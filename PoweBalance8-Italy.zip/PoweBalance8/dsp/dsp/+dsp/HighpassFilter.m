classdef (StrictDefaults)HighpassFilter < dsp.internal.LPHPFilterBase
    %HighpassFilter FIR or IIR highpass filter
    %   HPF = dsp.HighpassFilter returns a highpass filter, HPF, which
    %   independently filters each channel of the input over time using the
    %   given design specifications.
    %
    %   HPF = dsp.HighpassFilter('PropertyName', PropertyValue, ...)
    %   returns a highpass filter, HPF, with each specified property set to
    %   the specified value.
    %
    %   Step method syntax:
    %
    %   Y = step(HPF, X) filters the real or complex input signal X using
    %   the specified filter to produce the output Y. Each column of the
    %   input signal is filtered independently over time.
    %
    %   System objects may be called directly like a function instead of
    %   using the step method. For example, y = step(obj, x) and y = obj(x)
    %   are equivalent.
    %
    %   HighpassFilter methods:
    %
    %   step      - See above description for use of this method
    %   getFilter - Return underlying FIR or Biquad filter
    %   release   - Allow property value and input characteristics changes
    %   clone     - Create highpass filter object with same property values
    %   isLocked  - Locked status (logical)
    %   reset     - Reset the internal states to initial conditions
    % generatehdl - Generate HDL code. (Filter Design HDL Coder Required)
    %
    %   HighpassFilter properties:
    %
    %   SampleRate             - Sample rate of input in Hz
    %   FilterType             - FIR or IIR (Biquad)
    %   DesignForMinimumOrder  - Option for minimum/specify order design
    %   FilterOrder            - Order of the filter
    %   NormalizedFrequency    - Provide normalized frequencies for filter specifications
    %   PassbandFrequency      - Passband frequency of highpass filter
    %   StopbandFrequency      - Stopband frequency of highpass filter
    %   PassbandRipple         - Allowed passband ripple of highpass filter
    %   StopbandAttenuation    - Minimum stopband attenuation of the filter
    %
    %   This System object supports several filter analysis methods. For
    %   more information, type dsp.HighpassFilter.helpFilterAnalysis.
    %
    %   This System object supports fixed-point operations. For more
    %   information, type dsp.HighpassFilter.helpFixedPoint.
    %
    %   % EXAMPLE: Design an equiripple highpass FIR filter. Filter white
    %   % Gaussian noise with the resulting filter and estimate the
    %   % transfer function.
    %   % Initialize
    %   Fs = 96e3;
    %   HPF = dsp.HighpassFilter(SampleRate=Fs,PassbandFrequency=12e3);
    %   TFE = dsp.TransferFunctionEstimator(FrequencyRange='onesided',...
    %           SpectralAverages=50);
    %   AP = dsp.ArrayPlot(PlotType='Line',YLimits=[-100 5],...
    %           YLabel='Magnitude (dB)',XLabel='Frequency (Hz)',...
    %           SampleIncrement=Fs/1024,ShowLegend=true,...
    %           Title='Magnitude Response; Exact (Ch 1), Estimate (Ch 2)');
    %   Htrue = freqz(HPF,513); % Compute exact transfer function
    %   % Stream processing loop
    %   Niter = 1000;
    %   for k = 1:Niter
    %       x = randn(1024,1);  % Input signal = white Gaussian noise
    %       y = HPF(x);   % Filter noise with FIR filter
    %       H = TFE(x,y); % Compute transfer function estimate
    %       AP(20*log10(abs([Htrue,H]))); % Plot estimate
    %   end
    %  % EXAMPLE 2: Design an equiripple highpass FIR filter with passband
    %  % and stopband edges at 0.65 and 0.5 rad/sample respectively. Filter
    %  % white Gaussian noise with the resulting filter and estimate the
    %  % transfer function.
    %   HPF = dsp.HighpassFilter(NormalizedFrequency=true,PassbandFrequency=0.65, StopbandFrequency=0.5);
    %   TFE = dsp.TransferFunctionEstimator(FrequencyRange='onesided',...
    %           SpectralAverages=50);
    %   AP = dsp.ArrayPlot(PlotType='Line',YLimits=[-100 5],...
    %           YLabel='Magnitude (dB)',XLabel='Normalized Frequency (\times\pi rad/sample)',...
    %           SampleIncrement=2/1024,ShowLegend=true,...
    %           Title='Magnitude Response; Exact (Ch 1), Estimate (Ch 2)');
    %   Htrue = freqz(HPF,513); % Compute exact transfer function
    %   % Stream processing loop
    %   Niter = 1000;
    %   for k = 1:Niter
    %       x = randn(1024,1);  % Input signal = white Gaussian noise
    %       y = HPF(x);   % Filter noise with FIR filter
    %       H = TFE(x,y); % Compute transfer function estimate
    %       AP(20*log10(abs([Htrue,H]))); % Plot estimate
    %   end
    %
    %   See also dsp.HighpassFilter, dsp.VariableBandwidthFIRFilter,
    %   dsp.VariableBandwidthIIRFilter, dsp.FIRFilter, dsp.BiquadFilter.
    
    % Copyright 2014-2022 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCA>
    properties (Nontunable)
        %StopbandFrequency  Stopband edge frequency
        %   Specify the stopband edge frequency of the filter as a positive
        %   real scalar smaller than half the sample rate. This property
        %   applies when you set the DesignForMinimumOrder property to
        %   true. Specify the value of stopband edge frequency in Hertz
        %   when NormalizedFrequency is set to false and in normalized
        %   units when NormalizedFrequency is set to true. The default
        %   value of this property is 8 kHz.
        StopbandFrequency = 8e3;
        %PassbandFrequency  Passband edge frequency
        %   Specify the passband edge frequency of the filter as a positive
        %   real scalar smaller than half the sample rate. Specify the
        %   value of passband edge frequency in Hertz when
        %   NormalizedFrequency is set to false and in normalized units
        %   when NormalizedFrequency is set to true. The default value of
        %   this property is 12 kHz.
        PassbandFrequency = 12e3;
    end
    
    methods
        function obj = HighpassFilter(varargin)
            
            % Support name-value pair arguments
            setProperties(obj,nargin,varargin{:});
            obj.NumChannels = int32(-1);
            if obj.NormalizedFrequency                
                isPassbandFrequencySpecified = false;
                isStopbandFrequencySpecified = false;
                for i = 1:2:numel(varargin)
                    if strcmp(varargin{i}, 'PassbandFrequency')
                        isPassbandFrequencySpecified = true;
                    elseif strcmp(varargin{i}, 'StopbandFrequency')
                        isStopbandFrequencySpecified = true;
                    end
                end
                if ~isPassbandFrequencySpecified
                    obj.PassbandFrequency = 12000/(44100/2);
                end
                if ~isStopbandFrequencySpecified
                    obj.StopbandFrequency = 8000/(44100/2);
                end
            end
        end
        
        function set.PassbandFrequency(obj,Fp)
            validateattributes(Fp,{'numeric'},{'finite','scalar','real',...
                'positive'},'','PassbandFrequency');
            obj.PassbandFrequency = Fp;
            needToDesignFilters(obj);
        end
        
        function set.StopbandFrequency(obj,Fst)
            validateattributes(Fst,{'numeric'},{'finite','scalar','real',...
                'positive'},'','StopbandFrequency');
            obj.StopbandFrequency = Fst;
            needToDesignFilters(obj);
        end
    end
    %----------------------------------------------------------------------
    methods (Hidden)
        function flag = ishdlable(~)
            flag = true;
        end
    end
    %----------------------------------------------------------------------
    methods (Access = protected)
        function Fc=outputDelayDefaultNormalizedFc(~)
            % Return the (normalized) frequency for which group delay is evaluated in
            % outputDelay. 
            Fc = 1; % For highpass 
        end

        function b = computeFIRCoefficients(obj)
            Fs = getSampleRate(obj);
            
            Fp = obj.PassbandFrequency;
            Fpn = Fp./(Fs/2);
            Ap = obj.PassbandRipple;
            Rp = (10.^(Ap./20) - 1)./...
                (10.^(Ap./20) + 1);
            Ast = obj.StopbandAttenuation;
            Rs = 10.^(-Ast./20);
            
            if obj.DesignForMinimumOrder
                 Fst = obj.StopbandFrequency;
                 Fstn= Fst./(Fs/2);
                 b = firgr('minorder',[0 Fstn Fpn 1],[0 0 1 1],[Rs,Rp]);
            else
                N  = obj.FilterOrder;
                b = firceqrip(N,Fpn,[Rs,Rp],'passedge','high');
            end
        end
        
        function designFilter(obj,u)
            % Create filter System objects
            
            if isempty(coder.target)
                if obj.IsFilterDesigned
                    % This helps avoid duplicate construction of filters when
                    % setup() is called after getFilters().
                    % For codegen, this property is always false.
                    return
                end
            end
            
            coder.extrinsic('dsp.HighpassFilter.designBiquad');
            coder.extrinsic('dsp.internal.LPHPFilterBase.firPrecision');
            coder.extrinsic('dsp.internal.LPHPFilterBase.biquadPrecision');
            
            Fs = getSampleRate(obj);
            Fp = obj.PassbandFrequency;
            Ap = obj.PassbandRipple;
            Ast = obj.StopbandAttenuation;
            
            switch obj.FilterType
                case 'FIR'
                    b = computeFIRCoefficients(obj);

                    if isa(u,'double') || isa(u,'single')
                        FIR = dsp.FIRFilter('Numerator', cast(b,class(u)));
                    else
                        % fixed-point input
                        w = fi(b, obj.CoefficientsDataType);  % vector of filter weights of type fi
                        
                        % compute output data type
                        if isinteger(u)
                            x = numerictype(class(u));
                        else
                            x = numerictype(u);
                        end
                        [~,~,outputWL, outputFL] = coder.const(@dsp.internal.LPHPFilterBase.firPrecision, ...
                            w,x);
                        outputDType = numerictype(true, outputWL, outputFL);
                        
                        FIR = dsp.FIRFilter('Numerator', b, ...
                            'CoefficientsDataType', 'Custom', ...
                            'CustomCoefficientsDataType', numerictype(true,w.WordLength,w.FractionLength), ...
                            'FullPrecisionOverride', false, ...
                            'OutputDataType', 'Custom', ...
                            'CustomOutputDataType', outputDType, ...
                            'RoundingMethod', obj.RoundingMethod);
                    end
                    
                    obj.FilterObj = FIR;
                    
                    if isempty(coder.target)
                        % Set metadata for FVTool
                        if obj.DesignForMinimumOrder
                            Fst = obj.StopbandFrequency;
                            fdes = fdesign.highpass(Fst,Fp,Ast,Ap,Fs);
                            fmet = fdfmethod.eqriphp;
                        else
                            N  = obj.FilterOrder;
                            fdes = fdesign.highpass('N,Fp,Ast,Ap',N,Fp,Ast,Ap,Fs);
                            fmet = fdfmethod.eqriphpfpass;
                        end
                        if ~isempty(fdes)
                          if isprop(obj, 'NormalizedFrequency')
                              if obj.NormalizedFrequency
                                  % Display Normalized frequencies with
                                  % fvtool                                  
                                  normalizefreq(fdes);
                              end
                          end
                        end
                        setMetaData(obj, ...
                            fdes, fmet, ...
                            [], 'equiripple');
                        
                        obj.IsFilterDesigned = true;
                    end
                case 'IIR'
                    N  = obj.FilterOrder;
                    Fst = obj.StopbandFrequency;
                    
                    [SOS,SV] = coder.const(@obj.designBiquad,obj.DesignForMinimumOrder,N,Fp,Fst,Ap,Ast,Fs);
                    
                    if isa(u,'double') || isa(u,'single')
                        % Floating point
                        IIR = dsp.BiquadFilter(...
                            'Structure', 'Direct form I',...
                            'SOSMatrix',SOS,...
                            'ScaleValues',SV);
                        
                    else
                        % fixed-point input
                        
                        % Determine DT
                        cT = obj.CoefficientsDataType;
                        if isinteger(u)
                            x = numerictype(class(u));
                        else
                            x = numerictype(u);
                        end
                        [cT,secT,prodT,accT] = coder.const(@dsp.internal.LPHPFilterBase.biquadPrecision,cT,x);
                        
                        IIR = dsp.BiquadFilter(...
                            'Structure', 'Direct form I',...
                            'SOSMatrix',SOS,...
                            'ScaleValues',SV,...
                            'RoundingMethod', obj.RoundingMethod,...
                            'OverflowAction', 'Wrap',...
                            'SectionInputDataType', 'Custom',...
                            'CustomSectionInputDataType', secT,...
                            'SectionOutputDataType', 'Custom',...
                            'CustomSectionOutputDataType', secT,...
                            'NumeratorCoefficientsDataType','Custom',...
                            'CustomNumeratorCoefficientsDataType',cT,...
                            'DenominatorCoefficientsDataType', 'Custom',...
                            'CustomDenominatorCoefficientsDataType', cT,...
                            'ScaleValuesDataType', 'Custom',...
                            'CustomScaleValuesDataType',cT,...
                            'NumeratorProductDataType', 'Custom',...
                            'CustomNumeratorProductDataType', prodT, ...
                            'DenominatorProductDataType', 'Custom',...
                            'CustomDenominatorProductDataType', prodT,...
                            'NumeratorAccumulatorDataType','Custom',...
                            'CustomNumeratorAccumulatorDataType', accT, ...
                            'DenominatorAccumulatorDataType', 'Custom',...
                            'CustomDenominatorAccumulatorDataType', accT, ...
                            'OutputDataType', 'Custom',...
                            'CustomOutputDataType', secT ...
                            );
                    end
                    
                    obj.FilterObj = IIR;
                    
                    if isempty(coder.target)
                        % Set metadata for FVTool
                        if obj.DesignForMinimumOrder
                            fdes = fdesign.highpass(Fst,Fp,Ast,Ap,Fs);
                            fmet = fmethod.elliplpmin;
                        else
                            fdes = fdesign.highpass('N,Fp,Ast,Ap',N,Fp,Ast,Ap,Fs);
                            fmet = fmethod.elliplpastop;
                        end
                        if ~isempty(fdes)
                          if isprop(obj, 'NormalizedFrequency')
                              if obj.NormalizedFrequency
                                  % Display Normalized frequencies with
                                  % fvtool
                                  normalizefreq(fdes);
                              end
                          end
                        end
                        setMetaData(obj, ...
                            fdes, fmet, ...
                            [], 'ellip');
                        
                        obj.IsFilterDesigned = true;
                    end
            end
        end
        
        function crossValidateProperties(obj)
            HalfFs = getSampleRate(obj)./2;
            minord = obj.DesignForMinimumOrder;
            Fp = obj.PassbandFrequency;
            
             validateattributes(Fp,{'numeric'},{'finite','scalar','real',...
                'positive','<',HalfFs},'','PassbandFrequency');
            
            if minord
                Fst = obj.StopbandFrequency;
                validateattributes(Fst,{'numeric'},{'finite','scalar','real',...
                    'positive','<',Fp,'<',HalfFs},'','StopbandFrequency');
            end
        end
        
        function validatePropertiesImpl(obj)

            Ap = obj.PassbandRipple;
            Ast= obj.StopbandAttenuation;

            validateattributes(Ast,{'numeric'},{'finite','scalar','real',...
                'positive','>',Ap},'','StopbandAttenuation');
        end
        function flag = isInactivePropertyImpl(obj, prop)            
            switch prop
                case {'SampleRateMode'}
                    flag = true;
                otherwise
                    flag = isInactivePropertyImpl@dsp.internal.LPHPFilterBase(obj,prop);
            end
        end
        
    end
    %---------------------------------------------------------------------
    methods (Static)
        function helpFixedPoint
            %helpFixedPoint Display HighpassFilter System
            %               object fixed-point information
            %   dsp.HighpassFilter.helpFixedPoint displays
            %   information about fixed-point properties and operations of
            %   the HighpassFilter System object.
            
            matlab.system.dispFixptHelp('dsp.HighpassFilter', ...
                dsp.HighpassFilter.getDisplayFixedPointPropertiesImpl);
        end
    end
    %---------------------------------------------------------------------
    methods (Static,Hidden)
        
        function props = getDisplayPropertiesImpl()
            props = {...
                
                'FilterType',...
                'DesignForMinimumOrder', ...
                'FilterOrder', ...
                'StopbandFrequency', ...
                'PassbandFrequency', ...
                'StopbandAttenuation',...
                'PassbandRipple'...
                'NormalizedFrequency',...
                'SampleRate',...
                };
        end

        function a = getAlternateBlock()
            a = 'dspfdesign/Highpass Filter';
        end
        
        function [SOS,SV] = designBiquad(DesignForMinimumOrder,N,Fp,Fst,Ap,Ast,Fs)
            
            if DesignForMinimumOrder
                fdes = fdesign.highpass(Fst,Fp,Ast,Ap,Fs);
            else
                
                fdes = fdesign.highpass('N,Fp,Ast,Ap',N,Fp,Ast,Ap,Fs);
            end
            fdo = fdopts.sosscaling;
            fdo.NumeratorConstraint='none';
            fdo.ScaleValueConstraint='unit';
            FilterObj = design(fdes,'ellip',SystemObject=true,...
                FilterStructure='df2tsos',SOSScaleNorm='Linf',...
                SOSScaleOpts=fdo);

            SOS = FilterObj.SOSMatrix;
            SV  = FilterObj.ScaleValues(:);
            % Force an exact one for last scale value
            SOS(end,1:3) = SOS(end,1:3)*SV(end);
            SV(end) = 1; 
        end
 
    end
    %----------------------------------------------------------------------
    methods(Static,Hidden,Access=protected)
        function groups = getPropertyGroupsImpl
            props = dsp.HighpassFilter.getDisplayPropertiesImpl;
            
            mainS = matlab.system.display.Section('Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', props);
            filterVis = dsp.internal.FilterVisualizationButton;
            mainS.Actions = filterVis.fvtoolAction;
            mainSG = matlab.system.display.SectionGroup('TitleSource', 'Auto', ...
                'Sections', mainS);
            dtSG = matlab.system.display.internal.DataTypesGroup(...
                'dsp.HighpassFilter');
            dtSG.PropertyList{2} = matlab.system.display.internal.DataTypeProperty('CoefficientsDataType', ...
                'Prefix', 'coeffs', ...
                'Description', getString(message('dsp:system:Shared:Coefficients')));
            groups = [mainSG, dtSG];
        end
    end
end
