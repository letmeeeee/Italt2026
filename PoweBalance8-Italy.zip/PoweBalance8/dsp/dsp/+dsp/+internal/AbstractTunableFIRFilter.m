classdef AbstractTunableFIRFilter < matlab.System
%AbstractTunableFIRFilter

    %   Copyright 2022-2023 The MathWorks, Inc.

    %#codegen

    properties
        % FilterOrder FIR filter order
        %   Specify the order of the FIR filter as a positive integer
        %   scalar. The default is 100.
        FilterOrder = 100;
        % SidelobeAttenuation Chebyshev window sidelobe attenuation (dB)
        %   Specify the Chebyshev window sidelobe attenuation as a real,
        %   positive scalar in decibels (dB). This property applies when
        %   you set the Window property to "Chebyshev". The default is 60
        %   dB.
        SidelobeAttenuation = 60;
        % KaiserWindowParameter Kaiser window parameter
        %   Specify the Kaiser window parameter as a real scalar. This property
        %   applies when you set the  Window property to 'Kaiser'. The default is
        %   0.5;
        KaiserWindowParameter = .5;
    end

    properties(Nontunable)
        %MaxOrder FIR Filter maximum order
        %   Specify the filter maximum order as a finite positive integer
        %   scalar. The default value is 10.
        MaxOrder = 100
        % Window Window function
        %   Specify the window function used to design the FIR filter as
        %   one of "Hann" | "Hamming" | "Blackman" | "Blackman-Harris" |
        %   "Chebyshev" | "Kaiser". The default is "Hann".
        Window (1, :) char {matlab.system.mustBeMemberMessageID(Window, ...
            {'dsp:system:TunableFIRFilter:Window_Hann', ...
            'dsp:system:TunableFIRFilter:Window_Hamming', ...
            'dsp:system:TunableFIRFilter:Window_Blackman', ...
            'dsp:system:TunableFIRFilter:Window_BlackmanHarris', ...
            'dsp:system:TunableFIRFilter:Window_Chebyshev', ...
            'dsp:system:TunableFIRFilter:Window_Kaiser'})} = 'Hann';
        %OutputDataType Output data type
        %   Specify the output data type as "single" or "double". The
        %   default is "double".
        OutputDataType (1, :) char {matlab.system.mustBeMemberMessageID(OutputDataType, ...
            {'dsp:system:TunableFIRFilter:OutputDataType_double'; ...
            'dsp:system:TunableFIRFilter:OutputDataType_single'})} = 'double';
    end

    properties(Access = protected)
        num;
        isInit = false;
        pProtoypeWindow; 
    end

    properties(Access=protected,Nontunable)
        pWindowFunc = @hann;
        pIsChebwin(1, 1) logical = false;
        pIsKaiser(1, 1) logical = false;
    end

    methods
        function this = AbstractTunableFIRFilter(varargin)
            % Support name-value pair arguments when constructing object
            setProperties(this,nargin,varargin{:})
        end
        %------------------------------------------------------------------
        function set.FilterOrder(this,value)
            validateFilterOrder(this, value, false);
            this.FilterOrder = value;
        end
        %------------------------------------------------------------------
        function set.MaxOrder(this, value)
            validateMaxOrder(this, value);
            this.MaxOrder = value;
        end
        %------------------------------------------------------------------
        function set.SidelobeAttenuation(this,value)
            validateSidelobeAttenuation(this, value);
            this.SidelobeAttenuation = value;
        end
        %------------------------------------------------------------------
        function set.KaiserWindowParameter(this,value)
            validateKaiserWindowParameter(this, value);
            this.KaiserWindowParameter = value;
        end
    end

    methods(Access = protected)
        %------------------------------------------------------------------
        function setupImpl(this)
            dims = getCoefficientsDimensions(this);
            dt = this.OutputDataType;
            L = dims(2);
            this.num = zeros(1, L, dt);
            this.pProtoypeWindow = zeros(1, L, dt);
            this.pIsChebwin = isChebwin(this);
            this.pIsKaiser = isKaiser(this);
            switch(this.Window)
                case 'Hann'
                    this.pWindowFunc = @dsp.util.hann;
                case 'Hamming'
                    this.pWindowFunc = @dsp.util.hamming;
                case 'Blackman'
                    this.pWindowFunc = @dsp.util.blackman;
                case 'Blackman-Harris'
                    this.pWindowFunc = @dsp.util.blackmanharris;
                case 'Chebyshev'
                    this.pWindowFunc = @dsp.util.chebwin;
                case 'Kaiser'
                    this.pWindowFunc = @dsp.util.kaiserwin;
            end
        end
        %------------------------------------------------------------------
        function b = stepImpl(this)
            if ~this.isInit
                processTunedPropertiesImpl(this);
            end
            b = this.num;
        end
        %------------------------------------------------------------------
        function resetImpl(this)
            this.num(1,:) = 0;
        end
        %------------------------------------------------------------------
        function releaseImpl(this)
            this.num(:,1) = 0;
            this.isInit = false;
        end
        %------------------------------------------------------------------
        function processTunedPropertiesImpl(this)
            % If CenterFrequency or Bandwidth are coming from an input
            % port, the Simulink engine sets their value to zero before
            % actually reading the correct value provided at the input.
            if ~isDesignFilterAllowed(this)
                return;
            end
            crossValidateProperties(this);
            % we need to reset the coefficients cache, specially for cases
            % when the filter order decreases.
            resetCoefficientsCache(this);
            this.isInit = true;
            n = this.num;
            b = designFilter(this);
            n(1,1:numel(b)) = b;
            this.num = n;
        end
        %------------------------------------------------------------------
        function validatePropertiesImpl(this)
            crossValidateProperties(this);
        end
        %------------------------------------------------------------------
        function s = saveObjectImpl(this)
            % Set properties in structure s to values in object obj
            % Set public properties and states
            s = saveObjectImpl@matlab.System(this);
            s.num = this.num;
            s.isInit = this.isInit;
            s.pProtoypeWindow = this.pProtoypeWindow;
            s.pWindowFunc = this.pWindowFunc;
            s.pIsChebwin = this.pIsChebwin;
            s.pIsKaiser = this.pIsKaiser;
        end
        %------------------------------------------------------------------
        function loadObjectImpl(this,s,wasLocked)
            % Set properties in object obj to values in structure s
            % Set public properties and states
            loadObjectImpl@matlab.System(this,s,wasLocked);
            if wasLocked
                this.num = s.num;
                this.isInit = s.isInit;
                this.pProtoypeWindow = s.pProtoypeWindow;
                this.pWindowFunc = s.pWindowFunc;
                this.pIsChebwin = s.pIsChebwin;
                this.pIsKaiser = s.pIsKaiser;
            end
        end
        %------------------------------------------------------------------
        function flag = isInputSizeMutableImpl(~,~)
            % Return false if input size cannot change
            % between calls to the System object
            flag = false;
        end
        %------------------------------------------------------------------
        function crossValidateProperties(this)
            validateFilterOrder(this, this.FilterOrder, true);
            if isChebwin(this)
                validateSidelobeAttenuation(this, this.SidelobeAttenuation);
            end
            if isKaiser(this)
                validateKaiserWindowParameter(this, this.KaiserWindowParameter);
            end
        end
        %------------------------------------------------------------------
        function flag = isInactivePropertyImpl(this, prop)
            flag = false;
            switch prop
                case 'SidelobeAttenuation'
                    flag = ~isChebwin(this);
                case 'KaiserWindowParameter'
                    flag = ~isKaiser(this);
            end
        end
        %------------------------------------------------------------------
        function validateFilterOrder(this, value, compareWithMax)
            if compareWithMax
                validateattributes(value, {'numeric'}, {'finite','real','scalar','integer','nonnegative','even','<=',this.MaxOrder}, 'set.FilterOrder', 'FilterOrder');
            else
                validateattributes(value, {'numeric'}, {'finite','real','scalar','integer','nonnegative','even'}, 'set.FilterOrder', 'FilterOrder');
            end
        end
        %------------------------------------------------------------------
        function validateMaxOrder(~, value)
            validateattributes(value, {'numeric'}, {'finite','real','scalar','integer','positive','even'}, 'set.MaxOrder','MaxOrder');
        end
        %------------------------------------------------------------------
        function validateSidelobeAttenuation(~, value, varargin)
            allowZero = false;
            if numel(varargin) > 0
                allowZero = varargin{1};
            end
            if allowZero
                validateattributes(value, {'double','single'}, {'finite','real','scalar','nonnegative'}, 'set.SidelobeAttenuation','SidelobeAttenuation');
            else
                validateattributes(value, {'double','single'}, {'finite','real','scalar','positive'}, 'set.SidelobeAttenuation','SidelobeAttenuation');
            end
        end
        %------------------------------------------------------------------
        function validateKaiserWindowParameter(~, value)
            validateattributes(value,{'double','single'}, {'real','scalar','finite','nonnegative'},'set.KaiserWindowParameter','KaiserWindowParameter');
        end
        %------------------------------------------------------------------
        function dims = getCoefficientsDimensions(this)
            dims = [1 this.MaxOrder + 1];
        end
        %------------------------------------------------------------------
        function flag = isDesignFilterAllowed(this)
            flag = this.FilterOrder > 0 && this.SidelobeAttenuation > 0;
        end
        %------------------------------------------------------------------
        function computePrototypeWindow(this)
            dt = this.OutputDataType;
            L = this.FilterOrder + 1;
            assert(L<=this.MaxOrder + 1);
            if this.pIsChebwin
                this.pProtoypeWindow(1,1:L) = this.pWindowFunc(L,this.SidelobeAttenuation,dt);
            elseif this.pIsKaiser
                this.pProtoypeWindow(1,1:L) = this.pWindowFunc(L,this.KaiserWindowParameter,'symmetric',dt);
            else
                this.pProtoypeWindow(1,1:L) = this.pWindowFunc(L,'symmetric',dt);
            end
        end
        %------------------------------------------------------------------
        function b = designLowpassCoefficients(this)
            % Compute the design window
            computePrototypeWindow(this);
            dt = this.OutputDataType;
            Fc = cast(getCutoffFrequency(this),dt);
            twoCast = cast(2, dt);
            b = dsp.filterdesign.internal.fir.lpfir(cast(this.FilterOrder,dt), Fc, twoCast, this.pProtoypeWindow, cast(this.MaxOrder,dt));
        end
        %------------------------------------------------------------------
        function resetCoefficientsCache(this)
            dt = this.OutputDataType;
            zeroCast = cast(0, 'like', dt);
            this.num(1,:) = zeroCast;
        end
    end

    methods(Hidden)
        %------------------------------------------------------------------
        function flag = isChebwin(this)
            flag = strcmpi(this.Window,'Chebyshev');
        end
        %------------------------------------------------------------------
        function flag = isKaiser(this)
            flag = strcmpi(this.Window,'Kaiser');
        end
    end

    methods(Access=protected, Abstract)
        %------------------------------------------------------------------
        [b,a] = designFilter(this);
        Fc = getCutoffFrequency(this);
    end
end