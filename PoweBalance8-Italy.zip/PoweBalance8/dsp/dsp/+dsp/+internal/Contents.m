% Internal package for DSP System Toolbox System objects

% Copyright 1995-2010 The MathWorks, Inc.
