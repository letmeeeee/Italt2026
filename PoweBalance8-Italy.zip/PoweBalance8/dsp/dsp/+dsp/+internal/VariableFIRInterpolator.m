classdef (StrictDefaults)VariableFIRInterpolator < matlab.System ...
        & dsp.enhancedsim.UpdateSysObjBuildInfo
%VARIABLEFIRINTERPOLATOR Variable FIR Interpolator
%   VFIRI = dsp.internal.VariableFIRInterpolator returns a System object, VFIRI, 
%   which interpolates the input using a polyphase filter structure oriented with respect
%   to the maximum interpolation factor. The interpolation factor can vary at each step 
%   and has to be a factor of the maximum interpolation factor. The filter coefficients are 
%   auto computed by default and can be specified externally.
%
%   VFIRI = dsp.internal.VariableFIRInterpolator(Name=Value, ...) returns a
%   Variable FIR Interpolator System object, VFIRI, with each specified
%   property name set to the specified value. You can specify additional
%   name-value pair arguments in any order as (Name1=Value1,...,Name=ValueN).
%
%   Step method syntax:
%
%   Y = step(VFIRI, X) interpolates the real or complex input signal X using the
%   specified filter to produce the output Y. The System object filters
%   each channel of the input signal independently over time.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%   Variable FIR Interpolator methods:
%
%   step          - See above description for use of this method
%   release      - Allow property value and input characteristics changes
%   clone        - Create Variable FIR Interpolator Filter object with
%                      same property values
%   isLocked   - Locked status (logical)
%   reset         - Reset the internal states to initial conditions
%
%   VariableBandwidthFIRFilter properties:
%   
%   MaxInterpolationFactor - Maximum interpolation factor
%   InterpolationFactor        - Interpolation factor
%   CoefficientSource          - Coefficient source
%   Coefficients                   - Prototype filter coefficients
%
%   % EXAMPLE #1: Interpolate input by a factor of 24
%   firInterp = dsp.internal.VariableFIRInterpolator(24);
%   x = (0:2)'
%   firInterp.InterpolationFactor = 6;
%   y = firInterp(x)
%   See also dsp.FIRInterpolator, dsp.FIRRateConverter, designMultirateFIR.
    %#codegen
    %#ok<*EMCA>
    %#ok<*EMCLS>

%   Copyright 2022-2023 The MathWorks, Inc.
    properties(Nontunable)
        % MaxInterpolationFactor Maximum interpolation factor
        % Specify the maximum interpolation factor which is used to compute
        % the polyphase filter structure. Interpolation factor cannot be
        % greater than this value. The default value of this property is
        % 24.
        MaxInterpolationFactor = 24;
        % CoefficientSource Coefficient source
        % Specify the input source for coefficients as "Auto", "Dialog
        % parameter" or "Input port". The default is "Auto".
        CoefficientSource (1, :) char {matlab.system.mustBeMemberMessageID(CoefficientSource, ...
            {'dsp:system:VariableFIRInterpolator:CoefficientSource_Auto'; ...
            'dsp:system:VariableFIRInterpolator:CoefficientSource_Dialogparameter'; ...
            'dsp:system:VariableFIRInterpolator:CoefficientSource_Inputport'})} = 'Auto';
        % Specification Output frame length specification
        % Set the output frame length specification as "Interpolation
        % factor" or "Output frame length". The default is "Interpolation
        % factor".
        Specification (1, :) char {matlab.system.mustBeMemberMessageID(Specification, ...
            {'dsp:system:VariableFIRInterpolator:Specification_Interpolationfactor'; ...
            'dsp:system:VariableFIRInterpolator:Specification_Outputframelength'})} = 'Interpolation factor';
        % OutputFrameLength Output signal frame length
        % Specify the output signal frame length as a positive integer.
        % This property applies when the Specification is "Output frame
        % length". The default is 48.
        OutputFrameLength = 48;
    end

    properties
        % Coefficients Prototype filter coefficients
        % This property is overwritten when CoefficientSource is set to 'Dialog
        % parameter' or 'Input port'. 
        Coefficients = designMultirateFIR(24, 1);
        % InterpolationFactor Interpolation factor
        % Specify the interpolation factor at step. This value has to be a
        % factor of MaxInterpolationFactor. The default value of this
        % property is 24.
        InterpolationFactor = 24;
    end

    properties(Access = protected)
        pStates;
        pPolyphaseCoefficients;
        pFlippedPolyphaseCoefficients;
        pInputFrameLength = int32(-1);
        pNumChannels = int32(-1);
        pPrivNumCoefficients;
        pInputDataType;
    end

    properties(Access = private, Nontunable)
        pCompiledNumChannels = int32(-1);
        pCompiledMaxInterpolationFactor = uint32(24);
        pInterpFactorSpec (1, 1) logical = true;
    end
    %----------------------------------------------------------------------
    methods
        %------------------------------------------------------------------
        function obj = VariableFIRInterpolator(varargin)
            % Support name-value pair arguments when constructing object
            setProperties(obj,nargin,varargin{:},'MaxInterpolationFactor');
        end
        %------------------------------------------------------------------
        function set.MaxInterpolationFactor(obj,LM)
            validateattributes(LM,{'numeric'},{'positive','scalar','integer','finite'},'','MaxInterpolationFactor');
            obj.MaxInterpolationFactor = LM;
        end
        %------------------------------------------------------------------
        function set.InterpolationFactor(obj,L)
            validateattributes(L,{'numeric'},{'scalar','integer','finite'},'','InterpolationFactor');
            obj.InterpolationFactor = L;
        end
        %------------------------------------------------------------------
        function set.Coefficients(obj,b)
            validateattributes(b,{'single','double'},{'finite','row'},'','Coefficients');
            obj.Coefficients = b;
        end
    end
    %----------------------------------------------------------------------
    methods(Access=protected)
        %------------------------------------------------------------------
        function designFilter(obj)
            Lmax = uint32(getMaxInterpolationFactor(obj));
            if strcmp(obj.CoefficientSource, 'Auto')
                b = coder.const(cast(designMultirateFIR(Lmax,1), class(obj.pInputDataType)));
                Np = ceil(size(b,2)/Lmax);
                obj.pPolyphaseCoefficients = reshape(b, [Lmax, Np]);
            else
                setPolyphaseMatrixFromCustomCoeffs(obj);
            end
            obj.pFlippedPolyphaseCoefficients = rot90(obj.pPolyphaseCoefficients);
        end

        %------------------------------------------------------------------
        function setupImpl(obj,u)
            [FL,N] = getInputDataSize(obj,u);
            obj.pNumChannels = int32(N);
            obj.pCompiledNumChannels = int32(N);
            obj.pInputFrameLength = int32(FL);
            obj.pInputDataType = cast(1, class(u));
            obj.pInterpFactorSpec = strcmpi(obj.Specification, 'Interpolation factor');
            if obj.pInterpFactorSpec
                obj.pCompiledMaxInterpolationFactor = uint32(obj.MaxInterpolationFactor);
            else
                obj.pCompiledMaxInterpolationFactor = uint32(obj.OutputFrameLength);
            end
            % Error if the Input frame length is not a divisor of the
            % output frame length
            coder.internal.errorIf(~obj.pInterpFactorSpec && mod(obj.OutputFrameLength,FL), 'dsp:system:VariableFIRInterpolator:InputNotDivisorOfOutput', obj.OutputFrameLength);
            designFilter(obj);
            if ~strcmp(obj.CoefficientSource, 'Auto')
                obj.pPrivNumCoefficients = numel(obj.Coefficients);
            else
                obj.pPrivNumCoefficients = numel(obj.pPolyphaseCoefficients);
            end
            Np = coder.const(size(obj.pPolyphaseCoefficients, 2));
            obj.pStates = zeros(Np, N, 'like', u);
        end
        %------------------------------------------------------------------
        function y = stepImpl(obj,u)
            Lmax = uint32(obj.pCompiledMaxInterpolationFactor);
            L = uint32(getInterpolationFactor(obj));
            % Verify interpolation factor
            coder.internal.errorIf(mod(Lmax, L) ~= 0, 'dsp:system:VariableFIRInterpolator:InterpolationFactorNotDividing', L, Lmax);
            assert(L<=Lmax);
            z = obj.pStates;
            p = obj.pFlippedPolyphaseCoefficients;
            Np = uint32(size(p,1));
            if isempty(coder.target)
                [y, z] = dsp.internal.builtins.variableFIRInterpolator(u, z, p, Lmax, L, Np);
            else
                oneCast = cast(1, 'like', u);
                if ~isreal(p)
                    oneCast = cast(1, 'like', p);
                end
                if obj.pInterpFactorSpec
                    y = zeros(size(u,1) * L, obj.pCompiledNumChannels, 'like', oneCast);
                else
                    y = zeros(obj.OutputFrameLength, obj.pCompiledNumChannels, 'like', oneCast);
                end
                if coder.const(feval('dsp.enhancedsim.IsSysObjSimInCodeGen', coder.target))
                    [y, z] = dsp.internal.VariableFIRInterpolator.variableFIRInterpolatorHalideCG(u, z, p, Lmax, L, Np, y);
                else
                    [y, z] = dsp.internal.VariableFIRInterpolator.variableFIRInterpolatorCG(u, z, p, Lmax, L, Np, y);
                end
            end
            obj.pStates = z;
        end
        %------------------------------------------------------------------
        function resetImpl(obj)
            % Initialize / reset discrete-state properties
            obj.pStates = zeros(size(obj.pStates), 'like', obj.pStates);
        end
        %------------------------------------------------------------------
        function releaseImpl(obj)
            obj.pNumChannels = int32(-1);
            obj.pInputFrameLength = int32(-1);
        end
        %------------------------------------------------------------------
        function validateInputsImpl(obj,u,~,~)
            validateattributes(u, {'single', 'double'}, {'2d'},'','');
            % Verify number of channels
            [FL,N] = size(u);
            if obj.pNumChannels == -1 || obj.pNumChannels ==  0 || N == 0 || ...
                    obj.pInputFrameLength == -1 || obj.pInputFrameLength == 0 || FL == 0
                return;
            end
            % Error if number of channels changes
            coder.internal.errorIf(size(u,2) ~= obj.pNumChannels, 'dsp:system:Shared:numChannels');
            obj.pInputFrameLength = int32(FL);
        end
        %------------------------------------------------------------------
        function processTunedPropertiesImpl(obj)
            if ~strcmpi(obj.CoefficientSource,'Auto') 
                coder.internal.errorIf(numel(obj.Coefficients) ~= obj.pPrivNumCoefficients,'dsp:system:VariableFIRInterpolator:noChangeNumCoeffs');
                designFilter(obj);
            end
        end
        %------------------------------------------------------------------
        function flag = isInactivePropertyImpl(obj, prop)
            flag = false;
            switch prop
                case {'OutputFrameLength'}
                    flag = strcmpi(obj.Specification, 'Interpolation factor');
                case {'MaxInterpolationFactor', 'InterpolationFactor'}
                    flag = strcmpi(obj.Specification, 'Output frame length');
                case {'Coefficients'}
                    flag = ~strcmpi(obj.CoefficientSource, 'Dialog parameter'); 
            end
        end
        %------------------------------------------------------------------
        function s = saveObjectImpl(obj)
            % Default implementation saves all public properties
            s = saveObjectImpl@matlab.System(obj);
            if isLocked(obj)
                % All the following are set at setup
                s.pInputDataType                 = obj.pInputDataType;
                s.pNumChannels                   = obj.pNumChannels;
                s.pPrivNumCoefficients           = obj.pPrivNumCoefficients;
                s.pPolyphaseCoefficients         = obj.pPolyphaseCoefficients;
                s.pFlippedPolyphaseCoefficients  = obj.pFlippedPolyphaseCoefficients;
                s.pStates                        = obj.pStates;
                s.Coefficients                   = obj.Coefficients;
                s.InterpolationFactor            = obj.InterpolationFactor;
                s.pInputFrameLength              = obj.pInputFrameLength;
                s.pInterpFactorSpec              = obj.pInterpFactorSpec;
                s.pCompiledNumChannels           = obj.pCompiledNumChannels;
                s.pCompiledMaxInterpolationFactor= obj.pCompiledMaxInterpolationFactor;
            end
        end
        %------------------------------------------------------------------
        function s = loadObjectImpl(obj, s, wasLocked)
            % Re-load state if saved version was locked
            if wasLocked
                % All the following were set at setup
                obj.pInputDataType                  = s.pInputDataType;
                obj.pNumChannels                    = s.pNumChannels;
                if isfield(s,'privNumCoefficients')
                    obj.pPrivNumCoefficients       = s.pPrivNumCoefficients;
                else
                    if ~strcmpi(obj.CoefficientSource,'Auto')
                        obj.pPrivNumCoefficients   = numel(s.pPrivNumCoefficients);
                    end
                end
                obj.pPolyphaseCoefficients         = s.pPolyphaseCoefficients;
                obj.pFlippedPolyphaseCoefficients  = s.pFlippedPolyphaseCoefficients;
                obj.pStates                        = s.pStates;
                obj.Coefficients                   = s.Coefficients;
                obj.InterpolationFactor            = s.InterpolationFactor;
                obj.pInputFrameLength              = s.pInputFrameLength;
                if isfield(s, 'pCompiledNumChannels')
                    obj.pCompiledNumChannels            = s.pCompiledNumChannels;
                end
                if isfield(s,'pCompiledMaxInterpolationFactor')
                    obj.pCompiledMaxInterpolationFactor = s.pCompiledMaxInterpolationFactor;
                end
                if isfield(s, 'pInterpFactorSpec')
                    obj.pInterpFactorSpec               = s.pInterpFactorSpec;
                end
            end
            
            % Call base class method
            loadObjectImpl@matlab.System(obj,s,wasLocked);
        end
        %------------------------------------------------------------------
        function setPolyphaseMatrixFromCustomCoeffs(obj)
            Lmax = int32(getMaxInterpolationFactor(obj));
            b = obj.Coefficients;
            N = int32(length(b)); % Make sure mod is in right data type
            L = mod(N,Lmax);
            if L ~= 0
                bnew = [b(:); zeros(Lmax-L,1,'like',b)];
            else
                bnew = b;
            end
            Np = ceil(numel(bnew) / Lmax);
            obj.pPolyphaseCoefficients = cast(reshape(bnew, [Lmax, Np]),class(obj.pInputDataType));
        end
        %------------------------------------------------------------------
        function [L,N] = getInputDataSize(~, u)
            % fetch the number of channels
            [L,N] = size(u);
        end
        %------------------------------------------------------------------
        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end
        %------------------------------------------------------------------
        function flag = isInputComplexityMutableImpl(~,~)
            % Return false if input complexity cannot change
            % between calls to the System object
            flag = false;
        end
        %------------------------------------------------------------------
        function flag = isInputDataTypeMutableImpl(~,~)
            % Return false if input data type cannot change
            % between calls to the System object
            flag = false;
        end
        %------------------------------------------------------------------
        function b = polyphase2coeffs(obj)
            p = polyphase(obj);
            b = reshape(p,1,numel(p));
        end
        %------------------------------------------------------------------
        function M = getInterpolationFactor(obj)
            if obj.pInterpFactorSpec
                M = obj.InterpolationFactor;
            else
                M = int32(obj.OutputFrameLength) / obj.pInputFrameLength;
            end
        end
        %------------------------------------------------------------------
        function Lmax = getMaxInterpolationFactor(obj)
            if strcmpi(obj.Specification, 'Output frame length') 
                Lmax = obj.pCompiledMaxInterpolationFactor;
            else
                Lmax = obj.MaxInterpolationFactor;
            end
        end
    end
    %----------------------------------------------------------------------
    methods(Static,Access = protected)
        %------------------------------------------------------------------
        function [y, z] = variableFIRInterpolatorCG(u, z, p, Lm, L, Np, y)
            FL = uint32(size(u, 1));
            cb = [z(1:Np-1,:); u];
            for i = 1 : FL
                for j = 1 : L
                    y((i - 1) * L + j, :) = sum(cb(i : i + Np - 1, :) .* p(:, ((j-1) * Lm / L) + 1));
                end
            end
            z(1:Np-1, :) = cb(FL + 1 : end, :);
        end
        %------------------------------------------------------------------
        function [y, z] = variableFIRInterpolatorHalideCG(u, z, p, Lm, L, Np, y)
            coder.cinclude('iHalideVariableFIRInterpolator.hpp');
            if isa(u,'single') && ~isreal(u)
                if isreal(p)
                    func = 'processHalide_variableFirInterpolatorCRS';
                else
                    func = 'processHalide_variableFirInterpolatorCCS';
                end
            elseif isa(u,'double') && ~isreal(u)
                if isreal(p)
                    func = 'processHalide_variableFirInterpolatorCRD';
                else
                    func = 'processHalide_variableFirInterpolatorCCD';
                end
            elseif isa(u,'single') && isreal(u)
                if isreal(p)
                    func = 'processHalide_variableFirInterpolatorRRS';
                else
                    func = 'processHalide_variableFirInterpolatorRCS';
                end
            elseif isa(u,'double') && isreal(u)
                if isreal(p)
                    func = 'processHalide_variableFirInterpolatorRRD';
                else
                    func = 'processHalide_variableFirInterpolatorRCD';
                end
            end
            Lx = uint32(size(u, 1));
            Nc = uint32(size(u, 2));
            ps = zeros(L, 1, 'int32');
            for i = 1 : L
                ps(i) = int32((i-1) * (Lm / L));
            end
            coder.ceval(func, coder.ref(u), p, Lx, uint32(Np), Nc, uint32(L), uint32(Lm), ps, coder.ref(z), coder.ref(y));
        end
        %------------------------------------------------------------------
        function groups = getPropertyGroupsImpl

        % Modify order of display
            parameterString = getString(message('dsp:system:Shared:Parameters'));
            groups =  matlab.system.display.Section(...
                'Title', parameterString, ...
                'PropertyList', {'Specification','OutputFrameLength','MaxInterpolationFactor','InterpolationFactor','CoefficientSource','Coefficients'});
        end
    end
    %----------------------------------------------------------------------
    methods(Access=public)
        %------------------------------------------------------------------
        function c = coeffs(obj)
            %c = coeffs(obj) Return structure with filter coefficients
            %   c = coeffs(obj) returns the overall prototype lowpass
            %   filter coefficients in a structure.
            c.Numerator = polyphase2coeffs(obj);
        end
        %------------------------------------------------------------------
        function p = polyphase(obj)
            %p = polyphase(obj) Return polyphase matrix
            %   p = polyphase(obj) returns the polyphase matrix used by the
            %   filter bank. Each row in the matrix corresponds to a
            %   polyphase branch. The number of columns of p corresponds to
            %   the number of filter taps per branch.
            if ~isLocked(obj)
                designFilter(obj);
            end
            p = obj.pPolyphaseCoefficients;
        end
        %------------------------------------------------------------------
        function [b,a] = tf(obj)
            %[b,a] = tf(obj) Return transfer function
            %   [b,a] = tf(obj) returns the vector of numerator
            %   coefficients b and the vector of denominator coefficients a
            %   for the overall prototype lowpass filter used for the
            %   filter bank.
            b = polyphase2coeffs(obj);
            a = 1;
        end
        %------------------------------------------------------------------
        function fvt = fvtool(obj)
            if strcmp(obj.CoefficientSource, 'Auto')
                b = obj.polyphase2coeffs;
            else
                b = obj.Coefficients;
            end
            Lm = obj.MaxInterpolationFactor;
            filt = dsp.FIRInterpolator(InterpolationFactor=Lm, Numerator=b);
            fvt = fvtool(filt);
        end
    end
end
