classdef ConverterFilterDesignerBase < matlab.System
%dsp.internal.ConverterFilterDesignerBase Base class for the UpConverterFilterDesigner
%and DownConverterFilterDesigner classes.
    
% Copyright 2010-2020 The MathWorks, Inc.
%#codegen
%#ok<*EMCA>
    
    properties (Nontunable)
        %Bandwidth Double sided signal bandwidth
        Bandwidth = 200e3;
        %MinimumOrderDesign Minimum order design flag. Can be set to true
        %or false
        MinimumOrderDesign = true;
        %PassbandRipple Passband ripple in dB
        %   This property applies when you set the MinimumOrderDesign
        %   property to true.
        PassbandRipple= 0.1;
        %StopbandAttenuation Stopband attenuation in dB
        %   This property applies when you set the MinimumOrderDesign
        %   property to true.
        StopbandAttenuation = 60;
        %OrderStage2 Order of second filter stage
        %   This property applies when you set the MinimumOrderDesign
        %   property to false.
        OrderStage2 = 12;
        %StopbandFrequencySource Source of stopband frequency
        %   This property can be set to 'Auto' or 'Property'.
        StopbandFrequencySource = 'Auto';
        %StopbandFrequency Stopband frequency in Hertz
        %   This property applies when you set the StopbandFrequencySource
        %   property to 'Property'.
        StopbandFrequency = 150e3;
        %Arithmetic Filter arithmetic
        %   Set this property to 'double', 'single', or 'fixed'. This
        %   property controls the way in which the CIC section is
        %   implemented. If set to 'double' or 'single', the CIC stage is
        %   implemented as an FIR filter (coefficients of a cascade of
        %   boxcar filters). If set to 'fixed' the CIC stage is implemented
        %   as a true CIC filter. When this property is set to 'fixed',
        %   the filter designer finds the smallest coefficient word lengths
        %   that meet the frequency and attenuation specifications.
        Arithmetic = 0
        %OutputNumericType Numerictype of output
        OutputNumericType
        %InputNumericType Numerictype  of input
        InputNumericType
        %IsFilterDesignAvailable Flag is true if a filter design is available
        IsFilterDesignAvailable = false;
    end
    
    properties (Nontunable, SetAccess = protected)
        %CICFilterSysObj Handle to System object that forms the CIC stage
        CICFilterSysObj
        %GainFilter Scalar that forms the gain stage
        GainFilter
        %CICCompFilterSysObj Handle to System object that forms the CIC
        %compensator stage
        CICCompFilterSysObj
    end
    
    properties (Nontunable, Access = protected)
        %pCascadeFilterStopbandFrequency Stopband frequency of the cascade
        %response. This property will be used to verify attenuation in the
        %stopband of the cascade response.
        pCascadeFilterStopbandFrequency
        %pM1 Interpolation or decimation factor for first filter stage
        pM1
        %pM2 Interpolation or decimation factor for second filter stage
        pM2
        %pM3 Interpolation or decimation factor for third filter stage
        pM3
        %pFsStage1 Operating sampling frequency of first filter stage in
        %Hertz
        pFsStage1
        %pFsStage2 Operating sampling frequency of second filter stage in
        %Hertz
        pFsStage2
        %pFstopStage2 Stopband frequency of second filter stage in Hertz
        pFstopStage2
        %pFsStage3 Operating sampling frequency of third filter stage in
        %Hertz
        pFsStage3
        %pNumMagRespMeasPoints Number of frequency points used to measure
        %magnitude response.
        pNumMagRespMeasPoints = 4096;
        %pFCICNulls Vector containing the frequency locations (in Hertz) of
        %the nulls of the CIC stage.
        pFCICNulls
        %pStopbandAttenuationStep Step to increase the attenuation when designing
        %minimum order filters. Must be in dB.
        pStopbandAttenuationStep = 2;
        %pPassBandRippleReductionFactor Factor to reduce passband ripple when
        %designing minimum order filters.
        pPassBandRippleReductionFactor = 0.85;
    end
    
    properties (Access = protected)
        %pCICFilter Handle to an mfilt object that forms the CIC stage
        pCICFilter
        %pGainFilter Handle to a dfilt object that forms the gain stage
        pGainFilter
        %pCICCompFilter Handle to an mfilt object that forms the CIC compensator
        %stage
        pCICCompFilter
        %pCascadeFilter Handle to an mfilt object containing the cascade response
        pCascadeFilter
    end
    
    properties (Nontunable, Access = protected, Dependent)
        %pPassbandFrequency Passband frequency in Hertz
        pPassbandFrequency
    end
    
    %----------------------------------------------------------------------
    % Abstract methods
    %----------------------------------------------------------------------
    methods (Access = protected, Abstract)
        setFilterSectionTypes(obj)
        checkPropertyValues(obj)
        computeFrequencySpecifications(obj)
        nulls = computeCICNullFrequencies(obj)
        designFiltersMinOrder(obj)
%         setCoefficientsWordLength(obj,WL1,WL2)
%         flag = privIsSpecMet(obj)
    end
    methods (Abstract)
        SystemObjectsToMfilt(obj)
    end
    
    %----------------------------------------------------------------------
    % Public methods
    %----------------------------------------------------------------------
    methods
        %CONSTRUCTOR
        function obj = ConverterFilterDesignerBase(varargin)
            setProperties(obj, nargin, varargin{:});
        end
        %------------------------------------------------------------------
        function value = get.pPassbandFrequency(obj)
            value = obj.Bandwidth/2;
        end
        function set.Arithmetic(obj, val)
            if strcmp(val,'double')
                obj.Arithmetic = 0;
            elseif strcmp(val,'single')
                obj.Arithmetic = 1;
            else
                obj.Arithmetic = 2;
            end
        end
        function val = get.Arithmetic(obj)
            if obj.Arithmetic == 0
                val = 'double';
            elseif obj.Arithmetic == 1
                val = 'single';
            else
                val = 'fixed';
            end
        end
    end
    
    %----------------------------------------------------------------------
    % Protected methods
    %----------------------------------------------------------------------
    methods (Access = protected)
        function isDesignAvailable(obj)
            coder.internal.errorIf(~isLocked(obj), ...
                'dsp:system:DigitalDownConverter:noDesignAvailable');
        end
        %-------------------------------------------------------------------------
        function  hfvt = privFvtool(obj,Fs,cascadeGain,varargin)
            % Plot response of cascade using fvtool.
            % Fs is sampling frequency used in fvtool
            % cascadeGain is the gain of filter cascade
            % varargin contains other p-v pairs for fvtool
            isDesignAvailable(obj)
            useDefaultsFlag = false;
            if ~isempty(varargin)
                for idx = 1:length(varargin)
                    if ischar(varargin{idx})
                        useDefaultsFlag = strcmp(varargin{idx},'Fs') || ...
                            strcmp(varargin{idx},'FrequencyRange') || ...
                            strcmp(varargin{idx},'FrequencyVector');
                    end
                    if useDefaultsFlag
                        break
                    end
                end
            end
            if useDefaultsFlag
                hfvt = fvtool(obj.pCascadeFilter,varargin{:});
            else
                if length(obj.pFCICNulls)>1
                    fLimit = obj.pFCICNulls(2);
                else
                    fLimit = obj.pFCICNulls(end);
                end
                hfvt = fvtool(obj.pCascadeFilter,...
                    'FrequencyRange','Specify freq. vector', ...
                    'FrequencyVector',linspace(0,fLimit,2048),...
                    'Fs', Fs);
            end
            addMask(obj,cascadeGain,hfvt);
        end
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            
            s.CICFilterSysObj = matlab.System.saveObject(obj.CICFilterSysObj);
            s.CICCompFilterSysObj = matlab.System.saveObject(obj.CICCompFilterSysObj);
            s.GainFilter = obj.GainFilter;
            s.pCascadeFilterStopbandFrequency = obj.pCascadeFilterStopbandFrequency;
            s.pM1 = obj.pM1;
            s.pM2 = obj.pM2;
            s.pM3 = obj.pM3;
            s.pFsStage1 = obj.pFsStage1;
            s.pFsStage2 = obj.pFsStage2;
            s.pFstopStage2 = obj.pFstopStage2;
            s.pFsStage3 = obj.pFsStage3;
            s.pNumMagRespMeasPoints = obj.pNumMagRespMeasPoints;
            s.pFCICNulls = obj.pFCICNulls;
            s.pStopbandAttenuationStep = obj.pStopbandAttenuationStep;
            s.pPassBandRippleReductionFactor = obj.pPassBandRippleReductionFactor;
            s.pCICFilter = obj.pCICFilter;
            s.pGainFilter = obj.pGainFilter;
            s.pCICCompFilter = obj.pCICCompFilter;
            s.pCascadeFilter = obj.pCascadeFilter;
            s.pPassbandFrequency = obj.pPassbandFrequency;
        end
        
        %------------------------------------------------------------------------
        function loadSubObjects(obj,s,~)
            
            obj.CICFilterSysObj = matlab.System.loadObject(s.CICFilterSysObj);
            obj.CICCompFilterSysObj = matlab.System.loadObject(s.CICCompFilterSysObj);
            obj.GainFilter = s.GainFilter;
            obj.pCascadeFilterStopbandFrequency = s.pCascadeFilterStopbandFrequency;
            obj.pM1 = s.pM1;
            obj.pM2 = s.pM2;
            obj.pM3 = s.pM3;
            obj.pFsStage1 = s.pFsStage1;
            obj.pFsStage2 = s.pFsStage2;
            obj.pFstopStage2 = s.pFstopStage2;
            obj.pFsStage3 = s.pFsStage3;
            obj.pNumMagRespMeasPoints = s.pNumMagRespMeasPoints;
            obj.pFCICNulls = s.pFCICNulls;
            obj.pStopbandAttenuationStep = s.pStopbandAttenuationStep;
            obj.pPassBandRippleReductionFactor = s.pPassBandRippleReductionFactor;
            obj.pCICFilter = s.pCICFilter;
            obj.pGainFilter = s.pGainFilter;
            obj.pCICCompFilter = s.pCICCompFilter;
            obj.pCascadeFilter = s.pCascadeFilter;
        end
    end
    
    %----------------------------------------------------------------------
    % Static methods
    %----------------------------------------------------------------------
    methods (Static, Hidden)
        function coeffs = getCICFIRCoefficients(N,Fac)
            % Design an FIR filter with a CIC response using a cascade of
            % boxcar filters. 
            % N is the number of sections. 
            % Fac is the factor (decimation or interpolation)
            
            x = ones(1,Fac);
            c = x;
            for idx = 1:(N-1)
                c = conv(c,x);
            end
            coeffs = c;
        end
        
        %------------------------------------------------------------------
        function  [coeffs,N] = getMinOrderCICFIRCoefficients(Fac,Fs, ...
                pPassbandFrequency, StopbandAttenuation)
            % Design a minimum order FIR filter with a CIC response using a cascade
            % of boxcar filters.
            % Fac is the (decimation or interpolation) factor
            fp = (pPassbandFrequency)/(Fs/2);
            fo = cicnulls(Fac,1);
            fAI = fo(1)-fp;
            num = log(abs(10^(StopbandAttenuation/20)));
            den = log(abs((sin(pi*Fac*1*fAI/2)/sin(pi*fAI/2))/(1*Fac)));
            N = ceil(abs(num/den));
            
            coeffs = dsp.internal.ConverterFilterDesignerBase.getCICFIRCoefficients(N,Fac);
        end
        
        %------------------------------------------------------------------
        function fVect = setSectionFactors(M)
            % Decide on values for interpolation/decimation factors for
            % each stage
            
            fVect = zeros(3,1);
            Fac = factor(M);
            L = length(Fac);
            twoIdx = (Fac==2);
            twoIdxLength = nnz(twoIdx);
            if twoIdxLength > 2
                fVect(2) = 2;
                fVect(3) = 2;
                Fac(twoIdx(1:2)) = [];
                fVect(1) = prod(Fac);
            elseif twoIdxLength == 2
                if L == 2
                    fVect(1) = 2;
                    fVect(2) = 2;
                    fVect(3) = 1;
                else
                    Fac(twoIdx) = [];
                    fVect(1) = prod(Fac);
                    fVect(2) = 2;
                    fVect(3) = 2;
                end
            elseif twoIdxLength == 1
                if L == 1
                    fVect(1) = 2;
                    fVect(2) = 1;
                    fVect(3) = 1;
                elseif L == 2
                    Fac(twoIdx) = [];
                    fVect(1) = Fac;
                    fVect(2) = 2;
                    fVect(3) = 1;
                elseif L > 2
                    Fac(twoIdx) = [];
                    [fVect(2), minIdx] = min(Fac);
                    Fac(minIdx) = [];
                    fVect(1) = prod(Fac);
                    fVect(3) = 2;
                end
            else %(no twos found)
                if L == 1
                    fVect(1) = Fac;
                    fVect(2) = 1;
                    fVect(3) = 1;
                else
                    [fVect(2), minIdx] = min(Fac);
                    Fac(minIdx) = [];
                    fVect(1) = prod(Fac);
                    fVect(3) = 1;
                end
            end
        end
        
        %------------------------------------------------------------------------
        function atten = measureAttenuation(magResp,FVect,cascadeGain,interval)
            % Measure attenuation in a specified interval of frequencies.
            % Input magResp is the magnitude response computed at frequencies in
            % FVect vector. Input cascadeGain is the gain of the passband. Input
            % interval is a 1x2 vector containing the frequency points of interest.
            
            idx = (FVect >= interval(1)) & (FVect<= interval(2));
            if isempty(find(idx==1, 1))
                % No measurement points available since band of interest is smaller
                % than measurement resolution or has a width of 0 Hz (if interval(1)
                % equals interval(2))
                atten = [];
            else
                stopbandMagResp = magResp(idx);
                maxValue = max(stopbandMagResp);
                atten = cascadeGain - maxValue(1);
            end
        end
        %------------------------------------------------------------------------
        function [equiRipple, ripple] = measurePassbandRipple(magResp,FVect,cascadeGain, ...
                pPassbandFrequency)
            % Measure ripple in the passband.
            % Input magResp is the magnitude response computed at frequencies in
            % FVect vector. Input cascadeGain is the gain of the passband.
            
            idx = FVect <= pPassbandFrequency;
            passbandMagResp = magResp(idx);
            equiRipple = zeros(2,1);
            equiRipple(1) = max(passbandMagResp) - cascadeGain;
            equiRipple(2) = cascadeGain - min(passbandMagResp);
            ripple = abs(max(max(passbandMagResp),cascadeGain) - ...
                min(min(passbandMagResp),cascadeGain));
        end
        %------------------------------------------------------------------------
        function attenFactor = centerRipple(magResp,FVect,cascadeGain, ...
                pPassbandFrequency)
            idx = FVect <= pPassbandFrequency;
            passbandMagResp = magResp(idx);
            
            minValue = min(passbandMagResp);
            maxValue = max(passbandMagResp);
            centerValue = minValue(1) + (maxValue(1)-minValue(1))/2;
            %[~, centerIdx] = min(abs(centerValue - passbandMagResp));
            %attenFactor = cascadeGain - passbandMagResp(centerIdx(1));
            attenFactor = cascadeGain - centerValue;
            attenFactor = 10^(attenFactor/20);
        end
    end
    
    methods (Hidden)
        
        %------------------------------------------------------------------
        function addMask(obj,cascadeGain,hfvt)
            % Draw mask and add quantized filter response of cascade
            
            %Draw mask only for cases where the filter designer object designs the
            %filters.
            if strcmp(hfvt.FrequencyRange,'Specify freq. vector')
                [~,freqScale,~] = engunits(hfvt.FrequencyVector);
            else
                [~,freqScale,~] = engunits(hfvt.Fs);
            end
            axParams = get(hfvt.CurrentAxes);
            xLim = axParams.XLim/freqScale;
            yLim = axParams.YLim;
            
            a1 = yLim(1)-20;
            p = obj.pPassbandFrequency;
            s =  obj.pCascadeFilterStopbandFrequency;
            if obj.MinimumOrderDesign
                r1 = cascadeGain + obj.PassbandRipple/2;
                r2 = cascadeGain - obj.PassbandRipple/2;
                a = cascadeGain -obj.StopbandAttenuation;
                maskMagnitudes =  [r1 r1 r2 r2  NaN r2  a NaN r2 r2 a1 NaN a a NaN a  a]' ;
                maskFrequencies = [0  p  p  0   p   p   p  p   p  s  s  s  s p  s  s xLim(2)]*freqScale;
            else
                r = cascadeGain;
                maskMagnitudes =  [r  r a1 NaN a1 r r]' ;
                maskFrequencies = [0  p  p  s  s  s p]*freqScale;
            end
            
            % Do not allow mask frequencies to be greater than xLim(2) or FVtool
            % will issue a warning.
            outOfLimitIdx = maskFrequencies > (xLim(2)*freqScale);
            if any(outOfLimitIdx)
                maskFrequencies(outOfLimitIdx) = NaN;
            end
            
            fv = siggetappdata(hfvt, 'fvtool','handle');
            mask = dspdata.masklineMCOS;
            mask.NormalizedFrequency = false;
            mask.EnableMask = true;
            mask.MagnitudeVector = maskMagnitudes;
            mask.FrequencyVector = maskFrequencies;
            fv.UserDefinedMask = mask;
        end
    end
end
