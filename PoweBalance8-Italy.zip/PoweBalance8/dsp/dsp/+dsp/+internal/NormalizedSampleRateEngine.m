classdef NormalizedSampleRateEngine < matlab.System
% Class encapsulates sample rate specification behavior (block may specify
% sample rate on dialog, use normalized frequencies or derive it based on
% input specifications).

% Copyright 2022 The MathWorks, Inc.

    %#codegen
    %#ok<*EMCLS>
    
    properties (Nontunable)
        % SampleRateMode Sample rate mode
        %   Specify the Sample rate mode as one of 'Specify on dialog' |
        %   'Inherit from input port' | 'Use normalized frequency (0 to
        %   1)'. The default is 'Specify on dialog'.
        SampleRateMode (1, :) char {matlab.system.mustBeMemberMessageID(SampleRateMode,...
            {'dsp:system:AbstractSampleRateEngine:SampleRateMode_SpecifyOnDialog';...
            'dsp:system:AbstractSampleRateEngine:SampleRateMode_InheritFromInputPort';...
            'dsp:system:AbstractSampleRateEngine:SampleRateMode_UseNormalizedFrequency'})} = 'Specify on dialog';
 
        % NormalizedFrequency
        %   Provide normalized frequencies for filter specifications
        NormalizedFrequency (1,1) logical = false;
    end

    methods
        function set.NormalizedFrequency(obj,val)
            obj.NormalizedFrequency = val;
        end
        function set.SampleRateMode(obj,val)
            obj.SampleRateMode = val;
        end
    end

    methods (Access = protected, Abstract)
       % Property cross-validation. This method must be defined by child
       % classes. It is called in setupImpl. Cross-property validation that
       % depends on SampleRate cannot be put in validatePropertiesImpl,
       % because the value of SampleRate is not yet available there for the
       % block.
       crossValidateProperties(obj)  
    end
    
    % Protected access (self) plus allow Property or Input class to call
    methods (Access = protected)       
        function Fs = getInheritedSampleRate(obj)
            % This function is used to derive the sample rate from input
            % port specifications. It applies only to the block.
            
            sts = getSampleTime(obj);
            ts = sts.SampleTime;
            thisSize = propagatedInputSize(obj, 1);
            if isempty(thisSize)
                Fs = -1;
                return;
            end
            
            coder.internal.errorIf(disallowContinuousSampleTime(obj) && ts==0,...
                'dsp:system:Shared:ContinuousTimeNotAllowed');
            
            if isSampleRateInherited(obj)
                % Do not allow constant time if sample rate is inherited
                coder.internal.errorIf(isinf(ts),...
                    'dsp:system:AbstractSampleRateEngine:SampleTimeMustBeDiscrete');
                % Cannot inherit sample rate in triggered or asynchronous subsystems
                coder.internal.errorIf(ts < 0,...
                    'dsp:system:AbstractSampleRateEngine:TriggeredSubsystemNotSupported');
            end
            
            N = thisSize(1);
            Fs = N/ts;
            
        end
        
    end
        
    methods (Access = protected)
        
        function flag = disallowContinuousSampleTime(~)
            % Blocks inheriting from this class should overload this method
            % to allow continuous time
            flag = true;
        end
        
        function flag = isSampleRateInherited(obj)
            % Variable-size signals are not allowed if the sample rate is
            % inherited
            flag =  strcmp(obj.SampleRateMode,'Inherit from input port');
        end
        
        function flag = isInputSizeMutableImpl(obj,~)
            % Varsize signals not allowed when sample rate is inherited
            flag = ~isSampleRateInherited(obj);
        end

        function sts = getSampleTimeImpl(obj)
            if isSampleRateInherited(obj)
                % If sample rate is inherited, there is no way to deduce it
                % if the input sample rate is constant. Error out
                mode = 'Error';
            else
                % Object has discrete state. Disallow constant sample rate. 
                mode = 'Disallow';
            end
            
            sts = createSampleTime(obj, 'Type', 'Inherited', ...
                                   mode, 'Constant');
        end
          
        function numchans = getNumChannels(obj,u)
            % GETNUMCHANNELS Return the number of input channels
            if obj.getExecPlatformIndex()
                thisSize = propagatedInputSize(obj, 1);
                numchans = thisSize(2);
            else
                numchans = size(u,2);
            end
        end

         function setupImpl(obj,varargin)
            
             % Get the number of input channels
             numchans = getNumChannels(obj,varargin{1});
             % Disallow a first step with zero channels
             coder.internal.errorIf(numchans == 0,'dsp:system:Shared:EmptyFirstStep');
             
             dsp.internal.checkSampleTime(obj);
             
             crossValidateProperties(obj);
         end
         
         function processTunedPropertiesImpl(obj)
             crossValidateProperties(obj);
         end
    end
    methods (Hidden)
         function flag = isSampleRateOnDialog(obj)
             flag = strcmp(obj.SampleRateMode,'Specify on dialog');
         end
         function flag = isSampleRateNormalized(obj)
             flag = strcmp(obj.SampleRateMode,'Use normalized frequency (0 to 1)');
         end

         function freqUnits = getFrequencyUnits(obj)
             if isSampleRateNormalized(obj) || obj.NormalizedFrequency
                freqUnits = '';
             else
                freqUnits = 'Hz';
             end
         end
         
   end
 
end
