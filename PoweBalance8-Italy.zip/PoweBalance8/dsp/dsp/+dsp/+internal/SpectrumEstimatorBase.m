classdef SpectrumEstimatorBase < dsp.internal.SampleRateEngine
%SpectrumEstimatorBase Abstract base class for spectrum estimation
%   dsp.spectrumEstimator and dsp.CrossSpectrumEstimator inherit from this 
%   base class.  

%   Copyright 2013-2021 The MathWorks, Inc.

%#codegen
%#ok<*EMCLS>
  
properties (Constant, Hidden)
    % SampleTimeSet is used to setup the choices for Sample Time
    SampleRateSet = matlab.system.SourceSet({'PropertyOrMethod', ...
        'SystemBlock', 'InheritSampleRate', 'getInheritedSampleRate',true});
end

properties (Nontunable)
    %SampleRate Input sample rate (Hz)
    %   Specify the sampling rate of the input in Hertz as a finite
    %   numeric scalar. the default is 1 Hz.
    SampleRate = 1;
end

properties (Nontunable)
  %FFTLengthSource Source of the FFT length value
  %   Specify the source of the FFT length value as one of 'Auto' |
  %   'Property'. The default is 'Auto'. When you set this property to
  %   'Auto' the Spectrum Estimator sets the FFT length to the input frame
  %   size. When you set this property to 'Property' then you specify the 
  %   number of FFT points using the FFTLength property.
  FFTLengthSource (1, :) char {matlab.system.mustBeMemberMessageID(FFTLengthSource, ...
      {'dsp:system:SpectrumEstimatorBase:FFTLengthSource_Auto'; ...
      'dsp:system:SpectrumEstimatorBase:FFTLengthSource_Property'})} = 'Auto';
  %FFTLength FFT length
  %   Specify the length of the FFT that the Spectrum Estimator uses to
  %   compute spectral estimates as a positive, integer scalar. This
  %   property applies when you set the FFTLengthSource property to
  %   'Property'. The default is 128.
  FFTLength = 128;
  %Window Window function
  %   Specify a window function for the spectral estimator as one of
  %   'Rectangular' | 'Chebyshev' | 'Flat Top' | 'Hamming' | 'Hann' |
  %   'Kaiser'. The default is 'Hann'.
  Window (1, :) char {matlab.system.mustBeMemberMessageID(Window, ...
      {'dsp:system:SpectrumEstimatorBase:Window_Chebyshev'; ...
      'dsp:system:SpectrumEstimatorBase:Window_FlatTop'; ...
      'dsp:system:SpectrumEstimatorBase:Window_Hamming'; ...
      'dsp:system:SpectrumEstimatorBase:Window_Hann'; ...
      'dsp:system:SpectrumEstimatorBase:Window_Kaiser'; ...
      'dsp:system:SpectrumEstimatorBase:Window_Rectangular'})} = 'Hann';
  %SidelobeAttenuation Sidelobe attenuation of window (dB)
  %   Specify the sidelobe attenuation of the window as a real, positive
  %   scalar in decibels (dB). This property applies when you set the 
  %   Window property to 'Chebyshev' or 'Kaiser'. The default is 60 dB.
  SidelobeAttenuation = 60;
  %FrequencyRange Frequency range of the spectrum estimate
  %   Specify the frequency range of the spectrum estimator as one 
  %   of 'twosided' | 'onesided' | 'centered'. 
  %   If you set the FrequencyRange to 'onesided', the spectrum estimator 
  %   computes the one-sided spectrum of real input signals. When the FFT 
  %   length, NFFT, is even, the spectrum estimate length is NFFT/2+1 and 
  %   is computed over the interval [0,SampleRate/2]. If NFFT is odd, the 
  %   length of the spectrum estimate is equal to (NFFT+1)/2 and the 
  %   interval is [0,SampleRate/2).
  %   If you set the FrequencyRange to 'twosided', the spectrum estimate
  %   computes the two-sided spectrum of complex or real inputs signals. 
  %   The length of the spectrum estimate is equal to NFFT and is computed 
  %   over [0, SampleRate). 
  %   If you set the FrequencyRange to 'centered', the spectrum estimate 
  %   computes the centered two-sided spectrum of complex or real 
  %   input signals. The length of the spectrum estimate is equal to NFFT 
  %   and is computed over (-SampleRate/2, SampleRate/2] and 
  %   (-SampleRate/2, SampleRate/2) for even and odd length NFFT, 
  %   respectively. 
  %   The default is 'twosided'
  FrequencyRange (1, :) char {matlab.system.mustBeMemberMessageID(FrequencyRange, ...
      {'dsp:system:SpectrumEstimatorBase:FrequencyRange_centered'; ...
      'dsp:system:SpectrumEstimatorBase:FrequencyRange_onesided'; ...
      'dsp:system:SpectrumEstimatorBase:FrequencyRange_twosided'})} = 'twosided';
  %AveragingMethod Averaging method
  %   Specify the averaging method as 'Running' or 'Exponential'. In the
  %   running averaging method, the object computes an equally weighted
  %   average of a specified number of spectrum estimates defined by the
  %   'SpectralAverages' property. In the exponential method, the object
  %   computes the average over samples weighted by an exponentially
  %   decaying forgetting factor. The default is 'Running'.
  AveragingMethod (1, :) char {matlab.system.mustBeMemberMessageID(AveragingMethod, ...
      {'dsp:system:SpectrumEstimatorBase:AveragingMethod_Running'; ...
      'dsp:system:SpectrumEstimatorBase:AveragingMethod_Exponential'})} = 'Running';
  %SpectralAverages Number of spectral averages
  %   Specify the number of spectral averages as a positive, integer
  %   scalar. The Spectrum Estimator computes the current power spectrum
  %   estimate by averaging the last N power spectrum estimates, where N is
  %   the number of spectral averages defined in the SpectralAverages
  %   property. This property applies when 'AveragingMethod' is equal to
  %   'Running'. The default is 8.
  SpectralAverages = 8;
end

properties
  %ForgettingFactor Forgetting factor
  %   Specify the exponential weighting forgetting factor as a scalar value
  %   greater than zero and smaller than or equal to one. This property
  %   applies when 'AveragingMethod' is equal to 'Exponential'. The default
  %   is 0.9. This property is tunable.
  ForgettingFactor = 0.9; 
end

properties (Access = protected)
  %pPeriodogramMatrix 3D matrix containing the last SpectralAverages
  %periodograms in each column. The third dimension contains matrices for
  %each input channel. So pPeriodogramMatrix(:,:,i) contains the
  %periodograms for the i-th channel.
  pPeriodogramMatrix;
  % Cache cast forgetting factor
  pForgettingFactor;
  %pPreviousAvgSpectrum 2D matrix containing the last exponential average
  %computed for each channel.
  pPreviousAvgSpectrum;
  %pPreviousWeight scalar containing the previous weight used exponential
  %averaging
  pPreviousWeight;
  pENBWFactor
end

properties (Access = protected,Nontunable)
  %pNFFT Actual FFT length
  pNFFT
end

properties (Access = private)
  %pW Pre-computed frequency vector
  pW;
end

properties (Access = private)
  %pWindowData Pre-computed window vector
  pWindowData;
  %pWindowPower Pre-computed window power
  pWindowPower;
  %pNumAvgsCounter Counter that counts number of averages and saturates
  %when its value reaches SpectralAverages. This counter is used to avoid
  %averaging initial all zero periodograms.
  pNumAvgsCounter;
  %pNewPeriodogramIdx Index for newer periodogram column in the
  %pPeriodogramMatrix
  pNewPeriodogramIdx;
  %pRBW Pre-computed RBW
  pRBW;
end

properties (Access = private, Nontunable)
  % When true, no input wrapping is required
  % When false, input wrapping is required (FFT length < segment length)
  pNoWrapRequired (1, 1) logical
  % pSegmentLength Segment length, equal to the input frame length
  pSegmentLength;
  % pNumChannels Number of input channels
  pNumChannels;
  % pDatatype Input datatype
  pDatatype;
  % pInit Flag set to one when object is locked. Used in getRBW and
  % getFrequencyVector to disallow usage for unlocked object in code
  % generation
  pInit = 0
  % pSpectralAverages Cast SpectralAverages to input datatype
  pSpectralAverages
end
%--------------------------------------------------------------------------
% Abstract methods
%--------------------------------------------------------------------------
methods (Abstract, Access = protected)
  % Abstract method. Children objects redefine this method. 
  P = computeWindowFFT(~,~)
  initializeSpectrumCache(~);
  P = convertAndScale(~,~);
end

%--------------------------------------------------------------------------
% Public methods
%--------------------------------------------------------------------------
methods
  function obj = SpectrumEstimatorBase(varargin)
    %SpectrumEstimatorBase   Construct the SpectrumEstimatorBase class. 
    setProperties(obj, nargin, varargin{:});
  end

  function set.SampleRate(obj,val)
      validateattributes(val,...
          {'double','single'}, ...
          {'real','scalar','positive','finite'},...
          '','SampleRate');
      obj.SampleRate = val;
  end
    
  function set.SpectralAverages(obj,value)
    % Set the number of spectral averages. Positive scalar integer. 
    validateattributes(value,{'double'}, {'real','positive','scalar',...
                      'integer'},'','SpectralAverages');
    obj.SpectralAverages = value;
  end
  
  function set.SidelobeAttenuation(obj,value)
    % Set the Window sidelobe attenuation. Positive real scalar. 
    validateattributes(value,{'double'}, {'real','positive','scalar'},...
                              '','SidelobeAttenuation');
    obj.SidelobeAttenuation = value;
  end
  
  function set.FFTLength(obj,value)
    % Set the FFT length. Positive real scalar. 
    % Set the number of spectral averages. Positive scalar integer. 
    validateattributes(value,{'double'}, {'real','positive','scalar',...
                      'integer','>',1},'','FFTLength');
    obj.FFTLength = value;
  end
  
  function set.ForgettingFactor(obj, val)
    validateForgettingFactor(obj, val);  
    obj.ForgettingFactor = val;
  end
end

%--------------------------------------------------------------------------
% Public methods to get RBW and Frequency Vector
%--------------------------------------------------------------------------
methods
  function RBW = getRBW(obj,varargin)
    % getRBW Get the resolution bandwidth of the Spectrum, in Hz. 
    %   The resolution bandwidth, RBW, is the smallest positive frequency, 
    %   or frequency interval, that can be resolved. It is equal to 
    %   ENBW * SampleRate/ L, where L is the input length, and ENBW is the
    %   two-sided equivalent noise bandwidth of the window (in Hz). For
    %   example, if SampleRate = 100, L = 1024, and Window = 'Hann', 
    %   RBW =  enbw(hann(1024)) * 100 / 1024
    
    narginchk(1,2);
    % Throw compile-time error if function is called before locking object
    coder.internal.errorIf(obj.pInit==0,...
        'dsp:system:SpectrumEstimatorBase:NotLockedYet','getRBW');
    % Disallow usage if object was locked and then released
    coder.internal.errorIf(~isLocked(obj),...
        'dsp:system:SpectrumEstimatorBase:NotLockedYet','getRBW');
    
    if (nargin==1)
        RBW = obj.pRBW;
    else
        % Use input sample rate
        Fs = varargin{1};
        validateattributes(Fs,{'double','single'},{'real','scalar','positive','finite'},'getRBW','SampleRate',2);
        RBW = computeRBW(obj,Fs);
    end


  end
  
  function w = getFrequencyVector(obj,varargin)
   % getFrequencyVector Get the vector of frequencies at which the spectrum 
   %   is estimated, in Hz. 
   %   If you set the FrequencyRange to 'onesided' and the FFT length, 
   %   NFFT, is even, the frequency vector is of length NFFT/2+1 and it 
   %   covers the interval [0,SampleRate/2]. If you set the FrequencyRange 
   %   to 'onesided' and NFFT is odd, the frequency vector is of length 
   %   (NFFT+1)/2 and it covers the interval [0,SampleRate/2).
   %   If you set the FrequencyRange to 'twosided', the frequency vector is 
   %   of length NFFT and it covers the interval [0, SampleRate). 
   %   If you set the FrequencyRange to 'centered', the frequency vector is 
   %   of length NFFT and it covers the range (-SampleRate/2, SampleRate/2] 
   %   for even length NFFT, and (-SampleRate/2, SampleRate/2) for odd 
   %   length NFFT.
    
   narginchk(1,2);
   % Throw compile-time error if function is called before locking object
   coder.internal.errorIf(obj.pInit==0,...
        'dsp:system:SpectrumEstimatorBase:NotLockedYet','getFrequencyVector');
   % Disallow usage if object was locked and then released
   coder.internal.errorIf(~isLocked(obj),...
        'dsp:system:SpectrumEstimatorBase:NotLockedYet','getFrequencyVector');
    
   if (nargin==1)
       w0 = obj.pW;
   else
       % Use input sample rate
       isOneSided =  strcmp(obj.FrequencyRange,'onesided');
       Npts = obj.pNFFT;
       Fs = varargin{1};
       validateattributes(Fs,{'double','single'},{'real','scalar','positive','finite'},'getFrequencyVector','SampleRate',2);
       pCenterDC = strcmp(obj.FrequencyRange,'centered');
       w0 = dsp.internal.SpectrumEstimatorBase.frequencygrid...
           (isOneSided,Npts,Fs,pCenterDC);
   end
   w = cast(w0,obj.pDatatype);
  end
end
%--------------------------------------------------------------------------
% Protected methods
%--------------------------------------------------------------------------
methods(Access = protected)
    function validateForgettingFactor(~,val)
        validateattributes(val,...
            {'double','single'},...
            {'real','scalar','finite','>=',0,'<=',1},...
            '','ForgettingFactor');
    end

  function num = getNumOutputsImpl(~)
    num = 1;
  end

  function flag = isInputSizeMutableImpl(~,varargin)
    % The segment length depends on the input frame size, so variable-size
    % inputs are not allowed. 
    flag = false;
  end
  
  function  resetImpl(obj)
    % Reset the running average counter and index
    obj.pNumAvgsCounter = cast(0,getDatatype(obj));
    obj.pNewPeriodogramIdx = cast(0,getDatatype(obj));
    % Reset the exponential averaging previous weight and previous estimate
    obj.pPreviousWeight = cast(0,getDatatype(obj));
    % Initialize matrices that hold the running spectrum 
    initializeSpectrumCache(obj);
  end

  function validateInputsImpl(obj,x)
      
    if size(x,1)<=1
       matlab.system.internal.error(...
       'dsp:system:SpectrumEstimatorBase:ScalarInput');
    end
    
    % Complex input is not allowed for one-sided spectrum estimation
    if strcmp(obj.FrequencyRange,'onesided') && ~isreal(x)
       matlab.system.internal.error(...
       'dsp:system:SpectrumEstimatorBase:InvalidSpectrumType');
    end
    validateattributes(x,{'double','single'}, {'2d',...
                      'nonsparse'},'','x');
                  
  end
  
  function flag = isInputComplexityMutableImpl(~,~) 
    flag = false; 
  end
  
  function flag = isInactivePropertyImpl(obj, prop)
    flag = isInactivePropertyImpl@dsp.internal.SampleRateEngine(obj, prop);
    switch prop
        case 'SidelobeAttenuation'
            flag = ~strcmp('Chebyshev',obj.Window) && ...
                   ~strcmp('Kaiser',obj.Window);
        case 'FFTLength'
            flag = strcmp(obj.FFTLengthSource,'Auto');
        case 'ForgettingFactor'
            flag = strcmp(obj.AveragingMethod, 'Running');
        case 'SpectralAverages'
            flag = strcmp(obj.AveragingMethod, 'Exponential');
    end
  end
  
  function flag = fixFFTLength(~)
     % Some objects inheriting from this class may wish to fix an FFTLength
     % that is too short
     flag = false;
  end
  
  function setupImpl(obj, x , varargin)
    % Get the segment length and the number of channels from the input. 
     
    setupImpl@dsp.internal.SampleRateEngine(obj,x);
    
    obj.pSegmentLength = size(x,1);
    obj.pNumChannels = size(x,2);
    obj.pDatatype = class(x);
    if isRunningAverage(obj)
        obj.pSpectralAverages = cast(obj.SpectralAverages,obj.pDatatype);
    else
        obj.pForgettingFactor = cast(obj.ForgettingFactor,obj.pDatatype);
    end
    % Set the window parameters
    switch obj.Window
        case 'Rectangular'
            windowType = 1;
        case 'Hann'
            windowType = 2;
        case 'Hamming'
            windowType = 3;
        case  'Flat Top'
            windowType = 4;
        case 'Chebyshev'
            windowType = 5;
        otherwise % case  'Kaiser'
            windowType = 6;
    end
    
    coder.extrinsic('dsp.internal.designWindow');
    L = obj.pSegmentLength;
    obj.pWindowData =  coder.const(@dsp.internal.designWindow , windowType , L, class(x) , obj.SidelobeAttenuation);
     % Compute window power and store it in pWindowPower property
    obj.pWindowPower = obj.pWindowData.'*obj.pWindowData;
    ENBW = (sum(obj.pWindowData.^2)/sum(obj.pWindowData)^2)*cast(L , obj.pDatatype);
    obj.pENBWFactor = ENBW / cast(L , obj.pDatatype);
    % Compute the RBW and store it in pRBW property
    obj.pRBW = ENBW * cast(getSampleRate(obj), obj.pDatatype )/ cast(L , obj.pDatatype);

    % Set the actual FFT length.
    % when FFTLengthSource is auto, use segment length as FFT
    % length. Otherwise, use value in FFTLength property.
    if strcmp(obj.FFTLengthSource,'Auto')
        if obj.fixFFTLength
            nfft = max(1024,obj.pSegmentLength);
        else
            nfft =  obj.pSegmentLength;
        end
        obj.pNFFT = nfft;
    else
        obj.pNFFT = obj.FFTLength;
    end
    
    obj.pNoWrapRequired = obj.pNFFT >= size(x,1);

    % Pre-compute the frequency vector
    Fs = cast(getSampleRate(obj),obj.pDatatype);
    Npts = obj.pNFFT;
    
    coder.extrinsic('dsp.internal.SpectrumEstimatorBase.computeFrequencyVector');
    CenterDC = strcmp(obj.FrequencyRange,'centered');
    isOneSided =  strcmp(obj.FrequencyRange,'onesided');
    %obj.pW =  coder.const(@obj.computeFrequencyVector , CenterDC ,isOneSided ,  Fs , Npts , class(x));
    obj.pW =  Fs * coder.const(@obj.computeFrequencyVector , CenterDC ,isOneSided ,  cast(1,obj.pDatatype) , Npts , class(x));
    % Flag indicates object is locked         
    obj.pInit = 1;
    obj.pNumAvgsCounter = cast(0,obj.pDatatype);
    obj.pNewPeriodogramIdx = cast(0,obj.pDatatype);
  end
  
  function P = stepImpl(obj, varargin)
    P = computeOutput(obj, varargin{:}); 
  end
  
  function processTunedPropertiesImpl(obj)
      if ~isRunningAverage(obj)
          obj.pForgettingFactor = cast(obj.ForgettingFactor,getDatatype(obj));
      end
  end

  
  function P = computeOutput(obj, varargin) 
    % Compute periodogram of new segment
    P = computeWindowFFT(obj,varargin{:})/obj.pWindowPower;
    if isRunningAverage(obj)
       % Update the running average matrix
       updatePeriodogramMatrix(obj,P);
       % Get the current average
       P = getPeriodogramMatrixAverage(obj);
    else
       % Get the current exponential average 
       P = getExponentialAverage(obj, P);
    end
    % Convert and scale
    P = convertAndScale(obj,P);
  end

  function crossValidateProperties(~)
      
  end
  
  function s = saveObjectImpl(obj)
     s = saveObjectImpl@dsp.internal.SampleRateEngine(obj);
     if isLocked(obj)
        s.pWindowData = obj.pWindowData;
        s.pWindowPower = obj.pWindowPower;
        s.pW = obj.pW;
        s.pNumAvgsCounter = obj.pNumAvgsCounter;
        s.pNewPeriodogramIdx = obj.pNewPeriodogramIdx;
        s.pPeriodogramMatrix = obj.pPeriodogramMatrix;
        s.pPreviousAvgSpectrum = obj.pPreviousAvgSpectrum;
        s.pForgettingFactor = obj.pForgettingFactor;
        s.pPreviousWeight = obj.pPreviousWeight;
        s.pRBW = obj.pRBW;
        s.pNFFT = obj.pNFFT;
        s.pSegmentLength = obj.pSegmentLength;
        s.pNumChannels = obj.pNumChannels;
        s.pDatatype    = obj.pDatatype;
        s.pInit        = obj.pInit;
        s.pENBWFactor  = obj.pENBWFactor;
        s.pNoWrapRequired   = obj.pNoWrapRequired;
        s.pSpectralAverages  = obj.pSpectralAverages;
     end 
  end
  
  function loadObjectImpl(obj, s, wasLocked)
     if wasLocked
        obj.pWindowData = s.pWindowData;
        obj.pWindowPower = s.pWindowPower;
        obj.pW = s.pW;
        obj.pNumAvgsCounter = s.pNumAvgsCounter;
        obj.pNewPeriodogramIdx = s.pNewPeriodogramIdx;
        obj.pPeriodogramMatrix = s.pPeriodogramMatrix;
        if isfield(s,'pPreviousAvgSpectrum')
            % New in 19a
            obj.pPreviousAvgSpectrum = s.pPreviousAvgSpectrum;
        end
        if isfield(s,'pForgettingFactor')
            % New in 19a
            obj.pForgettingFactor = s.pForgettingFactor;
        end
        if isfield(s,'pPreviousWeight')
            % New in 19a
            obj.pPreviousWeight = s.pPreviousWeight;
        end
        obj.pRBW = s.pRBW;
        obj.pNFFT = s.pNFFT;
        obj.pSegmentLength = s.pSegmentLength;
        obj.pNumChannels = s.pNumChannels;
        obj.pDatatype    = s.pDatatype;
        obj.pInit        = s.pInit;
        obj.pENBWFactor  = s.pENBWFactor;
        if isfield(s,'pNoWrapRequired')
            % New in R2017b
            obj.pNoWrapRequired      = s.pNoWrapRequired;
        else
            obj.pNoWrapRequired   = true;
        end
        
        if isfield(s,'pSpectralAverages')
            % New in R2017b
            obj.pSpectralAverages      = s.pSpectralAverages;
        else
            obj.pSpectralAverages      = obj.SpectralAverages;
        end
     end
      loadObjectImpl@dsp.internal.SampleRateEngine(obj, s, wasLocked);
  end
   
  function RBW = computeRBW(obj,Fs)
      % Use input sample rate
      w = obj.pWindowData;
      L = length(w);
      % Compute window power
      ENBW = (sum(w.^2)/sum(w)^2)*L;
      % Compute the RBW
      RBW = ENBW * Fs/ L;
  end
  
  function xout = windowData(obj,x)
    % Multiply input by the window vector
    y = bsxfun(@times,x,obj.pWindowData);
    if ~isreal(x) && isreal(y)
       xout = complex(y,0);
    else
       xout = y;
    end
  end
  
  function xout = computeFFT(obj,xin)
    % Compute FFT
    if obj.pNoWrapRequired
        xout = fft(xin,obj.pNFFT);
    else
        fftlen   = obj.pNFFT;
        [frameLen,numChans] = size(xin);
        L   = ceil(frameLen/fftlen);
        pad = L *fftlen - frameLen; 
        x = [xin ; zeros(pad,numChans,'like',xin)];
        z = reshape(x,fftlen,L,numChans);
        xout = fft(sum(z,2),fftlen);
    end
  end

  function  Pout = preConvertAndScale(obj,P)
    %convertAndScale Convert to one sided and center DC if needed, scale by
    %Fs to convert to density

    if strcmp(obj.FrequencyRange,'onesided')
        % If user specified one sided spectrum we need to call
        % computeOneSidedSpectrum to fold power values
        Pout = computeOneSidedSpectrum(obj,P);
    elseif strcmp(obj.FrequencyRange,'centered')
        % Center DC
       Pout = centerDC(obj,P);
    else
        Pout = P;
    end

  end
  
  function dt = getDatatype(obj)
      dt = obj.pDatatype;
  end
  
  function numChan = getNumberOfChannels(obj)
      numChan = obj.pNumChannels;
  end
  
  function FFTLen = getActualFFTLen(obj)
      FFTLen = obj.pNFFT;
  end
  
  function flag = disallowContinuousSampleTime(~)
      flag = false;
  end
  
  function updatePeriodogramMatrix(obj,P)
    % Do running average with previous numAverage values
    % Do not include initial zero columns on the averages
    OneCast = cast(1,obj.pDatatype);
    obj.pNumAvgsCounter = min(obj.pNumAvgsCounter+OneCast,obj.pSpectralAverages);
    obj.pNewPeriodogramIdx =  max(1,mod(obj.pNewPeriodogramIdx+1,...
                                  obj.SpectralAverages+1));
    obj.pPeriodogramMatrix(:,obj.pNewPeriodogramIdx,:) = P; 
  end
  
  function P = getPeriodogramMatrixAverage(obj)
    P = squeeze(sum(obj.pPeriodogramMatrix,2)/obj.pNumAvgsCounter);
  end
  
  function [P_N] = getExponentialAverage(obj,P)
      oneCast = cast(1,obj.pDatatype);
      lambda = obj.pForgettingFactor;
      w_N_1 = obj.pPreviousWeight;
      w_N = lambda*w_N_1 + oneCast;
      
      P_N_1 = obj.pPreviousAvgSpectrum;
      P_N = (oneCast-oneCast/w_N).*P_N_1 + (oneCast/w_N).*squeeze(P);
      obj.pPreviousWeight = w_N;
      obj.pPreviousAvgSpectrum = P_N;
  end
  
  function flag = isRunningAverage(obj)
    flag = strcmp(obj.AveragingMethod,'Running');
  end
end

%--------------------------------------------------------------------------
% Private methods
%--------------------------------------------------------------------------
methods (Access = private)
  
  function Pos = computeOneSidedSpectrum(obj,P)
    nfft = obj.pNFFT;
    if rem(nfft,2)
        select = 1:(nfft+1)/2;  % ODD
        Pos_unscaled = P(select,:); % Take only [0,pi] or [0,pi)
        % Don't double DC
        Pos = [Pos_unscaled(1,:); 2*Pos_unscaled(2:end,:)];
    else
        select = 1:nfft/2+1;    % EVEN
        Pos_unscaled = P(select,:); % Take only [0,pi] or [0,pi)
        % Don't double unique Nyquist point
        Pos = [Pos_unscaled(1,:); 2*Pos_unscaled(2:end-1,:); ...
               Pos_unscaled(end,:)];
    end
  end

  function Pdc_out = centerDC(~,P)
    % Convert to plot + and - frequencies.

    nfft = size(P,1);

    Pdc = fftshift(P,1);  % Places the Nyquist freq on the negative side.

    % Determine half the number of FFT points.
    if ~rem(nfft,2)
        % Move the Nyquist point to the right-hand side (pos freq) to be
        % consistent with plot when looking at the positive half only.
        Pdc_out = [Pdc(2:end,:); Pdc(1,:)];
    else
        Pdc_out = Pdc;
    end
  end  
  
end
%--------------------------------------------------------------------------
% Static Hidden methods
%--------------------------------------------------------------------------
methods (Static,Hidden)
  function w = frequencygrid(isOneSided,Npts,Fs,CenterDC)
    freq_res = Fs/Npts;
    w0 = freq_res*(0:Npts-1);
    % There can still be some minor round off errors in the frequency grid.  
    % Fix the known points, i.e., those near pi and 2pi.
    Nyq = Fs/2;
    half_res = freq_res/2; % half the resolution

    % Determine if Npts is odd and calculate half and quarter of Npts.
    [isNPTSodd,halfNPTS] = ...
        dsp.internal.SpectrumEstimatorBase.NPTSinfo(Npts);

    if isNPTSodd
        % Adjust points on either side of Nyquist.
        w0(halfNPTS)   = Nyq - half_res;
        w0(halfNPTS+1) = Nyq + half_res;
    else
        % Make sure we hit Nyquist exactly, i.e., pi or Fs/2 
        w0(halfNPTS) = Nyq;
    end
    w0(Npts) = Fs-freq_res;

    % Get the right grid based on range, centerdc, etc.
    w = dsp.internal.SpectrumEstimatorBase.finalgrid(w0,isOneSided,...
                CenterDC,isNPTSodd,halfNPTS);
  end
end
%--------------------------------------------------------------------------
% Private static methods
%--------------------------------------------------------------------------  
methods (Access = private, Static)
  function [isNPTSodd,halfNPTS] = NPTSinfo(NPTS)
    % Determine if we are dealing with even or odd lengths of NPTS, 1/2 
    % NPTS, and 1/4 NPTS.

    % Determine if Npts is odd.
    isNPTSodd = false;
    if rem(NPTS,2)
        isNPTSodd = true;
    end

    % Determine half the number of points.
    if isNPTSodd
        halfNPTS = (NPTS+1)/2;  % ODD
    else
        halfNPTS = (NPTS/2)+1;  % EVEN
    end

  end
  
  function wout = finalgrid(w,isOneSided,CenterDC,isNPTSodd,...
                            halfNPTS)
    % Calculate the correct grid based on user specified values for range,
    % centerdc, etc.
    if ~isOneSided
        % Calculated by default.% [0, 2pi)

        if CenterDC          % (-pi, pi] even or (-pi, pi) odd
            if isNPTSodd
                negEndPt = halfNPTS;
            else
                negEndPt = halfNPTS-1;
            end
            wtemp = [-fliplr(w(2:negEndPt)), w(1:halfNPTS)];
            wout  = wtemp(:);  % Return a column vector.
        else
            wout = w(:); % Return a column vector.
        end

    else
        w2 = w(1:halfNPTS);      % [0, pi] even or [0, pi) odd
        wout = w2(:);  % Return a column vector. 
    end
    
  end

end

methods (Access = protected)
    % Propagators
    function sz_out = getOutputSizeImpl(obj)
        
        sz_in = propagatedInputSize(obj,1);
        sz_out = sz_in;
        if(~isempty(sz_in))
            if strcmp(obj.FFTLengthSource,'Auto')
                if obj.fixFFTLength
                    NFFT = max(sz_in(1),1024);
                else
                    NFFT = sz_in(1);
                end
            else
                NFFT = obj.FFTLength;
            end
            switch obj.FrequencyRange
                case 'onesided'
                    if mod(NFFT,2)==0
                        sz_out(1) = NFFT/2 + 1;
                    else
                        sz_out(1) = (NFFT+1)/2;
                    end
                case {'twosided','centered'}
                    sz_out(1) = NFFT;
            end
        end
    end
    %--------------------------------------------------------------------
    function dt_out = getOutputDataTypeImpl(obj)
        dt_out = propagatedInputDataType(obj,1);
    end
    %----------------------------------------------------------------------
    function fsz_out = isOutputFixedSizeImpl(~)
        fsz_out = true;
    end
    %----------------------------------------------------------------------
    function flag = supportsMultipleInstanceImpl(~)
        flag = true;
    end
    %----------------------------------------------------------------------
    function Fs = getSampleRate(obj)
        Fs = obj.SampleRate;
    end
    %----------------------------------------------------------------------
    function dt = getTunablePropertiesSpecificationImpl(obj,~)
        dt = propagatedInputDataType(obj,1);
    end
end

methods (Static, Hidden)
     function F = computeFrequencyVector(pCenterDC , isOneSided,  Fs , NFFT ,DT)
       F = cast(dsp.internal.SpectrumEstimatorBase.frequencygrid...
           (isOneSided,NFFT,Fs,pCenterDC),DT);
     end     
end

end
