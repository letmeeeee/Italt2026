classdef AbstractSlidingWindowMinMaxCG < matlab.System
%  AbstractSlidingWindowMinMaxCG This class is used in dsp.MovingMinimum
%  and dsp.MovingMaximum
%
% The algorithm is based on "STREAMING MAXIMUM-MINIMUM FILTER USING NO MORE
% THAN THREE COMPARISONS PER ELEMENT" by Daniel Lemire
% Double-ended queue. 
% Top of the queue always holds max (or min) value and its corresponding
% insertion time
% New values are compared with those of the back of the queue
% All values at back of the queue lower than the new value are removed
% New value is placed at back with an expiration time
% Top of the queue is removed when it expires. 
%
% Example for max with a window of length 4. Input: [5 9 2 6 5 3 5]
% Input is 5:                     Queue is [5]
% Input is 9: 9 clobbers 5.       Queue is [9]
% Input is 2:                     Queue is [9 2]
% Input is 6: 6 clobbers 2.       Queue is [9 6]
% Input is 5:                     Queue is [9 6 5]
% Input is 3: 9 expired           Queue is [6 5 3]
% Input is 5: 5 clobbers 5 and 3. Queue is [6 5]

%   Copyright 2016-2021 The MathWorks, Inc.
   
%#codegen
%#ok<*EMCLS>
    
    properties (Nontunable)
        %WindowLength Window length
        WindowLength (1, 1) {mustBePositive, mustBeInteger} = 4;

        % Numchans Number of input channels
        NumChans = 1
    end
    
    properties (Access = protected)
        % pBuffer= Circular buffer holding the queue
        pBuffer
        % pBufferIdx Holds the insertion time of the buffer elements
        pBufferIdx
        % pNumElements Number of elements currently in the queue
        pNumElements
        % pCount Counter used to determine expiration date
        pCount
        % pTop Index of the top of the queue
        pTop
    end
    
    methods (Access = protected, Abstract)
       z = compareElements(obj,x,y) 
    end
    
    properties (Access = protected, Nontunable)
        % pDatatype Input data type
        pDatatype
    end
    
    methods
        function obj = AbstractSlidingWindowMinMaxCG(varargin)
            setProperties(obj,nargin,varargin{:});
        end
    end
    
    methods(Access = protected)
        
        function setupImpl(obj,u)
            obj.pDatatype = class(u);
        end
        
        function m = stepImpl(obj,x)
            
            buf         = obj.pBuffer;
            bufIdx      = obj.pBufferIdx;
            numElements = obj.pNumElements;
            cnt         = obj.pCount;
            top         = obj.pTop;
            winLen      = int32(obj.WindowLength);
            
            % Pre-allocate output
            m = zeros(size(x),'like',x);
            
            % Cycle through the input samples
            for index = 1:size(x,1)

                for chanIndex =  1:obj.NumChans
                    
                    xin = x(index,chanIndex);

                    % Delete top if it is too old
                    if numElements(chanIndex) > 0  && cnt - bufIdx(top(chanIndex),chanIndex) == winLen
                        top(chanIndex) = top(chanIndex) + 1;
                        if top(chanIndex) > winLen
                            top(chanIndex) = 1;
                        end
                        numElements(chanIndex)   = numElements(chanIndex) - 1;
                    end
                    
                    % Insert new element
                    % placement is the end of the queue by default
                    placement =  numElements(chanIndex) + top(chanIndex)-1;
                    if placement >=  winLen
                       placement = placement -  winLen;
                    end
                    placement = placement + 1;
                    % ind_vect holds indices of elements in queue
                    ind_vect = zeros(1,winLen,'int32');
                    N = numElements(chanIndex);
                   
                    if N  > 0
                        count = int32(1);
                        for ind= int32(N)-1:-1:0
                            indVal = top(chanIndex)-1+int32(ind);
                            if indVal >=  winLen
                                indVal = indVal -  winLen;
                            end
                            ind_vect(count)  = indVal + 1;
                            count = count + 1;
                        end
                        for ind = 1:N
                            index2 = ind_vect(ind);
                            cond =  compareElements(obj,xin,buf(index2,chanIndex));
                            if cond
                                % New element goes at the end of the queue
                                break;
                            end
                            % New element clobbers element currently at index2
                            placement = index2;
                            % We clobbered an element, decrease number of
                            % elements
                            N         = N - 1;
                        end
                    end
                    % Insert new element
                    buf(placement,chanIndex)    = xin;
                    % Register time stamp of new element
                    bufIdx(placement,chanIndex) = cnt;
                    % Increase number of elements in queue
                    numElements(chanIndex)      = N + 1;
                    
                    % Output is top of the queue
                    m(index,chanIndex) = buf(top(chanIndex),chanIndex);
                    
                end
                % Move ahead in time
                cnt    = cnt + 1;
                if cnt > 1e6
                    cnt = cnt - 1e6;
                    bufIdx = bufIdx - 1e6;
                end
            end
            
            obj.pBuffer      = buf;
            obj.pBufferIdx   = bufIdx;
            obj.pNumElements = numElements;
            obj.pCount       = cnt;
            obj.pTop         = top;
           
            
        end
        
        function resetImpl(obj)
            obj.pBuffer      = zeros(obj.WindowLength,obj.NumChans,obj.pDatatype);
            obj.pBufferIdx   = zeros(obj.WindowLength,obj.NumChans,'int32');
            obj.pNumElements = zeros(1,obj.NumChans,'int32');
            obj.pCount       = ones(1,1,'int32');
            obj.pTop         = ones(1,obj.NumChans,'int32');
        end
        
        
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            if isLocked(obj)
                s.pBuffer      = obj.pBuffer;
                s.pBufferIdx   = obj.pBufferIdx;
                s.pNumElements = obj.pNumElements;
                s.pCount       = obj.pCount;
                s.pDatatype    = obj.pDatatype;
            end
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                obj.pBuffer      = s.pBuffer;
                obj.pBufferIdx   = s.pBufferIdx;
                obj.pNumElements = s.pNumElements;
                obj.pCount       = s.pCount;
                obj.pDatatype    = s.pDatatype;
            end
            loadObjectImpl@matlab.System(obj, s, wasLocked);
        end
    end
end
