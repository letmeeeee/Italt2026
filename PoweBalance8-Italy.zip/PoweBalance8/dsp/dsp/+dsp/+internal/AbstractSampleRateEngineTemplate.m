classdef (Abstract) AbstractSampleRateEngineTemplate < matlab.System
% AbstractSampleRateEngineTemplate  Template for AbstractSampleRateEngine

%   Copyright 2014-2020 The MathWorks, Inc.

    %#codegen
    %#ok<*EMCLS>
    
    properties (Abstract)
        % SampleRate Input sample rate (Hz)
        %   Specify the sampling rate of the input in Hertz as a finite
        %   numeric scalar.
        SampleRate
    end

    properties (Nontunable)
        % InheritSampleRate Inherit sample rate from input
        % Set this property to true to inherit the sample rate from the
        % input. Set it to false to specify the sample rate on the dialog.
        % This property is not relevant for the System object in MATLAB
        InheritSampleRate (1, 1) logical = false;
    end

    properties (Access = protected)
        % pSampleRateInherit Private property holds the derived sample rate
        % when inherited from input port. Default value of -1 means that
        % the sample rate has not been derived yet. 
        pSampleRateInherit = -1;
    end
    
    properties (Abstract, Access = protected)
        % pSampleRateDialog holds the sample rate specified on the dialog
        % Child classes define the default value of this property
        pSampleRateDialog
    end
    
    methods
        
        function obj = AbstractSampleRateEngineTemplate(varargin)
            setProperties(obj, nargin, varargin{:});
            coder.allowpcode('plain');
        end
    end
    
    methods (Access = protected)
        
        function flag = isInactivePropertyImpl(obj, prop)
            % Define visibility rules
            % InheritSampleRate is always inactive for System objects in
            % MATLAB
            % SampleRate is inactive if InheritSampleRate = true
            flag = false;
            switch prop
                case 'InheritSampleRate'
                    flag = ~obj.getExecPlatformIndex();
                case {'SampleRate','InputSampleRate'}
                    flag = obj.getExecPlatformIndex() && obj.InheritSampleRate;
            end
        end
        
        function setupImpl(obj,x)
            % If obj.SampleRate = -1, this means that the inherited sample
            % rate has not been computed yet. validatePropertiesImpl was
            % skipped. Perform validateProperties at the end of setup
            % (after sample rate is derived). 
            validationRequired = (obj.SampleRate == -1);
            if obj.getExecPlatformIndex()
                sts = getSampleTime(obj);
                ts = sts.SampleTime;
                % Never allow continuous time
                coder.internal.errorIf(disallowContinuousSampleTime(obj) && ts==0,...
                    'dsp:system:Shared:ContinuousTimeNotAllowed');
                if obj.InheritSampleRate
                    % Do not allow const time if sample rate is inherited
                    coder.internal.errorIf(isinf(ts),...
                        'dsp:system:AbstractSampleRateEngine:SampleTimeMustBeDiscrete');
                    % Cannot inherit sample rate in triggered or asynchronous subsystems 
                    coder.internal.errorIf(ts < 0,...
                        'dsp:system:AbstractSampleRateEngine:TriggeredSubsystemNotSupported');
                    value = size(x,1) / ts;
                    obj.pSampleRateInherit   = value;
                    postProcessSampleRate(obj,value);
                end
            end
            if validationRequired
                validateProperties(obj);
            end
        end
        
        function numchans = getNumChannels(obj,u, varargin)
            % GETNUMCHANNELS Return the number of input channels
            if nargin ==2
                in = 1;
            else
                in = varargin{1};
            end
            if obj.getExecPlatformIndex()
                thisSize = propagatedInputSize(obj, in);
                numchans = thisSize(2);
            else
                numchans = size(u,2);
            end
        end
        
        function s = saveObjectImpl(obj)
            % Default implementation saves all public properties
            s = saveObjectImpl@matlab.System(obj);
            if isLocked(obj)
                s.pSampleRateInherit = obj.pSampleRateInherit;
            end
            s.pSampleRateDialog = obj.pSampleRateDialog;
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            % Re-load state if saved version was locked
            if ~isfield(s, 'pSampleRateDialog')
                % Backwards compatibility
                obj.pSampleRateDialog = s.SampleRate;
            else
                obj.pSampleRateDialog = s.pSampleRateDialog;
            end
            if wasLocked
                if isfield(s, 'pSampleRateInherit')
                    % All the following were set at setup
                    obj.pSampleRateInherit = s.pSampleRateInherit;
                end
            end
            % Call base class method
            loadObjectImpl@matlab.System(obj, s, wasLocked);
        end
        
        function postProcessSampleRate(obj, varargin)%#ok
            % Child classes may overload this method to implement extra
            % work
            % needed to be done on setting SampleRate property
        end
       
        function flag = isSampleRateInherited(obj)
            % Variable-size signals are not allowed if the sample rate is
            % inherited
            flag =  obj.InheritSampleRate;
        end
        
        function flag = isInputSizeMutableImpl(obj,~)
            flag = ~isSampleRateInherited(obj);
        end
        
        function flag = disallowContinuousSampleTime(~)
            % Blocks inheriting from this class should overload this method
            % to allow continuous time
            flag = true;
        end
          
        function sts = getSampleTimeImpl(obj)
            if obj.InheritSampleRate
                % If sample rate is inherited, there is no way to deduce it
                % if the input sample rate is constant. Error out
                mode = 'Error';
            else
                % Object has discrete state. Disallow constant sample rate. 
                mode = 'Disallow';
            end
            
            sts = createSampleTime(obj, 'Type', 'Inherited', ...
                                   mode, 'Constant');
        end
          
    end
    
end
