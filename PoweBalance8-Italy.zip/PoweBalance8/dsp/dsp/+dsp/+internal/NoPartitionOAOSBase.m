classdef NoPartitionOAOSBase < matlab.System
    % NoPartitionOAOSBase Base class for classic overlap-add and
    % overlap-save filters. This class is used in
    % dsp.FrequencyDomainFIRFilter
    
    % Copyright 2017-2023 The MathWorks, Inc.
    
    %#codegen
    
    properties
        % Numerator FIR numerator
        Numerator = fir1(100,0.3);
    end
    
    properties (Nontunable)
        % FFTLength FFT length
        FFTLength = 256;
        Domain (1, :) char {matlab.system.mustBeMemberMessageID(Domain, ...
                     {'dsp:system:FrequencyDomainFIRFilter:Domain_Time',;...
                      'dsp:system:FrequencyDomainFIRFilter:Domain_Frequency'})}= 'Time';        
        NumeratorLength = 101;
    
       FilterIsReal (1, 1) logical = true; 
    end
        
    properties(Access = protected)
        % pLastSection Samples from previous computed segment
        pLastSection;
        % H FFT of numerator coefficients
        H
        % Input buffer
        pinBuff
        % Output buffer
        poutBuff
    end
    
    properties(Access = protected, Nontunable)
        pFilterLength
        pDatatype
        numChannels
        pFFTLength
        pIsOutputReal
        pHalideMode
    end
    
    methods
        function obj = NoPartitionOAOSBase(varargin)
            setProperties(obj,nargin,varargin{:});
            obj.pHalideMode = coder.const(feval('dsp.internal.feature','ActiveValue','dsp_simulations','halide'));
        end
    end
    
    methods (Access = public, Hidden)
        function setNumchans(obj,val)
            obj.numChannels   = val;
        end
    end
    
    methods (Access = protected)
        
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            if isLocked(obj)
                s.pLastSection = obj.pLastSection;
                s.H = obj.H;
                s.pinBuff =  saveobj(clone(obj.pinBuff));
                s.poutBuff = saveobj(clone(obj.poutBuff));
                s.pFilterLength = obj.pFilterLength;
                s.pDatatype = obj.pDatatype;
                s.numChannels = obj.numChannels;
                s.pFFTLength = obj.pFFTLength;
                s.pIsOutputReal = obj.pIsOutputReal;
            end
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                obj.pLastSection = s.pLastSection;
                obj.H = s.H;
                obj.pinBuff  = loadobj(s.pinBuff);
                obj.poutBuff = loadobj(s.poutBuff);
                obj.pFilterLength = s.pFilterLength;
                obj.pDatatype = s.pDatatype;
                obj.numChannels = s.numChannels;
                obj.pFFTLength = s.pFFTLength;
                obj.pIsOutputReal = s.pIsOutputReal;
            end
            loadObjectImpl@matlab.System(obj, s, wasLocked);
        end
        
        function setupImpl(obj,u)
            
            obj.pDatatype     = class(u);
            obj.pFFTLength    = cast(obj.FFTLength,obj.pDatatype);
            
            if strcmp(obj.Domain,'Time')
                obj.H = fft(cast(obj.Numerator,obj.pDatatype),obj.pFFTLength).';
                obj.pIsOutputReal = isreal(u) && isreal(obj.Numerator);
                obj.pFilterLength = cast(length(obj.Numerator),obj.pDatatype);
            else
                obj.H = cast(obj.Numerator , obj.pDatatype).';
                obj.pIsOutputReal = isreal(u) && obj.FilterIsReal;
                obj.pFilterLength = obj.NumeratorLength;
            end
            
            % The number of samples required to form a segment is FFTLength
            % - FilterLength + 1. This is the maximum number of samples
            % that can go into the input buffer for use in future calls to
            % step.
            obj.pinBuff        = dsp.AsyncBuffer('Capacity',max(obj.pFFTLength - obj.pFilterLength + 1,2));
            setup(obj.pinBuff,zeros(obj.pFFTLength - obj.pFilterLength + 1,obj.numChannels,'like',u));

            % With each segment computation, we produce FFTLength -
            % FilterLength + 1 output samples. This is the maximum number
            % of samples that can go to an output buffer for use in future
            % calls to step. 
            obj.poutBuff = dsp.AsyncBuffer('Capacity',max(obj.pFFTLength - obj.pFilterLength + 1,2)); 
          
            if ~obj.pIsOutputReal
                setup(obj.poutBuff,complex(zeros(obj.pFFTLength - obj.pFilterLength + 1,obj.numChannels,'like',u)));
            else
                setup(obj.poutBuff,zeros(obj.pFFTLength - obj.pFilterLength + 1,obj.numChannels,'like',u));
            end
        end
        
        function y = stepImpl(obj,u)
            
            sz         = size(u);
            numSamples = cast(sz(1),class(u));
            numchan    = cast(obj.numChannels,class(u));
            
            DT      = obj.pDatatype;
            
            poutbff     = obj.poutBuff;
            poutsamples = cast(poutbff.NumUnreadSamples , obj.pDatatype);

            pinbff      = obj.pinBuff;
            pinsamples  = cast(pinbff.NumUnreadSamples , obj.pDatatype);
            
            isOutReal  = obj.pIsOutputReal;
            
            availableSamples  = pinsamples;
            % Number of new input samples + number of samples already in
            % input buffer
            fftlen           = obj.pFFTLength;
            filtlen          = obj.pFilterLength;
            totalSamples = min(availableSamples,fftlen - filtlen + 1) + numSamples;
            
            prevsec          = obj.pLastSection;
            L                = fftlen - filtlen + 1;
            pH               = obj.H;
            
            numFrames = cast(floor(totalSamples / L),DT);

            input = zeros(L*numFrames,numchan,'like',u);
            
            % First, read samples from input buffer
            inpStart   = cast(1,DT);
            remSamples = L*numFrames;
            if (availableSamples > 0)
                val = min(L*numFrames,availableSamples);
                if numFrames > 0
                    input(1:val,:) = read(pinbff,int32(val));  
                    inpStart       = val +  cast(1,DT);
                    remSamples     = remSamples - val;
                end
            end
            
            % Append new input samples
            if remSamples > 0
                input(inpStart:inpStart+remSamples-1,:) = u(1:remSamples,:);
            end
            
            % Put unused input samples in input buffer
            if numSamples> remSamples
                write(pinbff, u(remSamples+1:end,1:numchan));
            end
            
            if isOutReal
              y = zeros(numSamples, numchan,DT);
            else
              y = zeros(numSamples, numchan,DT) + 1j * zeros(numSamples, numchan,DT);  
            end
            
            samplesToFill = numSamples;
            
            % First, transfer samples from output buffer to output
            ns = cast(1,class(u));
            if poutsamples> 0
                ns = min(numSamples,poutsamples);
                y(1:ns,:) = read(poutbff,int32(ns));
                samplesToFill = samplesToFill - ns;
                ns = ns + 1;
            end
            
            % Compute new output samples
            if numFrames > 0
                
                [o,prevsec] = obj.computeOutput(input,L,numFrames,numchan,pH,fftlen,filtlen,prevsec,isOutReal,obj.pHalideMode);
                
                y(ns:end,:) = o(1:samplesToFill, :);

                % Put unused output samples in output buffer for future use
                if samplesToFill  < L*numFrames
                    write(poutbff , o(samplesToFill+1:end,1:numchan));
                end
                
            end
            
            obj.pLastSection = prevsec;
        end
        
        function processTunedPropertiesImpl(obj)
             if strcmp(obj.Domain,'Time')
                obj.H = fft(cast(obj.Numerator,obj.pDatatype),obj.pFFTLength).';
             else
                obj.H = cast(obj.Numerator,obj.pDatatype).';
             end
        end
        
        function resetImpl(obj)
            
            obj.pLastSection = zeros(size(obj.pLastSection),'like',obj.pLastSection);
            
            reset(obj.pinBuff);
            reset(obj.poutBuff);
            
            if obj.pIsOutputReal
                step(obj.poutBuff,zeros(obj.pFFTLength - obj.pFilterLength + 1,obj.numChannels,obj.pDatatype));
            else
                step(obj.poutBuff,complex(zeros(obj.pFFTLength - obj.pFilterLength + 1,obj.numChannels,obj.pDatatype)));
            end
        end
        
    end
    
    methods (Static, Abstract)
        computeOutput(obj)
    end
    
end