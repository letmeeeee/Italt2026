classdef SlidingWindowMaximumSim < dsp.internal.AbstractSlidingWindowStatistic
    % SlidingWindowMaximumSim This class is internally used by
    % dsp.MovingMaximum
    
    %   Copyright 2016-2020 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCLS>
    
    properties (Access = protected)
        InitialBufferValue = -Inf;
    end
    
    methods
        function obj = SlidingWindowMaximumSim(varargin)
            setProperties(obj,nargin,varargin{:});
        end
    end
    
    methods(Access = protected)
        
        function y = computeStatistic(obj,u)
            y = movmax(u,obj.WindowLength ,'includenan','Endpoints','discard');
        end
        
         function s = saveObjectImpl(obj)
            s = saveObjectImpl@dsp.internal.AbstractSlidingWindowStatistic(obj);
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            loadObjectImpl@dsp.internal.AbstractSlidingWindowStatistic(obj, s, wasLocked);
        end
        
    end
end