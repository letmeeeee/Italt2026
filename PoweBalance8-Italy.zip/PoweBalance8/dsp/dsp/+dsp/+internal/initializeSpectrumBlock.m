function [Fs,delayFrames] = initializeSpectrumBlock(blk , checkRBW, computeFs , bufferBlkName)
% This function is used in the spectrum estimation, cross-spectrum
% estimation and transfer function estimation blocks.

%   Copyright 2016-2023 The MathWorks, Inc.

if checkRBW
    visibilities  = get_param(blk,'MaskVisibilities');
    MaskNames     = get_param(blk,'MaskNames');
    rbwIdx        = find(ismember(MaskNames,'RBW'));
    isRBWVisible  = strcmp(visibilities{rbwIdx},'on'); %#ok
    if  isRBWVisible
        % Span/RBW must be greater than 2
        Fs = get_param(blk,'SampleRate');
        if strcmp(get_param(blk,'FrequencyRange'),'One-sided')
            span = slResolve(Fs,blk);
        else
            span = slResolve(Fs,blk) / 2;
        end
        rbw = slResolve(get_param(blk,'RBW'),blk);
        if (span/rbw) <= 2
            error(message('dsp:system:SpectrumEstimatorBase:InvalidSpanRBW'));
        end
    end
end

Fs = 1;
if computeFs
    % Compute sample rate based on input dimensions and sample time
    compiledPortDimensions = get_param(blk,'CompiledPortDimensions');
    compiledSampleTime     = get_param([blk '/x'],'CompiledSampleTime');
    L = compiledPortDimensions.Inport(2);
    Fs = L / compiledSampleTime(1);
end

% Compute the number of samples of delay introduced by buffering.
% Inputs to the spectrum estimator subsystem block consisting of
% all zeros (i.e. initial conditions) must be ignored. Otherwise we
% do not match Spectrum analyzer
bufferBlock = [blk '/' bufferBlkName];
isInherit = strcmp(get_param(bufferBlock,'InheritSize'),'on');
compiledPortDimensions     = get_param([blk '/x'],'CompiledPortDimensions');
F = compiledPortDimensions.Outport(2);
if ~isInherit
    Nstr = get_param(bufferBlock,'N');
    if strcmp(Nstr,'WindowLength')
        N = slResolve(get_param(blk,'WindowLength'),blk);
    else
        N = slResolve(get_param(bufferBlock,'N'),blk);
    end
    V = slResolve(get_param(bufferBlock,'V'),blk);
else
    N = F;
    overlapPercent = slResolve(get_param(blk,'Overlap'),blk);
    V = floor(N * overlapPercent / 100 + 0.5);
end

isSingleRate = ((F == N) && (V == 0)) || (F == (N-V));
if isSingleRate
    delayFrames = 0;
else
    model = bdroot(blk);
    solverMode = get_param(model,'SolverMode');
    D = rebuffer_delay(F,N,V,lower(solverMode));
    % Delay in frames
    delayFrames = floor(D / N);
end

DT = get_param(blk,'CompiledPortDataTypes');
DT = DT.Inport{:};
Fs = cast(Fs,DT);
delayFrames = cast(delayFrames,DT);

end