classdef RunningMaximum < matlab.System
%   RunningMaximum This class is used in dsp.MovingMaximum

%   Copyright 2016 The MathWorks, Inc.
   
%#codegen
%#ok<*EMCLS>

    
    properties (Access = protected)
        % pCumMax Cumulative minimum
        pCumMax
    end
    
    properties (Nontunable)
        % NumChannels Number of channels
        NumChans = 1
    end
    
    methods
        function obj = RunningMaximum(varargin)
            setProperties(obj,nargin,varargin{:});
        end
    end
    
    methods(Access = protected)
        
        function setupImpl(obj,u)
            obj.pCumMax = -Inf * ones(1,obj.NumChans,'like',u);
        end

        function m = stepImpl(obj,u)
            y      = cummax([obj.pCumMax;u]);
            m      = y(2:end,:);
            obj.pCumMax = y(end,:);
        end
        
        function resetImpl(obj)
           obj.pCumMax = -Inf * ones(size(obj.pCumMax),'like',obj.pCumMax);
        end
        
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            if isLocked(obj)
                s.pCumMax = obj.pCumMax;
            end
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            if wasLocked
               obj.pCumMax = s.pCumMax;
            end
            loadObjectImpl@matlab.System(obj, s, wasLocked);
        end
        
    end
end