classdef ExponentialMovingVariance< matlab.System
% ExponentialMovingVariance This class is internally used by
% dsp.MovingVariance in the exponentially weighted mode

     
    %   Copyright 2016-2020 The MathWorks, Inc.

    methods
        function out=ExponentialMovingVariance
        end

        function out=computeStatistic(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

    end
    properties
        ForgettingFactor;

        NumChans;

    end
end
