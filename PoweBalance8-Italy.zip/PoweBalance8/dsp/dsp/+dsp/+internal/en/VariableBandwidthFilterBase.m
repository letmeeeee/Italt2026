classdef VariableBandwidthFilterBase< dsp.internal.NormalizedSampleRateEngine & dsp.internal.FilterAnalysis
%VARIABLEBANDWIDTHFILTERBASE Abstract base class for variable bandwidth
% objects. dsp.VariableBandwidthIIRFilter and
% dsp.VariableBandwidthFIRFilter inherit from this base class.

     
    %   Copyright 2013-2021 The MathWorks, Inc.

    methods
        function out=VariableBandwidthFilterBase
            % Constructor
        end

        function out=convertToDFILT(~) %#ok<STOUT>
            % Returns equivalent dfilt to current object.
        end

        function out=crossValidateProperties(~) %#ok<STOUT>
        end

        function out=getInputNamesImpl(~) %#ok<STOUT>
        end

        function out=getOutputDataTypeImpl(~) %#ok<STOUT>
        end

        function out=getOutputNamesImpl(~) %#ok<STOUT>
        end

        function out=getOutputSizeImpl(~) %#ok<STOUT>
        end

        function out=getSampleRate(~) %#ok<STOUT>
        end

        function out=getTunablePropertiesSpecificationImpl(~) %#ok<STOUT>
        end

        function out=infoImpl(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isInputComplexityMutableImpl(~) %#ok<STOUT>
        end

        function out=isOutputComplexImpl(~) %#ok<STOUT>
        end

        function out=isOutputFixedSizeImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=outputDelayDefaultNormalizedFc(~) %#ok<STOUT>
            % Return the (normalized) frequency for which group delay is evaluated in
            % outputDelay.
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
            % Tune the filter coefficients
        end

        function out=realizemdl(~) %#ok<STOUT>
            % realizemdl is not supported
        end

        function out=releaseImpl(~) %#ok<STOUT>
            % Release the filter object
        end

        function out=resetImpl(~) %#ok<STOUT>
            % Reset the filter object
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=supportsMultipleInstanceImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

    end
    methods (Abstract)
        %TUNECOEFFICIENTS Children objects redefine this method to specify
        % how coefficients are modified when filter characteristic is tuned
        tuneCoefficients;

        % VALIDATEFREQUENCYRANGE Children objects redefine this method to
        % validate cutoff frequencies versus sample rate.
        validateFrequencyRange;

    end
    properties
        % Bandwidth  Filter bandwidth 
        %   Specify the filter bandwidth as a real, positive scalar smaller
        %   than SampleRate/2. This property applies when you set the
        %   FilterType property to 'Bandpass' or 'Bandstop'. Specify the
        %   value of filter bandwidth in Hertz when you set
        %   NormalizedFrequency to false, and set the value in normalized
        %   units when you set NormalizedFrequency to true. The default is
        %   7680 Hz. This property is tunable.
        Bandwidth;

        %CenterFrequency  Filter center frequency 
        %   Specify the filter center frequency as a real, positive scalar
        %   less than SampleRate/2. This property applies when you set the
        %   FilterType property to 'Bandpass' or 'Bandstop'. Specify the
        %   value of center frequency in Hertz when you set
        %   NormalizedFrequency to false, and set the value in normalized
        %   units when you set NormalizedFrequency to true. The default is
        %   11025 Hz. This property is tunable.
        CenterFrequency;

        %FilterType Filter type
        %   Specify the type of the filter as one of 'Lowpass' | 'Highpass'
        %   | 'Bandpass' | 'Bandstop'. The default is 'Lowpass'.
        FilterType;

        % SampleRate Input sample rate (Hz)
        %   Specify the sampling rate of the input in Hertz as a finite
        %   numeric scalar. the default is 44100 Hz.
        SampleRate;

        % pDatatype Input datatype
        pDatatype;

        % pNumChannels Number of input channels
        pNumChannels;

        % pSampleRateDialog Default sample rate
        pSampleRateDialog;

        % filter handle. Children objects instantiate and set this object
        pfilter;

    end
end
