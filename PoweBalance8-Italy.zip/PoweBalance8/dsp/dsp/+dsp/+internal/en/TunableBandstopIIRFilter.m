classdef TunableBandstopIIRFilter< dsp.internal.TunableBandpassBandstopIIRFilter
% TunableBandstopIIRFilter

 
%   Copyright 2022-2023 The MathWorks, Inc.

    methods
        function out=TunableBandstopIIRFilter
        end

        function out=designFilter(~) %#ok<STOUT>
        end

    end
end
