%MSESIM Mean-squared error for adaptive filters.
%   MSE = MSESIM(H,X,D) Sequence of mean-square errors. This column vector
%   contains estimates of the mean-square error of the adaptive filter at
%   each time instant. The length of MSE is equal to SIZE(X,1). The columns
%   of the matrix X contain individual input signal sequences, and the
%   columns of the matrix D contain corresponding desired response signal
%   sequences.
%
%   [MSE,MEANW,W,TRACEK] = MSESIM(H,X,D) calculates three parameters
%   corresponding  to the simulated behavior of the adaptive filter defined
%   by H:
%
%   MEANW   - Sequence of coefficient vector means. The columns of this
%             matrix contain estimates of the mean values of the LMS
%             adaptive filter coefficients at each time instant. The
%             dimensions of MEANW are (SIZE(X,1)) x (H.length).
%   W       - estimate of the final values of the adaptive filter
%             coefficients for the algorithm corresponding to H.
%   TRACEK  - Sequence of total coefficient error powers. This column
%             vector contains estimates of the total coefficient error
%             power of the LMS adaptive filter at each time instant. The
%             length of TRACEK is equal to SIZE(X,1).
%
%   [MSE,MEANW,W,TRACEK] = MSESIM(H,X,D,M) specifies an optional decimation
%   factor  for computing MSE, MEANW, and TRACEK. If M > 1, every Mth
%   predicted value of  each of these sequences is saved. If omitted, the
%   value of M defaults to one.
%
%   % EXAMPLE #1: System identification of an FIR filter
%   ha = fir1(31,0.5);                  
%   sa = dsp.FIRFilter('Numerator',ha); % FIR system to be identified 
%   hb = dsp.IIRFilter('Numerator',sqrt(0.75),...
%       'Denominator',[1 -0.5]);
%   x = step(hb,sign(randn(2000,25))); 
%   n = 0.1*randn(size(x));             % Observation noise signal 
%   d = step(sa,x)+n;                   % Desired signal 
%   l = 32;                             % Filter length 
%   mu = 0.008;                         % LMS Step size. 
%   m  = 5;                             % Decimation factor for analysis
%                                       % and simulation results 
%   ha = dsp.LMSFilter(l,'StepSize',mu); 
%   [simmse,meanWsim,Wsim,traceKsim] = msesim(ha,x,d,m);
%   plot(m*(1:length(simmse)),10*log10(simmse));
%   xlabel('Iteration'); ylabel('MSE (dB)');
%   title('Learning curve for LMS filter used in system identification')
%
%   See also MSEPRED, MAXSTEP

 
%   Copyright 1999-2016 The MathWorks, Inc.

