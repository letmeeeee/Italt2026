classdef PartitionOAOSBase< matlab.System
% PartitionOAOSBase Base class for partitioned overlap-add and
% overlap-save filters. 
% This class is used in dsp.FrequencyDomainFIRFilter.

     
    % Copyright 2017-2023 The MathWorks, Inc.

    methods
        function out=PartitionOAOSBase
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

    end
    properties
        Domain;

        FilterIsReal;

        % Numerator Impulse response
        Numerator;

        % PartitionLength Length of each partition of the impulse response
        PartitionLength;

        numChannels;

        pDatatype;

        pFFTLength;

        pHalideMode;

        pIRFFT;

        pIsOutputReal;

        pLastSection;

        pLastSectionLength;

        pNumPartitions;

        pPartitionLength;

        pSum;

        pSumIdx;

        % Output buffer
        pinBuff;

        % Input buffer
        poutBuff;

    end
end
