%compactButAccurateMat2Str Convert scalars, vectors and 2-d Matrices to
%                          strings that evaluate back to same 
%                          double-precision values.

 
% Copyright 2014-2019 The MathWorks, Inc.

