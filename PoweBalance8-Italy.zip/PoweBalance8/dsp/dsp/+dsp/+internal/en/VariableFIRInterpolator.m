classdef VariableFIRInterpolator< matlab.System & dsp.enhancedsim.UpdateSysObjBuildInfo
%VARIABLEFIRINTERPOLATOR Variable FIR Interpolator
%   VFIRI = dsp.internal.VariableFIRInterpolator returns a System object, VFIRI, 
%   which interpolates the input using a polyphase filter structure oriented with respect
%   to the maximum interpolation factor. The interpolation factor can vary at each step 
%   and has to be a factor of the maximum interpolation factor. The filter coefficients are 
%   auto computed by default and can be specified externally.
%
%   VFIRI = dsp.internal.VariableFIRInterpolator(Name=Value, ...) returns a
%   Variable FIR Interpolator System object, VFIRI, with each specified
%   property name set to the specified value. You can specify additional
%   name-value pair arguments in any order as (Name1=Value1,...,Name=ValueN).
%
%   Step method syntax:
%
%   Y = step(VFIRI, X) interpolates the real or complex input signal X using the
%   specified filter to produce the output Y. The System object filters
%   each channel of the input signal independently over time.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%   Variable FIR Interpolator methods:
%
%   step          - See above description for use of this method
%   release      - Allow property value and input characteristics changes
%   clone        - Create Variable FIR Interpolator Filter object with
%                      same property values
%   isLocked   - Locked status (logical)
%   reset         - Reset the internal states to initial conditions
%
%   VariableBandwidthFIRFilter properties:
%   
%   MaxInterpolationFactor - Maximum interpolation factor
%   InterpolationFactor        - Interpolation factor
%   CoefficientSource          - Coefficient source
%   Coefficients                   - Prototype filter coefficients
%
%   % EXAMPLE #1: Interpolate input by a factor of 24
%   firInterp = dsp.internal.VariableFIRInterpolator(24);
%   x = (0:2)'
%   firInterp.InterpolationFactor = 6;
%   y = firInterp(x)
%   See also dsp.FIRInterpolator, dsp.FIRRateConverter, designMultirateFIR.
%#codegen
%#ok<*EMCA>
%#ok<*EMCLS>

 
%   Copyright 2022-2023 The MathWorks, Inc.

    methods
        function out=VariableFIRInterpolator
            % Support name-value pair arguments when constructing object
        end

        function out=coeffs(~) %#ok<STOUT>
            %c = coeffs(obj) Return structure with filter coefficients
            %   c = coeffs(obj) returns the overall prototype lowpass
            %   filter coefficients in a structure.
        end

        function out=designFilter(~) %#ok<STOUT>
        end

        function out=fvtool(~) %#ok<STOUT>
        end

        function out=getInputDataSize(~) %#ok<STOUT>
            % fetch the number of channels
        end

        function out=getInterpolationFactor(~) %#ok<STOUT>
        end

        function out=getMaxInterpolationFactor(~) %#ok<STOUT>
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
            % Modify order of display
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isInputComplexityMutableImpl(~) %#ok<STOUT>
            % Return false if input complexity cannot change
            % between calls to the System object
        end

        function out=isInputDataTypeMutableImpl(~) %#ok<STOUT>
            % Return false if input data type cannot change
            % between calls to the System object
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Re-load state if saved version was locked
        end

        function out=polyphase(~) %#ok<STOUT>
            %p = polyphase(obj) Return polyphase matrix
            %   p = polyphase(obj) returns the polyphase matrix used by the
            %   filter bank. Each row in the matrix corresponds to a
            %   polyphase branch. The number of columns of p corresponds to
            %   the number of filter taps per branch.
        end

        function out=polyphase2coeffs(~) %#ok<STOUT>
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
            % Initialize / reset discrete-state properties
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Default implementation saves all public properties
        end

        function out=setPolyphaseMatrixFromCustomCoeffs(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=tf(~) %#ok<STOUT>
            %[b,a] = tf(obj) Return transfer function
            %   [b,a] = tf(obj) returns the vector of numerator
            %   coefficients b and the vector of denominator coefficients a
            %   for the overall prototype lowpass filter used for the
            %   filter bank.
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

        function out=variableFIRInterpolatorCG(~) %#ok<STOUT>
        end

        function out=variableFIRInterpolatorHalideCG(~) %#ok<STOUT>
        end

    end
    properties
        % CoefficientSource Coefficient source
        % Specify the input source for coefficients as "Auto", "Dialog
        % parameter" or "Input port". The default is "Auto".
        CoefficientSource;

        % Coefficients Prototype filter coefficients
        % This property is overwritten when CoefficientSource is set to 'Dialog
        % parameter' or 'Input port'.
        Coefficients;

        % InterpolationFactor Interpolation factor
        % Specify the interpolation factor at step. This value has to be a
        % factor of MaxInterpolationFactor. The default value of this
        % property is 24.
        InterpolationFactor;

        % MaxInterpolationFactor Maximum interpolation factor
        % Specify the maximum interpolation factor which is used to compute
        % the polyphase filter structure. Interpolation factor cannot be
        % greater than this value. The default value of this property is
        % 24.
        MaxInterpolationFactor;

        % OutputFrameLength Output signal frame length
        % Specify the output signal frame length as a positive integer.
        % This property applies when the Specification is "Output frame
        % length". The default is 48.
        OutputFrameLength;

        % Specification Output frame length specification
        % Set the output frame length specification as "Interpolation
        % factor" or "Output frame length". The default is "Interpolation
        % factor".
        Specification;

        pFlippedPolyphaseCoefficients;

        pInputDataType;

        pInputFrameLength;

        pNumChannels;

        pPolyphaseCoefficients;

        pPrivNumCoefficients;

        pStates;

    end
end
