classdef AbstractMovingStatistic< dsp.internal.SupportScalarVarSize
%   AbstractMovingStatistic This class is used in the moving statistics
%   objects

 
%   Copyright 2016-2023 The MathWorks, Inc.

    methods
        function out=AbstractMovingStatistic
            % Constructor
        end

        function out=getFrameLength(~) %#ok<STOUT>
        end

        function out=getInputNamesImpl(~) %#ok<STOUT>
        end

        function out=getNumChans(~) %#ok<STOUT>
        end

        function out=getOutputDataTypeImpl(~) %#ok<STOUT>
            % Output datatype propagator
        end

        function out=getOutputNamesImpl(~) %#ok<STOUT>
        end

        function out=getOutputSizeImpl(~) %#ok<STOUT>
            % Output size propagator
        end

        function out=getTunablePropertiesSpecificationImpl(~) %#ok<STOUT>
        end

        function out=isFixedSizeOutput(~) %#ok<STOUT>
            % Varsize output if input is varsize or input length is
            % arbitrary
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=isOutputComplexImpl(~) %#ok<STOUT>
            % Complexity propagator
        end

        function out=isOutputFixedSizeImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setAutoOverlapLength(~) %#ok<STOUT>
            % If the user did not set the overlap length, it should
            % be equal to WindowLength - 1
        end

        function out=setUserDefinedOverlapLength(~) %#ok<STOUT>
            % If the user set the overlap length, set the overlap 
            % length factor source to 'property'
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Get the number of input channels
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=supportsMultipleInstanceImpl(~) %#ok<STOUT>
            % Support in for-each subsystem
        end

        function out=validateForgettingFactor(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

        function out=validatePropertiesImpl(~) %#ok<STOUT>
            % validate properties
        end

    end
    properties
        %ForgettingFactor Forgetting factor
        % Specify the exponential weighting forgetting factor as a scalar
        % value greater than zero and smaller than or equal to one. This
        % property applies when 'Method' is equal to 'Exponential
        % weighting'. The default is 0.9. This property is tunable.
        ForgettingFactor;

        %OverlapLength Overlap length
        % Specify the overlap length between sliding windows as a positive
        % integer. This property applies when 'Method' is equal to 'Sliding
        % window' and 'SpecifyWindowLength' is true. The default is
        % WindowLength-1.
        OverlapLength;

        % SpecifyWindowLength Specify window length 
        % When you set this property to true, the sliding window length is 
        % equal to the value of the 'SlidingWindow' property. When you set 
        % this property to false, the sliding window length is infinite. 
        % In this mode, the average is computed for the current sample and 
        % all past samples). This property applies when Method is equal to 
        % 'Sliding window'. The default is true.
        SpecifyWindowLength;

        %WindowLength Window length 
        % Specify the sliding window length as a positive integer.
        % This property applies when 'Method' is equal to 'Sliding
        % window' and 'SpecifyWindowLength' is true. The default is 4.
        WindowLength;

        % pStatistic Internal object used to compute average
        pStatistic;

    end
end
