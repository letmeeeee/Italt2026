classdef AbstractTunableFIRFilter< matlab.System
%AbstractTunableFIRFilter

 
    %   Copyright 2022-2023 The MathWorks, Inc.

    methods
        function out=AbstractTunableFIRFilter
            % Support name-value pair arguments when constructing object
        end

        function out=computePrototypeWindow(~) %#ok<STOUT>
        end

        function out=crossValidateProperties(~) %#ok<STOUT>
        end

        function out=designLowpassCoefficients(~) %#ok<STOUT>
            % Compute the design window
        end

        function out=getCoefficientsDimensions(~) %#ok<STOUT>
        end

        function out=isDesignFilterAllowed(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
            % Return false if input size cannot change
            % between calls to the System object
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Set properties in object obj to values in structure s
            % Set public properties and states
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
            % If CenterFrequency or Bandwidth are coming from an input
            % port, the Simulink engine sets their value to zero before
            % actually reading the correct value provided at the input.
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetCoefficientsCache(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Set properties in structure s to values in object obj
            % Set public properties and states
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=validateFilterOrder(~) %#ok<STOUT>
        end

        function out=validateKaiserWindowParameter(~) %#ok<STOUT>
        end

        function out=validateMaxOrder(~) %#ok<STOUT>
        end

        function out=validatePropertiesImpl(~) %#ok<STOUT>
        end

        function out=validateSidelobeAttenuation(~) %#ok<STOUT>
        end

    end
    methods (Abstract)
        %------------------------------------------------------------------
        designFilter;

        getCutoffFrequency;

    end
    properties
        % FilterOrder FIR filter order
        %   Specify the order of the FIR filter as a positive integer
        %   scalar. The default is 100.
        FilterOrder;

        % KaiserWindowParameter Kaiser window parameter
        %   Specify the Kaiser window parameter as a real scalar. This property
        %   applies when you set the  Window property to 'Kaiser'. The default is
        %   0.5;
        KaiserWindowParameter;

        %MaxOrder FIR Filter maximum order
        %   Specify the filter maximum order as a finite positive integer
        %   scalar. The default value is 10.
        MaxOrder;

        %OutputDataType Output data type
        %   Specify the output data type as "single" or "double". The
        %   default is "double".
        OutputDataType;

        % SidelobeAttenuation Chebyshev window sidelobe attenuation (dB)
        %   Specify the Chebyshev window sidelobe attenuation as a real,
        %   positive scalar in decibels (dB). This property applies when
        %   you set the Window property to "Chebyshev". The default is 60
        %   dB.
        SidelobeAttenuation;

        % Window Window function
        %   Specify the window function used to design the FIR filter as
        %   one of "Hann" | "Hamming" | "Blackman" | "Blackman-Harris" |
        %   "Chebyshev" | "Kaiser". The default is "Hann".
        Window;

        isInit;

        num;

        pIsChebwin;

        pIsKaiser;

        pProtoypeWindow;

        pWindowFunc;

    end
end
