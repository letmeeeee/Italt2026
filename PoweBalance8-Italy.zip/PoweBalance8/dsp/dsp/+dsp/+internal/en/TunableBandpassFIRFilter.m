classdef TunableBandpassFIRFilter< dsp.internal.TunableBandpassBandstopFIRFilter
% TunableBandpassFIRFilter

 
    %   Copyright 2022-2023 The MathWorks, Inc.

    methods
        function out=TunableBandpassFIRFilter
        end

        function out=designFilter(~) %#ok<STOUT>
            % Compute the design window
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
            % Modify order of display
        end

    end
end
