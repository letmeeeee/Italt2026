classdef MedianFilterCG< matlab.System
% MedianFilterCG This class is used in dsp.MedianFilter

 
%   Copyright 2016 The MathWorks, Inc.

    methods
        function out=MedianFilterCG
        end

        function out=bubbleUpMax(~) %#ok<STOUT>
            % Bubble element up the max-heap until heap is in good order
        end

        function out=bubbleUpMin(~) %#ok<STOUT>
            % Bubble element up the min-heap until heap is in good order
        end

        function out=compareItems(~) %#ok<STOUT>
            %Compare items ind1 and ind2. Return true if first element less than second element
        end

        function out=getMedian(~) %#ok<STOUT>
            % If the window length is odd, the median is the value in the
            % middle of the heap.
            % If the window length is even, the median is the average of
            % the two middle values.
        end

        function out=insertElement(~) %#ok<STOUT>
            % Overwrite the oldest element in the buffer
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
            % Reset states
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=swapElements(~) %#ok<STOUT>
            % Swap elements in heap
        end

        function out=trickleDownMax(~) %#ok<STOUT>
            % Trickle element down the max-heap until heap is in good order
        end

        function out=trickleDownMin(~) %#ok<STOUT>
            % Trickle element down the min-heap until heap is in good order
        end

    end
    properties
        % NumChans Number of input channels
        NumChans;

        % WindowLength Sliding window length
        WindowLength;

    end
end
