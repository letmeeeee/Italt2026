classdef FilterAnalysisCIC< dsp.internal.FilterAnalysis
%#codegen
%FilterAnalysisCIC Baseclass for CIC filter System object analysis

   
  %   Copyright 2011-2020 The MathWorks, Inc.

    methods
        function out=FilterAnalysisCIC
        end

        function out=convertToDFILTCIC(~) %#ok<STOUT>
        end

        function out=freqrespest(~) %#ok<STOUT>
        end

        function out=freqrespopts(~) %#ok<STOUT>
        end

        function out=isNLMSupported(~) %#ok<STOUT>
        end

        function out=noisepsd(~) %#ok<STOUT>
        end

        function out=noisepsdopts(~) %#ok<STOUT>
        end

        function out=parseArithmetic(~) %#ok<STOUT>
            % Parse arithmetic input
            % Inputs:
            %
            % inputsCell    - cell containing PV-pairs. The method will look for
            %                 the 'Arithmetic' input, parse its value and delete
            %                 the PV-pair from the cell. It will return the
            %                 modified cell in the second output, inputsCell.
            % noDfilt       - If true, do not generate an mfilt object from the
            %                 System object and return the parsed arithmetic
            %                 string instead of the dfilt object in the first
            %                 output, d.
        end

        function out=realizemdl(~) %#ok<STOUT>
        end

    end
end
