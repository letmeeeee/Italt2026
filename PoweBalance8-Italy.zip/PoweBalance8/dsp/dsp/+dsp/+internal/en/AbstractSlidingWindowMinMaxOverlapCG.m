classdef AbstractSlidingWindowMinMaxOverlapCG< matlab.System
%  AbstractSlidingWindowMinMaxCGOverlap This class is used in dsp.MovingMinimum
%  and dsp.MovingMaximum
%
% The algorithm is based on "STREAMING MAXIMUM-MINIMUM FILTER USING NO MORE
% THAN THREE COMPARISONS PER ELEMENT" by Daniel Lemire
% Double-ended queue. 
% Top of the queue always holds max (or min) value and its corresponding
% insertion time
% New values are compared with those of the back of the queue
% All values at back of the queue lower than the new value are removed
% New value is placed at back with an expiration time
% Top of the queue is removed when it expires. 
%
% Example for max with a window of length 4. Input: [5 9 2 6 5 3 5]
% Input is 5:                     Queue is [5]
% Input is 9: 9 clobbers 5.       Queue is [9]
% Input is 2:                     Queue is [9 2]
% Input is 6: 6 clobbers 2.       Queue is [9 6]
% Input is 5:                     Queue is [9 6 5]
% Input is 3: 9 expired           Queue is [6 5 3]
% Input is 5: 5 clobbers 5 and 3. Queue is [6 5]

 
%   Copyright 2016-2021 The MathWorks, Inc.

    methods
        function out=AbstractSlidingWindowMinMaxOverlapCG
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

    end
    properties
        HopSize;

        % Numchans Number of input channels
        NumChans;

        %WindowLength Window length
        WindowLength;

        % pBuffer= Circular buffer holding the queue
        pBuffer;

        % pBufferIdx Holds the insertion time of the buffer elements
        pBufferIdx;

        % pCount Counter used to determine expiration date
        pCount;

        % pDatatype Input data type
        pDatatype;

        % pModValueRev Counter to keep track of the input sample index 
        % at which next output needs to be generated
        pModValueRev;

        % pNumElements Number of elements currently in the queue
        pNumElements;

        % pTop Index of the top of the queue
        pTop;

    end
end
