classdef AsyncBuffercg< handle
%AsyncBuffercg Codegen class for dsp.AsyncBuffer

     
    % Copyright 2016-2020 The MathWorks, Inc.

    methods
        function out=AsyncBuffercg
        end

        function out=info(~) %#ok<STOUT>
        end

        function out=matlabCodegenFromRedirected(~) %#ok<STOUT>
        end

        function out=matlabCodegenToRedirected(~) %#ok<STOUT>
        end

        function out=peek(~) %#ok<STOUT>
        end

        function out=read(~) %#ok<STOUT>
            % Error check input and cast as necessary ---------------------
        end

        function out=release(~) %#ok<STOUT>
        end

        function out=reset(~) %#ok<STOUT>
        end

        function out=setup(~) %#ok<STOUT>
        end

        function out=step(~) %#ok<STOUT>
        end

        function out=write(~) %#ok<STOUT>
            %WRITE Write to buffer
        end

    end
    properties
        Capacity;

        %NumUnreadSamples Number of unread samples per channel in buffer
        % The total number of unread samples in the buffer is
        % NumUnreadSamples*(number of channels). This is a read-only
        % property.
        NumUnreadSamples;

    end
end
