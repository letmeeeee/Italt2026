classdef ParametricEQFilterBase< dsp.internal.SampleRateEngine & dsp.internal.FilterAnalysis
%ParametricEQFilter Second-order parametric equalizer filter. Super
%class for dsp.ParametricEQFilter and dsp.simulink.ParametricEQFilter

     
    % Copyright 2018-2023 The MathWorks, Inc.

    methods
        function out=ParametricEQFilterBase
            % Support name-value pair arguments
        end

        function out=coeffs(~) %#ok<STOUT>
        end

        function out=convertToDFILT(~) %#ok<STOUT>
        end

        function out=cost(~) %#ok<STOUT>
        end

        function out=crossValidateProperties(~) %#ok<STOUT>
        end

        function out=getBandwidth(~) %#ok<STOUT>
            %BW = getBandwidth(obj) get filter bandwidth
            %   BW = getBandwidth(obj) returns the bandwidth for the
            %   parametric EQ filter. The bandwidth is measured halfway
            %   between 1 and the peak gain/cut of the filter measured in
            %   absolute power units (magnitude squared of the filter). If
            %   the Specification is set to 'Quality factor and center
            %   frequency', the bandwidth is determined from the quality
            %   factor value. If the Specification property is set to
            %   'Coefficients', the bandwidth is determined from the
            %   BandwidthCoefficient value and the sample rate.
        end

        function out=getBandwidthCoefficient(~) %#ok<STOUT>
            %BWC = getBandwidthCoefficient(obj) get bandwidth coefficient
            %   BWC = getBandwidthCoefficient(obj) returns lattice allpass
            %   filter coefficient corresponding to the bandwidth for the
            %   parametric EQ filter. If the Specification is set to
            %   'Quality factor and center frequency', the bandwidth
            %   coefficient is determined from the quality factor value.
        end

        function out=getCenterFrequency(~) %#ok<STOUT>
            %CF = getCenterFrequency(obj) get center frequency
            %   CF = getCenterFrequency(obj) returns the center frequency
            %   for the parametric EQ filter. If the Specification property
            %   is set to 'Coefficients', the center frequency is
            %   determined from the CenterFrequencyCoefficient value and
            %   the sample rate.
        end

        function out=getCenterFrequencyCoefficient(~) %#ok<STOUT>
            %CFC = getCenterFrequencyCoefficient(obj) get center freq coeff
            %   CFC = getCenterFrequencyCoefficient(obj) returns the
            %   lattice allpass coefficient corresponding to the center
            %   frequency for the parametric EQ filter.
            %CFC = getCenterFrequencyCoefficient(obj) get center freq coeff
            %   CFC = getCenterFrequencyCoefficient(obj) returns the
            %   lattice allpass coefficient corresponding to the center
            %   frequency for the notch/peak filter.
        end

        function out=getHeaderImpl(~) %#ok<STOUT>
            % MATLAB System block header
        end

        function out=getOctaveBandwidth(~) %#ok<STOUT>
            %N = getOctaveBandwidth(obj) bandwidth in number of octaves
            %   N = getOctaveBandwidth(obj) returns the bandwidth of the
            %   parametric EQ filter measured in number of octaves rather
            %   than Hz.
        end

        function out=getPeakGain(~) %#ok<STOUT>
            %G = getPeakGain(obj) get peak gain
            %   G = getPeakGain(obj) returns the peak gain/cut for the
            %   parametric EQ filter in absolute units.
        end

        function out=getPeakGaindB(~) %#ok<STOUT>
            %GdB = getPeakGaindB(obj) get peak gain in dB
            %   G = getPeakGaindB(obj) returns the peak gain/cut for the
            %   parametric EQ filter in decibels.
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
            %Get default parameters group for this System object
        end

        function out=getQualityFactor(~) %#ok<STOUT>
            %Q = getQualityFactor(obj) get quality (Q) factor
            %   Q = getQualityFactor(obj) returns the quality factor (Q
            %   factor) for the parametric EQ filter. The Q factor is
            %   defined as the center frequency divided by the bandwidth.
        end

        function out=getTunablePropertiesSpecificationImpl(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Re-load state if saved version was locked
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=realizemdl(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
            % Specify initial values for DiscreteState properties
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Default implementation saves all public properties
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=tf(~) %#ok<STOUT>
            %[B,A] = tf(obj) Transfer function
            %   [B,A] = TF(obj) returns the vector of numerator
            %   coefficients B and the vector of denominator coefficients A
            %   for the equivalent transfer function corresponding to the
            %   parametric EQ filter.
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

    end
    properties
        %Bandwidth Filter bandwidth (Hz)
        %   Specify the filter's bandwidth as a finite positive numeric
        %   scalar in Hertz. The bandwidth is measured at the arithmetic
        %   mean between the peak gain in absolute power units and one. The
        %   default is 2205 Hz. This property is tunable.
        Bandwidth;

        %BandwidthCoefficient Bandwidth coefficient
        %   Specify the value that determines the filter's bandwidth as a
        %   finite numeric scalar between 0 and 1. 0 corresponds to the
        %   maximum bandwidth. 1 corresponds to the minimum bandwidth (0
        %   Hz; i.e. an allpass filter). The default is 0.72654. This
        %   property is tunable.
        BandwidthCoefficient;

        %CenterFrequency Equalizer center frequency (Hz)
        %   Specify the filter's center frequency as a finite positive
        %   numeric scalar in Hertz. The default is 11025 Hz. This property
        %   is tunable.
        CenterFrequency;

        %CenterFrequencyCoefficient Center frequency coefficient
        %   Specify the value that determines the filter's center frequency
        %   as a finite numeric scalar between -1 and 1. -1 corresponds to
        %   the minimum center frequency (0 Hz). 1 corresponds to the
        %   maximum center frequency (SampleRate/2 Hz). The default is 0
        %   which corresponds to SampleRate/4 Hz. This property is tunable.
        CenterFrequencyCoefficient;

        %InputDataType Data type of the inputs
        %   This is a private property that stores the data type of the
        %   inputs and it is used to set the data type of all the
        %   DiscreteState properties and the outputs.
        InputDataType;

        %PeakGain Gain (Linear Units)
        %   Specify the peak or dip of the filter in linear units. Values
        %   greater than one correspond to a boost while values less than
        %   one correspond to a dip or cut. The default is 2 (6.0206 dB).
        %   This property is tunable.
        PeakGain;

        %PeakGaindB Gain (dB)
        %   Specify the peak or dip of the filter in decibels. Values
        %   greater than zero correspond to a boost while values less than
        %   zero correspond to a dip or cut. The default is 6.02036dB. This
        %   property is tunable.
        PeakGaindB;

        %QualityFactor Quality factor
        %   Specify the quality factor (Q factor) for the parametric EQ
        %   filter. The default value is 5. This property is tunable.
        QualityFactor;

        % SampleRate Input sample rate (Hz)
        %   Specify the sampling rate of the input in Hertz as a finite
        %   numeric scalar. The default is 44100 Hz.
        SampleRate;

        %Specification Filter specification
        %   Set the specification as one of 'Bandwidth and center
        %   frequency' | 'Quality factor and center frequency' |
        %   'Coefficients'. The default is 'Bandwidth and center
        %   frequency'.
        Specification;

    end
end
