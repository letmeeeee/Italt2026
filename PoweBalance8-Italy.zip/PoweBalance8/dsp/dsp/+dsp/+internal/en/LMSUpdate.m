classdef LMSUpdate< matlab.System
%LMSUpdate Compute weights using LMS adaptive algorithm
%   LMSUPD = dsp.LMSUpdate returns an adaptive LMS update System object,
%   LMSUPD, that computes the filter weights for a given input and error
%   signal using the Least Mean Squares (LMS) algorithm.
%
%   LMSUPD = dsp.LMSUpdate('PropertyName', PropertyValue, ...) returns an
%   LMS update System object, LMSUPD, with each specified property set to
%   the specified value.
%
%   LMSUPD = dsp.LMSUpdate(LEN, 'PropertyName', PropertyValue, ...)
%   returns an LMS update System object, LMSUPD, with the Length property
%   set to LEN, and other specified properties set to the specified values.
%
%   Step method syntax:
%
%   W = step(LMSUPD, X, E) performs the LMS update on the inputs X and E,
%   and returns the estimated filter weights in W. The System object
%   estimates the filter weights needed to minimize the error.
%
%   W = step(LMSUPD, X, E, MU) performs the LMS update on the inputs X, E,
%   and step size MU, when the StepSizeSource property.
%
%   W = step(LMSUPD, X, E, A) performs the LMS update on the inputs X, E,
%   and A as the adaptation control, when the EnableAdaptInput property is
%   true. When A is non-zero, the System object continuously updates the
%   filter weights. When A is zero, the filter weights remain constant.
%
%   W = step(LMSUPD, X, E, R) performs the LMS update on the inputs X, E,
%   and R as a reset signal when the EnableResetInput property is true.
%   When R is non-zero, the System object resets the filter weights and
%   input buffer to their initial values.
%
%   The above operations can be used simultaneously, provided the System
%   object properties are set appropriately. One example of providing all
%   possible inputs and returning all possible outputs is shown below:
%   W = step(LMSUPD, X, E, MU, A, R) performs the LMS update using X and E,
%   with MU as the step size, A as the adaptation control, and R as the
%   reset signal, and returns the filter weights in W.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   LMSUpdate methods:
%
%   step     - See above description for use of this method
%   <a href="matlab:help matlab.System/reset   ">reset</a>    - Reset input buffer and weights to initial conditions
%   release  - Allow property value and input characteristics changes
%   clone    - Create LMSUpdate object with same property values
%   isLocked - Locked status (logical)
%
%   LMSUpdate properties:
%
%   Method            - Method to calculate filter weights
%   Length            - Length of FIR filter weights vector
%   NumFilters        - Number of adaptive filters
%   StepSizeSource    - How to specify adaptation step size
%   StepSize          - Adaptation step size
%   LeakageFactor     - Leakage factor used in Leaky LMS method
%   InitialConditions - Initial conditions of filter weights
%   AdaptiveFilterMode- Specify the adaptive filter behavior to be a tapped delay-line FIR filter or an adaptive linear combiner
%   EnableAdaptInput  - Enable adapt input (conditional weight adaptation)
%   EnableResetInput  - Enable reset input (conditional state reset)
%
%   See also dsp.LMSFilter, dsp.BlockLMSFilter

 
%   Copyright 1995-2022 The MathWorks, Inc.

    methods
        function out=LMSUpdate
        end

        function out=getNumInputsImpl(~) %#ok<STOUT>
            % Specify number of System inputs
        end

        function out=getNumOutputsImpl(~) %#ok<STOUT>
            % Specify number of System outputs
        end

        function out=getTunablePropertiesSpecificationImpl(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isInputComplexityMutableImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Call base class method
        end

        function out=resetImpl(~) %#ok<STOUT>
            % Reset internal INPUT BUFFER
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

        function out=validatePropertiesImpl(~) %#ok<STOUT>
            % Validating the dimensions of the InitialConditions property
        end

    end
    properties
        %AdaptiveFilterMode Adaptive filter mode
        %   Specify the adaptive filter mode as 'Tapped delay-line FIR filter' or
        %   'Adaptive linear combiner'. By default, the value of this property is
        %   'Tapped delay-line FIR filter' and the input must be a scalar. In
        %   this case, the object assumes that the input is a tapped delay line
        %   and keeps track of the buffer internally. When the value of this
        %   property is set to 'Adaptive linear combiner', the input provided to
        %   the step function must be a column vector with number of elements
        %   equal to filter length.
        AdaptiveFilterMode;

        %EnableAdaptInput Enable adapt input
        %   Specify when the System object should adapt the filter weights. By
        %   default, the value of this property is false, and the object
        %   continuously updates the filter weights. When this property is set to
        %   true, an adaptation control input is provided to the step method. If
        %   the value of this input is non-zero, the object continuously updates
        %   the filter weights. If the input is zero, the filter weights remain
        %   at their current value.
        EnableAdaptInput;

        %EnableResetInput Enable reset input
        %   Specify when the System object should reset the filter weights. By
        %   default, the value of this property is false, and the object does not
        %   reset the weights. When this property is set to true, a reset control
        %   input is provided to the step method. If the value of this input is
        %   non-zero, the filter weights and input buffer values are reset to
        %   their initial values.
        EnableResetInput;

        %InitialConditions Initial value of filter weights
        %   Specify the initial values of the filter weights as a scalar or
        %   matrix of size equal to the NumFilters x Length. The default
        %   value of this property is 0.
        InitialConditions;

        %LeakageFactor Leakage factor (0 to 1)
        %   Specify the leakage factor used in Leaky LMS method as a scalar
        %   numeric value between 0 and 1, both inclusive. When the value is less
        %   than 1, the System object implements a leaky LMS method. The default
        %   value of this property is 1, providing no leakage in the adapting
        %   method. This property is tunable.
        LeakageFactor;

        %Length Filter length
        %   Specify the length of filter weights of each adaptive filter as a
        %   positive scalar integer value. The default value of this property is
        %   32.
        Length;

        %Method Algorithm
        %   Specify the method used to calculate filter weights as one of
        %   ['LMS' | 'Normalized LMS' | 'Sign-Error LMS' | 'Sign-Data LMS' |
        %   'Sign-Sign LMS'].
        Method;

        % NumFilters Number of adaptive filters
        %   Specify the number of FIR adaptive filers as a positive scalar
        %   integer. The default value of this property is 1.
        NumFilters;

        %StepSize Step size (mu)
        %   Specify the adaptation step size factor as a scalar non-negative
        %   numeric value. For convergence of the normalized LMS method, the step
        %   size should be greater than 0 and less than 2. The default value of
        %   this property is 0.1. This property is applicable when the
        %   StepSizeSource property is 'Property'. This property is tunable.
        StepSize;

        %StepSizeSource Step size source
        %   Choose how to specify the adaptation step size factor as one of
        %   ['Property' | 'Input port'].
        StepSizeSource;

    end
end
