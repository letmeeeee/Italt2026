classdef PolyphaseFFTBase< dsp.internal.SupportScalarVarSize
% PolyphaseFFTBase Polyphase FFT Filter banks base class

     
    % Copyright 2016-2020 The MathWorks, Inc.

    methods
        function out=PolyphaseFFTBase
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Re-load state if saved version was locked
        end

        function out=poly2coeffs(~) %#ok<STOUT>
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
            % Specify initial values for DiscreteState properties
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Default implementation saves all public properties
        end

        function out=setPolyphaseMatrixFromCustomCoeffs(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

    end
    properties
        %InputDataType Data type of the inputs
        %   This is a private property that stores the data type of the
        %   inputs and it is used to set the data type of all the
        %   DiscreteState properties and the outputs.
        InputDataType;

        %LowpassCoefficients Prototype lowpass filter coefficients
        %   Specify the coefficients of the prototype lowpass filter as a
        %   real or complex row vector. There must be at least one
        %   coefficient per frequency band. If the length of the lowpass
        %   filter is less than the number of frequency bands, the
        %   coefficients will be zero-padded. This property applies when
        %   you set Specification to 'Coefficients'. The default vector of
        %   coefficients is obtained using rcosdesign(0.25,6,8,'sqrt').
        %   This property is tunable.
        LowpassCoefficients;

        %NumTapsPerBand Number of filter taps per frequency band
        %   Specify the number of filter coefficients or taps for each
        %   frequency band. This also corresponds to the number of filter
        %   coefficients per polyphase branch. The total number of filter
        %   coefficients is given by NumTapsPerBand times the number of
        %   frequency bands. This property applies when you set
        %   Specification to 'Number of taps per band and stopband
        %   attenuation'. The default is 12.
        NumTapsPerBand;

        PolyphaseMatrix;

        %Specification Polyphase filter specification
        %   Set the specification as one of 'Number of taps per band and
        %   stopband attenuation' | 'Coefficients'. The default is 'Number
        %   of taps per band and stopband attenuation'.
        Specification;

        States;

        %StopbandAttenuation Stopband attenuation (dB)
        %   Set the stopband attenuation in decibels for the prototype
        %   lowpass filter that is designed. This value controls the
        %   maximum amount of aliasing from one frequency band to the next.
        %   The larger the stopband attenuation, the smaller the passband
        %   ripple. This property applies when you set Specification to
        %   'Number of taps per band and stopband attenuation'. The default
        %   is 80 dB.
        StopbandAttenuation;

        actpmatrix;

        numChannels;

        oldNumFrequencyBands;

        % privNumCoefficients Keep track of the number of coefficients for
        % Specification = 'Coefficients'
        privNumCoefficients;

        privNumFrequencyBands;

    end
end
