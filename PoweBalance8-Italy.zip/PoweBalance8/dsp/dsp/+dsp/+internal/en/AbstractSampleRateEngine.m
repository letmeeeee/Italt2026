classdef AbstractSampleRateEngine< dsp.internal.AbstractSampleRateEngineTemplate
% ABSTRACTSAMPLERATENEGINE  This class controls sample rate functionality

 
%   Copyright 2014-2020 The MathWorks, Inc.

    methods
        function out=AbstractSampleRateEngine
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

    end
    properties
        % SampleRate Input sample rate (Hz)
        %   Specify the sampling rate of the input in Hertz as a finite
        %   numeric scalar.
        SampleRate;

    end
end
