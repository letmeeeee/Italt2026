classdef DigitalFilterFrequencyResponse< matlab.System
%#codegen
    methods
        function out=DigitalFilterFrequencyResponse
            % Support name-value pair arguments when constructing object
        end

        function out=computeResponse(~) %#ok<STOUT>
        end

        function out=getSampleRate(~) %#ok<STOUT>
        end

        function out=getSampleTimeImpl(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
            % Return false if input size cannot change
            % between calls to the System object
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Set properties in object obj to values in structure s
            % Set public properties and states
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
            % this.pFrequencyResponse = [];
            % this.pFrequencyVector = [];
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Set properties in structure s to values in object obj
            % Set public properties and states
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Perform one-time calculations, such as computing constants
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

        function out=validatePropertiesImpl(~) %#ok<STOUT>
        end

    end
    properties
        FFTLength;

        FilterType;

        FrequencyRange;

        NormalizedFrequency;

        NumFilters;

        SampleRate;

        XScale;

        pIsIIR;

        pMaxFFTLength;

        pNumInputs;

    end
end
