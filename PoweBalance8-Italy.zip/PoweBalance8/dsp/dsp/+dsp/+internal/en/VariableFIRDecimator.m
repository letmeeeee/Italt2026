classdef VariableFIRDecimator< dsp.internal.SupportScalarVarSize & dsp.enhancedsim.UpdateSysObjBuildInfo
%VARIABLEFIRDECIMATOR Variable FIR Decimator
%   VFD = dsp.internal.VariableFIRDecimator returns a System object, VFD,
%   which decimates the input using a common filter structure. The
%   decimation factor can vary at each step and has to be a factor of the
%   maximum decimation factor. The filter coefficients correspond to the
%   maximum decimation factor. They are auto computed by default and can be
%   specified externally.
%
%   VFD = dsp.internal.VariableFIRDecimator(Name=Value, ...) returns a
%   Variable FIR Decimator System object, VFD, with each specified
%   property name set to the specified value. You can specify additional
%   name-value pair arguments in any order as (Name1=Value1,...,NameN = ValueN).
%
%   Step method syntax:
%
%   Y = step(VFD, X) decimates the real or complex input signal X using the
%   specified filter to produce the output Y. The System object filters
%   each channel of the input signal independently over time.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   Variable FIR Decimator methods:
%
%   step          - See above description for use of this method
%   release       - Allow property value and input characteristics changes
%   clone         - Create Variable FIR Decimator object with
%                   same property values
%   isLocked      - Locked status (logical)
%   reset         - Reset the internal states to initial conditions
%
%   VariableFIRDecimator properties:
%
%   MaxDecimationFactor      - Maximum decimation factor
%   DecimationFactor         - Decimation factor
%   CoefficientSource        - Coefficient source
%   Coefficients             - Prototype filter coefficients
%
%   % EXAMPLE #1: Decimate the input by a factor of 24 followed by a factor
%   of 6 
%   varFIRDecim = dsp.internal.VariableFIRDecimator(24);
%   x = (0:10)';
%   y = varFIRDecim(x);
%   varFIRDecim.DecimationFactor = 6;
%   y = varFIRDecim(x);
%
%   See also dsp.FIRDecimator, dsp.FIRRateConverter, designMultirateFIR

 
%   Copyright 2022-2023 The MathWorks, Inc.

    methods
        function out=VariableFIRDecimator
            % Support name-value pair arguments when constructing object
        end

        function out=designFilter(~) %#ok<STOUT>
        end

        function out=fvtool(~) %#ok<STOUT>
        end

        function out=getDecimationFactor(~) %#ok<STOUT>
        end

        function out=getInputDataSize(~) %#ok<STOUT>
            % fetch the number of channels
        end

        function out=getMaxDecimationFactor(~) %#ok<STOUT>
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
            % Modify order of display
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isInputComplexityMutableImpl(~) %#ok<STOUT>
            % Return false if input complexity cannot change
            % between calls to the System object
        end

        function out=isInputDataTypeMutableImpl(~) %#ok<STOUT>
            % Return false if input data type cannot change
            % between calls to the System object
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Set properties in object obj to values in structure s
            % Set private and protected properties
        end

        function out=polyphase(~) %#ok<STOUT>
            %p = polyphase(obj) Return polyphase matrix
            %   p = polyphase(obj) returns the polyphase matrix used by the
            %   filter bank. Each row in the matrix corresponds to a
            %   polyphase branch. The number of columns of p corresponds to
            %   the number of filter taps per branch.
        end

        function out=polyphase2coeffs(~) %#ok<STOUT>
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
            % Initialize / reset discrete-state properties
        end

        function out=resetPhaseCounter(~) %#ok<STOUT>
            % If the decimation factor changes between steps,
            % reset the commutator phase.
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setPolyphaseMatrixFromCustomCoeffs(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

        function out=variableFIRDecimatorHalideCG(~) %#ok<STOUT>
        end

        function out=variableFIRDecimatorImpl(~) %#ok<STOUT>
        end

    end
    properties
        % CoefficientSource Coefficient source 
        % Specify the input source for coefficients as "Auto", "Dialog
        % parameter" or "Input port". The default is "Auto".
        CoefficientSource;

        % Coefficients Prototype filter coefficients
        % This property is overwritten when CoefficientSource is set to 'Dialog
        % parameter' or 'Input port'.
        Coefficients;

        % DecimationFactor Decimation factor
        % Specifies the instantaneous decimation factor. This value has to be
        % a factor of MaxDecimationFactor. The default value of this property is 24.
        DecimationFactor;

        % MaxDecimationFactor Maximum decimation factor Specify the maximum
        % decimation factor which is used to compute the polyphase filter
        % structure. Decimation factor must be less than or equal to the
        % maximum decimation factor. The default value of this property is
        % 24.
        MaxDecimationFactor;

        % OutputFrameLength Output signal frame length
        % Specify the output signal frame length as a positive integer.
        % To enable this property set the Specification is "Output frame
        % length". The default is 48.
        OutputFrameLength;

        % Specification Output frame length specification
        % Set the output frame length specification as "Decimation factor"
        % or "Output frame length". The default is "Decimation factor".
        Specification;

    end
end
