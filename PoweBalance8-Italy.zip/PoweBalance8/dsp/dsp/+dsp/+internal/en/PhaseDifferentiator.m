classdef PhaseDifferentiator< matlab.System
%   PhaseDifferentiator Compute phase difference of input
%   H = dsp.internal.PhaseDifferentiator returns a System object, H, that
%   computes the phase difference between consecutive samples of the
%   complex input.
%
%   H = dsp.internal.PhaseDifferentiator('Name', Value, ...) returns a Phase
%   Differentiator System object, H, with each specified property name set
%   to the specified value. You can specify additional name-value pair
%   arguments in any order as (Name1,Value1,...,NameN, ValueN).
%
%   Step method syntax:
%
%   p = step(H, X) computes the phase difference, p, of complex or real
%   input X. Each column of X is a channel. The System object computes the
%   phase difference of each channel of the input signal independently over
%   time.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%
%   PhaseDifferentiator methods:
%
%   step                     - Compute phase difference of input
%   release                  - Allow property value and input 
%                              characteristics changes, and release Phase 
%                              Differentiator resources
%   clone                    - Create Phase Differentiator object with same
%                              property values
%   isLocked                 - Display locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>                    - Reset the states of the Phase Differentiator
%
%   Differentiator properties:
%
%   TreatFramesIndependently - Compute difference only within the frame

    
% Copyright 2014-2020 The MathWorks, Inc.

    methods
        function out=PhaseDifferentiator
        end

        function out=getHeaderImpl(~) %#ok<STOUT>
            % MATLAB System block header
        end

        function out=getIconImpl(~) %#ok<STOUT>
            % MATLAB system block icon
        end

        function out=getNumChannels(~) %#ok<STOUT>
            % GETNUMCHANNELS Return the number of input channels
        end

        function out=getOutputDataTypeImpl(~) %#ok<STOUT>
        end

        function out=getOutputSizeImpl(~) %#ok<STOUT>
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
            % Modify order of display
        end

        function out=isInputComplexityMutableImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=isOutputComplexImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Re-load private properties
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
            % Update phase
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            % Validate inputs to the step method at initialization.
        end

    end
    properties
        % Compute phase difference only within the frame
        % Specify if the phase difference is to be computed only within the
        % frame, as a logical scalar. When this property is set to false,
        % the object returns the phase difference while ignoring boundaries
        % between input frames. If the property is set to true, the object
        % treats each frame of input data independently, and resets the
        % initial sample value to 1+0j each time a new input frame is
        % received. The default of this property is false.
        TreatFramesIndependently;

    end
end
