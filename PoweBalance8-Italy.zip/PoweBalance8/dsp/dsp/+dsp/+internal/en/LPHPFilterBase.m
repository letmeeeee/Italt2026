classdef LPHPFilterBase< dsp.internal.NormalizedSampleRateEngine & dsp.internal.FilterAnalysis
    methods
        function out=LPHPFilterBase
        end

        function out=convertToDFILT(~) %#ok<STOUT>
            % Convert the System object to a DFILT object for analysis
        end

        function out=fdhdltool(~) %#ok<STOUT>
            %   FDHDLTOOL(FO, nt) launches the Generate HDL dialog that lets you
            %   customize and generate Verilog or VHDL code and test benches for
            %   the filter System object, FO. You have to call FDHDLTOOL
            %   again if you make changes in the filter, FO, in the command line.
            %
            %   The main dialog and two subordinate dialogs provide access to many
            %   options for customizing the generated filter and test bench code.
            %
            %   The Generate HDL main dialog categorizes options in two frames:
            %
            %   * HDL Filter - Options you are most likely to customize at least once:
            %   language selection, name and location of generated files, reset
            %   specifications, and optimizations.
            %
            %   * Test bench types - Options for naming and specifying the type of test
            %   bench files to generate, and specific types of stimuli the test benches
            %   are to apply.
            %
            %   EXAMPLE:
            %   fo  = dsp.LowpassFilter;
            %   inT = numerictype(1,16,15);
            %   fdhdltool(fo, inT)
        end

        function out=generatehdl(~) %#ok<STOUT>
            %   GENERATEHDL(FO, 'InputDataType', nt) automatically generates VHDL
            %   or Verilog code for the filter System object, FO. The default
            %   language is VHDL; to generate Verilog, supply the
            %   property/value pair 'TargetLanguage','Verilog'. The file is written to
            %   the HDL source directory which defaults to 'hdlsrc' under the
            %   current directory. This directory will be created if necessary.
            %
            %   GENERATEHDL(FO, PARAMETER1, VALUE1, PARAMETER2, VALUE2, ...)
            %   generates the HDL code with parameter/value pairs. Valid properties
            %   and values for GENERATEHDL are listed in the Filter Design HDL
            %   Coder documentation section "Property Reference."
            %
            %   EXAMPLE:
            %   fo  = dsp.LowpassFilter;
            %   inT = numerictype(1,16,15);
            %   generatehdl(fo, 'InputDataType', inT)
        end

        function out=getFilter(~) %#ok<STOUT>
            %F = getFilter(obj) get underlying FIR or Biquad filter
            %   F = getFilter(obj) returns the underlying filter F
            %   used to implement the filter designed for the given
            %   specifications.
            %
            %   F = getFilter(obj, inNT) returns the underlying filter F
            %   used to implement the filter designed for the given
            %   specifications for the input numerictype inNT.
        end

        function out=getInputNamesImpl(~) %#ok<STOUT>
        end

        function out=getOutputDataTypeImpl(~) %#ok<STOUT>
        end

        function out=getOutputNamesImpl(~) %#ok<STOUT>
        end

        function out=getOutputSizeImpl(~) %#ok<STOUT>
        end

        function out=getSampleRate(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isOutputComplexImpl(~) %#ok<STOUT>
        end

        function out=isOutputFixedSizeImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=needToDesignFilters(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
            % Release the filter
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Default implementation saves all public properties
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
            % Implement algorithm. Calculate y as a function of
            % input u and discrete states.
        end

        function out=supportsMultipleInstanceImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

    end
    methods (Abstract)
        % Abstract method. Children objects re-define this method.
        computeFIRCoefficients;

        designFilter;

    end
    properties
        %CoefficientsDataType Coefficients word and fraction lengths
        %   Specify the coefficients fixed-point type as a signed
        %   numerictype object. The default value of this property is
        %   numerictype(1,16).
        %
        %   See also numerictype.
        CoefficientsDataType;

        %DesignForMinimumOrder Design minimum order filter
        %   When you set this property to true, the object designs filters
        %   with the minimum order that meets the passband frequency,
        %   stopband frequency, passband ripple, and stopband attenuation
        %   specifications that you set using the corresponding properties.
        %   When you set this property to false, the object designs filters
        %   with order that you specify in the FilterOrder property. This
        %   filter design meets the passband frequency, passband ripple,
        %   and stopband attenuation specifications that you set using the
        %   respective properties. Specify it as a logical scalar. The
        %   default value of this property is true.
        DesignForMinimumOrder;

        FilterObj;

        %FilterOrder Filter order
        %   Specify the order for the designed filter, as a positive
        %   integer scalar. This property applies when you set the
        %   DesignForMinimumOrder property to false. The default value of
        %   this property is 50.
        FilterOrder;

        %FilterType Filter type
        %   Set the specification as one of 'FIR' | 'IIR'. The default is
        %   'FIR'.
        FilterType;

        IsFilterDesigned;

        NumChannels;

        %PassbandRipple Maximum passband ripple (dB)
        %   Specify the maximum allowed ripple in the passband of the
        %   filter response, as a positive real scalar in decibels (dB).
        %   The default value of this property is 0.1 dB.
        PassbandRipple;

        %RoundingMethod Rounding method for fixed-point operations 
        %   Specify the rounding method for output as one of ['Ceiling' |
        %   'Convergent' | 'Floor' | 'Nearest' | 'Round' | 'Simplest' |
        %   'Zero']. The default value of this property is 'Floor'.
        RoundingMethod;

        % SampleRate Input sample rate (Hz)
        %   Specify the sampling rate of the input in Hertz as a finite
        %   numeric scalar. the default is 44100 Hz.
        SampleRate;

        %StopbandAttenuation Minimum stopband attenuation (dB)
        %   Specify the attenuation to be achieved in the stopband of the
        %   designed filter response, as a positive real scalar in
        %   decibels (dB). The default value of this property is 80 dB.
        StopbandAttenuation;

    end
end

 
    % Copyright 2014-2020 The MathWorks, Inc.

