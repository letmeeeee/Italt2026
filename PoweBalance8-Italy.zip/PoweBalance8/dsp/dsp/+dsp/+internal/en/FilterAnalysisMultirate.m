classdef FilterAnalysisMultirate< dsp.internal.FilterAnalysis
%FilterAnalysisMultirate Baseclass for multirate filter System object analysis

   
  %   Copyright 2011-2020 The MathWorks, Inc.

    methods
        function out=FilterAnalysisMultirate
        end

        function out=freqrespest(~) %#ok<STOUT>
        end

        function out=freqrespopts(~) %#ok<STOUT>
        end

        function out=isNLMSupported(~) %#ok<STOUT>
        end

        function out=noisepsd(~) %#ok<STOUT>
        end

        function out=noisepsdopts(~) %#ok<STOUT>
        end

        function out=polyphase(~) %#ok<STOUT>
            %Polyphase decomposition of System object
            %   P = polyphase(H) returns the polyphase matrix of the filter
            %   System object, H. The i-th row of the matrix P represents the
            %   i-th subfilter.
            %
            %   P = polyphase(H,'Arithmetic',ARITH,...) analyzes the filter
            %   System object, H, based on the arithmetic specified in the ARITH
            %   input. ARITH can be set to one of 'double', 'single', or 'fixed'.
            %   The analysis tool assumes a double precision filter when the
            %   arithmetic input is not specified and the filter System object is
            %   in an unlocked state.
            %
            %   polyphase(H) called with no outputs launches the Filter
            %   Visualization Tool (FVTool) with all the polyphase subfilters to
            %   allow analyses of each component individually.
        end

        function out=ss(~) %#ok<STOUT>
        end

    end
end
