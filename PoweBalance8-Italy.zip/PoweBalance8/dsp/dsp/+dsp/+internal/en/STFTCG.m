classdef STFTCG< handle & matlab.mixin.internal.indexing.Paren
% This class is used for code generation of dsp.STFT

 
% Copyright 2018-2020 The MathWorks, Inc.

    methods
        function out=STFTCG
        end

        function out=getFrequencyVector(~) %#ok<STOUT>
        end

        function out=matlabCodegenFromRedirected(~) %#ok<STOUT>
        end

        function out=matlabCodegenToRedirected(~) %#ok<STOUT>
        end

        function out=release(~) %#ok<STOUT>
        end

        function out=reset(~) %#ok<STOUT>
        end

        function out=setup(~) %#ok<STOUT>
        end

        function out=step(~) %#ok<STOUT>
        end

    end
    properties
        FFTLength;

        FrequencyRange;

        OverlapLength;

        % Same interface as dsp.STFT
        Window;

    end
end
