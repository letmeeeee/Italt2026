classdef ISTFTCG< handle & matlab.mixin.internal.indexing.Paren
% This class is used for code generation of dsp.ISTFT

 
% Copyright 2018-2020 The MathWorks, Inc.

    methods
        function out=ISTFTCG
        end

        function out=matlabCodegenFromRedirected(~) %#ok<STOUT>
        end

        function out=matlabCodegenToRedirected(~) %#ok<STOUT>
        end

        function out=release(~) %#ok<STOUT>
        end

        function out=reset(~) %#ok<STOUT>
        end

        function out=setup(~) %#ok<STOUT>
        end

        function out=step(~) %#ok<STOUT>
        end

    end
    properties
        ConjugateSymmetricInput;

        FrequencyRange;

        OverlapLength;

        WeightedOverlapAdd;

        % Same interface as dsp.ISTFT
        Window;

    end
end
