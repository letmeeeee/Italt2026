classdef FIRHalfbandBase< dsp.internal.NormalizedSampleRateEngine & dsp.internal.FilterAnalysisMultirate
%FIRHALFBANDBASE Abstract base class for FIRHalfbandDecimator and
% FIRHalfbandInterpolator System objects.
% dsp.FIRHalfbandDecimator and dsp.FIRHalfbandInterpolator inherit
% from this class.

     
    % Copyright 2014-2021 The MathWorks, Inc.

    methods
        function out=FIRHalfbandBase
            % Support name-value pair arguments
        end

        function out=cgConstructFixptHFilter(~) %#ok<STOUT>
        end

        function out=constructFltptHFilter(~) %#ok<STOUT>
        end

        function out=convertToDFILT(~) %#ok<STOUT>
            % Convert the System object to a mfilt object for analysis
        end

        function out=designFilter(~) %#ok<STOUT>
        end

        function out=getSampleRate(~) %#ok<STOUT>
        end

        function out=infoImpl(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isInputComplexityMutableImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=mlConstructFixptHFilter(~) %#ok<STOUT>
        end

        function out=needToDesignFilters(~) %#ok<STOUT>
            % Filter analysis may have been supported previously.
            % Clear previous FVTool (filter analysis) meta-data from
            % prior filter design properties here, to avoid UI issues.
        end

        function out=postProcessSampleRate(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupHFilterForCodeGen(~) %#ok<STOUT>
            % Only use this for CODEGEN modes and WHEN LOCKED
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            % Check if the input is either numeric or embedded.fi with
            % finite values
        end

    end
    properties
        Coefficients;

        %CoefficientsDataType Coefficients word and fraction lengths
        %   Specify the coefficients fixed-point type as a signed
        %   numerictype object. The default value of this property is
        %   numerictype(1,16).
        %
        %   See also numerictype.
        CoefficientsDataType;

        %DesignMethod Design method
        %   Specify the filter design method as 'Auto'| 'Equiripple' |
        %   'Kaiser'. When DesignMethod is set to 'Auto', the filter is
        %   designed using Equiripple or Kaiser window method, based on the
        %   filter design parameters. This property applies when the
        %   Specification is either 'Transition width and stopband
        %   attenuation' | 'Filter order and stopband attenuation' |
        %   'Filter order and transition width' . The default is 'Auto'.
        DesignMethod;

        %FilterOrder Filter order
        %   Specify the order for the designed FIR Halfband filter, as a
        %   finite even positive scalar. This property applies when the
        %   Specification is either 'Filter order and transition width' |
        %   'Filter order and stopband attenuation'. The default value of
        %   this property is 52.
        FilterOrder;

        HDelay;

        HFilter;

        IsFilterDesigned;

        IsHalfOrderOdd;

        NumChannels;

        %Numerator -  defined in FIRHalfbandDecimator/Interpolator
        Numerator;

        %RoundingMethod Rounding method for fixed-point operations at
        %   output
        %   Specify the rounding method for output as one of 'Ceiling' |
        %   'Convergent' | 'Floor' | 'Nearest' | 'Round' | 'Simplest' |
        %   'Zero'. The default value of this property is 'Floor'.
        RoundingMethod;

        % SampleRate Input sample rate (Hz)
        %   Specify the sampling rate of the input in Hertz as a finite
        %   numeric scalar. the default is 44100 Hz.
        SampleRate;

        %Specification Filter specification
        %   Specify design parameters to design the FIR Halfband filter
        %   using equiripple or Kaiser window filter design method, or
        %   specify the Numerator coefficients directly. When you set
        %   'Specification' to one of 'Transition width and stopband
        %   attenuation' | 'Filter order and stopband attenuation' |
        %   'Filter order and transition width', you choose two of the
        %   three available design parameters to design the filter. When
        %   you set 'Specification' to 'Coefficients', you can specify the
        %   halfband filter coefficients directly through the 'Numerator'
        %   property. The default of this property is 'Transition width and
        %   stopband attenuation'.
        Specification;

        %StopbandAttenuation Stopband attenuation (dB)
        %   Specify the stopband attenuation for the designed FIR Halfband
        %   filter in dB, as a finite positive scalar. This
        %   property applies when the Specification is either
        %   'Filter order and stopband attenuation' |
        %   'Transition width and stopband attenuation'.
        %   The default value of this property is 80dB.
        StopbandAttenuation;

        % pNumeratorDims   Cached numerator dimensions
        pNumeratorDims;

        % pProtoInputType  Input numerictype
        pProtoInputType;

        % pPrototypeCoeffs Coefficients vector (double precision)
        pPrototypeCoeffs;

        pSR;

        pfimath;

    end
end
