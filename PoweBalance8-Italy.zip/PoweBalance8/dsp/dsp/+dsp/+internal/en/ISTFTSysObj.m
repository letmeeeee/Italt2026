classdef ISTFTSysObj< matlab.System
% This class is used for code generation of dsp.ISTFT

 
    % Copyright 2018-2022 The MathWorks, Inc.

    methods
        function out=ISTFTSysObj
        end

        function out=calculateFFTLength(~) %#ok<STOUT>
            % Calculate FFT length based on the current input and frequency
            % range
        end

        function out=calculateNumFrequencySamples(~) %#ok<STOUT>
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
        end

        function out=isOneSided(~) %#ok<STOUT>
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

    end
    properties
        ConjugateSymmetricInput;

        FrequencyRange;

        OverlapLength;

        WeightedOverlapAdd;

        Window;

    end
end
