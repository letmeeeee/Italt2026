classdef AsyncBuffercgHelper< matlab.System
%AsyncBuffercgHelper Codegen class for dsp.AsyncBuffer

     
    % Copyright 2016-2021 The MathWorks, Inc.

    methods
        function out=AsyncBuffercgHelper
        end

        function out=infoImpl(~) %#ok<STOUT>
            %INFO Get cumulative overrun and underrun
            %   CumulativeOverrun - Number of samples overrun per channel since
            %       last call to reset. The number of samples overrun is the
            %       number of unread samples overwritten.
            %
            %   CumulativeUnderrun - Number of samples underrun per channel
            %       since last call to reset. Underrun occurs if you attempt to
            %       read more samples than available.
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Re-load state if saved version was locked
            % Casts for backwards compatibility before R2017b.
        end

        function out=peek(~) %#ok<STOUT>
            %PEEK Read from buffer without changing the number of unread 
            %     samples
            % out = peek(Q) returns all unread samples in buffer.
            %
            % out = peek(Q,NumRows) returns NumRows samples from each
            %   channel (column) of buffer. If the requested number of
            %   samples is greater than the number of unread samples, the
            %   output is zero-padded.
            %
            % out = peek(Q,NumRows,Overlap) returns NumRows samples from
            %   each channel and overlaps previously read samples by
            %   Overlap. The total number of samples read is NumRows *
            %   (number of channels). The total number of new samples read
            %   is (NumRows - Overlap) * (number of channels). If the
            %   overlap portion read contains samples that are
            %   overwritten, and are therefore not contiguously written,
            %   the output is zero-padded.
            %
            % [out,nUnderrun] = peek(Q,...) additionally returns the
            %   number of rows zero-padded if underrun occurred. Underrun
            %   occurs if you attempt to read more samples than available.
            %   Samples zero-padded in overlapped portions are not counted
            %   as underrun.
            %
            % % Example: Peek at contents of buffer
            % % Create AsyncBuffer object
            %   Q = dsp.AsyncBuffer;
            % 
            % % Create input signal
            % signal = (1:100).';
            % 
            % %% Write Signal to buffer
            % write(Q,signal);
            % 
            % %% Peek at first 3 samples
            % out1  = peek(Q,3); % out1 = [1; 2; 3];
            % 
            % %% Read first 50 samples
            % out2  = read(Q,50); % out2 = (1:50).';
            % 
            % %% Now peek again at first 3 samples
            % out1  = peek(Q,3); % out1 = [51; 52; 53];
            % 
            % %% Read remaining samples
            % out2  = read(Q); % out2 = (51:100).';
        end

        function out=read(~) %#ok<STOUT>
            %READ Read from buffer
            % out = read(Q) returns all unread samples in buffer.
            %
            % out = read(Q,NumRows) returns NumRows samples from each
            %   channel (column) of buffer. If the requested number of
            %   samples is greater than the number of unread samples, the
            %   output is zero-padded.
            %
            % out = read(Q,NumRows,Overlap) returns NumRows samples from
            %   each channel and overlaps previously read samples by
            %   Overlap. The total number of samples read is NumRows *
            %   (number of channels). The total number of new samples read
            %   is (NumRows - Overlap) * (number of channels). If the
            %   overlap portion read contains samples that are
            %   overwritten, and are therefore not contiguously written,
            %   the output is zero-padded.
            %
            % [out,nUnderrun] = read(Q,...) additionally returns the
            %   number of rows zero-padded if underrun occurred. Underrun
            %   occurs if you attempt to read more samples than available.
            %   Samples zero-padded in overlapped portions are not counted
            %   as underrun.
        end

        function out=releaseImpl(~) %#ok<STOUT>
            % The public dependent property NumUnreadSamples depends on the
            % read and write pointers, so they are reset during release
            % since they are no longer visible.
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

        function out=write(~) %#ok<STOUT>
            %WRITE Write to buffer
            % nOverrun = write(Q,x) writes the samples, x, to the
            %   buffering object, Q. It also returns the number of samples
            %   overrun in the current call to write. The number of samples
            %   overrun is the number of unread samples overwritten.
            % Write properties to local variables -------------------------
        end

    end
    properties
        Cache;

        %Capacity Number of writable/readable samples per channel in buffer
        % The default is 192000.
        Capacity;

        CumulativeOverrun;

        CumulativeUnderrun;

        %NumUnreadSamples Number of unread samples per channel in buffer
        % The total number of unread samples in the buffer is
        % NumUnreadSamples*(number of channels). This is a read-only
        % property.
        NumUnreadSamples;

        ReadPointer;

        WritePointer;

        isInitialized;

    end
end
