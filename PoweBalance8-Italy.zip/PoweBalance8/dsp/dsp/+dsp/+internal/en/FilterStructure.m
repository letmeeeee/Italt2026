classdef FilterStructure< dsp.internal.FilterAnalysis & dsp.internal.FilterCodeGenerator & matlab.System
%FilterStructure Baseclass for dsp.FilterCascade and dsp.ParallelFilter

   
%   Copyright 2023 The MathWorks, Inc.

    methods
        function out=FilterStructure
        end

        function out=checkFilterAndClearMetadata(~) %#ok<STOUT>
            %Checks filter type and clears fdesign metadata
        end

        function out=coeffs(~) %#ok<STOUT>
            %COEFFS Returns the filter System object coefficients in a structure
            %   S = coeffs(filt) Returns the coefficients of filter System object, filt,
            %   in the structure S.
            %
            %   S = coeffs(filt,'Arithmetic',ARITH,...) analyzes the filter System
            %   object, filt, based on the arithmetic specified in the ARITH input.
            %   ARITH can be set to one of 'double', 'single', or 'fixed'. The
            %   analysis tool assumes a double precision filter when the arithmetic
            %   input is not specified and the filter System object is in an
            %   unlocked state. The coeffs method returns the quantized filter
            %   coefficients when ARITH is set to 'single' or 'fixed'.
        end

        function out=getNumInputsImpl(~) %#ok<STOUT>
            % FilterCascade objects expect a single input
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
            % FilterCascade objects allow mutable inputs by default. If
            % any of the stages rejects mutable inputs, it will error out.
        end

        function out=isequal(~) %#ok<STOUT>
        end

        function out=releaseChildren(~) %#ok<STOUT>
            %releaseChildren Release the locked state of all branches/stages
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            % cache the input data type
        end

        function out=validatePropertiesImpl(~) %#ok<STOUT>
        end

    end
end
