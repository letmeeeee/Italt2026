classdef SpectrumEstimatorBase< dsp.internal.SampleRateEngine
%SpectrumEstimatorBase Abstract base class for spectrum estimation
%   dsp.spectrumEstimator and dsp.CrossSpectrumEstimator inherit from this 
%   base class.

 
%   Copyright 2013-2021 The MathWorks, Inc.

    methods
        function out=SpectrumEstimatorBase
            %SpectrumEstimatorBase   Construct the SpectrumEstimatorBase class.
        end

        function out=computeFFT(~) %#ok<STOUT>
            % Compute FFT
        end

        function out=computeOutput(~) %#ok<STOUT>
            % Compute periodogram of new segment
        end

        function out=computeRBW(~) %#ok<STOUT>
            % Use input sample rate
        end

        function out=crossValidateProperties(~) %#ok<STOUT>
        end

        function out=disallowContinuousSampleTime(~) %#ok<STOUT>
        end

        function out=fixFFTLength(~) %#ok<STOUT>
            % Some objects inheriting from this class may wish to fix an FFTLength
            % that is too short
        end

        function out=getActualFFTLen(~) %#ok<STOUT>
        end

        function out=getDatatype(~) %#ok<STOUT>
        end

        function out=getExponentialAverage(~) %#ok<STOUT>
        end

        function out=getFrequencyVector(~) %#ok<STOUT>
            % getFrequencyVector Get the vector of frequencies at which the spectrum 
            %   is estimated, in Hz. 
            %   If you set the FrequencyRange to 'onesided' and the FFT length, 
            %   NFFT, is even, the frequency vector is of length NFFT/2+1 and it 
            %   covers the interval [0,SampleRate/2]. If you set the FrequencyRange 
            %   to 'onesided' and NFFT is odd, the frequency vector is of length 
            %   (NFFT+1)/2 and it covers the interval [0,SampleRate/2).
            %   If you set the FrequencyRange to 'twosided', the frequency vector is 
            %   of length NFFT and it covers the interval [0, SampleRate). 
            %   If you set the FrequencyRange to 'centered', the frequency vector is 
            %   of length NFFT and it covers the range (-SampleRate/2, SampleRate/2] 
            %   for even length NFFT, and (-SampleRate/2, SampleRate/2) for odd 
            %   length NFFT.
        end

        function out=getNumOutputsImpl(~) %#ok<STOUT>
        end

        function out=getNumberOfChannels(~) %#ok<STOUT>
        end

        function out=getOutputDataTypeImpl(~) %#ok<STOUT>
        end

        function out=getOutputSizeImpl(~) %#ok<STOUT>
        end

        function out=getPeriodogramMatrixAverage(~) %#ok<STOUT>
        end

        function out=getRBW(~) %#ok<STOUT>
            % getRBW Get the resolution bandwidth of the Spectrum, in Hz. 
            %   The resolution bandwidth, RBW, is the smallest positive frequency, 
            %   or frequency interval, that can be resolved. It is equal to 
            %   ENBW * SampleRate/ L, where L is the input length, and ENBW is the
            %   two-sided equivalent noise bandwidth of the window (in Hz). For
            %   example, if SampleRate = 100, L = 1024, and Window = 'Hann', 
            %   RBW =  enbw(hann(1024)) * 100 / 1024
        end

        function out=getSampleRate(~) %#ok<STOUT>
        end

        function out=getTunablePropertiesSpecificationImpl(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isInputComplexityMutableImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
            % The segment length depends on the input frame size, so variable-size
            % inputs are not allowed.
        end

        function out=isOutputFixedSizeImpl(~) %#ok<STOUT>
        end

        function out=isRunningAverage(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=preConvertAndScale(~) %#ok<STOUT>
            %convertAndScale Convert to one sided and center DC if needed, scale by
            %Fs to convert to density
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
            % Reset the running average counter and index
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Get the segment length and the number of channels from the input.
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=supportsMultipleInstanceImpl(~) %#ok<STOUT>
        end

        function out=updatePeriodogramMatrix(~) %#ok<STOUT>
            % Do running average with previous numAverage values
            % Do not include initial zero columns on the averages
        end

        function out=validateForgettingFactor(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

        function out=windowData(~) %#ok<STOUT>
            % Multiply input by the window vector
        end

    end
    methods (Abstract)
        % Abstract method. Children objects redefine this method.
        computeWindowFFT;

        convertAndScale;

        initializeSpectrumCache;

    end
    properties
        %AveragingMethod Averaging method
        %   Specify the averaging method as 'Running' or 'Exponential'. In the
        %   running averaging method, the object computes an equally weighted
        %   average of a specified number of spectrum estimates defined by the
        %   'SpectralAverages' property. In the exponential method, the object
        %   computes the average over samples weighted by an exponentially
        %   decaying forgetting factor. The default is 'Running'.
        AveragingMethod;

        %FFTLength FFT length
        %   Specify the length of the FFT that the Spectrum Estimator uses to
        %   compute spectral estimates as a positive, integer scalar. This
        %   property applies when you set the FFTLengthSource property to
        %   'Property'. The default is 128.
        FFTLength;

        %FFTLengthSource Source of the FFT length value
        %   Specify the source of the FFT length value as one of 'Auto' |
        %   'Property'. The default is 'Auto'. When you set this property to
        %   'Auto' the Spectrum Estimator sets the FFT length to the input frame
        %   size. When you set this property to 'Property' then you specify the 
        %   number of FFT points using the FFTLength property.
        FFTLengthSource;

        %ForgettingFactor Forgetting factor
        %   Specify the exponential weighting forgetting factor as a scalar value
        %   greater than zero and smaller than or equal to one. This property
        %   applies when 'AveragingMethod' is equal to 'Exponential'. The default
        %   is 0.9. This property is tunable.
        ForgettingFactor;

        %FrequencyRange Frequency range of the spectrum estimate
        %   Specify the frequency range of the spectrum estimator as one 
        %   of 'twosided' | 'onesided' | 'centered'. 
        %   If you set the FrequencyRange to 'onesided', the spectrum estimator 
        %   computes the one-sided spectrum of real input signals. When the FFT 
        %   length, NFFT, is even, the spectrum estimate length is NFFT/2+1 and 
        %   is computed over the interval [0,SampleRate/2]. If NFFT is odd, the 
        %   length of the spectrum estimate is equal to (NFFT+1)/2 and the 
        %   interval is [0,SampleRate/2).
        %   If you set the FrequencyRange to 'twosided', the spectrum estimate
        %   computes the two-sided spectrum of complex or real inputs signals. 
        %   The length of the spectrum estimate is equal to NFFT and is computed 
        %   over [0, SampleRate). 
        %   If you set the FrequencyRange to 'centered', the spectrum estimate 
        %   computes the centered two-sided spectrum of complex or real 
        %   input signals. The length of the spectrum estimate is equal to NFFT 
        %   and is computed over (-SampleRate/2, SampleRate/2] and 
        %   (-SampleRate/2, SampleRate/2) for even and odd length NFFT, 
        %   respectively. 
        %   The default is 'twosided'
        FrequencyRange;

        %SampleRate Input sample rate (Hz)
        %   Specify the sampling rate of the input in Hertz as a finite
        %   numeric scalar. the default is 1 Hz.
        SampleRate;

        %SidelobeAttenuation Sidelobe attenuation of window (dB)
        %   Specify the sidelobe attenuation of the window as a real, positive
        %   scalar in decibels (dB). This property applies when you set the 
        %   Window property to 'Chebyshev' or 'Kaiser'. The default is 60 dB.
        SidelobeAttenuation;

        %SpectralAverages Number of spectral averages
        %   Specify the number of spectral averages as a positive, integer
        %   scalar. The Spectrum Estimator computes the current power spectrum
        %   estimate by averaging the last N power spectrum estimates, where N is
        %   the number of spectral averages defined in the SpectralAverages
        %   property. This property applies when 'AveragingMethod' is equal to
        %   'Running'. The default is 8.
        SpectralAverages;

        %Window Window function
        %   Specify a window function for the spectral estimator as one of
        %   'Rectangular' | 'Chebyshev' | 'Flat Top' | 'Hamming' | 'Hann' |
        %   'Kaiser'. The default is 'Hann'.
        Window;

        pENBWFactor;

        % Cache cast forgetting factor
        pForgettingFactor;

        %pNFFT Actual FFT length
        pNFFT;

        %pPeriodogramMatrix 3D matrix containing the last SpectralAverages
        %periodograms in each column. The third dimension contains matrices for
        %each input channel. So pPeriodogramMatrix(:,:,i) contains the
        %periodograms for the i-th channel.
        pPeriodogramMatrix;

        %pPreviousAvgSpectrum 2D matrix containing the last exponential average
        %computed for each channel.
        pPreviousAvgSpectrum;

        %pPreviousWeight scalar containing the previous weight used exponential
        %averaging
        pPreviousWeight;

    end
end
