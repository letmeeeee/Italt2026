classdef PartitionOA< dsp.internal.PartitionOAOSBase
% PartitionOA Partitioned overlap-add filter.
% This class is used in dsp.FrequencyDomainFIRFilter

     
    % Copyright 2017-2022 The MathWorks, Inc.

    methods
        function out=PartitionOA
        end

        function out=computeOutput(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

    end
end
