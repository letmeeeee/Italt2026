classdef FilterCodeGenerator< handle
%FilterCodeGenerator Generate MATLAB script from dsp.ParallelFilter or dsp.FilterCascade objects

 
%   Copyright 2023 The MathWorks, Inc.

    methods
        function out=FilterCodeGenerator
        end

        function out=genHeaderString(~) %#ok<STOUT>
        end

        function out=generateFilterCodeImpl(~) %#ok<STOUT>
        end

    end
end
