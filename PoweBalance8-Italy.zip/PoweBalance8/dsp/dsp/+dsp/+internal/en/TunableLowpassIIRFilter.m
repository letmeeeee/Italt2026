classdef TunableLowpassIIRFilter< dsp.internal.TunableLowpassHighpassIIRFilter
% TunableLowpassIIRFilter

 
%   Copyright 2022-2023 The MathWorks, Inc.

    methods
        function out=TunableLowpassIIRFilter
        end

        function out=designFilter(~) %#ok<STOUT>
        end

    end
end
