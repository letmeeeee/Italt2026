classdef DigitalConverterBase< dsp.internal.SampleRateEngine
%dsp.internal.DigitalConverterBase Baseclass for the DigitalDownConverter and
%DigitalUpconverter classes.

     
    %   Copyright 2010-2022 The MathWorks, Inc.

    methods
        function out=DigitalConverterBase
        end

        function out=callPlotMethod(~) %#ok<STOUT>
            % Call either fvtool or visualizeFilterStages of the filter designer
            % object. The plotMethod input can be 'fvtool' or 'visualizeFilterStages'.
            % Input varargin contains other arguments that can be passed to fvtool.
        end

        function out=crossValidateProperties(~) %#ok<STOUT>
            % Check that sample rate at oscillator input is at least twice the
            % oscillator frequency
        end

        function out=designFilters(~) %#ok<STOUT>
            % Check the validity of inputArith and then design filters if a design
            % is not available or if the filters must be redesigned for a different
            % arithmetic.
        end

        function out=designOscillator(~) %#ok<STOUT>
            % Design a sine wave generator or an NCO
        end

        function out=fvtool(~) %#ok<STOUT>
            %fvtool Visualize response of filter cascade
            %   fvtool(H) plots the magnitude response of the cascade of
            %   filters. By default, the object plots the cascade response
            %   up to the second CIC null frequency (or to the first when
            %   only one CIC null exists). The method plots a mask based on
            %   the filter specifications.
            %
            %   fvtool(H,..,'Arithmetic',ARITH,...) specifies the
            %   arithmetic of the filter cascade. You set input ARITH to
            %   'double', 'single', or 'fixed-point'. When object H is in
            %   an unlocked state you must specify the arithmetic. When
            %   object H is in a locked state the arithmetic input is
            %   ignored.
            %
            %   fvtool(H,..., PROP1, VALUE1,PROP2,VALUE2, etc.) launches
            %   FVTool and sets the specified FVTool properties to the
            %   specified values.
            %
            %  See also visualizeFilterStages.
        end

        function out=getNumOutputsImpl(~) %#ok<STOUT>
        end

        function out=groupDelay(~) %#ok<STOUT>
            %groupDelay Group delay of filter cascade
            %   D = groupDelay(H,N) returns a vector of group delays, D,
            %   evaluated at N frequency points equally spaced around the
            %   upper half of the unit circle. If you don't specify N, it
            %   defaults to 8192.
            %
            %   [D,F] = groupDelay(H,N) returns a vector of frequencies at
            %   which the group delay has been computed.
        end

        function out=isInputComplexityMutableImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=loadSubObjects(~) %#ok<STOUT>
        end

        function out=parseArithmetic(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setInputOutputTypes(~) %#ok<STOUT>
            % Cache data types of inputs and outputs
        end

        function out=supportsMultipleInstanceImpl(~) %#ok<STOUT>
        end

        function out=validatePropertiesImpl(~) %#ok<STOUT>
        end

        function out=visualizeFilterStages(~) %#ok<STOUT>
            %visualizeFilterStages Display response of filter stages
            %   visualizeFilterStages(H) plots the magnitude response of
            %   the filter stages and of the cascade response. The method
            %   plots a mask based on the filter specifications. By
            %   default, the object plots the response of the filters up to
            %   the second CIC null frequency (or to the first when only
            %   one CIC null exists).
            %
            %   visualizeFilterStages(H,'Arithmetic',ARITH) specifies the
            %   arithmetic of the filter stages. You set input ARITH to
            %   'double', 'single', or 'fixed-point'. When object H is in
            %   an unlocked state you must specify the arithmetic. When
            %   object H is in a locked state the arithmetic input is
            %   ignored.
            %
            %   hfvt = visualizeFilterStages(H) returns a handle to an
            %   FVTool object.
        end

    end
    properties
        %Bandwidth Two-sided bandwidth of input signal (Hz)
        %   Set this property to a positive, integer scalar. The object
        %   sets the passband frequency of the cascade of filters to
        %   one-half of the value that you specify in the Bandwidth
        %   property. The default is 200e3 Hertz.
        Bandwidth;

        % CustomOutputDataType Fixed-point data type of output
        %   Specify the output fixed-point type as a scaled numerictype
        %   object with a Signedness of Auto or Signed. This property
        %   applies when you set the OutputDataType property to 'Custom'.
        %   The default is numerictype([],16,15).
        %
        %   See also numerictype.
        CustomOutputDataType;

        %Dither Dither control for NCO
        %   When you set this property to true, a number of dither bits
        %   specified in the NumDitherBits property will be used to apply
        %   dither to the NCO signal. This property applies when you set
        %   the Oscillator property to 'NCO'. The default is true.
        %
        %   See also dsp.NCO.
        Dither;

        %NumAccumulatorBits Number of NCO accumulator bits
        %   Specify this property as an integer scalar in the range [1
        %   128]. This property applies when you set the Oscillator
        %   property to 'NCO'. The default is 16.
        %
        %   See also dsp.NCO.
        NumAccumulatorBits;

        %NumDitherBits Number of NCO dither bits
        %   Specify this property as an integer scalar smaller than the
        %   number of accumulator bits that you specify in the
        %   NumAccumulatorBits property. This property applies when you set
        %   the Oscillator property to 'NCO' and the Dither property to
        %   true. The default is 4.
        %
        %   See also dsp.NCO.
        NumDitherBits;

        %NumQuantizedAccumulatorBits Number of NCO quantized accumulator
        %bits
        %   Specify this property as an integer scalar in the range [1
        %   128]. The value you specify in the NumQuantizedAccumulatorBits
        %   property must be less than the value you specify in the
        %   NumAccumulatorBits property. This property applies when you set
        %   the Oscillator property to 'NCO'. The default is 12.
        %
        %   See also dsp.NCO.
        NumQuantizedAccumulatorBits;

        % OutputDataType Data type of output
        %    Specify the data type of output as 'Same as input' | 'Custom'.
        %    The default is 'Same as input'.
        OutputDataType;

        %PassbandRipple Passband ripple of cascade response (dB)
        %   Set this property to a double precision, positive scalar. When
        %   you set the MinimumOrderDesign property to true, the object
        %   designs the filters so that the cascade response meets the
        %   passband ripple that you specify in the PassbandRipple
        %   property. This property applies when you set the
        %   MinimumOrderDesign property to true. The default is 0.1 dB.
        PassbandRipple;

        %SecondFilterOrder Order of CIC compensation filter stage
        %   Set this property to a positive, integer scalar. This property
        %   applies when you set the MinimumOrderDesign property to
        %   false. The default is 12.
        SecondFilterOrder;

        %StopbandAttenuation Stopband attenuation of cascade response (dB)
        %   Set this property to a double precision, positive scalar. When
        %   you set the MinimumOrderDesign property to true, the object
        %   designs the filters so that the cascade response meets the
        %   stopband attenuation that you specify in the
        %   StopbandAttenuation property. This property applies when you
        %   set the MinimumOrderDesign property to true. The default is 60 
        %   dB.
        StopbandAttenuation;

        %StopbandFrequency Stopband frequency (Hz)
        %   Set this property to a double precision positive scalar. This
        %   property applies when you set the StopbandFrequencySource 
        %   property to 'Property'. The default is 150e3 Hertz.
        StopbandFrequency;

        %pArithmetic Arithmetic of filters. Can be 'double', 'single' or 'fixed-point'
        pArithmetic;

        %pCIC CIC filter
        pCIC;

        %pCICComp CIC compensator filter
        pCICComp;

        %pCICNormalizationFactor Scaling factor to normalize CIC response
        pCICNormalizationFactor;

        %pCastOutputToBuiltInInteger If true, then we need to cast the output to
        %a built in integer
        pCastOutputToBuiltInInteger;

        %pCastOutputToFloatingFi If true then we need to cast the output to a
        %double or single fi object.
        pCastOutputToFloatingFi;

        %pFilterDesigner Filter designer object
        pFilterDesigner;

        %pInitCICNormOutput Data initialization used to cast CIC normalization
        %output
        pInitCICNormOutput;

        %pInitMixerOutput Data initialization used to cast the mixer output
        pInitMixerOutput;

        %pInitOscillatorOutput Data initialization used to cast the oscillator
        %output.
        pInitOscillatorOutput;

        %pInputDataType Input data type
        pInputDataType;

        %pInputDesignDataType Data Type of input used in designFilters
        pInputDesignDataType;

        %pInputNumericType If input is fixed point, this property holds the
        %numerictype of that input data.
        pInputNumericType;

        %pInputSize Size of input signal
        pInputSize;

        %pIsInputFixedPoint True if input is fixed point
        pIsInputFixedPoint;

        %pIsOscillatorDesigned Flag to check if oscillator has been designed
        pIsOscillatorDesigned;

        %pNormalizeCICOutputFunction Handle to CIC normalization helper function
        pNormalizeCICOutputFunction;

        %pOscillator Oscillator for the frequency converter
        pOscillator;

        %pOscillatorOutputNumericType Numeric type of oscillator output
        pOscillatorOutputNumericType;

        %pOutputCastFunction Handle to the output cast function
        pOutputCastFunction;

        %pOutputNumericType Numeric type of output
        pOutputNumericType;

        %pReinterpretCastNumericType Numeric type of reinterpreted CIC output
        pReinterpretCastNumericType;

        %pRemNormFactor Remaining normalization factor
        pRemNormFactor;

    end
end
