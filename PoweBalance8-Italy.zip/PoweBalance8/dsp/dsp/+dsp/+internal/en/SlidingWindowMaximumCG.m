classdef SlidingWindowMaximumCG< dsp.internal.AbstractSlidingWindowMinMaxCG
% SlidingWindowMaximumCG This class is internally used by
% dsp.MovingMinimum
    methods
        function out=SlidingWindowMaximumCG
        end

        function out=compareElements(~) %#ok<STOUT>
        end

    end
end
