classdef NoPartitionOAOSBase< matlab.System
% NoPartitionOAOSBase Base class for classic overlap-add and
% overlap-save filters. This class is used in
% dsp.FrequencyDomainFIRFilter

     
    % Copyright 2017-2023 The MathWorks, Inc.

    methods
        function out=NoPartitionOAOSBase
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

    end
    properties
        Domain;

        % FFTLength FFT length
        FFTLength;

        FilterIsReal;

        % H FFT of numerator coefficients
        H;

        % Numerator FIR numerator
        Numerator;

        NumeratorLength;

        numChannels;

        pDatatype;

        pFFTLength;

        pFilterLength;

        pHalideMode;

        pIsOutputReal;

        % pLastSection Samples from previous computed segment
        pLastSection;

        % Input buffer
        pinBuff;

        % Output buffer
        poutBuff;

    end
end
