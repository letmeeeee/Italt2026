classdef FourthOrderSectionFilterAnalysis< dsp.internal.FilterAnalysis
% FourthOrderSectionFilterAnalysis Baseclass for Fourth-Order Section
% filter System object analysis

     
    % Copyright 2021 The MathWorks, Inc.

    methods
        function out=FourthOrderSectionFilterAnalysis
        end

        function out=convertToDFILT(~) %#ok<STOUT>
            % Returns equivalent dfilt to current object.
            % Fixed-point analysis is not currently supported
        end

    end
end
