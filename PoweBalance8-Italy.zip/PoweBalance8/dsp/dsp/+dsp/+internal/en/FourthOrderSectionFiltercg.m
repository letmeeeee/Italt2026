classdef FourthOrderSectionFiltercg< handle & matlab.mixin.internal.indexing.Paren
%FOURTHORDERSECTIONFILTERCG Codegen class for
%dsp.FourthOrderSectionFilter

         
    % Copyright 2018-2020 The MathWorks, Inc.

    methods
        function out=FourthOrderSectionFiltercg
        end

        function out=matlabCodegenFromRedirected(~) %#ok<STOUT>
        end

        function out=matlabCodegenToRedirected(~) %#ok<STOUT>
        end

    end
    properties
        % Denominator - Denominator coefficients of size Lx4, where L is
        % the number of sections.
        Denominator;

        % Numerator - Numerator coefficients of size Lx5, where L is the
        % number of sections.
        Numerator;

    end
end
