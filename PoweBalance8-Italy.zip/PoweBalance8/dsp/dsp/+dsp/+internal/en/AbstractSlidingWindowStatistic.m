classdef AbstractSlidingWindowStatistic< matlab.System
% AbstractSlidingWindowStatistic this abstract class is used in the
% moving statistics objects.

     
%   Copyright 2016-2021 The MathWorks, Inc.

    methods
        function out=AbstractSlidingWindowStatistic
            % Constructor
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
            % Reset buffer
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Setup the buffer
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

    end
    methods (Abstract)
        % Concrete moving statistics objects must define this method
        computeStatistic;

    end
    properties
        % InitialBufferValue Initial value in buffer
        InitialBufferValue;

        % NumChans Number of input channels
        NumChans;

        % WindowLength Length of the sliding window
        WindowLength;

        % pbuffer Holds previous WindowLength-1 samples of each input
        % channel
        pBuffer;

    end
end
