classdef TunableBandpassBandstopIIRFilter< dsp.internal.AbstractTunableIIRFilter
% TunableBandpassBandstopIIRFilter

 
%   Copyright 2022-2023 The MathWorks, Inc.

    methods
        function out=TunableBandpassBandstopIIRFilter
        end

        function out=crossValidateProperties(~) %#ok<STOUT>
        end

        function out=getCoefficientsDimensions(~) %#ok<STOUT>
        end

        function out=isDesignFilterAllowed(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isScaleValueAllowed(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Set properties in object obj to values in structure s
            % Set public properties and states
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Set properties in structure s to values in object obj
            % Set public properties and states
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Perform one-time calculations, such as computing constants
        end

        function out=validateF3dB1(~) %#ok<STOUT>
        end

        function out=validateF3dB2(~) %#ok<STOUT>
        end

        function out=validateFilterOrder(~) %#ok<STOUT>
        end

        function out=validateMaxOrder(~) %#ok<STOUT>
        end

    end
    properties
        %CascadeSectionsForm Filter cascade sections form
        %   Specify the filter cascade sections form as one of
        %   ["Fourth-order sections" | "Second-order sections"]. The
        %   default is "Fourth-order sections".
        CascadeSectionsForm;

        %F3dB1 First 3-dB cutoff frequency
        %   Specify the normalized frequency of the 3 dB point below the
        %   passband value for the first cutoff. The default is 0.25. This
        %   property is tunable.
        F3dB1;

        %F3dB2 Second 3-dB cutoff frequency
        %   Specify the normalized frequency of the 3 dB point below the
        %   passband value for the second cutoff. The default is 0.75. This
        %   property is tunable.
        F3dB2;

        pIsUsingSOS;

    end
end
