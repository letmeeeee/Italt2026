classdef NoPartitionOA< dsp.internal.NoPartitionOAOSBase
% NoPartitionOA Classic overlap-add filter. 
% This class is used in dsp.FrequencyDomainFIRFilter

 
% Copyright 2017-2022 The MathWorks, Inc.

    methods
        function out=NoPartitionOA
        end

        function out=computeOutput(~) %#ok<STOUT>
            % input       : Input samples
            % L           : Number of samples to keep (save) from each computed FFT
            % numFrames   : Number of input frames
            % numChannels : Number of input channels
            % H           : FFT of filter numerator
            % fftlen      : FFT length
            % prevsec     : State (samples from previous segment to be added)
            % o           : Output filtered samples
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

    end
end
