classdef FilterVisualizationButton
%FILTERVISUALIZATIONBUTTON Button to view filter response on dialog of
%System block.
%  Example usage in getPropertyGroupsImpl method of a System object:
%      mainS = matlab.system.display.Section('Title', 'Parameters', ...
%                 'PropertyList', props);  
%      filterVis = dsp.internal.FilterVisualizationButton;
%      mainS.Actions = filterVis.fvtoolAction;
%  This will add a 'View Filter Response' button on the dialog when the
%  System object is used in a MATLAB System block. Clicking the button will
%  call fvtool on the object.

 
% Copyright 2015-2023 The MathWorks, Inc.

    methods
        function out=FilterVisualizationButton
            % Create the button
        end

        function out=blankAndAnnotate(~) %#ok<STOUT>
        end

        function out=cacheProperties(~) %#ok<STOUT>
            % Save the System object, to act as baseline for checking for
            % any property change in the future
        end

        function out=onActionCalled(~) %#ok<STOUT>
        end

        function out=onDialogApplied(~) %#ok<STOUT>
            % Close an existing error dialog
        end

        function out=onSystemDeleted(~) %#ok<STOUT>
            % Close an existing warning dialog
        end

        function out=onUnresolvedProperty(~) %#ok<STOUT>
        end

        function out=propertiesChanged(~) %#ok<STOUT>
            % Check if a property value has changed since last button press
        end

    end
    properties
        % Holds information about the button
        fvtoolAction;

    end
end
