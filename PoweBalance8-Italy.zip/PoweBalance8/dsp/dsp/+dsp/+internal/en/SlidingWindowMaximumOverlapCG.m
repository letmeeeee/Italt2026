classdef SlidingWindowMaximumOverlapCG< dsp.internal.AbstractSlidingWindowMinMaxOverlapCG
% SlidingWindowMaximumCGOverlap This class is internally used by
% dsp.MovingMinimum

 
%   Copyright 2021 The MathWorks, Inc.

    methods
        function out=SlidingWindowMaximumOverlapCG
        end

        function out=compareElements(~) %#ok<STOUT>
        end

    end
end
