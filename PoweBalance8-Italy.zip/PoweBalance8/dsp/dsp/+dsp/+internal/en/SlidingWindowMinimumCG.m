classdef SlidingWindowMinimumCG< dsp.internal.AbstractSlidingWindowMinMaxCG
% SlidingWindowMinimumCG This class is internally used by
% dsp.MovingMinimum

 
%   Copyright 2016-2020 The MathWorks, Inc.

    methods
        function out=SlidingWindowMinimumCG
        end

        function out=compareElements(~) %#ok<STOUT>
        end

    end
end
