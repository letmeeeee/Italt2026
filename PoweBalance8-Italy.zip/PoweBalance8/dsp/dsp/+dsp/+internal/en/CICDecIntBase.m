classdef CICDecIntBase< matlab.System & dsp.internal.FilterAnalysisCIC
%CICDecIntBase Base class for CIC Decimator/Interpolator filter classes
%
%   See also dsp.CICDecimator,  dsp.CICInterpolator

     
    %   Copyright 1995-2021 The MathWorks, Inc.

    methods
        function out=CICDecIntBase
        end

        function out=fdhdltool(~) %#ok<STOUT>
            %FDHDLTOOL Launch the GUI to generate HDL
            %   FDHDLTOOL(CIC, nt) launches the Generate HDL dialog that lets you
            %   customize and generate Verilog or VHDL code and test benches for
            %   the quantized System object filter, CIC. You have to call FDHDLTOOL
            %   again if you make changes in the filter, CIC, in the command line.
            %
            %   The main dialog and two subordinate dialogs provide access to many
            %   options for customizing the generated filter and test bench code.
            %
            %   The Generate HDL main dialog categorizes options in two frames:
            %
            %   * HDL Filter - Options you are most likely to customize at least once:
            %   language selection, name and location of generated files, reset
            %   specifications, and optimizations.
            %
            %   * Test bench types - Options for naming and specifying the type of test
            %   bench files to generate, and specific types of stimuli the test benches
            %   are to apply.
            %
            %   EXAMPLE:
            %   cicdecimfilt  = dsp.CICDecimator;
            %   cicinterpfilt = dsp.CICInterpolator;
            %   T = numerictype(1,16,15);
            %   fdhdltool(cicdecimfilt,  T)
            %   fdhdltool(cicinterpfilt, T)
        end

        function out=generatehdl(~) %#ok<STOUT>
            %   GENERATEHDL(CIC, 'InputDataType', nt) automatically generates VHDL
            %   or Verilog code for the quantized filter, CIC. The default
            %   language is VHDL; to generate Verilog, supply the
            %   property/value pair 'TargetLanguage','Verilog'. The file is written to
            %   the HDL source directory which defaults to 'hdlsrc' under the
            %   current directory. This directory will be created if necessary.
            %
            %   GENERATEHDL(CIC, PARAMETER1, VALUE1, PARAMETER2, VALUE2, ...)
            %   generates the HDL code with parameter/value pairs. Valid properties
            %   and values for GENERATEHDL are listed in the Filter Design HDL
            %   Coder documentation section "Property Reference."
            %
            %   EXAMPLE:
            %   cicdecimfilt  = dsp.CICDecimator;
            %   cicinterpfilt = dsp.CICInterpolator;
            %   T = numerictype(1,16,15);
            %   generatehdl(cicdecimfilt,  'InputDataType', T)
            %   generatehdl(cicinterpfilt, 'InputDataType', T)
        end

        function out=getFixedPointInfo(~) %#ok<STOUT>
            %getFixedPointInfo Get fixed-point word and fraction lengths
            %   [WLs, FLs] = getFixedPointInfo(CIC, NT) returns all fixed-point
            %   Section and Output word lengths and fraction lengths for the
            %   CIC filter System object, CIC, and input numerictype, NT. For
            %   locked objects, the input numerictype argument NT is optional.
            %
            %   The WLs are returned as a row vector containing all of the
            %   integrator section, comb section, and output word lengths,
            %   in the signal flow order from the first section to the output,
            %   i.e., [Sec1_WL, Sec2_WL, ..., SecN_WL, Output_WL].
            %
            %   The FLs are returned as a row vector containing all of the
            %   integrator section, comb section, and output fraction lengths,
            %   in the signal flow order from the first section to the output,
            %   i.e., [Sec1_FL, Sec2_FL, ..., SecN_FL, Output_FL].
            %
            %   EXAMPLE:
            %   inputNT       = numerictype(1,16,15);
            %   cicdecimfilt  = dsp.CICDecimator;
            %   [dWLs, dFLs]  = getFixedPointInfo(cicdecimfilt, inputNT);
            %   cicinterpfilt = dsp.CICInterpolator;
            %   [iWLs, iFLs]  = getFixedPointInfo(cicinterpfilt, inputNT);
        end

        function out=getWLsFLsFromInputNT(~) %#ok<STOUT>
        end

        function out=infoImpl(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Call the base class method
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setPortDataTypeConnections(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

    end
    properties
        cCmbStage1;

        cCmbStage10;

        cCmbStage11;

        cCmbStage12;

        cCmbStage13;

        cCmbStage14;

        cCmbStage15;

        cCmbStage2;

        cCmbStage3;

        cCmbStage4;

        cCmbStage5;

        cCmbStage6;

        cCmbStage7;

        cCmbStage8;

        cCmbStage9;

        cIntgStage1;

        cIntgStage10;

        cIntgStage11;

        cIntgStage12;

        cIntgStage13;

        cIntgStage14;

        cIntgStage15;

        cIntgStage2;

        cIntgStage3;

        cIntgStage4;

        cIntgStage5;

        cIntgStage6;

        cIntgStage7;

        cIntgStage8;

        cIntgStage9;

        cOutFL;

        cOutWL;

        % pArithmetic Arithmetic of filters ('double', 'single', or 'fixed')
        pArithmetic;

        % pDelayStates holds internal states due to the integrator stages
        %              with size [nSections, nChannels]. It is tunable.
        pDelayStates;

        % properties added for double and single data type support
        % pFIRFilter Discrete FIR (Boxcar) filter object
        pFIRFilter;

        pInputNT;

    end
end
