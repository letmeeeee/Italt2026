%MSEPRED Predicted mean-squared error for dsp.LMSFilter System object.
%
%   [MMSE,EMSE] = MSEPRED(H,X,D) predicts the steady-state values at
%   convergence of the minimum mean-squared error (MMSE) and the excess
%   mean-squared error (EMSE) given the input and desired response signal
%   sequences  in X and D and the quantities in the adaptive filter H.
%
%   [MMSE,EMSE,MEANW,MSE,TRACEK] = MSEPRED(H,X,D) calculates three
%   sequences corresponding to the analytical behavior of the LMS adaptive
%   filter defined by H:
%
%   MEANW   - Sequence of coefficient vector means. The columns of this
%             matrix contain predictions of the mean values of the LMS
%             adaptive filter coefficients at each time instant. The
%             dimensions of MEANW are (SIZE(X,1)) x (H.length).
%   MSE     - Sequence of mean-square errors. This column vector contains
%             predictions of the mean-square error of the LMS adaptive
%             filter at each time instant. The length of MSE is equal to
%             SIZE(X,1).
%   TRACEK  - Sequence of total coefficient error powers. This column
%             vector contains predictions of the total coefficient error
%             power of the LMS adaptive filter at each time instant. The
%             length of TRACEK is equal to SIZE(X,1).
%
%   [MMSE,EMSE,MEANW,MSE,TRACEK] = MSEPRED(H,X,D,M) specifies an optional
%   decimation factor for computing MEANW, MSE, and TRACEK. If M > 1, every
%   Mth predicted value of each of these sequences is saved. If omitted,
%   the value of M defaults to one.
%
%   See also MSESIM, MAXSTEP.

 
%   Copyright 1999-2016 The MathWorks, Inc.

