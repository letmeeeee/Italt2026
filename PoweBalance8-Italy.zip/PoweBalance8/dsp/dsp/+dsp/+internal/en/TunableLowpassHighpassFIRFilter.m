classdef TunableLowpassHighpassFIRFilter< dsp.internal.AbstractTunableFIRFilter
%TunableLowpassHighpassFIR Filter

 
    %   Copyright 2022-2023 The MathWorks, Inc.

    methods
        function out=TunableLowpassHighpassFIRFilter
        end

        function out=crossValidateProperties(~) %#ok<STOUT>
        end

        function out=getCutoffFrequency(~) %#ok<STOUT>
        end

        function out=isDesignFilterAllowed(~) %#ok<STOUT>
        end

        function out=validateCutoffFrequency(~) %#ok<STOUT>
        end

    end
    properties
        % CutoffFrequency Filter Cutoff frequency
        %   Specify the normalized filter cutoff frequency as a real,
        %   positive scalar smaller than or equal to 1. Th e default is
        %   0.5. This property is tunable.
        CutoffFrequency;

    end
end
