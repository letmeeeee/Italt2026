classdef MIMONoPartitionOAOSBase< matlab.System
% MIMONoPartitionOAOSBase Base class for MIMO overlap-add and
% overlap-save with multiple filters. This class is used in
% dsp.FrequencyDomainFIRFilter

 
    % Copyright 2023 The MathWorks, Inc.

    methods
        function out=MIMONoPartitionOAOSBase
        end

        function out=computeFilter(~) %#ok<STOUT>
            % Compute the equivalent filter across all paths for a given
            % Tx-Rx pair and/or the FFT of the filters
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
            % Initialize / reset discrete-state properties
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

    end
    properties
        FFTLength;

        FilterIsReal;

        % H FFT of Numerator coefficients
        H;

        NumPaths;

        % Numerator FIR numerator
        Numerator;

        NumeratorDomain;

        NumeratorLength;

        SumFilteredOutputs;

        % pCalculateEqvFilter Compute equivalent filter when number of
        % paths is greater than 1
        pCalculateEqvFilter;

        pDatatype;

        % pEqvFreqNum FFT of equivalent filter
        pEqvFreqNum;

        pFFTLength;

        pFilterLength;

        % pInBuff Input buffer
        pInBuff;

        % pIs2DOutput Compute if output size is 2D or 3D
        pIs2DOutput;

        pIsOutputReal;

        pNumChannels;

        pNumFilters;

        pNumReceivers;

        % pOutBuff Output buffer
        pOutBuff;

        % pStates Samples from Previous Computed Segment
        pStates;

    end
end
