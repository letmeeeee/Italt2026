classdef MedianFilterSim< dsp.internal.AbstractSlidingWindowStatistic
% MedianFilterSim This class is used in dsp.MedianFilter

 
%   Copyright 2016-2020 The MathWorks, Inc.

    methods
        function out=MedianFilterSim
        end

        function out=computeStatistic(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

    end
    properties
        InitialBufferValue;

    end
end
