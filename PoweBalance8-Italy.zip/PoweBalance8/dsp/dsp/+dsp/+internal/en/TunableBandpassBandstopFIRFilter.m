classdef TunableBandpassBandstopFIRFilter< dsp.internal.AbstractTunableFIRFilter
%#codegen
    methods
        function out=TunableBandpassBandstopFIRFilter
        end

        function out=crossValidateProperties(~) %#ok<STOUT>
        end

        function out=getCutoffFrequency(~) %#ok<STOUT>
        end

        function out=isDesignFilterAllowed(~) %#ok<STOUT>
        end

        function out=validateBandwidth(~) %#ok<STOUT>
        end

        function out=validateCenterFrequency(~) %#ok<STOUT>
        end

        function out=validateCenterFrequencyBandwidth(~) %#ok<STOUT>
        end

    end
    properties
        % Bandwidth  Filter bandwidth (Hz)
        %   Specify the normalized filter bandwidth in Hertz as a real,
        %   positive scalar less than or equal to 1. The default is 0.1.
        %   This property is tunable.
        Bandwidth;

        %CenterFrequency  Filter center frequency (Hz)
        %   Specify the normalized filter center frequency as a real,
        %   positive scalar less than or equal to 1. The default is 0.5.
        %   Hz. This property is tunable.
        CenterFrequency;

    end
end
