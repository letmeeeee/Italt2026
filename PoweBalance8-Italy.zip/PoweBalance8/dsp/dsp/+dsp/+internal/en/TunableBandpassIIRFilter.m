classdef TunableBandpassIIRFilter< dsp.internal.TunableBandpassBandstopIIRFilter
% TunableBandpassIIRFilter

 
%   Copyright 2022-2023 The MathWorks, Inc.

    methods
        function out=TunableBandpassIIRFilter
        end

        function out=designFilter(~) %#ok<STOUT>
        end

    end
end
