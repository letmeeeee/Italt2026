classdef FilterAnalysis< handle
%#codegen
%#ok<*EMCLS>
%#ok<*EMCA>

   
  %   Copyright 2011-2023 The MathWorks, Inc.

    methods
        function out=FilterAnalysis
        end

        function out=cacheInputDataType(~) %#ok<STOUT>
        end

        function out=cascade(~) %#ok<STOUT>
            %CASCADE Create a dsp.FilterCascade System object
            %   FC = cascade(obj1,obj2,...) returns an object of type
            %   dsp.FilterCascade that cascades filter System objects.
        end

        function out=checkIfNLMSupportedAndSendError(~) %#ok<STOUT>
        end

        function out=coeffs(~) %#ok<STOUT>
            %COEFFS Returns the filter System object coefficients in a structure
            %   S = coeffs(filt) Returns the coefficients of filter System object, filt,
            %   in the structure S.
            %
            %   S = coeffs(filt,'Arithmetic',ARITH,...) analyzes the filter System
            %   object, filt, based on the arithmetic specified in the ARITH input.
            %   ARITH can be set to one of 'double', 'single', or 'fixed'. The
            %   analysis tool assumes a double precision filter when the arithmetic
            %   input is not specified and the filter System object is in an
            %   unlocked state. The coeffs method returns the quantized filter
            %   coefficients when ARITH is set to 'single' or 'fixed'.
        end

        function out=cost(~) %#ok<STOUT>
            %COST   Cost estimate for implementation of filter System object
            %   C = cost(filt) return a cost estimate C for the filter System object,
            %   filt. The cost estimate contains the following fields:
            %   NumCoefficients               : Number of filter coefficients
            %                                   (excluding coefficients with
            %                                   values 0, 1 or -1)
            %   NumStates                     : Number of states
            %   MultiplicationsPerInputSample : Number of multiplications per
            %                                   input sample
            %   AdditionsPerInputSample       : Number of additions per
            %                                   input sample
            %
            %   C = cost(filt,'Arithmetic',ARITH,...) analyzes the filter System
            %   object, filt, based on the arithmetic specified in the ARITH input.
            %   ARITH can be set to one of 'double', 'single', or 'fixed'. The
            %   analysis tool assumes a double precision filter when the arithmetic
            %   input is not specified and the filter System object is in an
            %   unlocked state.
        end

        function out=firtype(~) %#ok<STOUT>
            %FIRTYPE Determine the type (1-4) of a linear phase FIR filter System object
            %   T = firtype(filt) determines the type (1 through 4) of the FIR filter
            %   System object filt. The filter must be real and have linear phase.
            %
            %   Types 1 through 4 are defined as follows:
            %       
            %   Type 1: Even order symmetric coefficients.
            %   Type 2: Odd order symmetric coefficients.
            %   Type 3: Even order antisymmetric coefficients.
            %   Type 4: Odd order antisymmetric coefficients.
        end

        function out=freqrespest(~) %#ok<STOUT>
            %FREQRESPEST  Frequency response estimate via filtering
            %   [Hr,W] = freqrespest(filt,L) computes the frequency response estimate
            %   of the filter System object filt by running input data made up from
            %   sinusoids with uniformly distributed random frequencies through
            %   the filter and forming the ratio between output data and input
            %   data. This is particularly useful for fixed-point filters, a
            %   frequency response estimate that is close to the frequency response
            %   obtained by using only the quantized coefficients but ignoring the
            %   fixed-point additions/multiplications is a good indication that the
            %   filter's fixed-point performance closely matches a floating point
            %   implementation with the same (quantized) coefficients.
            %
            %   L is the number of trials used to compute the estimate. If not
            %   specified, L defaults to 10. In general, the more trials used, the
            %   more accurate estimate obtained at the expense of a longer time
            %   needed to compute the estimate.
            %
            %   Hr is the estimate of the complex frequency response. W is a vector
            %   of frequencies at which filt is estimated.
            %
            %   [Hr,W] = freqrespest(filt,L,P1,V1,P2,V2,...) specifies optional
            %   parameters via parameter-value pairs. Valid pairs are:
            %
            %         Parameter           Default        Description/Valid values
            %   ---------------------  -----------  ----------------------------------
            %    'NFFT'                 512          Number of FFT points.
            %    'NormalizedFrequency'  true         {true,false}
            %    'Fs'                   'Normalized' Sampling frequency. Only used when
            %                                        'NormalizedFrequency' is false.
            %    'SpectrumRange'        'Half'       {'Half','Whole'}
            %    'CenterDC'             false        {true,false}
            %
            %   [Hr, W] = freqrespest(filt,L,OPTS) uses an options object to specify
            %   the optional parameters in lieu of specifying parameter-value
            %   pairs. The OPTS object can be created with OPTS = freqrespopts(filt).
            %   Settings can be changed in OPTS before calling freqrespest, e.g.
            %   set(OPTS,'Fs',48e3);
            %   
            %   [Hr,W] = freqrespest(filt,'Arithmetic',ARITH,...) analyzes the filter
            %   System object, filt, based on the arithmetic specified in the ARITH
            %   input. ARITH can be set to one of 'double', 'single', or 'fixed'.
            %   The analysis tool assumes a double precision filter when the
            %   arithmetic input is not specified and the filter System object is
            %   in an unlocked state.
            %
            %   freqrespest(filt,...) with no output argument launches FVTool and shows
            %   the magnitude response estimate of the filter System object, filt.
        end

        function out=freqrespopts(~) %#ok<STOUT>
            %FREQRESPOPTS Create an options object for frequency response estimate
            %   OPTS = freqrespopts(filt) uses the current settings in the filter
            %   System object filt to create an options object OPTS that contains
            %   options for frequency response estimation.  The OPTS object can be
            %   passed in as an argument to the FREQRESPEST method.
        end

        function out=freqz(~) %#ok<STOUT>
            %FREQZ  Frequency response of discrete-time filter System object
            %   [Hr,W] = freqz(filt,N) returns the N-point complex frequency response
            %   vector Hr and the N-point frequency vector W in radians/sample of
            %   the filter System object filt. The frequency response is evaluated at
            %   N points equally spaced around the upper half of the unit circle.
            %   If N is not specified, it defaults to 8192.
            %
            %   [Hr,W] = freqz(filt,'Arithmetic',ARITH,...) analyzes the filter System
            %   object, filt, based on the arithmetic specified in the ARITH input.
            %   ARITH can be set to one of 'double', 'single', or 'fixed'. The
            %   analysis tool assumes a double precision filter when the arithmetic
            %   input is not specified and the filter System object is in an
            %   unlocked state.
            %
            %   freqz(filt) with no output argument launches FVTool and shows the
            %   magnitude and phase responses of the filter System object, filt.
            %
            %   For additional parameters, see signal/freqz.
        end

        function out=getCoefficientsDataType(~) %#ok<STOUT>
        end

        function out=grpdelay(~) %#ok<STOUT>
            %GRPDELAY Group delay response of discrete-time filter System object
            %   [Gd,W] = grpdelay(filt,N) returns length N vectors Gd and W containing
            %   the group delay of the filter System object, filt, and the frequencies
            %   (in radians) at which it is evaluated. The group delay is defined
            %   as -d{angle(w)}/dw. The frequency response is evaluated at N points
            %   equally spaced around the upper half of the unit circle. For an FIR
            %   filter where N is a power of two, the computation is done faster
            %   using FFTs. If you do not specify N, it defaults to 8192.
            %
            %   [Gd,W] = grpdelay(filt,'Arithmetic',ARITH,...) analyzes the filter
            %   System object, filt, based on the arithmetic specified in the ARITH
            %   input. ARITH can be set to one of 'double', 'single', or 'fixed'.
            %   The analysis tool assumes a double precision filter when the
            %   arithmetic input is not specified and the filter System object is
            %   in an unlocked state.
            %
            %   grpdelay(filt) with no output argument launches FVTool and shows the
            %   group delay response of the filter System object, filt.
            %
            %   For additional parameters, see signal/grpdelay.
        end

        function out=helpFilterAnalysis(~) %#ok<STOUT>
            %   The following analysis methods are available for discrete-time filter System objects:
            %
            %   <a href="matlab:help fvtool">fvtool</a>       -  Filter visualization tool
            %   <a href="matlab:help dsp.internal.FilterAnalysis.infoFA">info</a>         -  Filter information
            %   <a href="matlab:help dsp.internal.FilterAnalysis.freqz">freqz</a>        -  Frequency response
            %   <a href="matlab:help dsp.internal.FilterAnalysis.phasez">phasez</a>       -  Phase response
            %   <a href="matlab:help dsp.internal.FilterAnalysis.zerophase">zerophase</a>    -  Zero-phase response
            %   <a href="matlab:help dsp.internal.FilterAnalysis.grpdelay">grpdelay</a>     -  Group delay response
            %   <a href="matlab:help dsp.internal.FilterAnalysis.phasedelay">phasedelay</a>   -  Phase delay response
            %   <a href="matlab:help dsp.internal.FilterAnalysis.impz">impz</a>         -  Impulse response
            %   <a href="matlab:help dsp.internal.FilterAnalysis.impzlength">impzlength</a>   -  Length of impulse response
            %   <a href="matlab:help dsp.internal.FilterAnalysis.stepz">stepz</a>        -  Step response
            %   <a href="matlab:help dsp.internal.FilterAnalysis.zplane">zplane</a>       -  Pole/zero plot
            %   <a href="matlab:help dsp.internal.FilterAnalysis.cost">cost</a>         -  Cost estimate for implementation of the filter System object
            %   <a href="matlab:help dsp.internal.FilterAnalysis.measure">measure</a>      -  Measure characteristics of the frequency response   
            %
            %   <a href="matlab:help dsp.internal.FilterAnalysis.outputDelay">outputDelay</a>  -  Output delay value
            %   <a href="matlab:help dsp.internal.FilterAnalysis.order">order</a>        -  Filter order
            %   <a href="matlab:help dsp.internal.FilterAnalysis.coeffs">coeffs</a>       -  Filter coefficients in a structure
            %   <a href="matlab:help dsp.internal.FilterAnalysis.firtype">firtype</a>      -  Determine the type (1-4) of a linear phase FIR filter System object
            %   <a href="matlab:help dsp.internal.FilterAnalysis.tf">tf</a>           -  Convert to transfer function
            %   <a href="matlab:help dsp.internal.FilterAnalysis.zpk">zpk</a>          -  Convert to zero-pole-gain
            %   <a href="matlab:help dsp.internal.FilterAnalysis.ss">ss</a>           -  Convert to state space representation
            %
            %   <a href="matlab:help dsp.internal.FilterAnalysis.isallpass">isallpass</a>    -  Verify if filter System object is allpass
            %   <a href="matlab:help dsp.internal.FilterAnalysis.isfir">isfir</a>        -  Verify if filter System object is FIR
            %   <a href="matlab:help dsp.internal.FilterAnalysis.islinphase">islinphase</a>   -  Verify if filter System object is linear phase
            %   <a href="matlab:help dsp.internal.FilterAnalysis.ismaxphase">ismaxphase</a>   -  Verify if filter System object is maximum phase
            %   <a href="matlab:help dsp.internal.FilterAnalysis.isminphase">isminphase</a>   -  Verify if filter System object is minimum phase
            %   <a href="matlab:help dsp.internal.FilterAnalysis.isreal">isreal</a>       -  Verify if filter System object is minimum real
            %   <a href="matlab:help dsp.internal.FilterAnalysis.issos">issos</a>        -  Verify if filter System object is in second-order sections form
            %   <a href="matlab:help dsp.internal.FilterAnalysis.isstable">isstable</a>     -  Verify if filter System object is stable
            %
            %   <a href="matlab:help dsp.internal.FilterAnalysis.realizemdl">realizemdl</a>   -  Filter realization (Simulink diagram)   
            %
            %   <a href="matlab:help dsp.internal.FilterAnalysis.specifyall">specifyall</a>   -  Fully specify fixed-point filter System object settings  
            %
            %   <a href="matlab:help dsp.internal.FilterAnalysis.cascade">cascade</a>      -  Create a dsp.FilterCascade System object  
            %   <a href="matlab:help dsp.internal.FilterAnalysis.parallel">parallel</a>     -  Create a dsp.ParallelFilter System object  
            %
            %   Second-order sections:
            %
            %   <a href="matlab:help dsp.BiquadFilter.scale">scale</a>        -  Scale second-order sections of BiquadFilter System object
            %   <a href="matlab:help dsp.BiquadFilter.scalecheck">scalecheck</a>   -  Check scaling of BiquadFilter System object
            %   <a href="matlab:help dsp.BiquadFilter.reorder">reorder</a>      -  Reorder second-order sections of BiquadFilter System object
            %   <a href="matlab:help dsp.BiquadFilter.cumsec">cumsec</a>       -  Cumulative second-order section of BiquadFilter System object
            %   <a href="matlab:help dsp.BiquadFilter.scaleopts">scaleopts</a>    -  Create an options object for second-order section scaling
            %   <a href="matlab:help dsp.IIRFilter.sos">sos</a>          -  Convert to second-order-sections (for IIRFilter System objects only)
            %
            %   Fixed-Point (Fixed-Point Designer Required):
            %
            %   <a href="matlab:help dsp.internal.FilterAnalysis.freqrespest">freqrespest</a>  -  Frequency response estimate via filtering
            %   <a href="matlab:help dsp.internal.FilterAnalysis.freqrespopts">freqrespopts</a> -  Create an options object for frequency response estimate
            %   <a href="matlab:help dsp.internal.FilterAnalysis.noisepsd">noisepsd</a>     -  Power spectral density of filter output due to roundoff noise
            %   <a href="matlab:help dsp.internal.FilterAnalysis.noisepsdopts">noisepsdopts</a> -  Create an options object for output noise PSD computation
            %
            %   Multirate Analysis:
            %
            %   <a href="matlab:help dsp.internal.FilterAnalysisMultirate.polyphase">polyphase</a>                - Polyphase decomposition of multirate filter System object
            %   <a href="matlab:help dsp.CICDecimator.gain">gain (CIC decimator)</a>     - Gain of CIC decimator filter System object
            %   <a href="matlab:help dsp.CICInterpolator.gain">gain (CIC interpolator)</a>  - Gain of CIC interpolator filter System object
            %
            %   For decimator, interpolator, or rate change filter System objects
            %   the analysis tools perform computations relative to the rate at
            %   which the filter is running. If a sampling frequency is specified,
            %   it is assumed that the filter is running at that rate.
        end

        function out=impz(~) %#ok<STOUT>
            %IMPZ   Impulse response of discrete-time filter System object
            %   [Hr,T] = impz(filt) computes the impulse response of the filter System
            %   object, filt, and returns the response in column vector Hr, and a
            %   vector of times (or sample intervals) in T (T = [0 1 2...]'). The
            %   number of samples in the response is chosen automatically.
            %
            %   [Hr,T] = impz(filt,'Arithmetic',ARITH,...) analyzes the filter System
            %   object, filt, based on the arithmetic specified in the ARITH input.
            %   ARITH can be set to one of 'double', 'single', or 'fixed'. The
            %   analysis tool assumes a double precision filter when the arithmetic
            %   input is not specified and the filter System object is in an
            %   unlocked state.
            %
            %   impz(filt) with no output argument launches FVTool and shows the
            %   impulse response of the filter System object, filt.
            %
            %   For additional parameters, see signal/impz.
        end

        function out=impzlength(~) %#ok<STOUT>
            %IMPZLENGTH Length of impulse response of discrete-time filter System object
            %   L = impzlength(filt) returns the length, L, of the impulse response of
            %   the filter System object, filt.
            %
            %   L = impzlength(filt,TOL) specifies the tolerance, TOL, to increase or
            %   decrease the length accuracy. By default, TOL = 5e-5.
            %
            %   L = impzlength(filt,'Arithmetic',ARITH,...) analyzes the filter System
            %   object, filt, based on the arithmetic specified in the ARITH input.
            %   ARITH can be set to one of 'double', 'single', or 'fixed'. The
            %   analysis tool assumes a double precision filter when the arithmetic
            %   input is not specified and the filter System object is in an
            %   unlocked state.
        end

        function out=infoFA(~) %#ok<STOUT>
            %INFO   Information about filter System object
            %   S = info(filt) returns a string matrix with information about the
            %   filter System object, filt.
            %
            %   S = info(filt,'Arithmetic',ARITH) assumes the filter arithmetic
            %   specified in the ARITH input. The ARITH input can be one of
            %   'double', 'single' or 'fixed'. The info method assumes that filt is a
            %   double precision filter when the arithmetic input is not specified
            %   and the filter System object is in an unlocked state.
            %
            %   An optional string argument, 'long' or 'short' can be passed to
            %   format the contents of info. The default value is 'short'.
            %
            %   S = info(filt,...,'long') returns detailed information about the
            %   filter that includes the design method, options, specifications,
            %   measurements and implementation cost.
            %
            %   S = info(filt,...,'short') returns the brief information about filter.
        end

        function out=isNLMSupported(~) %#ok<STOUT>
        end

        function out=isallpass(~) %#ok<STOUT>
            %ISALLPASS Verify that discrete-time filter System object is allpass
            %   FLAG = isallpass(filt) returns true if filter System object, filt, is
            %   all-pass.
            % 
            %   FLAG = isallpass(filt,TOL) uses tolerance TOL to determine when two
            %   numbers are close enough to be considered equal.
            %
            %   FLAG = isallpass(filt,'Arithmetic',ARITH,...) analyzes the filter
            %   System object, filt, based on the arithmetic specified in the ARITH
            %   input. ARITH can be set to one of 'double', 'single', or 'fixed'.
            %   The analysis tool assumes a double precision filter when the
            %   arithmetic input is not specified and the filter System object is
            %   in an unlocked state.
        end

        function out=isfir(~) %#ok<STOUT>
            %ISFIR  Verify if discrete-time System object filter is FIR
            %   FLAG = isfir(filt) returns true if filter System object, filt, is FIR.
        end

        function out=islinphase(~) %#ok<STOUT>
            %ISLINPHASE Verify that discrete-time filter System object is linear phase
            %   FLAG = islinphase(filt) returns true if filter System object, filt, is
            %   linear phase.
            %
            %   FLAG = islinphase(filt,TOL) uses tolerance TOL to determine when two
            %   numbers are close enough to be considered equal.
            %
            %   FLAG = islinphase(filt,'Arithmetic',ARITH,...) analyzes the filter
            %   System object, filt, based on the arithmetic specified in the ARITH
            %   input. ARITH can be set to one of 'double', 'single', or 'fixed'.
            %   The analysis tool assumes a double precision filter when the
            %   arithmetic input is not specified and the filter System object is
            %   in an unlocked state.
        end

        function out=ismaxphase(~) %#ok<STOUT>
            %ISMAXPHASE Verify that discrete-time filter System object is maximum phase
            %   FLAG = ismaxphase(filt) returns true if filter System object, filt, is
            %   maximum phase.
            %
            %   FLAG = ismaxphase(filt,TOL) uses tolerance TOL to determine when two
            %   numbers are close enough to be considered equal.
            %
            %   FLAG = ismaxphase(filt,'Arithmetic',ARITH,...) analyzes the filter
            %   System object, filt, based on the arithmetic specified in the ARITH
            %   input. ARITH can be set to one of 'double', 'single', or 'fixed'.
            %   The analysis tool assumes a double precision filter when the
            %   arithmetic input is not specified and the filter System object is
            %   in an unlocked state.
        end

        function out=isminphase(~) %#ok<STOUT>
            %ISMINPHASE Verify that discrete-time filter System object is minimum phase
            %   FLAG = isminphase(filt) returns true if filter System object, filt, is
            %   maximum phase.
            %
            %   FLAG = isminphase(filt,TOL) uses tolerance TOL to determine when two
            %   numbers are close enough to be considered equal.
            %
            %   FLAG = isminphase(filt,'Arithmetic',ARITH,...) analyzes the filter
            %   System object, filt, based on the arithmetic specified in the ARITH
            %   input. ARITH can be set to one of 'double', 'single', or 'fixed'.
            %   The analysis tool assumes a double precision filter when the
            %   arithmetic input is not specified and the filter System object is
            %   in an unlocked state.
        end

        function out=isreal(~) %#ok<STOUT>
            %ISREAL Verify that discrete-time filter System object is real
            %   FLAG = isreal(filt) returns true if filter System object, filt, has real
            %   coefficients.
        end

        function out=issos(~) %#ok<STOUT>
            %ISSOS  Verify if discrete-time System object filter is in second-order sections form
            %   FLAG = issos(filt) returns true if filter System object, filt, is in
            %   second-order sections form.
        end

        function out=isstable(~) %#ok<STOUT>
            %ISSTABLE Verify that discrete-time filter System object is stable
            %   FLAG = isstable(filt) returns true if filter System object, filt, is
            %   stable.
            %
            %   FLAG = isstable(filt,'Arithmetic',ARITH,...) analyzes the filter
            %   System object, filt, based on the arithmetic specified in the ARITH
            %   input. ARITH can be set to one of 'double', 'single', or 'fixed'.
            %   The analysis tool assumes a double precision filter when the
            %   arithmetic input is not specified and the filter System object is
            %   in an unlocked state.
        end

        function out=listFilterAnalysisObjects(~) %#ok<STOUT>
        end

        function out=loadFA(~) %#ok<STOUT>
        end

        function out=measure(~) %#ok<STOUT>
            %MEASURE  Measure frequency response characteristics of filter System object
            %   measure(filt) displays measurements of various quantities from the
            %   frequency response of the filter System object, filt. Values that are
            %   measured can include the actual passband ripple, the minimum
            %   stopband attenuation, the frequency point at which the filter's
            %   gain is 3 dB below the nominal passband gain, etc. In order for
            %   measure to work, the filter filt needs to be designed using FDESIGN.
            %
            %   M = measure(filt) returns the measurements, M, such that they can be
            %   queried programmatically. For example, to query the 3 dB point, one
            %   would type M.F3dB. Type GET(M) to see the full list of properties
            %   that can be queried. Note that different filter responses will
            %   generate different measurements.
            %
            %   M = measure(filt,'Arithmetic',ARITH,...) analyzes the filter System
            %   object, filt, based on the arithmetic specified in the ARITH input.
            %   ARITH can be set to one of 'double', 'single', or 'fixed'. The
            %   analysis tool assumes a double precision filter when the arithmetic
            %   input is not specified and the filter System object is in an
            %   unlocked state.
            %  
            %   For designs that do not specify some of the frequency constraints,
            %   it may not be possible to determine corresponding magnitude
            %   measurements. In these cases, a frequency value can be passed in to
            %   measure in order to determine the magnitude measurements that
            %   corresponds to such value.
            %
            %   %   Example #1: Measure an equiripple FIR design of a bandpass filter
            %   f = fdesign.bandpass('Fst1,Fp1,Fp2,Fst2,Ast1,Ap,Ast2',0.3,0.4,0.6,0.7,80,1,75);
            %   filt = design(f,'equiripple','SystemObject',true);
            %   measure(filt)
            %  
            %   % Example #2: Specify the passband frequency of the filter
            %   f = fdesign.lowpass('N,F3dB,Ast',8,0.5,80);
            %   filt = design(f,'cheby2','SystemObject',true);
            %   measure(filt,'Fpass',0.4)
        end

        function out=noisepsd(~) %#ok<STOUT>
            %NOISEPSD Power spectral density of filter output due to roundoff noise
            %   Hpsd = noisepsd(filt,L) computes the power spectral density (PSD) at
            %   the output of the filter System object filt due to roundoff noise
            %   produced by quantization errors within the filter. The PSD is
            %   computed from an average over the L trials. The larger the number
            %   of trials, the better the estimate (at the expense of longer
            %   computation time). If L is not specified, it defaults to 10 trials.
            %
            %   Output Hpsd is a PSD data object. The PSD vector can be extracted
            %   from Hpsd using GET(Hpsd,'Data') and it can be plotted using
            %   PLOT(Hpsd). The average power of the output noise (the integral of
            %   the PSD) can be computed using AVGPOWER(Hpsd).
            %
            %   Hpsd = noisepsd(filt,L,P1,V1,P2,V2,...) specifies optional parameters
            %   via parameter-value pairs. Valid pairs are:
            %
            %        Parameter           Default        Description/Valid values
            %   ---------------------  -----------  ----------------------------------
            %   'NFFT'                 512          Number of FFT points.
            %   'NormalizedFrequency'  true         {true,false}
            %   'Fs'                   'Normalized' Sampling frequency. Only used when
            %                                       'NormalizedFrequency' is false.
            %   'SpectrumType'         'Onesided'   {'Onesided','Twosided'}
            %   'CenterDC'             false        {true,false}
            %
            %   Hpsd = noisepsd(filt,L,OPTS) uses an options object to specify the
            %   optional parameters in lieu of specifying parameter-value pairs.
            %   The OPTS object can be created with OPTS = noisepsdopts(filt).
            %   Settings can be changed in OPTS before calling noisepsd, e.g.
            %   set(OPTS,'Fs',48e3);
            %
            %   Hpsd = noisepsd(filt,'Arithmetic',ARITH,...) analyzes the filter
            %   System object, filt, based on the arithmetic specified in the ARITH
            %   input. ARITH can be set to one of 'double', 'single', or 'fixed'.
            %   The analysis tool assumes a double precision filter when the
            %   arithmetic input is not specified and the filter System object is
            %   in an unlocked state.
            %
            %   noisepsd(filt,...) with no output argument launches FVTool and shows
            %   the noise PSD estimate of the filter System object, filt.
        end

        function out=noisepsdopts(~) %#ok<STOUT>
            %NOISEPSDOPTS Create an options object for output noise PSD computation
            %   OPTS = noisepsdopts(filt) uses the current settings in the filter
            %   System object filt to create an options object OPTS that contains
            %   options for output noise PSD computation.  The OPTS object can be
            %   passed in as an argument to the noisepsd method.
        end

        function out=order(~) %#ok<STOUT>
            %ORDER  Order of discrete-time filter System object
            %   N = order(filt) returns the order, N, of the filter System object, filt.
            %   The order depends on the filter structure and the reference
            %   double-precision floating-point coefficients.
        end

        function out=outputDelay(~) %#ok<STOUT>
            %outputDelay Output delay of a single rate or a multirate filter.
            %
            % The function outputDelay calculates the delay of a multirate filter, 
            % which results from the group delay of its convolution stages.
            %
            % A multirate filter is any cascade combining upsampling, downsampling, 
            % and convolution filters (FIR or IIR). Most filter System objects in 
            % the DSP System Toolbox(TM) are classified as multirate filters. For
            % example, dsp.FIRDecimator(5) is the multirate filter ->H(z)->(↓5)->. 
            % Single rate filters are a special case of multirate filters with
            % a rate conversion ratio of 1. Single stage filters are also a special
            % case of multirate cascades. For example, dsp.LowpassFilter is 
            % a single-rate, single-stage filter of the form ->H(z)->.
            %
            % The outputDelay(sys) function assumes the multirate filter sys models 
            % a resampling system. Namely, a system whose output is a filtered and 
            % resampled version of the input (at a different rate). In such models, 
            % the input is interpolated to a continuous domain function f(t). The
            % input can then be approximated as u(n) ≈ f(n/FsIn) and the output is
            % y(k) = A⋅f(k/FsOut - D). The values FsIn and FsOut are the input 
            % and output sample rates respectively, and D is the resampling delay.
            % 
            % The outputDelay function returns the delay D and the output sample 
            % rate FsOut for a multirate filter System object operating at an input 
            % sample rate FsIn. 
            %
            % The delay value D depends on the filter structure and order, rate 
            % conversion factors, and sometimes the input signal itself. The value 
            % D is determined by the group delay of the convolution filter stages.
            % 
            % The outputDelay function can operate in two modes, depending on the
            % group delay of filter stages. If all filter stages have a linear 
            % phase, then outputDelay operates in a full band mode. Similarly, if 
            % the filter can be reordered (through noble identity operations) to
            % have equivalent stages with linear phases, the outputDelay function 
            % also operates in a full band mode. If one or more of the stages have 
            % a nonlinear phase, and the filter does not have a linear phase 
            % equivalent, outputDelay operates in a bandlimited mode.
            %
            % • In the full band mode, the returned delay value D applies to all 
            %   inputs. All symmetric filter designs work in that mode. 
            %
            % • In the bandlimited mode, the outputDelay function calculates the 
            %   delay D for a specific input frequency. Specify the input frequency 
            %   through the parameter Fc. This mode is used with filters that have
            %   nonlinear phase stages, which cause a distortion due to the varying 
            %   group delay. In such cases, the resampling model and the delay 
            %   value D are valid only for bandlimited inputs around Fc. The width 
            %   of the band is determined by the frequency region over which the 
            %   group delay is approximately constant. Use the grpdelay function to 
            %   inspect the flatness of the group delay of the filter stages.
            %
            %   The outputDelay function alerts the user if the filter has stages 
            %   with a nonlinear phase. You can use the islinphase function to 
            %   determine if the filter has a linear phase. 
            %   
            % The outputDelay function can estimate a band of input frequencies ƒ 
            % for which the delay is close to D up to a given tolerance Tol.
            % That is |D(ƒ)-D|<=Tol/FsIn. Band measurement is available only for 
            % systems that can be reduced to a rational rate converter, namely, 
            % a cascade of the form ->(↑L)->H(z)->(↓M)->. For a linear phase 
            % system, the returned band is always full (flat group delay). 
            %
            % Usage:
            % D = outputDelay(sys) returns the system output delay. Use this 
            %   syntax when sys is a linear phase single-rate filter. 
            %
            % [D, FsOut] = outputDelay(sys) returns the output delay D and the
            %   output sample rate FsOut. Use this syntax when sys is a linear 
            %   phase multirate filter. 
            %
            % D = outputDelay(sys, FsIn = fin) returns the system output delay
            %   where the input sample rate is the FsIn that you specify. If you do
            %   not specify FsIn, the function uses the built-in input sample rate
            %   property of sys if exists, otherwise the function uses FsIn=1. Use 
            %   this syntax when you want to override the input sample rate.
            %    
            % D = outputDelay(sys, Fc = fc) returns the system output delay, where
            %   the input center frequency is the Fc that you specify. The
            %   frequency Fc determines the value of D through sampling the group 
            %   delay appropriately. If you do not specify Fc, the function uses
            %   the default center frequency of Fc=0 for most filters, except for 
            %   bandpass and highpass filters. Make sure that |fc|<=FsIn/2. Use
            %   this syntax when sys has stages of nonlinear phase.
            %
            % [D, FsOut, B] = outputDelay(sys, Fc = fc, Tol = T, FFTLength = N) 
            %   returns the estimated input frequency band on which the delay value 
            %   is within tolerance Tol (in input sample units) of D. The FFTLength 
            %   parameter sets the resolution at which B is calculated. The default
            %   value of Tol is 0.05, and the default value of FFTLength is 8192.
            %   The returned vector B=[ƒ1 ƒ2] is a pair of boudary frequencies, and
            %   the band stretches from ƒ1 counterclockwise to ƒ2. That is, if 
            %   ƒ2>ƒ1 then the band is {ƒ1<ƒ<ƒ2}. If ƒ2<ƒ1 then the band wraps
            %   around the Nyquist frequency, that is the union of {-FsIn/2<ƒ<ƒ2}
            %   and {ƒ1<ƒ<FsIn/2}. If ƒ1=ƒ2 then band has a single frequency
            %   due to the FFT resolution being too coarse. In such cases, increase 
            %   the value of FFTLength or the tolerance Tol. Use this syntax when 
            %   sys has stages of nonlinear phase.
            %
            %
            % % EXAMPLE 1: Find output times for a dsp.FarrowRateConverter
            % u = sin(6*pi*(1:50)'/200);
            % FsIn = 48000;
            % frc = dsp.FarrowRateConverter(FsIn, 44100);
            % [D, FsOut] = frc.outputDelay();
            % y = frc(u);
            % ts = timescope(NumInputPorts = 2, SampleRate = [FsIn FsOut], ...
            %               TimeDisplayOffset = [0, -D],...
            %               ChannelNames = {'Input','Output'}, ...
            %               TimeSpan = length(y)*1.1/FsIn, ...
            %               PlotType = 'stem')
            % ts(u, y);
            %
            % % EXAMPLE 2: Find output times for dsp.FIRRateConverter (streaming)
            % N = 20; % Frame size
            % inbuf = dsp.AsyncBuffer;
            % inbuf.write(cos(6*pi*(0:2000)'/147));
            % frc = dsp.FIRRateConverter(13, N, 'Auto');
            % [D, FsOut] = frc.outputDelay();
            % ts = timescope(2, [1 FsOut], ...
            %                   TimeDisplayOffset = [0, -D], ...
            %                   TimeSpan=1.1*5*N)
            % for i=1:5
            %   u = inbuf.read(N);
            %   y = frc(u);
            %   ts(u, y);
            % end
            %
            % % EXAMPLE 3: Find output sample times of dsp.FIRRateConverter 
            % n = (0:146)';
            % u = cos(6*pi*n/147);
            % frc = dsp.FIRRateConverter(12,21,'Auto');
            % [D, FsOut] = outputDelay(frc);
            % y = frc(u);
            % stem(y);
            % hold on;
            % stem((n+D)*FsOut+1,u);  % Map input samples to output times
            % hold off;
            %
            % % EXAMPLE 4: Find output times for a dsp.SampleRateConverter
            % FsIn = 44.1e4; 
            % FsOut = 96e3;
            % src = dsp.SampleRateConverter(Bandwidth=40e3,...
            %        InputSampleRate = FsIn, OutputSampleRate = FsOut);
            % D = outputDelay(src);
            % y = src(u);
            % ts = timescope(NumInputPorts = 2, SampleRate = [FsIn FsOut], ...
            %               TimeDisplayOffset = [0, -D],...
            %               ChannelNames={'Input', 'Output'});
            % ts(u, y);    
            %
            % % EXAMPLE 5: Calculate band for a nonlinear phase filter
            % FsIn = 10; 
            % Fc   = 3.3;
            % h = cascade(dsp.FIRFilter(designFracDelayFIR(0.8, 7)), ...
            %             dsp.FIRDecimator);
            % [D,~,B] = outputDelay(h, FsIn = FsIn, Fc=Fc, Tol = 0.1)
            % 
            % [G,W] = h.grpdelay(8192,FsIn);
            % I = W>=B(1) & W<=B(2);  % Mask applicable frequencies
            % plot(W,G /FsIn); 
            % hold on
            % plot(W(I), G(I)/FsIn, 'r', LineWidth=2); 
            % plot(Fc, D, 'ro'); 
            % title(sprintf('Applicable Band (FsIn=%iHz, Fc=%1.1fHz)',FsIn,Fc))
            % legend('Group delay (in sample time units)',...
            %        'Applicable input frequencies band',...
            %        'Output delay for Fc')
            % ylabel('Delay (sec)')
            % xlabel('Frequency (Hz)')
            % hold off
            %
            % See also grpdelay, timescope, islinphase
        end

        function out=outputDelayDefaultNormalizedFc(~) %#ok<STOUT>
            % Return the (normalized) frequency for which group delay is evaluated in
            % outputDelay.
        end

        function out=parallel(~) %#ok<STOUT>
            %PARALLEL Create a dsp.ParallelFilter System object
            %   PF = parallel(obj1,obj2,...) returns an object of type
            %   dsp.ParallelFilter that takes the output sum of filter System 
            %   objects.
        end

        function out=parseArithmetic(~) %#ok<STOUT>
            % Parse arithmetic input
            % Inputs:
            %
            % inputsCell    - cell containing PV-pairs. The method will look for
            %                 the 'Arithmetic' input, parse its value and delete
            %                 the PV-pair from the cell. It will return the 
            %                 modified cell in the second output, inputsCell.
            % forceToDouble - If true, force arithmetic to 'double' regardless of
            %                 the 'Arithmetic' input
            % noDfilt       - If true, do not generate a dfilt object from the 
            %                 System object and return the parsed arithmetic 
            %                 string instead of the dfilt object in the first 
            %                 output, d.
        end

        function out=parseOutputDelayArguments(~) %#ok<STOUT>
        end

        function out=phasedelay(~) %#ok<STOUT>
            %PHASEDELAY Phase delay response of discrete-time filter System object
            %   [PHI,W] = phasedelay(filt,N) returns the N-point phase delay response
            %   vector PHI and the N-point frequency vector W in radians/sample of
            %   the filter System object, filt. The phase response is evaluated at N
            %   points equally spaced around the upper half of the unit circle. If
            %   N is not specified, it defaults to 8192.
            %
            %   [Phi,W] = phasedelay(filt,'Arithmetic',ARITH,...) analyzes the filter
            %   System object, filt, based on the arithmetic specified in the ARITH
            %   input. ARITH can be set to one of 'double', 'single', or 'fixed'.
            %   The analysis tool assumes a double precision filter when the
            %   arithmetic input is not specified and the filter System object is
            %   in an unlocked state.
            %
            %   phasedelay(filt) with no output argument launches FVTool and shows the
            %   phase delay response of the filter System object, filt.
            %
            %   For additional parameters, see signal/phasedelay.
        end

        function out=phasez(~) %#ok<STOUT>
            %PHASEZ Phase response of discrete-time filter System object (unwrapped)
            %   [Phi,W] = phasez(filt,N) returns vectors Phi and W containing the
            %   phase response of the filter System object, filt, and the frequencies
            %   (in radians) at which it is evaluated. The phase response is
            %   evaluated at N points equally spaced around the upper half of the
            %   unit circle. If you do not specify N, it defaults to 8192.
            %
            %   [Phi,W] = phasez(filt,'Arithmetic',ARITH,...) analyzes the filter
            %   System object, filt, based on the arithmetic specified in the ARITH
            %   input. ARITH can be set to one of 'double', 'single', or 'fixed'.
            %   The analysis tool assumes a double precision filter when the
            %   arithmetic input is not specified and the filter System object is
            %   in an unlocked state.
            %
            %   phasez(filt) with no output argument launches FVTool and shows the
            %   phase response of the filter System object, filt.
            %
            %   For additional parameters, see signal/phasez.
        end

        function out=realizemdl(~) %#ok<STOUT>
            %REALIZEMDL Filter realization (Simulink diagram)
            %   realizemdl(filt) automatically generates architecture model of filter
            %   System object, filt, in a Simulink subsystem block using individual
            %   sum, gain, and delay blocks, according to user-defined
            %   specifications.
            %    
            %   realizemdl(filt,'Arithmetic',ARITH,...) analyzes the filter System
            %   object, filt, based on the arithmetic specified in the ARITH input.
            %   ARITH can be set to one of 'double' or 'single'. The analysis tool
            %   assumes a double precision filter when the arithmetic input is not
            %   specified. The realizemdl method for filter System objects does not
            %   support fixed-point arithmetic. 
            %
            %   realizemdl(filt, PARAMETER1, VALUE1, PARAMETER2, VALUE2, ...)
            %   generates the model with parameter/value pairs. Valid properties
            %   and values for realizemdl are listed in this table, with the
            %   default value noted and descriptions of what the properties do.
            %
            %     -------------       ---------------      ----------------------------
            %     Property Name       Property Values      Description
            %     -------------       ---------------      ----------------------------
            %     Destination         [{'current'}         Specify whether to add the block
            %                          'new'               to your current Simulink model,
            %                          <user defined>]     create a new model to contain the
            %                                              block, or specify the name of the
            %                                              target subsystem.
            %
            %     Blockname           {'filter'}           Provides the name for the new
            %                                              subsystem block. By default the
            %                                              block is named 'filter'.
            %
            %     OverwriteBlock      ['on' {'off'}]       Specify whether to overwrite an
            %                                              existing block with the same name
            %                                              as specified by the Blockname
            %                                              property or create a new block.
            %
            %     OptimizeZeros       [{'on'} 'off']       Specify whether to remove zero-gain
            %                                              blocks.
            %
            %     OptimizeOnes        [{'on'} 'off']       Specify whether to replace unity-gain
            %                                              blocks with direct connections.
            %
            %     OptimizeNegOnes     [{'on'} 'off']       Specify whether to replace negative
            %                                              unity-gain blocks with a sign
            %                                              change at the nearest sum block.
            %
            %     OptimizeDelayChains [{'on'} 'off']       Specify whether to replace cascaded
            %                                              chains of delay blocks with a
            %                                              single integer delay block to
            %                                              provide an equivalent delay.
            %
            %     MapStates           ['on' {'off'}]       Specify whether to map the States
            %                                              of the filter as initial conditions
            %                                              of the block.
            %
            %     MapCoeffsToPorts    ['on' {'off'}]       Specify whether to map the
            %                                              coefficients of the filter
            %                                              to the ports of the block.
            %
            %     CoeffNames          {'Num'}              Specify the coefficient
            %                                              variables names. MapCoeffsToPorts
            %                                              must be 'on' for this property
            %                                              to apply.
            %
            %     InputProcessing   [{'columnsaschannels'} Specify sample-based
            %                        'elementsaschannels'] ('elementsaschannels') vs.
            %                                              frame-based ('columnsaschannels')
            %                                              processing.
            %
            %     RateOption(*)      [{'enforcesinglerate'} Specify how the block adjusts
            %                       'allowmultirate']      the rate at the output to accommodate
            %                                              the reduced number of samples.
            %                                              Apply only to multirate blocks
            %                                              when InputProcessing is set to
            %                                              'columnsaschannels'.
        end

        function out=saveFA(~) %#ok<STOUT>
        end

        function out=sendNoAvailableCoefficientsError(~) %#ok<STOUT>
        end

        function out=setFdesign(~) %#ok<STOUT>
        end

        function out=setFmethod(~) %#ok<STOUT>
        end

        function out=specifyall(~) %#ok<STOUT>
            %SPECIFYALL Fully specify fixed-point filter System object settings
            %   specifyall(filt) sets all the data type fixed-point properties of the
            %   filter System object, filt, to 'Custom' so that you can easily specify
            %   all the fixed-point settings. If the object has a
            %   FullPrecisionOverride property, its value is set to false.
            %   specifyall is intended as a shortcut to changing all the
            %   fixed-point properties one-by-one.
            %
            %   specifyall(filt,FLAG) when FLAG is false, is essentially the opposite
            %   of specifyall(filt). All fixed-point properties are set to their
            %   default values and the filter is set to full precision mode if one
            %   is available.
            %
            %   specifyall(filt,FLAG) is equivalent to specifyall(filt) when FLAG is
            %   true.
        end

        function out=ss(~) %#ok<STOUT>
            %SS     Convert discrete-time filter System object to state-space representation
            %   [A,B,C,D] = ss(filt) converts filter System object, filt, to
            %   state-space representation given by:    
            %   x(k+1) = A*x(k) + B*u(k)
            %   y(k)   = C*x(k) + D*u(k)
            %   where x is the state vector, u is the input vector, and y is the 
            %   output vector. 
            %
            %   [A,B,C,D] = ss(filt,'Arithmetic',ARITH) analyzes the filter System
            %   object, filt, based on the arithmetic specified in the ARITH input.
            %   ARITH can be set to one of 'double', 'single', or 'fixed'. The
            %   analysis tool assumes a double precision filter when the arithmetic
            %   input is not specified and the filter System object is in an
            %   unlocked state.
        end

        function out=stepz(~) %#ok<STOUT>
            %STEPZ Step response of discrete-time filter System object
            %   [Hr,T] = stepz(filt) returns the step response Hr of the filter System
            %   object, filt. The length of column vector filt is computed using
            %   IMPZLENGTH. The vector of time samples at which filt is evaluated is
            %   returned in vector T.
            %
            %   [Hr,T] = impz(filt,'Arithmetic',ARITH,...) analyzes the filter System
            %   object, filt, based on the arithmetic specified in the ARITH input.
            %   ARITH can be set to one of 'double', 'single', or 'fixed'. The
            %   analysis tool assumes a double precision filter when the arithmetic
            %   input is not specified and the filter System object is in an
            %   unlocked state.
            %
            %   stepz(filt) with no output argument launches FVTool and shows the step
            %   response of the filter System object, filt.
            %
            %   For additional parameters, see signal/stepz.
        end

        function out=tf(~) %#ok<STOUT>
            %TF Convert discrete-time filter System object to transfer function
            %   [NUM,DEN] = tf(filt) converts discrete-time filter System object, filt,
            %   to numerator and denominator vectors.
            %
            %   [NUM,DEN] = tf(filt,'Arithmetic',ARITH) analyzes the filter System
            %   object, filt, based on the arithmetic specified in the ARITH input.
            %   ARITH can be set to one of 'double', 'single', or 'fixed'. The
            %   analysis tool assumes a double precision filter when the arithmetic
            %   input is not specified and the filter System object is in an
            %   unlocked state.
        end

        function out=toMultirateChain(~) %#ok<STOUT>
            % Convert a FilterAnalysis object to a MultirateChain object
            % The standard model for a FilterAnalysis object (except for
            % FilterCascade) is up->filter->down, i.e. ⟶(↑L)⟶H(z)⟶(↓M)⟶
        end

        function out=zerophase(~) %#ok<STOUT>
            %ZEROPHASE Zero-phase response of discrete-time filter System object
            %   [Hr,W] = zerophase(filt,N) returns length N vectors Hr and W
            %   containing the zero-phase response of the filter System object filt,
            %   and the frequencies (in radians) at which it is evaluated. The
            %   zero-phase response is evaluated at N points equally spaced around
            %   the upper half of the unit circle. For an FIR filter where N is a
            %   power of two, the computation is done faster using FFTs. If you
            %   don't specify N, it defaults to 8192.
            %
            %   [Hr,W] = zerophase(filt,'Arithmetic',ARITH,...) analyzes the filter
            %   System object, filt, based on the arithmetic specified in the ARITH
            %   input. ARITH can be set to one of 'double', 'single', or 'fixed'.
            %   The analysis tool assumes a double precision filter when the
            %   arithmetic input is not specified and the filter System object is
            %   in an unlocked state.
            %
            %   zerophase(filt) with no output argument launches FVTool and shows the
            %   zero-phase response of the filter System object, filt.
            %
            %   For additional parameters, see signal/zerophase.
        end

        function out=zpk(~) %#ok<STOUT>
            %ZPK Zero-pole-gain conversion of discrete-time filter System object
            %   [Z,P,K] = zpk(filt) returns the zeros, poles, and gain corresponding
            %   to the filter System object, filt, in vectors Z, P, and scalar K
            %   respectively.
            %
            %   [Z,P,K] = zpk(filt,'Arithmetic',ARITH) analyzes the filter System
            %   object, filt, based on the arithmetic specified in the ARITH input.
            %   ARITH can be set to one of 'double', 'single', or 'fixed'. The
            %   analysis tool assumes a double precision filter when the arithmetic
            %   input is not specified and the filter System object is in an
            %   unlocked state.
        end

        function out=zplane(~) %#ok<STOUT>
            %ZPLANE Z-plane zero-pole plot for discrete-time filter System object
            %   zplane(filt) plots the zeros and poles of the filter System object, filt,
            %   with the unit circle for reference in the Filter Visualization Tool
            %   (FVTool). Each zero is represented with a 'o' and each pole with a
            %   'x' on the plot. Multiple zeros and poles are indicated by the
            %   multiplicity number shown to the upper right of the zero or pole.
            %
            %   zplane(filt,'Arithmetic',ARITH,...) analyzes the filter System object,
            %   filt, based on the arithmetic specified in the ARITH input. ARITH can
            %   be set to one of 'double', 'single', or 'fixed'. The analysis tool
            %   assumes a double precision filter when the arithmetic input is not
            %   specified and the filter System object is in an unlocked state.
            %
            %   [Z, P, k] = zplane(filt)  returns the zeros, poles, and gain of
            %   filt.
            %
            %   For additional parameters, see signal/zplane.
        end

    end
    properties
        %pDesignMethod Design method metadata
        pDesignMethod;

        %pFdesign Fdesign metadata
        pFdesign;

        %pFmethod Fmethod metadata
        pFmethod;

        %pInputWordLength
        pInputFractionLength;

        %pInputSignedness
        pInputSignedness;

        %pInputWordLength
        pInputWordLength;

        %pLockedArithmetic
        pLockedArithmetic;

        %pMeasurements Measurements metadata
        pMeasurements;

    end
end
