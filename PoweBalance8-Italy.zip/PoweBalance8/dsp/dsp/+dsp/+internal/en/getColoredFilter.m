%GETCOLOREDFILTER Return a filter for generating colored noise
%   Return SOS coefficients for a colored filter, a gain that will avoid
%   clipping, and the length of the impulse response. The first impzLen
%   samples output from the filter should be thrown away.

 
%   Copyright 2019 The MathWorks, Inc.

