%MAXSTEP  Maximum step size for LMS adaptive filter convergence.
%
%   MUMAX = MAXSTEP(H,X) predicts a bound on the step size to  provide
%   convergence of the mean values of the adaptive filter coefficients.
%
%   The columns of the matrix X contain individual input signal sequences.
%   The signal set is assumed to have zero mean or nearly so.
% 
%   [MUMAX,MUMAXMSE] = MAXSTEP(H,X) predicts a bound on the adaptive filter
%   step size to provide convergence of the adaptive filter coefficients in
%   mean square.
%
%   See also MSEPRED, MSESIM.

 
%   Copyright 1999-2016 The MathWorks, Inc.

