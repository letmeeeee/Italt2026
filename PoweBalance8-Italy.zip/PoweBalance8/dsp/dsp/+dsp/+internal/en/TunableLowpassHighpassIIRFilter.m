classdef TunableLowpassHighpassIIRFilter< dsp.internal.AbstractTunableIIRFilter
% TunableLowpassHighpassIIRFilter

 
%   Copyright 2022 The MathWorks, Inc.

    methods
        function out=TunableLowpassHighpassIIRFilter
        end

        function out=crossValidateProperties(~) %#ok<STOUT>
        end

        function out=isDesignFilterAllowed(~) %#ok<STOUT>
        end

        function out=validateF3dB(~) %#ok<STOUT>
        end

    end
    properties
        %F3dB 3-dB cutoff frequency
        %   Specify the normalized cutoff frequency for the 3 dB point
        %   below the passband. The default is 0.25. This property is
        %   tunable.
        F3dB;

    end
end
