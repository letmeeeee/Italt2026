classdef AbstractMovingMinMax< matlab.System
%   AbstractMovingMinMax This is the base class of dsp.MovingMinimum and
%   dsp.MovingMaximum

 
%   Copyright 2016-2021 The MathWorks, Inc.

    methods
        function out=AbstractMovingMinMax
        end

        function out=getNumChans(~) %#ok<STOUT>
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
            % Modify order of display
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isInputComplexityMutableImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Get the number of input channels
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

    end
    properties
        % NumChannels Cached number of channels (used for error checking)
        NumChannels;

        % SpecifyWindowLength Specify window length
        % When you set this property to true, the sliding window length is
        % equal to the value of the WindowLength property. 
        % When you set this property to false, the sliding window length is
        % infinite. In this mode, the statistic is computed for the current
        % sample and all previous samples.
        % The default is true.
        SpecifyWindowLength;

        %WindowLength Window length
        % Specify the sliding window length as a positive, scalar integer.
        % This property applies when 'SpecifyWindowLength' is true. 
        % The default is 4.
        WindowLength;

        % pNumChannels Cached number of channels (used to allocate state)
        pNumChannels;

        % pStat Object used to perform moving maximum/minimum
        pStat;

    end
end
