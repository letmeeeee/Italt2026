classdef QRFactorization< matlab.System
% QRFactorization Factor arbitrary matrix into unitary and upper
% triangular components

     
    %   Copyright 2019-2023 The MathWorks, Inc.

    methods
        function out=QRFactorization
            % Support name-value pair arguments when constructing object
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Set properties in object obj to values in structure s
            % Set public properties and states
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Set properties in structure s to values in object obj
            % Set public properties and states
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
            % Implement algorithm. Calculate y as a function of input u and
            % discrete states.
        end

    end
    properties
        % outputSize Output size
        outputSize;

    end
end
