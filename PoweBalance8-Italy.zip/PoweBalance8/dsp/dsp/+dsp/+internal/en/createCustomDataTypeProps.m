%createCustomDataTypeProps Create a System object data type props structure
%   This is a private function used only by System objects.

 
%   Copyright 2014 The MathWorks, Inc.

