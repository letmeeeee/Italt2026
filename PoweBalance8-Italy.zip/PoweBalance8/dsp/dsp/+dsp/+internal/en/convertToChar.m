% convert numerical param to string

 
% Copyright 2014-2020 The MathWorks, Inc.

