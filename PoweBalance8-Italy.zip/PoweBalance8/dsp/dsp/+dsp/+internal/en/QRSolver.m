classdef QRSolver< matlab.System
% QRSolver Find minimum-norm-residual solution to AX=B

 
%   Copyright 2019-2023 The MathWorks, Inc.

    methods
        function out=QRSolver
            % Support name-value pair arguments when constructing object
        end

        function out=lsqminnorm(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
            % Calculate x as a function of inputs A and b
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

    end
end
