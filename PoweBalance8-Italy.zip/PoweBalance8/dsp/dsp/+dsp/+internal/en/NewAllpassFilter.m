classdef NewAllpassFilter< matlab.System & dsp.internal.FilterAnalysis
%AllpassFilter Single-section or cascaded allpass filter with
%   Minimum-multiplier, Lattice, or Wave Digital structure
%
%   APF = dsp.AllpassFilter returns an allpass filter APF that filters
%   each channel of the input signal independently using an allpass
%   filter with the default structure and coefficients.
%
%   APF = dsp.AllpassFilter('PropertyName', PropertyValue, ...) returns
%   an allpass filter, APF, with each specified property set to a
%   specified value.
%
%   Step method syntax:
%
%   Y = step(APF, X) filters the real or complex input signal X using
%   the specified filter to produce the output Y. Each column of X is
%   treated and filtered independently as a separate channel over time.
%
%   AllpassFilter methods:
%
%   step                - See above description for use of this method.
%   release             - Allow changes to non-tunable properties
%                         values and input characteristics.
%   clone               - Create an allpass filter object with the same
%                         property values and internal states.
%   isLocked            - Locked status (logical).
%   reset               - Reset the internal states to initial
%                         conditions.
%
%   AllpassFilter properties:
%
%   Structure                 - Internal allpass filter structure.    
%   AllpassCoefficients       - Coefficients used with 'Minimum 
%                               multiplier' structure.
%   LatticeCoefficients       - Coefficients used with 'Lattice'
%                               structure.
%   WDFCoefficients           - Coefficients used with the 'Wave Digital
%                               Filter' structure.
%   TrailingFirstOrderSection - Is the last section first order.
%
%   This filter supports several filter analysis methods. For more
%   information, type dsp.AllpassFilter.helpFilterAnalysis.
%
%   % EXAMPLE: Implement a lowpass filter using two allpass filters.
%
%     Fs  = 48000;    % in Hz
%     FL = 1024;
%     APF1 = dsp.AllpassFilter('AllpassCoefficients',...
%                        [-0.710525516540603   0.208818210000029]);
%     APF2 =  dsp.AllpassFilter('AllpassCoefficients',...
%                        [-0.940456403667957   0.6;...
%                         -0.324919696232907   0],...
%                         'TrailingFirstOrderSection',true);    
%     TFE = dsp.TransferFunctionEstimator('FrequencyRange',...
%           'onesided','SpectralAverages',2);
%     AP = dsp.ArrayPlot('PlotType','Line','YLimits', [-80 5],...
%         'YLabel','Magnitude (dB)','SampleIncrement', Fs/FL,...
%         'XLabel','Frequency (Hz)','Title','Magnitude Response',...
%         'ShowLegend', true);
%     tic;
%     while toc < 5
%         in  = randn(FL,1);
%         out = 0.5.*(step(APF1,in) + step(APF2,in));        
%         A = step(TFE, in, out);
%         step(AP,db(A));
%     end
%
%   See also dsp.CoupledAllpassFilter, dsp.BiquadFilter, dsp.IIRFilter,
%   dsp.IIRHalfbandInterpolator, dsp.IIRHalfbandDecimator.

     
    %   Copyright 2015-2022 The MathWorks, Inc.

    methods
        function out=NewAllpassFilter
            % Support name-value pair arguments
        end

        function out=convertToDFILT(~) %#ok<STOUT>
            % Returns equivalent dfilt to current object.
        end

        function out=getCoefficients(~) %#ok<STOUT>
        end

        function out=getNumChs(~) %#ok<STOUT>
        end

        function out=infoImpl(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
            % Support mutable input size
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Re-load state if saved version was locked
        end

        function out=parseArithmetic(~) %#ok<STOUT>
            % This overrides the same method of dsp.internal.FilterAnalysis
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
            % Cache initial conditions and internal states.
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Default implementation saves all public properties
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            % Invoked at first call to setup/step, and then every time the
            % input dimensions change
        end

    end
    properties
        %AllpassCoefficients Allpass polynomial coefficients
        %   Specify the real allpass polynomial filter coefficients. This
        %   property is only applicable when the Structure property is set
        %   to 'Mininimum multiplier'. The value of this property can be
        %   either a Nx1 or Nx2 matrix of N first or second-order allpass
        %   sections. The default value for this property is [-2^(-1/2)
        %   0.5]. This property is tunable.
        AllpassCoefficients;

        %LatticeCoefficients Lattice allpass coefficients
        %   Specify the real or complex allpass coefficients as lattice
        %   reflection coefficients form. This property is only applicable
        %   when the Structure property is set to 'Lattice'. The value of
        %   this property can be either a row vector  or a column vector.
        %   The default value for this property is [-2^(1/2)/3, 1/2]. This
        %   property is tunable.
        LatticeCoefficients;

        %Structure Internal allpass structure
        %   Specify the internal allpass filter implementation structure as
        %   one of {'Minimum multiplier' | 'Wave Digital Filter' |
        %   'Lattice'}. Each structure uses a different coefficients set,
        %   independently stored in the corresponding object property
        Structure;

        %TrailingFirstOrderSection Indicate if last section is first order
        %   For the minimum-multiplier structure, specify whether the last
        %   section is a first order section (true) or whether it is a
        %   second order section (false). The default is false.
        TrailingFirstOrderSection;

        %WDFCoefficients Wave Digital Filter allpass coefficients
        %   Specify the real allpass coefficients in Wave Digital Filter
        %   form. This property is only applicable when the Structure
        %   property is set to 'Wave Digital Filter'. The value of this
        %   property can be either a Nx1 or Nx2 matrix of N first or
        %   second-order allpass sections.  All elements must have absolute
        %   value <= 1. The default value for this property is [1/2,
        %   -2^(1/2)/3].
        WDFCoefficients;

    end
end
