classdef TunableHighpassIIRFilter< dsp.internal.TunableLowpassHighpassIIRFilter
% TunableHighpassIIRFilter

 
%   Copyright 2022-2023 The MathWorks, Inc.

    methods
        function out=TunableHighpassIIRFilter
        end

        function out=designFilter(~) %#ok<STOUT>
        end

    end
end
