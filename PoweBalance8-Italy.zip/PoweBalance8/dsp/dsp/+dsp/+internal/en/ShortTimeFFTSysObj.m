classdef ShortTimeFFTSysObj< matlab.System
% This class is used for code generation of dsp.STFT

 
% Copyright 2018-2021 The MathWorks, Inc.

    methods
        function out=ShortTimeFFTSysObj
        end

        function out=getNumChannels(~) %#ok<STOUT>
            % GETNUMCHANNELS Return the number of input channels
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Re-load private properties
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            % Validate inputs to the step method at initialization.
        end

    end
    properties
        FFTLength;

        OverlapLength;

        Window;

    end
end
