classdef RunningMinimum< matlab.System
%   RunningMinimum This class is used in dsp.MovingMinimum

 
%   Copyright 2016 The MathWorks, Inc.

    methods
        function out=RunningMinimum
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

    end
    properties
        % NumChans Number of channels
        NumChans;

        % pCumMin Cumulative minimum
        pCumMin;

    end
end
