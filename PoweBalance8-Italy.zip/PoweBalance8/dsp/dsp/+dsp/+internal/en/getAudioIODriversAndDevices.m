%GETAUDIOIODRIVERSANDDEVICES Get information of audio drivers and devices
%   OUT = dsp.internal.getAudioIODriversAndDevices('drivers') returns audio
%   drivers supported on current platform.
%
%   OUT = dsp.internal.getAudioIODriversAndDevices('allDrivers') returns
%   audio drivers supported, irrespective of platform.
%
%   OUT = dsp.internal.getAudioIODriversAndDevices('inputDevices', DRIVER)
%   returns a cell array of input audio device names that are available to
%   be used with DRIVER.
%
%   OUT = dsp.internal.getAudioIODriversAndDevices('outputDevices', DRIVER)
%   returns a cell array of output audio device names that are available to
%   be used with DRIVER.
%   
%   OUT = dsp.internal.getAudioIODriversAndDevices('driverIndex', DRIVER)
%   returns the index for a particular driver. This index is used to
%   identify the driver by audio API.
%
%   OUT = dsp.internal.getAudioIODriversAndDevices('defaultDriver') returns
%   the default driver for current platform.
%
%   OUT = dsp.internal.getAudioIODriversAndDevices('defaultInputDevice')
%   returns the default input audio device for default driver on current
%   platform.
%
%   OUT = dsp.internal.getAudioIODriversAndDevices('defaultOutputDevice')
%   returns the default output audio device for default driver on current
%   platform.
%
%   This function is used by audioDeviceReader and audioDeviceWriter System
%   objects, and Audio Device Reader and Audio Device Writer blocks.

 
%   Copyright 2015-2020 The MathWorks, Inc.

