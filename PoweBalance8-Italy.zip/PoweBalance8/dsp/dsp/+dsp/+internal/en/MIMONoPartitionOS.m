classdef MIMONoPartitionOS< dsp.internal.MIMONoPartitionOAOSBase
% MIMONoPartitionOS MIMO Overlap-save for multiple filters.
% This class is used in dsp.FrequencyDomainFIRFilter

 
    % Copyright 2023 The MathWorks, Inc.

    methods
        function out=MIMONoPartitionOS
        end

        function out=computeOutput(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

    end
end
