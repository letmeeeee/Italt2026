classdef MIMONoPartitionOA< dsp.internal.MIMONoPartitionOAOSBase
% MIMONoPartitionOA MIMO Overlap-add for multiple filters.
% This class is used in dsp.FrequencyDomainFIRFilter

 
    % Copyright 2023 The MathWorks, Inc.

    methods
        function out=MIMONoPartitionOA
        end

        function out=computeOutput(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

    end
end
