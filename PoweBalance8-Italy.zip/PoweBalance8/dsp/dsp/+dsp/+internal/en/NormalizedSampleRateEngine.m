classdef NormalizedSampleRateEngine< matlab.System
% Class encapsulates sample rate specification behavior (block may specify
% sample rate on dialog, use normalized frequencies or derive it based on
% input specifications).

 
% Copyright 2022 The MathWorks, Inc.

    methods
        function out=NormalizedSampleRateEngine
        end

        function out=disallowContinuousSampleTime(~) %#ok<STOUT>
            % Blocks inheriting from this class should overload this method
            % to allow continuous time
        end

        function out=getInheritedSampleRate(~) %#ok<STOUT>
            % This function is used to derive the sample rate from input
            % port specifications. It applies only to the block.
        end

        function out=getNumChannels(~) %#ok<STOUT>
            % GETNUMCHANNELS Return the number of input channels
        end

        function out=getSampleTimeImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
            % Varsize signals not allowed when sample rate is inherited
        end

        function out=isSampleRateInherited(~) %#ok<STOUT>
            % Variable-size signals are not allowed if the sample rate is
            % inherited
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Get the number of input channels
        end

    end
    methods (Abstract)
        % Property cross-validation. This method must be defined by child
        % classes. It is called in setupImpl. Cross-property validation that
        % depends on SampleRate cannot be put in validatePropertiesImpl,
        % because the value of SampleRate is not yet available there for the
        % block.
        crossValidateProperties;

    end
    properties
        % NormalizedFrequency
        %   Provide normalized frequencies for filter specifications
        NormalizedFrequency;

        % SampleRateMode Sample rate mode
        %   Specify the Sample rate mode as one of 'Specify on dialog' |
        %   'Inherit from input port' | 'Use normalized frequency (0 to
        %   1)'. The default is 'Specify on dialog'.
        SampleRateMode;

    end
end
