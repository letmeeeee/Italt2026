classdef CICCompensationBase< dsp.internal.SampleRateEngine & dsp.internal.FilterAnalysisMultirate
%CICCOMPENSATIONBASE Abstract base class for CIC compensation objects
% dsp.CICCompensationDecimator and dsp.CICCompensationInterpolator inherit
% from this class.

 
% Copyright 2014-2021 The MathWorks, Inc.

    methods
        function out=CICCompensationBase
            % Support name-value pair arguments
        end

        function out=convertToDFILT(~) %#ok<STOUT>
            % Convert the System object to a mfilt object for analysis
        end

        function out=fdhdltool(~) %#ok<STOUT>
            %   FDHDLTOOL(FO, nt) launches the Generate HDL dialog that lets you
            %   customize and generate Verilog or VHDL code and test benches for
            %   the filter System object, FO. You have to call FDHDLTOOL
            %   again if you make changes in the filter, FO, in the command line.
            %
            %   The main dialog and two subordinate dialogs provide access to many
            %   options for customizing the generated filter and test bench code.
            %
            %   The Generate HDL main dialog categorizes options in two frames:
            %
            %   * HDL Filter - Options you are most likely to customize at least once:
            %   language selection, name and location of generated files, reset
            %   specifications, and optimizations.
            %
            %   * Test bench types - Options for naming and specifying the type of test
            %   bench files to generate, and specific types of stimuli the test benches
            %   are to apply.
            %
            %   EXAMPLE:
            %   fo  = dsp.CICCompensationInterpolator;
            %   inT = numerictype(1,16,15);
            %   fdhdltool(fo, inT)
        end

        function out=generatehdl(~) %#ok<STOUT>
            %   GENERATEHDL(FO, 'InputDataType', nt) automatically generates VHDL
            %   or Verilog code for the dsp.FarrowRateConverter, FO. The default
            %   language is VHDL; to generate Verilog, supply the
            %   property/value pair 'TargetLanguage','Verilog'. The file is written to
            %   the HDL source directory which defaults to 'hdlsrc' under the
            %   current directory. This directory will be created if necessary.
            %
            %   GENERATEHDL(FO, PARAMETER1, VALUE1, PARAMETER2, VALUE2, ...)
            %   generates the HDL code with parameter/value pairs. Valid properties
            %   and values for GENERATEHDL are listed in the Filter Design HDL
            %   Coder documentation section "Property Reference."
            %
            %   EXAMPLE:
            %   fo  = dsp.CICCompensationInterpolator;
            %   inT = numerictype(1,16,15);
            %   generatehdl(fo, 'InputDataType', inT)
        end

        function out=getNumInputsImpl(~) %#ok<STOUT>
            % Number of system inputs
        end

        function out=getNumOutputsImpl(~) %#ok<STOUT>
            % Number of system outputs
        end

        function out=infoImpl(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isInputComplexityMutableImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=needToDesignFilters(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

    end
    properties
        %CICDifferentialDelay Differential delay of CIC
        %   Specify the delay value used in each of the comb sections of
        %   the CIC filter to be compensated, as a positive integer scalar.
        %   The default value of this property is 1.
        CICDifferentialDelay;

        %CICNumSections Number of sections of CIC
        %   Specify the number of integrator and comb sections in the CIC
        %   filter to be compensated, as a positive integer scalar. The
        %   default value of this property is 2.
        CICNumSections;

        %CICRateChangeFactor Rate change factor of CIC
        %   Specify the rate change factor of the CIC filter to be
        %   compensated, as a positive integer scalar. The default value of
        %   this property is 2.
        CICRateChangeFactor;

        %CoefficientsDataType Coefficients word and fraction lengths
        %   Specify the coefficients fixed-point type as a signed
        %   numerictype object. The default value of this property is
        %   numerictype(1,16).
        %
        %   See also numerictype.
        CoefficientsDataType;

        %DesignForMinimumOrder Minimum order filter design
        %   When you set this property to true, the object designs filters
        %   with the minimum order that meets the passband frequency,
        %   stopband frequency, passband ripple, and stopband attenuation
        %   specifications that you set using the corresponding properties.
        %   When you set this property to false, the object designs filters
        %   with order that you specify in the FilterOrder property. This
        %   filter design meets the passband frequency, passband ripple,
        %   and stopband attenuation specifications that you set using the
        %   respective properties. Specify it as a logical scalar. The
        %   default value of this property is true.
        DesignForMinimumOrder;

        %FilterOrder Filter order
        %   Specify the order for the designed compensation filter, as a
        %   positive integer scalar. This property applies when you set the
        %   DesignForMinimumOrder property to false. The default value of
        %   this property is 12.
        FilterOrder;

        %PassbandRipple Passband ripple (dB)
        %   Specify the maximum allowed ripple in the passband of the
        %   filter's response, as a positive real scalar in decibels (dB).
        %   The default value of this property is 0.1 dB.
        PassbandRipple;

        %RoundingMethod Rounding method for fixed-point operations at
        %   output 
        %   Specify the rounding method for output as one of ['Ceiling' |
        %   'Convergent' | 'Floor' | 'Nearest' | 'Round' | 'Simplest' |
        %   'Zero']. The default value of this property is 'Floor'.
        RoundingMethod;

        SampleRate;

        %StopbandAttenuation Stopband attenuation (dB)
        %   Specify the attenuation to be achieved in the stopband of the
        %   designed filter's response, as a positive real scalar in
        %   decibels (dB). The default value of this property is 60 dB.
        StopbandAttenuation;

        pIsFilterDesigned;

        pSR;

    end
end
