%GETSUPPORTEDSYSOBJ Get the supportedSysObj.

 
%   Copyright 2011-2018 The MathWorks, Inc.

