classdef STFTSysObj< matlab.System
% This class is used for code generation of dsp.STFT

 
% Copyright 2018-2023 The MathWorks, Inc.

    methods
        function out=STFTSysObj
        end

        function out=getFrequencyVector(~) %#ok<STOUT>
            % getFrequencyVector Get the vector of frequencies at which the
            % short-time FFT is computed.
        end

        function out=getNumChannels(~) %#ok<STOUT>
            % GETNUMCHANNELS Return the number of input channels
        end

        function out=getNumFrequencySamples(~) %#ok<STOUT>
            % Return the number of frequency samples based on the
            % FrequencyRange and FFTLength
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=isOneSided(~) %#ok<STOUT>
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            % Validate inputs to the step method at initialization.
        end

        function out=validatePropertiesImpl(~) %#ok<STOUT>
        end

    end
    properties
        FFTLength;

        FrequencyRange;

        OverlapLength;

        Window;

    end
end
