classdef UpConverterFilterDesigner< dsp.internal.ConverterFilterDesignerBase
%dsp.internal.UpConverterFilterDesigner Interpolation filter cascade designer
%   This object designs a cascade of interpolation filter System objects to
%   be used by the dsp.DigitalUpConverter class. The cascade consists of
%   four stages.
%
%   Stage1   = halfband or lowpass interpolation filter (this
%              stage may or may not be bypassed, depending on the property
%              settings of the object)
%   Stage2   = CIC compensator interpolation filter
%   Stage3   = CIC interpolator filter (this stage will be implemented as a
%              dsp.FIRInterpolator System object when the Arithmetic
%              property is set to 'double' or 'single', or as a
%              dsp.CICInterpolator System object when the Arithmetic
%              property is set to 'fixed'.
%  GainStage = Gain stage to normalize the gain of the CIC interpolator.

     
    %   Copyright 2010-2020 The MathWorks, Inc.

    methods
        function out=UpConverterFilterDesigner
        end

        function out=SystemObjectsToMfilt(~) %#ok<STOUT>
            %Create mfilt filter objects and cascade for filter analysis
        end

        function out=checkPropertyValues(~) %#ok<STOUT>
            %Verify that property values are within valid frequency ranges
        end

        function out=computeCICNullFrequencies(~) %#ok<STOUT>
            % Compute frequency locations of CIC nulls
        end

        function out=computeFrequencySpecifications(~) %#ok<STOUT>
            %Compute rate of operation and stopband frequencies for filter
            %sections.
        end

        function out=designCICInterpolationFilter(~) %#ok<STOUT>
            % Design a CIC interpolation response and implement it as an FIR filter
            % when Arithmetic is ''double' or 'single', or as a CIC filter when
            % Arithmetic is 'fixed'. Output the gain of the CIC filter.
        end

        function out=designFiltersMinOrder(~) %#ok<STOUT>
            % Design cascade of minimum order interpolation filters that meets
            % specifications.
        end

        function out=designFiltersSpecifiedOrders(~) %#ok<STOUT>
            % Design cascade of interpolation filters with specified orders,
            % passband and stopband frequencies.
        end

        function out=fvtool(~) %#ok<STOUT>
            %fvtool Display response of filter cascade
        end

        function out=getInterpolationFactors(~) %#ok<STOUT>
            % If a design is available, return the interpolation factors for each
            % stage
        end

        function out=getNumInputsImpl(~) %#ok<STOUT>
            % Specify number of System inputs
        end

        function out=getNumOutputsImpl(~) %#ok<STOUT>
            % Specify number of System inputs
        end

        function out=groupDelay(~) %#ok<STOUT>
        end

        function out=isFirstStageBypassed(~) %#ok<STOUT>
            % Ask if first stage has been bypassed or not
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setFilterSectionTypes(~) %#ok<STOUT>
            %Determine if the first filter section is bypassed or not. If not, then
            %determine whether the first section should be a halfband or a lowpass
            %interpolation filter. Set the interpolation factor values for each
            %section.
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Initialize private properties to be used later
        end

        function out=visualizeFilterStages(~) %#ok<STOUT>
            %visualizeFilterStages Display response of filter stages
            %   visualizeFilterStages(H) plots the magnitude response of the
            %   interpolation filter stages and of the cascade response. It also
            %   plots a mask based on the filter specifications.
            %
            %   hfvt = visualizeFilterStages(H) returns a handle to an fvtool
            %   object.
            %
            %   Call the fvtool method if you only want to visualize the cascade
            %   response.
        end

    end
    properties
        %InterpolationFactor Interpolation factor
        %   This property can be a scalar, a 1x2 vector, or a 1x3 vector. If it is
        %   a scalar, the interpolation factor for each stage is computed
        %   automatically. If it is a 1x2 vector, the first filter stage is
        %   bypassed. The elements of the 1x2 vector specify the interpolation
        %   factors for the second and third interpolation stages.
        InterpolationFactor;

        %OrderStage1 Order of first filter stage
        %   This property holds the order of the first filter stage. This property
        %   applies when MinimumOrderDesign is false.
        OrderStage1;

        %OrderStage3 Order of third filter stage
        %   This property holds the number of CIC sections. This property applies
        %   when MinimumOrderDesign is false.
        OrderStage3;

        %SampleRate Sample rate at the input of the filter cascade in Hertz
        SampleRate;

        %Stage1FilterSysObj Handle to System object that forms the first
        %stage
        Stage1FilterSysObj;

    end
end
