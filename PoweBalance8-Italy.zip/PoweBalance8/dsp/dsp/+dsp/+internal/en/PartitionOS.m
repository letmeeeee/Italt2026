classdef PartitionOS< dsp.internal.PartitionOAOSBase
% PartitionOS Partitioned overlap-save filter. This class is used in 
% dsp.FrequencyDomainFIRFilter

 
% Copyright 2017-2022 The MathWorks, Inc.

    methods
        function out=PartitionOS
        end

        function out=computeOutput(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

    end
end
