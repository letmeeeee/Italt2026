classdef WaveDigitalFilter
%WAVEDIGITALFILTER- design and filtering functions

 
%   Copyright 2015-2023 The MathWorks, Inc.

    methods
        function out=WaveDigitalFilter
        end

        function out=alpha2wdf(~) %#ok<STOUT>
            % Reference: 
            % M. Lutovac, D. Tosic, B. Evans.
            % Filter Design for Signal Processing using MATLAB and
            % Mathematica. Prentice Hall, 2001.
        end

        function out=filterSingleSection(~) %#ok<STOUT>
            % Reference: 
            % M. Lutovac, D. Tosic, B. Evans.
            % Filter Design for Signal Processing using MATLAB and
            % Mathematica. Prentice Hall, 2001.
        end

        function out=filterSingleSectionCG(~) %#ok<STOUT>
            %Codegen compatible version of single section filtering
        end

        function out=makeAllpassSpec(~) %#ok<STOUT>
            %coef - WDFCoefficients. Coefficients in wave digital form.
            %dType - datatype of input to cast coefs to.
            %hasTrailing1st -  filter has a trailing 1st order section. So
            %   ignore coef(end,2) if coef is nx2.
            %isDelay - the branch is a pure delay. Make an "empty" struct
        end

        function out=stepFirstOrderWDFSections(~) %#ok<STOUT>
            %Implements a cascade of 1st order Wave Digital Filter sections.
            %'zoffset' is the ending index of the preceding SOS into the
            %state matrix.
        end

        function out=stepSecondOrderWDFSections(~) %#ok<STOUT>
            %Implements a cascade of 2nd order Wave Digital Filter sections
        end

        function out=stepWDFCascade(~) %#ok<STOUT>
        end

        function out=wdf2allpass(~) %#ok<STOUT>
            % Reference: 
            % M. Lutovac, D. Tosic, B. Evans.
            % Filter Design for Signal Processing using MATLAB and
            % Mathematica. Prentice Hall, 2001.
        end

        function out=wdf2alpha(~) %#ok<STOUT>
            % Reference: 
            % M. Lutovac, D. Tosic, B. Evans.
            % Filter Design for Signal Processing using MATLAB and
            % Mathematica. Prentice Hall, 2001.
        end

    end
end
