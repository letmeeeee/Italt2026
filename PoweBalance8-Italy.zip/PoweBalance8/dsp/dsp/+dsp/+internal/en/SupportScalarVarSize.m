classdef SupportScalarVarSize< matlab.System
%SupportScalarVarSize
% This is a shared class that MATLAB system blocks can inherit from to
% allow scalar VarSize outputs.
%   Copyright 2022 The MathWorks, Inc.
%#codegen
%#ok<*EMCLS>

 %   Copyright 2022 The MathWorks, Inc.

    methods
        function out=SupportScalarVarSize
        end

        function out=supportsScalarVarsizeImpl(~) %#ok<STOUT>
        end

    end
end
