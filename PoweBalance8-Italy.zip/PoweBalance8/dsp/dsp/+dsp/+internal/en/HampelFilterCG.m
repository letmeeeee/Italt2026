classdef HampelFilterCG< matlab.System
% HampelFilterCG This class is used in dsp.HampelFilter

 
%   Copyright 2016-2019 The MathWorks, Inc.

    methods
        function out=HampelFilterCG
        end

        function out=bubbleUpMax(~) %#ok<STOUT>
            % Bubble element up the max-heap until heap is in good order.
        end

        function out=bubbleUpMin(~) %#ok<STOUT>
            % Bubble element up the min-heap until heap is in good order.
        end

        function out=bubbleUpMinMax(~) %#ok<STOUT>
            % Bubble element up min-max-heap (starting from the anywhere 
            % and moving toward the top of the max heap) until the heap is 
            % in good order.
        end

        function out=compareItems(~) %#ok<STOUT>
            % Compare items ind1 and ind2. 
            % Return true if first element less than second element.
        end

        function out=getValue(~) %#ok<STOUT>
            % Get the current sample value and current median value (the 
            % median value is in the middle of the heap).
        end

        function out=insertElement(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
            % Reset states
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=shiftLeft(~) %#ok<STOUT>
            % SHIFTLEFT move the max and min heap indices to the left and 
            % reorder all of the heaps as necessary. 
            % The max heap and the upper min-max heap become smaller. 
            % The min heap and the lower min-max heap become larger. 
            % 
            %    max heap idx      min heap idx
            %        |                 |
            %        v                 v
            %    [#][#][#][#][#][#][#][#][#]
            % 
            % max heap idx      min heap idx
            %     |                 |
            %     v                 v
            %    [#][#][#][#][#][#][#][#][#]
        end

        function out=shiftRight(~) %#ok<STOUT>
            % SHIFTRIGHT move the max and min heap indices to the right and 
            % reorder all of the heaps as necessary. 
            % The max heap and the upper min-max heap become larger. 
            % The min heap and the lower min-max heap become smaller. 
            % 
            %    max heap idx      min heap idx
            %        |                 |
            %        v                 v
            %    [#][#][#][#][#][#][#][#][#]
            % 
            %       max heap idx      min heap idx
            %           |                 |
            %           v                 v
            %    [#][#][#][#][#][#][#][#][#]
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=swapElements(~) %#ok<STOUT>
            % Swap elements in heap.
        end

        function out=trickleDownMax(~) %#ok<STOUT>
            % Trickle element down the max-heap until heap is in good order.
        end

        function out=trickleDownMin(~) %#ok<STOUT>
            % Trickle element down the min-heap until heap is in good order.
        end

        function out=trickleDownMinMax(~) %#ok<STOUT>
            % Trickle element down min-max-heap (starting from the anywhere 
            % and moving toward the top of the min heap) until the heap is 
            % in good order.
        end

    end
    properties
        % NumChans Number of input channels
        NumChans;

        Threshold;

        % WindowLength Sliding window length
        WindowLength;

    end
end
