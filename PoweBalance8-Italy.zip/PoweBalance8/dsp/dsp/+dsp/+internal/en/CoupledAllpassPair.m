classdef CoupledAllpassPair< matlab.System
% Legacy coupled allpass pair supporting cell arrays

 
    %   Copyright 2013-2020 The MathWorks, Inc.

    methods
        function out=CoupledAllpassPair
        end

        function out=areOutputsReal(~) %#ok<STOUT>
            % Get complexity info for allpass filters and beta multipliers
        end

        function out=arePreGainOutputsReal(~) %#ok<STOUT>
            % One branch at a time - first number 1
        end

        function out=createAllpassBranch(~) %#ok<STOUT>
        end

        function out=createBranchFilters(~) %#ok<STOUT>
        end

        function out=getActiveCoeffsInBranch(~) %#ok<STOUT>
        end

        function out=getBranches(~) %#ok<STOUT>
            %getBranches Return internal allpass branches
            %   Return copies of the internal allpass branches, as a
            %   two-field structure. Each branch is an instance of
            %   dsp.internal.LegacyAllpassFilter
        end

        function out=getDiscreteStateImpl(~) %#ok<STOUT>
        end

        function out=getNumInputsImpl(~) %#ok<STOUT>
        end

        function out=getNumOutputsImpl(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isPropertyActive(~) %#ok<STOUT>
        end

        function out=isSecondBranchInferred(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Re-load state if saved version was locked
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
            % Propagate coefficients changes to child objects
        end

        function out=propagateRelevantCoefficientsToBranches(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Default implementation saves all public properties
        end

        function out=setActiveCoefficientsForBranch(~) %#ok<STOUT>
        end

        function out=setDiscreteStateImpl(~) %#ok<STOUT>
        end

        function out=setPrivateGainMultiplierFcnHandles(~) %#ok<STOUT>
            % Define function handles for phase gain multipliers
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Create branch filter System objects and store in private
            % properties obj.PrivFilter1 and obj.PrivFilter2
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=supportsComplexCoefficients(~) %#ok<STOUT>
        end

        function out=validateCurrentInputs(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            % Invoked at first call to setup/step, and then every time the
            % input dimensions change
        end

    end
    properties
        %AllpassCoefficients1 Allpass polynomial coefficients of branch 1
        %   Specify the polynomial filter coefficients for the first
        %   allpass branch. 
        %   This property is only applicable when the Structure property is
        %   set to 'Minimum multiplier'. The value of this property can 
        %   be either a row vector (single-section configuration) or a cell
        %   array with as many cells as filter sections. The default value 
        %   for this property is {[0 0.5]}. This property is tunable.
        AllpassCoefficients1;

        %AllpassCoefficients2 Allpass polynomial coefficients of branch 2
        %   Specify the polynomial filter coefficients for the second
        %   allpass branch. 
        %   This property is only applicable when the Structure property is
        %   set to 'Minimum multiplier'. The value of this property can 
        %   be either a row vector (single-section configuration) or a cell
        %   array with as many cells as filter sections. The default value 
        %   for this property is {[]}. This property is tunable.
        AllpassCoefficients2;

        %Beta Coupled phase gain
        %   Specify the value of the phasor gain used in complex conjugate
        %   forms in each of the two branches, respectively, in complex 
        %   coefficient configurations.
        %   This property is only applicable when the selected Structure 
        %   property supports complex coefficients.
        %   The absolute value of this property should be 1 and its
        %   default value is 1. This property is tunable.
        Beta;

        % ComplexConjugateCoefficients Allows inferring the coefficients
        %   of the second allpass branch as complex conjugate of the first.
        %   When the input signal is real this triggers the use of an
        %   optimized structural realization. This property is only enabled
        %   if the currently selected structure supports complex
        %   coefficients, and it should only be used the filter
        %   coefficients are actually complex.
        ComplexConjugateCoefficients;

        %Delay Delay length in samples for branch 1
        %   Specify the delay length in number of samples for branch 1,
        %   when the latter operates as a pure delay.
        %   This property is only applicable when the PureDelayBranch
        %   property is set to true.
        Delay;

        %Gain1 Independent Branch 1 Phase Gain
        %   Specify the value of the independent phase gain applied to
        %   branch 1.
        %   This property can only accept values equal to '1', '-1', '0+1i'
        %   and '0-1i'. The default value for this property is '1'. 
        %   This property is nontunable.
        Gain1;

        %Gain2 Independent Branch 2 Phase Gain
        %   Specify the value of the independent phase gain applied to
        %   branch 2.
        %   This property can only accept values equal to '1', '-1', '0+1i'
        %   and '0-1i'. The default value for this property is '1'. 
        %   This property is nontunable.
        Gain2;

        %LatticeCoefficients1 Lattice coefficients of branch 1
        %   Specify the allpass lattice coefficients for the first
        %   allpass branch. 
        %   This property is only applicable when the Structure property is
        %   set to 'Lattice'. The value of this property can 
        %   be either a row vector (single-section configuration) or a cell
        %   array with as many cells as filter sections. The default value 
        %   for this property is {[0.5 0]}. This property is tunable.
        LatticeCoefficients1;

        %LatticeCoefficients2 Lattice coefficients of branch 2
        %   Specify the allpass lattice coefficients for the second
        %   allpass branch. 
        %   This property is only applicable when the Structure property is
        %   set to 'Lattice'. The value of this property can 
        %   be either a row vector (single-section configuration) or a cell
        %   array with as many cells as filter sections. The default value 
        %   for this property is {[]}. This property is tunable.
        LatticeCoefficients2;

        OnlyExecuteTopBranch;

        PureDelayBranch;

        Structure;

        %WDFCoefficients1 Wave Digital Filter coefficients of branch 1
        %   Specify the Wave Digital Filter coefficients for the first
        %   allpass branch. 
        %   This property is only applicable when the Structure property is
        %   set to 'Wave Digital Filter'. The value of this property can 
        %   be either a row vector (single-section configuration) or a cell
        %   array with as many cells as filter sections. The default value 
        %   for this property is {[0.5 0]}. This property is tunable.
        WDFCoefficients1;

        %WDFCoefficients2 Wave Digital Filter coefficients of branch 2
        %   Specify the Wave Digital Filter coefficients for the second
        %   allpass branch. 
        %   This property is only applicable when the Structure property is
        %   set to 'Wave Digital Filter'. The value of this property can 
        %   be either a row vector (single-section configuration) or a cell
        %   array with as many cells as filter sections. The default value 
        %   for this property is {[]}. This property is tunable.
        WDFCoefficients2;

    end
end
