% Design a window based on the window type (windowType) and segment length
% (L). The window is designed in the datatype specified by DT. Chebyshev
% and Kaiser windows need an additional SidelobeAttenuation parameter to be
% specified.
%
% Valid values for windowType are:
% 1 = 'Rectangular'
% 2 = 'Hann'
% 3 = 'Hamming'
% 4 = 'Flat Top'
% 5 = 'Chebyshev'
% 6 = 'Kaiser'
% 7 = 'Blackman'

 
% Copyright 2017 The MathWorks, Inc.

