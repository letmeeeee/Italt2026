classdef HampelFilterSim< dsp.internal.AbstractSlidingWindowStatistic
% HampelFilterSim This class is used in dsp.HampelFilter

 
%   Copyright 2016-2020 The MathWorks, Inc.

    methods
        function out=HampelFilterSim
        end

        function out=computeStatistic(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

    end
    properties
        InitialBufferValue;

        Threshold;

        pNumNeighbors;

    end
end
