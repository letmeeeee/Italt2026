classdef SlidingWindowVarianceSim< dsp.internal.AbstractSlidingWindowStatistic
% SlidingWindowVarianceSimOverlap This class is internally used by
% dsp.MovingVariance

     
    %   Copyright 2015-2021 The MathWorks, Inc.

    methods
        function out=SlidingWindowVarianceSim
        end

        function out=computeStatistic(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
            % Reset buffer
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Setup the buffer
        end

    end
    properties
        HopSize;

        InitialBufferValue;

    end
end
