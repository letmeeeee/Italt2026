classdef SecondOrderSectionFilter< matlab.System & dsp.internal.FilterAnalysis
%SECONDORDERSECTIONFILTER Implements filter formed of cascade of second
%order sections.

 
%   Copyright 2013-2020 The MathWorks, Inc.

    methods
        function out=SecondOrderSectionFilter
            % Constructor
        end

        function out=convertToDFILT(~) %#ok<STOUT>
            % Delegate to convertToDFILT method of equivalent dsp.BiquadFilter
            % object
        end

        function out=getRawCoefficients(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
            % release biquad filter
        end

        function out=resetImpl(~) %#ok<STOUT>
            % reset biquad filter
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Setup Biquad Filter
        end

        function out=stepImpl(~) %#ok<STOUT>
            % use dsp.BiquadFilter to perofrm filtering. Coefficients and
            % gains are tunable (specified from input port)
        end

    end
    properties
        % Denominator Denominator coefficients of size Lx2, where L is
        % the number of sections. The first coefficient is always unity.
        Denominator;

        % Numerator Numerator coefficients of size Lx3, where L is the
        % number of sections.
        Numerator;

    end
end
