classdef FourthOrderSectionFiltercgHelper< matlab.System
%FOURTHORDERSECTIONFILTERCGHELPER Codegen helper class for
%dsp.FourthOrderSectionFilter

     
    % Copyright 2018-2021 The MathWorks, Inc.

    methods
        function out=FourthOrderSectionFiltercgHelper
            % Constructor
            % Accept as Name-Value or Value only pairs
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
            % State is 4xMxL where M is the number of channels, and of
            % the same type as Input
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Set the number of sections
        end

        function out=stepImpl(~) %#ok<STOUT>
            % Pre-allocate variables for performance
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

    end
    properties
        % Denominator - Denominator coefficients of size Lx5, where L is
        % the number of sections.
        Denominator;

        % Numerator - Numerator coefficients of size Lx5, where L is the
        % number of sections.
        Numerator;

    end
end
