classdef SlidingWindowMinimumSim< dsp.internal.AbstractSlidingWindowStatistic
% SlidingWindowMinimumSim This class is internally used by
% dsp.MovingMinimum

     
    %   Copyright 2016-2020 The MathWorks, Inc.

    methods
        function out=SlidingWindowMinimumSim
        end

        function out=computeStatistic(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

    end
    properties
        InitialBufferValue;

    end
end
