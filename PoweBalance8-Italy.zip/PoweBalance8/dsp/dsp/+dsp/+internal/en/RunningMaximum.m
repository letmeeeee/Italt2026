classdef RunningMaximum< matlab.System
%   RunningMaximum This class is used in dsp.MovingMaximum

 
%   Copyright 2016 The MathWorks, Inc.

    methods
        function out=RunningMaximum
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

    end
    properties
        % NumChannels Number of channels
        NumChans;

        % pCumMax Cumulative minimum
        pCumMax;

    end
end
