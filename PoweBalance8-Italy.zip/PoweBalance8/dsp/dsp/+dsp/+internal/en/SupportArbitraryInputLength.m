classdef SupportArbitraryInputLength< dsp.internal.SupportScalarVarSize
% Class inherits matlab.System and determines arbitrary nature of
% the given inputs.

 
    % Copyright 2022 The MathWorks, Inc.

    methods
        function out=SupportArbitraryInputLength
        end

        function out=isInputArbitraryOrVarSize(~) %#ok<STOUT>
        end

    end
end
