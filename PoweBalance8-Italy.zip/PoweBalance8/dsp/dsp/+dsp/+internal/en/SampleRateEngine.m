classdef SampleRateEngine< dsp.internal.SupportArbitraryInputLength
% Class encapsulates sample rate specification behavior (block may specify
% sample rate on dialog, or derive it based on input specifications).

 
% Copyright 2016-2022 The MathWorks, Inc.

    methods
        function out=SampleRateEngine
        end

        function out=disallowContinuousSampleTime(~) %#ok<STOUT>
            % Blocks inheriting from this class should overload this method
            % to allow continuous time
        end

        function out=getNumChannels(~) %#ok<STOUT>
            % GETNUMCHANNELS Return the number of input channels
        end

        function out=getSampleTimeImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
            % Varsize signals not allowed when sample rate is inherited
        end

        function out=isSampleRateInherited(~) %#ok<STOUT>
            % Variable-size signals are not allowed if the sample rate is
            % inherited
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Get the number of input channels
        end

    end
    methods (Abstract)
        % Property cross-validation. This method must be defined by child
        % classes. It is called in setupImpl. Cross-property validation that
        % depends on SampleRate cannot be put in validatePropertiesImpl,
        % because the value of SampleRate is not yet available there for the
        % block.
        crossValidateProperties;

    end
    properties
        % InheritSampleRate Inherit sample rate from input
        % Set this property to true to inherit the sample rate from the
        % input. Set it to false to specify the sample rate on the dialog.
        % This property is not relevant for the System object in MATLAB
        InheritSampleRate;

    end
end
