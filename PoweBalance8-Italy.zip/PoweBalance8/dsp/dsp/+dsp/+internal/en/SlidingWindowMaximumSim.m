classdef SlidingWindowMaximumSim< dsp.internal.AbstractSlidingWindowStatistic
% SlidingWindowMaximumSim This class is internally used by
% dsp.MovingMaximum

     
    %   Copyright 2016-2020 The MathWorks, Inc.

    methods
        function out=SlidingWindowMaximumSim
        end

        function out=computeStatistic(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

    end
    properties
        InitialBufferValue;

    end
end
