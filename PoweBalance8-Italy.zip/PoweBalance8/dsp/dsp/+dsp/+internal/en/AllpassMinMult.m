classdef AllpassMinMult
%ALLPASSMINMULT - design and filtering functions for minimum mult structs

 
    %   Copyright 2015-2020 The MathWorks, Inc.

    methods
        function out=AllpassMinMult
        end

        function out=dsp_allpassfiltCG(~) %#ok<STOUT>
            % Codegen
        end

        function out=makeAllpassSpec(~) %#ok<STOUT>
            %coef - AllpassCoefficients. Coefficients in Min Mult form.
            %dType - datatype of input to cast coefs to.
            %hasTrailing1st -  filter has a trailing 1st order section. So
            %   ignore coef(end,2) if coef is nx2.
            %isDelay - the branch is a pure delay. Make an "empty" struct
        end

        function out=stepFirstOrderSections(~) %#ok<STOUT>
            %Implements a cascade of 1st order sections.
            %'zoffset' is the ending index of the preceding SOS into the
            %state matrix.
        end

        function out=stepMinMultCascade(~) %#ok<STOUT>
        end

        function out=stepMultipleSections(~) %#ok<STOUT>
            % Sim ---------------------------------------------------------
        end

        function out=stepSecondOrderSections(~) %#ok<STOUT>
        end

    end
end
