%FIRFilterPrecision Determine FIR filter precision settings and signal limits
%
%  [A,Q] = FIRFilterPrecision(W,X) Determines the 'Full precision' accumulator data type and
%  'Same wordlength as input' output data type for a set of FIR filters.
%  The maximum (most +ve) and minimum (most -ve) possible values of the accumulator and output
%  signals are also returned.
%
%  Each row of W is treated a coefficient set (or branch). The worst case precision
%  settings and signal limits across all branches are returned. For example W could contain
%  the branches of a polyphase interpolation or resampling filter.
%
%  * W is a matrix of filter weights of type fi. Each row represents one branch.
%  * X is a numerictype object describing the input fixedpoint precision.
%  * A is a fi vector where A(1) and A(2) are the min and max values of the
%    accumulator respectively with fixed-point properties set to full
%    precision.
%  * Q is a fi vector where Q(1) and Q(2) are the min and max values of the
%    output respectively with fixed-point properties set according to the
%    "Same word length as input" rule.

 
%   Copyright 2015-2021 The MathWorks, Inc.

