% This function is used in the spectrum estimation, cross-spectrum
% estimation and transfer function estimation blocks.

 
%   Copyright 2016-2023 The MathWorks, Inc.

