classdef ExponentialMovingAverage< matlab.System
% ExponentialMovingAverage This class is internally used by
% dsp.MovingAverage

 
%   Copyright 2016-2020 The MathWorks, Inc.

    methods
        function out=ExponentialMovingAverage
            % Constructor
        end

        function out=computeStatistic(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

    end
    properties
        % ForgettingFactor Forgetting factor
        ForgettingFactor;

        NumChans;

    end
end
