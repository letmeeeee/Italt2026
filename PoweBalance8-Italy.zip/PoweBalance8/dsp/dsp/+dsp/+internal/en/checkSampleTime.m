%  checkSampleTime Check input sample time
%  obj: Object handle

 
%   Copyright 2018-2019 The MathWorks, Inc.

