classdef AbstractSampleRateEngineTemplate< matlab.System
% AbstractSampleRateEngineTemplate  Template for AbstractSampleRateEngine

 
%   Copyright 2014-2020 The MathWorks, Inc.

    methods
        function out=AbstractSampleRateEngineTemplate
        end

        function out=disallowContinuousSampleTime(~) %#ok<STOUT>
            % Blocks inheriting from this class should overload this method
            % to allow continuous time
        end

        function out=getNumChannels(~) %#ok<STOUT>
            % GETNUMCHANNELS Return the number of input channels
        end

        function out=getSampleTimeImpl(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
            % Define visibility rules
            % InheritSampleRate is always inactive for System objects in
            % MATLAB
            % SampleRate is inactive if InheritSampleRate = true
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=isSampleRateInherited(~) %#ok<STOUT>
            % Variable-size signals are not allowed if the sample rate is
            % inherited
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Re-load state if saved version was locked
        end

        function out=postProcessSampleRate(~) %#ok<STOUT>
            % Child classes may overload this method to implement extra
            % work
            % needed to be done on setting SampleRate property
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Default implementation saves all public properties
        end

        function out=setupImpl(~) %#ok<STOUT>
            % If obj.SampleRate = -1, this means that the inherited sample
            % rate has not been computed yet. validatePropertiesImpl was
            % skipped. Perform validateProperties at the end of setup
            % (after sample rate is derived).
        end

    end
    properties
        % InheritSampleRate Inherit sample rate from input
        % Set this property to true to inherit the sample rate from the
        % input. Set it to false to specify the sample rate on the dialog.
        % This property is not relevant for the System object in MATLAB
        InheritSampleRate;

        % SampleRate Input sample rate (Hz)
        %   Specify the sampling rate of the input in Hertz as a finite
        %   numeric scalar.
        SampleRate;

        % pSampleRateDialog holds the sample rate specified on the dialog
        % Child classes define the default value of this property
        pSampleRateDialog;

        % pSampleRateInherit Private property holds the derived sample rate
        % when inherited from input port. Default value of -1 means that
        % the sample rate has not been derived yet.
        pSampleRateInherit;

    end
end
