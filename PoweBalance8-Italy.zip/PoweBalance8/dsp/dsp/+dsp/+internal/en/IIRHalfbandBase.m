classdef IIRHalfbandBase< dsp.internal.NormalizedSampleRateEngine & dsp.internal.FilterAnalysisMultirate
%IIRHALFBANDBASE Abstract base class for IIR halfband objects.
%  dsp.IIRHalfbandDecimator and dsp.IIRHalfbandInterpolator inherit from
%  this class.

 
% Copyright 2015-2021 The MathWorks, Inc.

    methods
        function out=IIRHalfbandBase
        end

        function out=convertToDFILT(~) %#ok<STOUT>
            % Set coefficients
        end

        function out=getCoeffsForMFILT(~) %#ok<STOUT>
            %This is used when in coefficient mode.
        end

        function out=getMFILT(~) %#ok<STOUT>
            % Suppress MFILT deprecation warnings
        end

        function out=getSampleRate(~) %#ok<STOUT>
        end

        function out=hasDelayBranch(~) %#ok<STOUT>
        end

        function out=infoImpl(~) %#ok<STOUT>
        end

        function out=isCoefficientMode(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
            %Do not call isInactivePropertyImpl@dsp.internal.NormalizedSampleRateEngine
            %These need to  be overridden here because of coefficient mode
        end

        function out=isInputComplexityMutableImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=needToDesignFilters(~) %#ok<STOUT>
            % If any of the properties are changed, we need to redesign the
            % filter
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
            %Only AllpassCoefficients1,2 are tunable. So this method only
            %applies in coefficient mode.
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
            % reset states
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setBranchCoefficients(~) %#ok<STOUT>
        end

        function out=setStates(~) %#ok<STOUT>
            % Allocate internal states
            % Minimum multiplier case needs twice as many states
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=usesMinMult(~) %#ok<STOUT>
            %Min multiplier for coeff mode + min mult or any design mode
        end

        function out=usesWaveDigital(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            % Checks on first input
        end

        function out=validatePropertiesImpl(~) %#ok<STOUT>
        end

    end
    properties
        %AllpassCoefficients1 Branch 1 allpass polynomial coefficients 
        %   Specify the real allpass polynomial filter coefficients for the
        %   first allpass branch. This property applies when Specification
        %   is set to 'Coefficients' and the Structure is set to 'Minimum
        %   multiplier'. The value of this property can be either a Nx1 or
        %   Nx2 matrix of N first or second-order allpass sections. The
        %   default value for this property is [0.1284563; 0.7906755]. This
        %   property is tunable.
        AllpassCoefficients1;

        %AllpassCoefficients2 Branch 2 allpass polynomial coefficients
        %   Specify the real allpass polynomial filter coefficients for the
        %   second allpass branch. This property applies when Specification
        %   is set to 'Coefficients' and the Structure is set to 'Minimum
        %   multiplier'. The value of this property can be either a Nx1 or
        %   Nx2 matrix of N first or second-order allpass sections. The
        %   default value for this property is 0.4295667. This property is
        %   tunable.
        AllpassCoefficients2;

        %Delay Delay length in samples for branch 1
        %   Specify the delay length in number of samples for branch 1, when
        %   that branch is configured as a pure delay.  This property
        %   applies when the HasPureDelayBranch property is set to
        %   true. The default value is 1.
        Delay;

        %DesignMethod Design method
        %   Specify the method used to design the IIR halfband filter. Set
        %   the DesignMethod as one of 'Elliptic' or 'Quasi-linear phase'.
        %   When the property is set to 'Quasi-linear phase', the first
        %   branch is a pure delay which results in an approximately linear
        %   phase response. This property applies when you set Specification
        %   to any option except 'Coefficients'. The default value of this
        %   property is 'Elliptic'.
        DesignMethod;

        %FilterOrder Filter order
        %   Specify the order for the designed IIR halfband filter, as a
        %   finite positive integer scalar. This property applies when the
        %   Specification is set to 'Filter order and transition width' or
        %   'Filter order and stopband attenuation'. When DesignMethod is
        %   'Elliptic', FilterOrder must be an odd integer greater than
        %   one. When DesignMethod is 'Quasi-linear phase', FilterOrder
        %   must be a multiple of four. The default value of this property
        %   is 9.
        FilterOrder;

        % HasPureDelayBranch Make the first branch a pure delay 
        %   When HasPureDelayBranch is set to true, the property holding the
        %   coefficients for the first allpass branch is disabled and Delay
        %   becomes enabled. The default value is false.
        HasPureDelayBranch;

        %HasTrailingFirstOrderSection Last section of branch 2 is first order
        %   For the minimum-multiplier or wave digital structure, specify
        %   whether the last section of branch 2 is a first order section
        %   (true) or whether it is a second order section (false). When set
        %   to true, the second element of the last row of the N-by-2 matrx
        %   is ignored. The default is false.
        HasTrailingFirstOrderSection;

        SampleRate;

        %Specification Filter specification
        %   Specify design parameters for the IIR halfband filter's design
        %   using the method in DesignMethod or specify the coefficients
        %   directly. Set the specification as one of 'Transition width and
        %   stopband attenuation', 'Filter order and stopband attenuation',
        %   'Filter order and transition width', or 'Coefficients'. The
        %   default value of this property is 'Transition width and stopband
        %   attenuation'.
        Specification;

        %StopbandAttenuation Stopband attenuation (dB)
        %   Specify the minimum stopband attenuation for the designed IIR
        %   halfband filter in dB, as a finite positive scalar. This
        %   property applies when Specification is set to 'Filter order and
        %   stopband attenuation' or 'Transition width and stopband
        %   attenuation'. The default value of this property is 80 dB.
        StopbandAttenuation;

        %Structure Internal allpass structure
        %   Specify the internal allpass filter implementation structure as
        %   one of 'Minimum multiplier' or 'Wave Digital Filter'. Each
        %   structure uses a different coefficients set, independently
        %   stored in the corresponding object property. This property
        %   applies when Specification is set to 'Coefficients'. The default
        %   value of this property is 'Minimum multiplier'.
        Structure;

        TransitionWidth;

        %WDFCoefficients1 Branch 1 Wave Digital coefficients
        %   Specify the real allpass coefficients in Wave Digital Filter
        %   form for the first allpass branch. This property applies when
        %   Specification is set to 'Coefficients' and Structure is set to
        %   'Wave Digital Filter'. The value of this property can be either
        %   a Nx1 or Nx2 matrix of N first or second-order allpass sections.
        %   All elements must have absolute value <= 1. The default value
        %   for this property is [0.1284563; 0.7906755].
        WDFCoefficients1;

        %WDFCoefficients2 Branch 2 Wave Digital coefficients
        %   Specify the real allpass coefficients in Wave Digital Filter
        %   form for the second allpass branch. This property applies when
        %   Specification is set to 'Coefficients' and Structure is set to
        %   'Wave Digital Filter'. The value of this property can be either
        %   a Nx1 or Nx2 matrix of N first or second-order allpass sections.
        %   All elements must have absolute value <= 1. The default value
        %   for this property is 0.4295667.
        WDFCoefficients2;

        pBranch2Carry;

        %pBranchCoef1 - 1st and 2nd order coefs
        pBranchCoef1;

        pBranchCoef2;

        %pBranchInfo1 - sizes and filter types of branches
        pBranchInfo1;

        pBranchInfo2;

        pCachedNoDelay;

        pCachedUsesMinMult;

        pDelay;

        pDelayVal;

        pInputPrototype;

        pIsFilterDesigned;

        pNumChannels;

        pSR;

        %pStates Holds internal filter states within a zero-padded 
        %  3-D array of size (maxStatesPerSection x numChannels x 
        %  numSections).
        pStates;

    end
end
