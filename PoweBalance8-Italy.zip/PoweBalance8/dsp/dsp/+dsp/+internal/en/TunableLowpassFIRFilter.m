classdef TunableLowpassFIRFilter< dsp.internal.TunableLowpassHighpassFIRFilter
% TunableLowpassFIRFilter

 
    %   Copyright 2022-2023 The MathWorks, Inc.

    methods
        function out=TunableLowpassFIRFilter
        end

        function out=designFilter(~) %#ok<STOUT>
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
            % Modify order of display
        end

    end
end
