classdef SlidingWindowVarianceCG< matlab.System
% SlidingWindowVarianceCGOverlap This class is internally used by
% dsp.MovingVariance in the sliding window mode

 
%   Copyright 2016-2021 The MathWorks, Inc.

    methods
        function out=SlidingWindowVarianceCG
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

    end
    properties
        HopSize;

        NumChans;

        % WindowLength Sliding window length
        WindowLength;

    end
end
