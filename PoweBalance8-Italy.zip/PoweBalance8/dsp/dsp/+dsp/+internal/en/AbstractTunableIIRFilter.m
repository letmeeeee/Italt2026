classdef AbstractTunableIIRFilter< matlab.System
% AbstractTunableIIRFilter Tunable IIR filter

 
%   Copyright 2022-2023 The MathWorks, Inc.

    methods
        function out=AbstractTunableIIRFilter
            % Support name-value pair arguments when constructing object
        end

        function out=crossValidateProperties(~) %#ok<STOUT>
        end

        function out=getCoefficientsDimensions(~) %#ok<STOUT>
        end

        function out=isDesignFilterAllowed(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
            % Return false if input size cannot change
            % between calls to the System object
        end

        function out=isScaleValueAllowed(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Set properties in object obj to values in structure s
            % Set public properties and states
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetCoefficientsCache(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Set properties in structure s to values in object obj
            % Set public properties and states
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Perform one-time calculations, such as computing constants
            %coder.extrinsic('getCoefficientsDimensions');
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=validateApass(~) %#ok<STOUT>
        end

        function out=validateAstop(~) %#ok<STOUT>
        end

        function out=validateFilterOrder(~) %#ok<STOUT>
        end

        function out=validateMaxOrder(~) %#ok<STOUT>
        end

        function out=validatePropertiesImpl(~) %#ok<STOUT>
        end

    end
    methods (Abstract)
        %------------------------------------------------------------------
        designFilter;

    end
    properties
        %Apass Passband ripple (dB)
        %   Specify the amount of ripple allowed in the passband in dB. The
        %   default is 1. This property is tunable.
        Apass;

        %Astop Stopband attenuation (dB)
        %   Specify the attenuation in the stop band in dB. The default is
        %   60. This property is tunable.
        Astop;

        %DesignMethod Design method
        %   Specify the filter design method as one of ["Butterworth" |
        %   "Chebyshev Type I" | "Chebyshev Type II"]. The default is
        %   "Butterworth".
        DesignMethod;

        %FilterOrder Filter order
        %   Specify the order filter, as a finite positive integer scalar.
        %   The default value of this property is 6. This property is
        %   tunable.
        FilterOrder;

        %HasScaleValues Has scale values
        %   Specify if design has scale values for each section.
        HasScaleValues;

        %MaxOrder Filter maximum order
        %   Specify the filter maximum order as a finite positive integer
        %   scalar. The default value is 10.
        MaxOrder;

        %OutputDataType Output data type
        %   Specify the output data type as "single" or "double". The
        %   default is "double".
        OutputDataType;

        den;

        gain;

        isInit;

        num;

    end
end
