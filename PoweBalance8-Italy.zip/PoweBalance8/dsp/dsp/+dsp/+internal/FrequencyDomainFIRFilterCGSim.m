function Z =  FrequencyDomainFIRFilterCGSim(str, zfft, pH, Z, fftlen, numchan, varargin)
% FrequencyDomainFIRFilterCG Code Generation function calling Halide for Frequency
% Domain FIR Filter

% Copyright 2022 The MathWorks, Inc.

%#codegen
coder.cinclude('iHalideFrequencyDomainFIRFilter.hpp');

if strcmp(str, "NoPartitionOS")

    if isa(zfft,'single')
        func = 'processHalide_FDFIR_NoPartitionOS_CCS';
    elseif isa(zfft,'double')
        func = 'processHalide_FDFIR_NoPartitionOS_CCD';
    end

    coder.ceval(func, zfft, pH,  ...
        uint32(fftlen),uint32(numchan), coder.ref(Z));

elseif strcmp(str, "NoPartitionOA")

    if isa(zfft,'single')
        func = 'processHalide_FDFIR_NoPartitionOA_CCS';
    elseif isa(zfft,'double')
        func = 'processHalide_FDFIR_NoPartitionOA_CCD';
    end

    coder.ceval(func, zfft, pH,  ...
        uint32(fftlen),uint32(varargin{1}), uint32(numchan), coder.ref(Z));

else %if strcmp(str, "Partition")

    if isa(zfft,'single')
        func = 'processHalide_FDFIR_PartitionOAOS_CCS';
    elseif isa(zfft, 'double')
        func = 'processHalide_FDFIR_PartitionOAOS_CCD';
    end

    coder.ceval(func, zfft, pH,  ...
        uint32(fftlen), uint32(varargin{1}), uint32(numchan), coder.ref(Z));
end
end
