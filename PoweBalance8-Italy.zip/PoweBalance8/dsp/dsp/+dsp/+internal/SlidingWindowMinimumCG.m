classdef SlidingWindowMinimumCG < dsp.internal.AbstractSlidingWindowMinMaxCG
% SlidingWindowMinimumCG This class is internally used by
% dsp.MovingMinimum

%   Copyright 2016-2020 The MathWorks, Inc.
   
%#codegen
%#ok<*EMCLS>

    methods
        function obj = SlidingWindowMinimumCG(varargin)
            setProperties(obj,nargin,varargin{:});
        end
    end
    
    methods (Access = protected)
        function z = compareElements(obj,x,y) %#ok
           z = (x>y); 
        end
        
    end

end