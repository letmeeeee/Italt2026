classdef TunableLowpassHighpassIIRFilter < dsp.internal.AbstractTunableIIRFilter
% TunableLowpassHighpassIIRFilter 

%   Copyright 2022 The MathWorks, Inc.

%#codegen

    properties
        %F3dB 3-dB cutoff frequency
        %   Specify the normalized cutoff frequency for the 3 dB point
        %   below the passband. The default is 0.25. This property is
        %   tunable.
        F3dB = 0.25;
    end

    methods
        %------------------------------------------------------------------
        function set.F3dB(this, value)
            validateF3dB(this, value);
            this.F3dB = value;
        end
    end

    methods(Access = protected)
        %------------------------------------------------------------------
        function crossValidateProperties(this)
            crossValidateProperties@dsp.internal.AbstractTunableIIRFilter(this);
            validateF3dB(this, this.F3dB);
        end
        %------------------------------------------------------------------
        function validateF3dB(~, value, varargin)
            allowZero = false;
            if numel(varargin) > 0
                allowZero = varargin{1};
            end
            if allowZero
                validateattributes(value, {'double','single'}, {'real','scalar','nonnegative','finite', '<=', 1}, 'set.F3dB','F3dB');
            else
                validateattributes(value, {'double','single'}, {'real','scalar','positive','finite', '<=', 1}, 'set.F3dB','F3dB');
            end
        end
        %------------------------------------------------------------------
        function flag = isDesignFilterAllowed(this)
            flag = isDesignFilterAllowed@dsp.internal.AbstractTunableIIRFilter(this);
            flag = flag && this.F3dB > 0;
        end
    end
end
