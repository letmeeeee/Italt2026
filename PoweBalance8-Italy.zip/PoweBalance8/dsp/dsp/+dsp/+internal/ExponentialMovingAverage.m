classdef (StrictDefaults)ExponentialMovingAverage < matlab.System
% ExponentialMovingAverage This class is internally used by
% dsp.MovingAverage

% The average of the Nth output sample is equal to 
% pmN = (1/pwN) * sum(plambda.^(N-1:-1:0) .* [x1 x2 x3 ... xN]),
% where:
% plambda is the forgetting factor
% pwN = sum(plambda.^(N-1:-1:0))
% [x1 x2 x3 ... xN] is the vector holding the current input sample xN 
% and the N-1 previous samples.
% The iterative version of this algorithm is:
% pmN = (1-1/pwN) * pmN + (1/pwN) * u(N,:);
% pwN = plambda * pwN + 1;
%
% Reference: Adaptive Filtering and Change Detection for Streaming Data,
% Dean Bodenham, Imperial College London, section 3.2.7 

%   Copyright 2016-2020 The MathWorks, Inc.

%#codegen
%#ok<*EMCLS>
    
    properties
        % ForgettingFactor Forgetting factor
        ForgettingFactor = 0.9;
    end
    
    properties(Access = private)
        % Internal states
        pwN
        pmN
        plambda
    end
    
    properties (Nontunable)
       NumChans = 1
       
    end
    
    properties (Nontunable, Access = private)
       pDatatype
    end
    
    methods
        function obj = ExponentialMovingAverage(varargin)
            % Constructor
            setProperties(obj,nargin,varargin{:});
        end
    end
    
    methods(Access = protected)
        
        function setupImpl(obj,u)
            obj.pDatatype = class(u);
            obj.pwN = cast(1,obj.pDatatype);
            obj.pmN = cast(zeros(1,obj.NumChans),'like',u);
            obj.plambda = cast(obj.ForgettingFactor,obj.pDatatype); 
        end
        
        function processTunedPropertiesImpl(obj)
           obj.plambda = cast(obj.ForgettingFactor,obj.pDatatype); 
        end
        
        function y = stepImpl(obj,u)
            if isempty(coder.target)
                %mex for sim
                wN = obj.pwN;
                mN = obj.pmN;
                lambda = obj.plambda;
                [y, wN, mN] = dsp.internal.builtins.expmovingavg(u, wN, mN, lambda);
                obj.pwN = wN;
                obj.pmN = mN;
            else
                %codegen
                [y,obj.pwN,obj.pmN] = dsp.internal.ExponentialMovingAverage.computeStatistic(obj.pwN,obj.pmN,obj.plambda,u);
            end
        end
        
        function resetImpl(obj)
            obj.pwN = ones(size(obj.pwN),'like',obj.pwN);
            obj.pmN = zeros(size(obj.pmN),'like',obj.pmN);
        end
        
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            if isLocked(obj)
                s.pwN        = obj.pwN;
                s.pmN        = obj.pmN;
                s.plambda   = obj.plambda;
                s.pDatatype = obj.pDatatype;
            end
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                obj.pwN        = s.pwN;
                obj.pmN        = s.pmN;
                obj.plambda   = s.plambda;
                obj.pDatatype = s.pDatatype;
            end
            loadObjectImpl@matlab.System(obj, s, wasLocked);
        end
        
        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end
    end
    
    methods (Static, Access = protected)
        function [y,pwLocal,pmLocal] = computeStatistic(pwLocal,pmLocal,lambda,u)
            y = zeros(size(u),'like',u);
            for index = 1:size(u,1)
                pmLocal = (1-1/pwLocal) * pmLocal + (1/pwLocal) * u(index,:);
                pwLocal   = lambda * pwLocal + 1;
                y(index,:) = pmLocal;
            end
            
        end
    end
end