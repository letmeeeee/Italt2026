classdef PartitionOAOSBase <  matlab.System
    % PartitionOAOSBase Base class for partitioned overlap-add and
    % overlap-save filters. 
    % This class is used in dsp.FrequencyDomainFIRFilter.
    
    % Copyright 2017-2023 The MathWorks, Inc.
    
    %#codegen
    
    properties
        % Numerator Impulse response
        Numerator = fir1(5000,0.3);
    end
    
    properties(Nontunable)
        % PartitionLength Length of each partition of the impulse response
        PartitionLength = 256;
        Domain (1, :) char {matlab.system.mustBeMemberMessageID(Domain, ...
                    {'dsp:system:FrequencyDomainFIRFilter:Domain_Time',;...
                    'dsp:system:FrequencyDomainFIRFilter:Domain_Frequency'})}= 'Time';
    end
    
    properties (Access = protected)
        % Output buffer
        pinBuff
        % Input buffer
        poutBuff
        pSumIdx
        pSum
        pLastSection;
        pIRFFT 
    end
    
    properties(Access = protected, Nontunable)
        pFFTLength
        pNumPartitions
        pDatatype
        pLastSectionLength
        pIsOutputReal
        numChannels
        pPartitionLength
        pHalideMode
    end
    
    properties (Nontunable)
        FilterIsReal (1, 1) logical = true;
    end
    
    methods
        function obj = PartitionOAOSBase(varargin)
            setProperties(obj,nargin,varargin{:});
            obj.pHalideMode = coder.const(feval('dsp.internal.feature','ActiveValue','dsp_simulations','halide'));
        end
    end
    
   methods (Access = public, Hidden)
        function setNumchans(obj,val)
            obj.numChannels   = val;
        end
    end
    
    methods(Access = protected)
        
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            if isLocked(obj)
                s.pSumIdx                  = obj.pSumIdx;
                s.pSum                     = obj.pSum;
                s.pLastSection             = obj.pLastSection;
                s.pIRFFT                   = obj.pIRFFT;
                s.pinBuff                  = saveobj(clone(obj.pinBuff));
                s.poutBuff                 = saveobj(clone(obj.poutBuff));
                s.pFFTLength               = obj.pFFTLength;
                s.pNumPartitions           = obj.pNumPartitions;
                s.pDatatype                = obj.pDatatype;
                s.pLastSectionLength       = obj.pLastSectionLength;
                s.pIsOutputReal            = obj.pIsOutputReal;
                s.numChannels              = obj.numChannels;
                s.pPartitionLength         = obj.pPartitionLength;
            end
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                obj.pSumIdx                  = s.pSumIdx;
                obj.pSum                     = s.pSum;
                obj.pLastSection             = s.pLastSection;
                obj.pIRFFT                   = s.pIRFFT;
                obj.pinBuff                  = loadobj(s.pinBuff);
                obj.poutBuff                 = loadobj(s.poutBuff);
                obj.pFFTLength               = s.pFFTLength;
                obj.pNumPartitions           = s.pNumPartitions;
                obj.pDatatype                = s.pDatatype;
                obj.pLastSectionLength       = s.pLastSectionLength;
                obj.pIsOutputReal            = s.pIsOutputReal;
                obj.numChannels              = s.numChannels;
                if isfield(s,'pPartitionLength')
                    obj.pPartitionLength         = s.pPartitionLength;
                else
                    % Pre-18a version (coefficients specified in
                    % time-domain only)
                    obj.pPartitionLength         = s.PartitionLength;
                end
            end
            loadObjectImpl@matlab.System(obj, s, wasLocked);
        end
        
        function y = stepImpl(obj,u)
            
            sz = size(u);
            numSamples  = cast(sz(1),class(u));
            numChans = obj.numChannels;
            outIsReal   = obj.pIsOutputReal;
            
            DT          = obj.pDatatype;
            
            poutbff     = obj.poutBuff;
            poutsamples = cast(poutbff.NumUnreadSamples , obj.pDatatype);
            
            pinbff      = obj.pinBuff;
            pinsamples  = cast(pinbff.NumUnreadSamples , obj.pDatatype);
            
            availableSamples  = pinsamples;
            
            L = obj.pFFTLength;
            K = obj.pPartitionLength;
            H = obj.pIRFFT;
            P = obj.pNumPartitions;
            
            totalSamples = availableSamples + numSamples;
            
            L0 =  L -  obj.pLastSectionLength;
            numFrames = min ( floor(totalSamples/L0) , floor((K + numSamples)/L0) );
            
            input      = zeros(L0*numFrames,size(u,2),'like',u);
            inpStart   = cast(1,DT);
            remSamples = L0*numFrames;
            
            % First, read samples from input buffer
            if (availableSamples > 0)
                val = min(L0*numFrames,availableSamples);
                if numFrames > 0
                    input(1:val,:) = read(pinbff,int32(val));
                    inpStart = val + cast(1,DT);
                    remSamples = remSamples - val;
                end
            end
            
            % Append new input samples
            if remSamples > 0
                input(inpStart:inpStart+remSamples-cast(1,DT),:) = u(1:remSamples,:);
            end
            
            % Put unused input samples in input buffer
            if size(u,1) > remSamples
                write(pinbff,u(remSamples+1:end,1:numChans));
            end
            
            if outIsReal
                y = zeros(numSamples, numChans,class(u));
            else
                y = zeros(numSamples, numChans,class(u)) + 1j * zeros(numSamples, numChans,class(u));
            end
            
            samplesToFill = numSamples;
            
            % First, transfer samples from output buffer to output
            ns = cast(1,DT);
            if poutsamples > 0
                ns = min(numSamples,poutsamples);
                y(1:ns,:) = read(poutbff,int32(ns));
                samplesToFill = samplesToFill - ns;
                ns = ns + 1;
            end
            
            % Compute new output samples
            if numFrames > 0
                sumY    = obj.pSum;
                p       = obj.pSumIdx;
                prevsec = obj.pLastSection;
                
                [o,prevsec,sumY,p] = obj.computeOutput(input,sumY,p,L0,numFrames,numChans,H,L,P,K,prevsec,outIsReal,coder.const(obj.pHalideMode));
                
                y(ns:end,:) = o(1:samplesToFill, :);
                if samplesToFill  < L0*numFrames
                    write(poutbff,o(samplesToFill+1:end,1:numChans));
                end
                
                obj.pSumIdx = p;
                obj.pSum = sumY;
                obj.pLastSection = prevsec;
            end
            
        end
        
        function setupImpl(obj, u)
            
            obj.pDatatype = class(u);
            
            K = obj.pPartitionLength;
            L = obj.pFFTLength;
            
            if strcmp(obj.Domain,'Time')

                h = cast(obj.Numerator.', class(u));
                
                P = ceil(length(h) / K);
                obj.pNumPartitions = P;
                
                % Zero-pad impulse response to make all partitions even
                pad = (K * P) - length(h);
                h = [h;zeros(pad,size(h,2),'like',u)];

                % H will hold the freq domain version of impulse response for each
                % partition
                obj.pIRFFT = dsp.internal.PartitionOAOSBase.getIRFreqDomain(K, P, h, L,obj.pDatatype);
                
                obj.pIsOutputReal = isreal(u) && isreal(obj.Numerator);
            else
                obj.pIRFFT = cast(obj.Numerator ,  class(u));
                obj.pNumPartitions = size(obj.Numerator,2);
                obj.pIsOutputReal = isreal(u) && obj.FilterIsReal;
            end
             
            obj.pSum = complex(zeros(L,obj.pNumPartitions,obj.numChannels,'like',u));
            
            if ~isempty(coder.target)
                obj.pinBuff               = dsp.AsyncBuffer('Capacity',max(obj.pPartitionLength,2));
                obj.poutBuff = dsp.AsyncBuffer('Capacity',max(obj.pPartitionLength,2));
            else
                
                 obj.pinBuff               = dsp.AsyncBuffer('Capacity',max(obj.pPartitionLength,2));
                 obj.poutBuff = dsp.AsyncBuffer('Capacity',max(obj.pPartitionLength,2));       
                
                setup(obj.poutBuff , zeros(obj.pPartitionLength,obj.numChannels,'like',u));
            end
            
            setup(obj.pinBuff , zeros(obj.pPartitionLength,obj.numChannels,'like',u));
            
        end
        
        function resetImpl(obj)
            
            obj.pSum = zeros(size(obj.pSum),'like',obj.pSum);
            obj.pSumIdx = cast(1,obj.pDatatype);
            obj.pLastSection = zeros(size(obj.pLastSection),'like',obj.pLastSection);
            
            reset(obj.pinBuff);
            
            reset(obj.poutBuff);
            
            if obj.pIsOutputReal
                step(obj.poutBuff ,zeros(obj.pPartitionLength,obj.numChannels,obj.pDatatype));
            else
                step(obj.poutBuff , complex(zeros(obj.pPartitionLength,obj.numChannels,obj.pDatatype)));
            end
            
        end
        
        function processTunedPropertiesImpl(obj)
            
            if strcmp(obj.Domain,'Time')
                K = obj.pPartitionLength;
                h = cast(obj.Numerator.',obj.pDatatype);
                P = obj.pNumPartitions;
                
                pad = (K * P) - length(h);
                hplus = [h;zeros(pad,size(h,2),obj.pDatatype)];
                
                L = obj.pFFTLength;
                
                obj.pIRFFT = dsp.internal.PartitionOAOSBase.getIRFreqDomain(K, P, hplus, L,obj.pDatatype);
                
            else
                obj.pIRFFT =    cast(obj.Numerator,obj.pDatatype);
            end
        end
        
        
    end
    
    methods (Static, Hidden)
        function H = getIRFreqDomain(K, P, h, L , DT)
            H = complex(zeros(L,P,DT));
            hcast = cast(h,DT);
            for j = 1:P
                hChunk = hcast(1+((j-1)*K):(j*K));
                H(:,j) = fft(hChunk,L);
            end
        end
    end
    
    methods (Static, Abstract)
        computeOutput(obj)
    end
end