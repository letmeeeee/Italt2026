classdef LMSUpdate < matlab.System
%LMSUpdate Compute weights using LMS adaptive algorithm
%   LMSUPD = dsp.LMSUpdate returns an adaptive LMS update System object,
%   LMSUPD, that computes the filter weights for a given input and error
%   signal using the Least Mean Squares (LMS) algorithm.
%
%   LMSUPD = dsp.LMSUpdate('PropertyName', PropertyValue, ...) returns an
%   LMS update System object, LMSUPD, with each specified property set to
%   the specified value.
%
%   LMSUPD = dsp.LMSUpdate(LEN, 'PropertyName', PropertyValue, ...)
%   returns an LMS update System object, LMSUPD, with the Length property
%   set to LEN, and other specified properties set to the specified values.
%
%   Step method syntax:
%
%   W = step(LMSUPD, X, E) performs the LMS update on the inputs X and E,
%   and returns the estimated filter weights in W. The System object
%   estimates the filter weights needed to minimize the error.
%
%   W = step(LMSUPD, X, E, MU) performs the LMS update on the inputs X, E,
%   and step size MU, when the StepSizeSource property.
%
%   W = step(LMSUPD, X, E, A) performs the LMS update on the inputs X, E,
%   and A as the adaptation control, when the EnableAdaptInput property is
%   true. When A is non-zero, the System object continuously updates the
%   filter weights. When A is zero, the filter weights remain constant.
%
%   W = step(LMSUPD, X, E, R) performs the LMS update on the inputs X, E,
%   and R as a reset signal when the EnableResetInput property is true.
%   When R is non-zero, the System object resets the filter weights and
%   input buffer to their initial values.
%
%   The above operations can be used simultaneously, provided the System
%   object properties are set appropriately. One example of providing all
%   possible inputs and returning all possible outputs is shown below:
%   W = step(LMSUPD, X, E, MU, A, R) performs the LMS update using X and E,
%   with MU as the step size, A as the adaptation control, and R as the
%   reset signal, and returns the filter weights in W.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   LMSUpdate methods:
%
%   step     - See above description for use of this method
%   reset    - Reset input buffer and weights to initial conditions
%   release  - Allow property value and input characteristics changes
%   clone    - Create LMSUpdate object with same property values
%   isLocked - Locked status (logical)
%
%   LMSUpdate properties:
%
%   Method            - Method to calculate filter weights
%   Length            - Length of FIR filter weights vector
%   NumFilters        - Number of adaptive filters
%   StepSizeSource    - How to specify adaptation step size
%   StepSize          - Adaptation step size
%   LeakageFactor     - Leakage factor used in Leaky LMS method
%   InitialConditions - Initial conditions of filter weights
%   AdaptiveFilterMode- Specify the adaptive filter behavior to be a tapped delay-line FIR filter or an adaptive linear combiner
%   EnableAdaptInput  - Enable adapt input (conditional weight adaptation)
%   EnableResetInput  - Enable reset input (conditional state reset)
%
%   See also dsp.LMSFilter, dsp.BlockLMSFilter

%   Copyright 1995-2022 The MathWorks, Inc.

%#codegen

%For MATLAB compiler support

%#ok<*EMCLS>
%#ok<*EMCA>

properties (Nontunable)
  %Method Algorithm
  %   Specify the method used to calculate filter weights as one of
  %   ['LMS' | 'Normalized LMS' | 'Sign-Error LMS' | 'Sign-Data LMS' |
  %   'Sign-Sign LMS'].
  Method (1, :) char {matlab.system.mustBeMemberMessageID(Method, ...
            {'dsp:system:LMSUpdate:Method_LMS'; ...
            'dsp:system:LMSUpdate:Method_NormalizedLMS'; ...
            'dsp:system:LMSUpdate:Method_SignErrorLMS'; ...
            'dsp:system:LMSUpdate:Method_SignDataLMS'; ...
            'dsp:system:LMSUpdate:Method_SignSignLMS'})} = 'LMS';
  %Length Filter length
  %   Specify the length of filter weights of each adaptive filter as a
  %   positive scalar integer value. The default value of this property is
  %   32.
  Length (1, 1) {mustBePositive, mustBeInteger} = 32;
  % NumFilters Number of adaptive filters
  %   Specify the number of FIR adaptive filers as a positive scalar
  %   integer. The default value of this property is 1.
  NumFilters (1, 1) {mustBePositive, mustBeInteger} = 1  
  %StepSizeSource Step size source
  %   Choose how to specify the adaptation step size factor as one of
  %   ['Property' | 'Input port'].
  StepSizeSource (1, :) char {matlab.system.mustBeMemberMessageID(StepSizeSource, ...
            {'dsp:system:LMSUpdate:StepSizeSource_Property'; ...
            'dsp:system:LMSUpdate:StepSizeSource_Inputport'})} = 'Property';
end

properties
  %StepSize Step size (mu)
  %   Specify the adaptation step size factor as a scalar non-negative
  %   numeric value. For convergence of the normalized LMS method, the step
  %   size should be greater than 0 and less than 2. The default value of
  %   this property is 0.1. This property is applicable when the
  %   StepSizeSource property is 'Property'. This property is tunable.
  StepSize =  0.1;
  %LeakageFactor Leakage factor (0 to 1)
  %   Specify the leakage factor used in Leaky LMS method as a scalar
  %   numeric value between 0 and 1, both inclusive. When the value is less
  %   than 1, the System object implements a leaky LMS method. The default
  %   value of this property is 1, providing no leakage in the adapting
  %   method. This property is tunable.
  LeakageFactor =  1.0;
end

properties (Nontunable)
  %InitialConditions Initial value of filter weights
  %   Specify the initial values of the filter weights as a scalar or
  %   matrix of size equal to the NumFilters x Length. The default
  %   value of this property is 0.
  InitialConditions =  0;
  %AdaptiveFilterMode Adaptive filter mode
  %   Specify the adaptive filter mode as 'Tapped delay-line FIR filter' or
  %   'Adaptive linear combiner'. By default, the value of this property is
  %   'Tapped delay-line FIR filter' and the input must be a scalar. In
  %   this case, the object assumes that the input is a tapped delay line
  %   and keeps track of the buffer internally. When the value of this
  %   property is set to 'Adaptive linear combiner', the input provided to
  %   the step function must be a column vector with number of elements
  %   equal to filter length.
  AdaptiveFilterMode (1, :) char {matlab.system.mustBeMemberMessageID(AdaptiveFilterMode, ...
      {'dsp:system:LMSUpdate:AdaptiveFilterMode_TappeddelaylineFIRfilter'; ...
      'dsp:system:LMSUpdate:AdaptiveFilterMode_Adaptivelinearcombiner'})} = 'Tapped delay-line FIR filter';
end

properties (Nontunable, Access = private)
    pInitialConditions
end

properties (Nontunable)
  %EnableAdaptInput Enable adapt input
  %   Specify when the System object should adapt the filter weights. By
  %   default, the value of this property is false, and the object
  %   continuously updates the filter weights. When this property is set to
  %   true, an adaptation control input is provided to the step method. If
  %   the value of this input is non-zero, the object continuously updates
  %   the filter weights. If the input is zero, the filter weights remain
  %   at their current value.
  EnableAdaptInput (1, 1) logical =  false;
  %EnableResetInput Enable reset input
  %   Specify when the System object should reset the filter weights. By
  %   default, the value of this property is false, and the object does not
  %   reset the weights. When this property is set to true, a reset control
  %   input is provided to the step method. If the value of this input is
  %   non-zero, the filter weights and input buffer values are reset to
  %   their initial values.
  EnableResetInput (1, 1) logical = false;
end

properties (Hidden, SetAccess = private, GetAccess = public)
    % Weights Matrix of filter weights  
    % The size of the matrix equals to NumFilters x Length with each row
    % corresponding to weights of the corresponding adaptive filter.
    Weights = zeros(1,32);
end

properties (Access = private)
    % xBuffer Input sample delay line
    xBuffer;
end
    
methods
    %CONSTRUCTOR
    function obj = LMSUpdate(varargin)
        coder.allowpcode('plain');
        setProperties(obj, nargin, varargin{:}, 'Length');
    end
    
    % Validating and setting StepSize
    function set.StepSize(obj,val)
        validateattributes(val, {'numeric'}, ...
            {'2d', 'nonsparse', 'scalar', 'real', 'finite'}, '', ...
            'StepSize)');
        
        coder.internal.errorIf((val < 0), ...
            'dsp:system:AdaptiveFilter:mustBePositiveRealScalar', ...
            'StepSize');
        
        obj.StepSize = val;
    end
    
    % Validating and setting LeakageFactor
    function set.LeakageFactor(obj,val)
        validateattributes(val, {'numeric'}, ...
            {'2d', 'nonsparse', 'scalar', 'real', 'finite'}, '', ...
            'LeakageFactor)');
        
        coder.internal.errorIf(~(val >= 0 && val <= 1), ...
            'dsp:system:AdaptiveFilter:mustBeRealScalar0to1Closed', ...
            'LeakageFactor');
        
        obj.LeakageFactor = val;
    end
    
    % Validating and setting InitialConditions
    function set.InitialConditions(obj,val)
        validateattributes(val, {'numeric'}, ...
            {'2d', 'nonsparse', 'finite'}, '', ...
            'InitialConditions');
        
        coder.internal.errorIf(~(isnumeric(val) && ismatrix(val) && all(isfinite(val(:)))), ...
            'dsp:system:LMSUpdate:mustBeNumericMatrix', 'InitialConditions');
        
        obj.InitialConditions = val;
    end
end

methods(Access=protected)
    function setupImpl(obj, X, ~, varargin)
        obj.xBuffer = zeros(1,obj.Length,'like',X); % cast to input type
        obj.Weights = zeros(obj.NumFilters,obj.Length,'like',X); % cast to input type
        obj.pInitialConditions = cast(obj.InitialConditions,class(X));
    end
    
    function resetImpl(obj)
        % Reset internal INPUT BUFFER
        obj.xBuffer(:) = cast(0,class(obj.xBuffer));
        % Reset internal WEIGHTS (ICs can be scalar or matrix)
        obj.Weights(:) = obj.pInitialConditions;
    end
    
    function W = stepImpl(obj, X, E, varargin)
        if strcmp(obj.StepSizeSource, 'Input port') % const folded for cg
            optArgIdx = 1; % keep track of optional input argument index
            mu = varargin{1};
        else
            optArgIdx = 0;
            mu = obj.StepSize;
        end

        if (obj.EnableAdaptInput) % const folded for codegen
            optArgIdx = optArgIdx + 1;
            adaptIn   = varargin{optArgIdx};
            doAdapt = logical(adaptIn(:));
        else
            doAdapt   = true;
        end
        
        if (obj.EnableResetInput) % const folded for codegen
            optArgIdx = optArgIdx + 1;
            doReset   = varargin{optArgIdx};
        else
            doReset   = false;
        end
        if doReset
            reset(obj);
        else
            if strcmp(obj.AdaptiveFilterMode,'Tapped delay-line FIR filter')
                % Update input sample buffer
                % (TODO: using linear buffer for now, to avoid double loop
                % with extra indexing in arithmetic code below as well as extra
                % private data property for circular buffer index value. Check
                % the speed of linear vs. circular buffer implementations here)
                L                = obj.Length;
                obj.xBuffer(2:L) = obj.xBuffer(1:L-1); 
                obj.xBuffer(1)   = X;
                X_buffer = obj.xBuffer;
            else
                X_buffer = X.';
            end

            % Compute LMS weights
            lk    = obj.LeakageFactor;
            if any(doAdapt)
                if isscalar(doAdapt)
                    obj.Weights = dsp.internal.LMSUpdate.lmsupdaterSignSign(X_buffer,...
                        obj.Weights,E,obj.Method,lk,mu);   
                else
                    obj.Weights(doAdapt,:) = dsp.internal.LMSUpdate.lmsupdaterSignSign(X_buffer,...
                        obj.Weights(doAdapt,:),E(doAdapt),obj.Method,lk,mu); 
                end
            end
        end            
                   
        % COMMON RETURN POINT
        W = obj.Weights;
    end
    
    function flag = isInactivePropertyImpl(obj, prop)
        flag = false;
        switch prop
            case 'StepSize'
                if strcmp(obj.StepSizeSource, 'Input port')
                    flag = true;
                end
        end
    end
    
    function validatePropertiesImpl(obj)
        % Validating the dimensions of the InitialConditions property
        sizePInit=size(obj.InitialConditions);
        coder.internal.errorIf(~(isscalar(obj.InitialConditions) || isequal(sizePInit,[obj.NumFilters obj.Length])),...
            'dsp:system:LMSUpdate:IncorrectInitialConditionsSize','InitialConditions',obj.NumFilters,obj.Length);
    end
    
    function validateInputsImpl(obj, X, E, varargin)
        coder.extrinsic('getString');
        coder.extrinsic('message');
        
        % Validate the input X. 
        % X must be scalar if input is processed as Tapped delay-line FIR filter and X must
        % be a vector if input is processed as Adaptive linear combiner. The datatype
        % must be double or single.
        validateattributes(X, {'double','single'}, ...
            {'2d', 'nonsparse', 'nonempty','vector'}, '', ...
            getString(message('dsp:system:LMSUpdate:InputPortLabel')));
        chkInputSizeVector = strcmp(obj.AdaptiveFilterMode,'Adaptive linear combiner') && ~isequal(size(X),[obj.Length 1]);
        coder.internal.errorIf(chkInputSizeVector,...
            'dsp:system:LMSUpdate:ExpectedBufferedInput',obj.Length);
        
        chkInputSizeScalar = strcmp(obj.AdaptiveFilterMode,'Tapped delay-line FIR filter') && ~isscalar(X);
        coder.internal.errorIf(chkInputSizeScalar,...
            'dsp:system:LMSUpdate:ExpectedScalarInput');    
        % X cannot be complex when the Method property is one of
        % 'Sign-Error LMS', 'Sign-Data LMS', or 'Sign-Sign LMS'
        chkSignLMS = any(strcmp({'Sign-Error LMS', 'Sign-Data LMS', 'Sign-Sign LMS'},obj.Method));
        coder.internal.errorIf(chkSignLMS && ~isreal(X),...
            'dsp:system:LMSUpdate:ExpectedRealInput',getString(message('dsp:system:LMSUpdate:InputPortLabel')));

        % Validate the error E. 
        % E must be a column vector of size obj.NumFilters
        validateattributes(E, {'double','single'}, ...
            {'2d', 'nonsparse', 'nonempty', 'vector', 'column'}, '', ...
            getString(message('dsp:system:LMSUpdate:ErrorPortLabel')));
        coder.internal.errorIf(~isequal(size(E),[obj.NumFilters 1]),...
            'dsp:system:LMSUpdate:IncorrectErrorSize',obj.NumFilters)

        % E cannot be complex when the Method property is one of
        % 'Sign-Error LMS', 'Sign-Data LMS', or 'Sign-Sign LMS'
        coder.internal.errorIf(chkSignLMS && ~isreal(E),...
            'dsp:system:LMSUpdate:ExpectedRealInput',getString(message('dsp:system:LMSUpdate:ErrorPortLabel')));        

        % X and E must both be same type (i.e., both single or both double)
        coder.internal.errorIf(~(strcmp(class(X), class(E))), ...
            'dsp:system:LMSUpdate:inputsNotFloatingPoint');

        % Validate optional input port Mu
        if strcmp(obj.StepSizeSource, 'Input port')
            optArgIdx = 1; % keep track of optional input port indices
            muPortSig = varargin{optArgIdx};
            validateattributes(muPortSig, {'double','single'}, ...
                {'2d', 'nonsparse', 'scalar', 'real', 'finite'}, '', ...
                getString(message('dsp:system:LMSUpdate:StepSizePortLabel')))

            % X and muPortSig must both be single or both double.
            coder.internal.errorIf(~(strcmp(class(X), class(muPortSig))), ...
                'dsp:system:LMSUpdate:inputsNotFloatingPoint');
            coder.internal.errorIf(isempty(muPortSig), ...
                'MATLAB:system:inputMustBeScalar', ...
                getString(message('dsp:system:LMSUpdate:StepSizePortLabel')));
        else
            optArgIdx = 0;
        end
        
        % Validate optional input port Adapt
        % If the Adapt input port is enabled, the Adapt input must be a
        % scalar or a vector of length equal to obj.NumFilters
        if (obj.EnableAdaptInput)
            optArgIdx = optArgIdx + 1;
            adPortSig = varargin{optArgIdx};
            validateattributes(adPortSig, {'logical','numeric'}, ...
                {'2d', 'nonsparse', 'vector', 'real', 'finite'}, '', ...
                getString(message('dsp:system:LMSUpdate:AdaptPortLabel')));
                
            coder.internal.errorIf(isempty(adPortSig), ...
                'MATLAB:system:inputMustBeVector', ...
                getString(message('dsp:system:LMSUpdate:AdaptPortLabel')));
            coder.internal.errorIf(~(isscalar(adPortSig) ||length(adPortSig)==obj.NumFilters),...
                'dsp:system:LMSUpdate:IncorrectAdaptSize',obj.NumFilters);
        end
        
        % Validate optional input port Reset
        if (obj.EnableResetInput)
            optArgIdx = optArgIdx + 1;
            rsPortSig = varargin{optArgIdx};
            validateattributes(rsPortSig, {'logical','numeric'}, ...
                {'2d', 'nonsparse', 'scalar', 'real', 'finite'}, '', ...
                getString(message('dsp:system:LMSUpdate:ResetPortLabel')));
                
            coder.internal.errorIf(isempty(rsPortSig), ...
                'MATLAB:system:inputMustBeScalar', ...
                getString(message('dsp:system:LMSUpdate:ResetPortLabel')));
        end
    end
           
    %% Backup/restore functions
    function s = saveObjectImpl(obj)
        s = saveObjectImpl@matlab.System(obj);
        if isLocked(obj)
            s.Weights = obj.Weights;
            s.xBuffer = obj.xBuffer;
            s.pInitialConditions = obj.pInitialConditions;
        end
    end
    
    function loadObjectImpl(obj,s,wasLocked)
        % Call base class method
        loadObjectImpl@matlab.System(obj, s, wasLocked);
        if wasLocked
            if isfield(s, 'Weights')
                obj.Weights = s.Weights;
            end
            if isfield(s, 'xBuffer')
                obj.xBuffer = s.xBuffer;
            end
            if isfield(s, 'pInitialConditions')
                obj.pInitialConditions = s.pInitialConditions;
            end
        end
    end
    
    function flag = isInputSizeMutableImpl(~,~)
        flag = false;
    end
    
    function flag = isInputComplexityMutableImpl(~,~)
        flag = false;
    end    
   
    function dt = getTunablePropertiesSpecificationImpl(obj,~)
        dt = propagatedInputDataType(obj,1);
    end
    
    function N = getNumInputsImpl(obj)
        % Specify number of System inputs
        N = 2 + double(strcmp(obj.StepSizeSource, 'Input port')) + ...
            double(obj.EnableAdaptInput) + double(obj.EnableResetInput);
    end
    
    function N = getNumOutputsImpl(~)
        % Specify number of System outputs
        N = 1; % Weights
    end
end

methods(Static, Hidden)
    function wBuffer = lmsupdaterSignSign(x_buf,wBuffer,E,Method,lambda,mu)
    % Function to update weights 
        switch Method
            case 'LMS'
                wBuffer = lambda * wBuffer + mu.*conj(x_buf).*E;
            case 'Normalized LMS'
                engyPlusEps = sum(x_buf .* conj(x_buf)) + eps(x_buf(1));
                wBuffer = lambda * wBuffer + mu.*conj(x_buf).*E./engyPlusEps;
            case 'Sign-Data LMS'
                wBuffer = lambda * wBuffer + mu.*sign(x_buf).*E;
            case 'Sign-Error LMS'
                wBuffer = lambda * wBuffer + mu.*conj(x_buf).*sign(E);
            case 'Sign-Sign LMS'
                wBuffer = lambda * wBuffer + mu.*sign(x_buf).*sign(E);
        end
    end
    function  props = getDisplayPropertiesImpl()
        props = {...
            'Method', ...
            'Length', ...
            'NumFilters',...
            'StepSizeSource', ...
            'StepSize', ...
            'LeakageFactor', ...
            'InitialConditions', ...
            'AdaptiveFilterMode',...
            'EnableAdaptInput', ...
            'EnableResetInput'};
    end
end
end
