classdef FilterVisualizationButton
%FILTERVISUALIZATIONBUTTON Button to view filter response on dialog of
%System block.
%  Example usage in getPropertyGroupsImpl method of a System object:
%      mainS = matlab.system.display.Section('Title', 'Parameters', ...
%                 'PropertyList', props);  
%      filterVis = dsp.internal.FilterVisualizationButton;
%      mainS.Actions = filterVis.fvtoolAction;
%  This will add a 'View Filter Response' button on the dialog when the
%  System object is used in a MATLAB System block. Clicking the button will
%  call fvtool on the object.

% Copyright 2015-2023 The MathWorks, Inc.
    
    properties
        % Holds information about the button
        fvtoolAction
    end
    
    methods
        function obj = FilterVisualizationButton
            % Create the button
            obj.fvtoolAction = matlab.system.display.Action(...
                @dsp.internal.FilterVisualizationButton.onActionCalled, ...
                'Label','dsp:system:Shared:Visualize',...
                'Placement','last','Alignment','right');
            % Associate callbacks for dialog apply and block delete
            matlab.system.display.internal.setCallbacks(obj.fvtoolAction, ...
                'DialogAppliedFcn', @dsp.internal.FilterVisualizationButton.onDialogApplied, ...
                'SystemDeletedFcn', @dsp.internal.FilterVisualizationButton.onSystemDeleted, ...
                'PropertyResolveErrorFcn', @dsp.internal.FilterVisualizationButton.onUnresolvedProperty);
        end
    end
    
    methods (Static, Access=protected)
        function onActionCalled(actionData, sysObj)

            [supported, errID] = isFVtoolSupported(sysObj);
            if ~supported
                % The object does not support fvtool in this setting
                actionData.UserData.errordlgHandle = ...
                    errordlg(getString(message(errID)),...
                    getString(message('dsp:system:Shared:fvtoolButtonInheritSRTitle')), ...
                    'replace');
                return;
            end
            
            f = [];
            if isfield(actionData.UserData,'fvtoolHandle')
                f = actionData.UserData.fvtoolHandle;
            end
            if isempty(f) || ~isvalid(f)   
                % Cache object characteristics
                ud = actionData.UserData;
                ud = dsp.internal.FilterVisualizationButton.cacheProperties(ud,sysObj);
                % Call fvtool. Set the block's name to its legend string.
                ud.fvtoolHandle = callFvtool(ud.pSysObj);
                isCalledFromBlock = ~isa(actionData.SystemHandle, 'matlab.System');
                if isCalledFromBlock
                    % Do not update legend string if called from System
                    % object editor
                    ud.fvtoolHandle = updateFvtoolLegend(ud.pSysObj,ud.fvtoolHandle,actionData.SystemHandle);
                end
                actionData.UserData = ud;
            else
                % Apply unapplied changes and bring figure to focus
                dsp.internal.FilterVisualizationButton.onDialogApplied(actionData, sysObj)
                figure(f);
            end
        end
        %------------------------------------------------------------------
        function onDialogApplied(actionData, sysObj)
            % Close an existing error dialog
            
            [supported, errID] = isFVtoolSupported(sysObj);
            
            if supported
                w = [];
                if isfield(actionData.UserData,'errordlgHandle')
                    w = actionData.UserData.errordlgHandle;
                end
                if ~isempty(w) && isvalid(w)
                    delete(w);
                end
            end

            % Refresh plot if needed
            f = [];
            if isfield(actionData.UserData,'fvtoolHandle')
                f = actionData.UserData.fvtoolHandle;
            end
            if ~isempty(f) && isvalid(f)
                ud = actionData.UserData;
                ah = [];
                if isfield(ud,'annotationHandle')
                    ah = ud.annotationHandle;
                end
                annotationAbsent = (isempty(ah) || ~isvalid(ah));
                % if there isn't any annotation on figure and no property
                % has changed then no need to update the plot
                if annotationAbsent && ...
                        ~dsp.internal.FilterVisualizationButton.propertiesChanged(ud,sysObj)
                    return;
                end
                % Cache the new property values
                ud = dsp.internal.FilterVisualizationButton.cacheProperties(ud,sysObj);
                % Update plot with new filter. If sample rate is inherited,
                % the update existing plot to show nothing.
                if ~supported 
                    str = getString(message(errID));
                    ud = dsp.internal.FilterVisualizationButton.blankAndAnnotate(ud, f, actionData.SystemHandle, str);
                else
                    % Delete annotation about inherited sample rate
                    if ~annotationAbsent
                        delete(ah);
                    end
                    % Update figure with new filter
                    ud.fvtoolHandle = updateFvtoolFigure(ud.pSysObj,f);
                    isCalledFromBlock = ~isa(actionData.SystemHandle, 'matlab.System');
                    if isCalledFromBlock
                        ud.fvtoolHandle = updateFvtoolLegend(ud.pSysObj, ud.fvtoolHandle, actionData.SystemHandle);
                    end
                end
                actionData.UserData = ud;
             end
        end
        %------------------------------------------------------------------
        function onSystemDeleted(actionData)
            % Close an existing warning dialog
            w = [];
            if isfield(actionData.UserData,'errordlgHandle')
                w = actionData.UserData.errordlgHandle;
            end
            if ~isempty(w) && isvalid(w)
                delete(w);
            end
            % Close visualization
            f = [];
            if isfield(actionData.UserData,'fvtoolHandle')
                f = actionData.UserData.fvtoolHandle;
            end

            if ~isempty(f) && isvalid(f) && isobject(f)
                close(f);
            end
        end
        %------------------------------------------------------------------
        function onUnresolvedProperty(actionData, e, ~)
            f = [];
            if isfield(actionData.UserData,'fvtoolHandle')
                f = actionData.UserData.fvtoolHandle;
            end
            if ~isempty(f) && isvalid(f)
                ud = actionData.UserData;
                % update existing plot to show nothing
                str = getString(message('dsp:system:Shared:fvtoolButtonUnresolvedParameter', e.message));
                ud = dsp.internal.FilterVisualizationButton.blankAndAnnotate(ud, f, actionData.SystemHandle, str);
                actionData.UserData = ud;
            end
            
            % Abort callback
            throw(e);
        end
        %------------------------------------------------------------------
        function flag =  propertiesChanged(ud,sysObj)
            % Check if a property value has changed since last button press
            if isfield(ud,'pSysObj')
                pObj = ud.pSysObj;
                props = properties(pObj);
                idx = 0;
                flag = false;
                
                w = warning('off', 'MATLAB:system:nonRelevantProperty');
                restoreWarn = onCleanup(@() warning(w));
            
                while (idx < length(props)) && (~flag)
                    idx = idx + 1;
                    flag = flag || ~(isequal(pObj.(props{idx}), sysObj.(props{idx})));
                end
            else
                flag = true;
            end
        end
        %------------------------------------------------------------------
        function  ud = cacheProperties(ud,sysObj)
            % Save the System object, to act as baseline for checking for
            % any property change in the future
            if ~isfield(ud,'pSysObj')
                ud.pSysObj = clone(sysObj);
                return
            end
            
            w = warning('off', 'MATLAB:system:nonRelevantProperty');
            restoreWarn = onCleanup(@() warning(w));
            
            props = properties(sysObj);
            if ~isempty(intersect(props, 'SampleRate'))
                if (sysObj.SampleRate < 0)
                    % Do not copy SampleRate because it is inherited and
                    % not yet available
                    props = setdiff(props, 'SampleRate', 'stable');
                end
            end
            
            mco = metaclass(sysObj);
            propList = mco.PropertyList;
            metaNames = {propList.Name};

            for index = 1:length(props)
                try
                    ind = find(strcmp(metaNames,props{index}));
                    if ~strcmp(propList(ind).SetAccess,'private')%#ok
                        ud.pSysObj.(props{index}) = sysObj.(props{index});
                    end
                catch E
                    % swallow the error of setting states
                    if ~strcmp(E.identifier, 'MATLAB:system:stateInvalidPublicSet')
                        throw(E);
                    end
                end
            end
        end
        %------------------------------------------------------------------
        function ud = blankAndAnnotate(ud, f, blkh, str)
            isCalledFromBlock = ~isa(blkh, 'matlab.System');
            if isCalledFromBlock
                rblk = get(blkh, 'ReferenceBlock');
                isUsingFreqz = strcmp(rblk, sprintf('dspsigops/Sample-Rate\nConverter')) || ...
                    strcmp(rblk, sprintf('dspmlti4/Complex Bandpass\nDecimator'));
            else
                isUsingFreqz = isa(blkh, 'dsp.simulink.SampleRateConverter') || isa(blkh, 'dsp.simulink.ComplexBandpassDecimator');
            end
            if isUsingFreqz
                lgd = findobj(f.Children, 'Type', 'Legend');
                for idx = 1:length(lgd)
                    delete(lgd);
                end
                
                ax = findobj(f.Children, 'Type', 'Axes');
                for idx = 1:length(ax)
                    lineObj = ax(idx).Children;
                    if ~isempty(lineObj) && isvalid(lineObj)
                        delete(lineObj); % remove existing data
                    end
                end
                for idx = 1:length(ax)                   
                    delete(ax); 
                end
                ah = [];
                if isfield(ud,'annotationHandle')
                    ah = ud.annotationHandle;
                end
                if isempty(ah) || ~isvalid(ah)
                    ud.annotationHandle = annotation(f, ...
                        'textbox', [0.1, 0.25, 0.1, 0.1]);
                end
                ud.annotationHandle.String  = str;
            else
                setfilter(f , 0, 1);
                if isCalledFromBlock
                    legend(f, get_param(blkh, 'Name'));
                end
                ah = [];
                if isfield(ud,'annotationHandle')
                    ah = ud.annotationHandle;
                end
                if isempty(ah) || ~isvalid(ah)
                    ud.annotationHandle = annotation(get(get(f, 'CurrentAxes'), 'Parent'), ...
                        'textbox', [0.25, 0.45, 0.1, 0.1]);
                end
                ud.annotationHandle.String  = str;
            end
        end
    end
    
end
