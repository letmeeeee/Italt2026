function props = createCustomDataTypeProps(ntObj, varargin)
%createCustomDataTypeProps Create a System object data type props structure
%   This is a private function used only by System objects.

%   Copyright 2014 The MathWorks, Inc.

props.DataTypeMode   = 'Fixed-point: binary point scaling';
if isempty(ntObj.SignednessBool) || ntObj.SignednessBool
    props.Signedness = 'Signed';
    signBoolean      = true;
else
    props.Signedness = 'Unsigned';
    signBoolean      = false;
end
props.WordLength     = int32(ntObj.WordLength);
props.FractionLength = int32(ntObj.FractionLength);
props.Slope          = 0;
props.Bias           = 0;
props.IsAlias        = false;

if strcmp(ntObj.DataTypeMode, 'Fixed-point: unspecified scaling') && (nargin > 1) && (~isempty(varargin{1}))

    % UNSPECIFIED FractionLength (i.e., use best precision)
    
    arrayOfValues = varargin{1};
    columOfValues = arrayOfValues(:);
    maximumAbsVal = max(abs(columOfValues));
    [normFraction, bitsIntPart] = log2(maximumAbsVal); % C "FREXP"
    bestPrecFractionLength = ...
        double(ntObj.WordLength) - bitsIntPart - double(signBoolean);
    if (signBoolean && (normFraction == 0.5))
        % Some of the original values used to compute the max abs values
        % could be negative, and some could be positive. If they are ALL
        % negative values, and are ALL an exact power-of-two (e.g. "-1"),
        % then we can represent them using one extra bit of precision,
        % (extra fraction length bit), resulting in more accuracy overall.
        indicesValsWithMaxAbsV = (abs(columOfValues) == maximumAbsVal);
        originalValsWithMaxAbs = columOfValues(indicesValsWithMaxAbsV);
        bestPrecFractionLength = bestPrecFractionLength + ...
            double(all(originalValsWithMaxAbs < 0)); % Use one more bit
    end
    props.FractionLength(:) = bestPrecFractionLength; % cast-assign
end
