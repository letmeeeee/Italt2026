classdef HampelFilterCG < matlab.System
% HampelFilterCG This class is used in dsp.HampelFilter

%   Copyright 2016-2019 The MathWorks, Inc.

%#codegen
%#ok<*EMCLS>

    properties (Nontunable)
        % WindowLength Sliding window length
        WindowLength = 11;
        % NumChans Number of input channels
        NumChans  = 1;
    end

    properties 
        Threshold = 3;
    end

    properties (Access = private, Nontunable)
       % pDatatype Cache input datatype
       pDatatype; 
    end
    
    properties (Access = private)
        % pWinLen Window length cast to input datatype
        pWinLen    
        % pBuf Buffer of data values, hold most recent WindowLength samples
        pBuf 
        % pHeap Heap indices. The middle of pHeap holds the index to the
        % median in pBuf. The first part of pHeap holds the indices of the
        % max heap in pBuf. The second part of pHeap holds the indices of 
        % the lower min-max heap in pBuf. The third part of pHeap holds the
        % indices of the upper min-max heap in pBuf. The fourth part of 
        % pHeap holds the indices of the min heap in pBuf
        pHeap
        % pMidIdx Index value pointing to the middle of the heap (holds
        % median value)
        pMidIdx
        % pIdx Position in pBuf. Indicates which value should be
        % overwritten next in pBuf
        pIdx 
        % pPos Heap position. Indicates where we are in the heap (min, max,
        % interval
        % or median)
        pPos   

        % pMinHeapLength Number of elements in min heap
        pMinHeapLength
        % pMaxHeapLength Number of elements in max heap
        pMaxHeapLength

        % pMinHeapIdx starting index of the min heap
        pMinHeapIdx
        % pMaxHeapIdx starting index of the max heap
        pMaxHeapIdx

        % pCurrSampIdx position in pBuf of the current sample to be returned
        pCurrSampIdx
    end

    properties (Access = private)
        % pScale scale the MAD by ~1.4826 as an estimate of its standard
        % deviation.
        pScale
    end

    methods
        % Constructor
        function obj = HampelFilterCG(varargin)
            setProperties(obj, nargin, varargin{:});
        end
    end
    
    methods (Access = protected)

        function setupImpl(obj,x)
            obj.pDatatype = class(x);
            % obj.pScale = ~1.4826 
            obj.pScale = coder.const(-1/(sqrt(2)*erfcinv(cast(3/2,obj.pDatatype))));
        end
        
        function [y,isOutlier] = stepImpl(obj,x)
            y = zeros(size(x),class(x));
            isOutlier = false(size(x));
            
            % Loop through channels.
            for chanIndex = 1:obj.NumChans
                for index = 1:cast(size(x,1),class(x))
                    % For each sample, insert new value into heap, re-order
                    % the heap if necessary, and return the value (median 
                    % if it is an outlier).
                    insertElement(obj,x(index,chanIndex),chanIndex);
                    [ y(index,chanIndex), isOutlier(index,chanIndex) ] = getValue(obj,chanIndex);
                end
            end
        end
        
        function resetImpl(obj)
            
            % Reset states
            
            nchan = obj.NumChans;
            wlen  = obj.WindowLength;
            dt    = obj.pDatatype;
            
            obj.pBuf    = zeros(wlen,nchan, dt);
            obj.pPos    = zeros(wlen,nchan, dt);
            obj.pHeap   = zeros(wlen,nchan, dt);
            obj.pWinLen = cast(wlen, dt);
            obj.pIdx    = obj.pWinLen * cast(ones(1,nchan),dt);
            obj.pMidIdx = ceil((obj.pWinLen +1) / 2);
            
            % For even (wlen-1)/2, min and max heaps have the same
            % number of elements.
            % For odd (wlen-1)/2, max heap has one more element.
            obj.pMinHeapLength = floor( ((obj.pWinLen-1)/2) / 2 ) * cast(ones(1,nchan),dt);
            obj.pMaxHeapLength = ceil( ((obj.pWinLen-1)/2) / 2 ) * cast(ones(1,nchan),dt);

            obj.pMaxHeapIdx = obj.pMaxHeapLength;
            obj.pMinHeapIdx = (obj.pWinLen+1) * cast(ones(size(obj.pMinHeapLength)),dt) - obj.pMinHeapLength;

            obj.pCurrSampIdx = cast((wlen-1)/2, dt) * cast(ones(1,nchan),dt);
            
            % The middle of pHeap holds the index of the median value in
            % pBuf. The first half of pHeap holds the indices to the
            % max-heap and lower min-max heap values in pBuf. The second 
            % half of pHeap holds the indices to the min-heap and upper 
            % min-max heap values in pBuf. pPos holds indices into pHeap 
            % and is used to decide where in the heap structure the next 
            % element should be inserted Incoming elements are inserted in 
            % the following order: 
            % 1. median
            % 2. lower min-max heap
            % 3. upper min-max heap
            % 4. repeat steps 2 and/or 3 until the heap(s) are filled
            % 5. max heap
            % 6. min heap
            % 7. repeat steps 5 and/or 6 until the heap(s) are filled
            %
            % For example, for a window length of 9:
            % The first two elements in pHeap hold the max heap indices
            % The next two elements in pHeap hold the lower min-max heap 
            % indices
            % The middle element in pHeap holds the median value index
            % The next two elements in pHeap hold the upper min-max heap
            % indices
            % The last two elements in pHeap hold the min heap indices
            % pPos holds the order of insertion: [5 4 6 3 7 2 8 1 9]
            % pHeap holds the location in the buffer: [8 6 4 2 1 3 5 7 9]
            cnt1 = cast(1, obj.pDatatype);
            cnt2 = obj.pWinLen;
            for index = wlen:-1:1
                if mod(index,2) == 0
                    obj.pPos(index,:) = cnt1;
                    cnt1 = cnt1 + 1;
                else
                    obj.pPos(index,:) = cnt2;
                    cnt2 = cnt2 - 1;
                end
                obj.pHeap(obj.pPos(index),:) = index;
            end
        end

        function val = compareItems(obj,  ind1, ind2, chanIdx)
            % Compare items ind1 and ind2. 
            % Return true if first element less than second element.

            val =  (obj.pBuf(obj.pHeap(ind1,chanIdx),chanIdx) < obj.pBuf(obj.pHeap(ind2,chanIdx),chanIdx));
        end

        function swapElements(obj, ind1, ind2 , chanIdx)
            % Swap elements in heap.

            temp = obj.pHeap(ind1,chanIdx);
            obj.pHeap(ind1,chanIdx)=obj.pHeap(ind2,chanIdx);
            obj.pHeap(ind2,chanIdx)=temp;
            obj.pPos(obj.pHeap(ind1,chanIdx),chanIdx)=ind1;
            obj.pPos(obj.pHeap(ind2,chanIdx),chanIdx)=ind2;
        end

        function trickleDownMin(obj, i, chanIdx)
            % Trickle element down the min-heap until heap is in good order.

            while (i <= obj.pMinHeapLength(chanIdx))
                if (i>1 && i < obj.pMinHeapLength(chanIdx) && compareItems(obj, i+1+obj.pMinHeapIdx(chanIdx)-1, i+obj.pMinHeapIdx(chanIdx)-1, chanIdx))
                    i = i + 1;
                end
                flag = compareItems(obj,i+obj.pMinHeapIdx(chanIdx)-1,fix(i/2)+obj.pMinHeapIdx(chanIdx)-1,chanIdx);
                if (~flag)
                    break;
                end
                swapElements(obj,i+obj.pMinHeapIdx(chanIdx)-1,fix(i/2)+obj.pMinHeapIdx(chanIdx)-1, chanIdx);
                i = i * 2;
            end
        end
        
        function trickleDownMax( obj, i, chanIdx)
            % Trickle element down the max-heap until heap is in good order.

            while (i >= -obj.pMaxHeapLength(chanIdx))
                if (i<-1 && i > -obj.pMaxHeapLength(chanIdx) && compareItems(obj, i+obj.pMaxHeapIdx(chanIdx)+1, i-1+obj.pMaxHeapIdx(chanIdx)+1, chanIdx))
                    i = i - 1;
                end
                flag = compareItems(obj,fix(i/2)+obj.pMaxHeapIdx(chanIdx)+1,i+obj.pMaxHeapIdx(chanIdx)+1,chanIdx);
                if (~flag)
                    break;
                end
                swapElements(obj,fix(i/2)+obj.pMaxHeapIdx(chanIdx)+1,i+obj.pMaxHeapIdx(chanIdx)+1, chanIdx);
                i = i * 2;
            end
        end
        
        function upperMinMaxChanged = bubbleUpMin(obj, i, chanIdx)
            % Bubble element up the min-heap until heap is in good order.

            % Align with heap indexing. 
            i = i - (obj.pMinHeapIdx(chanIdx)-1);

            if (obj.pMinHeapLength(chanIdx) > 0)
            
                while (i>0)
                    flag = compareItems(obj,i+obj.pMinHeapIdx(chanIdx)-1,fix(i/2)+obj.pMinHeapIdx(chanIdx)-1,chanIdx);
                    if (~flag)
                        break;
                    end
                    swapElements(obj,i+obj.pMinHeapIdx(chanIdx)-1,fix(i/2)+obj.pMinHeapIdx(chanIdx)-1,chanIdx);
                    i = fix(i/2);
                end
                upperMinMaxChanged = (i==0);
            
            else
                upperMinMaxChanged = true;
            end
        end
        
        function lowerMinMaxChanged = bubbleUpMax(obj, i, chanIdx)
            % Bubble element up the max-heap until heap is in good order.  
            
            % Align with heap indexing
            i = i - (obj.pMaxHeapIdx(chanIdx)+1);

            if (obj.pMaxHeapLength(chanIdx) > 0)

                while (i<0)
                    flag = compareItems(obj,fix(i/2)+obj.pMaxHeapIdx(chanIdx)+1,i+obj.pMaxHeapIdx(chanIdx)+1, chanIdx);
                    if (~flag)
                        break;
                    end
                    swapElements(obj,fix(i/2)+obj.pMaxHeapIdx(chanIdx)+1,i+obj.pMaxHeapIdx(chanIdx)+1, chanIdx);
                    i = fix(i/2);
                end
                lowerMinMaxChanged =  (i == 0);

            else
                lowerMinMaxChanged = true;
            end
        end

        function minRootChanged = trickleDownMinMax(obj, i, chanIdx, isLowerHeap)
            % Trickle element down min-max-heap (starting from the anywhere 
            % and moving toward the top of the min heap) until the heap is 
            % in good order. 

            % i: index, aligned with heap indexing
            % isLowerHeap: true when the min-max heap is the one below the 
            % median, otherwise false
            
            if isLowerHeap
                minHeapOffset = obj.pMaxHeapIdx(chanIdx);
                maxHeapOffset = obj.pMidIdx + 1;
                heapLength = obj.pMidIdx - obj.pMaxHeapIdx(chanIdx);
            else % isUpperHeap
                minHeapOffset = obj.pMidIdx - 1;
                maxHeapOffset = obj.pMinHeapIdx(chanIdx);
                heapLength = obj.pMinHeapIdx(chanIdx) - obj.pMidIdx;
            end
            % heapHalfLength - half the full size of the min-max heap 
            heapHalfLength = fix((heapLength + 1) / 2);

            % By default, the min heap root will not have changed, unless
            % the min-max heap has only one element.
            if (heapLength <= 1)
                minRootChanged = true;
                return;
            else
                minRootChanged = false;
            end
            
            if ( i > 0 || ((heapHalfLength + i == 0) && 1 == mod(heapLength,2)) ) % in min heap or the element does not have a pair

                i = sign(i) * i; % make i positive if it is not already
                while (i > 1)
                    flag = compareItems(obj,i+minHeapOffset,fix(i/2)+minHeapOffset,chanIdx);
                    if (~flag)
                        break;
                    end
                    swapElements(obj,i+minHeapOffset,fix(i/2)+minHeapOffset,chanIdx);
                    i = fix(i/2);
                end
                minRootChanged = (i == 1);
            else % in max heap

                if compareItems(obj, i+maxHeapOffset, -i+minHeapOffset, chanIdx)
                    swapElements(obj, i+maxHeapOffset, -i+minHeapOffset, chanIdx);
                    % reorder min heap
                    j = -i;
                    while (j > 1)
                        flag = compareItems(obj,j+minHeapOffset,fix(j/2)+minHeapOffset,chanIdx);
                        if (~flag)
                            break;
                        end
                        swapElements(obj,j+minHeapOffset,fix(j/2)+minHeapOffset,chanIdx);
                        j = fix(j/2);
                    end
                    minRootChanged = (j == 1);
                end

                % reorder max heap
                i = i * 2;
                while (i >= -heapHalfLength)
                    if (i < -1 && i > -heapHalfLength && compareItems(obj, i+maxHeapOffset, i-1+maxHeapOffset, chanIdx))
                        i = i - 1;
                    end
                    flag = compareItems(obj, fix(i/2)+maxHeapOffset, i+maxHeapOffset, chanIdx);
                    if (~flag)
                        break;
                    end
                    swapElements(obj, fix(i/2)+maxHeapOffset, i+maxHeapOffset, chanIdx);
                    if compareItems(obj, i+maxHeapOffset, -i+minHeapOffset, chanIdx)
                        swapElements(obj, i+maxHeapOffset, -i+minHeapOffset, chanIdx);
                    end
                    i = i * 2;
                end

            end

        end

        function maxRootChanged = bubbleUpMinMax(obj, i, chanIdx, isLowerHeap)
            % Bubble element up min-max-heap (starting from the anywhere 
            % and moving toward the top of the max heap) until the heap is 
            % in good order. 

            % i: index, aligned with heap indexing
            % isLowerHeap: true when the min-max heap is the one below the 
            % median, otherwise false
            
            if isLowerHeap
                minHeapOffset = obj.pMaxHeapIdx(chanIdx);
                maxHeapOffset = obj.pMidIdx + 1;
                heapLength = obj.pMidIdx - obj.pMaxHeapIdx(chanIdx);
            else % isUpperHeap
                minHeapOffset = obj.pMidIdx - 1;
                maxHeapOffset = obj.pMinHeapIdx(chanIdx);
                heapLength = obj.pMinHeapIdx(chanIdx) - obj.pMidIdx;
            end
            % heapHalfLength - half the full size of the min-max heap 
            heapHalfLength = fix((heapLength + 1) / 2);

            % By default, the max heap root will not have changed, unless
            % the min-max heap has only one element. 
            if (heapLength <= 1)
                maxRootChanged = true;
                return;
            else
                maxRootChanged = false;
            end
            
            if ( i < 0 || ((heapHalfLength - i == 0) && 1 == mod(heapLength,2)) ) % in max heap or the element does not have a pair 

                i = -1 * sign(i) * i; % make i negative if it is not already
                while (i < -1)
                    flag = compareItems(obj,fix(i/2)+maxHeapOffset,i+maxHeapOffset,chanIdx);
                    if (~flag)
                        break;
                    end
                    swapElements(obj,fix(i/2)+maxHeapOffset,i+maxHeapOffset,chanIdx);
                    i = fix(i/2);
                end
                maxRootChanged = (i == -1);

            else % in min heap

                if compareItems(obj, -i+maxHeapOffset, i+minHeapOffset, chanIdx)
                    swapElements(obj, -i+maxHeapOffset, i+minHeapOffset, chanIdx);
                    % reorder max heap
                    j = -i;
                    while (j < -1)
                        flag = compareItems(obj,fix(j/2)+maxHeapOffset,j+maxHeapOffset,chanIdx);
                        if (~flag)
                            break;
                        end
                        swapElements(obj,fix(j/2)+maxHeapOffset,j+maxHeapOffset,chanIdx);
                        j = fix(j/2);
                    end
                    maxRootChanged = (j == -1);
                end

                % reorder min heap
                i = i * 2;
                while (i <= heapHalfLength)
                    if (i > 1 && i < heapHalfLength && compareItems(obj, i+1+minHeapOffset, i+minHeapOffset, chanIdx))
                        i = i + 1;
                    end
                    flag = compareItems(obj, i+minHeapOffset, fix(i/2)+minHeapOffset, chanIdx);
                    if (~flag)
                        break;
                    end
                    swapElements(obj, i+minHeapOffset, fix(i/2)+minHeapOffset, chanIdx);
                    if compareItems(obj, -i+maxHeapOffset, i+minHeapOffset, chanIdx)
                        swapElements(obj, -i+maxHeapOffset, i+minHeapOffset, chanIdx);
                    end
                    i = i * 2;
                end

            end

        end

        function insertElement(obj,  v, chanIdx)

            dt = class(v);

            % Overwrite the oldest element in the buffer
            vprev = obj.pBuf(obj.pIdx(chanIdx),chanIdx);
            obj.pBuf(obj.pIdx(chanIdx),chanIdx) = v;
            % p holds the heap position that was overwritten 
            p = obj.pPos(obj.pIdx(chanIdx),chanIdx);
            % Increment 'oldest element' index
            obj.pIdx(chanIdx) = obj.pIdx(chanIdx) + 1;
            % Roll index back to 1 if we have reached the end of the
            % buffer
            if (obj.pIdx(chanIdx) == obj.pWinLen + 1)
                obj.pIdx(chanIdx) = cast(1,obj.pDatatype);
            end
            % Increment 'current sample' index
            obj.pCurrSampIdx(chanIdx) = obj.pCurrSampIdx(chanIdx) + 1;
            % Roll index back to 1 if we have reached the end of the
            % buffer
            if (obj.pCurrSampIdx(chanIdx) == obj.pWinLen + 1)
                obj.pCurrSampIdx(chanIdx) = cast(1,obj.pDatatype);
            end

            if (p <= obj.pMaxHeapIdx(chanIdx)) % new element inserted in max heap
                if ( v < vprev)
                    % The new element is smaller than the deleted element.
                    % All elements above this new element (including the
                    % median) do not need to move. Push the new element
                    % down until the max heap is reordered
                    trickleDownMax(obj,(p-(obj.pMaxHeapIdx(chanIdx)+1))*2,chanIdx);
                else
                    % Move the new value up until the max heap is reordered
                    lowerMinRootChanged = bubbleUpMax(obj,p,chanIdx);
                    % If the min heap root of the lower min-max heap has 
                    % changed, we need to reorder (push the value up until
                    % the lower min-max heap is reordered)
                    if lowerMinRootChanged
                        upperMinRootChanged = bubbleUpMinMax(obj,cast(1,dt),chanIdx,true);

                        if upperMinRootChanged
                            upperMaxRootChanged = bubbleUpMinMax(obj,cast(1,dt),chanIdx,false);

                            if upperMaxRootChanged
                                trickleDownMin(obj,cast(1,dt),chanIdx);
                            end
                        end
                    end
                end

            elseif (p < obj.pMidIdx) % new element inserted in lower min-max heap
                
                % convert position p to heap index
                halfHeapLength = fix((obj.pMidIdx - obj.pMaxHeapIdx(chanIdx) + 1)/2);
                if (p - obj.pMaxHeapIdx(chanIdx) > halfHeapLength) % in max heap
                    p = p - (obj.pMidIdx + 1);
                else % in min heap
                    p = p - obj.pMaxHeapIdx(chanIdx);
                end

                if (v > vprev)
                    upperMinRootChanged = bubbleUpMinMax(obj,p,chanIdx,true);

                    if upperMinRootChanged
                        upperMaxRootChanged = bubbleUpMinMax(obj,cast(1,dt),chanIdx,false);

                        if upperMaxRootChanged
                            trickleDownMin(obj,cast(1,dt),chanIdx);
                        end
                    end
                else
                    lowerMinRootChanged = trickleDownMinMax(obj,p,chanIdx,true);

                    if lowerMinRootChanged
                        trickleDownMax(obj,cast(-1,dt),chanIdx);
                    end
                end

            elseif (p == obj.pMidIdx) % new element overwrote median
                if (v > vprev)

                    upperMaxRootChanged = bubbleUpMinMax(obj,cast(1,dt),chanIdx,false);

                    if upperMaxRootChanged
                        trickleDownMin(obj,cast(1,dt),chanIdx);
                    end
                else

                    lowerMinRootChanged = trickleDownMinMax(obj,cast(-1,dt),chanIdx,true);

                    if lowerMinRootChanged
                        trickleDownMax(obj,cast(-1,dt),chanIdx);
                    end
                end

            elseif (p < obj.pMinHeapIdx(chanIdx)) % new element inserted in upper min-max heap

                % convert position p to heap index
                halfHeapLength = fix((obj.pMinHeapIdx(chanIdx) - obj.pMidIdx + 1)/2);
                if (p - (obj.pMidIdx - 1) > halfHeapLength) % in max heap
                    p = p - obj.pMinHeapIdx(chanIdx);
                else % in min heap
                    p = p - (obj.pMidIdx-1);
                end

                if (v > vprev)
                    upperMaxRootChanged = bubbleUpMinMax(obj,p,chanIdx,false);

                    if upperMaxRootChanged
                        trickleDownMin(obj,cast(1,dt),chanIdx);
                    end
                else
                    lowerMaxRootChanged = trickleDownMinMax(obj,p,chanIdx,false);

                    if lowerMaxRootChanged
                        lowerMinRootChanged = trickleDownMinMax(obj,cast(-1,dt),chanIdx,true);

                        if lowerMinRootChanged
                            trickleDownMax(obj,cast(-1,dt),chanIdx);
                        end
                    end
                end

            else % new element inserted in min heap
                if (v > vprev)
                    % The new element is larger than the deleted element.
                    % All elements above this new element (including the
                    % median) do not need to move. Push the new element
                    % down until the min heap is reordered
                    trickleDownMin(obj,(p-(obj.pMinHeapIdx(chanIdx)-1))*2,chanIdx);
                else
                    % Move the new value up until the mim heap is reordered
                    upperMaxRootChanged = bubbleUpMin(obj,p,chanIdx);

                    if upperMaxRootChanged
                        lowerMaxRootChanged = trickleDownMinMax(obj,cast(-1,dt),chanIdx,false);

                        if lowerMaxRootChanged
                            lowerMinRootChanged = trickleDownMinMax(obj,cast(-1,dt),chanIdx,true);

                            if lowerMinRootChanged
                                trickleDownMax(obj,cast(-1,dt),chanIdx);
                            end
                        end
                    end
                end
            end
        end
        
        function shiftLeft(obj,chanIdx)
            % SHIFTLEFT move the max and min heap indices to the left and 
            % reorder all of the heaps as necessary. 
            % The max heap and the upper min-max heap become smaller. 
            % The min heap and the lower min-max heap become larger. 
            % 
            %    max heap idx      min heap idx
            %        |                 |
            %        v                 v
            %    [#][#][#][#][#][#][#][#][#]
            % 
            % max heap idx      min heap idx
            %     |                 |
            %     v                 v
            %    [#][#][#][#][#][#][#][#][#]

            dt = obj.pDatatype;

            % Reorder min heap
            obj.pMinHeapLength(chanIdx) = obj.pMinHeapLength(chanIdx) + 1;
            obj.pMinHeapIdx(chanIdx)    = obj.pMinHeapIdx(chanIdx) - 1;

            for i = 1:obj.pMinHeapLength(chanIdx)-1
                swapElements(obj,i+obj.pMinHeapIdx(chanIdx)-1,i+1+obj.pMinHeapIdx(chanIdx)-1,chanIdx);
            end
            
            bubbleUpMin(obj,obj.pWinLen,chanIdx);

            % Reorder max heap
            obj.pMaxHeapLength(chanIdx) = obj.pMaxHeapLength(chanIdx) - 1;
            obj.pMaxHeapIdx(chanIdx)    = obj.pMaxHeapIdx(chanIdx) - 1;

            if obj.pMaxHeapLength(chanIdx) > 0
                for i = -obj.pMaxHeapLength(chanIdx):-2
                    swapElements(obj,i+obj.pMaxHeapIdx(chanIdx)+1,i+1+obj.pMaxHeapIdx(chanIdx)+1,chanIdx);
                end

                trickleDownMax(obj,cast(-2,dt),chanIdx);
            end

            % Reorder upper min-max heap
            heapLength = obj.pMinHeapIdx(chanIdx) - obj.pMidIdx;
            % min-max heap will already be ordered if there are 3 or fewer
            % elements
            if heapLength > 3
                numShift = fix(heapLength/2) - 1; 

                for i = -numShift-1:-2
                    swapElements(obj,i+obj.pMinHeapIdx(chanIdx),i+1+obj.pMinHeapIdx(chanIdx),chanIdx);
                end

                trickleDownMinMax(obj,cast(-1,dt),chanIdx,false);

            end

            % Reorder lower min-max heap
            heapLength = obj.pMidIdx - obj.pMaxHeapIdx(chanIdx);

            numShift = fix((heapLength-1)/2); 

            for i = 1:numShift
                swapElements(obj,i+obj.pMaxHeapIdx(chanIdx),i+1+obj.pMaxHeapIdx(chanIdx),chanIdx);
            end

            trickleDownMinMax(obj,numShift+1,chanIdx,true);

        end

        function shiftRight(obj,chanIdx)
            % SHIFTRIGHT move the max and min heap indices to the right and 
            % reorder all of the heaps as necessary. 
            % The max heap and the upper min-max heap become larger. 
            % The min heap and the lower min-max heap become smaller. 
            % 
            %    max heap idx      min heap idx
            %        |                 |
            %        v                 v
            %    [#][#][#][#][#][#][#][#][#]
            % 
            %       max heap idx      min heap idx
            %           |                 |
            %           v                 v
            %    [#][#][#][#][#][#][#][#][#]


            dt = obj.pDatatype;

            % Reorder max heap
            obj.pMaxHeapLength(chanIdx) = obj.pMaxHeapLength(chanIdx) + 1;
            obj.pMaxHeapIdx(chanIdx)    = obj.pMaxHeapIdx(chanIdx) + 1;

            for i = -1:-1:obj.pMaxHeapLength(chanIdx)-1
                swapElements(obj,i+obj.pMaxHeapIdx(chanIdx)+1,i-1+obj.pMaxHeapIdx(chanIdx)+1,chanIdx);
            end

            bubbleUpMax(obj,cast(1,dt),chanIdx);

            % Reorder min heap
            obj.pMinHeapLength(chanIdx) = obj.pMinHeapLength(chanIdx) - 1;
            obj.pMinHeapIdx(chanIdx)    = obj.pMinHeapIdx(chanIdx) + 1;

            if obj.pMinHeapLength(chanIdx) > 0

                for i = obj.pMinHeapLength(chanIdx):-1:2
                    swapElements(obj,i+obj.pMinHeapIdx(chanIdx)-1,i-1+obj.pMinHeapIdx(chanIdx)-1,chanIdx);
                end

                trickleDownMin(obj,cast(2,dt),chanIdx);
            end
            
            % Reorder upper min-max heap
            heapLength = obj.pMinHeapIdx(chanIdx) - obj.pMidIdx;

            numShift = fix((heapLength-1)/2);

            for i = -1:-1:-numShift
                swapElements(obj,i+obj.pMinHeapIdx(chanIdx),i-1+obj.pMinHeapIdx(chanIdx),chanIdx);
            end

            bubbleUpMinMax(obj,-numShift-1,chanIdx,false);

            % Reorder lower min-max heap
            heapLength = obj.pMidIdx - obj.pMaxHeapIdx(chanIdx);
            % min-max heap will already be ordered if there are 3 or fewer
            % elements
            if heapLength > 3
                numShift = fix(heapLength/2) - 1;

                for i = numShift+1:-1:2
                    swapElements(obj,i+obj.pMaxHeapIdx(chanIdx),i-1+obj.pMaxHeapIdx(chanIdx),chanIdx);
                end

                bubbleUpMinMax(obj,cast(1,dt),chanIdx,true);

            end
        end

        function [v,isOutlier] = getValue(obj, chanIdx)

            % Get the current sample value and current median value (the 
            % median value is in the middle of the heap). 
            x       = obj.pBuf(obj.pCurrSampIdx(chanIdx),chanIdx);
            xmedian = obj.pBuf(obj.pHeap(obj.pMidIdx,chanIdx),chanIdx);

            % calculate current MAD value
            % while ( median - value(i-1) < value(j) - median ) {
            %     i--;
            %     j--;
            % }
            while ( obj.pMaxHeapIdx(chanIdx) >= 1 && ...
                xmedian - obj.pBuf(obj.pHeap(obj.pMaxHeapIdx(chanIdx),chanIdx),chanIdx) < ...
                obj.pBuf(obj.pHeap(obj.pMinHeapIdx(chanIdx)-1,chanIdx),chanIdx) - xmedian )

                shiftLeft(obj,chanIdx);
            end
            % while ( value(j+1) - median < median - value(i) ) {
            %     i++;
            %     j++;
            % }
            while ( obj.pMinHeapIdx(chanIdx) <= obj.WindowLength && ...
                obj.pBuf(obj.pHeap(obj.pMinHeapIdx(chanIdx),chanIdx),chanIdx) - xmedian < ...
                xmedian - obj.pBuf(obj.pHeap(obj.pMaxHeapIdx(chanIdx)+1,chanIdx),chanIdx) )

                shiftRight(obj,chanIdx);
            end
            % MAD = max( median - value(i), value(j) - median );
            xmad = max( obj.pBuf(obj.pHeap(obj.pMinHeapIdx(chanIdx)-1,chanIdx),chanIdx) - xmedian, ...
                xmedian - obj.pBuf(obj.pHeap(obj.pMaxHeapIdx(chanIdx)+1,chanIdx),chanIdx) );
            xsigma = obj.pScale * xmad;

            isOutlier = abs(x - xmedian) > obj.Threshold * xsigma;
            if isOutlier
                v = xmedian;
            else
                v = x;
            end

        end
         
       function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            if isLocked(obj)
                s.pBuf = obj.pBuf;
                s.pPos = obj.pPos;
                s.pHeap = obj.pHeap;
                s.pWinLen = obj.pWinLen;
                s.pIdx = obj.pIdx;
                s.pCurrSampIdx = obj.pCurrSampIdx;
                s.pMidIdx = obj.pMidIdx;
                s.pMinHeapIdx = obj.pMinHeapIdx;
                s.pMaxHeapIdx = obj.pMaxHeapIdx;
                s.pDatatype = obj.pDatatype;
                s.pMinHeapLength = obj.pMinHeapLength;
                s.pMaxHeapLength = obj.pMaxHeapLength;
            end
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                obj.pBuf = s.pBuf;
                obj.pPos = s.pPos;
                obj.pHeap = s.pHeap;
                obj.pWinLen = s.pWinLen;
                obj.pIdx = s.pIdx;
                obj.pCurrSampIdx = s.pCurrSampIdx;
                obj.pMidIdx = s.pMidIdx;
                obj.pMinHeapIdx = s.pMinHeapIdx;
                obj.pMaxHeapIdx = s.pMaxHeapIdx;
                obj.pDatatype = s.pDatatype;
                obj.pMinHeapLength = s.pMinHeapLength;
                obj.pMaxHeapLength = s.pMaxHeapLength;
            end
            loadObjectImpl@matlab.System(obj, s, wasLocked);
        end
        
    end
    
end