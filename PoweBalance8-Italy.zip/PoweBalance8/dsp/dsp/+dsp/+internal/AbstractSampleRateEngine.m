classdef (Abstract) AbstractSampleRateEngine < dsp.internal.AbstractSampleRateEngineTemplate

% ABSTRACTSAMPLERATENEGINE  This class controls sample rate functionality

%   Copyright 2014-2020 The MathWorks, Inc.


    %#codegen
    %#ok<*EMCLS>
    
    properties (Nontunable, Dependent)
        % SampleRate Input sample rate (Hz)
        %   Specify the sampling rate of the input in Hertz as a finite
        %   numeric scalar.
        SampleRate
    end
    
    methods
        function set.SampleRate(obj,value)
            % Validate and set dependent SampleRate
            % For MATLAB System block, if InheritSampleRate is true, set
            % pSampleRateInherit. if InheritSampleRate is false, set
            % pSampleRateDialog. 
            % For System object in MATLAB, always set pSampleRateDialog
            validateattributes(value,...
                {'double','single'}, ...
                {'real','scalar','positive','finite'},...
                '','SampleRate');
            if ~obj.InheritSampleRate || ~obj.getExecPlatformIndex()
                obj.pSampleRateDialog = value;
            end
            postProcessSampleRate(obj,value); % Child class can overload this 
        end
        
        function value = get.SampleRate(obj)
            % Get dependent SampleRate
            % For MATLAB System block, if InheritSampleRate is true, get
            % pSampleRateInherit. if InheritSampleRate is false, get
            % pSampleRateDialog. 
            % For System object in MATLAB, always get pSampleRateDialog
             if obj.InheritSampleRate && obj.getExecPlatformIndex()
                value = obj.pSampleRateInherit;
            else
                value = obj.pSampleRateDialog;
            end
        end 
    end
    
    methods (Access = protected)

        function setupImpl(obj,x)
            setupImpl@dsp.internal.AbstractSampleRateEngineTemplate(obj,x);
        end

    end
    
end