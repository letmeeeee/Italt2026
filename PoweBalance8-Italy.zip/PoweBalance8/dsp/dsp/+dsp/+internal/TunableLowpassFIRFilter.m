classdef TunableLowpassFIRFilter < dsp.internal.TunableLowpassHighpassFIRFilter
% TunableLowpassFIRFilter

    %   Copyright 2022-2023 The MathWorks, Inc.

    %#codegen

    methods(Access = protected)
        %------------------------------------------------------------------
        function b = designFilter(this)
            b = designLowpassCoefficients(this);
        end
    end

    methods(Static, Access=protected)
        function mainS = getPropertyGroupsImpl
            % Modify order of display
            mainS =  matlab.system.display.Section(...
                'Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', {'FilterOrder','MaxOrder','CutoffFrequency','Window','SidelobeAttenuation','OutputDataType'});
        end
    end
end
