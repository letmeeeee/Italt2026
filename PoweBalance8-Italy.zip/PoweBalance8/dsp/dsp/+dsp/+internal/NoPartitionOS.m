classdef NoPartitionOS < dsp.internal.NoPartitionOAOSBase
% NoPartitionOS Classic overlap-save filter. 
% This class is used in dsp.FrequencyDomainFIRFilter

% Copyright 2017-2022 The MathWorks, Inc.

 %#codegen
    
    methods
        function obj = NoPartitionOS(varargin)
            setProperties(obj,nargin,varargin{:});
        end
    end
    
    methods (Access = protected)
        function setupImpl(obj,u)
            setupImpl@dsp.internal.NoPartitionOAOSBase(obj,u);
            obj.pLastSection = zeros(obj.pFilterLength - 1,obj.numChannels,'like',u);
        end
    end
    
     methods (Static)
         % Implement overlap-save
         function [o,prevsec] = computeOutput(input,L,numFrames,numchan,pH,fftlen,filtlen,prevsec,isOutReal,halideMode)
           
            % input       : Input samples
            % L           : Number of samples to keep (save) from each computed FFT
            % numFrames   : Number of input frames
            % numChannels : Number of input channels
            % H           : FFT of filter numerator
            % fftlen      : FFT length
            % prevsec     : State (samples from previous segment to be added)
            % o           : Output filtered samples
            
             if isOutReal
                o = zeros(L*numFrames,numchan,class(input));
             else
                o = zeros(L*numFrames,numchan,class(input)) + 1j * zeros(L*numFrames,numchan,class(input));
             end
             
             if isempty(coder.target)
                 % Halide's performance is optimal for cases with
                 % filter length less than 1024. 
                 if (filtlen<1024 && (halideMode == 1)) || (halideMode == 2) 
                     Z = complex(zeros(fftlen, numchan, class(input)));
                     if isreal(pH)
                         pH = complex(pH);
                     end
                 end
             elseif coder.const(feval('dsp.enhancedsim.IsSysObjSimInCodeGen', coder.target)) && coder.const(halideMode)  
                 Z = complex(zeros(fftlen, numchan, class(input)));
                 if isreal(pH)
                     Hc = complex(pH);
                 end
             end

             for index = 1:numFrames

                 in = input((index-1)*L+1:index*L,:);
                 z = [prevsec ; in];
                 prevsec(:,:)   = z(L+1:L + filtlen - 1,:);

                 if(isempty(coder.target))
                     if (filtlen<1024 && (halideMode == 1)) || (halideMode == 2) 
                         zfft = complex(fft(z,fftlen));
                         dsp.internal.builtins.FrequencyDomainFIRFilter(0, zfft, pH, Z, fftlen, numchan);
                     else
                         Z = bsxfun(@times, fft(z,fftlen), pH);
                     end
                 else
                     if coder.const(feval('dsp.enhancedsim.IsSysObjSimInCodeGen', coder.target)) && coder.const(halideMode)

                         zfft = complex(fft(z,fftlen));
                         Z = dsp.internal.FrequencyDomainFIRFilterCGSim("NoPartitionOS", zfft, pH, Z, fftlen, numchan);

                         if isreal(pH)
                             Z = dsp.internal.FrequencyDomainFIRFilterCGSim("NoPartitionOS", zfft, Hc, Z, fftlen, numchan);
                         else
                             Z = dsp.internal.FrequencyDomainFIRFilterCGSim("NoPartitionOS", zfft, pH, Z, fftlen, numchan);
                         end

                     else
                         Z = bsxfun(@times, fft(z,fftlen), pH);
                     end
                 end

                 if isOutReal
                     zout = real(ifft(Z,fftlen));
                 else
                     zout = ifft(Z,fftlen);
                 end

                 o((index-1)*L+1:L*index,:) = zout(filtlen:end,:);

             end

         end
     end
end
