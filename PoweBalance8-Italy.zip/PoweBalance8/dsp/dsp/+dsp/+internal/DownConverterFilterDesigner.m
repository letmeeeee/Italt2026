classdef DownConverterFilterDesigner < dsp.internal.ConverterFilterDesignerBase
%dsp.internal.DownConverterFilterDesigner Decimation filter cascade designer
%   This object designs a cascade of decimation filter System objects to be
%   used by the dsp.DigitalDownConverter class. The cascade consists of
%   four stages. When  FilterSpecification is 'Design parameters':
%
%   Stage1    = CIC decimator filter (this stage will be implemented as a
%               dsp.FIRDecimator System object when the Arithmetic property
%               is set to 'Double' or 'Single', or as a dsp.CICDecimator
%               System object when the Arithmetic property is set to
%               'fixed'.
%   Stage2    = CIC compensator decimation filter
%   Stage3    = halfband or lowpass decimation filter (this
%               stage may or may not be bypassed, depending on the property
%               settings of the object)
%   GainStage = Gain stage to normalize the gain of the CIC decimator.
%
%   When  FilterSpecification is 'Coefficients':
%
%   Stage1    = CIC decimator filter (this stage will be implemented as a
%               dsp.FIRDecimator System object when the Arithmetic property
%               is set to 'Double' or 'Single', or as a dsp.CICDecimator
%               System object when the Arithmetic property is set to
%               'fixed'.
%   Stage2    = FIR decimation filter
%   Stage3    = FIR decimation filter (this stage may or may not be
%               bypassed, depending on the property settings of the object)
%   GainStage = Gain stage to normalize the gain of the CIC decimator.
    
%   Copyright 2010-2020 The MathWorks, Inc.
%#codegen
%#ok<*PROP>
%#ok<*EMCA>
    
    properties (Nontunable)
        %SampleRate Sample rate at the input of the filter cascade in Hertz
        SampleRate = 30e6;
        %DecimationFactor Decimation factor
        %   This property can be a scalar, a 1x2 vector, or a 1x3 vector.
        %   If it is a scalar, the decimation factor for each stage is
        %   computed automatically. If it is a 1x2 vector, the third filter
        %   stage is bypassed. The elements of the 1x2 vector specify the
        %   decimation factors for the first and second decimation stages.
        DecimationFactor = 100;
        %OrderStage1 Order of first filter stage
        %   This property holds the number of CIC sections. This property
        %   applies when MinimumOrderDesign is false.
        OrderStage1 = 3;
        %OrderStage3 Order of third filter stage
        %   This property holds the order of the third filter stage. This
        %   property applies when  FilterSpecification is 'Design
        %   parameters' and MinimumOrderDesign is false.
        OrderStage3 = 10;
    end
    
    properties (SetAccess = private)
        %Stage3FilterSysObj Handle to System object that forms the third
        %stage
        Stage3FilterSysObj
    end
    
    properties (Access = private)
        %pStage3Filter Handle to an mfilt object that forms the third stage
        pStage3Filter
    end
    
    properties (Nontunable, Access=private)
        %pBypassStage3 Flag to determine whether the third stage is
        %bypassed or not. Can be set to true or false.
        pBypassStage3
        %pFilterTypeStage3 Type of filter implemented in the third stage.
        %This property can be set to 'lowpass' or 'halfband'
        pFilterTypeStage3
        %pFstopStage3 stopband frequency of third filter stage in Hertz  
        pFstopStage3
        %pFcuttofStage3 Cutoff frequency of third stage in Hertz
        pFcuttofStage3
        %pTWStage3 Transition width of third stage in Hertz
        pTWStage3
    end
    
    %----------------------------------------------------------------------
    % Public methods
    %----------------------------------------------------------------------
    methods
        %CONSTRUCTOR
        function obj = DownConverterFilterDesigner(varargin)
            obj@dsp.internal.ConverterFilterDesignerBase(varargin{:})
            setProperties(obj, nargin, varargin{:});
        end
        %------------------------------------------------------------------
        function [d,f] = groupDelay(obj,varargin)
            isDesignAvailable(obj)
            [d, w] = grpdelay(obj.pCascadeFilter,varargin{:});
            f = (w/pi)*obj.SampleRate/2;
        end
        %------------------------------------------------------------------
        function Mvect = getDecimationFactors(obj)
            % If a design is available, return the decimation factors for
            % each stage
            isDesignAvailable(obj)
            Mvect = [obj.pM1 obj.pM2 obj.pM3];
        end
        %------------------------------------------------------------------
        function flag = isThirdStageBypassed(obj)
            % Ask if third stage has been bypassed or not
            isDesignAvailable(obj)
            flag = obj.pBypassStage3;
        end
        %------------------------------------------------------------------
        function hfvt = visualizeFilterStages(obj)
            %visualizeFilterStages Display response of filter stages
            %   visualizeFilterStages(H) plots the magnitude response of the
            %   decimation filter stages and of the cascade response. If you set the
            %   FilterSpecification property to 'Design parameters' it also plots a
            %   mask based on the filter specifications.
            %
            %   hfvt = visualizeFilterStages(H) returns a handle to an fvtool
            %   object.
            %
            %   Call the fvtool method if you only want to visualize the cascade
            %   response.
            
            isDesignAvailable(obj)
            
            [filt, figureProps] = getFvtoolParametersForVFS(obj);
            hfvt = fvtool(filt{:});
            set(hfvt, figureProps{:});
            
            legendCell = getLegendStringForVFS(obj);
            legend(hfvt,legendCell{:});
            
            cascadeGain = 0;
            addMask(obj,cascadeGain,hfvt);
        end
        %------------------------------------------------------------------
        function hfvt = fvtool(obj,varargin)
            %fvtool Display response of filter cascade
            cascadeGain = 0;
            hfvt = privFvtool(obj,obj.SampleRate,cascadeGain,varargin{:});
        end
        %------------------------------------------------------------------
        function SystemObjectsToMfilt(obj)
            %Create mfilt filter objects and cascade for filter analysis
            
            obj.pCICFilter = todfilt(obj.CICFilterSysObj, obj.Arithmetic);
            obj.pCICCompFilter = todfilt(obj.CICCompFilterSysObj, obj.Arithmetic);
            obj.pGainFilter = dfilt.scalar(obj.GainFilter);
            if ~obj.pBypassStage3
                obj.pStage3Filter = todfilt(obj.Stage3FilterSysObj, obj.Arithmetic);
            end
            
            if obj.pBypassStage3
                obj.pCascadeFilter = cascade(obj.pCICFilter,obj.pGainFilter,...
                    obj.pCICCompFilter);
            else
                obj.pCascadeFilter = cascade(obj.pCICFilter,obj.pGainFilter,...
                    obj.pCICCompFilter, obj.pStage3Filter);
            end
        end
    end
    
    %----------------------------------------------------------------------
    % Protected methods
    %----------------------------------------------------------------------
    methods (Access = protected)
        function N = getNumInputsImpl(~)
            % Specify number of System inputs
            N=1;
        end
        function N = getNumOutputsImpl(~)
            % Specify number of System inputs
            N=0;
        end
        function releaseImpl(obj)
            release(obj.CICFilterSysObj);
            release(obj.CICCompFilterSysObj);
            if ~obj.pBypassStage3
                release(obj.Stage3FilterSysObj);
            end
            obj.IsFilterDesignAvailable = false;
        end
        function setupImpl(obj, inputFixedPointArguments)
            % Initialize private properties to be used later
            
            if (isempty(inputFixedPointArguments) &&...
                    obj.IsFilterDesignAvailable)
                % If design is available for non fixed-point cases, then do
                % not redesign
                return;
            end
            
            %Decide if third filter section is bypassed or not. If not,
            %then set the filter type to 'halfband' or 'lowpass'. Set the
            %decimation or interpolation factor values for each section.
            %When user specifies coefficients, just set the decimation
            %factors in the corresponding properties.
            setFilterSectionTypes(obj)
            
            %Verify that stopband frequency is within valid frequency range
            checkPropertyValues(obj)
            
            %Compute rate of operation and stopband frequencies for filter
            %sections.
            computeFrequencySpecifications(obj);
            
            % Compute CIC null frequencies
            computeCICNullFrequencies(obj);
            
            % Design the filters
                if obj.MinimumOrderDesign
                    obj.designFiltersMinOrder(inputFixedPointArguments);
                else
                    obj.designFiltersSpecifiedOrders(inputFixedPointArguments);
                end
        end
        %------------------------------------------------------------------
        function setFilterSectionTypes(obj)
            %Determine if the third filter section is bypassed or not. If
            %not, then determine whether the third section should be a
            %halfband or a lowpass decimation filter. Set the decimation
            %factor values for each section.
            coder.extrinsic('dsp.internal.ConverterFilterDesignerBase.setSectionFactors');
                if isscalar(obj.DecimationFactor)
                    % Factor the DecimationFactor into three values for
                    % each section. Bypass third filter section if
                    % MinimumOrderDesign is true and M3 equals 1
                    MVect = coder.const(@obj.setSectionFactors,obj.DecimationFactor);
                    obj.pM1 = MVect(1);
                    obj.pM2 = MVect(2);
                    obj.pM3 = MVect(3);
                    
                    if obj.pM3 == 1 && obj.MinimumOrderDesign
                        %MinimumOrderDesign is true, and M3=1
                        obj.pBypassStage3 = true;
                        obj.pFilterTypeStage3 = 'lowpass'; % Not used, needed for codegen
                    elseif obj.pM3 == 1 && ~obj.MinimumOrderDesign
                        %MinimumOrderDesign is false, and M3=1
                        if strcmpi(obj.StopbandFrequencySource, 'property')
                            %MinimumOrderDesign is false, and M3=1,
                            %StopbandFrequencySource = 'Property'
                            obj.pBypassStage3 = false;
                            obj.pFilterTypeStage3 = 'lowpass';
                        else
                            obj.pBypassStage3 = true;
                            obj.pFilterTypeStage3 = 'lowpass'; % Not used, needed for codegen
                            coder.internal.warning('dsp:system:DigitalDownConverter:bypassedThirdStage');
                        end
                    elseif obj.pM3 == 2
                        %M3=2
                        obj.pBypassStage3 = false;
                        if strcmpi(obj.StopbandFrequencySource, 'auto')
                            obj.pFilterTypeStage3 = 'halfband';
                        else
                            obj.pFilterTypeStage3 = 'lowpass';
                        end
                    end
                    
                elseif length(obj.DecimationFactor) == 2
                    % DecimationFactor is a 1x2 vector, bypass the third filter
                    % section
                    obj.pBypassStage3 = true;
                    obj.pFilterTypeStage3 = 'lowpass'; % Not used, needed for codegen
                    obj.pM1 = obj.DecimationFactor(1);
                    obj.pM2 = obj.DecimationFactor(2);
                    obj.pM3 = 1;
                    
                elseif length(obj.DecimationFactor) == 3
                    %DecimationFactor is a 1x3 vector
                    obj.pM1 = obj.DecimationFactor(1);
                    obj.pM2 = obj.DecimationFactor(2);
                    obj.pM3 = obj.DecimationFactor(3);
                    
                    if obj.pM3 == 1
                        if strcmpi(obj.StopbandFrequencySource, 'auto')
                            obj.pBypassStage3 = true;
                            obj.pFilterTypeStage3 = 'lowpass'; % Not used, needed for codegen
                            coder.internal.warning('dsp:system:DigitalDownConverter:bypassedThirdStage1');
                        else
                            obj.pBypassStage3 = false;
                            obj.pFilterTypeStage3 = 'lowpass';
                        end
                    else
                        obj.pBypassStage3 = false;
                        if strcmpi(obj.StopbandFrequencySource, 'auto')
                            obj.pFilterTypeStage3 = 'halfband';
                        else
                            obj.pFilterTypeStage3 = 'lowpass';
                        end
                    end
                else
                    coder.internal.errorIf(true, 'dsp:system:DigitalDownConverter:invalidDecimFactor');
                end
        end
        %------------------------------------------------------------------
        function checkPropertyValues(obj)
            %Verify that stopband frequency is within valid frequency range
            
            coder.internal.errorIf(obj.pPassbandFrequency >=...
                    obj.SampleRate/2/(prod(obj.DecimationFactor)), ...
                    'dsp:system:DigitalDownConverter:passbandFreqTooLarge', ...
                    floor(obj.SampleRate), round((obj.SampleRate - floor(obj.SampleRate))*10), ...
                    prod(obj.DecimationFactor));
            
            if strcmpi(obj.StopbandFrequencySource,'property')
                coder.internal.errorIf(obj.pBypassStage3 && (obj.StopbandFrequency >...
                        obj.SampleRate/(obj.pM1)/2), ...
                        'dsp:system:DigitalDownConverter:stopbandFreqTooLarge', ...
                        floor(obj.SampleRate/(obj.pM1)/2), ...
                        round((obj.SampleRate/(obj.pM1)/2 - floor(obj.SampleRate/(obj.pM1)/2)) * 10), ...
                        obj.pM1);
                coder.internal.errorIf(~obj.pBypassStage3 && (obj.StopbandFrequency > ...
                        obj.SampleRate/(obj.pM1*obj.pM2)/2), ...
                        'dsp:system:DigitalDownConverter:stopbandFreqTooLarge1',...
                        floor(obj.SampleRate/(obj.pM1*obj.pM2)/2), ...
                        round((obj.SampleRate/(obj.pM1*obj.pM2)/2 - floor(obj.SampleRate/(obj.pM1*obj.pM2)/2)) * 10), ...    
                        obj.pM1, obj.pM2);
                coder.internal.errorIf(obj.StopbandFrequency <= obj.pPassbandFrequency, ...
                        'dsp:system:DigitalDownConverter:stopbandFreqTooSmall');
            end
        end
        %-------------------------------------------------------------------------
        function computeFrequencySpecifications(obj)
            %Compute rate of operation and stopband frequencies for filter
            %sections.
            
            % Frequency of operation of filter stages
            obj.pFsStage1 = obj.SampleRate;
            obj.pFsStage2 = obj.SampleRate/obj.pM1;
            obj.pFsStage3 = obj.SampleRate/obj.pM1/obj.pM2;
            
                if strcmpi(obj.StopbandFrequencySource,'property')
                    % Stopband of third filter stage
                    obj.pFstopStage3 = obj.StopbandFrequency;
                    obj.pTWStage3 = obj.pFstopStage3 - obj.pPassbandFrequency;
                    obj.pFcuttofStage3 = obj.pPassbandFrequency + obj.pTWStage3/2;
                    % Stopband frequency of cascade response
                    obj.pCascadeFilterStopbandFrequency = obj.StopbandFrequency;
                else
                    % Cutoff is placed at output Nyquist rate
                    obj.pFcuttofStage3 = obj.SampleRate/2/(obj.pM1*obj.pM2*obj.pM3);
                    % Transition width of third stage
                    obj.pTWStage3 = 2*(obj.pFcuttofStage3 - obj.pPassbandFrequency);
                    % Stopband frequency of third stage
                    obj.pFstopStage3 = obj.pFcuttofStage3 + obj.pTWStage3/2;
                    % Stopband frequency of cascade response
                    obj.pCascadeFilterStopbandFrequency = obj.pFstopStage3;
                end
                
                if obj.pBypassStage3
                    obj.pFstopStage2 = obj.pFstopStage3;
                    if obj.pM2 == 1   
                        % If the decimation factor is prime, the CIC
                        % Compensator will be a single-rate filter. In this
                        % case, we need to pull the stopband frequency to
                        % the cut-off value. Otherwise, it goes above
                        % pFsStage2/2 which isn't acceptable for design.
                        % This is only when StopbandFrequencySource = Auto
                        obj.pFstopStage2 = obj.pFcuttofStage3;
                    end
                else
                    obj.pFstopStage2 = obj.pFsStage3 - obj.pFstopStage3;
                end
        end
        %------------------------------------------------------------------
        function computeCICNullFrequencies(obj)
            % Compute frequency locations of CIC nulls
            
            D = 1;          % Differential delay
            R = obj.pM1;    % Rate change factor
            f = 1:ceil((D*R-1)/2);
            Fo = 2*f/(D*R); % Normalized null frequencies between 0 and 1
            
            obj.pFCICNulls = Fo * obj.SampleRate/2;
        end
        %------------------------------------------------------------------
        function designFiltersSpecifiedCoefficients(obj, filterInputDataType)
            % Design the filter stages when user specifies the coefficients
            
            if ~isempty(filterInputDataType)
                coder.internal.errorIf(~strcmp(obj.Arithmetic,'fixed'), ...
                    'dsp:system:DigitalDownConverter:invalidArithmetic');
                
                coder.internal.errorIf(~isa(filterInputDataType,'embedded.numerictype'), ...
                    'dsp:system:DigitalDownConverter:invalidInputType');
            end
            
            % Design first stage (CIC)
            NumCICSections = obj.OrderStage1;
            CICGain = designCICDecimationFilter(obj,NumCICSections,filterInputDataType);
            
            % CIC gain normalization filter
            obj.GainFilter = 1/CICGain;
            
            % Get fixed-point properties for CIC Compensator and Stage3
            coder.extrinsic('dsp.internal.DownConverterFilterDesigner.getFixedPointPropertiesCoefficients');
            if strcmpi(obj.Arithmetic,'fixed')
                fixedPointProperties = coder.const(@obj.getFixedPointPropertiesCoefficients,...
                    filterInputDataType, obj.pBypassStage3, ...
                    obj.pM3, obj.pM2, obj.CoefficientsStage3, obj.CoefficientsStage2, obj.CoefficientsStage3DataType, obj.CoefficientsStage2DataType);
            end
            
            % Design second stage (CIC compensator)
            if ~strcmpi(obj.Arithmetic,'fixed')
                obj.CICCompFilterSysObj = dsp.FIRDecimator('DecimationFactor', obj.pM2, ...
                    'Numerator', obj.CoefficientsStage2, 'FullPrecisionOverride', false);
            else
                if  obj.pBypassStage3
                    % Set CIC compensator output data type to OutputNumericType
                    obj.CICCompFilterSysObj = dsp.FIRDecimator('DecimationFactor', obj.pM2, ...
                        'Numerator', obj.CoefficientsStage2, 'FullPrecisionOverride', false, ...
                        'CoefficientsDataType', 'Custom', ...
                        'CustomCoefficientsDataType', numerictype([],...
                        obj.CoefficientsStage2DataType.WordLength,...
                        obj.CoefficientsStage2DataType.FractionLength), ...
                        'ProductDataType', 'Custom', ...
                        'AccumulatorDataType', 'Custom', ...
                        'CustomProductDataType', numerictype([],...
                        fixedPointProperties.CICCompProductWordLength,...
                        fixedPointProperties.CICCompProductFracLength), ...
                        'CustomAccumulatorDataType', numerictype([],...
                        fixedPointProperties.CICCompAccumWordLength,...
                        fixedPointProperties.CICCompAccumFracLength), ...
                        'OutputDataType', 'Custom', ...
                        'CustomOutputDataType', obj.OutputNumericType);
                else
                    % Set CIC compensator output data type to FiltersInputNumericType
                    obj.CICCompFilterSysObj = dsp.FIRDecimator('DecimationFactor', obj.pM2, ...
                        'Numerator', obj.CoefficientsStage2, 'FullPrecisionOverride', false, ...
                        'CoefficientsDataType', 'Custom', ...
                        'CustomCoefficientsDataType', numerictype([],...
                        obj.CoefficientsStage2DataType.WordLength,...
                        obj.CoefficientsStage2DataType.FractionLength), ...
                        'ProductDataType', 'Custom', ...
                        'AccumulatorDataType', 'Custom', ...
                        'CustomProductDataType', numerictype([],...
                        fixedPointProperties.CICCompProductWordLength,...
                        fixedPointProperties.CICCompProductFracLength), ...
                        'CustomAccumulatorDataType', numerictype([],...
                        fixedPointProperties.CICCompAccumWordLength,...
                        fixedPointProperties.CICCompAccumFracLength), ...
                        'OutputDataType', 'Custom', ...
                        'CustomOutputDataType', filterInputDataType);
                end
            end
            
            % Third stage design
            if ~obj.pBypassStage3
                if ~strcmpi(obj.Arithmetic,'fixed')
                    obj.Stage3FilterSysObj = dsp.FIRDecimator('DecimationFactor', obj.pM3, ...
                        'Numerator', obj.CoefficientsStage3,  'FullPrecisionOverride', false);
                else
                    % We do not set the output data type since that will be set by
                    % the DDC object.
                    obj.Stage3FilterSysObj = dsp.FIRDecimator('DecimationFactor', obj.pM3, ...
                        'Numerator', obj.CoefficientsStage3,  'FullPrecisionOverride', false, ...
                        'CoefficientsDataType', 'Custom', ...
                        'CustomCoefficientsDataType', numerictype([],...
                        obj.CoefficientsStage3DataType.WordLength,...
                        obj.CoefficientsStage3DataType.FractionLength), ...
                        'ProductDataType', 'Custom', ...
                        'AccumulatorDataType', 'Custom', ...
                        'CustomProductDataType', numerictype([],...
                        fixedPointProperties.Stage3ProductWordLength,...
                        fixedPointProperties.Stage3ProductFracLength), ...
                        'CustomAccumulatorDataType', numerictype([],...
                        fixedPointProperties.Stage3AccumWordLength,...
                        fixedPointProperties.Stage3AccumFracLength), ...
                        'OutputDataType', 'Custom', ...
                        'CustomOutputDataType', obj.OutputNumericType);
                end
            else
                obj.Stage3FilterSysObj = [];
            end
        end
        
        %-------------------------------------------------------------------------
        function CICGain = designCICDecimationFilter(obj,NumCICSections,inputDataType)
            % Design a CIC decimation response and implement it as an FIR
            % filter when Arithmetic is 'double' or 'single', or as a CIC
            % filter when Arithmetic is 'fixed'. Output the gain of the CIC
            % filter.
            
            coder.extrinsic('dsp.internal.ConverterFilterDesignerBase.getCICFIRCoefficients');
            coder.extrinsic('dsp.internal.DownConverterFilterDesigner.getCICFixedPointProperties');
            if ~strcmpi(obj.Arithmetic, 'fixed')
                coeffs = coder.const(@obj.getCICFIRCoefficients,NumCICSections,obj.pM1);
                obj.CICFilterSysObj = dsp.FIRDecimator('DecimationFactor', obj.pM1, ...
                    'Numerator', coeffs);
            else
                % Set word and frac lengths as per FullPrecision mode for CIC
                % Decimator
                fixedPointProperties = coder.const(@obj.getCICFixedPointProperties,...
                    NumCICSections, obj.pM1, inputDataType);

                obj.CICFilterSysObj = dsp.CICDecimator('DecimationFactor', obj.pM1, ...
                    'NumSections', NumCICSections, ...
                    'FixedPointDataType', 'Specify word and fraction lengths', ...
                    'SectionWordLengths', fixedPointProperties.SectionWordLengths, ...
                    'SectionFractionLengths', fixedPointProperties.SectionFracLengths, ...
                    'OutputWordLength', fixedPointProperties.OutputWordLength, ...
                    'OutputFractionLength', fixedPointProperties.OutputFracLength);
            end
            CICGain = obj.pM1^(NumCICSections);
        end
        
        %-------------------------------------------------------------------------
        function designFiltersSpecifiedOrders(obj, inputDataType)
            % Design cascade of decimation filters with specified orders,
            % passband and stopband frequencies.
            
            if ~isempty(inputDataType)
                coder.internal.errorIf(~strcmp(obj.Arithmetic,'fixed'), ...
                    'dsp:system:DigitalDownConverter:invalidArithmetic');
                
                coder.internal.errorIf(~isa(inputDataType,'embedded.numerictype'), ...
                    'dsp:system:DigitalDownConverter:invalidInputType');
            end
            
            % Design first stage (CIC)
            NumCICSections = obj.OrderStage1;
            CICGain = designCICDecimationFilter(obj,NumCICSections, inputDataType);
            
            % CIC gain normalization filter
            obj.GainFilter = 1/CICGain;
            
            % Coefficients for CIC Compensator stage and Third stage
            coder.extrinsic('dsp.internal.DownConverterFilterDesigner.getFilterCoeffsSpecifiedOrder');
            [coeffs2, coeffs3, Astop2, Astop3] = coder.const(@dsp.internal.DownConverterFilterDesigner.getFilterCoeffsSpecifiedOrder,...
                obj.pM2, NumCICSections, obj.pM1, obj.OrderStage2, obj.pPassbandFrequency, ...
                obj.pFstopStage2, obj.pFsStage2, obj.pBypassStage3, obj.pFilterTypeStage3, ...
                obj.pM3, obj.OrderStage3, obj.pTWStage3, obj.pFsStage3, obj.pFstopStage3);
            
            coder.extrinsic('dsp.internal.DownConverterFilterDesigner.getFixedPointPropertiesSpecifiedOrders');
            if strcmpi(obj.Arithmetic,'fixed')
                % Find the minimum coefficient lengths for the CIC compensator, stage
                % 3, and scaling factor. Measure the passband ripple and stopband
                % attenuation of each stage and of the cascade response using double
                % precision. These measurements will be the baseline to compute the
                % smallest possible coefficient word lengths and scale factor data
                % type.
                
                fixedPointProperties = coder.const(@dsp.internal.DownConverterFilterDesigner.getFixedPointPropertiesSpecifiedOrders, ...
                    inputDataType, obj.pM1, 1, NumCICSections, CICGain, ...
                    obj.pM2, coeffs2, obj.pM3, coeffs3, Astop2, Astop3, ...
                    obj.pBypassStage3, obj.SampleRate, obj.pFCICNulls, ...
                    obj.pFstopStage2, obj.pFstopStage3, obj.pNumMagRespMeasPoints, ...
                    obj.MinimumOrderDesign, obj.PassbandRipple, obj.StopbandAttenuation, ...
                    obj.pCascadeFilterStopbandFrequency, obj.pPassbandFrequency);
                
            end
            
            % Design second stage (CIC compensator)
            if ~strcmpi(obj.Arithmetic,'fixed')
                obj.CICCompFilterSysObj = dsp.FIRDecimator('DecimationFactor', obj.pM2, ...
                    'Numerator', coeffs2, 'FullPrecisionOverride', false);
            else
                if  obj.pBypassStage3
                    % Set CIC compensator output data type to OutputNumericType
                    obj.CICCompFilterSysObj = dsp.FIRDecimator('DecimationFactor', obj.pM2, ...
                        'Numerator', coeffs2, 'FullPrecisionOverride', false, ...
                        'CoefficientsDataType', 'Custom', ...
                        'CustomCoefficientsDataType', numerictype([],...
                        fixedPointProperties.CICCompWordLength,...
                        fixedPointProperties.CICCompFracLength), ...
                        'ProductDataType', 'Custom', ...
                        'AccumulatorDataType', 'Custom', ...
                        'CustomProductDataType', numerictype([],...
                        fixedPointProperties.CICCompProductWordLength,...
                        fixedPointProperties.CICCompProductFracLength), ...
                        'CustomAccumulatorDataType', numerictype([],...
                        fixedPointProperties.CICCompAccumWordLength,...
                        fixedPointProperties.CICCompAccumFracLength), ...
                        'OutputDataType', 'Custom', ...
                        'CustomOutputDataType', obj.OutputNumericType);
                else
                    % Set CIC compensator output data type to FiltersInputNumericType
                    obj.CICCompFilterSysObj = dsp.FIRDecimator('DecimationFactor', obj.pM2, ...
                        'Numerator', coeffs2, 'FullPrecisionOverride', false, ...
                        'CoefficientsDataType', 'Custom', ...
                        'CustomCoefficientsDataType', numerictype([],...
                        fixedPointProperties.CICCompWordLength,...
                        fixedPointProperties.CICCompFracLength), ...
                        'ProductDataType', 'Custom', ...
                        'AccumulatorDataType', 'Custom', ...
                        'CustomProductDataType', numerictype([],...
                        fixedPointProperties.CICCompProductWordLength,...
                        fixedPointProperties.CICCompProductFracLength), ...
                        'CustomAccumulatorDataType', numerictype([],...
                        fixedPointProperties.CICCompAccumWordLength,...
                        fixedPointProperties.CICCompAccumFracLength), ...
                        'OutputDataType', 'Custom', ...
                        'CustomOutputDataType', inputDataType);
                end
            end
            
            % Third stage design
            if ~obj.pBypassStage3
                if ~strcmpi(obj.Arithmetic,'fixed')
                    obj.Stage3FilterSysObj = dsp.FIRDecimator('DecimationFactor', obj.pM3, ...
                        'Numerator', coeffs3,  'FullPrecisionOverride', false);
                else
                    % We do not set the output data type since that will be set by
                    % the DDC object.
                    obj.Stage3FilterSysObj = dsp.FIRDecimator('DecimationFactor', obj.pM3, ...
                        'Numerator', coeffs3,  'FullPrecisionOverride', false, ...
                        'CoefficientsDataType', 'Custom', ...
                        'CustomCoefficientsDataType', numerictype([],...
                        fixedPointProperties.ThirdFilterWordLength,...
                        fixedPointProperties.ThirdFilterFracLength), ...
                        'ProductDataType', 'Custom', ...
                        'AccumulatorDataType', 'Custom', ...
                        'CustomProductDataType', numerictype([],...
                        fixedPointProperties.ThirdFilterProductWordLength,...
                        fixedPointProperties.ThirdFilterProductFracLength), ...
                        'CustomAccumulatorDataType', numerictype([],...
                        fixedPointProperties.ThirdFilterAccumWordLength,...
                        fixedPointProperties.ThirdFilterAccumFracLength), ...
                        'OutputDataType', 'Custom', ...
                        'CustomOutputDataType', obj.OutputNumericType);
                end
            else
                obj.Stage3FilterSysObj = [];
            end
        end
        %-------------------------------------------------------------------------
        function designFiltersMinOrder(obj, inputDataType)
            % Design cascade of minimum order decimation filters that meets
            % specifications.
            
            if ~isempty(inputDataType)
                coder.internal.errorIf(~strcmp(obj.Arithmetic,'fixed'), ...
                    'dsp:system:DigitalDownConverter:invalidArithmetic');
                
                coder.internal.errorIf(~isa(inputDataType,'embedded.numerictype'), ...
                    'dsp:system:DigitalDownConverter:invalidInputType');
            end
            
            coder.extrinsic('dsp.internal.DownConverterFilterDesigner.getFilterCoeffsMinOrder');
            % Get the number of CIC sections and coefficients of other
            % filters in case of minimum order design
            [NumCICSections, coeffs2, coeffs3, CICNormFact, Astop2, Astop3, isDone] = coder.const(@dsp.internal.DownConverterFilterDesigner.getFilterCoeffsMinOrder,...
                obj.PassbandRipple, obj.StopbandAttenuation, ...
                obj.pBypassStage3, obj.SampleRate, obj.pFCICNulls, ...
                obj.pFstopStage2, obj.pFstopStage3, obj.pNumMagRespMeasPoints, ...
                obj.pM2, obj.pPassbandFrequency, obj.pFsStage2, ...
                obj.pFilterTypeStage3, obj.pM3, obj.pTWStage3, obj.pFsStage3, ...
                obj.pM1, obj.pPassBandRippleReductionFactor, obj.pStopbandAttenuationStep, ...
                obj.Arithmetic, obj.pFsStage1, obj.MinimumOrderDesign);

            % Design first stage (CIC)
            designCICDecimationFilter(obj,NumCICSections, inputDataType);
            
            % CIC gain normalization filter
            obj.GainFilter = CICNormFact;
            
            coder.extrinsic('dsp.internal.DownConverterFilterDesigner.getFixedPointPropertiesMinOrder');
            if ~isDone
                if strcmpi(obj.Arithmetic,'fixed')
                    warning(message('dsp:system:DigitalDownConverter:noConvergenceDtype'));
                else
                    warning(message('dsp:system:DigitalDownConverter:noConvergence'));
                end
            else
                if strcmpi(obj.Arithmetic,'fixed')
                    % Find the minimum coefficient lengths for the CIC compensator, stage
                    % 3, and scaling factor. The specified passband ripple and stopband
                    % attenuation  of the cascade response will be the baseline to compute the
                    % smallest possible coefficient word lengths and scale factor data
                    % type.
                    
                    fixedPointProperties = coder.const(@dsp.internal.DownConverterFilterDesigner.getFixedPointPropertiesMinOrder, ...
                        inputDataType, obj.pM1, 1, NumCICSections, CICNormFact, ...
                        obj.pM2, coeffs2, obj.pM3, coeffs3, Astop2, Astop3, ...
                        obj.pBypassStage3, obj.SampleRate, obj.pFCICNulls, ...
                        obj.pFstopStage2, obj.pFstopStage3, obj.pNumMagRespMeasPoints, ...
                        obj.MinimumOrderDesign, obj.PassbandRipple, obj.StopbandAttenuation, ...
                        obj.pCascadeFilterStopbandFrequency, obj.pPassbandFrequency, ...
                        obj.PassbandRipple, obj.StopbandAttenuation);
                end
            end
            
            % Design second stage (CIC compensator)
            if ~strcmpi(obj.Arithmetic,'fixed')
                obj.CICCompFilterSysObj = dsp.FIRDecimator('DecimationFactor', obj.pM2, ...
                    'Numerator', coeffs2, 'FullPrecisionOverride', false);
            else
                if  obj.pBypassStage3
                    % Set CIC compensator output data type to OutputNumericType
                    obj.CICCompFilterSysObj = dsp.FIRDecimator('DecimationFactor', obj.pM2, ...
                        'Numerator', coeffs2, 'FullPrecisionOverride', false, ...
                        'CoefficientsDataType', 'Custom', ...
                        'CustomCoefficientsDataType', numerictype([],...
                        fixedPointProperties.CICCompWordLength,...
                        fixedPointProperties.CICCompFracLength), ...
                        'ProductDataType', 'Custom', ...
                        'AccumulatorDataType', 'Custom', ...
                        'CustomProductDataType', numerictype([],...
                        fixedPointProperties.CICCompProductWordLength,...
                        fixedPointProperties.CICCompProductFracLength), ...
                        'CustomAccumulatorDataType', numerictype([],...
                        fixedPointProperties.CICCompAccumWordLength,...
                        fixedPointProperties.CICCompAccumFracLength), ...
                        'OutputDataType', 'Custom', ...
                        'CustomOutputDataType', obj.OutputNumericType);
                else
                    % Set CIC compensator output data type to FiltersInputNumericType
                    obj.CICCompFilterSysObj = dsp.FIRDecimator('DecimationFactor', obj.pM2, ...
                        'Numerator', coeffs2, 'FullPrecisionOverride', false, ...
                        'CoefficientsDataType', 'Custom', ...
                        'CustomCoefficientsDataType', numerictype([],...
                        fixedPointProperties.CICCompWordLength,...
                        fixedPointProperties.CICCompFracLength), ...
                        'ProductDataType', 'Custom', ...
                        'AccumulatorDataType', 'Custom', ...
                        'CustomProductDataType', numerictype([],...
                        fixedPointProperties.CICCompProductWordLength,...
                        fixedPointProperties.CICCompProductFracLength), ...
                        'CustomAccumulatorDataType', numerictype([],...
                        fixedPointProperties.CICCompAccumWordLength,...
                        fixedPointProperties.CICCompAccumFracLength), ...
                        'OutputDataType', 'Custom', ...
                        'CustomOutputDataType', inputDataType);
                end
            end
            
            % Third stage design
            if ~obj.pBypassStage3
                if ~strcmpi(obj.Arithmetic,'fixed')
                    obj.Stage3FilterSysObj = dsp.FIRDecimator('DecimationFactor', obj.pM3, ...
                        'Numerator', coeffs3,  'FullPrecisionOverride', false);
                else
                    % We do not set the output data type since that will be set by
                    % the DDC object.
                    obj.Stage3FilterSysObj = dsp.FIRDecimator('DecimationFactor', obj.pM3, ...
                        'Numerator', coeffs3,  'FullPrecisionOverride', false, ...
                        'CoefficientsDataType', 'Custom', ...
                        'CustomCoefficientsDataType', numerictype([],...
                        fixedPointProperties.ThirdFilterWordLength,...
                        fixedPointProperties.ThirdFilterFracLength), ...
                        'ProductDataType', 'Custom', ...
                        'AccumulatorDataType', 'Custom', ...
                        'CustomProductDataType', numerictype([],...
                        fixedPointProperties.ThirdFilterProductWordLength,...
                        fixedPointProperties.ThirdFilterProductFracLength), ...
                        'CustomAccumulatorDataType', numerictype([],...
                        fixedPointProperties.ThirdFilterAccumWordLength,...
                        fixedPointProperties.ThirdFilterAccumFracLength), ...
                        'OutputDataType', 'Custom', ...
                        'CustomOutputDataType', obj.OutputNumericType);
                end
            else
                obj.Stage3FilterSysObj = [];
            end
        end
        %------------------------------------------------------------------
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@dsp.internal.ConverterFilterDesignerBase(obj);
            
            s.Stage3FilterSysObj = matlab.System.saveObject(obj.Stage3FilterSysObj);
            s.pStage3Filter = obj.pStage3Filter;
            s.pBypassStage3 = obj.pBypassStage3;
            s.pFilterTypeStage3 = obj.pFilterTypeStage3;
            s.pFstopStage3 = obj.pFstopStage3;
            s.pFcuttofStage3 = obj.pFcuttofStage3;
            s.pTWStage3 = obj.pTWStage3;
        end
        %------------------------------------------------------------------
        function loadObjectImpl(obj, s,wasLocked)
            loadSubObjects(obj,s,wasLocked);

            obj.Stage3FilterSysObj = matlab.System.loadObject(s.Stage3FilterSysObj);
            obj.pStage3Filter = s.pStage3Filter;
            obj.pBypassStage3 = s.pBypassStage3;
            obj.pFilterTypeStage3 = s.pFilterTypeStage3;
            obj.pFstopStage3 = s.pFstopStage3;
            obj.pFcuttofStage3 = s.pFcuttofStage3;
            obj.pTWStage3 = s.pTWStage3;
            
            % Call the base class method
            loadObjectImpl@matlab.System(obj, s);
        end
    end
    %----------------------------------------------------------------------
    % Static methods
    %----------------------------------------------------------------------
    methods (Static, Hidden)
        function [coeffs2, coeffs3, Astop2, Astop3] = getFilterCoeffsSpecifiedOrder(...
                pM2, NumCICSections, pM1, OrderStage2, pPassbandFrequency, ...
                pFstopStage2, pFsStage2, pBypassStage3, pFilterTypeStage3, ...
                pM3, OrderStage3, pTWStage3, pFsStage3, pFstopStage3)
            % Compute coefficients for CIC Compensator and Third stage
            % filter
            
            % Suppress MFILT deprecation warning on calling design method
            % on an fdesign object without "SystemObject" flag set to true.
            w = warning('off', 'dsp:fdesign:basecatalog:UseSystemObjectForMultirateDesigns');
            restoreWarn = onCleanup(@() warning(w));
            
            % Design second stage (CIC compensator)
            d = fdesign.decimator(pM2,'ciccomp',1,NumCICSections,pM1,...
                'n,fp,fst', OrderStage2, pPassbandFrequency,...
                pFstopStage2, pFsStage2);
            pCICCompFilter = design(d,'equiripple');
            coeffs2 = pCICCompFilter.Numerator;
            m2 = measure(pCICCompFilter);
            Astop2 = m2.Astop;
            
            % Third stage design
            if ~pBypassStage3
                if strcmp(pFilterTypeStage3,'halfband')
                    d = fdesign.decimator(pM3,'halfband','n,tw',...
                        OrderStage3,pTWStage3,pFsStage3);
                    %Kaiserwin is used to ensure convergence of halfband design
                    pStage3Filter = design(d,'kaiserwin');
                    coeffs3 = pStage3Filter.Numerator;
                else
                    d = fdesign.decimator(pM3,'lowpass','n,fp,fst',...
                        OrderStage3, pPassbandFrequency,...
                        pFstopStage3,pFsStage3);
                    pStage3Filter = design(d,'equiripple');
                    coeffs3 = pStage3Filter.Numerator;
                end
                m3 = measure(pStage3Filter);
                Astop3 = m3.Astop;
            else
                coeffs3= [];
                Astop3 = [];
            end
            
        end
        %------------------------------------------------------------------
        function [NumCICSections, coeffs2, coeffs3, CICNormFact, Astop2, Astop3, isDone] = getFilterCoeffsMinOrder(...
                PassbandRipple, StopbandAttenuation, ...
                pBypassStage3, SampleRate, pFCICNulls, pFstopStage2, pFstopStage3, ...
                pNumMagRespMeasPoints, pM2, pPassbandFrequency, pFsStage2, ...
                pFilterTypeStage3, pM3, pTWStage3, pFsStage3, pM1, ...
                pPassBandRippleReductionFactor, pStopbandAttenuationStep, ...
                Arithmetic, pFsStage1, MinimumOrderDesign)
            %Compute quantities that will be useful to perform measurements on the
            %cascade response. Set attenuation variables that will be updated with
            %new values until the specifications are met.
            
            pActualPassbandRipple = PassbandRipple;
            pActualStopbandAttenuation = StopbandAttenuation;
            
            %Initial passband ripple and stopband attenuation for stages 2 and 3
            Ap2 = PassbandRipple;
            Astop2 = StopbandAttenuation;
            Ap3 = PassbandRipple;
            Astop3 = StopbandAttenuation;
            
            if pBypassStage3
                Fmax = min(SampleRate/2, pFCICNulls(1)+pFstopStage2);
                interval1 = [pFstopStage2 pFCICNulls(1)-pFstopStage2];
                interval2 = [pFCICNulls(1)-pFstopStage2 Fmax];
            else
                Fmax = min(SampleRate/2, pFCICNulls(1)+pFstopStage3);
                interval1 = [pFstopStage3 pFstopStage2];
                interval2 = [pFstopStage2 pFCICNulls(1)-pFstopStage3];
                interval3 = [pFCICNulls(1)-pFstopStage3 Fmax];
            end
            % Measurement frequencies
            FVect = linspace(0,Fmax,pNumMagRespMeasPoints);
            % Compute overall gain of cascade response
            cascadeGain = 0; % dB
            
            % Loop until specs are met or until the number of iterations has gone
            % beyond 20.
            % Define some loop flags
            isDone = false;
            numIters = 0;
            reDesignStage1 = true;
            reDesignStage2 = true;
            reDesignStage3 = true;
            reDesignStage3Order = false;
            reDesignNormalizationStage = false;
            rippleFactor = 1;
            
            % Suppress MFILT deprecation warning on calling design method
            % on an fdesign object without "SystemObject" flag set to true.
            w = warning('off', 'dsp:fdesign:basecatalog:UseSystemObjectForMultirateDesigns');
            restoreWarn = onCleanup(@() warning(w));
            
            % Instantiate designer objects before going into the iterations
            dStage2 = fdesign.decimator(pM2,'ciccomp',1,2,...
                'fp,fst,ap,ast',pPassbandFrequency,pFstopStage2,...
                Ap2,Astop2,pFsStage2);
            
            if ~pBypassStage3
                if strcmp(pFilterTypeStage3,'halfband')
                    dStage3 = fdesign.decimator(pM3,'halfband','TW,ast',...
                        pTWStage3,Astop3,pFsStage3);
                else
                    dStage3 = fdesign.decimator(pM3,'lowpass','Fp,Fst,Ap,Ast', ...
                        pPassbandFrequency,pFstopStage3,Ap3,...
                        Astop3,pFsStage3);
                end
            end
            
            while ~isDone && numIters < 21
                %Design first stage (CIC)
                if numIters == 0
                    [pCICFilter, NumCICSections, CICGain] = dsp.internal.DownConverterFilterDesigner.designMinOrderCICDecimationFilter(...
                        Arithmetic, pM1, pPassbandFrequency,StopbandAttenuation, pFsStage1);
                else
                    if reDesignStage1
                        [pCICFilter, CICGain] = dsp.internal.DownConverterFilterDesigner.designSectionsCICDecimationFilter(...
                            Arithmetic, NumCICSections, pM1);
                    end
                end
                
                if reDesignStage1 || reDesignNormalizationStage
                    % CIC gain normalization filter
                    pGainFilter = dfilt.scalar(rippleFactor/CICGain);
                end
                
                % Second stage design
                if reDesignStage2
                    dStage2.NumberOfSections = NumCICSections;
                    dStage2.CICRateChangeFactor = pM1;
                    dStage2.Apass = Ap2;
                    dStage2.Astop = Astop2;
                    pCICCompFilter = design(dStage2,'equiripple');
                end
                
                % Third stage design
                if ~pBypassStage3 && (reDesignStage3 || reDesignStage3Order)
                    if reDesignStage3
                        if strcmp(pFilterTypeStage3,'halfband')
                            dStage3.Astop = Astop3;
                            %Kaiserwin is used to ensure convergence of halfband design
                            pStage3Filter = design(dStage3,'kaiserwin');
                        else
                            dStage3.Apass = Ap3;
                            dStage3.Astop = Astop3;
                            pStage3Filter = design(dStage3,'equiripple');
                        end
                    else
                        if reDesignStage3Order
                            d = fdesign.decimator(pM3,'halfband','N,TW',...
                                N,pTWStage3,pFsStage3);
                            %Kaiserwin is used to ensure convergence of halfband design
                            pStage3Filter = design(d,'kaiserwin');
                        end
                    end
                end
                
                if pBypassStage3
                    pCascadeFilter = cascade(pCICFilter, pGainFilter,...
                        pCICCompFilter);
                else
                    pCascadeFilter = cascade(pCICFilter,pGainFilter,...
                        pCICCompFilter,pStage3Filter);
                end
                
                % Measure cascade response and adjust parameters if specifications
                % are not met. Do not redesign the filters unless a parameter of the
                % filter needs to be updated to meet the specifications. Decimation
                % filter cascade operates at input sample rate.
                reDesignStage1 = false;
                reDesignStage2 = false;
                reDesignStage3 = false;
                reDesignStage3Order = false;
                reDesignNormalizationStage = false;
                
                % If Arithmetic is 'Single', change the arithmetic of the filters to
                % single. If Arithmetic is 'fixed', design the filters in double
                % precision and then find the coefficients data type that meet the
                % specifications.
                if strcmpi(Arithmetic,'single')
                    pCICFilter.Arithmetic = 'Single';
                    pCICCompFilter.Arithmetic = 'Single';
                    if ~pBypassStage3
                        pStage3Filter.Arithmetic = 'Single';
                    end
                    pGainFilter.Arithmetic = 'Single';
                end
                
                magResp = 20*log10(abs(freqz(pCascadeFilter,FVect,...
                    SampleRate)));
                
                % If ripple specification is not met, then decrease the passband
                % ripple of the third stage or CIC compensator filter. Equiripple Spec
                % is the ripple measured from 0 dB to max(magResp) and from 0 dB to
                % min(magResponse). Ripple spec is measured as max(magResponse) -
                % min(magResponse).
                [equiRippleSpecMet, rippleSpecMet] = ...
                    dsp.internal.DownConverterFilterDesigner.isRippleSpecMet(magResp,FVect,cascadeGain, ...
                    MinimumOrderDesign, pActualPassbandRipple, pPassbandFrequency);
                if ~equiRippleSpecMet && ~rippleSpecMet
                    if  ~pBypassStage3
                        if strcmp(pFilterTypeStage3,'lowpass')
                            Ap3 = Ap3*pPassBandRippleReductionFactor;
                            reDesignStage3 = true;
                            Ap2 = Ap2*pPassBandRippleReductionFactor;
                            reDesignStage2 = true;
                        else
                            Ap2 = Ap2*pPassBandRippleReductionFactor;
                            reDesignStage2 = true;
                            N = order(pStage3Filter) + 1;
                            if mod(N,2)
                                N = N+1;
                            end
                            reDesignStage3Order = true;
                        end
                    else
                        Ap2 = Ap2*pPassBandRippleReductionFactor;
                        reDesignStage2 = true;
                    end
                    isDoneRipple = false;
                elseif equiRippleSpecMet
                    isDoneRipple = true;
                elseif ~equiRippleSpecMet && rippleSpecMet
                    % The ripple (max(magResp) - min(magResp)) meets the specification
                    % value but is not centered around 0 dB. Center it by applying some
                    % attenuation via the scalar normalization filter.
                    rippleFactor = dsp.internal.ConverterFilterDesignerBase.centerRipple(magResp,FVect,cascadeGain,pPassbandFrequency);
                    isDoneRipple = false;
                    reDesignNormalizationStage = true;
                end
                
                % If attenuation is not met in different stopband regions, increase
                % the attenuation specification of the filters.
                if ~dsp.internal.DownConverterFilterDesigner.isStopbandAttenuationSpecMet(magResp,FVect,cascadeGain,interval1, ...
                        pActualStopbandAttenuation)
                    % Wait until the attenuation specs are met before centering the
                    % equiripple around the cascade gain.
                    rippleFactor = 1;
                    if pBypassStage3
                        Astop2 = Astop2 + pStopbandAttenuationStep;
                        reDesignStage2 = true;
                    else
                        Astop3 = Astop3 + pStopbandAttenuationStep;
                        reDesignStage3 = true;
                    end
                    isDoneInterval1 = false;
                else
                    isDoneInterval1 = true;
                end
                
                if ~dsp.internal.DownConverterFilterDesigner.isStopbandAttenuationSpecMet(magResp,FVect,cascadeGain,...
                        interval2, pActualStopbandAttenuation)
                    % Wait until the attenuation specs are met before centering the
                    % equiripple around the cascade gain.
                    rippleFactor = 1;
                    if pBypassStage3
                        NumCICSections = NumCICSections + 1;
                        reDesignStage1 = true;
                        reDesignStage2 = true;
                    else
                        Astop2 = Astop2 + pStopbandAttenuationStep;
                        reDesignStage2 = true;
                    end
                    isDoneInterval2 = false;
                else
                    isDoneInterval2 = true;
                end
                
                if ~pBypassStage3
                    if ~dsp.internal.DownConverterFilterDesigner.isStopbandAttenuationSpecMet(magResp,FVect,cascadeGain,...
                            interval3, pActualStopbandAttenuation)
                        % Wait until the attenuation specs are met before centering the
                        % equiripple around the cascade gain.
                        rippleFactor = 1;
                        NumCICSections = NumCICSections + 1;
                        reDesignStage1 = true;
                        reDesignStage2 = true;
                        isDoneInterval3 = false;
                    else
                        isDoneInterval3 = true;
                    end
                else
                    isDoneInterval3 = true;
                end
                
                isDone = isDoneRipple & isDoneInterval1 &...
                    isDoneInterval2 & isDoneInterval3;
                
                numIters = numIters + 1;
            end
            coeffs2 = pCICCompFilter.Numerator;
            if ~pBypassStage3
                coeffs3 = pStage3Filter.Numerator; 
            else
                coeffs3 = [];
            end
            CICNormFact = pGainFilter.Gain;
        end
        %------------------------------------------------------------------
        function fixedPointProperties = getFixedPointPropertiesSpecifiedOrders( ...
                inputDataType, cicDecimation, cicDiffDelay, cicNumSections, cicgain, ...
                ciccompDecimation, ciccompCoeffs, stage3Decimation, ...
                stage3Coeffs, Astop2, Astop3, pBypassStage3, SampleRate, ...
                pFCICNulls, pFstopStage2, pFstopStage3, pNumMagRespMeasPoints, ...
                MinimumOrderDesign, PassbandRipple, StopbandAttenuation, ...
                pCascadeFilterStopbandFrequency, pPassbandFrequency)
            
            % Suppress MFILT deprecation warnings
            w = warning('off', 'dsp:mfilt:mfilt:Obsolete');
            restoreWarn = onCleanup(@() warning(w));
            
            % create a cascade filter object
            stage1 = mfilt.cicdecim(cicDecimation,cicDiffDelay,cicNumSections);%#ok
            stage2 = dfilt.scalar(1/cicgain);
            stage3 = mfilt.firdecim(ciccompDecimation, ciccompCoeffs);%#ok
            if ~pBypassStage3
                stage4 = mfilt.firdecim(stage3Decimation, stage3Coeffs);%#ok
                pCascadeFilter = mfilt.cascade(stage1, stage2, stage3, stage4);%#ok
            else
                pCascadeFilter = mfilt.cascade(stage1, stage2, stage3);%#ok
            end
            
            % Get ripple and attenuation measurements to adjust data type of
            % scaling normalization
            if pBypassStage3
                Fmax = ...
                    min(SampleRate/2, pFCICNulls(1)+pFstopStage2);
                interval = [pFstopStage2 Fmax];
            else
                Fmax = ...
                    min(SampleRate/2, pFCICNulls(1)+pFstopStage3);
                interval = [pFstopStage3 Fmax];
            end
            % Measurement frequencies
            FVect = linspace(0,Fmax,pNumMagRespMeasPoints);
            magResp = 20*log10(abs(freqz(pCascadeFilter,FVect,...
                SampleRate)));
            
            % get ripple and specification for double precision
            cascadeGain = 0;
            [~, pActualPassbandRipple] =  ...
                dsp.internal.DownConverterFilterDesigner.measurePassbandRipple(magResp,FVect,cascadeGain, ...
                pPassbandFrequency);
            pActualStopbandAttenuation = dsp.internal.DownConverterFilterDesigner.measureAttenuation(magResp,...
                FVect,cascadeGain,interval);
            
            % set the wordlength of filter coefficients
            pCascadeFilter = dsp.internal.DownConverterFilterDesigner.setWordLengthOfFilterSections(inputDataType,pCascadeFilter,pBypassStage3,Astop2,Astop3, ...
                MinimumOrderDesign,PassbandRipple, StopbandAttenuation, ...
                SampleRate, pFCICNulls, pFstopStage2, pFstopStage3, pNumMagRespMeasPoints, ...
                pCascadeFilterStopbandFrequency, pActualPassbandRipple, pActualStopbandAttenuation, ...
                pPassbandFrequency);
            
            fixedPointProperties.CICCompWordLength = pCascadeFilter.Stage(3).CoeffWordLength;
            fixedPointProperties.CICCompFracLength =  pCascadeFilter.Stage(3).NumFracLength;
            fixedPointProperties.CICCompProductWordLength = pCascadeFilter.Stage(3).ProductWordLength;
            fixedPointProperties.CICCompProductFracLength = pCascadeFilter.Stage(3).ProductFracLength;
            fixedPointProperties.CICCompAccumWordLength = pCascadeFilter.Stage(3).AccumWordLength;
            fixedPointProperties.CICCompAccumFracLength = pCascadeFilter.Stage(3).AccumFracLength;
            if ~pBypassStage3
                fixedPointProperties.ThirdFilterWordLength = pCascadeFilter.Stage(4).CoeffWordLength;
                fixedPointProperties.ThirdFilterFracLength =  pCascadeFilter.Stage(4).NumFracLength;
                fixedPointProperties.ThirdFilterProductWordLength = pCascadeFilter.Stage(4).ProductWordLength;
                fixedPointProperties.ThirdFilterProductFracLength = pCascadeFilter.Stage(4).ProductFracLength;
                fixedPointProperties.ThirdFilterAccumWordLength = pCascadeFilter.Stage(4).AccumWordLength;
                fixedPointProperties.ThirdFilterAccumFracLength = pCascadeFilter.Stage(4).AccumFracLength;
            end
        end
        %------------------------------------------------------------------
        function fixedPointProperties = getFixedPointPropertiesMinOrder( ...
                inputDataType, cicDecimation, cicDiffDelay, cicNumSections, CICNormFact, ...
                ciccompDecimation, ciccompCoeffs, stage3Decimation, ...
                stage3Coeffs, Astop2, Astop3, pBypassStage3, SampleRate, ...
                pFCICNulls, pFstopStage2, pFstopStage3, pNumMagRespMeasPoints, ...
                MinimumOrderDesign, PassbandRipple, StopbandAttenuation, ...
                pCascadeFilterStopbandFrequency, pPassbandFrequency, ...
                pActualPassbandRipple, pActualStopbandAttenuation)
            
            % Suppress MFILT deprecation warnings
            w = warning('off', 'dsp:mfilt:mfilt:Obsolete');
            restoreWarn = onCleanup(@() warning(w));
            
            % create a cascade filter object
            stage1 = mfilt.cicdecim(cicDecimation,cicDiffDelay,cicNumSections);%#ok
            stage2 = dfilt.scalar(CICNormFact);
            stage3 = mfilt.firdecim(ciccompDecimation, ciccompCoeffs);%#ok
            if ~pBypassStage3
                stage4 = mfilt.firdecim(stage3Decimation, stage3Coeffs);%#ok
                pCascadeFilter = mfilt.cascade(stage1, stage2, stage3, stage4);%#ok
            else
                pCascadeFilter = mfilt.cascade(stage1, stage2, stage3);%#ok
            end
            
            % set the wordlength of filter coefficients
            pCascadeFilter = dsp.internal.DownConverterFilterDesigner.setWordLengthOfFilterSections(inputDataType,pCascadeFilter,pBypassStage3,Astop2,Astop3, ...
                MinimumOrderDesign,PassbandRipple, StopbandAttenuation, ...
                SampleRate, pFCICNulls, pFstopStage2, pFstopStage3, pNumMagRespMeasPoints, ...
                pCascadeFilterStopbandFrequency, pActualPassbandRipple, pActualStopbandAttenuation, ...
                pPassbandFrequency);
            
            fixedPointProperties.CICCompWordLength = pCascadeFilter.Stage(3).CoeffWordLength;
            fixedPointProperties.CICCompFracLength =  pCascadeFilter.Stage(3).NumFracLength;
            fixedPointProperties.CICCompProductWordLength = pCascadeFilter.Stage(3).ProductWordLength;
            fixedPointProperties.CICCompProductFracLength = pCascadeFilter.Stage(3).ProductFracLength;
            fixedPointProperties.CICCompAccumWordLength = pCascadeFilter.Stage(3).AccumWordLength;
            fixedPointProperties.CICCompAccumFracLength = pCascadeFilter.Stage(3).AccumFracLength;
            if ~pBypassStage3
                fixedPointProperties.ThirdFilterWordLength = pCascadeFilter.Stage(4).CoeffWordLength;
                fixedPointProperties.ThirdFilterFracLength =  pCascadeFilter.Stage(4).NumFracLength;
                fixedPointProperties.ThirdFilterProductWordLength = pCascadeFilter.Stage(4).ProductWordLength;
                fixedPointProperties.ThirdFilterProductFracLength = pCascadeFilter.Stage(4).ProductFracLength;
                fixedPointProperties.ThirdFilterAccumWordLength = pCascadeFilter.Stage(4).AccumWordLength;
                fixedPointProperties.ThirdFilterAccumFracLength = pCascadeFilter.Stage(4).AccumFracLength;
            end
        end
        %-------------------------------------------------------------------------
        function pCascadeFilter =setWordLengthOfFilterSections(inputDataType,pCascadeFilter,pBypassStage3,Astop2,Astop3, ...
                MinimumOrderDesign,PassbandRipple, StopbandAttenuation, ...
                SampleRate, pFCICNulls, pFstopStage2, pFstopStage3, pNumMagRespMeasPoints, ...
                pCascadeFilterStopbandFrequency, pActualPassbandRipple, pActualStopbandAttenuation, ...
                pPassbandFrequency)
            % Find smallest word length that still allows the filter cascade to
            % meet specifications
            
            % Apply rule of thumb - 6 dB of attenuation per bit - to compute
            % initial word length. Use the attenuation values used in the final
            % design of the cascade (Astop1, Astop2)
            pCascadeFilter.Stage(3).Arithmetic = 'fixed';
            pCascadeFilter.Stage(3).InputWordLength = inputDataType.WordLength;
            pCascadeFilter.Stage(3).InputFracLength = inputDataType.FractionLength;
            WL2 = round(Astop2/6);
            if ~pBypassStage3
                pCascadeFilter.Stage(4).Arithmetic = 'fixed';
                pCascadeFilter.Stage(4).InputWordLength = inputDataType.WordLength;
                pCascadeFilter.Stage(4).InputFracLength = inputDataType.FractionLength;
                WL3 = round(Astop3/6);
            else
                WL3 = []; % don't care value
            end
            dsp.internal.DownConverterFilterDesigner.optimizeCoefficientsWordLengths(pCascadeFilter,pBypassStage3,WL2,WL3, ...
                MinimumOrderDesign,PassbandRipple, StopbandAttenuation, ...
                SampleRate, pFCICNulls, pFstopStage2, pFstopStage3, pNumMagRespMeasPoints, ...
                pCascadeFilterStopbandFrequency, pActualPassbandRipple, pActualStopbandAttenuation, ...
                pPassbandFrequency);
        end
        %------------------------------------------------------------------
        function pCascadeFilter = setCoefficientsWordLength(pCascadeFilter,pBypassStage3,WL2,WL3)
            if ~pBypassStage3
                pCascadeFilter.Stage(4).CoeffWordLength = WL3;
            end
            pCascadeFilter.Stage(3).CoeffWordLength = WL2;
        end
        
        %------------------------------------------------------------------
        function flag = privIsSpecMet(MinimumOrderDesign,PassbandRipple, StopbandAttenuation, ...
                pBypassStage3, SampleRate, pFCICNulls, pFstopStage2, pFstopStage3, pNumMagRespMeasPoints, ...
                pCascadeFilter, pCascadeFilterStopbandFrequency, pActualPassbandRipple, ...
                pActualStopbandAttenuation, pPassbandFrequency)
            % Protected method can be called even if a final filter design is not
            % available yet. Returns true if the cascade response meets the filter
            % specifications.
            
            if MinimumOrderDesign
                pActualPassbandRipple = PassbandRipple;
                pActualStopbandAttenuation = StopbandAttenuation;
            end
            
            if pBypassStage3
                Fmax = ...
                    min(SampleRate/2, pFCICNulls(1)+pFstopStage2);
            else
                Fmax = ...
                    min(SampleRate/2, pFCICNulls(1)+pFstopStage3);
            end
            
            % Measurement frequencies
            FVect = linspace(0,Fmax,pNumMagRespMeasPoints);
            magResp = 20*log10(...
                abs(freqz(pCascadeFilter,FVect,SampleRate)));
            cascadeGain = 0;
            flag = dsp.internal.DownConverterFilterDesigner.thisIsSpecMet(magResp,FVect,cascadeGain,...
                pCascadeFilterStopbandFrequency,MinimumOrderDesign, pActualPassbandRipple, ...
                pActualStopbandAttenuation, pPassbandFrequency);
        end
        
        %------------------------------------------------------------------
        function optimizeCoefficientsWordLengths(pCascadeFilter,pBypassStage3,WL1,WL2, ...
                MinimumOrderDesign,PassbandRipple, StopbandAttenuation, ...
                SampleRate, pFCICNulls, pFstopStage2, pFstopStage3, pNumMagRespMeasPoints, ...
                pCascadeFilterStopbandFrequency, pActualPassbandRipple, pActualStopbandAttenuation, ...
                pPassbandFrequency)
            % Iterate until we find a word length that meets the specifications WL1
            % and WL2 are initial word lengths for the Stage1 and CIC compensator
            % sections (when obj is an up converter) or the word lengths for the CIC
            % compensator and Stage2 (when obj is a down converter)
            
            isDone1 = false;
            isDone2 = false;
            numIters = 0;
            while ~isDone1 && numIters < 14
                pCascadeFilter = dsp.internal.DownConverterFilterDesigner.setCoefficientsWordLength(pCascadeFilter,pBypassStage3,WL1,WL2);
                isDone1 = dsp.internal.DownConverterFilterDesigner.privIsSpecMet(MinimumOrderDesign,PassbandRipple, StopbandAttenuation, ...
                    pBypassStage3, SampleRate, pFCICNulls, pFstopStage2, pFstopStage3, pNumMagRespMeasPoints, ...
                    pCascadeFilter, pCascadeFilterStopbandFrequency, pActualPassbandRipple, ...
                    pActualStopbandAttenuation, pPassbandFrequency);
                if ~isDone1
                    WL1 = WL1 + 4;
                    WL2 = WL2 + 4;
                else
                    idx = 3;
                    while ~isDone2
                        WL1b = max(2,WL1 - idx); % Coefficients need at least 2 bits
                        WL2b = max(2,WL2 - idx);
                        pCascadeFilter = dsp.internal.DownConverterFilterDesigner.setCoefficientsWordLength(pCascadeFilter,pBypassStage3,WL1b,WL2b);
                        isDone2 = dsp.internal.DownConverterFilterDesigner.privIsSpecMet(MinimumOrderDesign,PassbandRipple, StopbandAttenuation, ...
                            pBypassStage3, SampleRate, pFCICNulls, pFstopStage2, pFstopStage3, pNumMagRespMeasPoints, ...
                            pCascadeFilter, pCascadeFilterStopbandFrequency, pActualPassbandRipple, ...
                            pActualStopbandAttenuation,pPassbandFrequency);
                        idx = idx - 1;
                    end
                end
                numIters = numIters + 1;
            end
            if ~isDone1
                coder.internal.warning('dsp:system:DigitalDownConverter:noConvergenceWLCoeff');
            end
        end
        %------------------------------------------------------------------------
        function flag = thisIsSpecMet(magResp,FVect,cascadeGain,...
                pCascadeFilterStopbandFrequency, MinimumOrderDesign, pActualPassbandRipple,...
                pActualStopbandAttenuation, pPassbandFrequency)
            % Returns true if the ripple and stopband attenuation specifications of
            % the filter response have been met.
            % FVect(end) must be larger than pCascadeFilterStopbandFrequency
            
            [flag1, flag2] = dsp.internal.DownConverterFilterDesigner.isRippleSpecMet(magResp,FVect,cascadeGain,MinimumOrderDesign, pActualPassbandRipple, pPassbandFrequency);
            interval = [pCascadeFilterStopbandFrequency FVect(end)];
            flag3 = dsp.internal.DownConverterFilterDesigner.isStopbandAttenuationSpecMet(magResp,FVect,cascadeGain, interval, ...
                pActualStopbandAttenuation);
            flag = flag1 & flag2 & flag3;
        end
        %------------------------------------------------------------------------
        function [equirippleFlag, rippleFlag]= isRippleSpecMet(magResp,FVect,cascadeGain, ...
                MinimumOrderDesign, pActualPassbandRipple, pPassbandFrequency)
            % Returns true if the passband ripple specification is met
            
            [equiRipple, ripple] = dsp.internal.DownConverterFilterDesigner.measurePassbandRipple(magResp,FVect,cascadeGain, ...
                pPassbandFrequency);
            
            if MinimumOrderDesign
                flag1 = equiRipple(1) <= pActualPassbandRipple/2;
                flag2 = (equiRipple(2) <= pActualPassbandRipple/2) && ...
                    (equiRipple(2) >=0);
                equirippleFlag = flag1 & flag2;
            else
                equirippleFlag = true;
            end
            
            rippleFlag = (ripple <= pActualPassbandRipple);
        end
        
        %------------------------------------------------------------------------
        function flag = isStopbandAttenuationSpecMet(magResp,FVect,cascadeGain,interval, ...
                pActualStopbandAttenuation)
            % Returns true if the stopband attenuation specification is met in the
            % specified frequency interval.
            attenunation = dsp.internal.DownConverterFilterDesigner.measureAttenuation(magResp,FVect,cascadeGain,interval);
            if isempty(attenunation)
                % No measurement points available since band of interest is smaller
                % than measurement resolution or has a width of 0 Hz (if interval(1)
                % equals interval(2))
                flag = true;
            else
                flag = attenunation >= pActualStopbandAttenuation;
            end
        end
        
        %------------------------------------------------------------------------
        function [pCICFilter, NumCICSections,CICGain] = designMinOrderCICDecimationFilter(...
                Arithmetic, pM1, pPassbandFrequency,StopbandAttenuation, pFsStage1)
            % Design a minimum order CIC decimation response and implement it as an
            % FIR filter when Arithmetic is 'double' or 'single', or as a CIC
            % filter when Arithmetic is 'fixed'. Output the number of CIC sections
            % and the gain of the CIC filter.
            
            if ~strcmpi(Arithmetic, 'fixed')
                % Suppress MFILT deprecation warnings
                w = warning('off', 'dsp:mfilt:mfilt:Obsolete');
                restoreWarn = onCleanup(@() warning(w));
                
                [coeffs,NumCICSections] = dsp.internal.ConverterFilterDesignerBase.getMinOrderCICFIRCoefficients(...
                    pM1, pFsStage1, pPassbandFrequency, StopbandAttenuation);
                pCICFilter = mfilt.firdecim(pM1,coeffs);%#ok
            else
                % Suppress MFILT deprecation warning on calling design
                % method on an fdesign object without "SystemObject" flag
                % set to true.
                w = warning('off', 'dsp:fdesign:basecatalog:UseSystemObjectForMultirateDesigns');
                restoreWarn = onCleanup(@() warning(w));
                
                d = fdesign.decimator(pM1,'cic',1,'fp,ast',...
                    pPassbandFrequency,StopbandAttenuation,pFsStage1);
                pCICFilter = design(d);
                NumCICSections = pCICFilter.NumberOfSections;
            end
            CICGain = pM1^(NumCICSections);
        end
        
        %-------------------------------------------------------------------------
        function [pCICFilter,CICGain] = designSectionsCICDecimationFilter(...
                Arithmetic, NumCICSections, pM1)
            % Design a CIC decimation response and implement it as an FIR filter
            % when Arithmetic is 'double' or 'single', or as a CIC filter when
            % Arithmetic is 'fixed'. Output the gain of the CIC filter.
            
            % Suppress MFILT deprecation warnings
            w = warning('off', 'dsp:mfilt:mfilt:Obsolete');
            restoreWarn = onCleanup(@() warning(w));
            
            if ~strcmpi(Arithmetic, 'fixed')
                coeffs = dsp.internal.ConverterFilterDesignerBase.getCICFIRCoefficients(NumCICSections,pM1);
                pCICFilter = mfilt.firdecim(pM1,coeffs);%#ok
            else
                pCICFilter = mfilt.cicdecim(pM1,1,NumCICSections);%#ok
            end
            CICGain = pM1^(NumCICSections);
        end
        %------------------------------------------------------------------
        function fixedPointProperties = getCICFixedPointProperties(NumCICSections, pM1, ...
                inputDataType)
            % Design a mfilt CIC and return its fixed-point properties
            
            % Suppress MFILT deprecation warnings
            w = warning('off', 'dsp:mfilt:mfilt:Obsolete');
            restoreWarn = onCleanup(@() warning(w));
            
            h = mfilt.cicdecim;%#ok
            h.DecimationFactor = pM1;
            h.NumberOfSections = NumCICSections;
            h.InputWordLength = inputDataType.WordLength;
            h.InputFracLength = inputDataType.FractionLength;
            fixedPointProperties.SectionWordLengths = h.SectionWordLengths;
            fixedPointProperties.SectionFracLengths = h.SectionFracLengths;
            fixedPointProperties.OutputWordLength = h.OutputWordLength;
            fixedPointProperties.OutputFracLength = h.OutputFracLength;
        end
        %------------------------------------------------------------------
        function fixedPointProperties = getFixedPointPropertiesCoefficients(...
                filterInputDataType, pBypassStage3, ...
                pM3, pM2, coeffs3, coeffs2, CoefficientsStage3DataType, CoefficientsStage2DataType)
            % Design mfilt filters and return their fixed-point properties
            
            % Suppress MFILT deprecation warnings
            w = warning('off', 'dsp:mfilt:mfilt:Obsolete');
            restoreWarn = onCleanup(@() warning(w));
            
            if ~pBypassStage3
                m1 = mfilt.firdecim;%#ok
                m1.DecimationFactor = pM3;
                m1.Numerator = coeffs3;
                m1.Arithmetic = 'fixed';
                m1.CoeffAutoScale = false;
                m1.CoeffWordLength = CoefficientsStage3DataType.WordLength;
                m1.NumFracLength = CoefficientsStage3DataType.FractionLength;
                m1.InputWordLength = filterInputDataType.WordLength;
                m1.InputFracLength = filterInputDataType.FractionLength;
                
                m2 = mfilt.firdecim;%#ok
                m2.DecimationFactor = pM2;
                m2.Numerator = coeffs2;
                m2.Arithmetic = 'fixed';
                m2.CoeffAutoScale = false;
                m2.CoeffWordLength = CoefficientsStage2DataType.WordLength;
                m2.NumFracLength = CoefficientsStage2DataType.FractionLength;
                m2.InputWordLength = filterInputDataType.WordLength;
                m2.InputFracLength = filterInputDataType.FractionLength;
                
                fixedPointProperties.Stage3ProductWordLength = m1.ProductWordLength;
                fixedPointProperties.Stage3ProductFracLength = m1.ProductFracLength;
                fixedPointProperties.Stage3AccumWordLength = m1.AccumWordLength;
                fixedPointProperties.Stage3AccumFracLength = m1.AccumFracLength;
            else
                m2 = mfilt.firdecim;%#ok
                m2.DecimationFactor = pM2;
                m2.Numerator = coeffs2;
                m2.Arithmetic = 'fixed';
                m2.CoeffAutoScale = false;
                m2.CoeffWordLength = CoefficientsStage2DataType.WordLength;
                m2.NumFracLength = CoefficientsStage2DataType.FractionLength;
                m2.InputWordLength = filterInputDataType.WordLength;
                m2.InputFracLength = filterInputDataType.FractionLength;
            end
            
            fixedPointProperties.CICCompProductWordLength = m1.ProductWordLength;
            fixedPointProperties.CICCompProductFracLength = m1.ProductFracLength;
            fixedPointProperties.CICCompAccumWordLength = m1.AccumWordLength;
            fixedPointProperties.CICCompAccumFracLength = m1.AccumFracLength;
        end
    end
    
    methods (Hidden)
        function [filt, figureProps] = getFvtoolParametersForVFS(obj)
            % Get filters and figure properties for the plot of
            % visualizeFilterStages method
            
            CICNorm = cascade(obj.pCICFilter, obj.pGainFilter);
            
            if length(obj.pFCICNulls)>1
                fLimit = obj.pFCICNulls(2);
            else
                fLimit = obj.pFCICNulls(end);
            end
            
            if obj.pBypassStage3
                filt = {CICNorm, obj.pCICCompFilter,obj.pCascadeFilter};
                figureProps = {'FrequencyRange','Specify freq. vector', ...
                    'FrequencyVector',linspace(0,fLimit,2048),'Fs',...
                    [obj.SampleRate, obj.pFsStage2,obj.SampleRate], ...
                    'ShowReference','on','Color','White'};
            else
                filt = {CICNorm, obj.pCICCompFilter,obj.pStage3Filter,obj.pCascadeFilter};
                figureProps = {'FrequencyRange','Specify freq. vector', ...
                    'FrequencyVector',linspace(0,fLimit,2048),'Fs',...
                    [obj.SampleRate, obj.pFsStage2, ...
                    obj.pFsStage3,obj.SampleRate], ...
                    'ShowReference','on','Color','White'};
            end
        end
        
        function legendCell = getLegendStringForVFS(obj)
            % Get legend for the plot of visualizeFilterStages method
            
            st1 = ['CIC decimator, Decimation factor = ',num2str(obj.pM1)];
            st2 = ['CIC compensator, Decimation factor = ',num2str(obj.pM2)];
            st4 = 'Cascade response';
            
            if obj.pBypassStage3
                legendCell = {st1, st2, st4};
            else
                    if strcmpi(obj.pFilterTypeStage3,'halfband')
                        st3 = ['Halfband decimator, Decimation factor = ',num2str(obj.pM3)];
                    else
                        st3 = ['Lowpass decimator, Decimation factor = ',num2str(obj.pM3)];
                    end
                legendCell = {st1, st2, st3, st4};
            end
        end
    end
end
