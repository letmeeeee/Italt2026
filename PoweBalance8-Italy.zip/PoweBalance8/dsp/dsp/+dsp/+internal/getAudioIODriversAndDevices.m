function out = getAudioIODriversAndDevices(command,varargin)
%GETAUDIOIODRIVERSANDDEVICES Get information of audio drivers and devices
%   OUT = dsp.internal.getAudioIODriversAndDevices('drivers') returns audio
%   drivers supported on current platform.
%
%   OUT = dsp.internal.getAudioIODriversAndDevices('allDrivers') returns
%   audio drivers supported, irrespective of platform.
%
%   OUT = dsp.internal.getAudioIODriversAndDevices('inputDevices', DRIVER)
%   returns a cell array of input audio device names that are available to
%   be used with DRIVER.
%
%   OUT = dsp.internal.getAudioIODriversAndDevices('outputDevices', DRIVER)
%   returns a cell array of output audio device names that are available to
%   be used with DRIVER.
%   
%   OUT = dsp.internal.getAudioIODriversAndDevices('driverIndex', DRIVER)
%   returns the index for a particular driver. This index is used to
%   identify the driver by audio API.
%
%   OUT = dsp.internal.getAudioIODriversAndDevices('defaultDriver') returns
%   the default driver for current platform.
%
%   OUT = dsp.internal.getAudioIODriversAndDevices('defaultInputDevice')
%   returns the default input audio device for default driver on current
%   platform.
%
%   OUT = dsp.internal.getAudioIODriversAndDevices('defaultOutputDevice')
%   returns the default output audio device for default driver on current
%   platform.
%
%   This function is used by audioDeviceReader and audioDeviceWriter System
%   objects, and Audio Device Reader and Audio Device Writer blocks.

%   Copyright 2015-2020 The MathWorks, Inc.

narginchk(1,2);
switch command
    case 'drivers'
        out = getDrivers;
    case 'allDrivers'
        out = getAllDrivers;
    case 'inputDevices'
        out = getInputDevices(varargin{1});
    case 'outputDevices'
        out = getOutputDevices(varargin{1});
    case 'fullDuplexDevices'
        out = getFullDuplexDevices();
    case 'driverIndex'
        out = getIndexForDriver(varargin{1});
    case 'defaultDriver'
        out = getDefaultDriver;
    case 'fullDuplexDriver'
        out = getFullDuplexDriver;
    case 'defaultInputDevice'
        out = getDefaultInputDevice;
    case 'defaultOutputDevice'
        out = getDefaultOutputDevice;
    case 'defaultFullDuplexDevice'
        out = getDefaultFullDuplexDevice;
    case 'defaultFullDuplexDeviceName'
        out = getDefaultFullDuplexDeviceName;
end
end

function s = getDrivers
if ispc
    s = {'DirectSound', 'ASIO', 'WASAPI'};
elseif ismac
    s = {'CoreAudio'};
else
    s = {'ALSA'};
end
end

function s = getFullDuplexDriver
if ispc
    s = {'ASIO'};
elseif ismac
    s = {'CoreAudio'};
else
    s = {'ALSA'};
end
end

function s = getAllDrivers
    s = {'DirectSound', 'ASIO','WASAPI','CoreAudio','ALSA'};
end

function driverIdx = getIndexForDriver(driverStr)
if strcmp(driverStr, 'Default')
    drivers = getDrivers();
    driverStr = drivers{2};
end
switch driverStr
    case 'DirectSound'
        driverIdx = 1;
    case 'ASIO'
        driverIdx = 3;
    case 'CoreAudio'
        driverIdx = 5;
    case 'ALSA'
        driverIdx = 8;
    case 'WASAPI'
        driverIdx = 13;
end
end

function s = getDefaultDriver
s = getDrivers;
s = s{1};
end

function dev = getDefaultInputDevice
defaultDriver = getDefaultDriver();
list = getInputDevices(defaultDriver);
dev = list{1};
end

function dev = getDefaultOutputDevice
defaultDriver = getDefaultDriver();
list = getOutputDevices(defaultDriver);
dev = list{1};
end

function dev = getDefaultFullDuplexDevice
devCell = getFullDuplexDevices();
dev = devCell{1};
end

function dev = getDefaultFullDuplexDeviceName
devCell = getFullDuplexDevices();
if length(devCell)>1
    % There is a valid full duplex device
    driver = getFullDuplexDriver();
    driverIdx = dsp.internal.getAudioIODriversAndDevices('driverIndex', driver{1});
    outDevInfoAll = dspAudioDeviceInfo('defaultOutput',driverIdx);
    outDevName = regexprep(outDevInfoAll.name, ' \([^\(]*\)$', '');
    if strcmpi(outDevName, 'Default') && isunix
        % Sometimes a device named 'default' is listed on Linux. In
        % that case, it is renamed to ASLAdefault.
        outDevName = 'ALSAdefault';
    end
    if ismember(outDevName, devCell)
        % If the default output device is a full-duplex one, use that as
        % the default for audioPlayerRecorder also
        dev = outDevName;
    else
        dev = devCell{2};
    end
else
    dev = devCell{1};
end
end

function devCell = getInputDevices(driver)
driverIdx = getIndexForDriver(driver);
inDevs = dspAudioDeviceInfo('inputsForApi',driverIdx);
if isempty(inDevs)
    devCell = {getString(message('dsp:audioDeviceIO:noInputDevice'))};
else
    devCell{1}= 'Default';
    for i=1:length(inDevs)
        temp = regexprep(inDevs(i).name, ' \([^\(]*\)$', '');
        if strcmpi(temp, 'Default') && isunix
            % Sometimes a device named 'default' is listed on Linux. In
            % that case, it is renamed to ASLAdefault.
            temp = 'ALSAdefault';
        end
        devCell{end+1} = temp;  %#ok
    end
end
end

function devCell = getOutputDevices(driver)
driverIdx = getIndexForDriver(driver);
outDevs = dspAudioDeviceInfo('outputsForApi',driverIdx);
if isempty(outDevs)
    devCell = {getString(message('dsp:audioDeviceIO:noOutputDevice'))};
else
    devCell{1}= 'Default';
    for i=1:length(outDevs)
        temp = regexprep(outDevs(i).name, ' \([^\(]*\)$', '');
        if strcmpi(temp, 'Default') && isunix
            % Sometimes a device named 'default' is listed on Linux. In
            % that case, it is renamed to ASLAdefault.
            temp = 'ALSAdefault';
        end
        devCell{end+1} = temp;  %#ok
    end
end
end

function devCell = getFullDuplexDevices
driver = getFullDuplexDriver();
driverIdx = getIndexForDriver(driver{1});
outDevs = dspAudioDeviceInfo('outputsForApi',driverIdx);
validDevs = arrayfun(@(x) x.maxInputs>0 && x.maxOutputs > 0, outDevs);
outDevs = outDevs(validDevs);
if isempty(outDevs)
    devCell = {getString(message('audio:audioPlayerRecorder:noDevice'))};
else
    devCell{1}= 'Default';
    for i=1:length(outDevs)
        temp = regexprep(outDevs(i).name, ' \([^\(]*\)$', '');
        if strcmpi(temp, 'Default') && isunix
            % Sometimes a device named 'default' is listed on Linux. In
            % that case, it is renamed to ASLAdefault.
            temp = 'ALSAdefault';
        end
        devCell{end+1} = temp;  %#ok
    end
end
end