classdef AllpassMinMult
    %ALLPASSMINMULT - design and filtering functions for minimum mult structs

    %   Copyright 2015-2020 The MathWorks, Inc.
    
    %#codegen
    methods (Static)
        
        function [y, Z] = stepMinMultCascade(u, Z, branchInfo, branchCoef)
            coder.internal.prefer_const(branchInfo); % pull in available constant for branchInfo
            CF = branchCoef.FirstOrderSectionCoeffs;
            CS = branchCoef.SecondOrderSectionCoeffs;
            numFOS = branchInfo.NumFOS;
            numSOS = branchInfo.NumSOS;
            hasSOS = numSOS ~= 0;
            
            %Second order sections
            if hasSOS
                [ysos,Z] =dsp.internal.AllpassMinMult.stepSecondOrderSections(u,CS, Z, numSOS);
            else
                ysos = u;
            end
            %Trailing First order sections
            if numFOS > 0
                [y,Z] = dsp.internal.AllpassMinMult.stepFirstOrderSections(ysos, CF, ...
                    Z, numFOS, numSOS, hasSOS);
            else
                y = ysos;
            end
        end
        
        function [y, Z] = stepSecondOrderSections(u,coe, Z, numSOS)
            idx     = 1:numSOS;
            c       = coe(idx,:);
            zTop    = Z(1:2, :, idx);
            zBottom = Z(3:4, :, idx);
            
            [y,zTop,zBottom] = dsp.internal.AllpassMinMult.stepMultipleSections(c,u,zTop,zBottom,false);
            
            Z(1:2, :, idx) = zTop;
            Z(3:4, :, idx) = zBottom;
        end
        
        function [y, Z] = stepFirstOrderSections(u, coe, Z, numFOS, zoffset, followsSOS)
            %Implements a cascade of 1st order sections.
            %'zoffset' is the ending index of the preceding SOS into the
            %state matrix.
            if followsSOS
                zbotidx = 3;
            else
                zbotidx = 2;
            end
            idx     = cast(1:numFOS,class(zoffset));
            zTop    = Z(1, :, zoffset+idx);
            zBottom = Z(zbotidx, :, zoffset+idx);
            
            [y, zTop,zBottom] = dsp.internal.AllpassMinMult.stepMultipleSections(real(coe),u,zTop,zBottom,false);
            
            Z(1, :, zoffset+idx)       = zTop;
            Z(zbotidx, :, zoffset+idx) = zBottom;
        end
        
        %-------------------------------------------------------------------
        % Multiple-Section Allpass Minimum Multiplier
        %-------------------------------------------------------------------
        function [x,zTop,zBottom] = stepMultipleSections(coefs, x, zTop, zBottom,isLastCoefficientFirstOrder)
            % Sim ---------------------------------------------------------
            if isempty(coder.target)
                if ~isreal(x)
                    zTop    = complex(zTop);
                    zBottom = complex(zBottom);
                end
                [x,zTop,zBottom] = dsp.internal.builtins.allpassfilt(coefs.',x,zTop,zBottom,isLastCoefficientFirstOrder);
            else
                % Codegen -----------------------------------------------------
                nChan     = size(x,2);
                nSections = size(zTop,3);
                nCoefs    = size(coefs,2); % Coefficients per section
                
                for kS = 1:nSections
                    c = coefs(kS,1:nCoefs);
                    
                    if  (kS == nSections) && isLastCoefficientFirstOrder
                        % Separate current section of top and bottom states
                        zT = zTop(1   , 1:nChan, kS);
                        zB = zBottom(1, 1:nChan, kS);
                        
                        [x, zT, zB] = dsp.internal.AllpassMinMult.dsp_allpassfiltCG(c(1), x, zT, zB);
                        
                        % Update states
                        zTop(1   , 1:nChan, kS) = zT;
                        zBottom(1, 1:nChan, kS) = zB;
                    else
                        % Separate current section of top and bottom states
                        zT = zTop(1:nCoefs   , 1:nChan, kS);
                        zB = zBottom(1:nCoefs, 1:nChan, kS);
                        
                        [x, zT, zB] = dsp.internal.AllpassMinMult.dsp_allpassfiltCG(c, x, zT, zB);
                        
                        % Update states
                        zTop(1:nCoefs   , 1:nChan, kS) = zT;
                        zBottom(1:nCoefs, 1:nChan, kS) = zB;
                    end
                end
            end
        end
        
        %-------------------------------------------------------------------
        % Single-Section Allpass Minimum Multiplier
        %-------------------------------------------------------------------
        function [u, ZT, ZB] = dsp_allpassfiltCG(c, u, ZT, ZB)
            % Codegen
            Nchan = size(u,2);
            % Loop through time
            for t = 1:size(u, 1)
                % Isolate final top state across all channels
                z0 = ZT(end, 1:Nchan);
                ZT(2:end, 1:Nchan) = ZT(1:end-1, 1:Nchan);
                ZT(1, 1:Nchan) = u(t, 1:Nchan);
                
                % Top minus bottom states across all channels
                zdelta = ZT(end:-1:1, 1:Nchan) - ZB;
                
                % Compute output (re-use temp input)
                % Note: Coefficients size is [Order, 1]
                u(t, 1:Nchan) = z0 + c * zdelta;
                
                % Update states
                ZB(2:end, 1:Nchan) = ZB(1:end-1, 1:Nchan);
                ZB(1, 1:Nchan) = u(t, 1:Nchan);
            end
        end
        
        
        function [filterInfo, filterCoef] = makeAllpassSpec(coef, dType, hasTrailing1st, isDelay)
            %coef - AllpassCoefficients. Coefficients in Min Mult form.
            %dType - datatype of input to cast coefs to.
            %hasTrailing1st -  filter has a trailing 1st order section. So
            %   ignore coef(end,2) if coef is nx2.
            %isDelay - the branch is a pure delay. Make an "empty" struct
            
            
            if isDelay %filter is just a delay
                filterInfo = struct('NumFOS', uint32(0), ...
                    'NumSOS', uint32(0),...
                    'MaxOrder', uint32(0),...
                    'WDFTypeFOS', [], ...
                    'WDFTypeSOS', []);
                
                filterCoef = struct(...
                    'FirstOrderSectionCoeffs', [],...
                    'SecondOrderSectionCoeffs', []);
            else
                coef = cast(coef, dType);
                [r,c] = coder.const(@size, coef);
                
                if c == 1 %first order sections
                    filterInfo= struct('NumFOS', uint32(r), ...
                        'NumSOS', uint32(0),...
                        'MaxOrder', uint32(1),...
                        'WDFTypeFOS', [], ...
                        'WDFTypeSOS', []);
                    
                    filterCoef = struct(...
                        'FirstOrderSectionCoeffs', coef,...
                        'SecondOrderSectionCoeffs', []);
                    
                else %second order
                    if hasTrailing1st
                        fosCoe = coef(r,1);
                        r = r - 1;
                        nfos = 1;
                    else
                        fosCoe = [];
                        nfos = 0;
                    end
                    filterInfo = struct('NumFOS', uint32(coder.const(nfos)), ...
                        'NumSOS', uint32(r),...
                        'MaxOrder', uint32(2),...
                        'WDFTypeFOS', [], ...
                        'WDFTypeSOS', []);
                    
                    filterCoef = struct(...
                        'FirstOrderSectionCoeffs', fosCoe,...
                        'SecondOrderSectionCoeffs', coef(1:r,:));
                end
                
            end
        end
    end
    
end
