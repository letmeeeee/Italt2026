classdef AbstractSlidingWindowStatistic < matlab.System
% AbstractSlidingWindowStatistic this abstract class is used in the
% moving statistics objects.
    
%   Copyright 2016-2021 The MathWorks, Inc.

%#codegen
    
    properties (Nontunable)
        % WindowLength Length of the sliding window
        WindowLength (1, 1) {mustBePositive, mustBeInteger} = 4;
    
        % NumChans Number of input channels
        NumChans;
    end
    
    properties(Access = protected)
        % pbuffer Holds previous WindowLength-1 samples of each input
        % channel
        pBuffer;
    end
      
    properties (Abstract, Nontunable, Access = protected)
       % InitialBufferValue Initial value in buffer
       InitialBufferValue 
    end
    
    methods (Access = protected, Abstract)
        % Concrete moving statistics objects must define this method
        y = computeStatistic(obj,x);
    end
    
    methods
        function obj = AbstractSlidingWindowStatistic(varargin)
            % Constructor
            setProperties(obj,nargin,varargin{:});
        end
    end
    
    methods(Access = protected)
        
        function validateInputsImpl(obj,u)
            if obj.NumChans ~= -1 && size(u,2) ~= 0
                coder.internal.errorIf(size(u,2) ~= obj.NumChans, ['dsp:system',...
                    ':Shared:numChannels']);
            end
        end 
        
        function setupImpl(obj,u)
            % Setup the buffer
            obj.pBuffer = zeros(obj.WindowLength - 1,obj.NumChans,'like',u);
        end
        
        function y = stepImpl(obj,u)
            x = [obj.pBuffer;u];
            y = obj.computeStatistic(x);
            obj.pBuffer = x(end-obj.WindowLength + 2:end,:);
        end
        
        function resetImpl(obj)
            % Reset buffer
            obj.pBuffer = cast(obj.InitialBufferValue,class(obj.pBuffer)) * ones(size(obj.pBuffer),'like',obj.pBuffer);
        end
        
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            if isLocked(obj)
                s.pBuffer            = obj.pBuffer;
                s.InitialBufferValue = obj.InitialBufferValue;
            end
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                obj.pBuffer = s.pBuffer;
                obj.InitialBufferValue = s.InitialBufferValue;
            end
            loadObjectImpl@matlab.System(obj, s, wasLocked);
        end
        
    end
end
