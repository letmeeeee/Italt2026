classdef TunableBandpassBandstopIIRFilter < dsp.internal.AbstractTunableIIRFilter
% TunableBandpassBandstopIIRFilter

%   Copyright 2022-2023 The MathWorks, Inc.

%#codegen
    properties
        %F3dB1 First 3-dB cutoff frequency
        %   Specify the normalized frequency of the 3 dB point below the
        %   passband value for the first cutoff. The default is 0.25. This
        %   property is tunable.
        F3dB1 = 0.25;
        %F3dB2 Second 3-dB cutoff frequency
        %   Specify the normalized frequency of the 3 dB point below the
        %   passband value for the second cutoff. The default is 0.75. This
        %   property is tunable.
        F3dB2 = 0.75;
    end

    properties(Nontunable)
        %CascadeSectionsForm Filter cascade sections form
        %   Specify the filter cascade sections form as one of
        %   ["Fourth-order sections" | "Second-order sections"]. The
        %   default is "Fourth-order sections".
        CascadeSectionsForm (1, :) char {matlab.system.mustBeMemberMessageID(CascadeSectionsForm, ...
            {'dsp:system:TunableIIRFilter:CascadeSectionsForm_Fourthordersections'; ...
            'dsp:system:TunableIIRFilter:CascadeSectionsForm_Secondordersections'})} = 'Fourth-order sections';
    end

    properties(Access=protected, Nontunable)
        pIsUsingSOS(1, 1) logical = false;
    end

    methods
        %------------------------------------------------------------------
        function set.F3dB1(this, value)
            validateF3dB1(this, value, false);
            this.F3dB1 = value;
        end
        %------------------------------------------------------------------
        function set.F3dB2(this, value)
            validateF3dB2(this, value, false);
            this.F3dB2 = value;
        end
    end

    methods(Access = protected)
        %------------------------------------------------------------------
        function setupImpl(this)
            % Perform one-time calculations, such as computing constants
            this.pIsUsingSOS = strcmpi(this.CascadeSectionsForm, 'Second-order sections');
            setupImpl@dsp.internal.AbstractTunableIIRFilter(this);
        end
        %------------------------------------------------------------------     
        function s = saveObjectImpl(this)
            % Set properties in structure s to values in object obj
            % Set public properties and states
            s = saveObjectImpl@dsp.internal.AbstractTunableIIRFilter(this);
            s.pIsUsingSOS = this.pIsUsingSOS;
        end
        %------------------------------------------------------------------
        function loadObjectImpl(this,s,wasLocked)
            % Set properties in object obj to values in structure s
            % Set public properties and states
            loadObjectImpl@dsp.internal.AbstractTunableIIRFilter(this,s,wasLocked);
            if wasLocked
                this.pIsUsingSOS = s.pIsUsingSOS;
            end
        end
        %------------------------------------------------------------------
        function flag = isInactivePropertyImpl(this, prop)
            flag = isInactivePropertyImpl@dsp.internal.AbstractTunableIIRFilter(this, prop);
            switch prop
                case 'HasScaleValues'
                    flag = strcmpi(this.CascadeSectionsForm, 'Fourth-order sections');
            end
        end
        %------------------------------------------------------------------
        function crossValidateProperties(this)
            crossValidateProperties@dsp.internal.AbstractTunableIIRFilter(this);
            validateF3dB1(this, this.F3dB1, true);
            validateF3dB2(this, this.F3dB2, true);
        end
        %------------------------------------------------------------------
        function validateFilterOrder(this, value, compareWithMax)    
            if compareWithMax
                validateattributes(value, {'numeric'}, {'finite','real','scalar','integer','nonnegative','even','<=',this.MaxOrder}, 'set.FilterOrder', 'FilterOrder');
            else
                validateattributes(value, {'numeric'}, {'finite','real','scalar','integer','nonnegative','even'}, 'set.FilterOrder', 'FilterOrder');
            end
        end
        %------------------------------------------------------------------
        function validateMaxOrder(~, value)
            validateattributes(value, {'numeric'}, {'finite','real','scalar','integer','positive','even'}, 'set.MaxOrder','MaxOrder');
        end
        %------------------------------------------------------------------
        function validateF3dB1(this, value, compareWithMax, varargin)
            allowZero = false;
            if numel(varargin) > 0
                allowZero = varargin{1};
            end
            if allowZero
                if compareWithMax && this.F3dB2 > 0
                    validateattributes(value, {'double','single'}, {'real','scalar','nonnegative','finite','<',this.F3dB2,'<=', 1}, 'set.F3dB1','F3dB1');
                else
                    validateattributes(value, {'double','single'}, {'real','scalar','nonnegative','finite','<=', 1}, 'set.F3dB1','F3dB1');
                end
            else
                if compareWithMax && this.F3dB2 > 0
                    validateattributes(value, {'double','single'}, {'real','scalar','positive','finite', '<',this.F3dB2,'<=', 1}, 'set.F3dB1','F3dB1');
                else
                    validateattributes(value, {'double','single'}, {'real','scalar','positive','finite', '<=', 1}, 'set.F3dB1','F3dB1');
                end
            end
        end
        %------------------------------------------------------------------
        function validateF3dB2(this, value, compareWithMin, varargin)
            allowZero = false;
            if numel(varargin) > 0
                allowZero = varargin{1};
            end
            if allowZero
                if compareWithMin && this.F3dB2 > 0
                    validateattributes(value, {'double','single'}, {'real','scalar','nonnegative','finite','<=', 1,'>',this.F3dB1}, 'set.F3dB2','F3dB2');
                else
                    validateattributes(value, {'double','single'}, {'real','scalar','nonnegative','finite','<=', 1}, 'set.F3dB2','F3dB2');
                end
            else
                if compareWithMin && this.F3dB2 > 0
                    validateattributes(value, {'double','single'}, {'real','scalar','positive','finite','<=', 1,'>',this.F3dB1}, 'set.F3dB2','F3dB2');
                else
                    validateattributes(value, {'double','single'}, {'real','scalar','positive','finite', '<=', 1}, 'set.F3dB2','F3dB2');
                end
            end
        end
        %------------------------------------------------------------------
        function dims = getCoefficientsDimensions(this)
            N = this.MaxOrder;
            sectionOrder = 3;
            isUsingSOS = strcmpi(this.CascadeSectionsForm, 'Second-order sections');
            if ~isUsingSOS
                sectionOrder = 5;
                N = N / 2;
            end
            r = rem(N,2); 
            K = (N - r) / 2;
            L = K + r;
            dims = [L sectionOrder];
        end
        %------------------------------------------------------------------
        function flag = isDesignFilterAllowed(this)
            flag = isDesignFilterAllowed@dsp.internal.AbstractTunableIIRFilter(this);
            flag = flag && this.F3dB1 >= 0 && this.F3dB2 >= 0;
        end
        %------------------------------------------------------------------
        function flag = isScaleValueAllowed(this)
            flag = this.HasScaleValues && strcmpi(this.CascadeSectionsForm, 'Second-order sections');
        end
    end
end
