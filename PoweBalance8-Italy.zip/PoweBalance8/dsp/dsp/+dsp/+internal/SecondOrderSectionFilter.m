classdef SecondOrderSectionFilter  < matlab.System  & dsp.internal.FilterAnalysis
%SECONDORDERSECTIONFILTER Implements filter formed of cascade of second
%order sections. 

%   Copyright 2013-2020 The MathWorks, Inc.

%#codegen
%#ok<*EMCLS>
properties (Dependent)
  % Numerator Numerator coefficients of size Lx3, where L is the
  % number of sections.
  Numerator
  % Denominator Denominator coefficients of size Lx2, where L is
  % the number of sections. The first coefficient is always unity.
  Denominator
end

properties (Access = private)
  % pBiquad Handle to dsp.BiquadFilter object
  pBiquad;
  % pNumerator Reshaped numerator coefficients 
  pNumerator = [1 .1 .2];
  % pDenominator Reshaped denominator coefficients 
  pDenominator  = [1 .1];
  % untransformed coefficients
  pNumeratorRaw;
  pDenominatorRaw;
end
%--------------------------------------------------------------------------
% Public methods
%--------------------------------------------------------------------------
methods
  function obj = SecondOrderSectionFilter(varargin)
    % Constructor
    setProperties(obj, nargin, varargin{:});
  end
  %------------------------------------------------------------------------
  function set.Denominator(obj,val)
    % strip off leading unity coefficient
    obj.pDenominator = val(:,2:3).';
    obj.pDenominatorRaw = val;
  end
  %------------------------------------------------------------------------
  function denum = get.Denominator(obj)
    denum = obj.pDenominator;
  end
  %------------------------------------------------------------------------
  function set.Numerator(obj,val)
    obj.pNumerator =val.';
    obj.pNumeratorRaw = val;
  end
  %------------------------------------------------------------------------
  function num = get.Numerator(obj)
    num = obj.pNumerator;
  end

 %------------------------------------------------------------------------
 function [n,d] = getRawCoefficients(obj)
     n = obj.pNumeratorRaw;
     d = obj.pDenominatorRaw;
 end
end
%--------------------------------------------------------------------------
% Public methods
%--------------------------------------------------------------------------  
methods (Access = protected) 
  function setupImpl(obj, ~)
    % Setup Biquad Filter
        obj.pBiquad = dsp.BiquadFilter('SOSMatrixSource','Input port',...
                                   'ScaleValuesInputPort',false);
  end
  %------------------------------------------------------------------------
  function y = stepImpl(obj, x )
    % use dsp.BiquadFilter to perofrm filtering. Coefficients and
    % gains are tunable (specified from input port)
    y = step(obj.pBiquad,x,obj.pNumerator,obj.pDenominator); 
  end
  %------------------------------------------------------------------------
  function resetImpl(obj)
    % reset biquad filter
    reset(obj.pBiquad);
  end
  %------------------------------------------------------------------------  
  function releaseImpl(obj)
    % release biquad filter
    release(obj.pBiquad);
  end
  %------------------------------------------------------------------------
  function s = saveObjectImpl(obj)
    s = saveObjectImpl@matlab.System(obj);
    if isLocked(obj)
        s.pBiquad      = matlab.System.saveObject(obj.pBiquad);
        s.pNumerator   = obj.pNumerator;
        s.pDenominator = obj.pDenominator;
        s.pNumeratorRaw = obj.pNumeratorRaw;
        s.pDenominatorRaw = obj.pDenominatorRaw;
    end
  end
  %------------------------------------------------------------------------
  function loadObjectImpl(obj, s, wasLocked)
     
    if wasLocked
        obj.pBiquad      = matlab.System.loadObject(s.pBiquad);
        obj.pDenominator = s.pDenominator;
        if isfield(s,'pScaleValues')
           s.pNumerator =  s.pNumerator .* repmat(s.pScaleValues(1:end-1),3,1);
        end
        obj.pNumerator   = s.pNumerator;
        if isfield(s,'pNumeratorRaw')
           obj.pNumeratorRaw = s.pNumeratorRaw;
           obj.pDenominatorRaw = s.pDenominatorRaw; 
        end
    end
    loadObjectImpl@matlab.System(obj, s);
  end
  %------------------------------------------------------------------------
  function d = convertToDFILT(obj, arith)
    % Delegate to convertToDFILT method of equivalent dsp.BiquadFilter
    % object
    hbiquadfvtool = dsp.BiquadFilter;
    hbiquadfvtool.SOSMatrix = [obj.Numerator.',...
                               ones(size(obj.Numerator.',1),1),...
                               obj.Denominator.'];
    d = hbiquadfvtool.convertToDFILT(arith);
  end
end
%--------------------------------------------------------------------------
% Hidden methods
%--------------------------------------------------------------------------  
methods (Hidden)
  % Methods required for filter analysis functionality
  function restrictionsCell = getFixedPointRestrictions(~,~)
    restrictionsCell = {}; 
  end
  function props = getFixedPointProperties(~)
    props = {};
  end
  function props = getNonFixedPointProperties(obj)
    props = obj.getPropertyNames;
    idxtoprune = [];
    for k = 1:length(props)
        if(isInactiveProperty(obj, props{k}))
            idxtoprune = [idxtoprune, k]; %#ok
        end
    end
    props(idxtoprune) = [];
  end
  function flag = isPropertyActive(obj,prop)
    flag = ~isInactiveProperty(obj, prop);
  end
end
end