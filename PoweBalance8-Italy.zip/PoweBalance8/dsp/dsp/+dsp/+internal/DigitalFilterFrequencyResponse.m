classdef DigitalFilterFrequencyResponse < matlab.System
    %#codegen
    properties(Nontunable)
        NumFilters = 1;
        FilterType (1, :) char {matlab.system.mustBeMemberMessageID(FilterType, ...
                               {'dsp:system:DigitalFilterFrequencyResponse:FilterType_FIR',;...
                               'dsp:system:DigitalFilterFrequencyResponse:FilterType_IIR'})} = 'FIR';
    end

    properties
        NormalizedFrequency = 1;
        XScale = 1;
        FFTLength = 2048;
        SampleRate = 44100; 
    end

    properties(Dependent)
        FrequencyRange;
    end

    properties(Access=private)
        pFrequencyVector;
        pFrequencyResponse = [];
        pInputCache;
        pFrequencyRange = [0 22050];
        pNormalizedFrequencyRange = [0 1];
        pInputDataType = 'double';
    end

    properties(Access=protected, Nontunable)
        pIsIIR = false;
        pNumInputs = 1;
        pMaxFFTLength = int32(2^16);
    end

    methods
        %------------------------------------------------------------------
        % Constructor
        function this = DigitalFilterFrequencyResponse(varargin)
            % Support name-value pair arguments when constructing object
            setProperties(this,nargin,varargin{:})
        end
        %------------------------------------------------------------------
        function set.FrequencyRange(this, value)
            if this.NormalizedFrequency
                this.pNormalizedFrequencyRange = value;
            else
                this.pFrequencyRange = value;
            end
        end
        function range = get.FrequencyRange(this)
            if this.NormalizedFrequency
                range = this.pNormalizedFrequencyRange;
            else
                range = this.pFrequencyRange;
            end
        end
    end

    methods(Access = protected)
        %------------------------------------------------------------------
        function setupImpl(this, varargin)
            % Perform one-time calculations, such as computing constants
            this.pInputDataType = class(varargin{1});
            this.pIsIIR = strcmpi(this.FilterType, 'IIR');
            this.pNumInputs = (1 + this.pIsIIR) * this.NumFilters;
            this.pFrequencyVector = zeros(1, this.pMaxFFTLength);
            if isempty(coder.target)
                this.pInputCache = cell(1,this.pNumInputs);
                this.pInputCache(1,1:this.pNumInputs) = {1};
            end
        end
        %------------------------------------------------------------------
        function h = stepImpl(this, varargin)
            if isempty(coder.target)
                % Cache current inputs
                if ~isequal(varargin, this.pInputCache)
                    h = computeResponse(this, varargin);
                    this.pInputCache(1,1:this.pNumInputs) = varargin(1,1:this.pNumInputs);
                    this.pFrequencyResponse = h;
                else
                    if size(this.pFrequencyResponse,1) == this.FFTLength
                        h = this.pFrequencyResponse;
                    else
                        h = computeResponse(this, varargin);
                        this.pFrequencyResponse = h;
                    end
                end
            else
                h = computeResponse(this, varargin);
            end
        end
        %------------------------------------------------------------------
        function h = computeResponse(this, data)
            N = this.FFTLength;
            R = this.FrequencyRange;
            Fs = getSampleRate(this);
            assert(N <= this.pMaxFFTLength);
            if R(2) > Fs/2
                R(2) = Fs/2;
            end
            % Compute frequency vector
            if ~this.XScale
                if R(1) == 0 
                    R(1) = diff(R)/(N * Fs); 
                end
                this.pFrequencyVector(1,1:N) = logspace(log10(R(1)), log10(R(2)), N);
            else
                this.pFrequencyVector(1,1:N) = linspace(R(1), R(2), N);
            end
            % Compute frequency response
            h = complex(zeros(N, this.NumFilters),zeros(N, this.NumFilters));
            for idx = 1:this.NumFilters
                coeffIdx = (1 + this.pIsIIR) * (idx - 1) + 1;
                b = data{coeffIdx};
                a = 1;
                if this.pIsIIR
                    a = data{2 * idx};
                end
                h(1:N,idx) = dsp.internal.DigitalFilterFrequencyResponse.computefreqz(b,a,N,this.pFrequencyVector,getSampleRate(this));
            end
        end
        %------------------------------------------------------------------
        function releaseImpl(this)
            % this.pFrequencyResponse = [];
            % this.pFrequencyVector = [];
            if isempty(coder.target)
                this.pInputCache = {};
            end
        end
        %------------------------------------------------------------------
        function processTunedPropertiesImpl(~)
        end
        %------------------------------------------------------------------
        function validateInputsImpl(this,varargin)
            isIIR = strcmpi(this.FilterType, 'IIR');
            if isIIR
                numInputs = (1 + isIIR) * this.NumFilters;
                for idx = 1:2:numInputs
                    [numSectionsNum, orderNum] = size(varargin{idx});
                    if numSectionsNum > 1
                        coder.internal.errorIf(~(orderNum == 3 || orderNum == 5), 'dsp:system:DigitalFilterFrequencyResponse:InvalidIIRFilterCoeffs');
                        [~, orderDen] = size(varargin{idx + 1});
                        coder.internal.errorIf(orderNum ~= orderDen, 'dsp:system:DigitalFilterFrequencyResponse:InvalidIIRFilterOrder',idx,idx+1);
                    end
                end
            else
                for idx = 1:this.NumFilters
                    coder.internal.errorIf(~isvector(varargin{idx}), 'dsp:system:DigitalFilterFrequencyResponse:InvalidFIRFilterCoeffs');
                end
            end
        end
        %------------------------------------------------------------------
        function validatePropertiesImpl(~)
        end
        %------------------------------------------------------------------
        function s = saveObjectImpl(this)
            % Set properties in structure s to values in object obj
            % Set public properties and states
            s = saveObjectImpl@matlab.System(this);
            s.pFrequencyResponse = this.pFrequencyResponse;
            s.pFrequencyVector = this.pFrequencyVector;
            s.pInputCache = this.pInputCache;
            s.pInputDataType = this.pInputDataType;
        end
        %------------------------------------------------------------------
        function loadObjectImpl(this,s,wasLocked)
            % Set properties in object obj to values in structure s
            % Set public properties and states
            loadObjectImpl@matlab.System(this,s,wasLocked);
            if wasLocked
                this.pFrequencyResponse = s.pFrequencyResponse;
                this.pFrequencyVector = s.pFrequencyVector;
                this.pInputCache = s.pInputCache;
                this.pInputDataType = s.pInputDataType;
            end
        end
        %------------------------------------------------------------------
        function flag = isInputSizeMutableImpl(~,~)
            % Return false if input size cannot change
            % between calls to the System object
            flag = true;
        end
        %------------------------------------------------------------------
        function sts = getSampleTimeImpl(this)
            sts = createSampleTime(this,'Type','Inherited');
        end
        %------------------------------------------------------------------
        function Fs = getSampleRate(this)
            if this.NormalizedFrequency
                Fs = 2;
            else
                Fs = this.SampleRate;
            end
        end
        %------------------------------------------------------------------
        function flag = isInactivePropertyImpl(this, prop)
            flag = false;
            switch prop
                case 'SampleRate'
                    flag = logical(this.NormalizedFrequency);
            end
        end
    end

    methods(Static, Hidden)
        %------------------------------------------------------------------
        function h = computefreqz(b,a,nFFT,freqVec,Fs)
            % Make B a row vector
            if isvector(b)
                b = b(:).';
            end
            % Make a row vector
            if isvector(a)
                a = a(:).';
            end
            kb = size(b,1);
            hNum = complex(zeros(nFFT, 1),zeros(nFFT,1));
            hNum(:, 1) = dsp.internal.DigitalFilterFrequencyResponse.freqz(b(1,:), 1, freqVec(1,1:nFFT), Fs);
            for k = 2:kb
                hNum(:,1) = hNum(:,1).*dsp.internal.DigitalFilterFrequencyResponse.freqz(b(k, :), 1 , freqVec(1:nFFT), Fs).';
            end
            % Den
            ka = size(a,1);
            hDen = complex(zeros(nFFT, 1),zeros(nFFT,1));
            hDen(:, 1) = dsp.internal.DigitalFilterFrequencyResponse.freqz(1, a(1,:), freqVec(1,1:nFFT), Fs);
            for k = 2:ka
                hDen(:,1) = hDen(:,1).*dsp.internal.DigitalFilterFrequencyResponse.freqz(1, a(k, :), freqVec(1,1:nFFT), Fs).';
            end
            % Total Frequency Response
            h = hNum.*hDen;
        end
        %------------------------------------------------------------------
        function h = freqz(b,a,freqVec,Fs)
            if length(a) == 1
                h = dsp.internal.DigitalFilterFrequencyResponse.freqzfir(b,a,freqVec,Fs);
            else
                h = dsp.internal.DigitalFilterFrequencyResponse.freqziir(b,a,freqVec,Fs);
            end
        end
        %------------------------------------------------------------------
        function h = freqzfir(b,a,w,Fs)
            n  = length(b);
            b = b./a;
            digw = 2.*pi.*w./Fs; % Convert from Hz to rad/sample for computational purposes
            s = exp(1i*digw);    % Digital frequency must be used for this calculation
            hpoly = dsp.internal.DigitalFilterFrequencyResponse.polyval(b,s);
            h = hpoly./exp(1i*digw*(n-1));
        end
        %------------------------------------------------------------------
        function h = freqziir(b,a,w,Fs)
            na = numel(a);
            nb = numel(b);
            a  = [a(:).' zeros(1,max(0,nb-na))];  % Make a and b of the same length
            b  = [b(:).' zeros(1,max(0,na-nb))];
            digw = 2.*pi.*w./Fs; % Convert from Hz to rad/sample for computational purposes
            s = exp(1i*digw);    % Digital frequency must be used for this calculation
            h =  dsp.internal.DigitalFilterFrequencyResponse.polyval(b,s)./dsp.internal.DigitalFilterFrequencyResponse.polyval(a,s);
        end
        %------------------------------------------------------------------
        function h = polyval(b,s)
            nc = length(b);
            h = complex(zeros(size(s)),zeros(size(s)));
            h(:) = b(1);
            for i = 2:nc
                sh = s.*h;
                h = sh + double(b(i));
            end
        end
    end
end