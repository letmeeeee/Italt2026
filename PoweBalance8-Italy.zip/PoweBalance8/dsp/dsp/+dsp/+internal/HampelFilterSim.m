classdef HampelFilterSim < dsp.internal.AbstractSlidingWindowStatistic
% HampelFilterSim This class is used in dsp.HampelFilter

%   Copyright 2016-2020 The MathWorks, Inc.

    %#codegen
    %#ok<*EMCLS>
    
    properties (Access = protected)
        InitialBufferValue = 0;
        
        pNumNeighbors;
    end
    
    properties 
        Threshold = 3;
    end
    
    methods
        function obj = HampelFilterSim(varargin)
            setProperties(obj,nargin,varargin{:});
        end
    end
    
    methods (Access = protected)
        
        function setupImpl(obj,u)
            setupImpl@dsp.internal.AbstractSlidingWindowStatistic(obj,u);
            
            obj.pNumNeighbors = (obj.WindowLength-1) / 2;
        end
        
        function [y,isOutlier] = computeStatistic(obj,u)
            k = obj.pNumNeighbors;
            if (k > 0)
                [x,idx] = hampel(u,k,obj.Threshold);
            else
                x = u;
                idx = false(size(x));
            end
            
            % Discard endpoints. 
            y         = x(k+1:end-k,:);
            isOutlier = idx(k+1:end-k,:);
        end

        function [y,isOutlier] = stepImpl(obj,u)
            if size(u,2) ~= 0
                x = [obj.pBuffer;u];
                [y,isOutlier] = obj.computeStatistic(x);
                obj.pBuffer = x(end-obj.WindowLength + 2:end,:);
            else
                y = u;
                isOutlier = false(size(u));
            end
        end
        
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@dsp.internal.AbstractSlidingWindowStatistic(obj);
            if isLocked(obj)
                s.pNumNeighbors = obj.pNumNeighbors;
            end
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                obj.pNumNeighbors = s.pNumNeighbors;
            end
            loadObjectImpl@dsp.internal.AbstractSlidingWindowStatistic(obj, s, wasLocked);
        end
        
    end

end