classdef PartitionOS <  dsp.internal.PartitionOAOSBase
% PartitionOS Partitioned overlap-save filter. This class is used in 
% dsp.FrequencyDomainFIRFilter

% Copyright 2017-2022 The MathWorks, Inc.

 %#codegen
    methods
        function obj = PartitionOS(varargin)
            setProperties(obj,nargin,varargin{:});
        end
    end
    
    methods(Access = protected)
        function setupImpl(obj, u)

            if strcmp(obj.Domain,'Time')
                obj.pPartitionLength = obj.PartitionLength;
            else
                obj.pPartitionLength = size(obj.Numerator,1) / 2;
            end
            
            obj.pFFTLength         = cast(2 * obj.pPartitionLength,class(u));
            obj.pLastSectionLength = obj.pPartitionLength;
            setupImpl@dsp.internal.PartitionOAOSBase(obj,u);
            obj.pLastSection = zeros(obj.pLastSectionLength,size(obj.pSum,3),'like',u);
        end
    end
    
    methods (Static)
        function [o,prevsec,sumY,p] = computeOutput(input,sumY,p,L0,numFrames,numchan,H,fftlen,P,K,prevsec,isOutReal, IsHalideEnabled)

            if isOutReal
                o = zeros(L0*numFrames,numchan,class(input));
            else
                o = complex(zeros(L0*numFrames,numchan,class(input)));
            end
            
            zvect = zeros(2*L0,numFrames,numchan,'like',input);
            for frameIdx = 1:numFrames
              x = input((frameIdx-1)*L0+1:frameIdx*L0,:);
              z = [prevsec ; x];
              zvect(:,frameIdx,:) = z;
              prevsec(:,:)   = z(L0 + 1:end,:);  
            end
            
            zvectFFT = complex(fft(zvect, fftlen));

            if isempty(coder.target)
                if IsHalideEnabled
                    Z = complex(zeros(fftlen, P, numchan, class(input)));
                    if isreal(H)
                        H = complex(H);
                    end
                end
            elseif coder.const(IsHalideEnabled) && coder.const(feval('dsp.enhancedsim.IsSysObjSimInCodeGen', coder.target))
                Z = complex(zeros(fftlen, P, numchan, class(input)));
                if isreal(H)
                    pH = complex(H);
                end
            end

            for frameIdx = 1:numFrames

                % Multiply fft of data with fft of all impulses
                % Sum it up. Use 'p' as the index to track circular
                % shift in columns of sumY
                zvect = complex(squeeze(zvectFFT(:,frameIdx,:)));

                if(isempty(coder.target))
                    if IsHalideEnabled
                        dsp.internal.builtins.FrequencyDomainFIRFilter(2, zvect, H, Z, fftlen, P, numchan);
                    else
                        Z = bsxfun(@times, H, zvectFFT(:,frameIdx,:) );
                    end
                else
                    if coder.const(IsHalideEnabled) && coder.const(feval('dsp.enhancedsim.IsSysObjSimInCodeGen', coder.target))
                        if isreal(H)
                            Z = dsp.internal.FrequencyDomainFIRFilterCGSim("Partition", zvect, pH, Z, fftlen, numchan, P);
                        else
                            Z = dsp.internal.FrequencyDomainFIRFilterCGSim("Partition", zvect, H, Z, fftlen, numchan, P);
                        end
                    else
                        Z = bsxfun(@times, H, zvectFFT(:,frameIdx,:) );
                    end
                end

                sumY = sumY +  circshift(Z,-P+p-1,2); 
                
                % IFFT of pth segment
                if isOutReal
                    ifftSumY = real(ifft(sumY(:,p,:),fftlen));
                else
                    ifftSumY = ifft(sumY(:,p,:),fftlen);
                end

                % Select last L-K points
                o((frameIdx-1)*L0+1:frameIdx*L0,:) = ifftSumY(end-(fftlen-K)+1:end,:);

                % Set pth sum back to zero
                sumY(:,p,:) = zeros(fftlen,1,numchan);
                
                % p is the index for circular shift
                if p<P
                    p = p+1;
                else
                    p = cast(1,class(input));
                end
            end
        end
    end

end
