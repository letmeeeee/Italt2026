classdef (Abstract) IIRHalfbandBase < dsp.internal.NormalizedSampleRateEngine & ...
        dsp.internal.FilterAnalysisMultirate
%IIRHALFBANDBASE Abstract base class for IIR halfband objects.
%  dsp.IIRHalfbandDecimator and dsp.IIRHalfbandInterpolator inherit from
%  this class.

% Copyright 2015-2021 The MathWorks, Inc.

%#codegen
%#ok<*EMCA>

    properties (Nontunable, Abstract)
        SampleRate;
    end
    
    properties (Nontunable)
        %FilterOrder Filter order
        %   Specify the order for the designed IIR halfband filter, as a
        %   finite positive integer scalar. This property applies when the
        %   Specification is set to 'Filter order and transition width' or
        %   'Filter order and stopband attenuation'. When DesignMethod is
        %   'Elliptic', FilterOrder must be an odd integer greater than
        %   one. When DesignMethod is 'Quasi-linear phase', FilterOrder
        %   must be a multiple of four. The default value of this property
        %   is 9.
        FilterOrder = 9;
        %StopbandAttenuation Stopband attenuation (dB)
        %   Specify the minimum stopband attenuation for the designed IIR
        %   halfband filter in dB, as a finite positive scalar. This
        %   property applies when Specification is set to 'Filter order and
        %   stopband attenuation' or 'Transition width and stopband
        %   attenuation'. The default value of this property is 80 dB.
        StopbandAttenuation = 80;
        %DesignMethod Design method
        %   Specify the method used to design the IIR halfband filter. Set
        %   the DesignMethod as one of 'Elliptic' or 'Quasi-linear phase'.
        %   When the property is set to 'Quasi-linear phase', the first
        %   branch is a pure delay which results in an approximately linear
        %   phase response. This property applies when you set Specification
        %   to any option except 'Coefficients'. The default value of this
        %   property is 'Elliptic'.
        DesignMethod (1, :) char {matlab.system.mustBeMemberMessageID(DesignMethod, ...
            {'dsp:system:IIRHalfbandDecimator:DesignMethod_Elliptic'; ...
            'dsp:system:IIRHalfbandDecimator:DesignMethod_QuasiLinearPhase'})} = 'Elliptic'; 
        %Specification Filter specification
        %   Specify design parameters for the IIR halfband filter's design
        %   using the method in DesignMethod or specify the coefficients
        %   directly. Set the specification as one of 'Transition width and
        %   stopband attenuation', 'Filter order and stopband attenuation',
        %   'Filter order and transition width', or 'Coefficients'. The
        %   default value of this property is 'Transition width and stopband
        %   attenuation'.
        Specification (1, :) char {matlab.system.mustBeMemberMessageID(Specification, ...
            {'dsp:system:IIRHalfbandDecimator:Specification_NTw'; ...
            'dsp:system:IIRHalfbandDecimator:Specification_NAst'; ...
            'dsp:system:IIRHalfbandDecimator:Specification_TwAst'; ...
            'dsp:system:IIRHalfbandDecimator:Specification_Coefficients'})} = 'Transition width and stopband attenuation'; 
        %Structure Internal allpass structure
        %   Specify the internal allpass filter implementation structure as
        %   one of 'Minimum multiplier' or 'Wave Digital Filter'. Each
        %   structure uses a different coefficients set, independently
        %   stored in the corresponding object property. This property
        %   applies when Specification is set to 'Coefficients'. The default
        %   value of this property is 'Minimum multiplier'.
        Structure (1, :) char {matlab.system.mustBeMemberMessageID(Structure, ...
            {'dsp:system:IIRHalfbandDecimator:Structure_Minimummultiplier'; ...
            'dsp:system:IIRHalfbandDecimator:Structure_WaveDigitalFilter'})} = 'Minimum multiplier';
        % HasPureDelayBranch Make the first branch a pure delay 
        %   When HasPureDelayBranch is set to true, the property holding the
        %   coefficients for the first allpass branch is disabled and Delay
        %   becomes enabled. The default value is false.
        HasPureDelayBranch (1, 1) logical = false
        %Delay Delay length in samples for branch 1
        %   Specify the delay length in number of samples for branch 1, when
        %   that branch is configured as a pure delay.  This property
        %   applies when the HasPureDelayBranch property is set to
        %   true. The default value is 1.
        Delay = 1;
    end
    properties
        %AllpassCoefficients1 Branch 1 allpass polynomial coefficients 
        %   Specify the real allpass polynomial filter coefficients for the
        %   first allpass branch. This property applies when Specification
        %   is set to 'Coefficients' and the Structure is set to 'Minimum
        %   multiplier'. The value of this property can be either a Nx1 or
        %   Nx2 matrix of N first or second-order allpass sections. The
        %   default value for this property is [0.1284563; 0.7906755]. This
        %   property is tunable.
        AllpassCoefficients1 = [0.1284563; 0.7906755]
        %AllpassCoefficients2 Branch 2 allpass polynomial coefficients
        %   Specify the real allpass polynomial filter coefficients for the
        %   second allpass branch. This property applies when Specification
        %   is set to 'Coefficients' and the Structure is set to 'Minimum
        %   multiplier'. The value of this property can be either a Nx1 or
        %   Nx2 matrix of N first or second-order allpass sections. The
        %   default value for this property is 0.4295667. This property is
        %   tunable.
        AllpassCoefficients2 = 0.4295667 
    end
    properties (Nontunable)
        %WDFCoefficients1 Branch 1 Wave Digital coefficients
        %   Specify the real allpass coefficients in Wave Digital Filter
        %   form for the first allpass branch. This property applies when
        %   Specification is set to 'Coefficients' and Structure is set to
        %   'Wave Digital Filter'. The value of this property can be either
        %   a Nx1 or Nx2 matrix of N first or second-order allpass sections.
        %   All elements must have absolute value <= 1. The default value
        %   for this property is [0.1284563; 0.7906755].
        WDFCoefficients1 = [0.1284563; 0.7906755]
        %WDFCoefficients2 Branch 2 Wave Digital coefficients
        %   Specify the real allpass coefficients in Wave Digital Filter
        %   form for the second allpass branch. This property applies when
        %   Specification is set to 'Coefficients' and Structure is set to
        %   'Wave Digital Filter'. The value of this property can be either
        %   a Nx1 or Nx2 matrix of N first or second-order allpass sections.
        %   All elements must have absolute value <= 1. The default value
        %   for this property is 0.4295667.
        WDFCoefficients2 = 0.4295667
    end
    properties (Abstract, Nontunable)
        TransitionWidth
    end
    properties(Nontunable)
        %HasTrailingFirstOrderSection Last section of branch 2 is first order
        %   For the minimum-multiplier or wave digital structure, specify
        %   whether the last section of branch 2 is a first order section
        %   (true) or whether it is a second order section (false). When set
        %   to true, the second element of the last row of the N-by-2 matrx
        %   is ignored. The default is false.
        HasTrailingFirstOrderSection (1, 1) logical = false
    end
    
    properties(Access = protected)
        %pStates Holds internal filter states within a zero-padded 
        %  3-D array of size (maxStatesPerSection x numChannels x 
        %  numSections).
        pStates        
        pBranch2Carry
        pNumChannels = int8(-1);
        pBranchCoef1    %1st and 2nd order coefs
        pBranchCoef2

    end
    
    properties(Access = protected, Nontunable)   
        pDelay
        pDelayVal 
        pIsFilterDesigned  = false;
        pInputPrototype
        pBranchInfo1    %sizes and filter types of branches
        pBranchInfo2
        pCachedNoDelay = false;
        pCachedUsesMinMult = false;
    end
    
    properties(Abstract, Access = protected, Nontunable)
        pSR
    end
    %----------------------------------------------------------------------
    % Abstract methods
    %----------------------------------------------------------------------
    methods (Abstract, Access=protected)
        isDecimator(obj)
    end
    %----------------------------------------------------------------------
    % Public methods
    %----------------------------------------------------------------------
    methods
        %------------------------------------------------------------------
        % Set method for properties
        %------------------------------------------------------------------
        function set.StopbandAttenuation(obj,Astop)
            validateattributes(Astop,{'single','double'},{'real','positive',...
                'finite','scalar'},'','StopbandAttenuation');
            obj.StopbandAttenuation = Astop;
            needToDesignFilters(obj);
        end
        %------------------------------------------------------------------
        function set.FilterOrder(obj,Order)
            validateattributes(Order,{'numeric'},{'real','integer','positive',...
                'finite', 'scalar'},'','FilterOrder');
            obj.FilterOrder = double(Order);
            needToDesignFilters(obj);
        end
        %------------------------------------------------------------------
        function set.DesignMethod(obj,dm)
            obj.DesignMethod = dm;
            needToDesignFilters(obj);
        end
        %------------------------------------------------------------------
        function set.Specification(obj,s)
            obj.Specification = s;
            needToDesignFilters(obj);
        end
        %------------------------------------------------------------------
        function set.AllpassCoefficients1(obj,value)
            validateattributes(value, {'numeric'}, ...
                {'finite','real'},...
                'set.AllpassCoefficients1','AllpassCoefficients1');
            [r,c] = size(value);
            if (r >= 1) && (c > 2)
                coder.internal.errorIf(true, ['dsp:system',...
                    ':Shared:coeffSize']); 
            end
            
            needToDesignFilters(obj);
            obj.AllpassCoefficients1 = value;
        end
        %------------------------------------------------------------------
        function set.AllpassCoefficients2(obj,value)
            validateattributes(value, {'numeric'}, ...
                {'finite','real'},...
                'set.AllpassCoefficients2','AllpassCoefficients2');
            [r,c] = size(value);
            if (r >= 1) && (c > 2)
                coder.internal.errorIf(true, ['dsp:system',...
                    ':Shared:coeffSize']);
            end
            needToDesignFilters(obj);
            obj.AllpassCoefficients2 = value;
        end
        %------------------------------------------------------------------
        function set.WDFCoefficients1(obj,value)
            validateattributes(value, {'numeric'}, ... 
                {'finite', 'real'},'set.WDFCoefficients1', 'WDFCoefficients1');
            [r,c] = size(value);
            if (r >= 1) && (c > 2)
                coder.internal.errorIf(true, ['dsp:system',...
                    ':Shared:wdfcoeffSize']);
            end
            if(any(any(abs(value) > 1)))
                coder.internal.errorIf(true, ['dsp:system',...
                    ':Shared:wdfCoeBiggerThanOne'])
            end
            needToDesignFilters(obj);
            obj.WDFCoefficients1 = value; 
        end
        %------------------------------------------------------------------
        function set.WDFCoefficients2(obj,value)
            validateattributes(value, {'numeric'}, ... 
                {'finite', 'real'},'set.WDFCoefficients2', 'WDFCoefficients2');
            [r,c] = size(value);
            if (r >= 1) && (c > 2)
                coder.internal.errorIf(true, ['dsp:system',...
                    ':Shared:wdfcoeffSize']);
            end
            if(any(any(abs(value) > 1)))
                coder.internal.errorIf(true, ['dsp:system',...
                    ':Shared:wdfCoeBiggerThanOne'])
            end
            needToDesignFilters(obj);
            obj.WDFCoefficients2 = value; 
        end
        %------------------------------------------------------------------
        function set.HasTrailingFirstOrderSection(obj,x)
            needToDesignFilters(obj);
            obj.HasTrailingFirstOrderSection = x;
        end
        %------------------------------------------------------------------
        function set.Delay(obj,del)
            validateattributes(del,{'single','double'},{'real','positive',...
                'finite','scalar'},'','Delay');
            obj.Delay = del;
            needToDesignFilters(obj);
        end
    end
    %----------------------------------------------------------------------
    % Protected methods
    %----------------------------------------------------------------------
    methods (Access = protected)

        function processTunedPropertiesImpl(obj)        
            %Only AllpassCoefficients1,2 are tunable. So this method only
            %applies in coefficient mode.
            if strcmp(obj.Specification, 'Coefficients') && ...
                    strcmp(obj.Structure, 'Minimum multiplier')
                %cache old values for error checking
                prevBranch1NumFOS = obj.pBranchInfo1.NumFOS;
                prevBranch1NumSOS = obj.pBranchInfo1.NumSOS;
                prevBranch2NumFOS = obj.pBranchInfo2.NumFOS;
                prevBranch2NumSOS = obj.pBranchInfo2.NumSOS;
                
                %Make new coefficients of the proper type.
                dType = obj.pInputPrototype;
                
                
                if obj.HasPureDelayBranch
                    del = obj.Delay;
                else
                    del = 0;
                end
                
                %Only allpass coefficients are tunable so only parse those.
                [branchInfo1, branchCoef1] = dsp.internal.AllpassMinMult.makeAllpassSpec(...
                    obj.AllpassCoefficients1, dType, false, del);
                [branchInfo2, branchCoef2] = dsp.internal.AllpassMinMult.makeAllpassSpec(...
                    obj.AllpassCoefficients2, dType, ...
                    obj.HasTrailingFirstOrderSection, 0);
                
                newBranch1NumFOS = branchInfo1.NumFOS;
                newBranch1NumSOS = branchInfo1.NumSOS;
                newBranch2NumFOS = branchInfo2.NumFOS;
                newBranch2NumSOS = branchInfo2.NumSOS;
                
                if isempty(coder.target)
                    % Check that orders hasn't changed
                    if ~(isequal(prevBranch1NumFOS, newBranch1NumFOS) && ...
                            isequal(prevBranch1NumSOS, newBranch1NumSOS) && ...
                            isequal(prevBranch2NumFOS, newBranch2NumFOS) && ...
                            isequal(prevBranch2NumSOS, newBranch2NumSOS))
                        
                        coder.internal.errorIf(true, ['dsp:system',...
                            ':Shared:noChangeNumOfSections']);
                    end
                end
                
                obj.pBranchCoef1 = branchCoef1;
                obj.pBranchCoef2 = branchCoef2;
            end
        end
        %----------------------------------------------------------------------
        function validateInputsImpl(obj,u)
            
            % Checks on first input
            validateattributes(u, {'single','double'},...
                {'2d'},'input');
            
            % Check if number of channels has changed since last step
            if obj.pNumChannels ~= -1
                coder.internal.errorIf(size(u,2) ~= obj.pNumChannels, ['dsp:system',...
                    ':Shared:numChannels']);
            end

            % cache the input data type
            if isempty(coder.target)
                if ~isempty(u)
                    cacheInputDataType(obj,u)
                end
            end
        end
        %------------------------------------------------------------------
        function validatePropertiesImpl(obj)

            if ~isCoefficientMode(obj) && ...
                    ~strcmp(obj.Specification, 'Transition width and stopband attenuation')
                if strcmp(obj.DesignMethod, 'Elliptic')
                    % Elliptic design needs odd filter order
                    coder.internal.errorIf(obj.FilterOrder==1 || ~mod(obj.FilterOrder,2), ...
                    'dsp:system:IIRHalfbandInterpolator:invalidOrderElliptic');
                else
                    % Quasi-linear phase design needs filter order to be multiple of 4
                    coder.internal.errorIf(mod(obj.FilterOrder,4)~=0, ...
                    'dsp:system:IIRHalfbandInterpolator:invalidOrderQuasiLinearPhase');
                end
            end
            
        end
        %------------------------------------------------------------------
        function setupImpl(obj, varargin)
            u = varargin{1};
            setupImpl@dsp.internal.NormalizedSampleRateEngine(obj,u);
            
            % Set system dimensions
            obj.pNumChannels = int8(getNumChannels(obj,u));

            % Set coefficients
            if obj.pIsFilterDesigned && isa(u, 'single')
                % Redesign if input is single and previous design was by
                % filter analysis methods. They would have designed coeffs
                % for double data type.
                needToDesignFilters(obj);
            end
            setBranchCoefficients(obj, class(u));
            
            % Set states
            setStates(obj, u);
            obj.pInputPrototype = class(u); 

            %Avoid method call and strcmp overhead during step
            obj.pCachedNoDelay = ~hasDelayBranch(obj);
            obj.pCachedUsesMinMult = usesMinMult(obj); 
        end
        %------------------------------------------------------------------
        function resetImpl(obj) 
            % reset states 
            if hasDelayBranch(obj)
                reset(obj.pDelay);
                obj.pStates.Branch2 = zeros(size(obj.pStates.Branch2), 'like', obj.pStates.Branch2);
            else
                obj.pStates.Branch1 = zeros(size(obj.pStates.Branch1), 'like', obj.pStates.Branch1);
                obj.pStates.Branch2 = zeros(size(obj.pStates.Branch2), 'like', obj.pStates.Branch2);
            end
            
            if isDecimator(obj)
                obj.pBranch2Carry = zeros(size(obj.pBranch2Carry),'like',obj.pBranch2Carry);
            end
        end
        %------------------------------------------------------------------
        function releaseImpl(obj)
            needToDesignFilters(obj);
            obj.pNumChannels = int8(-1);
            if hasDelayBranch(obj) 
                release(obj.pDelay);
            end
        end
        %------------------------------------------------------------------
        function flag = isInactivePropertyImpl(obj, prop)
            %Do not call isInactivePropertyImpl@dsp.internal.NormalizedSampleRateEngine
            %These need to  be overridden here because of coefficient mode
            flag = false;
            coeff = strcmp(obj.Specification, 'Coefficients');


            switch prop
                case 'StopbandAttenuation'
                    flag = coeff || strcmp(obj.Specification,'Filter order and transition width');
                case 'TransitionWidth'
                    flag = coeff || strcmp(obj.Specification,'Filter order and stopband attenuation');
                case 'FilterOrder'
                    flag = coeff || strcmp(obj.Specification, 'Transition width and stopband attenuation');
                case {'Structure', 'HasTrailingFirstOrderSection','HasPureDelayBranch'}
                    flag = ~coeff; 
                case {'AllpassCoefficients2'}
                    flag = ~(coeff && strcmp(obj.Structure, 'Minimum multiplier'));
                case {'WDFCoefficients2'}
                    flag = ~(coeff && strcmp(obj.Structure, 'Wave Digital Filter'));
                case {'DesignMethod'}
                    flag = coeff;
                case {'Delay'}
                    flag = ~coeff || ~obj.HasPureDelayBranch;
                case 'AllpassCoefficients1'
                    flag = ~(coeff && ~obj.HasPureDelayBranch && ...
                        strcmp(obj.Structure, 'Minimum multiplier') );
                case 'WDFCoefficients1'
                    flag = ~(coeff && ~obj.HasPureDelayBranch && ...
                        strcmp(obj.Structure, 'Wave Digital Filter') );

                case {'SampleRate'}
                    if obj.getExecPlatformIndex()
                        flag = ~isSampleRateOnDialog(obj);
                    else
                        flag = obj.NormalizedFrequency;
                    end
                    flag = flag || coeff;  
                case {'SampleRateMode','NormalizedFrequency'}
                    flag = coeff;
            end
        end
        %------------------------------------------------------------------
        function needToDesignFilters(obj)
            % If any of the properties are changed, we need to redesign the
            % filter
            obj.pIsFilterDesigned = false;
        end
        %------------------------------------------------------------------
        function setBranchCoefficients(obj, dType)
            
            if obj.pIsFilterDesigned
                % This helps avoid duplicate construction of filters when
                % setup() is called after an analysis method.
                % For codegen, this property is always false.
                return
            end

            coder.extrinsic('dsp.internal.IIRHalfbandBase.designIIRHB')

            if ~isCoefficientMode(obj)

                switch obj.Specification
                    case 'Transition width and stopband attenuation'
                        designParam1 = obj.TransitionWidth;
                        designParam2 = obj.StopbandAttenuation;
                    case 'Filter order and transition width'
                        designParam1 = obj.FilterOrder;
                        designParam2 = obj.TransitionWidth;
                    case 'Filter order and stopband attenuation'
                        designParam1 = obj.FilterOrder;
                        designParam2 = obj.StopbandAttenuation;
                end
                isNormalized = (isSampleRateNormalized(obj) || obj.NormalizedFrequency);
                if ~isempty(coder.target)                                            
                     [bi1,bi2,bc1,bc2, obj.pDelayVal] = ...
                         coder.const(@obj.designIIRHB, isDecimator(obj), ...
                         obj.DesignMethod, obj.Specification, ... 
                         designParam1, designParam2, getSampleRate(obj), dType,...
                         isNormalized);
                 else                                         
                     [bi1,bi2,bc1,bc2, obj.pDelayVal, mfiltObj] = ...
                         dsp.internal.IIRHalfbandBase.designIIRHB(isDecimator(obj), ...
                         obj.DesignMethod, obj.Specification, ...
                         designParam1, designParam2, getSampleRate(obj), dType,...
                         isNormalized);
                 end                                                    
            
                 obj.pBranchInfo1 =bi1;
                 obj.pBranchInfo2 =bi2;
                 obj.pBranchCoef1 =bc1;
                 obj.pBranchCoef2 =bc2;

            else
                % --- Coefficient mode --- 
                
                %mfilt not needed in coefficient mode because there is no
                %metadata.
                
                if obj.HasPureDelayBranch
                    obj.pDelayVal = obj.Delay;
                else
                    obj.pDelayVal = 0; 
                end
                
                if usesWaveDigital(obj) 
                    [binfo1, coef1] = dsp.internal.WaveDigitalFilter.makeAllpassSpec(...
                        obj.WDFCoefficients1, dType, false, obj.HasPureDelayBranch);
                    [binfo2, coef2] = dsp.internal.WaveDigitalFilter.makeAllpassSpec(...
                        obj.WDFCoefficients2, dType, ...
                        obj.HasTrailingFirstOrderSection, 0); 
                else
                    [binfo1, coef1] = dsp.internal.AllpassMinMult.makeAllpassSpec(...
                        obj.AllpassCoefficients1, dType, false, obj.HasPureDelayBranch); 
                    [binfo2, coef2] = dsp.internal.AllpassMinMult.makeAllpassSpec(...
                        obj.AllpassCoefficients2, dType, ...
                        obj.HasTrailingFirstOrderSection, 0); 
                end
                
                obj.pBranchInfo1 = binfo1;
                obj.pBranchInfo2 = binfo2;
                obj.pBranchCoef1 = coef1;
                obj.pBranchCoef2 = coef2;


            end 
            if hasDelayBranch(obj)
                % Linear phase design has one branch as pure delay
                obj.pDelay = dsp.Delay(obj.pDelayVal);
            end
            if isempty(coder.target)
                if ~isCoefficientMode(obj)
                    % Set fdesign and fmethod on the object. Not needed in
                    % coef mode.
                    setMetaData(obj, getfdesign(mfiltObj), getfmethod(mfiltObj));
                end
                % Set pIsFilterDesigned to true to indicate the filter has
                % been designed
                obj.pIsFilterDesigned = true;
            end
        end
        %------------------------------------------------------------------
        function setStates(obj, u)
            % Allocate internal states
            % Minimum multiplier case needs twice as many states
            numChans = getNumChannels(obj,u);
            
            if  usesMinMult(obj)           
                if hasDelayBranch(obj)
                    obj.pStates = struct(...
                        'Branch2', zeros(2*obj.pBranchInfo2.MaxOrder, numChans, obj.pBranchInfo2.NumFOS + obj.pBranchInfo2.NumSOS, 'like', u));
                else
                    obj.pStates = struct(...
                        'Branch1', zeros(2*obj.pBranchInfo1.MaxOrder, numChans, obj.pBranchInfo1.NumFOS + obj.pBranchInfo1.NumSOS, 'like', u), ...
                        'Branch2', zeros(2*obj.pBranchInfo2.MaxOrder, numChans, obj.pBranchInfo2.NumFOS + obj.pBranchInfo2.NumSOS, 'like', u));
                end
            else
                %Wave Digital means half as many states
                if hasDelayBranch(obj)
                    obj.pStates = struct('Branch2', zeros(2*obj.pBranchInfo2.MaxOrder, ...
                        numChans, obj.pBranchInfo2.NumFOS + obj.pBranchInfo2.NumSOS, 'like', u));
                else
                    obj.pStates = struct(...
                        'Branch1', zeros(obj.pBranchInfo1.MaxOrder, numChans, obj.pBranchInfo1.NumFOS + obj.pBranchInfo1.NumSOS, 'like', u), ...
                        'Branch2', zeros(obj.pBranchInfo2.MaxOrder, numChans, obj.pBranchInfo2.NumFOS + obj.pBranchInfo2.NumSOS, 'like', u));
                end
            end
            
            if isDecimator(obj)
                obj.pBranch2Carry = zeros(1,numChans, 'like', u);
            end
        end
        %------------------------------------------------------------------
        function d = convertToDFILT(obj,~)
            % Set coefficients
            setBranchCoefficients(obj,'double');
            
            if ~strcmp(obj.Specification, 'Coefficients')
                if strcmp(obj.DesignMethod, 'Elliptic')
                    branch1 = num2cell(obj.pBranchCoef1.FirstOrderSectionCoeffs,2)';
                    if isempty(obj.pBranchCoef2.FirstOrderSectionCoeffs)
                        % Edge case - when filter order is 3, second branch
                        % does not have any allpass section
                        branch2 = {1};
                    else
                        branch2 = num2cell(obj.pBranchCoef2.FirstOrderSectionCoeffs,2)';
                    end
                else
                    % Get coefficients in the form that mfilt.iirinterp accepts
                    branch1 = zeros(1,obj.pDelayVal+1);
                    branch1(end) = 1;
                    branch1 = {branch1};
                    if obj.pBranchInfo2.NumSOS==0
                        branch2 = num2cell(obj.pBranchCoef2.FirstOrderSectionCoeffs,2)';
                    else
                        branch2 = [num2cell(obj.pBranchCoef2.SecondOrderSectionCoeffs,2)', ...
                            num2cell(obj.pBranchCoef2.FirstOrderSectionCoeffs,2)'];
                    end
                end
            else  %we have the coefficients
                [branch1, branch2] = getCoeffsForMFILT(obj);
            end
            
            % Suppress MFILT deprecation warning
            w = warning('off', 'dsp:mfilt:mfilt:Obsolete');
            restoreWarn = onCleanup(@() warning(w));
            
            d = getMFILT(obj, branch1, branch2);
        end
        %------------------------------------------------------------------
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@dsp.internal.NormalizedSampleRateEngine(obj);
            s.pSR           = obj.pSR;
            if isLocked(obj)
                s.pStates       = obj.pStates;
                if isDecimator(obj)
                    s.pBranch2Carry = obj.pBranch2Carry;
                end
                s.pNumChannels  = obj.pNumChannels;
                s.pBranchInfo1      = obj.pBranchInfo1;
                s.pBranchInfo2      = obj.pBranchInfo2;
                s.pBranchCoef1      = obj.pBranchCoef1;
                s.pBranchCoef2      = obj.pBranchCoef2;
                s.pCachedNoDelay = obj.pCachedNoDelay;  
                s.pCachedUsesMinMult = obj.pCachedUsesMinMult;  
                if hasDelayBranch(obj)
                    s.pDelay    = matlab.System.saveObject(obj.pDelay);
                end
                s.pDelayVal = obj.pDelayVal;
                s.pIsFilterDesigned = obj.pIsFilterDesigned;
                s.pInputPrototype = obj.pInputPrototype;
            end
            s = saveFA(obj, s);   % Save filter analysis class properties
        end
        %------------------------------------------------------------------
        function loadObjectImpl(obj, s, wasLocked)
            loadObjectImpl@dsp.internal.NormalizedSampleRateEngine(obj,s,wasLocked);
            obj.pSR           = s.pSR;
            if wasLocked
                obj.pStates       = s.pStates;
                if isDecimator(obj)
                    obj.pBranch2Carry = s.pBranch2Carry;
                end
                obj.pNumChannels  = s.pNumChannels;
                if isfield(s, 'pBranch1') % pre R2016a
                    obj.pCachedNoDelay = ~hasDelayBranch(obj);  
                    obj.pCachedUsesMinMult = usesMinMult(obj); 

                    if strcmp(obj.DesignMethod, 'Elliptic')
                        %Elliptic is all 1st order sections
                        obj.pBranchInfo1.MaxOrder = uint32(1);
                        obj.pBranchInfo1.NumFOS = uint32(s.pBranch1.NumSections); 
                        obj.pBranchInfo1.NumSOS = uint32(0); 
                        obj.pBranchInfo1.WDFTypeFOS = [];
                        obj.pBranchInfo1.WDFTypeSOS = [];
                        obj.pBranchCoef1.FirstOrderSectionCoeffs = s.pBranch1.Coefficients;
                        obj.pBranchCoef1.SecondOrderSectionCoeff = []; 

                        obj.pBranchInfo2.MaxOrder = uint32(1);
                        obj.pBranchInfo2.NumFOS = uint32(s.pBranch1.NumSections); 
                        obj.pBranchInfo2.NumSOS = uint32(0); 
                        obj.pBranchInfo2.WDFTypeFOS = [];
                        obj.pBranchInfo2.WDFTypeSOS = [];
                        obj.pBranchCoef2.FirstOrderSectionCoeffs = s.pBranch2.Coefficients;
                        obj.pBranchCoef2.SecondOrderSectionCoeff = []; 
                        obj.pDelayVal = 0;


                    else %quasi-linear. Branch 2 is delay
                        obj.pBranchInfo1.MaxOrder = uint32(0); 
                        obj.pBranchInfo1.NumFOS = uint32(0);
                        obj.pBranchInfo1.NumSOS = uint32(0); 
                        obj.pBranchInfo1.WDFTypeFOS = [];
                        obj.pBranchInfo1.WDFTypeSOS = [];
                        obj.pBranchCoef1.FirstOrderSectionCoeffs = []; 
                        obj.pBranchCoef1.SecondOrderSectionCoeff = []; 
                        obj.pDelayVal = obj.Branch1.DelayVal;

                        obj.pBranchInfo2.MaxOrder = uint32(1); 
                        obj.pBranchInfo2.NumFOS = uint32(s.pBranch1.NumSections); 
                        obj.pBranchInfo2.NumSOS = uint32(0); 
                        obj.pBranchInfo2.WDFTypeFOS = [];
                        obj.pBranchInfo2.WDFTypeSOS = [];
                        obj.pBranchCoef2.FirstOrderSectionCoeffs = s.pBranch2.FirstOrderSectionCoeffs;
                        obj.pBranchCoef2.SecondOrderSectionCoeff = s.pBranch2.SecondOrderSectionCoeffs;
                    end
                    s.pInputPrototype = class(obj.pBranchCoef2.FirstOrderSectionCoeffs); 
                else
                    obj.pBranchInfo1   = s.pBranchInfo1;
                    obj.pBranchInfo2   = s.pBranchInfo2;
                    obj.pBranchCoef1   = s.pBranchCoef1;
                    obj.pBranchCoef2   = s.pBranchCoef2;
                    obj.pCachedNoDelay = s.pCachedNoDelay;  
                    obj.pCachedUsesMinMult = s.pCachedUsesMinMult;  
                    obj.pDelayVal = s.pDelayVal;
                end

                obj.pInputPrototype = s.pInputPrototype;
                if hasDelayBranch(obj) 
                    obj.pDelay    = matlab.System.loadObject(s.pDelay);
               end
                obj.pIsFilterDesigned = s.pIsFilterDesigned;
            end 
            loadFA(obj, s, wasLocked); % Load filter analysis class properties
        end
        %------------------------------------------------------------------
        function y = infoImpl(obj,varargin)
            y = infoFA(obj,varargin{:});
        end
        %------------------------------------------------------------------
        function flag = isInputComplexityMutableImpl(~,~)
            flag = false;
        end
        %------------------------------------------------------------------
        function [branch1, branch2] = getCoeffsForMFILT(obj)
            %This is used when in coefficient mode.
            
            if hasDelayBranch(obj)
                branch1 = zeros(1, obj.Delay + 1);
                branch1(end) = 1;
                branch1 = {branch1};
            else
                if strcmp(obj.Structure, 'Minimum multiplier')
                    branch1 = num2cell(obj.AllpassCoefficients1,2).';
                else 
                    branch1 = wdf2allpass(num2cell(obj.WDFCoefficients1,2)).';
                end
            end

            %loop through and add stages because the last may be 1st order
            isMinMult = strcmp(obj.Structure, 'Minimum multiplier');
            if isMinMult
                coe2 = obj.AllpassCoefficients2;
            else
                coe2 = obj.WDFCoefficients2;
            end
            [stages,order] = size(coe2);
            hasTrailing = obj.HasTrailingFirstOrderSection && (order ==2);
            branch2 = cell(1,stages);
            for ii=1:stages
                if (ii==stages) && hasTrailing 
                    if isMinMult 
                        branch2{ii} = coe2(ii,1);
                    else
                        branch2{ii} = wdf2allpass(coe2(ii,1));
                    end

                else
                    if isMinMult 
                        branch2{ii} = coe2(ii,:);
                    else
                        branch2{ii} = wdf2allpass(coe2(ii,:));
                    end
                end
            end
        end
        %------------------------------------------------------------------
        function m = getMFILT(obj, branch1, branch2)
            % Suppress MFILT deprecation warnings
            w = warning('off', 'dsp:mfilt:mfilt:Obsolete');
            restoreWarn = onCleanup(@() warning(w));
            

            if isDecimator(obj)
                if usesWaveDigital(obj)
                    m = mfilt.iirwdfdecim(branch1, branch2);%#ok
                else
                    m = mfilt.iirdecim(branch1, branch2);%#ok
                end
            else
                if usesWaveDigital(obj)
                    m = mfilt.iirwdfinterp(branch1, branch2);%#ok
                else
                    m = dsp.internal.mfilt.iirinterp(branch1, branch2);
                end
            end
        end
        %------------------------------------------------------------------
        function tf = usesWaveDigital(obj)
            tf = strcmp(obj.Specification, 'Coefficients') && ...
                strcmp(obj.Structure, 'Wave Digital Filter');
        end
        %------------------------------------------------------------------
        function tf = usesMinMult(obj)
            %Min multiplier for coeff mode + min mult or any design mode
            tf = (strcmp(obj.Specification, 'Coefficients') && ...
                strcmp(obj.Structure, 'Minimum multiplier')) || ...
                ~(strcmp(obj.Specification, 'Coefficients'));
        end
        %------------------------------------------------------------------
        function tf = isCoefficientMode(obj)
            tf = strcmp(obj.Specification, 'Coefficients');
        end

        function tf = hasDelayBranch(obj)
            coeff =  isCoefficientMode(obj);
            tf = (coeff && obj.HasPureDelayBranch) ||  ... 
                   (~coeff &&  strcmp(obj.DesignMethod, 'Quasi-linear phase'));
        end
        function Fs = getSampleRate(obj)
            if ~isInactivePropertyImpl(obj, 'SampleRateMode')
                % Call from simulink object
                if isSampleRateNormalized(obj)
                    Fs = 2;
                elseif isSampleRateInherited(obj)
                    Fs = getInheritedSampleRate(obj);
                else
                    Fs = obj.SampleRate;
                end
            else
                if obj.NormalizedFrequency
                   Fs = 2;
               else
                   Fs = obj.SampleRate;
                end
            end
        end
    end
    %----------------------------------------------------------------------
    % Static hidden methods
    %----------------------------------------------------------------------
    methods (Hidden, Static)
        function [binfo1, binfo2, bcoef1, bcoef2, delayVal, iirhb] = designIIRHB(isDecim, ...
                designMethod, spec, designParam1, designParam2, Fs, dType, isNormalized)
            %Branch(1/2) is a struct with fields:
            %   MaxOrder  - 1 or 2
            %   FirstOrderSectionCoeffs  - empty if no FOS
            %   NumFOS
            %   SecondOrderSectionCoeffs - empty if no SOS
            %   NumSOS
            %If a branch is pure 1st order, MaxOrder=1, but the other fields
            %should be populated.

            if isDecim
                designFcn = @fdesign.decimator;
            else
                designFcn = @fdesign.interpolator;
                Fs = Fs*2;   % fs is treated as output sample rate
            end
            
            if strcmp(designMethod, 'Elliptic')
                designMethod = 'ellip';
            else
                designMethod = 'iirlinphase';
            end
            
            % Suppress warnings for designs that do not converge. Instead,
            % an error will be thrown later.
            w1 = warning('off','MATLAB:nearlySingularMatrix');
            w2 = warning('off','dsp:fdfmethod:iirhalfbandeqripfpass:actualdesign:iterationLimit');
            w1Cleanup = onCleanup(@() warning(w1));
            w2Cleanup = onCleanup(@() warning(w2));
            % Suppress MFILT deprecation warning on calling design method
            % without "SystemObject" flag set to true.
            w3 = warning('off','dsp:fdesign:basecatalog:UseSystemObjectForMultirateDesigns');
            w3Cleanup = onCleanup(@() warning(w3));
            
            try %#ok
                switch spec
                    case 'Transition width and stopband attenuation'
                        designArgs = {designFcn, 2, 'Halfband', 'TW,Ast', ...
                            designParam1, designParam2};
                        if ~isNormalized
                            designArgs = [designArgs,Fs];
                        end
                        fd = feval(designArgs{:});
                        iirhb = design(fd, designMethod,SystemObject=true);
                        c = coeffs(iirhb);
                    case 'Filter order and transition width'
                        designArgs = {designFcn, 2, 'Halfband', 'N,TW', ...
                            designParam1, designParam2};
                        if ~isNormalized
                            designArgs = [designArgs,Fs];
                        end
                        fd = feval(designArgs{:});
                        iirhb = design(fd, designMethod,SystemObject=true);
                        c = coeffs(iirhb);
                    case 'Filter order and stopband attenuation'
                        designArgs = {designFcn, 2, 'Halfband', 'N,Ast', ...
                            designParam1, designParam2};
                        if ~isNormalized
                            designArgs = [designArgs,Fs];
                        end
                        fd = feval(designArgs{:});
                        iirhb = design(fd, designMethod,SystemObject=true);
                        c = coeffs(iirhb);
                end
            catch ME
                if (strcmp(ME.identifier,'dsp:fdfmethod:iirhalfbandeqripmin:actualdesign:notConverging'))
                    coder.internal.errorIf(1, ...
                        'dsp:system:IIRHalfbandInterpolator:noConvergenceQuasiLinearPhase');
                else
                    rethrow(ME);
                end
            end
            
            % Based on the design method, return the coefficients in a
            % structure. 
            
            % Noble identities have been applied to the coefficients
            % already and we will be using efficient polyphase
            % implementation.
            
            if strcmp(designMethod, 'ellip')
                % Get vector of coefficients for sections of first branch
                % Each section is first order allpass filter
                firstBranchCoeffs = structfun(@(x) x(1), c.Polyphase.Phase1);
                
                % Get vector of coefficients for sections of second branch
                % Each section is first order allpass filter
                secondBranchCoeffs = structfun(@(x) x(1), c.Polyphase.Phase2);
                if isequal(secondBranchCoeffs, 1)
                    % Edge case - when filter order is 3, second branch
                    % does not have any allpass section
                    secondBranchCoeffs = [];
                end
                
                binfo1.MaxOrder = uint32(1);
                binfo1.NumFOS = uint32(length(firstBranchCoeffs));
                binfo1.NumSOS = uint32(0);
                binfo1.WDFTypeFOS = [];
                binfo1.WDFTypeSOS = [];

                bcoef1.FirstOrderSectionCoeffs= cast(firstBranchCoeffs, dType);
                bcoef1.SecondOrderSectionCoeffs = [];

                binfo2.MaxOrder = uint32(1);
                binfo2.NumFOS = uint32(length(secondBranchCoeffs));
                binfo2.NumSOS = uint32(0);
                binfo2.WDFTypeFOS = [];
                binfo2.WDFTypeSOS = [];
                delayVal = 0;
                bcoef2.FirstOrderSectionCoeffs= cast(secondBranchCoeffs, dType);
                bcoef2.SecondOrderSectionCoeffs = [];
            else
                
                % First branch is a pure delay
                binfo1.MaxOrder = uint32(0);
                binfo1.NumFOS = uint32(0); 
                binfo1.NumSOS = uint32(0);
                delayVal = length(c.Polyphase.Phase1.Section1)-1;
                binfo1.WDFTypeFOS = [];
                binfo1.WDFTypeSOS = [];

                bcoef1.FirstOrderSectionCoeffs= [];
                bcoef1.SecondOrderSectionCoeffs = [];

                % Second branch can have a mix of 1st order and 2nd order sections
                secondBranchSections = structfun(@(x) x, ...
                    c.Polyphase.Phase2, 'UniformOutput', false);
                fNames = fieldnames(secondBranchSections);
                secondBranchSectionOrders = structfun(@(x) size(x,2), secondBranchSections);
                firstOrderSections = fNames(secondBranchSectionOrders==1);
                secondOrderSections = fNames(secondBranchSectionOrders==2);
                
                firstOrderCoeffs = [];
                secondOrderCoeffs = [];
                binfo2.MaxOrder = 1;
                for idx = 1:length(firstOrderSections)
                    firstOrderCoeffs = [firstOrderCoeffs; ...
                        secondBranchSections.(firstOrderSections{idx})]; %#ok
                end
                for idx = 1:length(secondOrderSections)
                    secondOrderCoeffs = [secondOrderCoeffs; ...
                        secondBranchSections.(secondOrderSections{idx})]; %#ok
                    binfo2.MaxOrder = 2;
                end
                
                bcoef2.FirstOrderSectionCoeffs = cast(firstOrderCoeffs, dType);
                binfo2.NumFOS = uint32(size(firstOrderCoeffs,1));
                bcoef2.SecondOrderSectionCoeffs = cast(secondOrderCoeffs, dType);
                binfo2.NumSOS = uint32(size(secondOrderCoeffs,1));
                binfo2.WDFTypeFOS = [];
                binfo2.WDFTypeSOS = [];
            end
        end
    end
    %----------------------------------------------------------------------
    % Hidden methods
    %----------------------------------------------------------------------
    methods (Hidden)
        function flag = isPropertyActive(obj,prop)
            % Need to implement this for dsp.internal.FilterAnalysisMultirate
            flag = ~isInactivePropertyImpl(obj, prop);      
        end
        %------------------------------------------------------------------
        function props = getFixedPointProperties(~)
            % Need to implement this for dsp.internal.FilterAnalysisMultirate
            props = {};
        end
        %------------------------------------------------------------------
        function restrictionsCell = getFixedPointRestrictions(~,~)
            % Need to implement this for dsp.internal.FilterAnalysisMultirate
            restrictionsCell = {};
        end
        function [flag,errID] = isFVtoolSupported(obj)
            % Specify if fvtool plot is supported, and what error should be
            % used when it is not supported.
            flag = true;
            errID = [];
            if strcmp(obj.Specification, 'Coefficients')
               if (strcmp(obj.Structure,'Minimum multiplier') && obj.CoefficientsPort)
                   flag = false;
                   errID = 'dsp:system:Shared:fvtoolButtonSpecifyCoefficientsText';
               end
            elseif isprop(obj, 'SampleRateMode')
                if isSampleRateInherited(obj)
                    flag = false;
                    errID = 'dsp:system:Shared:fvtoolButtonInheritSRTexDropdown';
                end
            end
        end
    end
end
