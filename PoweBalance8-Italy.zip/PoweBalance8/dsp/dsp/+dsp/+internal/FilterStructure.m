classdef  (StrictDefaults) FilterStructure < dsp.internal.FilterAnalysis &...
                            dsp.internal.FilterCodeGenerator &...
                            matlab.System
%FilterStructure Baseclass for dsp.FilterCascade and dsp.ParallelFilter
  
%   Copyright 2023 The MathWorks, Inc.

properties (Constant, Hidden, Abstract)
   ChildLabel; % Either Stage or Branch
end

methods (Abstract, Hidden)
    n = numChildren(obj)
    h = child(obj, n)
    b = clonedChildren(obj)
end

methods
    function obj = FilterStructure(varargin)

    end

    function flag = isequal(obj, obj2)
        flag = false;
        if ~isa(obj2, class(obj))
            return;
        end

        if obj.clonedChildren() ~= obj2.clonedChildren()
            return
        end

        if obj.numChildren()~= obj2.numChildren()
            return
        end

        for idx = 1:obj.numChildren()
            if ~isequal(obj.child(idx), obj2.child(idx))
                return
            end
        end

        flag = true;
    end

    function s = coeffs(obj,varargin)
    %COEFFS Returns the filter System object coefficients in a structure
    %   S = coeffs(filt) Returns the coefficients of filter System object, filt,
    %   in the structure S.
    %
    %   S = coeffs(filt,'Arithmetic',ARITH,...) analyzes the filter System
    %   object, filt, based on the arithmetic specified in the ARITH input.
    %   ARITH can be set to one of 'double', 'single', or 'fixed'. The
    %   analysis tool assumes a double precision filter when the arithmetic
    %   input is not specified and the filter System object is in an
    %   unlocked state. The coeffs method returns the quantized filter
    %   coefficients when ARITH is set to 'single' or 'fixed'.

        if isa(obj,'dsp.FilterCascade')
            label = 'Stage';
        else
            label = 'Branch';
        end

        s = struct();
        for n=1:obj.numChildren()
            cn = obj.child(n);
            if ~obj.isNumericScalarFilter(cn)
                s.(sprintf('%s%i',label, n)) = coeffs(cn, varargin{:});
            else
                s.(sprintf('%s%i',label, n)) = struct(Gain=cn);
            end
        end
    end
end


methods(Access=protected)
   function releaseChildren(obj)
    %releaseChildren Release the locked state of all branches/stages
        for idx = 1:obj.numChildren()
            if ~obj.isNumericScalarFilter(obj.child(idx))
                release(obj.child(idx));
            end
        end
   end 

   %----------------------------------------------------------------------
   function filterClone = checkFilterAndClearMetadata(obj, filter, currentval)
       %Checks filter type and clears fdesign metadata
       if isa(obj,'dsp.FilterCascade')
           idprefix = 'dsp:system:FilterCascade:';
       else
           idprefix = 'dsp:system:ParallelFilter:';
       end

       % If filter is numeric, make sure it is a scalar
       if isnumeric(filter) && ~isscalar(filter)
           coder.internal.error([idprefix 'invalidScalarType'],['[' num2str(size(filter)) ']']);
       end

       coder.internal.errorIf(~(isa(filter, 'dsp.internal.FilterAnalysis') ...
           || obj.isNumericScalarFilter(filter)), [idprefix 'invalidChildType'],class(filter));

       % If the structure uses original handles rather than clones, make
       % sure there are no multiple reference or cyclic reference
       if ~obj.clonedChildren()
           if (currentval==filter)
               filterClone = filter;
               clearMetaData(obj);
               return
           end

           % Check that stage is not already contained within obj
           p = searchHandle(obj, filter);
           coder.internal.errorIf(p=="obj", [idprefix 'handleExists_root']);
           coder.internal.errorIf(~isempty(p), [idprefix 'handleAlreadyExistsInObj'],p);

           % Check that obj is not contained within the new stage (if it is a
           % cascade or a parallel)
           if isa(filter, 'dsp.internal.FilterStructure')
               p = searchHandle(filter, obj);
               coder.internal.errorIf(~isempty(p), [idprefix 'objHandleExistsInChild'],p);
           end
       end

       if obj.clonedChildren()  && ~obj.isNumericScalarFilter(filter)
           filterClone = clone(filter);
       else
           filterClone = filter;
       end
       clearMetaData(obj);
   end

   %------------------------------------------------------------------
   function n = getNumInputsImpl(~)
       % FilterCascade objects expect a single input
       n=1;
   end
   %------------------------------------------------------------------
   function flag = isInputSizeMutableImpl(~,~)
       % FilterCascade objects allow mutable inputs by default. If
       % any of the stages rejects mutable inputs, it will error out.
       flag = true;
   end

   %------------------------------------------------------------------
   function flag = isInactivePropertyImpl(obj,prop)
       flag = false; % Assume visible property first

       % Handle 'StageN' properties
       if startsWith(prop,obj.ChildLabel)
           % Extract from 'StageN'/'BranchN' the value of N
           P = digitsPattern;
           snum = extract(prop,P);

           if ~isempty(snum)
               snum = str2double(snum{1});
               flag = (obj.numChildren() < snum);
               return;
           end
       end

       switch prop
           case {'CloneStages','CloneBranches'}
               flag = false;
       end
   end
   %------------------------------------------------------------------
   function validateInputsImpl(obj,u)
       % cache the input data type
       if isempty(coder.target) && ~isempty(u)
           cacheInputDataType(obj, u)
       end
   end

   %------------------------------------------------------------------
   function validatePropertiesImpl(obj)
        if isa(obj, 'dsp.FilterCascade')
            idprefix = 'dsp:system:FilterCascade:';
       else
            idprefix = 'dsp:system:ParallelFilter:';
       end

       % Make sure all stages/branches have a single port
       for n=1:obj.numChildren()
           stg = obj.child(n);
           if ~obj.isNumericScalarFilter(stg)
               if (isprop(stg,'NumeratorSource') && stg.NumeratorSource=="Input port")
                   coder.internal.error([idprefix 'invalidCoeffSource'], n, 'NumeratorSource');
               end

               if (isprop(stg,'CoefficientSource') && stg.CoefficientSource=="Input port")
                   coder.internal.error([idprefix 'invalidCoeffSource'], n, 'CoefficientSource');
               end

               if (isprop(stg,'SOSMatrixSource') && stg.SOSMatrixSource=="Input port")
                   coder.internal.error([idprefix 'invalidCoeffSource'], n, 'SOSMatrixSource');
               end
           end
       end
   end

   %------------------------------------------------------------------
   function releaseImpl(obj)
       releaseChildren(obj);
   end

   %------------------------------------------------------------------
   function resetImpl(obj)
       for idx = 1:obj.numChildren()
           if ~obj.isNumericScalarFilter(obj.child(idx))
               reset(obj.child(idx));
           end
       end
   end

end

methods (Hidden, Static)
    function flag = isNumericScalarFilter(filter)
        flag = isnumeric(filter) && isscalar(filter);
    end    
end

methods(Hidden)
   %------------------------------------------------------------------
    function flag = isPropertyActive(obj,prop)
        flag = ~isInactivePropertyImpl(obj, prop);
    end
    
    %------------------------------------------------------------------
    function props = getNonFixedPointProperties(obj)
        props = properties(obj);
    end
    
    %------------------------------------------------------------------
    function props = getFixedPointProperties(~)
        props = {};
    end
    
    %------------------------------------------------------------------
    function restrictionsCell = getFixedPointRestrictions(~,~)
        restrictionsCell = {};
    end

    %----------------------------------------------------------------------
    function p = searchHandle(obj, H)
        p = '';

        % If H is not a handle, nothing to search
        if obj.isNumericScalarFilter(H)
            return;
        end

        % First, check self
        if H==obj
            p = 'obj';
            return;
        end

        for k=1:obj.numChildren()
            stgk = obj.child(k);

            if isa(stgk,'dsp.internal.FilterStructure')
                subp = searchHandle(stgk, H);
                if ~isempty(subp)
                    if subp~="obj"
                        p = sprintf('%s%u.%s', obj.ChildLabel, k, subp);
                    else
                        p = sprintf('%s%u', obj.ChildLabel, k);
                    end
                    % Chain path and return
                    return
                end
            elseif isa(stgk,'dsp.internal.FilterAnalysis') && stgk==H
                p = sprintf('%s%u',obj.ChildLabel,k);
                % Chain path and return
                return
            end
        end
    end
end

%----------------------------------------------------------------------
% Hidden Static methods
%----------------------------------------------------------------------
methods (Hidden, Static)
    function flag = isAllowedInSystemBlock(~)
        % dsp.FilterCascade and dsp.ParallelFilter are not allowed to be
        % used as System blocks
        flag = false;
    end
end

end
