classdef (StrictDefaults)PhaseDifferentiator < matlab.System
%   PhaseDifferentiator Compute phase difference of input
%   H = dsp.internal.PhaseDifferentiator returns a System object, H, that
%   computes the phase difference between consecutive samples of the
%   complex input.
%
%   H = dsp.internal.PhaseDifferentiator('Name', Value, ...) returns a Phase
%   Differentiator System object, H, with each specified property name set
%   to the specified value. You can specify additional name-value pair
%   arguments in any order as (Name1,Value1,...,NameN, ValueN).
%
%   Step method syntax:
%
%   p = step(H, X) computes the phase difference, p, of complex or real
%   input X. Each column of X is a channel. The System object computes the
%   phase difference of each channel of the input signal independently over
%   time.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%
%   PhaseDifferentiator methods:
%
%   step                     - Compute phase difference of input
%   release                  - Allow property value and input 
%                              characteristics changes, and release Phase 
%                              Differentiator resources
%   clone                    - Create Phase Differentiator object with same
%                              property values
%   isLocked                 - Display locked status (logical)
%   reset                    - Reset the states of the Phase Differentiator
%
%   Differentiator properties:
%
%   TreatFramesIndependently - Compute difference only within the frame
   
% Copyright 2014-2020 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCLS>
    properties (Nontunable)
        % Compute phase difference only within the frame
        % Specify if the phase difference is to be computed only within the
        % frame, as a logical scalar. When this property is set to false,
        % the object returns the phase difference while ignoring boundaries
        % between input frames. If the property is set to true, the object
        % treats each frame of input data independently, and resets the
        % initial sample value to 1+0j each time a new input frame is
        % received. The default of this property is false.
        TreatFramesIndependently (1, 1) logical = false;
    end
    
    properties (Nontunable, Access = private)
        % Cache input dimensions. This property is used when this object
        % is used via composition in another object (e.g.
        % PhaseExtractor). The top object is responsible for setting
        % the input dimension on this object.
        pInputDims = -1
    end
    
    properties (Access = private)
        % pLastSample - Last input sample in memory
        pLastSample;
        % pNumChans - Number of channels. This property is used to disallow
        % variable number of channels while allowing variable frame length.
        pNumChans;
    end
    
    properties (Access = private, Nontunable) % 
        % pCompiledNumChans - Number of channels. This property is used to
        % set object states.
        pCompiledNumChans;
    
        % pHasState - Property is true if TreatFramesIndependently is
        % false, and is false is TreatFramesIndependently is true
        pHasState (1, 1) logical;
    end
    
    methods
        % Constructor
        function obj = PhaseDifferentiator(varargin)
            setProperties(obj,nargin,varargin{:});
            obj.pNumChans = int32(-1);
        end
    end
    
    methods (Hidden)
        function cacheInputDimensions(obj,dims)
            obj.pInputDims = dims;
        end
    end
    
    methods (Access = protected)

        function setupImpl(obj,u)
            if obj.pInputDims >= 0
              obj.pNumChans = int32(obj.pInputDims);
              obj.pCompiledNumChans = obj.pInputDims;
            else
                numChans = getNumChannels(obj,u);
                obj.pNumChans = int32(numChans);
                obj.pCompiledNumChans = numChans;
            end
            obj.pLastSample = ones(1,obj.pCompiledNumChans ,'like',u);
            obj.pHasState = ~obj.TreatFramesIndependently;
        end
        
        function phase = stepImpl(obj,x)
            % Update phase
            if obj.pHasState
                [phase,sample] = dsp.internal.phasedifference(x,obj.pLastSample);
                obj.pLastSample = sample(1,1:obj.pCompiledNumChans); 
            else
                phase =  dsp.internal.phasedifference(x,obj.pLastSample);
            end
        end
 
        function resetImpl(obj)
            obj.pLastSample = ones(size(obj.pLastSample),...
                                  'like',obj.pLastSample);
        end
        
        function releaseImpl(obj)
            obj.pNumChans = int32(-1);
        end
        
        function numchans = getNumChannels(obj,u)
            % GETNUMCHANNELS Return the number of input channels
            if obj.getExecPlatformIndex()
                thisSize = propagatedInputSize(obj, 1);
                numchans = thisSize(2);
            else
                numchans = size(u,2);
            end
        end
        
        %% Propagators
        function varargout = isOutputComplexImpl(~)
            varargout = {false}; 
        end
        
        function varargout = getOutputSizeImpl(obj)
            varargout = {propagatedInputSize(obj, 1)}; 
        end
        
        function varargout = getOutputDataTypeImpl(obj)
            varargout = {propagatedInputDataType(obj, 1)}; 
        end
        
        %% Backup/restore functions
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            % Save private properties
            if isLocked(obj)
                s.pLastSample = obj.pLastSample;
                s.pCompiledNumChans = obj.pCompiledNumChans;
                s.pNumChans = obj.pNumChans;
                s.pHasState = obj.pHasState;
                s.pInputDims = obj.pInputDims;
            end
        end
        
        function loadObjectImpl(obj,s,wasLocked)
            % Re-load private properties
            if wasLocked
                obj.pLastSample = s.pLastSample;
                obj.pHasState = s.pHasState;
                obj.pCompiledNumChans = s.pCompiledNumChans;
                obj.pNumChans = s.pNumChans;
            end
            if isfield(s,'pInputDims')
               obj.pInputDims = s.pInputDims;
            end
            % Call base class method
            loadObjectImpl@matlab.System(obj, s, wasLocked);
        end
        
        function validateInputsImpl(obj,u)
            % Validate inputs to the step method at initialization.
            validateattributes(u,{'double','single'}, {'2d',...
                'nonsparse'},'','input'); 
            % The number of input channels is not allowed to change.
            coder.internal.errorIf(obj.pNumChans~=-1 && ...
                                   obj.pNumChans ~= size(u,2), ...
                                  'dsp:system:varSizeChannelsNotSupported')
        end
        
        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end
        
        function flag = isInputComplexityMutableImpl(~,~)
            flag = true;
        end
        
        function icon = getIconImpl(~)
            % MATLAB system block icon
            icon = getString(message('dsp:system:PhaseDifferentiator:BlockIcon'));
        end
    end
    
    %----------------------------------------------------------------------
    % Static, Protected methods
    %----------------------------------------------------------------------
    methods(Static, Access=protected)
        function group = getPropertyGroupsImpl
            % Modify order of display
            group =  matlab.system.display.Section(...
                'Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', {'TreatFramesIndependently'});
        end
        
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header...
                ('dsp.internal.PhaseDifferentiator', ...
                'ShowSourceLink', true, ...
                'Title', getString(message('dsp:system:PhaseDifferentiator:BlockName')),...
                'Text',  getString(message('dsp:system:PhaseDifferentiator:BlockHeader')));
        end
    end
end
