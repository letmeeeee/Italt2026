classdef NoPartitionOA < dsp.internal.NoPartitionOAOSBase
% NoPartitionOA Classic overlap-add filter. 
% This class is used in dsp.FrequencyDomainFIRFilter

% Copyright 2017-2022 The MathWorks, Inc.

 %#codegen
    
    methods
        function obj = NoPartitionOA(varargin)
            setProperties(obj,nargin,varargin{:});
        end
    end
    
    methods (Access = protected)
        
        function setupImpl(obj,u)
            setupImpl@dsp.internal.NoPartitionOAOSBase(obj,u);
            
            if obj.pIsOutputReal
                obj.pLastSection = zeros(obj.pFilterLength - 1,obj.numChannels,obj.pDatatype);
            else
                obj.pLastSection = zeros(obj.pFilterLength - 1,obj.numChannels,obj.pDatatype) + 1j *  zeros(obj.pFilterLength - 1,obj.numChannels,obj.pDatatype);
            end
        end
        
    end
    
    methods (Static)
        
        % Implement overlap-add
        function [o,prevsec] = computeOutput(input,L,numFrames,numChannels,H,fftlen,filtlen,prevsec,isOutReal,halideMode)
            
            % input       : Input samples
            % L           : Number of samples to keep (save) from each computed FFT
            % numFrames   : Number of input frames
            % numChannels : Number of input channels
            % H           : FFT of filter numerator
            % fftlen      : FFT length
            % prevsec     : State (samples from previous segment to be added)
            % o           : Output filtered samples
            
            zs   = reshape(input,L,numFrames,numChannels);

            if(isempty(coder.target))
                % Halide's performance is optimal for cases with
                % filter length less than 1024.
                if (halideMode == 2) ||(filtlen<1024 && (halideMode == 1))
                    zfft = complex(fft(zs,fftlen,1));
                    Z = complex(zeros(fftlen, numFrames, numChannels, class(input)));

                    if isreal(H)
                        H = complex(H);
                    end

                    dsp.internal.builtins.FrequencyDomainFIRFilter(1, zfft, H, Z, fftlen, numChannels, numFrames);
                else
                    Z = bsxfun(@times, fft(zs,fftlen,1), H);
                end
            else
                if coder.const(feval('dsp.enhancedsim.IsSysObjSimInCodeGen', coder.target)) && coder.const(halideMode)

                    zfft = complex(fft(zs,fftlen,1));
                    Z = complex(zeros(fftlen, numFrames, numChannels, class(input)));

                    if isreal(H)
                        pH = complex(H);
                        Z = dsp.internal.FrequencyDomainFIRFilterCGSim("NoPartitionOA", zfft, pH, Z, fftlen, numChannels, numFrames);
                    else
                        Z = dsp.internal.FrequencyDomainFIRFilterCGSim("NoPartitionOA", zfft, H, Z, fftlen, numChannels, numFrames);
                    end

                else
                    Z = bsxfun(@times, fft(zs,fftlen,1), H);
                end
            end

            if isOutReal
                o = zeros(L*numFrames,numChannels,class(input));
                zout = real(ifft(Z,fftlen));
            else
                o = zeros(L*numFrames,numChannels,class(input)) + 1j * zeros(L*numFrames,numChannels,class(input));
                zout = ifft(Z,fftlen);
            end

            for index = 1:numFrames
                zout(1:filtlen-1,index,:)  = squeeze(zout(1:filtlen-1,index,:)) + prevsec;
                prevsec(:,:)               = squeeze(zout(fftlen - filtlen + 2:end,index,:));
                o((index-1)*L+1:L*index,:) = zout(1:L,index,:);
            end

        end

    end
end
