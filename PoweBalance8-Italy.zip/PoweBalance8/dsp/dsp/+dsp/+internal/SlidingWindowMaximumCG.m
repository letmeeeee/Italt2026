classdef SlidingWindowMaximumCG < dsp.internal.AbstractSlidingWindowMinMaxCG
    % SlidingWindowMaximumCG This class is internally used by
    % dsp.MovingMinimum
    
    %#codegen
    
    methods
        function obj = SlidingWindowMaximumCG(varargin)
            setProperties(obj,nargin,varargin{:});
        end
    end
    
    methods (Access = protected)
        
        function z = compareElements(obj,x,y) %#ok
           z = (x<y); 
        end
        
    end

end