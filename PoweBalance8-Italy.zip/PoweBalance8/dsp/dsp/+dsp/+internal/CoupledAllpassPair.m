classdef CoupledAllpassPair < matlab.System
    % Legacy coupled allpass pair supporting cell arrays

    %   Copyright 2013-2020 The MathWorks, Inc.

    properties(Nontunable)
        Structure (1, :) char {matlab.system.mustBeMemberMessageID(Structure, ...
            {'dsp:system:CoupledAllpassFilter:Structure_Minimummultiplier'; ...
            'dsp:system:CoupledAllpassFilter:Structure_WaveDigitalFilter'; ...
            'dsp:system:CoupledAllpassFilter:Structure_Lattice'})} = 'Minimum multiplier';
        PureDelayBranch (1, 1) logical = false
    end
    properties
        %AllpassCoefficients1 Allpass polynomial coefficients of branch 1
        %   Specify the polynomial filter coefficients for the first
        %   allpass branch. 
        %   This property is only applicable when the Structure property is
        %   set to 'Minimum multiplier'. The value of this property can 
        %   be either a row vector (single-section configuration) or a cell
        %   array with as many cells as filter sections. The default value 
        %   for this property is {[0 0.5]}. This property is tunable.
        AllpassCoefficients1 = {[0 0.5]}
        %AllpassCoefficients2 Allpass polynomial coefficients of branch 2
        %   Specify the polynomial filter coefficients for the second
        %   allpass branch. 
        %   This property is only applicable when the Structure property is
        %   set to 'Minimum multiplier'. The value of this property can 
        %   be either a row vector (single-section configuration) or a cell
        %   array with as many cells as filter sections. The default value 
        %   for this property is {[]}. This property is tunable.
        AllpassCoefficients2 = {[]}
        %WDFCoefficients1 Wave Digital Filter coefficients of branch 1
        %   Specify the Wave Digital Filter coefficients for the first
        %   allpass branch. 
        %   This property is only applicable when the Structure property is
        %   set to 'Wave Digital Filter'. The value of this property can 
        %   be either a row vector (single-section configuration) or a cell
        %   array with as many cells as filter sections. The default value 
        %   for this property is {[0.5 0]}. This property is tunable.
        WDFCoefficients1 = {[0.5 0]}
        %WDFCoefficients2 Wave Digital Filter coefficients of branch 2
        %   Specify the Wave Digital Filter coefficients for the second
        %   allpass branch. 
        %   This property is only applicable when the Structure property is
        %   set to 'Wave Digital Filter'. The value of this property can 
        %   be either a row vector (single-section configuration) or a cell
        %   array with as many cells as filter sections. The default value 
        %   for this property is {[]}. This property is tunable.
        WDFCoefficients2 = {[]}
        %LatticeCoefficients1 Lattice coefficients of branch 1
        %   Specify the allpass lattice coefficients for the first
        %   allpass branch. 
        %   This property is only applicable when the Structure property is
        %   set to 'Lattice'. The value of this property can 
        %   be either a row vector (single-section configuration) or a cell
        %   array with as many cells as filter sections. The default value 
        %   for this property is {[0.5 0]}. This property is tunable.
        LatticeCoefficients1 = {[0 0.5]}
        %LatticeCoefficients2 Lattice coefficients of branch 2
        %   Specify the allpass lattice coefficients for the second
        %   allpass branch. 
        %   This property is only applicable when the Structure property is
        %   set to 'Lattice'. The value of this property can 
        %   be either a row vector (single-section configuration) or a cell
        %   array with as many cells as filter sections. The default value 
        %   for this property is {[]}. This property is tunable.
        LatticeCoefficients2 = {[]}
        %Beta Coupled phase gain
        %   Specify the value of the phasor gain used in complex conjugate
        %   forms in each of the two branches, respectively, in complex 
        %   coefficient configurations.
        %   This property is only applicable when the selected Structure 
        %   property supports complex coefficients.
        %   The absolute value of this property should be 1 and its
        %   default value is 1. This property is tunable.
        Beta = 1
    end
    
    properties(Nontunable)
        %Delay Delay length in samples for branch 1
        %   Specify the delay length in number of samples for branch 1,
        %   when the latter operates as a pure delay.
        %   This property is only applicable when the PureDelayBranch
        %   property is set to true.
        Delay = 0;
        %Gain1 Independent Branch 1 Phase Gain
        %   Specify the value of the independent phase gain applied to
        %   branch 1.
        %   This property can only accept values equal to '1', '-1', '0+1i'
        %   and '0-1i'. The default value for this property is '1'. 
        %   This property is nontunable.
        Gain1 (1, :) char {matlab.system.mustBeMemberMessageID(Gain1, ...
            {'dsp:system:CoupledAllpassFilter:Gain_1'; ...
            'dsp:system:CoupledAllpassFilter:Gain_Neg1'; ...
            'dsp:system:CoupledAllpassFilter:Gain_1i'; ...
            'dsp:system:CoupledAllpassFilter:Gain_Neg1i'})} = '1'
        %Gain2 Independent Branch 2 Phase Gain
        %   Specify the value of the independent phase gain applied to
        %   branch 2.
        %   This property can only accept values equal to '1', '-1', '0+1i'
        %   and '0-1i'. The default value for this property is '1'. 
        %   This property is nontunable.
        Gain2 (1, :) char {matlab.system.mustBeMemberMessageID(Gain2, ...
            {'dsp:system:CoupledAllpassFilter:Gain_1'; ...
            'dsp:system:CoupledAllpassFilter:Gain_Neg1'; ...
            'dsp:system:CoupledAllpassFilter:Gain_1i'; ...
            'dsp:system:CoupledAllpassFilter:Gain_Neg1i'})} = '1';
        % ComplexConjugateCoefficients Allows inferring the coefficients
        %   of the second allpass branch as complex conjugate of the first.
        %   When the input signal is real this triggers the use of an
        %   optimized structural realization. This property is only enabled
        %   if the currently selected structure supports complex
        %   coefficients, and it should only be used the filter
        %   coefficients are actually complex.
        ComplexConjugateCoefficients (1, 1) logical = false;

        OnlyExecuteTopBranch (1, 1) logical = false;
    end
   
    properties(Access = private)
        % Cell vector of dsp.internal.LegacyAllpassFilter objects
        PrivFilter1
        PrivFilter2
        PrivUsingComplexCoeff
        PrivBeta = 1
        % Handles to multiplying functions for phase gains 1 or 2
        PrivMultiplier1 = @(x) x
        PrivMultiplier2 = @(x) x
     end
    
    methods
        
        function obj = CoupledAllpassPair(varargin)
            setProperties(obj,length(varargin),varargin{:});
        end
        
        function set.AllpassCoefficients1(obj, value)
            % Validate using underlying rules in dsp.internal.LegacyAllpassFilter
            % StructureId = 1
            coe = dsp.internal.LegacyAllpassFilter.validateUserCoefficients(value, 1);
            obj.AllpassCoefficients1 = coe;
        end
            
        function set.AllpassCoefficients2(obj, value)
            % Validate using underlying rules in dsp.internal.LegacyAllpassFilter
            % StructureId = 1
            coe = dsp.internal.LegacyAllpassFilter.validateUserCoefficients(value, 1);
            obj.AllpassCoefficients2 = coe;
        end
            
        function set.WDFCoefficients1(obj, value)
            % Validate using underlying rules in dsp.internal.LegacyAllpassFilter
            % StructureId = 2
            coe = dsp.internal.LegacyAllpassFilter.validateUserCoefficients(value, 2);
            obj.WDFCoefficients1 = coe;
        end
            
        function set.WDFCoefficients2(obj, value)
            % Validate using underlying rules in dsp.internal.LegacyAllpassFilter
            % StructureId = 2
            coe = dsp.internal.LegacyAllpassFilter.validateUserCoefficients(value, 2);
            obj.WDFCoefficients2 = coe;
        end
            
        function set.LatticeCoefficients1(obj, value)
            % Validate using underlying rules in dsp.internal.LegacyAllpassFilter
            % StructureId = 3
            coe = dsp.internal.LegacyAllpassFilter.validateUserCoefficients(value, 3);
            obj.LatticeCoefficients1 = coe;
        end
        
        function set.LatticeCoefficients2(obj, value)
            % Validate using underlying rules in dsp.internal.LegacyAllpassFilter
            % StructureId = 3
            coe = dsp.internal.LegacyAllpassFilter.validateUserCoefficients(value, 3);
            obj.LatticeCoefficients2 = coe;
        end
        
        function set.Beta(obj, value)
            validateattributes(value, {'single','double'}, {'scalar'})
            obj.Beta = value;
        end

        function set.Delay(obj, value)
            validateattributes(value, {'numeric'}, {'scalar', 'integer',...
                'nonnegative'})
            obj.Delay = value;
        end
        
        function set.ComplexConjugateCoefficients(obj, value)
            validateattributes(true, {'binary', 'logical'}, {'scalar'})
            obj.ComplexConjugateCoefficients = logical(value);
        end
        
        function branches = getBranches(obj)
            %getBranches Return internal allpass branches
            %   Return copies of the internal allpass branches, as a
            %   two-field structure. Each branch is an instance of
            %   dsp.internal.LegacyAllpassFilter
            if(~isLocked(obj))
                setup(obj, 0.1, 0.1)
                release(obj)
            end
            branches = struct(...
                'Branch1', clone(obj.PrivFilter1), ...
                'Branch2', clone(obj.PrivFilter2) );
        end
        
    end 
    
    methods (Access = protected)
        
        function setupImpl(obj, u1, u2)
            
            % Create branch filter System objects and store in private
            % properties obj.PrivFilter1 and obj.PrivFilter2
            createBranchFilters(obj)
            
            % Setup branches - only branch 1 if branch 2 does not execute
            if(~obj.OnlyExecuteTopBranch)
                setup(obj.PrivFilter2, u2);
            end
            setup(obj.PrivFilter1, u1);
            
            % Cache use of complex coefficients
            obj.PrivUsingComplexCoeff = supportsComplexCoefficients(obj);
            
            % Define function handles for phase gain multipliers
            setPrivateGainMultiplierFcnHandles(obj, u1, u2);
        end
        
        function resetImpl(obj)
            reset(obj.PrivFilter1)
            reset(obj.PrivFilter2)
        end
        
        function releaseImpl(obj)
            release(obj.PrivFilter1)
            release(obj.PrivFilter2)
        end
        
        function [y1, y2] = stepImpl(obj, u1, u2)

            y1 = step(obj.PrivFilter1, u1);
            y1 = obj.PrivMultiplier1(y1);

            if(~obj.OnlyExecuteTopBranch)

                y2 = step(obj.PrivFilter2, u2);
                y2 = obj.PrivMultiplier2(y2);

            else
                y2 = [];
            end

        end
        
        function flag = isInactivePropertyImpl(obj, propertyName)
            flag = false;
            switch propertyName
                case 'AllpassCoefficients1'
                flag = obj.PureDelayBranch || ...
                    ~strcmp(obj.Structure, 'Minimum multiplier');
                
                case 'AllpassCoefficients2'
                flag = ~strcmp(obj.Structure, 'Minimum multiplier');
                
                case 'WDFCoefficients1'
                flag = obj.PureDelayBranch || ...
                    ~strcmp(obj.Structure, 'Wave Digital Filter');
                
                case 'WDFCoefficients2'
                flag = ~strcmp(obj.Structure, 'Wave Digital Filter');
                
                case 'LatticeCoefficients1'
                flag = obj.PureDelayBranch || ...
                    ~strcmp(obj.Structure, 'Lattice');
                
                case 'LatticeCoefficients2'
                flag = ~strcmp(obj.Structure, 'Lattice');

                case 'Delay'
                flag = ~obj.PureDelayBranch;
                
                case 'ComplexConjugateCoefficients'
                flag = obj.PureDelayBranch || ...
                    ~supportsComplexCoefficients(obj);
                
                case 'Beta'
                flag = ~supportsComplexCoefficients(obj);
                    
                case 'OnlyExecuteTopBranch'
                flag = ~obj.ComplexConjugateCoefficients;

            end
        end
        
        function num = getNumInputsImpl(~)
            num = 2;
        end
        
        function num = getNumOutputsImpl(~)
            num = 2;
        end
        
        function s = saveObjectImpl(obj)
            % Default implementation saves all public properties
            s = saveObjectImpl@matlab.System(obj);

            if isLocked(obj)
                % The following are set at setup
                s.PrivFilter1 = matlab.System.saveObject(obj.PrivFilter1);
                s.PrivFilter2 = matlab.System.saveObject(obj.PrivFilter2);
                s.PrivBeta = obj.PrivBeta;
                s.PrivMultiplier1 = obj.PrivMultiplier1;
                s.PrivMultiplier2 = obj.PrivMultiplier2;
            end
        end
        
        function loadObjectImpl(obj, s, wasLocked)
            % Re-load state if saved version was locked
            if wasLocked
                % The following were set at setup
                obj.PrivFilter1 = matlab.System.loadObject(s.PrivFilter1);
                obj.PrivFilter2 = matlab.System.loadObject(s.PrivFilter2);
                obj.PrivBeta = s.PrivBeta;
                obj.PrivMultiplier1 = s.PrivMultiplier1;
                obj.PrivMultiplier2 = s.PrivMultiplier2;
            end

            % Call base class method
            loadObjectImpl@matlab.System(obj,s,wasLocked);
        end

        function s = getDiscreteStateImpl(obj)
            if(~isLocked(obj))
                ds1 = [];
                ds2 = [];
            else
                branch2ds = getDiscreteState(obj.PrivFilter2);
                ds2 = {branch2ds.FilterStates};
                if(~obj.PureDelayBranch)
                    branch1ds = ...
                        getDiscreteState(obj.PrivFilter1);
                    ds1 = {branch1ds.FilterStates};
                else
                    ds1 = [];
                end
            end
            s = struct(...
                'Branch1', ds1,...
                'Branch2', ds2);
        end

        function setDiscreteStateImpl(~, ~)
            coder.internal.warning(['dsp:system:CoupledAllpassFilter:',...
                'setDSNotAllowed'])
        end

        function validateInputsImpl(obj, u1, u2)
            % Invoked at first call to setup/step, and then every time the
            % input dimensions change
            validateCurrentInputs(obj, u1, u2);
        end
        
        function processTunedPropertiesImpl(obj)
            % Propagate coefficients changes to child objects
            propagateRelevantCoefficientsToBranches(obj)
        end
        
end
    
    methods
        
        function doesit = supportsComplexCoefficients(obj)
            StructuresWithComplexCoe = {'Lattice'};
            doesit = any(strcmp(obj.Structure, StructuresWithComplexCoe));
        end
        
        function isit = isSecondBranchInferred(obj)
            supportsComplex = supportsComplexCoefficients(obj);
            isit = supportsComplex ...
                && obj.ComplexConjugateCoefficients;
        end
        
        function setActiveCoefficientsForBranch(obj, BranchId, coe)
            switch obj.Structure
                case 'Minimum multiplier'
                    if(BranchId == 1)
                        obj.AllpassCoefficients1 = coe;
                    elseif(BranchId == 2)
                        obj.AllpassCoefficients2 = coe;
                    else
                        assert(false)
                    end
                case 'Wave Digital Filter'
                    if(BranchId == 1)
                        obj.WDFCoefficients1 = coe;
                    elseif(BranchId == 2)
                        obj.WDFCoefficients2 = coe;
                    else
                        assert(false)
                    end
                case 'Lattice'
                    if(BranchId == 1)
                        obj.LatticeCoefficients1 = coe;
                    elseif(BranchId == 2)
                        obj.LatticeCoefficients2 = coe;
                    else
                        assert(false)
                    end
                otherwise
                    assert(false)
            end

        end
        
        function coe = getActiveCoeffsInBranch(obj, branchNumber)
            switch obj.Structure
                case 'Minimum multiplier'
                    if(branchNumber == 1)
                        coe = obj.AllpassCoefficients1;
                    elseif(branchNumber == 2)
                        coe = obj.AllpassCoefficients2;
                    else
                        assert(false)
                    end
                case 'Wave Digital Filter'
                    if(branchNumber == 1)
                        coe = obj.WDFCoefficients1;
                    elseif(branchNumber == 2)
                        coe = obj.WDFCoefficients2;
                    else
                        assert(false)
                    end
                case 'Lattice'
                    if(branchNumber == 1)
                        coe = obj.LatticeCoefficients1;
                    elseif(branchNumber == 2)
                        coe = obj.LatticeCoefficients2;
                    else
                        assert(false)
                    end
                otherwise
                    assert(false)
            end
        end
        
        function propagateRelevantCoefficientsToBranches(obj)
            br1 = obj.PrivFilter1;
            br2 = obj.PrivFilter2;
            
            if(~obj.PureDelayBranch)
                % Both branches are allpass filters
                coe1 = getActiveCoeffsInBranch(obj, 1);
                if(~isSecondBranchInferred(obj))
                    coe2 = getActiveCoeffsInBranch(obj, 2);
                else
                    coe2 = cellfun(@conj, coe1, 'UniformOutput', false);
                end
                setActiveCoefficients(br1, coe1);
                setActiveCoefficients(br2, coe2);
            else
                % Branch 1 is pure delay
                % Delay is nontunable - only propagate if object is not
                % locked
                if(~isLocked(obj))
                    d = obj.Delay;
                    br1.Length = d;
                end
                % Branch 2 is allpass filter
                coe2 = getActiveCoeffsInBranch(obj, 2);
                setActiveCoefficients(br2, coe2);
            end
            
            obj.PrivFilter1 = br1;
            obj.PrivFilter2 = br2;
        end
        
        function createBranchFilters(obj)
            
            if(~obj.PureDelayBranch)
                % Both branches are allpass filters
                
                % Branch 1
                coe1 = getActiveCoeffsInBranch(obj, 1);
                createAllpassBranch(obj, coe1, 1);
                % Branch 2
                if(~isSecondBranchInferred(obj))
                    coe2 = getActiveCoeffsInBranch(obj, 2);
                else
                    coe2 = cellfun(@conj, coe1, 'UniformOutput', false);
                end
                createAllpassBranch(obj, coe2, 2);

            else
                % Branch 1 is pure delay, Branch 2 is allpass not inferred
                
                % Branch 1
                obj.PrivFilter1 = dsp.Delay('Length', obj.Delay);

                % Branch 2
                coe2 = getActiveCoeffsInBranch(obj, 2);
                createAllpassBranch(obj, coe2, 2);
                    
            end
        end
        
        function createAllpassBranch(obj, coefficients, branchNumber)
            assert(any(branchNumber == [1,2]));
            switch obj.Structure
                case 'Minimum multiplier'
                    switch branchNumber
                        case 1
                            obj.PrivFilter1 = dsp.internal.LegacyAllpassFilter( ...
                                'Structure', 'Minimum multiplier', ...
                                'AllpassCoefficients', coefficients);
                        case 2
                            obj.PrivFilter2 = dsp.internal.LegacyAllpassFilter( ...
                                'Structure', 'Minimum multiplier', ...
                                'AllpassCoefficients', coefficients);
                    end
                case 'Wave Digital Filter'
                    switch branchNumber
                        case 1
                            obj.PrivFilter1 = dsp.internal.LegacyAllpassFilter( ...
                                'Structure', 'Wave Digital Filter', ...
                                'WDFCoefficients', coefficients);
                        case 2
                            obj.PrivFilter2 = dsp.internal.LegacyAllpassFilter( ...
                                'Structure', 'Wave Digital Filter', ...
                                'WDFCoefficients', coefficients);
                    end
                case 'Lattice'
                    switch branchNumber
                        case 1
                            obj.PrivFilter1 = dsp.internal.LegacyAllpassFilter( ...
                                'Structure', 'Lattice', ...
                                'LatticeCoefficients', coefficients);
                        case 2
                            obj.PrivFilter2 = dsp.internal.LegacyAllpassFilter( ...
                                'Structure', 'Lattice', ...
                                'LatticeCoefficients', coefficients);
                    end
            end

        end
        
        function validateCurrentInputs(~, u1, u2)
            validateattributes(u1, {'single', 'double'}, {'2d'})
            if(~isempty(u2))
                validateattributes(u2, {class(u1)}, {'size', size(u1)})
            end
        end

        function [isOut1, isOut2] = arePreGainOutputsReal(obj, u1, u2)
            % One branch at a time - first number 1
            if(obj.PureDelayBranch)
                ap1OutProto = dsp.internal.LegacyAllpassFilter.getPrototype(u1);
            else
                ap1OutProto = dsp.internal.LegacyAllpassFilter.getPrototype(...
                        u1 ,getActiveCoeffsInBranch(obj, 1));
            end
            beta1OutProto = dsp.internal.LegacyAllpassFilter.getPrototype(...
                ap1OutProto, obj.PrivBeta);

            isOut1 = isreal(beta1OutProto);
            
            % Then number 2
            if(~obj.OnlyExecuteTopBranch)
                ap2OutProto = dsp.internal.LegacyAllpassFilter.getPrototype(...
                        u2 ,getActiveCoeffsInBranch(obj, 2));
                beta2OutProto = dsp.internal.LegacyAllpassFilter.getPrototype(...
                    ap2OutProto, obj.PrivBeta);

                isOut2 = isreal(beta2OutProto);
            else
                isOut2 = [];
            end
        end

        function [isOut1Real, isOut2Real] = areOutputsReal(obj, u1, u2)
            
            % Get complexity info for allpass filters and beta multipliers
            [isPgOut1, isPgOut2] = arePreGainOutputsReal(obj, u1, u2);
            
            % One branch at a time - first number 1...
            switch(obj.Gain1)
                case{'1', '-1'}
                    isOut1Real = isPgOut1;
                case{'0+1i', '0-1i'}
                    isOut1Real = false;
                otherwise
                    % No other allowed value for obj.Gain1
                    assert(false)
            end
            
            % ...then number 2
            if(~obj.OnlyExecuteTopBranch)
                switch(obj.Gain2)
                    case{'1', '-1'}
                        isOut2Real = isPgOut2;
                    case{'0+1i', '0-1i'}
                        isOut2Real = false;
                    otherwise
                        % No other allowed value for obj.Gain2
                        assert(false)
                end
            else
                isOut2Real = [];
            end
        end

        function flag = isPropertyActive(obj,prop)
            flag = ~isInactiveProperty(obj, prop);      
        end
        
        function setPrivateGainMultiplierFcnHandles(obj, u1, u2)
            % Define function handles for phase gain multipliers
            [isPregainOut1Real, isPregainOut2Real] = ...
                arePreGainOutputsReal(obj, u1, u2);
            
            coeReal = ~supportsComplexCoefficients(obj);
            
            mh1 = @(x) x;
            if(isPregainOut1Real && coeReal)
                % <Real> * Gain1
                switch(obj.Gain1)
                % case '1', mh1 = @(x) x;
                case '-1', mh1 = @(x) -x;
                case '0+1i', mh1 = @(x) complex(0,x);
                case '0-1i', mh1 = @(x) complex(0,-x);
                % otherwise, assert(false) % No other values for Gain1
                end
            elseif(~isPregainOut1Real && coeReal)
                % <Complex> * Gain1
                switch(obj.Gain1)
                % case '1', mh1 = @(x) x;
                case '-1', mh1 = @(x) -x;
                case '0+1i', mh1 = ...
                        @(x) complex(-imag(x), real(x));
                case '0-1i', mh1 = ...
                        @(x) complex(imag(x), -real(x));
                % otherwise, assert(false) % No other values for Gain1
                end
            elseif(isPregainOut1Real && ~coeReal)
                % <Real> * Gain1 * Beta
                b = cast(obj.Beta, class(u1)); 
                switch(obj.Gain1)
                case '1', mh1 = @(x) x * conj(b);
                case '-1', mh1 = @(x) -x * conj(b);
                case '0+1i', mh1 = @(x) complex(0,x) * conj(b);
                case '0-1i', mh1 = @(x) complex(0,-x) * conj(b);
                % otherwise, assert(false) % No other values for Gain1
                end
            elseif(~isPregainOut1Real && ~coeReal)
                % <Complex> * Gain1 * Beta
                b = cast(obj.Beta, class(u1)); 
                switch(obj.Gain1)
                case '1', mh1 = @(x) x * conj(b);
                case '-1', mh1 = @(x) -x * conj(b);
                case '0+1i', mh1 = ...
                        @(x) complex(-imag(x), real(x)) * conj(b);
                case '0-1i', mh1 = ...
                        @(x) complex(imag(x), -real(x)) * conj(b);
                % otherwise, assert(false) % No other values for Gain1
                end
            end
            
            mh2 = @(x) x;
            if(~isempty(isPregainOut2Real))
                if(isPregainOut2Real && coeReal)
                    % <Real> * Gain2
                    switch(obj.Gain2)
                    % case '1', mh2 = @(x) x;
                    case '-1', mh2 = @(x) -x;
                    case '0+1i', mh2 = @(x) complex(0,x);
                    case '0-1i', mh2 = @(x) complex(0,-x);
                    % otherwise, assert(false) % No other values for Gain2
                    end
                elseif(~isPregainOut2Real && coeReal)
                    % <Complex> * Gain2
                    switch(obj.Gain2)
                    % case '1', mh2 = @(x) x;
                    case '-1', mh2 = @(x) -x;
                    case '0+1i', mh2 = @(x) complex(-imag(x), real(x));
                    case '0-1i', mh2 = @(x) complex(imag(x), -real(x));
                    % otherwise, assert(false) % No other values for Gain2
                    end
                elseif(isPregainOut2Real && ~coeReal)
                    % <Real> * Gain2 * Beta
                    b = cast(obj.Beta, class(u1));
                    switch(obj.Gain2)
                    case '1', mh2 = @(x) x * b;
                    case '-1', mh2 = @(x) -x * b;
                    case '0+1i', mh2 = @(x) complex(0,x) * b;
                    case '0-1i', mh2 = @(x) complex(0,-x) * b;
                    % otherwise, assert(false) % No other values for Gain2
                    end
                elseif(~isPregainOut2Real && ~coeReal)
                    b = cast(obj.Beta, class(u1));
                    % <Complex> * Gain2 * Beta
                    switch(obj.Gain2)
                    case '1', mh2 = @(x) x * b;
                    case '-1', mh2 = @(x) -x * b;
                    case '0+1i', mh2 = ...
                            @(x) complex(-imag(x), real(x)) * b;
                    case '0-1i', mh2 = ...
                            @(x) complex(imag(x), -real(x)) * b;
                    % otherwise, assert(false) % No other values for Gain2
                    end
                end
            end % Else keep default value
            
            obj.PrivMultiplier1 = mh1;
            obj.PrivMultiplier2 = mh2;
            
        end
        
    end
    
end
