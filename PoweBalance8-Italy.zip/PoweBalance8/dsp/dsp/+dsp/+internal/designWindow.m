function window = designWindow(windowType , L , DT , varargin)
% Design a window based on the window type (windowType) and segment length
% (L). The window is designed in the datatype specified by DT. Chebyshev
% and Kaiser windows need an additional SidelobeAttenuation parameter to be
% specified.
%
% Valid values for windowType are:
% 1 = 'Rectangular'
% 2 = 'Hann'
% 3 = 'Hamming'
% 4 = 'Flat Top'
% 5 = 'Chebyshev'
% 6 = 'Kaiser'
% 7 = 'Blackman'

% Copyright 2017 The MathWorks, Inc.

%#codegen
switch windowType
    case 1 %'Rectangular'
        w = ones(L,1);
    case 2 %'Hann'
        w = hann(L,'periodic');
    case 3 %'Hamming'
        w = hamming(L,'periodic');
    case 4 % 'Flat Top'
        w = flattopwin(L,'periodic');
    case 5 % 'Chebyshev'
        SidelobeAttenuation = varargin{1};
        w = chebwin(L,SidelobeAttenuation);
    case 7 % 'Blackman'
        w = blackman(L,'periodic');
    otherwise % case 6 % 'Kaiser'
        SidelobeAttenuation = varargin{1};
        if SidelobeAttenuation > 50
            winParam = 0.1102*(SidelobeAttenuation-8.7);
        elseif SidelobeAttenuation < 21
            winParam = 0;
        else
            winParam = (0.5842*(SidelobeAttenuation-21)^0.4) + ...
                0.07886*(SidelobeAttenuation-21);
        end
        w = kaiser(L,winParam);
end

window = cast(w,DT);
end