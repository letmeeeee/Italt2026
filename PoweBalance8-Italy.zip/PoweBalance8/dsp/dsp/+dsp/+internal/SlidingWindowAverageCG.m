classdef (StrictDefaults)SlidingWindowAverageCG < matlab.System
% SlidingWindowAverageOverlap This class is internally used by dsp.MovingAverage

%   Copyright 2016-2021 The MathWorks, Inc.

%#codegen
%#ok<*EMCLS>
     
    properties (Nontunable)
        % WindowLength Sliding window length
        WindowLength (1, 1) {mustBePositive, mustBeInteger} = int32(4);
        HopSize (1, 1) {mustBePositive, mustBeInteger} = int32(1);
    
       NumChans = 1
    end

    properties (Nontunable, Logical, Hidden)
        isFixedOutput= true
    end

    properties(Access = private)
        % pCumSum Forward cumulative sum
        pCumSum
        % pCumSumRev Reverse cumulative sum
        pCumSumRev
        % pCumRevIndex Index in reverse sum
        pCumRevIndex
        % pModValueRev Counter to keep track of the input sample index 
        % at which next output needs to be generated
        pModValueRev
    end
    
    methods
        function obj = SlidingWindowAverageCG(varargin)
            % Constructor
            setProperties(obj,nargin,varargin{:});
        end
    end

    methods(Access = protected)

        function setupImpl(obj,u)
            obj.pCumSum    = zeros(1,obj.NumChans,'like',u);
            obj.pCumSumRev = zeros(obj.WindowLength - 1,obj.NumChans,'like',u);
            obj.pCumRevIndex = cast(1,class(u));
            obj.pModValueRev = cast(obj.HopSize - 1,class(u));
        end

        function y = stepImpl(obj,u)
           
           windLength  = cast(obj.WindowLength,class(u));
           hopSize  = cast(obj.HopSize,class(u));
           if (windLength==1)
               y = u;
               return;
           end
           
           L = cast(size(u,1),class(u));
           cumRevIndex = obj.pCumRevIndex;
           csum        = obj.pCumSum;
           csumrev     = obj.pCumSumRev;
           modValueRev = obj.pModValueRev;
           modIndex    = int32(1);
           z           = zeros(1,obj.NumChans,'like',u);
           
           % Pre-allocate output
           % Size of output signal is calculated using size of input,
           % hopSize, modValueRev
           if (hopSize == 1) 
               y = zeros(size(u),'like',u);
           elseif coder.const(obj.isFixedOutput)
               % For codegen to create fixed size outputs
               y = zeros([floor((L-1)/hopSize)+1,size(u,2)],'like',u);
           else 
               y = zeros([floor((L-abs(modValueRev)-1)/hopSize)+1,size(u,2)],'like',u);
           end
           
           
           for index = 1:L
               val  = u(index,1:obj.NumChans);
               csum = csum + val;
               if (modValueRev == 0)
                   z    = csum + csumrev(cumRevIndex,:);
               end
               csumrev(cumRevIndex,:) = val;
               % Update reverse cumulative sum state
               if cumRevIndex ~= windLength - 1
                   cumRevIndex = cumRevIndex + 1;
               else
                   cumRevIndex(:)  = 1;
                   csum(:) = 0;
                   csumrev = cumsum(csumrev,1,'reverse');
               end
               % Output is generated at current sample if modValueRev is 0
               if (modValueRev == 0)
                   y(modIndex,:) = z / windLength;
                   % Increment the index of output signal
                   modIndex = modIndex + 1;  
               end
               % modValueRev is decremented if it is greater than 0
               % Else it is reset it to hopSize - 1
               if (modValueRev > 0)
                   modValueRev = modValueRev - 1;
               else
                   modValueRev(:) = hopSize - 1;
               end
           end
           
           obj.pCumSum    = csum;
           obj.pCumSumRev = csumrev;
           obj.pCumRevIndex     = cumRevIndex;
           obj.pModValueRev = modValueRev;
        end

        function resetImpl(obj)
            obj.pCumSum      = zeros(size(obj.pCumSum),'like',obj.pCumSum);
            obj.pCumSumRev   = zeros(size(obj.pCumSumRev),'like',obj.pCumSumRev);
            obj.pCumRevIndex = cast(1,class(obj.pCumRevIndex));
            obj.pModValueRev = cast(obj.HopSize - 1,class(obj.pModValueRev));
        end
        
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            if isLocked(obj)
                s.pCumSum         = obj.pCumSum;
                s.pCumSumRev      = obj.pCumSumRev;
                s.pCumRevIndex    = obj.pCumRevIndex;
                s.pModValueRev    = obj.pModValueRev;
            end
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                obj.pCumSum         = s.pCumSum;
                obj.pCumSumRev      = s.pCumSumRev;
                obj.pCumRevIndex    = s.pCumRevIndex;
                if isfield(s,'pModValueRev')
                    obj.pModValueRev    = s.pModValueRev;
                end
            end
            loadObjectImpl@matlab.System(obj, s, wasLocked);
        end

        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end
    end
end
