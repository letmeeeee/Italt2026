classdef SupportArbitraryInputLength < dsp.internal.SupportScalarVarSize
    % Class inherits matlab.System and determines arbitrary nature of
    % the given inputs.

    % Copyright 2022 The MathWorks, Inc.

    %#codegen
    %#ok<*EMCLS>
    methods (Access = protected)
        function arbFlag = isInputArbitraryOrVarSize(obj, dFactor)
            arbFlag = false;
            if ~isempty(coder.target)
                fixedInput = propagatedInputFixedSize(obj, 1);
                in_sz = propagatedInputSize(obj, 1);
                if isempty(fixedInput)
                    fixedInput = true;
                end

                if ~fixedInput % Varsize inputs
                    arbFlag = true;
                    return;
                elseif ~isempty(in_sz)
                    arbFlag = mod(in_sz(1),dFactor) ~= 0;
                    return;
                end
            end
        end
    end
end