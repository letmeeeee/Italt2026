classdef FilterCodeGenerator < handle
%FilterCodeGenerator Generate MATLAB script from dsp.ParallelFilter or dsp.FilterCascade objects

%   Copyright 2023 The MathWorks, Inc.

% Protected methods
methods(Access=protected)
    function generateFilterCodeImpl(obj, functionName, WriteFile)
        if WriteFile
            [filePath,functionName,ext] = fileparts(functionName);
            if isempty(ext)
                ext='.m';
            end
        end

        str = StringWriter;
        addcr(str, genHeaderString(obj, functionName));
        add(str, getConstructionString(obj));
        add(str, getStepString(obj));

        indentCode(str);

        if ~WriteFile
            % Display in editor
            untitledFile = matlab.desktop.editor.newDocument(string(str));
            untitledFile.smartIndentContents;
        else
            % save in file
            fullFileName = fullfile(filePath,[functionName,ext]);
            [fid, err] = fopen(fullFileName, 'w');
            if ~isempty(err)
                error(err);
            end
            indentCode(str);
            fwrite(fid,char(str));
            fclose(fid);
        end
    end

    function headerString = genHeaderString(obj, fileName)
        [~,functionName,~] = fileparts(fileName);
        str = StringWriter;
        addcr(str,'function y = %s(x)',functionName);
        if isa(obj,'dsp.FilterCascade')
            addcr(str,'%%%s Construct a filter cascade and process its stages',upper(functionName));
        else
            addcr(str,'%%%s Construct a parallel filter and process its branches',upper(functionName));
        end
        craddcr(str,sptfileheader('MATLAB Code', 'dsp'));
        codegenStr = ['  % ' FilterDesignDialog.message('CCodegenCommandLineHelp')];
        codegenLineSpaces = strfind(codegenStr, ' ');
        codegenLineSplit = codegenLineSpaces(find(codegenLineSpaces<76,1,'last'));
        cradd(str, codegenStr(1:codegenLineSplit));
        cradd(str, ['  % ' codegenStr(codegenLineSplit+1:end)]);
        cradd(str,'%#codegen');
        headerString = str.string;
    end
end

% Public hidden methods
methods(Hidden)
    function constructionString = getConstructionString(obj)
        str = StringWriter;
        cradd(str,'%% Construction');

        cradd(str,'persistent');

        stageTree = genExpressionTree(obj);
        leaves = findLeaves(stageTree);
        for ind = 1:length(leaves)
            add(str,' %s',leaves{ind}.label);
        end

        craddcr(str,'if isempty(%s)',leaves{1}.label);
        for ind2 = 1:numChildren(obj)
            indStr = int2str(ind2);
            h = child(obj, ind2);
            if isa(h,'dsp.FilterCascade') || isa(h,'dsp.ParallelFilter')
                s = getStructureConstructionString(h, indStr);
            else
                s = getLeafConstructionString(h, indStr);
            end
            addcr(str,s);
        end

        addcr(str,'end');
        constructionString = str.string;
    end

    function stepString = getStepString(obj,varargin)    
        str = StringWriter;
        craddcr(str,'%% Process');
        if ~isempty(varargin)
            narginchk(2,5);
            DT = varargin(1);
            if strcmp(DT,'Double precision')
                addcr(str,'s = double(x);');
            elseif strcmp(DT,'Single precision')
                addcr(str,'s = single(x);');
            else
                narginchk(5,5);
                SG = varargin{1,2}; % Sign
                WL = varargin{1,3}; % Word Length
                FL = varargin{1,4}; % Fraction Length
                addcr(str,sprintf('s = fi(x,%s,%s,%s,RoundingMethod=''Round'',OverflowAction=''Saturate'');',SG,WL,FL));
            end
            inpS = 's';
        else
            inpS = 'x';
        end
        stageTree = genExpressionTree(obj);
    
        s = getStepCode(stageTree,inpS);
        addcr(str,s.string);
        stepString = str.string;
    end


end

end


%------------------------------------------------------------------
function str = getLeafConstructionString(h, indStr)
    if isNumericScalarFilter(h)
        fstr = scalarFilterConstructor(h);     
    else
        fstr = dsp.util.genFilterConstructor(h);
    end

    str = [classLabel(h), indStr, ' = ', sprintf(fstr)];
end

%------------------------------------------------------------------
function cascadeConstString = getStructureConstructionString(h,indStr)
    str = StringWriter;
    for ind = 1:numChildren(h)
        indStr2 = int2str(ind);
        h2 = child(h, ind);
        if isa(h2,'dsp.FilterCascade') || isa(h2,'dsp.ParallelFilter')
            s = getStructureConstructionString(h2, [indStr, '_', indStr2]);
        else
            s = getLeafConstructionString(h2, [indStr, '_', indStr2]);
        end
        addcr(str,s);
    end
    cascadeConstString = str.string;
end

%------------------------------------------------------------------
function fstr = scalarFilterConstructor(h)
    if isa(h, 'double')
        fstr = dsp.internal.compactButAccurateMat2Str(h);
    elseif isa(h, 'single')
        fstr = ['single(', dsp.internal.compactButAccurateMat2Str(h), ')'];
    else
        fstr = tostring(h);
    end

    fstr = [fstr ';'];
end

function stepCode = getStepCode(node, inS)
    str = StringWriter;

    outS = sprintf('y%s',node.idxstr);

    if strcmp(node.type,'cascade')
        for n=1:numel(node.children)
            cn = node.children{n};
            scd = getStepCode(cn,inS);
            inS = sprintf('y%s',cn.idxstr);
            
            code = scd.cellstr();
            code = code(1:end-1);

            if n==numel(node.children)
                % Last stage, replace yN in 'yN = filterN(yN-1)' with outS,
                % the cascade output
                last_assignment = code{end};
                idx= find(last_assignment=='=',1,'first');
                code{end} = [outS ' = ' last_assignment(idx+2:end)];
            end
            
            addcr(str, strjoin(code,'\n'));

        end
    elseif strcmp(node.type,'parallel')
        for n=1:numel(node.children)
            cn = node.children{n};
            scd = getStepCode(cn,inS);
            % Step through branches
            addcr(str,scd.string);
        end
        % Sum branches
        add(str,'%s = ',outS);
        for n=1:numel(node.children)-1
            add(str,'y%s + ',node.children{n}.idxstr);
        end
        addcr(str,'y%s;',node.children{end}.idxstr);
    else
        % node is a leaf
        if strcmpi(node.type,'sysobj')
            addcr(str,sprintf('%s = %s(%s);', outS, node.label, inS));
        else
            addcr(str,sprintf('%s = %s * %s;', outS, node.label, inS));
        end
    end

    stepCode = str;
end

function L = findLeaves(node)
    if isfield(node,'children')
        L = {};
        for i=1:numel(node.children)
            L = [L findLeaves(node.children{i})]; %#ok
        end
    else
        L = {node};
    end
end

function stageTree = genExpressionTree(obj, prefixStr)
    arguments
        obj;
        prefixStr (1,:) char = '';
    end

    if isa(obj,'dsp.internal.FilterStructure')
        % obj is a node
        if isa(obj, 'dsp.FilterCascade')
            stype = 'cascade';
        else
            stype = 'parallel';
        end

        stageTree = struct(idxstr=prefixStr, type=stype, children = {{}}); 

        if ~isempty(prefixStr)
            prefixStr = [prefixStr '_'];
        end

        for ind = 1:numChildren(obj)
            h = child(obj, ind);
            idxStr = sprintf('%s%s',prefixStr, int2str(ind));
            stageTree.children{end+1} = genExpressionTree(h, idxStr); 
        end
    else
        % obj is a leaf
        if isNumericScalarFilter(obj)
            stype = 'scalar';
        else
            stype = 'sysobj';
        end
        label = [classLabel(obj) prefixStr];
        stageTree = struct(idxstr = prefixStr, type=stype, label=label); 
    end
end

function flag = isNumericScalarFilter(h)
    flag = isnumeric(h) && isscalar(h);
end

function label = classLabel(h)
    switch class(h)
        case {'double','single','embedded.fi'}
            label = 'scalar';
        case 'dsp.FIRFilter'
            label = 'fir';
        case {'dsp.SOSFilter','dsp.BiquadFilter','dsp.IIRFilter',...
                'dsp.FourthOrderSectionFilter', 'dsp.AllpoleFilter',...
                'dsp.AllpassFilter','dsp.CoupledAllpassFilter'}
            label = 'iir';
        case {'dsp.FIRDecimator','dsp.CICDecimator', 'dsp.FIRHalfbandDecimator'}
            label = 'firdn';
        case {'dsp.FIRInterpolator','dsp.CICInterpolator', 'dsp.FIRHalfbandInterpolator'}
            label = 'firup';
        case {'dsp.FIRRateConverter', 'dsp.SampleRateConverter'}
            label = 'firrc';
        case 'dsp.FarrowRateConverter'
            label = 'farw';
        case 'dsp.FilterCascade'
            label = 'casc';
        case 'dsp.ParallelFilter'
            label = 'para';
        case {'dsp.Delay', 'dsp.VariableFractionalDelay'}
            label = 'dly';
        otherwise
            label = 'filter';
    end
end
