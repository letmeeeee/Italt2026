classdef (StrictDefaults, TunablesDetermineInactiveStatus)TimeScopeBase < matlabshared.scopes.mixin.CommandLineAutoscale & matlabshared.scopes.UnifiedSystemScope
%TimeScopeBase Display time-domain signals

%   Copyright 2020-2022 The MathWorks, Inc.


% Declare MATLAB Compiler dependencies for extension manager based files.
% See g2060669. To get a list of the pragmas, call the method
% printExtensionPragmas on the System Object.

%#function matlabshared.scopes.GeneralUIOptions
%#function matlabshared.scopes.SourceUIOptions
%#function matlabshared.scopes.source.SystemObjectSource
%#function matlabshared.scopes.visual.TimeDomainVisual
%#function matlabshared.scopes.tool.PlotNavigation
%#function matlabshared.scopes.tool.Measurements
  
  properties
    %Name Caption to display on Time Scope window
    %   Specify the caption to display on the Time Scope window as any
    %   string. The default value of this property is 'Time Scope'. This
    %   property is tunable.
    Name = 'Time Scope';
  end
  
  properties (Nontunable)
    %NumInputPorts Number of input signals
    %   Specify the number of input signals to display on the Time Scope as
    %   a positive integer. You must invoke the step method with the same
    %   number of inputs as the value of this property. The default value
    %   of this property is 1.
    NumInputPorts = 1;
  end
  
  properties (Nontunable)
    %SampleRate Sample rate of inputs
    %   Specify the sampling rate of the input signal(s) in Hz as a
    %   finite numeric scalar, or a numeric vector of length equal to the
    %   NumInputPorts property value. The inverse of the sample rate
    %   determines the x-axis (time axis) spacing between points in the
    %   displayed signal. When the NumInputPorts property value is more
    %   than 1, and this property is set to a scalar, the same sample rate
    %   is used for all inputs. The default value of this property is 1.
    SampleRate = 1;
  end
  
  properties(Dependent)
    %TimeSpanSource Source of time span
    %   Specify the source of time span for frame-based input as one of
    %   ['Auto' | 'Property']. The default is 'Auto'. The time span
    %   determines the x-axis limits of the Time Scope. When this property
    %   is set to 'Auto', the x-axis limits are derived from the input
    %   signals' sample times, frame sizes and time display offsets as
    %   follows:
    %   Minimum X-axis limit: min(TimeDisplayOffset)
    %   Maximum X-axis limit: max(TimeDisplayOffset) +
    %                         max(1/SampleRate.*FrameSize)
    %
    %   Here, TimeDisplayOffset is the value of the TimeDisplayOffset
    %   property, SampleRate is the value of the SampleRate property, and
    %   FrameSize is a vector equal to the number of rows in each input
    %   signal.
    %
    %   When this property is set to 'Property', the x-axis limits are
    %   derived from the TimeDisplayOffset and TimeSpan properties. This
    %   property is applicable when the FrameBasedProperty is true. This
    %   property is tunable.
    TimeSpanSource;
    %TimeSpan Time span
    %   Specify the time span as a positive numeric scalar in units of
    %   seconds. This property is applicable when the FrameBasedProcessing
    %   property is false. It is also applicable when the
    %   FrameBasedProcessing property is true and the TimeSpanSource
    %   property is 'Property'. The time span value determines the x-axis
    %   limits of the Time Scope as follows:
    %   Minimum X-axis limit: min(TimeDisplayOffset)
    %   Maximum X-axis limit: max(TimeDisplayOffset) + TimeSpan
    %
    %   Here, TimeDisplayOffset is the value of the TimeDisplayOffset
    %   property, and TimeSpan is the value of the TimeSpan property.
    %   The default value of the property is 10. This property is tunable.
    TimeSpan;
    %TimeSpanOverrunAction Wrap or scroll when the Time Span is overrun
    %   Specify whether the Time Scope will display the data as one of
    %   ['Wrap' | 'Scroll']. The default is 'Wrap'. When this property is 
    %   set to 'Wrap', the Time Scope will add data to the left side of the 
    %    Time Scope after overrunning the right side of the Time Scope.  When 
    %    this property is set to 'Scroll', old data will be moved to the left 
    %    when the data overruns the right hand side of the screen.  This 
    %    property is tunable.
    TimeSpanOverrunAction;
    %TimeDisplayOffset Offset x-axis limits
    %   Specify the offset to apply to the time axis (x-axis) in units of
    %   seconds. This property can either be set to a numeric scalar, or a
    %   vector of length equal to the number of input channels. If this
    %   property is set to a scalar, the same time display offset is used
    %   for all channels. If it is set to a vector, each element is used as
    %   the time offset for the corresponding channel. For vector lengths
    %   less than the number of input channels, the time display offset for
    %   the remaining channels is assumed to be 0. For vector lengths
    %   greater than the number of input channels, the extra vector
    %   elements are ignored. For more information on input channels, see
    %   <a href="matlab:helpview(fullfile(docroot,'toolbox','dsp','dsp.map'),'ugframebasedprocessing')">frame-based processing</a>. The default value of this property is 0.
    %   This property is tunable.
    %
    %   See also: dsp.TimeScope.TimeSpanSource, dsp.TimeScope.TimeSpan.
    TimeDisplayOffset;
    %TimeUnits Units of the time axis
    %   Specify the units used to describe the time-axis.  'None' will
    %   use no units, 'Metric' will convert the time to milliseconds,
    %   microseconds, etc., 'Seconds' will always leave the units as
    %   seconds.  'Metric' is the default.  This property is tunable.
    TimeUnits;
    %AxesScaling Axes scaling mode
    %   Specify the scaling mode for the axes as one of ['Auto' | 'Manual' 
    %   | 'Updates' | 'OnceAtStop']. The default is 'OnceAStop'. When this
    %   property is set to 'Auto' the scope will attempt to always keep the
    %   data in the display while minimizing the number of axes limit
    %   updates.  When this property is set to 'Manual', the scope will 
    %   take no action unless specified by the user.  When this property is
    %   set to 'Updates' the scope will update the axes limits after a set 
    %   number of visual updates.  When this property is set to 
    %   'OnceAtStop' the limits will be updated once at the stop of the 
    %   simulation (when release is called).  This property is tunable.
    AxesScaling;
    %YLimits Y-axis limits
    %   Specify the y-axis limits as a two-element numeric vector: [ymin
    %   ymax]. When the PlotAsMagnitudePhase property is false, the default value
    %   of this property is [-10 10]. When the PlotAsMagnitudePhase property is
    %   true, the default value of this property is [0 10] and it specifies
    %   the y-axis limits of magnitude plot. When set, ActiveDisplay
    %   controls which displays are updated. This property is tunable.
    YLimits;
    %YLabel Y-axis label
    %   Specify the y-axis label as a string. The default value of this
    %   property is 'Amplitude'. This property is applicable when the
    %   PlotAsMagnitudePhase property is false. When the PlotAsMagnitudePhase property
    %   is true, the y-axes labels are read-only values which are set to
    %   'Magnitude' and 'Phase' for magnitude plot and phase plot,
    %   respectively. When set, ActiveDisplay controls which displays are
    %   updated. This property is tunable.
    YLabel;
    %PlotType Option to control the type of plot
    %   Specify the type of plot to be used.  Valid types are 'Line'
    %   and 'Stairs'. The default is 'Line'. This property is tunable.
    PlotType;
    %Title Display title
    %   Specify the display title as a string. The default value of this
    %   property is ''. When set, ActiveDisplay controls which displays
    %   are updated. This property is tunable.
    Title;
    %TimeAxisLabels Time-axis labels
    %   Specify how time-axis labels should appear in the Time Scope's
    %   displays as one of ['All' | 'None' | 'Bottom']. The default is 
    %   'All'. When this property is set to 'All', time-axis labels appear 
    %   in all displays. When this property is set to 'None', time-axis 
    %   labels appear in no displays. When this property is set to 
    %   'Bottom', time-axis labels appear in the bottom display of each
    %   column. This property is tunable.
    TimeAxisLabels;
    %MaximizeAxes Maximize axes control
    %   Specify how axes should appear in the Time Scope's displays as one 
    %   of ['Auto' | 'On' | 'Off']. The default is 'Auto'. When this 
    %   property is set to 'Auto', axes are maximized only if no displays 
    %   contain label or title annotations.  When this property is set to 
    %   'On', axes are maximized in all displays.  When this property is 
    %   set to 'Off', axes are not maximized in any display. This property 
    %   is tunable.
    MaximizeAxes;
    %ActiveDisplay Active display for display-specific properties
    %   Specify the active display for getting and setting relevant
    %   properties as a number, where a display number corresponds to its
    %   column-wise placement index. The default value of this property is
    %   1.  Setting this property controls which display is used for the
    %   following properties: YLimits, YLabel, ShowLegend, ShowGrid, Title,
    %   PlotAsMagnitudePhase. This property is tunable.
    ActiveDisplay;
    %LayoutDimensions Layout grid dimensions
    %   Specify the layout grid dimensions as two-element vector:
    %   [numberOfRows numberOfColumns]. The default value of this property
    %   is [1 1]. No greater than 4 rows or columns may be specified in a
    %   layout. This property is tunable.
    LayoutDimensions;
    %BufferLength Buffer length
    %    Specify length of the buffer used for each input signal. This
    %    property is tunable.
    BufferLength;
    %ChannelNames A cell array of channel names
    %   Set this property to a cell array of strings to represent the input
    %   channels. These strings are used to label the data channels in the
    %   legend, in the Style dialog and in various measurement tools. The
    %   default is an empty cell array. When this property is an empty cell
    %   array, the channels will be named by default as Channel 1, Channel 2
    %   and so on. This property is tunable.
    ChannelNames
  end
  
  properties (Nontunable)
    %FrameBasedProcessing Process input in frames or as samples
    %   Set this property to true to enable frame-based processing. Set
    %   this property to false to enable sample-based processing. The
    %   default value of this property is true.
    FrameBasedProcessing (1, 1) logical;
  end
  
  properties % This should be dependent
    %ReduceUpdates Reduce updates to improve performance
    %   Set this property to false to update the scope every time the step
    %   method is called. This will negatively impact performance. The
    %   default is true. This property is tunable.
    ReduceUpdates (1, 1) logical;
    %ShowLegend Show or hide legend
    %   When this property is set to false, no legend is displayed. When
    %   this property is set to true, a legend with automatic string labels
    %   for each input channel is displayed. See the documentation for the
    %   FrameBasedProcessing property on more information about input
    %   channels. You can use the legend to toggle signal visibility in the
    %   scope. In the legend, click on a signal name to hide the signal in
    %   the scope. To show the signal, click on the signal name again. To
    %   show only one signal, right-click the signal name. When set,
    %   ActiveDisplay controls which displays are updated. This property is
    %   tunable.
    %
    %   See also: dsp.TimeScope.FrameBasedProcessing.
    ShowLegend (1, 1) logical;
    %ShowGrid Option to turn on grid
    %   Set this property to true to turn on the grid. The default value is
    %   false. When set, ActiveDisplay controls which displays are updated
    %   This property is tunable.
    ShowGrid (1, 1) logical;
    %PlotAsMagnitudePhase Plot signal as Magnitude-and-Phase
    %   Set this property to true to plot magnitude and phase of the
    %   signal. The default value is false. When set, ActiveDisplay
    %   controls which displays are updated. This property is tunable.
    PlotAsMagnitudePhase (1, 1) logical;
  end
  
  properties(Constant, Hidden)
    TimeSpanSourceSet = dsp.CommonSets.getSet('AutoOrProperty');
    TimeSpanOverrunActionSet = matlab.system.StringSet({'Wrap', 'Scroll'});
    PlotTypeSet = matlab.system.StringSet({'Line', 'Stairs'});
    TimeAxisLabelsSet = matlab.system.StringSet({'All', 'None', 'Bottom'});
    MaximizeAxesSet = matlab.system.StringSet({'Auto', 'On', 'Off'});
    TimeUnitsSet = matlab.system.StringSet({'None', 'Metric', 'Seconds'});
    AxesScalingSet = matlabshared.scopes.mixin.CommandLineAutoscale.getAxesScalingSet;
  end
  
  properties (Access = private)
      NumInputPortsListener;
  end
  
  methods

    function obj = TimeScopeBase(varargin)
      obj@matlabshared.scopes.UnifiedSystemScope();
      % enable measurements
      obj.Position = uiscopes.getDefaultPosition([560 420]);
      enableExtension(obj.pFramework.ExtDriver, 'Tools', 'Measurements');
      
      % Add string support.
      if nargin > 0
          firstProp = find(cellfun(@ischar, varargin), 1, 'first');
          varargin(firstProp:2:end) = cellstr(varargin(firstProp:2:end));
      end
      
      setProperties(obj, nargin, varargin{:}, 'NumInputPorts', 'SampleRate');
      
      obj.NumInputPortsListener = uiservices.addlistener(obj.pSource, 'NumInputPorts', ...
          'PostSet', @(~,~) updateNumInputPorts(obj));
      
      % Turn off the playback control toolbar
      obj.pSource.setPropertyValue('ShowSnapShotButton',false);
    end
    
    function set.Name(obj, value)
      value = char(value);
      setScopeName(obj, value);
      obj.Name = value;
    end
    
    function set.NumInputPorts(obj, value)
      validateattributes(value, ...
        {'numeric'}, {'integer', 'scalar', '>=', 1, '<=', 96}, '', 'NumInputPorts'); %#ok<*EMCA>
      obj.NumInputPorts = value;
      if ~isScopeLaunched(obj)
        launchScope(obj);
      end
      
      % Update displays to have correct ShowContent state
      obj.pFramework.Visual.updateDisplayShowContent(value);
      
      obj.pSource.NumInputPorts = value;
    end
    
    function value = get.NumInputPorts(obj)
      if isScopeLaunched(obj)
        value = obj.pSource.NumInputPorts;
      else
        value = obj.NumInputPorts;
      end
    end
    
    function set.BufferLength(obj, value)
      if ~isScopeLaunched(obj)
        launchScope(obj);
      end
      if matlabshared.scopes.TimeScopeValidator.PositiveInteger(value)
        setPropertyValue(obj.pFramework.DataSource,'PointsPerSignal',value);
      else
        msgObj = message('Spcuilib:configuration:InvalidSetting','BufferLength',...
          obj.Name,getString(message('Spcuilib:configuration:InvalidPositiveInteger')));
        throwAsCaller(MException(msgObj));
      end       
    end
    
    function value = get.BufferLength(obj)
      if ~isScopeLaunched(obj)
        launchScope(obj);
      end
      value = getPropertyValue(obj.pFramework.DataSource,'PointsPerSignal');  
    end
    
    function set.SampleRate(obj, value)
      validateattributes(value, ...
        {'numeric'},{'positive','finite'}, '', 'SampleRate');
      obj.SampleRate = value;
    end
    
    function set.FrameBasedProcessing(obj, value)
      if value
        valuestr = 'FrameProcessing';
      else
        valuestr = 'SampleProcessing';
      end
      setVisualProperty(obj, 'InputProcessing', valuestr);
    end
    
    function value = get.FrameBasedProcessing(obj)
      value = strcmp(getVisualProperty(obj, 'InputProcessing'), ...
        'FrameProcessing');
    end
    
    function set.TimeSpanSource(obj, value)
      if obj.FrameBasedProcessing
        if strcmp(value, 'Auto')
          setVisualProperty(obj, 'TimeRangeFrames', 'Spcuilib:scopes:TimeRangeInputSampleTime');
        else % 'Property'
          setVisualProperty(obj, 'TimeRangeFrames', obj.TimeSpan, true);
        end
      end
    end
    
    function value = get.TimeSpanSource(obj)
      if obj.FrameBasedProcessing
        if strcmp(getVisualProperty(obj, 'TimeRangeFrames'), ...
            'Spcuilib:scopes:TimeRangeInputSampleTime')
          value = 'Auto';
        else
          value = 'Property';
        end
      else % Sample-based
        value = 'Property';
      end
    end
    
    function set.TimeSpan(obj, value)
      %TimeSpan must be a real positive scalar
      validateattributes(value, ...
        {'numeric'}, {'real','finite','positive','scalar'},'', 'TimeSpan');
      
      if obj.FrameBasedProcessing
        prop = 'TimeRangeFrames';
      else
        prop = 'TimeRangeSamples';
      end
      if strcmp(obj.TimeSpanSource, 'Property')
        setVisualProperty(obj, prop, value, true);
        % For editable popups, we need to refresh the properties dialog
        % explicitly so that it reflects the new value.
        refreshPropertiesDialog(obj.getFramework.Visual);
      end
    end
    
    function value = get.TimeSpan(obj)
      if obj.FrameBasedProcessing
        if ~strcmp(getVisualProperty(obj, 'TimeRangeFrames'), ...
            'Spcuilib:scopes:TimeRangeInputSampleTime')
          value = getVisualProperty(obj, 'TimeRangeFrames', true);
        else
          value = getVisualProperty(obj, 'TimeRangeSamples', true);
        end
      else
        value = getVisualProperty(obj, 'TimeRangeSamples', true);
      end
    end
    
    function set.TimeDisplayOffset(obj, value)
      validateattributes(value, ...
        {'numeric'}, {'real','finite'},'', 'TimeDisplayOffset');
      setVisualProperty(obj, 'TimeDisplayOffset', value, true);
    end
    
    function value = get.TimeDisplayOffset(obj)
      value = getVisualProperty(obj, 'TimeDisplayOffset', true);
    end
    
    function set.TimeAxisLabels(obj, value)
      
      setVisualProperty(obj, 'TimeAxisLabels', char(value));
    end
    
    function value = get.TimeAxisLabels(obj)
      value = getVisualProperty(obj, 'TimeAxisLabels');
    end
    
    function set.MaximizeAxes(obj, value)
      
      setVisualProperty(obj, 'MaximizeAxes', char(value));
    end
    
    function value = get.MaximizeAxes(obj)
      value = getVisualProperty(obj, 'MaximizeAxes');
    end
    
    function set.ActiveDisplay(obj, value)
      if ~matlabshared.scopes.TimeScopeValidator.ActiveDisplay(value) || ...
                    (floor(value) > prod(obj.LayoutDimensions)) 
        localError('invalidActiveDisplay');
      end
      if ~isScopeLaunched(obj)
        launchScope(obj);
      end
      obj.pFramework.Visual.SelectedDisplay = num2str(floor(value));
    end
    
    function value = get.ActiveDisplay(obj)
      
      if ~isScopeLaunched(obj)
        launchScope(obj);
      end
      
      value = str2double(obj.pFramework.Visual.SelectedDisplay);
    end
    
    function set.LayoutDimensions(obj, value)
      if ~matlabshared.scopes.TimeScopeValidator.LayoutDimensions(value)
        localError('invalidLayoutDimensions');
      end
      setVisualProperty(obj, 'DisplayLayoutDimensions',floor(value));
    end
    
    function value = get.LayoutDimensions(obj)
      value = getVisualProperty(obj, 'DisplayLayoutDimensions');
    end
    
    function set.TimeUnits(obj, value)
      setVisualProperty(obj, 'TimeUnits', lower(char(value)));
      refreshPropertiesDialog(obj.getFramework.Visual);
    end
    
    function value = get.TimeUnits(obj)
      value = getVisualProperty(obj, 'TimeUnits');
      value(1) = upper(value(1));
    end
    
    function set.ReduceUpdates(obj, value)
        setPropertyValue(obj.getSource, 'LockSynchronous', ~value);
    end
    
    function value = get.ReduceUpdates(obj)
        value = ~getPropertyValue(obj.getSource, 'LockSynchronous');
    end
    
    function set.PlotAsMagnitudePhase(obj, value)
      obj.setActiveDisplayProperty('PlotMagPhase', value);
    end
    
    function value = get.PlotAsMagnitudePhase(obj)
      value = obj.getActiveDisplayProperty('PlotMagPhase');
    end
    
    function set.AxesScaling(obj, newScaling)
        setAxesScaling(obj, newScaling)
    end
    
    function scaling = get.AxesScaling(obj)
        scaling = getAxesScaling(obj);
    end
    
    function set.YLimits(obj, value)
      % Check that value is a 2-element numeric vector
      if ~matlabshared.scopes.TimeScopeValidator.Limits(value)
        localError('invalidYLimits','YLimits');
      end
      
      if ~isScopeLaunched(obj)
        launchScope(obj);
      end
      
      if obj.PlotAsMagnitudePhase
        minPropName = 'MinYLimMag';
        maxPropName = 'MaxYLimMag';
      else
        minPropName = 'MinYLimReal';
        maxPropName = 'MaxYLimReal';
      end
      
      % Convert the values to strings.
      minYLimValue = mat2str(value(1));
      maxYLimValue = mat2str(value(2));
      
      % Set the values onto the visual.  Suppressing events until after
      % everything is done.
      hVisual = obj.pFramework.Visual;
      hVisual.SettingMultipleProperties = true;
      obj.setActiveDisplayProperty(minPropName, minYLimValue);
      obj.setActiveDisplayProperty(maxPropName, maxYLimValue);
      hVisual.SettingMultipleProperties = false;
      
      % Update the limits once after everything is set.
      updateYLimits(hVisual.Displays{obj.ActiveDisplay});

      % Turn off autoscaling if the YLimits are set directly.
      fevalOnExtension(obj.pFramework, 'Tools', 'Plot Navigation', ...
          @(h) setPropertyValue(h, 'AutoscaleMode', 'Manual', 'OnceAtStop', false));
      
      % Send the DisplayUpdated event once at the end after everything has
      % been updated.
      notify(hVisual, 'DisplayUpdated', uiservices.DataEventData( ...
          struct('UserGenerated', true)));
    end
    
    function value = get.YLimits(obj)
      
      if obj.PlotAsMagnitudePhase
        minYLimValue = uiservices.evaluate(obj.getActiveDisplayProperty('MinYLimMag'))';
        maxYLimValue = uiservices.evaluate(obj.getActiveDisplayProperty('MaxYLimMag'))';
        value = [minYLimValue, maxYLimValue];
      else
        minYLimValue = uiservices.evaluate(obj.getActiveDisplayProperty('MinYLimReal'))';
        maxYLimValue = uiservices.evaluate(obj.getActiveDisplayProperty('MaxYLimReal'))';
        value = [minYLimValue, maxYLimValue];
      end
    end
    
    function set.YLabel(obj, value)
      % Check that value is a string
      if ~ischar(value) && ~isstring(value)
        localError('invalidYLabel','YLabel');
      end
      
      obj.setActiveDisplayProperty('YLabelReal', char(value));
    end
    
    function value = get.YLabel(obj)
      
      value = obj.getActiveDisplayProperty('YLabelReal');
    end
    
    function set.Title(obj, value)
      
      % Check that value is a string
      if ~ischar(value) && ~isstring(value)
        localError('invalidTitle');
      end
      
      obj.setActiveDisplayProperty('Title', char(value));
    end
    
    function value = get.Title(obj)
      
      value = obj.getActiveDisplayProperty('Title');
    end
    
    function set.ShowGrid(obj, value)
      obj.setActiveDisplayProperty('XGrid', value);
      obj.setActiveDisplayProperty('YGrid', value);
    end
    
    function value = get.ShowGrid(obj)
      value = obj.getActiveDisplayProperty('XGrid');
    end
    
    function set.ShowLegend(obj, value)
      obj.setActiveDisplayProperty('LegendVisibility', ...
          uiservices.logicalToOnOff(value));        
    end
    
    function value = get.ShowLegend(obj)
      value = uiservices.onOffToLogical( ...
          obj.getActiveDisplayProperty('LegendVisibility'));
    end
    
    function set.ChannelNames(obj, value)
        if ~iscellstr(value)%#ok
            localError('invalidChannelNames', 'ChannelNames');
        end
        if ~isScopeLaunched(obj)
            launchScope(obj);
        end
        obj.pFramework.Visual.Displays{obj.ActiveDisplay}.UserDefinedChannelNames = cellstr(value);
    end
    
    function value = get.ChannelNames(obj)
        if ~isScopeLaunched(obj)
            launchScope(obj);
        end
        value = obj.pFramework.Visual.Displays{obj.ActiveDisplay}.UserDefinedChannelNames;
    end
    
    function set.TimeSpanOverrunAction(obj, value)
      setVisualProperty(obj, 'TimeSpanOverrunMode', char(value));
    end
    function value = get.TimeSpanOverrunAction(obj)
      value = getVisualProperty(obj, 'TimeSpanOverrunMode');
    end
    
    function set.PlotType(obj, value)
      setVisualProperty(obj, 'PlotType', char(value));
    end
    function value = get.PlotType(obj)
      value = getVisualProperty(obj, 'PlotType');
    end
    
    
  end
  
  methods(Access = private)
      
    function setActiveDisplayProperty(obj, displayPropName, value)
      
      % Ensure we are not given a cell array
      if iscell(value)
        localError('invalidActiveDisplayPropertyValue');
      end
      
      if ~isScopeLaunched(obj)
        launchScope(obj);
      end
      
      % Set selected display property.  If applying a cell array for
      % 'All', then the code above applied the actual values to the
      % individual displays, and here the SelectedDisplay values should
      % just be cleared in order to update the properties dialog.
      switch displayPropName
        case {'XGrid', 'YGrid'}
          obj.pFramework.Visual.SelectedDisplayGrid = value;
        case 'LegendVisibility'
          obj.pFramework.Visual.SelectedDisplayLegend = uiservices.onOffToLogical(value);
        otherwise
          obj.pFramework.Visual.(['SelectedDisplay' displayPropName]) = value;
      end
    end
    
    function value = getActiveDisplayProperty(obj, displayPropName)
      
      if ~isScopeLaunched(obj)
        launchScope(obj);
      end
      activeDisplay = obj.ActiveDisplay;
      hDisplays = obj.pFramework.Visual.Displays;
      value = hDisplays{activeDisplay}.(displayPropName);
    end
  end
  
  methods(Hidden)
    function st = getInputSampleTime(obj)
      if obj.NumInputPorts > 1 && isscalar(obj.SampleRate)
        st = 1./obj.SampleRate*ones(1,obj.NumInputPorts);
      else
        st = 1./obj.SampleRate;
      end
      dims = ones(1,obj.NumInputPorts);
      for ii=1:obj.NumInputPorts
        dm = getMaxDimensions(obj.pSource,ii);
        dims(ii) = dm(1);
      end
      if obj.FrameBasedProcessing
          st = st.*dims;
      end
    end
  end
  
  methods (Access = protected)
    
    function hScopeCfg = getScopeCfg(~)
      hScopeCfg = spbscopes.TimeScopeSystemObjectCfg;
    end
    
    function num = getNumInputsImpl(obj)
      num = obj.NumInputPorts;
    end
    
    function validatePropertiesImpl(obj)
        
      % add checks for TimeDisplayOffset, Legend
      if numel(obj.SampleRate) ~=1 && ...
          numel(obj.SampleRate) ~= obj.NumInputPorts
        localError('invalidSampleRate');
      end
    end
    
    function flag = isInactivePropertyImpl(obj, prop)
      flag = false;
      switch prop
        case 'TimeSpan'
          flag = obj.FrameBasedProcessing && strcmp(obj.TimeSpanSource, 'Auto');
        case 'TimeSpanSource'
          flag = ~obj.FrameBasedProcessing;
        case {'YLabel'}
          if ischar(obj.ActiveDisplay)
            flag = false;
          else
            flag = obj.PlotAsMagnitudePhase;
          end
      end
    end
    
    function setupImpl(obj, varargin)
        validateInputs(obj,varargin{1});
        setupImpl@matlabshared.scopes.UnifiedSystemScope(obj, varargin{:});
        % Add a tooltip to the Simulation time in status bar
        hFrame = obj.pFramework.getStatusControl('Frame');
        hFrame.Tooltip = obj.pSource.getTimeStatusTooltip;
    end
    
    function S = saveObjectImpl(obj)
      S = saveObjectImpl@matlabshared.scopes.UnifiedSystemScope(obj);
      % Properties that are not part of the Scope Configuration should be
      % saved explicitly in the serialized object.
      S.NumInputPorts = obj.NumInputPorts;
      S.SampleRate = obj.SampleRate;
    end
    
    function loadObjectImpl(obj, s, wasLocked)
      loadObjectImpl@matlabshared.scopes.UnifiedSystemScope(obj, s, wasLocked);
      setup(obj.pFramework.Visual); 
      
      % Update the time span to reflect on the Scope as it may have been
      % reset due to the explicit call to setup. Without the time span
      % update, Scope does not set the XLimit correctly after cloning.
      updateTimeSpan(obj.pFramework.Visual);
      
      % The older MATLAB versions saved the public properties such as
      % YLimits instead of the private non-dependent properties. Therefore,
      % we need to handle both cases.
      sProps = fieldnames(s);
      if isfield(s, 'ScopeConfiguration')
        % The following properties are not part of the Scope Configuration
        % and must be restored explicitly
        objProps = {'NumInputPorts', 'SampleRate'}; 
        sProps = intersect(objProps,sProps);
      else
        
        % We need to support older MAT files which may contain the public
        % or the private field names.
        fn1 = {'NumInputPorts', 'SampleRate', ...
          'FrameBasedProcessing', 'pFrameBasedProcessing',...
          'TimeSpanSource', 'pTimeSpanSource',...
          'TimeSpan', 'pTimeSpan',...
          'TimeDisplayOffset', 'pTimeDisplayOffset',...
          'YLimits', 'pYLimits', ...
          'YLabel', 'pYLabel',...
          'LegendSource', 'pLegendSource', ...
          'Grid', 'pGrid', ...
          'TimeSpanOverrunMode', 'pTimeSpanOverrunMode'}';
        sProps = intersect(sProps, fn1);
        objProps = sProps;
        objProps(strcmp(objProps,'pFrameBasedProcessing')) = {'FrameBasedProcessing'};
        objProps(strcmp(objProps,'pGrid')) = {'ShowGrid'};
        objProps(strcmp(objProps,'pLegendSource')) = {'ShowLegend'};
        objProps(strcmp(objProps,'pTimeDisplayOffset')) = {'TimeDisplayOffset'};
        objProps(strcmp(objProps,'pTimeSpan')) = {'TimeSpan'};
        objProps(strcmp(objProps,'pTimeSpanOverrunMode')) = {'TimeSpanOverrunAction'};
        objProps(strcmp(objProps,'pTimeSpanSource')) = {'TimeSpanSource'};
        objProps(strcmp(objProps,'pYLabel')) = {'YLabel'};
        objProps(strcmp(objProps,'pYLimits')) = {'YLimits'};
        
        % Translate LegendSource property to new value
        if isfield(s,'pLegendSource')
            s.pLegendSource = strcmpi(s.pLegendSource,'Auto');
        end
      end
      
      % Apply old properties to their corresponding new ones
      for indx=1:length(sProps)
        obj.(objProps{indx}) = s.(sProps{indx});
      end
    end
    
    function loadObjectPreStart(obj, s)
      
      % Set the SampleRate before starting so that the correct value is
      % used.
      obj.SampleRate = s.SampleRate;
    end
  end
  
  methods(Static, Hidden)      
      function a = getAlternateBlock
          a = 'dspsnks4/Time Scope';
      end
  end
  
  methods(Static, Access=protected)
    function groups = getPropertyGroupsImpl
      % Only the properties listed in mainProps are displayed in the
      % command-line by default
      mainProps = {'NumInputPorts', 'SampleRate', 'TimeSpanSource', ...
        'TimeSpan', 'TimeSpanOverrunAction', 'AxesScaling'};
      
      advancedProps = {'Name', 'Position', 'ReduceUpdates', ...
        'LayoutDimensions', 'PlotType', 'BufferLength', ...
        'FrameBasedProcessing', 'TimeUnits', 'TimeDisplayOffset', ...
        'TimeAxisLabels', 'MaximizeAxes'};
      
      displayProps = {'ActiveDisplay', 'Title', 'ShowLegend', 'ChannelNames', ...
        'ShowGrid', 'PlotAsMagnitudePhase', 'YLimits', 'YLabel'};
      
      advancedPropsTitle = getString(message('dsp:system:Shared:AdvancedProperties'));
      displayPropsTitle = getString(message('dsp:system:Shared:DisplayProperties'));
      mainGroup = matlab.system.display.SectionGroup(...
        'TitleSource', 'Auto', 'PropertyList', mainProps);
      advancedGroup = matlab.system.display.SectionGroup(...
        'Title', advancedPropsTitle, 'PropertyList', advancedProps);
      displayGroup = matlab.system.display.SectionGroup(...
        'Title', displayPropsTitle, 'PropertyList', displayProps);
      
      groups = [mainGroup advancedGroup displayGroup];
    end
  end
end

function localError(ID, varargin)
error(message(['dsp:system:TimeScope:' ID], varargin{:}));
end

function updateNumInputPorts(obj)

obj.NumInputPorts = obj.pSource.NumInputPorts;
end

% [EOF]
