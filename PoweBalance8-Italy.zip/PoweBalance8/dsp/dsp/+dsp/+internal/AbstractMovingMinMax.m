classdef AbstractMovingMinMax < matlab.System
%   AbstractMovingMinMax This is the base class of dsp.MovingMinimum and
%   dsp.MovingMaximum

%   Copyright 2016-2021 The MathWorks, Inc.
   
%#codegen
%#ok<*EMCLS>

    properties (Nontunable)
        % SpecifyWindowLength Specify window length
        % When you set this property to true, the sliding window length is
        % equal to the value of the WindowLength property. 
        % When you set this property to false, the sliding window length is
        % infinite. In this mode, the statistic is computed for the current
        % sample and all previous samples.
        % The default is true.
        SpecifyWindowLength (1, 1) logical         = true;
    
        %WindowLength Window length
        % Specify the sliding window length as a positive, scalar integer.
        % This property applies when 'SpecifyWindowLength' is true. 
        % The default is 4.
        WindowLength (1, 1) {mustBePositive, mustBeInteger} = 4;
    end
    
    properties (Access = protected)
        % NumChannels Cached number of channels (used for error checking)
        NumChannels
        % pStat Object used to perform moving maximum/minimum
        pStat
    end
    
    properties (Access = protected, Nontunable)
        % pNumChannels Cached number of channels (used to allocate state)
        pNumChannels
    end
    
    methods
        function obj = AbstractMovingMinMax(varargin)
            setProperties(obj,nargin,varargin{:}, 'WindowLength');
            obj.NumChannels = int32(-1);
        end
    end
    
    methods (Access = protected, Abstract)
       setupStatisticObject(obj); 
    end
    
    methods(Access = protected)
                      
        function n = getNumChans(obj,u)
            if obj.getExecPlatformIndex()
                thisSize = propagatedInputSize(obj, 1);
                n = thisSize(2);
            else
                n = size(u,2);
            end
        end
        
        function setupImpl(obj,u)       
            % Get the number of input channels
            numchans = getNumChans(obj,u);
            obj.NumChannels = int32(numchans);
            obj.pNumChannels = numchans;
            
            % Disallow a first step with zero channels
            coder.internal.errorIf(numchans == 0,'dsp:system:Shared:EmptyFirstStep');
            
            obj.pStat  = setupStatisticObject(obj);
            setup(obj.pStat,u)
        end
        
        function m = stepImpl(obj,u)
            m = step(obj.pStat,u);
        end
        
        function resetImpl(obj)
           reset(obj.pStat);
        end
        
        function flag = isInputComplexityMutableImpl(~,~)
            flag = false;
        end

        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end
        
        function releaseImpl(obj)
            obj.NumChannels = int32(-1);
            release(obj.pStat);
        end
        
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            if isLocked(obj)
                s.NumChannels = obj.NumChannels;
                s.pNumChannels = obj.pNumChannels;
                s.pStat      = matlab.System.saveObject(obj.pStat);
            end
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                obj.NumChannels = s.NumChannels;
                obj.pNumChannels = s.pNumChannels;
                obj.pStat = matlab.System.loadObject(s.pStat);
            end
            loadObjectImpl@matlab.System(obj, s, wasLocked);
        end
        
        function flag = isInactivePropertyImpl(obj, prop)
            flag = false;
            switch prop
                case 'WindowLength'
                    flag = ~obj.SpecifyWindowLength;
                otherwise
            end
        end
        
        function validateInputsImpl(obj,u)
            
            validateattributes(u, {'numeric'}, {'2d','real'},'','')
            if obj.NumChannels ~= -1
                coder.internal.errorIf(size(u,2) ~= obj.NumChannels, ['dsp:system',...
                    ':Shared:numChannels']);
            end 
        end        
        
    end
    
    %% Block header - widget grouping
    methods(Static, Access=protected)
        function mainS = getPropertyGroupsImpl
            % Modify order of display
            mainS =  matlab.system.display.Section(...
                'Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', ...
                {matlab.system.display.internal.Property('SpecifyWindowLength','Description','dsp:StatisticsBlockDialog:SpecifyWindowLength_MP'),...
                matlab.system.display.internal.Property('WindowLength','Description','dsp:StatisticsBlockDialog:WindowLength_MP')});
        end
    end
end
