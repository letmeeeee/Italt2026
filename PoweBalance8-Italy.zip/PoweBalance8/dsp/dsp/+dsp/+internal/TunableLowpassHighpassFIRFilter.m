classdef TunableLowpassHighpassFIRFilter < dsp.internal.AbstractTunableFIRFilter
%TunableLowpassHighpassFIR Filter

    %   Copyright 2022-2023 The MathWorks, Inc.

    %#codegen

    properties
        % CutoffFrequency Filter Cutoff frequency
        %   Specify the normalized filter cutoff frequency as a real,
        %   positive scalar smaller than or equal to 1. Th e default is
        %   0.5. This property is tunable.
        CutoffFrequency = 0.5;
    end

    methods
        %------------------------------------------------------------------
        function set.CutoffFrequency(this, value)
            validateCutoffFrequency(this, value);
            this.CutoffFrequency = value;
        end
    end

    methods(Access = protected)
        %------------------------------------------------------------------
        function crossValidateProperties(this)
            crossValidateProperties@dsp.internal.AbstractTunableFIRFilter(this);
            validateCutoffFrequency(this, this.CutoffFrequency);
        end
        %------------------------------------------------------------------
        function validateCutoffFrequency(~, value, varargin)
            allowZero = false;
            if numel(varargin) > 0
                allowZero = varargin{1};
            end
            if allowZero
                validateattributes(value, {'double','single'}, {'real','scalar','nonnegative','finite', '<=', 1}, 'set.CutoffFrequency','CutoffFrequency');
            else
                validateattributes(value, {'double','single'}, {'real','scalar','positive','finite', '<=', 1}, 'set.CutoffFrequency','CutoffFrequency');
            end
        end
        %------------------------------------------------------------------
        function flag = isDesignFilterAllowed(this)
            flag = isDesignFilterAllowed@dsp.internal.AbstractTunableFIRFilter(this);
            flag = flag && this.CutoffFrequency >= 0;
        end
        %------------------------------------------------------------------
        function Fc = getCutoffFrequency(this)
            Fc = this.CutoffFrequency;
        end
    end
end
