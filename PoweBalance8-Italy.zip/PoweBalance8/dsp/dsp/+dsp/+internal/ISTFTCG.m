classdef ISTFTCG < handle &  matlab.mixin.internal.indexing.Paren
% This class is used for code generation of dsp.ISTFT    

% Copyright 2018-2020 The MathWorks, Inc.

%#codegen
    
    properties (Dependent)
        % Same interface as dsp.ISTFT
        Window
        OverlapLength
        ConjugateSymmetricInput
        WeightedOverlapAdd
        FrequencyRange
    end
    
    properties (Access = private)
        % this is a System object that performs ISTFT
        pObj
    end

    methods
        
        function obj = ISTFTCG(varargin)
            obj.pObj = dsp.internal.ISTFTSysObj(varargin{:});
        end
        
        % Set/get
        function set.Window(obj,val)
           validateattributes(val,{'numeric'}, ...
                {'vector','real','nonnan'}, ...
                'set.Window','Window');
            obj.pObj.Window = val;
        end
        function set.OverlapLength(obj,val)
            validateattributes(val,{'numeric'}, ...
                {'scalar','integer','nonnegative','real','nonnan'}, ...
                'set.OverlapLength','OverlapLength');
            obj.pObj.OverlapLength = val;
        end
    
        function set.ConjugateSymmetricInput(obj,val)

            validateattributes(val,{'numeric','logical'}, ...
                {'scalar','real','nonnan'}, ...
                'set.ConjugateSymmetricInput','ConjugateSymmetricInput');
            obj.pObj.ConjugateSymmetricInput = val;
        end
        
        function set.WeightedOverlapAdd(obj,val)

            validateattributes(val,{'numeric','logical'}, ...
                {'scalar','real','nonnan'}, ...
                'set.WeightedOverlapAdd','WeightedOverlapAdd');
            obj.pObj.WeightedOverlapAdd = val;
        end
        
        
        function set.FrequencyRange(obj,val)
           obj.pObj.FrequencyRange = val; 
        end
 
        function val = get.Window(obj)
            val = obj.pObj.Window;
        end
        function val = get.OverlapLength(obj)
            val = obj.pObj.OverlapLength;
        end
        function val = get.ConjugateSymmetricInput(obj)
            val = obj.pObj.ConjugateSymmetricInput;
        end
        function val = get.WeightedOverlapAdd(obj)
            val = obj.pObj.WeightedOverlapAdd;
        end
        
        function val = get.FrequencyRange(obj)
           val = obj.pObj.FrequencyRange; 
        end

        % Mirror dsp.ISTFT methods
        function y = setup(obj,u)
            y = setup(obj.pObj,u);
        end
        
        function y = step(obj,u)
            y = step(obj.pObj,u);
        end
        
        function reset(obj)
            reset(obj.pObj);
        end
        
        function release(obj)
             release(obj.pObj);
        end
    end
    
    methods (Static)
        function out = matlabCodegenToRedirected(~)
            out  = dsp.internal.ISTFTCG;
        end
        
        function out = matlabCodegenFromRedirected(~)
            out = dsp.ISTFT;
        end
    end
    methods (Hidden, Static)
        function name = matlabCodegenUserReadableName
            name = 'dsp.ISTFT';
        end
    end
    
    %----------------------------------------------------------------------
    % Hidden, Sealed methods
    %----------------------------------------------------------------------
    methods  (Hidden=true,Sealed=true)
        function Y = parenReference(obj,u)
            % This is used to enable stepping the object with function
            % notation.
            Y = step(obj,u);
        end
    end
    
end