classdef (StrictDefaults)AbstractMovingStatistic < dsp.internal.SupportScalarVarSize
%   AbstractMovingStatistic This class is used in the moving statistics
%   objects

%   Copyright 2016-2023 The MathWorks, Inc.
   
%#codegen
%#ok<*EMCLS>
    
    properties (Nontunable)
        % SpecifyWindowLength Specify window length 
        % When you set this property to true, the sliding window length is 
        % equal to the value of the 'SlidingWindow' property. When you set 
        % this property to false, the sliding window length is infinite. 
        % In this mode, the average is computed for the current sample and 
        % all past samples). This property applies when Method is equal to 
        % 'Sliding window'. The default is true.
        SpecifyWindowLength (1, 1) logical = true;
    
        %WindowLength Window length 
        % Specify the sliding window length as a positive integer.
        % This property applies when 'Method' is equal to 'Sliding
        % window' and 'SpecifyWindowLength' is true. The default is 4.
        WindowLength (1, 1) {mustBePositive, mustBeInteger} = 4;
    end
    properties (Nontunable,  Dependent)
        %OverlapLength Overlap length
        % Specify the overlap length between sliding windows as a positive
        % integer. This property applies when 'Method' is equal to 'Sliding
        % window' and 'SpecifyWindowLength' is true. The default is
        % WindowLength-1.
        OverlapLength;
    end
    
    properties
        %ForgettingFactor Forgetting factor
        % Specify the exponential weighting forgetting factor as a scalar
        % value greater than zero and smaller than or equal to one. This
        % property applies when 'Method' is equal to 'Exponential
        % weighting'. The default is 0.9. This property is tunable.
        ForgettingFactor = 0.9;
    end
    
    properties(Access = protected)
        % pStatistic Internal object used to compute average
        pStatistic;
    end
    
    properties(Access = private)
        % NumChannels Cached number of channels (used for error checking)
        NumChannels
        % FrameLength Cached input frame length (used for error checking)
        FrameLength
    end
    
    properties(Access = private, Nontunable)
       % pNumChannels Cached number of channels (used to allocate state)
        pNumChannels 
        %pOverlapLengthSource OverlapLength source
        pOverlapLengthSource = 'auto';
        %pAutoOverlapLength Auto OverlapLength value
        pAutoOverlapLength = 3;
        %pUserDefinedOverlapLength User-defined OverlapLength
        pUserDefinedOverlapLength = 3;
    end

    methods
        function obj = AbstractMovingStatistic(varargin)
            % Constructor
            setProperties(obj, nargin, varargin{:}, 'WindowLength','OverlapLength');
            obj.NumChannels = int32(-1);
            obj.FrameLength = int32(-1);
        end
        
        function set.ForgettingFactor(obj,val)
            obj.validateForgettingFactor(val);
            obj.ForgettingFactor = val;
        end
        function set.WindowLength(obj,L)
            validateattributes(L,...
                {'numeric'},...
                {'real','scalar','positive','integer','finite'},...
                '','WindowLength');
            obj.WindowLength = L;
            setAutoOverlapLength(obj);
        end
        function set.OverlapLength(obj, L)
            validateattributes(L,...
                {'numeric'},...
                {'real','scalar','nonnegative','integer','finite'},...
                '','OverlapLength');
            setUserDefinedOverlapLength(obj,L);
        end 
        function L = get.OverlapLength(obj)
            if strcmpi(obj.pOverlapLengthSource,'property')
                L = obj.pUserDefinedOverlapLength;
            else
                L = obj.pAutoOverlapLength;
            end
        end
    end
    
    methods (Abstract, Access = protected)
       getStatisticObject(obj);
    end
    
    methods(Access = protected)
        
        function setupImpl(obj,u)
            % Get the number of input channels
            numchans = getNumChans(obj,u);
            obj.NumChannels  = int32(numchans);
            obj.FrameLength = int32(getFrameLength(obj,u));
            obj.pNumChannels = numchans;
 
            % Disallow a first step with zero channels
            coder.internal.errorIf(numchans == 0,'dsp:system:Shared:EmptyFirstStep');
            
            % Select internal computing object based on object settings
            obj.pStatistic = getStatisticObject(obj,u);
            obj.pStatistic.NumChans = obj.pNumChannels;
            if ~isempty(coder.target) && strcmp(obj.Method,'Sliding window') && obj.SpecifyWindowLength
                obj.pStatistic.isFixedOutput  = obj.isFixedSizeOutput();
            end
        end
        function flag = isFixedSizeOutput(obj)
            % Varsize output if input is varsize or input length is
            % arbitrary
            fixedinput = propagatedInputFixedSize(obj,1);
            sz = propagatedInputSize(obj, 1);
            WL = obj.WindowLength;
            OL = obj.OverlapLength;
            nonArbInputLength = mod(sz, WL - OL)==0;
            flag = fixedinput(1) && nonArbInputLength(1);       
        end
        
        function n = getNumChans(obj,u)
            if obj.getExecPlatformIndex()
                thisSize = propagatedInputSize(obj, 1);
                n = thisSize(2);
            else
                n = size(u,2);
            end
        end

        function n = getFrameLength(obj,u)
            if obj.getExecPlatformIndex()
                thisSize = propagatedInputSize(obj, 1);
                n = thisSize(1);
            else
                n = size(u,1);
            end
        end
        
        function y = stepImpl(obj,u)
            y = step(obj.pStatistic,u);
        end
        
        function resetImpl(obj)
            reset(obj.pStatistic);
        end
        
        function releaseImpl(obj)
            release(obj.pStatistic);
            obj.NumChannels = int32(-1);
            obj.FrameLength = int32(-1);
        end
        
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            s.pOverlapLengthSource = obj.pOverlapLengthSource;
            s.pAutoOverlapLength = obj.pAutoOverlapLength;
            s.pUserDefinedOverlapLength = obj.pUserDefinedOverlapLength;
            if isLocked(obj)
                s.pStatistic      = matlab.System.saveObject(obj.pStatistic);
            end
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                obj.pStatistic = matlab.System.loadObject(s.pStatistic);
            end
            if (isfield(s,'pOverlapLengthSource'))
                obj.pOverlapLengthSource = s.pOverlapLengthSource;
            end
            if (isfield(s,'pAutoOverlapLength'))
                obj.pAutoOverlapLength = s.pAutoOverlapLength;
            end
            if (isfield(s,'pUserDefinedOverlapLength'))
                obj.pUserDefinedOverlapLength = s.pUserDefinedOverlapLength;
            end            
            loadObjectImpl@matlab.System(obj, s, wasLocked);
        end
        
        function flag = isInactivePropertyImpl(obj, prop)
            flag = false;
            switch prop
                case {'SpecifyWindowLength'}
                    flag = strcmp(obj.Method,'Exponential weighting');
                case {'WindowLength','OverlapLength'}
                    flag = strcmp(obj.Method,'Exponential weighting') || ~obj.SpecifyWindowLength;
                case 'ForgettingFactor'
                    flag = strcmp(obj.Method,'Sliding window');
                otherwise
            end
        end
        
        function validateInputsImpl(obj,u)
            validateattributes(u, {'single', 'double'}, {'2d'},'','')
            if obj.NumChannels ~= -1
                coder.internal.errorIf(size(u,2) ~= obj.NumChannels, ['dsp:system',...
                    ':Shared:numChannels']);
            end
            if obj.FrameLength ~= -1
                ArbInputLength = mod(size(u,1), obj.WindowLength - obj.OverlapLength)~=0;
                inputLengthChanged = (size(u,1) ~= obj.FrameLength);
                coder.internal.errorIf(obj.isFixedSizeOutput && inputLengthChanged && ArbInputLength, 'dsp:system:MovingStatistic:inputSizeChangeUndefined');
            end
        end 
        
        function dt = getTunablePropertiesSpecificationImpl(obj,~)
            dt = propagatedInputDataType(obj,1);
        end

        function processTunedPropertiesImpl(obj)
           if strcmp(obj.Method,'Exponential weighting')
              obj.pStatistic.ForgettingFactor = obj.ForgettingFactor;
           end
        end
        

        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end
        
        function name = getInputNamesImpl(~)
            name = '';
        end
        
        function name = getOutputNamesImpl(~)
            name = '';
        end
        
        %%Propagators
        function cplx = isOutputComplexImpl(obj)
            % Complexity propagator
            cplx = propagatedInputComplexity(obj, 1);
        end
        
        function sz = getOutputSizeImpl(obj)
            % Output size propagator
            sz = propagatedInputSize(obj, 1);
        end
        
        function dt = getOutputDataTypeImpl(obj)
            % Output datatype propagator
            dt = propagatedInputDataType(obj, 1);
        end
        
        function isvar = isOutputFixedSizeImpl(obj)
            isvar = propagatedInputFixedSize(obj,1);
        end
        
        function val = supportsMultipleInstanceImpl(~)
            % Support in for-each subsystem
            val = true;
        end
        
        function validateForgettingFactor(~,val)
            validateattributes(val,...
                {'double','single'},...
                {'real','scalar','finite','>',0,'<=',1},...
                '','ForgettingFactor');
        end
        function setUserDefinedOverlapLength(obj,L)
            % If the user set the overlap length, set the overlap 
            % length factor source to 'property'            
            obj.pOverlapLengthSource = 'property';
            obj.pUserDefinedOverlapLength = L;            
        end
        function setAutoOverlapLength(obj)
            % If the user did not set the overlap length, it should
            % be equal to WindowLength - 1 
            obj.pAutoOverlapLength = obj.WindowLength - 1; 
        end  
        
        function validatePropertiesImpl(obj)
            % validate properties
            O = obj.OverlapLength;
            L = obj.WindowLength;
            % Throw an error if the specified OverlapLength is not 
            % less than the WindowLength
            coder.internal.errorIf(L <= O,['dsp:system',...
                ':MovingStatistic:invalidOverlapLength'],L);
        end
    end
    
end