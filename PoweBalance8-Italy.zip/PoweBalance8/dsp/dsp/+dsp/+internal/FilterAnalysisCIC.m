classdef FilterAnalysisCIC < dsp.internal.FilterAnalysis
%#codegen
  %FilterAnalysisCIC Baseclass for CIC filter System object analysis
  
  %   Copyright 2011-2020 The MathWorks, Inc.
  
  methods
    function obj = FilterAnalysisCIC(varargin)

    end
    
    function realizemdl(obj,varargin)  %#ok<*INUSD>
      error(message('dsp:dsp:private:FilterSystemObjectBase:UnsupportedCICRealizemdl'))
    end    
   %----------------------------------------------------------------------
    function [Hpsd,W] = freqrespest(obj,varargin)     %#ok<*STOUT>
      error(message(...
        'dsp:dsp:private:FilterSystemObjectBase:NLMNotDefinedForMultirate',...
        'freqrespest',class(obj)));
    end 
   %----------------------------------------------------------------------
    function OPTS = freqrespopts(obj,varargin)    
      error(message(...
        'dsp:dsp:private:FilterSystemObjectBase:NLMNotDefinedForMultirate',...
        'freqrespopts',class(obj)));
    end        
   %----------------------------------------------------------------------
    function Hpsd = noisepsd(obj,varargin)    
      error(message(...
        'dsp:dsp:private:FilterSystemObjectBase:NLMNotDefinedForMultirate',...
        'noisepsd',class(obj)));
    end 
   %----------------------------------------------------------------------
    function OPTS = noisepsdopts(obj,varargin)    
      error(message(...
        'dsp:dsp:private:FilterSystemObjectBase:NLMNotDefinedForMultirate',...
        'noisepsdopts',class(obj)));
    end        
  end  
  methods (Hidden)
    function flag = isCICFilter(~)
      flag = true;
    end     
    function flag = isMultirate(~)
      flag = true;
    end          
  end
  
  methods (Access = protected)
    function [d, inputsCell] = parseArithmetic(obj,inputsCell,isArithmeticIrrelevant,noDfilt)
      % Parse arithmetic input
      % Inputs:
      %
      % inputsCell    - cell containing PV-pairs. The method will look for
      %                 the 'Arithmetic' input, parse its value and delete
      %                 the PV-pair from the cell. It will return the
      %                 modified cell in the second output, inputsCell.
      % noDfilt       - If true, do not generate an mfilt object from the
      %                 System object and return the parsed arithmetic
      %                 string instead of the dfilt object in the first
      %                 output, d.
      
      % Convert string inputs to char inputs
      [inputsCell{:}] = convertStringsToChars(inputsCell{:});
      
      idx = [];
      if nargin > 1
        idx = find(strcmpi(inputsCell,'arithmetic'));
      end
      if nargin < 3
        isArithmeticIrrelevant = false;
      end
              
      if ~isempty(idx)
        idx = idx(1);
        if (length(inputsCell)>= idx+1 &&...
            ~any(strcmpi({'double','single','fixed'},inputsCell{idx+1})))...
            || length(inputsCell)< idx+1
          error(message(...
            'dsp:dsp:private:FilterSystemObjectBase:InvalidArithmeticInput'))
        end
        
        arith = inputsCell{idx+1};
        if strcmpi(arith, 'fixed') && ~isfixptinstalled
          error(message('dsp:dsp:private:FilterSystemObjectBase:NoFixedPointTbx'))
        end
        inputsCell([idx idx+1]) = [];               
      end
      
      if isempty(idx) || isArithmeticIrrelevant
        arith = 'fixed';
      end
                  
      noDfiltFlag = false;
      if nargin > 3 && noDfilt
        noDfiltFlag = noDfilt;
      end
      
      % Convert System object to dfilt using the parsed arithmetic
      if noDfiltFlag
        % If no dfilt is requested then we return the parsed arithmetic
        % value
        d = arith;
      else
        d = todfilt(obj,arith);
      end
    end
    
    function convertToDFILTCIC(obj,d, arith)   
      
      if ~(strcmpi(arith,'fixed') || strcmpi(arith,'double') || strcmpi(arith,'single') )
        warning(message('dsp:dsp:private:FilterSystemObjectBase:InvalidArithmeticInput'));
      end      
      
      if strcmpi(arith,'double') || strcmpi(arith,'single')
          d.FilterInternals    = 'FullPrecision'; % equivalent fixed-point setting
      else
          switch obj.FixedPointDataType
              case 'Minimum section word lengths'
                  d.FilterInternals    = 'MinWordLengths';
                  d.OutputWordLength   = obj.OutputWordLength;
              case 'Specify word lengths'
                  d.FilterInternals    = 'SpecifyWordLengths';
                  d.OutputWordLength   = obj.OutputWordLength;
                  d.SectionWordLengths = obj.SectionWordLengths;
              case 'Specify word and fraction lengths'
                  d.FilterInternals    = 'SpecifyPrecision';
                  d.OutputWordLength   = obj.OutputWordLength;
                  d.SectionWordLengths = obj.SectionWordLengths;
                  d.SectionFracLengths = obj.SectionFractionLengths;
                  d.OutputFracLength   = obj.OutputFractionLength;
          end
      end
    end 
    
    function flag = isNLMSupported(obj,~)
      flag = false;
    end
  end
end
