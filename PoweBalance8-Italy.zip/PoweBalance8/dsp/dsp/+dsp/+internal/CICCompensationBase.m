classdef CICCompensationBase < dsp.internal.SampleRateEngine & ...
                               dsp.internal.FilterAnalysisMultirate
%CICCOMPENSATIONBASE Abstract base class for CIC compensation objects
% dsp.CICCompensationDecimator and dsp.CICCompensationInterpolator inherit
% from this class.

% Copyright 2014-2021 The MathWorks, Inc.

%#codegen
%#ok<*EMCA>
    properties (Nontunable, Abstract)
        SampleRate;
    end
    
    properties (Nontunable)
        %CICRateChangeFactor Rate change factor of CIC
        %   Specify the rate change factor of the CIC filter to be
        %   compensated, as a positive integer scalar. The default value of
        %   this property is 2.
        CICRateChangeFactor = 2;
        %CICDifferentialDelay Differential delay of CIC
        %   Specify the delay value used in each of the comb sections of
        %   the CIC filter to be compensated, as a positive integer scalar.
        %   The default value of this property is 1.
        CICDifferentialDelay = 1;
        %CICNumSections Number of sections of CIC
        %   Specify the number of integrator and comb sections in the CIC
        %   filter to be compensated, as a positive integer scalar. The
        %   default value of this property is 2.
        CICNumSections = 2;
        %FilterOrder Filter order
        %   Specify the order for the designed compensation filter, as a
        %   positive integer scalar. This property applies when you set the
        %   DesignForMinimumOrder property to false. The default value of
        %   this property is 12.
        FilterOrder = 12;
        %PassbandRipple Passband ripple (dB)
        %   Specify the maximum allowed ripple in the passband of the
        %   filter's response, as a positive real scalar in decibels (dB).
        %   The default value of this property is 0.1 dB.
        PassbandRipple = 0.1;
        %StopbandAttenuation Stopband attenuation (dB)
        %   Specify the attenuation to be achieved in the stopband of the
        %   designed filter's response, as a positive real scalar in
        %   decibels (dB). The default value of this property is 60 dB.
        StopbandAttenuation = 60;
    
        %DesignForMinimumOrder Minimum order filter design
        %   When you set this property to true, the object designs filters
        %   with the minimum order that meets the passband frequency,
        %   stopband frequency, passband ripple, and stopband attenuation
        %   specifications that you set using the corresponding properties.
        %   When you set this property to false, the object designs filters
        %   with order that you specify in the FilterOrder property. This
        %   filter design meets the passband frequency, passband ripple,
        %   and stopband attenuation specifications that you set using the
        %   respective properties. Specify it as a logical scalar. The
        %   default value of this property is true.
        DesignForMinimumOrder (1, 1) logical = true;
    
        %RoundingMethod Rounding method for fixed-point operations at
        %   output 
        %   Specify the rounding method for output as one of ['Ceiling' |
        %   'Convergent' | 'Floor' | 'Nearest' | 'Round' | 'Simplest' |
        %   'Zero']. The default value of this property is 'Floor'.
        RoundingMethod = 'Floor';
        
        %CoefficientsDataType Coefficients word and fraction lengths
        %   Specify the coefficients fixed-point type as a signed
        %   numerictype object. The default value of this property is
        %   numerictype(1,16).
        %
        %   See also numerictype.
        CoefficientsDataType = numerictype(1, 16);
    end
    
    properties (Constant, Hidden)
        % fixpt enum props
        RoundingMethodSet = matlab.system.internal.RoundingMethodSet;
        CoefficientsDataTypeSet = matlab.system.internal.DataTypeSet(...
            { matlab.system.internal.CustomDataType( ...
            'Signedness', {'Signed'}, 'Scaling', {'Unspecified', 'BinaryPoint'})});
    end
    
    properties (Nontunable, Access = protected)                    
        pIsFilterDesigned = false;
    end
    
    properties (Abstract, Access = protected, Nontunable)
        pSR
    end
    
    %----------------------------------------------------------------------
    % Abstract public methods
    %----------------------------------------------------------------------
    methods (Abstract)
        h = getFilter(obj);
    end
    %----------------------------------------------------------------------
    % Abstract protected methods
    %----------------------------------------------------------------------
    methods (Abstract, Access = protected)
        designFilter(obj,varargin);
        postProcessSampleRate(obj, val);
    end
    %----------------------------------------------------------------------
    % Abstract hidden methods
    %----------------------------------------------------------------------
    methods (Abstract, Hidden)
        props = getNonFixedPointProperties(~);
    end
    %----------------------------------------------------------------------
    % Abstract static hidden methods
    %----------------------------------------------------------------------
    methods (Abstract, Static, Hidden)
        num = designCompensator(...
            RateChangeFactor, DesignForMinimumOrder, ...
            NumberOfSections, DifferentialDelay, ...
            CICRateChangeFactor, FilterOrder, ...
            Fpass, Fstop, Apass, Astop, SampleRate);
        helpFixedPoint;
    end
    %----------------------------------------------------------------------
    % Public methods
    %----------------------------------------------------------------------
    methods
        function obj = CICCompensationBase(varargin)
            % Support name-value pair arguments
            setProperties(obj,nargin,varargin{:});
        end
        %------------------------------------------------------------------
        function set.DesignForMinimumOrder(obj, value)
            obj.DesignForMinimumOrder = value;
            needToDesignFilters(obj)
        end
        %------------------------------------------------------------------
        function set.CICRateChangeFactor(obj, value)
            validateattributes( value, {'numeric'}, ...
                {'real', 'positive', 'integer', 'scalar', 'finite'}, ...
                '', 'CICRateChangeFactor');
            obj.CICRateChangeFactor = value;
            needToDesignFilters(obj)
        end
        %------------------------------------------------------------------
        function set.CICDifferentialDelay(obj, value)
            validateattributes( value, {'numeric'}, ...
                {'real', 'positive', 'integer', 'scalar', 'finite'}, ...
                '', 'CICDifferentialDelay');
            obj.CICDifferentialDelay = value;
            needToDesignFilters(obj)
        end
        %------------------------------------------------------------------
        function set.CICNumSections(obj, value)
            validateattributes( value, {'numeric'}, ...
                {'real', 'positive', 'integer', 'scalar', '<=', 15}, ...
                '', 'CICNumSections');
            obj.CICNumSections = value;
            needToDesignFilters(obj)
        end
        %------------------------------------------------------------------
        function set.FilterOrder(obj, value)
            validateattributes(value, {'numeric'}, ...
                {'real', 'positive', 'integer', 'scalar', 'finite'}, ...
                '', 'FilterOrder');
            obj.FilterOrder = value;
            needToDesignFilters(obj)
        end
        %------------------------------------------------------------------
        function set.PassbandRipple(obj, value)
            validateattributes(value, {'numeric'}, ...
                {'real', 'positive', 'real', 'scalar', 'finite'},...
                '', 'PassbandRipple');
            obj.PassbandRipple = value;
            needToDesignFilters(obj)
        end
        %------------------------------------------------------------------
        function set.StopbandAttenuation(obj, value)
            validateattributes(value, {'numeric'}, ...
                {'real', 'positive', 'real', 'scalar', 'finite'},...
                '', 'StopbandAttenuation');
            obj.StopbandAttenuation = value;
            needToDesignFilters(obj)
        end
        %------------------------------------------------------------------
        function set.RoundingMethod(obj,val)
            obj.RoundingMethod = val;
            needToDesignFilters(obj)
        end
        %------------------------------------------------------------------
        function set.CoefficientsDataType(obj, val)
            obj.CoefficientsDataType = val;
            needToDesignFilters(obj)
        end
        %------------------------------------------------------------------
        function fdhdltool(obj,InputNumericType)
            %   FDHDLTOOL(FO, nt) launches the Generate HDL dialog that lets you
            %   customize and generate Verilog or VHDL code and test benches for
            %   the filter System object, FO. You have to call FDHDLTOOL
            %   again if you make changes in the filter, FO, in the command line.
            %
            %   The main dialog and two subordinate dialogs provide access to many
            %   options for customizing the generated filter and test bench code.
            %
            %   The Generate HDL main dialog categorizes options in two frames:
            %
            %   * HDL Filter - Options you are most likely to customize at least once:
            %   language selection, name and location of generated files, reset
            %   specifications, and optimizations.
            %
            %   * Test bench types - Options for naming and specifying the type of test
            %   bench files to generate, and specific types of stimuli the test benches
            %   are to apply.
            %
            %   EXAMPLE:
            %   fo  = dsp.CICCompensationInterpolator;
            %   inT = numerictype(1,16,15);
            %   fdhdltool(fo, inT)
                        
            if ~exist('InputNumericType','var')
                error(message('hdlfilter:privgeneratehdl:fdhdltoolinputdatatypenotspecified'));
            end
            
            sysObj = getFilter(obj, InputNumericType);
            fo     = sysobjHdl(sysObj, 'InputDataType', InputNumericType);
            fdhdltool(fo);
        end
        %------------------------------------------------------------------
        function generatehdl(obj,varargin)
            %   GENERATEHDL(FO, 'InputDataType', nt) automatically generates VHDL
            %   or Verilog code for the dsp.FarrowRateConverter, FO. The default
            %   language is VHDL; to generate Verilog, supply the
            %   property/value pair 'TargetLanguage','Verilog'. The file is written to
            %   the HDL source directory which defaults to 'hdlsrc' under the
            %   current directory. This directory will be created if necessary.
            %
            %   GENERATEHDL(FO, PARAMETER1, VALUE1, PARAMETER2, VALUE2, ...)
            %   generates the HDL code with parameter/value pairs. Valid properties
            %   and values for GENERATEHDL are listed in the Filter Design HDL
            %   Coder documentation section "Property Reference."
            %
            %   EXAMPLE:
            %   fo  = dsp.CICCompensationInterpolator;
            %   inT = numerictype(1,16,15);
            %   generatehdl(fo, 'InputDataType', inT)
            
            for k = 1:length(varargin)
                if iscell(varargin{k})
                    [varargin{k}{:}] = convertStringsToChars(varargin{k}{:});
                else
                    varargin{k} = convertStringsToChars(varargin{k});
                end
            end
            
            if nargin > 1 && any(strcmpi(varargin, 'InputDataType'))
                inT_Indices = find(strcmpi(varargin, 'InputDataType'));
                inNT = varargin{(inT_Indices(1) + 1)};
            else
                inNT = numerictype('double');
            end
            sysObj = getFilter(obj, inNT);
            fo     = sysobjHdl(sysObj, varargin{:});
            generatehdl(fo, varargin{:},'FilterSystemObject',clone(obj));
        end
    end
    %----------------------------------------------------------------------
    % Protected methods
    %----------------------------------------------------------------------
    methods (Access=protected)
        function flag = isInputSizeMutableImpl(~,~)
            flag = false;
        end
        
        function flag = isInputComplexityMutableImpl(~,~)
            flag = false;
        end
        function N = getNumInputsImpl(~)
            % Number of system inputs
            N = 1;
        end
        %------------------------------------------------------------------
        function N = getNumOutputsImpl(~)
            % Number of system outputs
            N = 1;
        end
        %------------------------------------------------------------------
        function flag = isInactivePropertyImpl(obj, prop)
            flag = isInactivePropertyImpl@dsp.internal.SampleRateEngine(obj, prop);
            switch prop
                case 'FilterOrder'
                    if obj.DesignForMinimumOrder
                        flag = true;
                    end
                case 'StopbandFrequency'
                    if ~obj.DesignForMinimumOrder
                        flag = true;
                    end
            end
        end
        %------------------------------------------------------------------
        function needToDesignFilters(obj)
            obj.pIsFilterDesigned = false;
        end
        %------------------------------------------------------------------
        function d = convertToDFILT(obj,arith)
            % Convert the System object to a mfilt object for analysis 
            sysObj = getFilter(obj);
            if strcmp(arith,'fixed') && ~isLocked(sysObj)
                sysObj.CoefficientsDataType = 'custom';
                coeffDT = obj.CoefficientsDataType;
                coeffDT.Signedness = 'Auto';
                sysObj.CustomCoefficientsDataType = coeffDT;
            end
            d = todfilt(sysObj,arith);
        end
        %------------------------------------------------------------------
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@dsp.internal.SampleRateEngine(obj);
            s.pSR = obj.pSR;
            if isLocked(obj)
                s.pIsFilterDesigned    = obj.pIsFilterDesigned;
            end
            s = saveFA(obj, s);   % Save filter analysis class properties
        end
        %------------------------------------------------------------------
        function loadObjectImpl(obj, s, wasLocked)
            if isfield(s, 'CoefficientsDataType')
                % backwards compatibility for objects saved before R2015b
                if strcmp(s.CoefficientsDataType.Signedness, 'Auto')
                    s.CoefficientsDataType.Signedness = 'Signed';
                end
            end
            loadObjectImpl@dsp.internal.SampleRateEngine(obj,s,wasLocked);
            if wasLocked
                obj.pIsFilterDesigned    = s.pIsFilterDesigned;
            end 
            if isfield(s, 'pSR')
                obj.pSR = s.pSR;
            else
                obj.pSR = s.SampleRate;
            end
            loadFA(obj, s, wasLocked); % Load filter analysis class properties
        end
        %------------------------------------------------------------------
        function y = infoImpl(obj,varargin)
            y = infoFA(obj,varargin{:});
        end
    end
    %----------------------------------------------------------------------
    % Hidden methods
    %----------------------------------------------------------------------
    methods (Hidden)
        function flag = isPropertyActive(obj,prop)
            % Need to implement this for dsp.internal.FilterAnalysisMultirate
            flag = ~isInactivePropertyImpl(obj, prop);      
        end
        %------------------------------------------------------------------
        function props = getFixedPointProperties(~)
            % Need to implement this for dsp.internal.FilterAnalysisMultirate
            props = dsp.internal.CICCompensationBase.getDisplayFixedPointPropertiesImpl;
        end
        %------------------------------------------------------------------
        function restrictionsCell = getFixedPointRestrictions(obj,prop)
            % Need to implement this for dsp.internal.FilterAnalysisMultirate
            switch prop
                case {'CoefficientsDataType'}
                    restrictionsCell = {'AUTOSIGNED'};
                otherwise
                    error(message(...
                        'dsp:dsp:private:FilterSystemObjectBase:InvalidProperty',prop,class(obj)))
            end
        end
    end
    %----------------------------------------------------------------------
    % Static hidden methods
    %----------------------------------------------------------------------
    methods (Static,Hidden)
        function props = getDisplayFixedPointPropertiesImpl()
            % Need to implement this for dsp.internal.FilterAnalysisMultirate
            props = {'CoefficientsDataType', 'RoundingMethod'};
        end
        %------------------------------------------------------------------
        function props = getCICProperties()
            % CIC properties used in display in MATLAB System block
            props = {...
                matlab.system.display.internal.Property('CICRateChangeFactor', Description='dsp:system:CICCompensationBase:CICRateChangeFactor_MP'),...
                matlab.system.display.internal.Property('CICNumSections', Description='dsp:system:CICCompensationBase:CICNumSections_MP'),...
                matlab.system.display.internal.Property('CICDifferentialDelay', Description='dsp:system:CICCompensationBase:CICDifferentialDelay_MP'),...
            };
        end
        %------------------------------------------------------------------
        function props = getFilterProperties()
            props = {...
                matlab.system.display.internal.Property('DesignForMinimumOrder', Description='dsp:system:CICCompensationBase:DesignForMinimumOrder_MP'),...
                matlab.system.display.internal.Property('FilterOrder', Description='dsp:system:CICCompensationBase:FilterOrder_MP'),...
                matlab.system.display.internal.Property('PassbandFrequency', Description='dsp:system:CICCompensationBase:PassbandFrequency_MP'),...
                matlab.system.display.internal.Property('StopbandFrequency', Description='dsp:system:CICCompensationBase:StopbandFrequency_MP'),...
                matlab.system.display.internal.Property('PassbandRipple', Description='dsp:system:CICCompensationBase:PassbandRipple_MP'),...
                matlab.system.display.internal.Property('StopbandAttenuation', Description='dsp:system:CICCompensationBase:StopbandAttenuation_MP'),...
                matlab.system.display.internal.Property('InheritSampleRate', Description='dsp:system:AbstractSampleRateEngine:InheritSampleRate_MP'), ...
                matlab.system.display.internal.Property('SampleRate', Description='dsp:system:AbstractSampleRateEngine:SampleRate_MP'), ...
                };
        end
    end
end

