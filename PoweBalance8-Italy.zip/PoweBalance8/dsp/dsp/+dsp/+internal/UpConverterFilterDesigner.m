classdef UpConverterFilterDesigner < dsp.internal.ConverterFilterDesignerBase
    %dsp.internal.UpConverterFilterDesigner Interpolation filter cascade designer
    %   This object designs a cascade of interpolation filter System objects to
    %   be used by the dsp.DigitalUpConverter class. The cascade consists of
    %   four stages.
    %
    %   Stage1   = halfband or lowpass interpolation filter (this
    %              stage may or may not be bypassed, depending on the property
    %              settings of the object)
    %   Stage2   = CIC compensator interpolation filter
    %   Stage3   = CIC interpolator filter (this stage will be implemented as a
    %              dsp.FIRInterpolator System object when the Arithmetic
    %              property is set to 'double' or 'single', or as a
    %              dsp.CICInterpolator System object when the Arithmetic
    %              property is set to 'fixed'.
    %  GainStage = Gain stage to normalize the gain of the CIC interpolator.
    
    %   Copyright 2010-2020 The MathWorks, Inc.
    %#codegen
    %#ok<*EMCA>
    
    properties (Nontunable)
        %SampleRate Sample rate at the input of the filter cascade in Hertz
        SampleRate = 300e3;
        %InterpolationFactor Interpolation factor
        %   This property can be a scalar, a 1x2 vector, or a 1x3 vector. If it is
        %   a scalar, the interpolation factor for each stage is computed
        %   automatically. If it is a 1x2 vector, the first filter stage is
        %   bypassed. The elements of the 1x2 vector specify the interpolation
        %   factors for the second and third interpolation stages.
        InterpolationFactor = 100;
        %OrderStage1 Order of first filter stage
        %   This property holds the order of the first filter stage. This property
        %   applies when MinimumOrderDesign is false.
        OrderStage1 = 10;
        %OrderStage3 Order of third filter stage
        %   This property holds the number of CIC sections. This property applies
        %   when MinimumOrderDesign is false.
        OrderStage3 = 3;
    end
    
    properties (SetAccess = private)
        %Stage1FilterSysObj Handle to System object that forms the first
        %stage
        Stage1FilterSysObj
    end
    
    properties (Access = private)
        %pStage1Filter Handle to an mfilt object that forms the first stage
        pStage1Filter
    end
    
    properties (Nontunable, Access = private)
        %pFstopStage1 stopband frequency of first filter stage in Hertz
        pFstopStage1
        %pFcuttofStage1 Cutoff frequency of first stage in Hertz
        pFcuttofStage1
        %pTWStage1 Transition width of first stage in Hertz
        pTWStage1
        %pBypassStage1 Flag to determine whether the first stage is bypassed or
        %not. Can be set to true or false.
        pBypassStage1
        %pFilterTypeStage1 Type of filter implemented in the first stage. This
        %property can be set to 'lowpass' or 'halfband'
        pFilterTypeStage1
    end
    
    %----------------------------------------------------------------------
    % Public methods
    %----------------------------------------------------------------------
    methods
        %CONSTRUCTOR
        function obj = UpConverterFilterDesigner(varargin)
            obj@dsp.internal.ConverterFilterDesignerBase(varargin{:})
            setProperties(obj, nargin, varargin{:});
        end
        %------------------------------------------------------------------
        function [d,f] = groupDelay(obj,varargin)
            isDesignAvailable(obj)
            [d,w] = grpdelay(obj.pCascadeFilter,varargin{:});
            f = (w/pi)*obj.SampleRate*prod(obj.InterpolationFactor)/2;
        end
        %------------------------------------------------------------------
        function Mvect = getInterpolationFactors(obj)
            % If a design is available, return the interpolation factors for each
            % stage
            isDesignAvailable(obj)
            Mvect = [obj.pM1 obj.pM2 obj.pM3];
        end
        %------------------------------------------------------------------
        function flag = isFirstStageBypassed(obj)
            % Ask if first stage has been bypassed or not
            isDesignAvailable(obj)
            flag = obj.pBypassStage1;
        end
        %------------------------------------------------------------------
        function hfvt = visualizeFilterStages(obj)
            %visualizeFilterStages Display response of filter stages
            %   visualizeFilterStages(H) plots the magnitude response of the
            %   interpolation filter stages and of the cascade response. It also
            %   plots a mask based on the filter specifications.
            %
            %   hfvt = visualizeFilterStages(H) returns a handle to an fvtool
            %   object.
            %
            %   Call the fvtool method if you only want to visualize the cascade
            %   response.
            
            isDesignAvailable(obj)
            
            [filt, figureProps] = getFvtoolParametersForVFS(obj);
            hfvt = fvtool(filt{:});
            set(hfvt, figureProps{:});
            
            legendCell = getLegendStringForVFS(obj);
            legend(hfvt,legendCell{:});
            
            cascadeGain =  20*log10(obj.pM1*obj.pM2*obj.pM3);
            addMask(obj,cascadeGain,hfvt);
        end
        %------------------------------------------------------------------
        function hfvt = fvtool(obj,varargin)
            %fvtool Display response of filter cascade
            cascadeGain =  20*log10(obj.pM1*obj.pM2*obj.pM3);
            hfvt = privFvtool(obj,obj.pFsStage3,cascadeGain,varargin{:});
        end
        %------------------------------------------------------------------
        function SystemObjectsToMfilt(obj)
            %Create mfilt filter objects and cascade for filter analysis
            
            if ~obj.pBypassStage1
                obj.pStage1Filter = todfilt(obj.Stage1FilterSysObj, obj.Arithmetic);
            end
            
            obj.pCICCompFilter = todfilt(obj.CICCompFilterSysObj, obj.Arithmetic);
            obj.pCICFilter = todfilt(obj.CICFilterSysObj, obj.Arithmetic);
            obj.pGainFilter = dfilt.scalar(obj.GainFilter);
            
            if obj.pBypassStage1
                obj.pCascadeFilter = cascade(obj.pCICCompFilter, obj.pCICFilter,...
                    obj.pGainFilter);
            else
                obj.pCascadeFilter = cascade(obj.pStage1Filter, obj.pCICCompFilter, ...
                    obj.pCICFilter, obj.pGainFilter);
            end
        end
    end
    %----------------------------------------------------------------------
    % Protected methods
    %----------------------------------------------------------------------
    methods (Access = protected)
        function N = getNumInputsImpl(~)
            % Specify number of System inputs
            N=1;
        end
        %------------------------------------------------------------------
        function N = getNumOutputsImpl(~)
            % Specify number of System inputs
            N=0;
        end
        %------------------------------------------------------------------
        function releaseImpl(obj)
            if ~obj.pBypassStage1
                release(obj.Stage1FilterSysObj);
            end
            release(obj.CICCompFilterSysObj);
            release(obj.CICFilterSysObj);
            obj.IsFilterDesignAvailable = false;
        end
        %------------------------------------------------------------------
        function setupImpl(obj, inputFixedPointArguments)
            % Initialize private properties to be used later
            
            if (isempty(inputFixedPointArguments) &&...
                    obj.IsFilterDesignAvailable)
                % If design is available for non fixed-point cases, then do
                % not redesign
                return;
            end
            
            %Decide if first filter section is bypassed or not. If not,
            %then set the filter type to 'halfband' or 'lowpass'. Set the
            %interpolation factor values for each section.
            %When user specifies coefficients, just set the interpolation
            %factors in the corresponding properties.
            setFilterSectionTypes(obj)
            
            %Verify that stopband frequency is within valid frequency range
            checkPropertyValues(obj)
            
            %Compute rate of operation and stopband frequencies for filter
            %sections.
            computeFrequencySpecifications(obj);
            
            % Compute CIC null frequencies
            computeCICNullFrequencies(obj);
            
            % Design the filters
            if obj.MinimumOrderDesign
                obj.designFiltersMinOrder(inputFixedPointArguments);
            else
                obj.designFiltersSpecifiedOrders(inputFixedPointArguments);
            end
        end
        %------------------------------------------------------------------
        function setFilterSectionTypes(obj)
            %Determine if the first filter section is bypassed or not. If not, then
            %determine whether the first section should be a halfband or a lowpass
            %interpolation filter. Set the interpolation factor values for each
            %section.
            
            coder.extrinsic('dsp.internal.ConverterFilterDesignerBase.setSectionFactors');
            
            
            if isscalar(obj.InterpolationFactor)
                % Factor the InterpolationFactor into three values for each section.
                % Flip the output vector so that largest value goes to the CIC
                % section. Bypass first filter section if MinimumOrderDesign is true
                % and M1 equals 1
                
                MVect = coder.const(@obj.setSectionFactors,obj.InterpolationFactor);
                obj.pM1 = MVect(3);
                obj.pM2 = MVect(2);
                obj.pM3 = MVect(1);
                
                if obj.pM1 == 1 && obj.MinimumOrderDesign
                    %MinimumOrderDesign is true, and M1=1
                    obj.pBypassStage1 = true;
                    obj.pFilterTypeStage1 = 'lowpass'; % Not used, needed for codegen
                elseif obj.pM1 == 1 && ~obj.MinimumOrderDesign
                    if strcmpi(obj.StopbandFrequencySource, 'property')
                        %MinimumOrderDesign is false, and M1=1, StopbandFrequencySource
                        %= 'Property'
                        obj.pBypassStage1 = false;
                    else
                        obj.pBypassStage1 = true;
                        obj.pFilterTypeStage1 = 'lowpass'; % Not used, needed for codegen
                        coder.internal.warning('dsp:system:DigitalUpConverter:bypassedFirstStage');
                    end
                elseif obj.pM1 == 2
                    %M1=2
                    obj.pBypassStage1 = false;
                    if strcmpi(obj.StopbandFrequencySource, 'auto')
                        obj.pFilterTypeStage1 = 'halfband';
                    else
                        obj.pFilterTypeStage1 = 'lowpass';
                    end
                end
                
            elseif length(obj.InterpolationFactor) == 2
                % InterpolationFactor is a 1x2 vector, bypass the first filter
                % section
                obj.pBypassStage1 = true;
                obj.pFilterTypeStage1 = 'lowpass'; % Not used, needed for codegen
                obj.pM1 = 1;
                obj.pM2 = obj.InterpolationFactor(1);
                obj.pM3 = obj.InterpolationFactor(2);
                
            elseif length(obj.InterpolationFactor) == 3
                %InterpolationFactor is a 1x3 vector
                obj.pM1 = obj.InterpolationFactor(1);
                obj.pM2 = obj.InterpolationFactor(2);
                obj.pM3 = obj.InterpolationFactor(3);
                
                if obj.pM1 == 1
                    if strcmpi(obj.StopbandFrequencySource, 'auto')
                        obj.pBypassStage1 = true;
                        obj.pFilterTypeStage1 = 'lowpass'; % Not used, needed for codegen
                        coder.internal.warning('dsp:system:DigitalUpConverter:bypassedFirstStage1');
                    else
                        obj.pBypassStage1 = false;
                        obj.pFilterTypeStage1 = 'lowpass';
                    end
                else
                    obj.pBypassStage1 = false;
                    if strcmpi(obj.StopbandFrequencySource, 'auto')
                        obj.pFilterTypeStage1 = 'halfband';
                    else
                        obj.pFilterTypeStage1 = 'lowpass';
                    end
                end
            else
                coder.internal.errorIf(true, 'dsp:system:DigitalUpConverter:invalidInterpFactor');
            end
        end
        %-------------------------------------------------------------------------
        function checkPropertyValues(obj)
            %Verify that property values are within valid frequency ranges
            
            if strcmpi(obj.StopbandFrequencySource,'property')
                coder.internal.errorIf(obj.pBypassStage1 && ...
                    (obj.StopbandFrequency > obj.SampleRate*obj.pM2/2), ...
                    'dsp:system:DigitalUpConverter:stopbandFreqTooLarge', ...
                    floor(obj.SampleRate*obj.pM2/2), ...
                    round((obj.SampleRate*obj.pM2/2 - floor(obj.SampleRate*obj.pM2/2)) * 10), ...
                    obj.pM2);
                coder.internal.errorIf(~obj.pBypassStage1 && ...
                    (obj.StopbandFrequency > obj.SampleRate*obj.pM1/2), ...
                    'dsp:system:DigitalUpConverter:stopbandFreqTooLarge1', ...
                    floor(obj.SampleRate*obj.pM1/2), ...
                    round((obj.SampleRate*obj.pM1/2 - floor(obj.SampleRate*obj.pM1/2)) * 10), ...
                    obj.pM1);
                coder.internal.errorIf(obj.StopbandFrequency <= obj.pPassbandFrequency, ...
                    'dsp:system:DigitalUpConverter:stopbandFreqTooSmall');
            end
            
            coder.internal.errorIf(obj.pPassbandFrequency >= obj.SampleRate/2, ...
                'dsp:system:DigitalUpConverter:passbandFreqTooLarge');
            
        end
        %-------------------------------------------------------------------------
        function computeFrequencySpecifications(obj)
            %Compute rate of operation and stopband frequencies for filter
            %sections.
            
            % Frequency of operation of filter stages
            obj.pFsStage1 = obj.SampleRate*obj.pM1;
            obj.pFsStage2 = obj.SampleRate*obj.pM1*obj.pM2;
            obj.pFsStage3 = obj.SampleRate*obj.pM1*obj.pM2*obj.pM3;
            
            if strcmpi(obj.StopbandFrequencySource,'property')
                % Stopband of first filter stage
                obj.pFstopStage1 = obj.StopbandFrequency;
                obj.pTWStage1 = obj.pFstopStage1 - obj.pPassbandFrequency;
                obj.pFcuttofStage1 = obj.pPassbandFrequency + obj.pTWStage1/2;
                % Stopband frequency of cascade response
                obj.pCascadeFilterStopbandFrequency = obj.StopbandFrequency;
            else
                % Cutoff is placed at input Nyquist rate
                obj.pFcuttofStage1 = obj.SampleRate/2;
                % Transition width of first stage
                obj.pTWStage1 = 2*(obj.pFcuttofStage1 - obj.pPassbandFrequency);
                % Stopband frequency of first stage
                obj.pFstopStage1 = obj.pFcuttofStage1 + obj.pTWStage1/2;
                % Stopband frequency of cascade response
                obj.pCascadeFilterStopbandFrequency = obj.pFstopStage1;
            end
            
            if obj.pBypassStage1
                obj.pFstopStage2 = obj.pFstopStage1;
                if obj.pM2 == 1
                    % If the interpolation factor is prime, the CIC
                    % Compensator will be a single-rate filter. In this
                    % case, we need to pull the stopband frequency to
                    % the cut-off value. Otherwise, it goes above
                    % pFsStage2/2 which isn't acceptable for design.
                    % This is only when StopbandFrequencySource = Auto
                    obj.pFstopStage2 = obj.pFcuttofStage1;
                end
            else
                obj.pFstopStage2 = obj.pFsStage1 - obj.pFstopStage1;
            end
        end
        %-------------------------------------------------------------------------
        function computeCICNullFrequencies(obj)
            % Compute frequency locations of CIC nulls
            D = 1;
            R = obj.pM3;
            f = 1:ceil((D*R-1)/2);
            Fo = 2*f/(D*R); % Normalized null frequencies between 0 and 1
            obj.pFCICNulls = Fo * ...
                obj.SampleRate*obj.pM1*obj.pM2*obj.pM3/2;
        end
        %-------------------------------------------------------------------------
        function CICGain = designCICInterpolationFilter(obj,NumCICSections,inputDataType)
            % Design a CIC interpolation response and implement it as an FIR filter
            % when Arithmetic is ''double' or 'single', or as a CIC filter when
            % Arithmetic is 'fixed'. Output the gain of the CIC filter.
            
            coder.extrinsic('dsp.internal.ConverterFilterDesignerBase.getCICFIRCoefficients');
            coder.extrinsic('dsp.internal.UpConverterFilterDesigner.getCICFixedPointProperties');
            if ~strcmpi(obj.Arithmetic, 'fixed')
                coeffs = coder.const(@obj.getCICFIRCoefficients,NumCICSections,obj.pM3);
                obj.CICFilterSysObj = dsp.FIRInterpolator('InterpolationFactor', obj.pM3, ...
                    'Numerator', coeffs);
            else
                % Set word and frac lengths as per FullPrecision mode for CIC
                % Interpolator
                fixedPointProperties = coder.const(@obj.getCICFixedPointProperties,...
                    NumCICSections, obj.pM3, inputDataType);

                obj.CICFilterSysObj = dsp.CICInterpolator('InterpolationFactor', obj.pM3, ...
                    'NumSections', NumCICSections, ...
                    'FixedPointDataType', 'Specify word and fraction lengths', ...
                    'SectionWordLengths', fixedPointProperties.SectionWordLengths, ...
                    'SectionFractionLengths', fixedPointProperties.SectionFracLengths, ...
                    'OutputWordLength', fixedPointProperties.OutputWordLength, ...
                    'OutputFractionLength', fixedPointProperties.OutputFracLength);
            end
            CICGain = obj.pM3^(NumCICSections-1);
        end
        %-------------------------------------------------------------------------
        function designFiltersSpecifiedOrders(obj, filterOutputDataType)
            % Design cascade of interpolation filters with specified orders,
            % passband and stopband frequencies.
            
            if ~isempty(filterOutputDataType)
                coder.internal.errorIf(~strcmp(obj.Arithmetic,'fixed'), ...
                    'dsp:system:DigitalUpConverter:invalidArithmetic');
                
                coder.internal.errorIf(~isa(filterOutputDataType,'embedded.numerictype'), ...
                    'dsp:system:DigitalUpConverter:invalidInputType');
            end
            
            NumCICSections = obj.OrderStage3;
            
             % Coefficients for CIC Compensator stage and Third stage
            coder.extrinsic('dsp.internal.UpConverterFilterDesigner.getFilterCoeffsSpecifiedOrder');
            [coeffs2, coeffs1, Astop2, Astop1] = coder.const(@dsp.internal.UpConverterFilterDesigner.getFilterCoeffsSpecifiedOrder,...
                obj.pM2, NumCICSections, obj.pM3, obj.OrderStage2, obj.pPassbandFrequency, ...
                obj.pFstopStage2, obj.pFsStage2, obj.pBypassStage1, obj.pFilterTypeStage1, ...
                obj.pM1, obj.OrderStage1, obj.pTWStage1, obj.pFsStage1, obj.pFstopStage1);
            
            % Design third stage (CIC)
            CICGain = designCICInterpolationFilter(obj,NumCICSections,filterOutputDataType);
            
            % CIC gain normalization filter - the gain is the excess gain from the
            % gain due to the interpolation factor M3
            obj.GainFilter = 1/CICGain;
            
            coder.extrinsic('dsp.internal.UpConverterFilterDesigner.getFixedPointPropertiesSpecifiedOrders');
            if strcmpi(obj.Arithmetic,'fixed')
                % Find the minimum coefficient lengths for the CIC compensator, stage
                % 1, and scaling factor. Measure the passband ripple and stopband
                % attenuation of each stage and of the cascade response using double
                % precision. These measurements will be the baseline to compute the
                % smallest possible coefficient word lengths and scale factor data
                % type.
                
                fixedPointProperties = coder.const(@dsp.internal.UpConverterFilterDesigner.getFixedPointPropertiesSpecifiedOrders, ...
                    obj.InputNumericType, filterOutputDataType, obj.pM3, 1, NumCICSections, CICGain, ...
                    obj.pM2, coeffs2, obj.pM1, coeffs1, Astop2, Astop1, ...
                    obj.pBypassStage1, obj.SampleRate, obj.pFCICNulls, ...
                    obj.pFstopStage2, obj.pFstopStage1, obj.pNumMagRespMeasPoints, ...
                    obj.MinimumOrderDesign, obj.PassbandRipple, obj.StopbandAttenuation, ...
                    obj.pCascadeFilterStopbandFrequency, obj.pPassbandFrequency, obj.InterpolationFactor, ...
                    obj.pM1, obj.pM2, obj.pM3);
                
            end
            
            % First stage design
            if ~obj.pBypassStage1
                if ~strcmpi(obj.Arithmetic,'fixed')
                    obj.Stage1FilterSysObj = dsp.FIRInterpolator('InterpolationFactor', obj.pM1, ...
                        'Numerator', coeffs1,  'FullPrecisionOverride', false);
                else
                    % We do not set the output data type since that will be set by
                    % the DDC object.
                    obj.Stage1FilterSysObj = dsp.FIRInterpolator('InterpolationFactor', obj.pM1, ...
                        'Numerator', coeffs1,  'FullPrecisionOverride', false, ...
                        'CoefficientsDataType', 'Custom', ...
                        'CustomCoefficientsDataType', numerictype([],...
                        fixedPointProperties.FirstFilterWordLength,...
                        fixedPointProperties.FirstFilterFracLength), ...
                        'ProductDataType', 'Custom', ...
                        'AccumulatorDataType', 'Custom', ...
                        'CustomProductDataType', numerictype([],...
                        fixedPointProperties.FirstFilterProductWordLength,...
                        fixedPointProperties.FirstFilterProductFracLength), ...
                        'CustomAccumulatorDataType', numerictype([],...
                        fixedPointProperties.FirstFilterAccumWordLength,...
                        fixedPointProperties.FirstFilterAccumFracLength), ...
                        'OutputDataType', 'Custom', ...
                        'CustomOutputDataType', filterOutputDataType);
                end
            else
                obj.Stage1FilterSysObj = [];
            end
            
            % Design second stage (CIC compensator)
            if ~strcmpi(obj.Arithmetic,'fixed')
                obj.CICCompFilterSysObj = dsp.FIRInterpolator('InterpolationFactor', obj.pM2, ...
                    'Numerator', coeffs2, 'FullPrecisionOverride', false);
            else
                % Set CIC compensator output data type to FiltersInputNumericType
                obj.CICCompFilterSysObj = dsp.FIRInterpolator('InterpolationFactor', obj.pM2, ...
                    'Numerator', coeffs2, 'FullPrecisionOverride', false, ...
                    'CoefficientsDataType', 'Custom', ...
                    'CustomCoefficientsDataType', numerictype([],...
                    fixedPointProperties.CICCompWordLength,...
                    fixedPointProperties.CICCompFracLength), ...
                    'ProductDataType', 'Custom', ...
                    'AccumulatorDataType', 'Custom', ...
                    'CustomProductDataType', numerictype([],...
                    fixedPointProperties.CICCompProductWordLength,...
                    fixedPointProperties.CICCompProductFracLength), ...
                    'CustomAccumulatorDataType', numerictype([],...
                    fixedPointProperties.CICCompAccumWordLength,...
                    fixedPointProperties.CICCompAccumFracLength), ...
                    'OutputDataType', 'Custom', ...
                    'CustomOutputDataType', filterOutputDataType);
            end
        end
        %-------------------------------------------------------------------------
        function designFiltersMinOrder(obj, filterInputDataType)
            % Design cascade of minimum order interpolation filters that meets
            % specifications.
            
            if ~isempty(filterInputDataType)
                coder.internal.errorIf(~strcmp(obj.Arithmetic,'fixed'), ...
                    'dsp:system:DigitalUpConverter:invalidArithmetic');
                
                coder.internal.errorIf(~isa(filterInputDataType,'embedded.numerictype'), ...
                    'dsp:system:DigitalUpConverter:invalidInputType');
            end
            
            coder.extrinsic('dsp.internal.UpConverterFilterDesigner.getFilterCoeffsMinOrder');
            % Get the number of CIC sections and coefficients of other
            % filters in case of minimum order design
            [NumCICSections, coeffs2, coeffs1, CICNormFact, Astop2, Astop1, isDone] = coder.const(@dsp.internal.UpConverterFilterDesigner.getFilterCoeffsMinOrder,...
                obj.PassbandRipple, obj.StopbandAttenuation, ...
                obj.pBypassStage1, obj.SampleRate, obj.pFCICNulls, ...
                obj.pFstopStage2, obj.pFstopStage1, obj.pNumMagRespMeasPoints, ...
                obj.pM2, obj.pPassbandFrequency, obj.pFsStage2, ...
                obj.pFilterTypeStage1, obj.pM1, obj.pTWStage1, obj.pFsStage1, obj.pFsStage3, ...
                obj.pM3, obj.pPassBandRippleReductionFactor, obj.pStopbandAttenuationStep, ...
                obj.Arithmetic,obj.MinimumOrderDesign, obj.InterpolationFactor);
            
            % Design third stage (CIC)
            designCICInterpolationFilter(obj,NumCICSections, filterInputDataType);
            
            % CIC gain normalization filter
            obj.GainFilter = CICNormFact;
            
            coder.extrinsic('dsp.internal.UpConverterFilterDesigner.getFixedPointPropertiesMinOrder');
            if ~isDone
                if strcmpi(obj.Arithmetic,'fixed')
                    warning(message('dsp:system:DigitalUpConverter:noConvergenceDtype'));
                else
                    warning(message('dsp:system:DigitalUpConverter:noConvergence'));
                end
            else
                if strcmpi(obj.Arithmetic,'fixed')
                    % Find the minimum coefficient lengths for the CIC compensator, stage
                    % 3, and scaling factor. The specified passband ripple and stopband
                    % attenuation  of the cascade response will be the baseline to compute the
                    % smallest possible coefficient word lengths and scale factor data
                    % type.
                    
                    fixedPointProperties = coder.const(@dsp.internal.UpConverterFilterDesigner.getFixedPointPropertiesMinOrder, ...
                        obj.InputNumericType,  filterInputDataType, obj.pM3, 1, NumCICSections, CICNormFact, ...
                        obj.pM2, coeffs2, obj.pM1, coeffs1, Astop2, Astop1, ...
                        obj.pBypassStage1, obj.SampleRate, obj.pFCICNulls, ...
                        obj.pFstopStage2, obj.pFstopStage1, obj.pNumMagRespMeasPoints, ...
                        obj.MinimumOrderDesign, obj.PassbandRipple, obj.StopbandAttenuation, ...
                        obj.pCascadeFilterStopbandFrequency, obj.pPassbandFrequency, ...
                        obj.PassbandRipple, obj.StopbandAttenuation, obj.InterpolationFactor, ...
                        obj.pM1, obj.pM2, obj.pM3);
                end
            end
            
            % First stage design
            if ~obj.pBypassStage1
                if ~strcmpi(obj.Arithmetic,'fixed')
                    obj.Stage1FilterSysObj = dsp.FIRInterpolator('InterpolationFactor', obj.pM1, ...
                        'Numerator', coeffs1,  'FullPrecisionOverride', false);
                else
                    % We do not set the output data type since that will be set by
                    % the DDC object.
                    obj.Stage1FilterSysObj = dsp.FIRInterpolator('InterpolationFactor', obj.pM1, ...
                        'Numerator', coeffs1,  'FullPrecisionOverride', false, ...
                        'CoefficientsDataType', 'Custom', ...
                        'CustomCoefficientsDataType', numerictype([],...
                        fixedPointProperties.FirstFilterWordLength,...
                        fixedPointProperties.FirstFilterFracLength), ...
                        'ProductDataType', 'Custom', ...
                        'AccumulatorDataType', 'Custom', ...
                        'CustomProductDataType', numerictype([],...
                        fixedPointProperties.FirstFilterProductWordLength,...
                        fixedPointProperties.FirstFilterProductFracLength), ...
                        'CustomAccumulatorDataType', numerictype([],...
                        fixedPointProperties.FirstFilterAccumWordLength,...
                        fixedPointProperties.FirstFilterAccumFracLength), ...
                        'OutputDataType', 'Custom', ...
                        'CustomOutputDataType', filterInputDataType);
                end
            else
                obj.Stage1FilterSysObj = [];
            end
            
            % Design second stage (CIC compensator)
            if ~strcmpi(obj.Arithmetic,'fixed')
                obj.CICCompFilterSysObj = dsp.FIRInterpolator('InterpolationFactor', obj.pM2, ...
                    'Numerator', coeffs2, 'FullPrecisionOverride', false);
            else
                % Set CIC compensator output data type to FiltersInputNumericType
                obj.CICCompFilterSysObj = dsp.FIRInterpolator('InterpolationFactor', obj.pM2, ...
                    'Numerator', coeffs2, 'FullPrecisionOverride', false, ...
                    'CoefficientsDataType', 'Custom', ...
                    'CustomCoefficientsDataType', numerictype([],...
                    fixedPointProperties.CICCompWordLength,...
                    fixedPointProperties.CICCompFracLength), ...
                    'ProductDataType', 'Custom', ...
                    'AccumulatorDataType', 'Custom', ...
                    'CustomProductDataType', numerictype([],...
                    fixedPointProperties.CICCompProductWordLength,...
                    fixedPointProperties.CICCompProductFracLength), ...
                    'CustomAccumulatorDataType', numerictype([],...
                    fixedPointProperties.CICCompAccumWordLength,...
                    fixedPointProperties.CICCompAccumFracLength), ...
                    'OutputDataType', 'Custom', ...
                    'CustomOutputDataType', filterInputDataType);
            end
        end
        %------------------------------------------------------------------
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@dsp.internal.ConverterFilterDesignerBase(obj);
            
            s.Stage1FilterSysObj = matlab.System.saveObject(obj.Stage1FilterSysObj);
            s.pStage1Filter = obj.pStage1Filter;
            s.pBypassStage1 = obj.pBypassStage1;
            s.pFilterTypeStage1 = obj.pFilterTypeStage1;
            s.pFstopStage1 = obj.pFstopStage1;
            s.pFcuttofStage1 = obj.pFcuttofStage1;
            s.pTWStage1 = obj.pTWStage1;
        end
        %------------------------------------------------------------------
        function loadObjectImpl(obj, s,wasLocked)
            loadSubObjects(obj,s,wasLocked);

            obj.Stage1FilterSysObj = matlab.System.loadObject(s.Stage1FilterSysObj);
            obj.pStage1Filter = s.pStage1Filter;
            obj.pBypassStage1 = s.pBypassStage1;
            obj.pFilterTypeStage1 = s.pFilterTypeStage1;
            obj.pFstopStage1 = s.pFstopStage1;
            obj.pFcuttofStage1 = s.pFcuttofStage1;
            obj.pTWStage1 = s.pTWStage1;
            
            % Call the base class method
            loadObjectImpl@matlab.System(obj, s);
        end
    end
    %----------------------------------------------------------------------
    % Static methods
    %----------------------------------------------------------------------
    methods (Static, Hidden)
        function [coeffs2, coeffs1, Astop2, Astop1] = getFilterCoeffsSpecifiedOrder(...
                pM2, NumCICSections, pM3, OrderStage2, pPassbandFrequency, ...
                pFstopStage2, pFsStage2, pBypassStage1, pFilterTypeStage1, ...
                pM1, OrderStage1, pTWStage1, pFsStage1, pFstopStage1)
            % Compute coefficients for CIC Compensator and Third stage
            % filter
            
            % Suppress MFILT deprecation warning on calling design method
            % on an fdesign object without "SystemObject" flag set to true.
            w = warning('off', 'dsp:fdesign:basecatalog:UseSystemObjectForMultirateDesigns');
            restoreWarn = onCleanup(@() warning(w));
            
            % First stage design
            if ~pBypassStage1
                if strcmp(pFilterTypeStage1,'halfband')
                    d = fdesign.interpolator(pM1,'halfband','n,tw',...
                        OrderStage1,pTWStage1,pFsStage1);
                    %Kaiserwin is used to ensure convergence of halfband design
                    pStage1Filter = design(d,'kaiserwin', AllowLegacyFilters=true);
                    coeffs1 = pStage1Filter.Numerator;
                else
                    d = fdesign.interpolator(pM1,'lowpass','n,fp,fst',...
                        OrderStage1, pPassbandFrequency,...
                        pFstopStage1,pFsStage1);
                    pStage1Filter = design(d,'equiripple', AllowLegacyFilters=true);
                    coeffs1 = pStage1Filter.Numerator;
                end
                m1 = measure(pStage1Filter);
                Astop1 = m1.Astop;
            else
                coeffs1 = [];
                Astop1 = [];
            end
            
            % Design second stage (CIC compensator)
            d = fdesign.interpolator(pM2,'ciccomp',1,NumCICSections,pM3,...
                'n,fp,fst', OrderStage2, pPassbandFrequency,...
                pFstopStage2, pFsStage2);
            pCICCompFilter = design(d,'equiripple', AllowLegacyFilters=true);
            coeffs2 = pCICCompFilter.Numerator;
            m2 = measure(pCICCompFilter);
            Astop2 = m2.Astop;
            
        end
        %------------------------------------------------------------------
        function [NumCICSections, coeffs2, coeffs1, CICNormFact, Astop2, Astop1, isDone] = getFilterCoeffsMinOrder(...
                PassbandRipple, StopbandAttenuation, ...
                pBypassStage1, SampleRate, pFCICNulls, pFstopStage2, pFstopStage1, ...
                pNumMagRespMeasPoints, pM2, pPassbandFrequency, pFsStage2, ...
                pFilterTypeStage1, pM1, pTWStage1, pFsStage1, pFsStage3, pM3, ...
                pPassBandRippleReductionFactor, pStopbandAttenuationStep, ...
                Arithmetic, MinimumOrderDesign, InterpolationFactor)
            %Compute quantities that will be useful to perform measurements on the
            %cascade response. Set attenuation variables that will be updated with
            %new values until the specifications are met.
            
            pActualPassbandRipple = PassbandRipple;
            pActualStopbandAttenuation = StopbandAttenuation;
            
            %output sample rate
            FsOut = SampleRate*prod(InterpolationFactor);
            
            %Compute quantities that will be useful to perform measurements on the
            %cascade response. Set attenuation variables that will be updated with
            %new values until the specifications are met.
            
            %Initial passband ripple and stopband attenuation for stages 1 and 2
            Ap2 = PassbandRipple;
            Astop2 = StopbandAttenuation;
            Ap1 = PassbandRipple;
            Astop1 = StopbandAttenuation;
            
            if pBypassStage1
                Fmax = min(FsOut/2, pFCICNulls(1)+pFstopStage2);
                interval1 = [pFstopStage2 pFCICNulls(1)-pFstopStage2];
                interval2 = [pFCICNulls(1)-pFstopStage2 Fmax];
            else
                %Passband ripple for stage 1, used when first stage is lowpass filter
                Fmax = min(FsOut/2, pFCICNulls(1)+pFstopStage1);
                interval1 = [pFstopStage1 pFstopStage2];
                interval2 = [pFstopStage2 pFCICNulls(1)-pFstopStage1];
                interval3 = [pFCICNulls(1)-pFstopStage1 Fmax];
            end
            % Measurement frequencies
            FVect = linspace(0,Fmax,pNumMagRespMeasPoints);
            % Compute overall gain of cascade response
            cascadeGain =  20*log10(pM1*pM2*pM3);
            
            % Loop until specs are met or until the number of iterations has gone
            % beyond 20.
            % Define some loop flags
            isDone = false;
            numIters = 0;
            reDesignStage1 = true;
            reDesignStage2 = true;
            reDesignStage3 = true;
            reDesignStage1Order = false;
            reDesignNormalizationStage = false;
            rippleFactor = 1;
            
            % Suppress MFILT deprecation warning on calling design method
            % on an fdesign object without "SystemObject" flag set to true.
            w = warning('off', 'dsp:fdesign:basecatalog:UseSystemObjectForMultirateDesigns');
            restoreWarn = onCleanup(@() warning(w));
            
            % Instantiate designer objects before going into the iterations
            if ~pBypassStage1
                if strcmp(pFilterTypeStage1,'halfband')
                    dStage1 = fdesign.interpolator(pM1,'halfband','TW,ast',...
                        pTWStage1,Astop1,pFsStage1);
                else
                    dStage1 = fdesign.interpolator(pM1,'lowpass','Fp,Fst,Ap,Ast', ...
                        pPassbandFrequency,pFstopStage1,Ap1,...
                        Astop1,pFsStage1);
                end
            end
            
            dStage2 = fdesign.interpolator(pM2,'ciccomp',1,2,pM3,...
                'fp,fst,ap,ast',pPassbandFrequency,pFstopStage2,...
                Ap2,Astop2,pFsStage2);
            
            while ~isDone && numIters < 21
                % First stage design
                if ~pBypassStage1 && (reDesignStage1 || reDesignStage1Order)
                    if reDesignStage1
                        if strcmp(pFilterTypeStage1,'halfband')
                            dStage1.Astop = Astop1;
                            %Kaiserwin is used to ensure convergence of halfband design
                            pStage1Filter = design(dStage1,'kaiserwin', AllowLegacyFilters=true);
                        else
                            dStage1.Apass = Ap1;
                            dStage1.Astop = Astop1;
                            pStage1Filter = design(dStage1,'equiripple', AllowLegacyFilters=true);
                        end
                    else
                        if reDesignStage1Order
                            d = fdesign.interpolator(pM1,'halfband', 'N,TW', N,pTWStage1, pFsStage1);
                            %Kaiserwin is used to ensure convergence of halfband design
                            pStage1Filter = design(d,'kaiserwin',AllowLegacyFilters=true);
                        end
                    end
                end
                
                %Design third stage (CIC) before the second stage since the CIC
                %compensator needs to know the number of CIC stages
                if numIters == 0
                    [pCICFilter, NumCICSections, CICGain] = dsp.internal.UpConverterFilterDesigner.designMinOrderCICInterpolationFilter(...
                        Arithmetic, pM3, pPassbandFrequency,StopbandAttenuation, pFsStage3);
                else
                    if reDesignStage3
                    [pCICFilter, CICGain] = dsp.internal.UpConverterFilterDesigner.designSectionsCICInterpolationFilter(...
                            Arithmetic, NumCICSections, pM3);
                    end
                end
                
                if reDesignStage3 || reDesignNormalizationStage
                    % CIC gain normalization filter - the gain is the excess gain from
                    % the gain due to the interpolation factor M3
                    pGainFilter = dfilt.scalar(rippleFactor/CICGain);
                end
                
                % Second stage design
                if reDesignStage2
                    dStage2.NumberOfSections = NumCICSections;
                    dStage2.Apass = Ap2;
                    dStage2.Astop = Astop2;
                    pCICCompFilter = design(dStage2,'equiripple',AllowLegacyFilters=true);
                end
                
                if pBypassStage1
                    pCascadeFilter = cascade(pCICCompFilter,pCICFilter,...
                        pGainFilter);
                else
                    pCascadeFilter = cascade(pStage1Filter,...
                        pCICCompFilter,pCICFilter,pGainFilter); %#ok<*PROP>
                end
                
                % Measure cascade response and adjust parameters if specifications
                % are not met. Do not redesign the filters unless a parameter of the
                % filter needs to be updated to meet the specifications.
                % Interpolation filter cascade operates at output sampling rate.
                reDesignStage1 = false;
                reDesignStage2 = false;
                reDesignStage3 = false;
                reDesignStage1Order = false;
                reDesignNormalizationStage = false;
                
                % If Arithmetic is 'Single', change the arithmetic of the filters to
                % single. If Arithmetic is 'fixed', design the filters in double
                % precision and then find the coefficients data type that meet the
                % specifications.
                if strcmpi(Arithmetic,'single')
                    pCICFilter.Arithmetic = 'Single';
                    pCICCompFilter.Arithmetic = 'Single';
                    if ~pBypassStage1
                        pStage1Filter.Arithmetic = 'Single';
                    end
                    pGainFilter.Arithmetic = 'Single';
                end
                
                magResp = 20*log10(abs(freqz(pCascadeFilter,FVect,FsOut)));
                
                % If ripple specification is not met, then decrease the passband
                % ripple of the first stage or CIC compensator filter. Equiripple Spec
                % is the ripple measured from the cascadeGain to max(magResp) and
                % from the cascadeGain to min(magResponse). Ripple spec is measured
                % as max(magResponse) - min(magResponse).
                [equiRippleSpecMet, rippleSpecMet] = ...
                    dsp.internal.UpConverterFilterDesigner.isRippleSpecMet(magResp,FVect,cascadeGain, ...
                    MinimumOrderDesign, pActualPassbandRipple, pPassbandFrequency);
                if ~equiRippleSpecMet && ~rippleSpecMet
                    if  ~pBypassStage1
                        if strcmp(pFilterTypeStage1,'lowpass')
                            Ap1 = Ap1*pPassBandRippleReductionFactor;
                            reDesignStage1 = true;
                            Ap2 = Ap2*pPassBandRippleReductionFactor;
                            reDesignStage2 = true;
                        else
                            Ap2 = Ap2*pPassBandRippleReductionFactor;
                            reDesignStage2 = true;
                            N = order(pStage1Filter) + 1;
                            if mod(N,2)
                                N = N+1;
                            end
                            reDesignStage1Order = true;
                        end
                    else
                        Ap2 = Ap2*pPassBandRippleReductionFactor;
                        reDesignStage2 = true;
                    end
                    isDoneRipple = false;
                elseif equiRippleSpecMet
                    isDoneRipple = true;
                elseif ~equiRippleSpecMet && rippleSpecMet
                    % The ripple (max(magResp) - min(magResp)) meets the specification
                    % value but is not centered around the cascadeGain. Center it by
                    % applying some attenuation via the scalar normalization filter.
                    rippleFactor = dsp.internal.ConverterFilterDesignerBase.centerRipple(magResp,FVect,cascadeGain,pPassbandFrequency);
                    isDoneRipple = false;
                    reDesignNormalizationStage = true;
                end
                
                % If attenuation is not met in different stopband regions, increase
                % the attenuation specification of the filters.
                if ~dsp.internal.UpConverterFilterDesigner.isStopbandAttenuationSpecMet(magResp,FVect,cascadeGain,interval1, ...
                        pActualStopbandAttenuation)
                    % Wait until the attenuation specs are met before centering the
                    % equiripple around the cascade gain.
                    rippleFactor = 1;
                    if pBypassStage1
                        Astop2 = Astop2 + pStopbandAttenuationStep;
                        reDesignStage2 = true;
                    else
                        Astop1 = Astop1 + pStopbandAttenuationStep;
                        reDesignStage1 = true;
                    end
                    isDoneInterval1 = false;
                else
                    isDoneInterval1 = true;
                end
                
                if ~dsp.internal.UpConverterFilterDesigner.isStopbandAttenuationSpecMet(magResp,FVect,cascadeGain,...
                        interval2, pActualStopbandAttenuation)
                    % Wait until the attenuation specs are met before centering the
                    % equiripple around the cascade gain.
                    rippleFactor = 1;
                    if pBypassStage1
                        NumCICSections = NumCICSections + 1;
                        reDesignStage2 = true;
                        reDesignStage3 = true;
                    else
                        Astop2 = Astop2 + pStopbandAttenuationStep;
                        reDesignStage2 = true;
                    end
                    isDoneInterval2 = false;
                else
                    isDoneInterval2 = true;
                end
                
                if ~pBypassStage1
                    if ~dsp.internal.UpConverterFilterDesigner.isStopbandAttenuationSpecMet(magResp,FVect,cascadeGain,...
                            interval3, pActualStopbandAttenuation)
                        % Wait until the attenuation specs are met before centering the
                        % equiripple around the cascade gain.
                        rippleFactor = 1;
                        NumCICSections = NumCICSections + 1;
                        reDesignStage2 = true;
                        reDesignStage3 = true;
                        isDoneInterval3 = false;
                    else
                        isDoneInterval3 = true;
                    end
                else
                    isDoneInterval3 = true;
                end
                
                isDone = isDoneRipple & isDoneInterval1 &...
                    isDoneInterval2 & isDoneInterval3;
                
                numIters = numIters + 1;
            end
            coeffs2 = pCICCompFilter.Numerator;
            if ~pBypassStage1
                coeffs1 = pStage1Filter.Numerator; 
            else
                coeffs1 = [];
            end
            CICNormFact = pGainFilter.Gain;
        end
        %------------------------------------------------------------------
        function fixedPointProperties = getFixedPointPropertiesSpecifiedOrders( ...
                inputDataType, filterOutputDataType, cicInterpolation, cicDiffDelay, cicNumSections, cicgain, ...
                ciccompInterpolation, ciccompCoeffs, stage1Interpolation, ...
                stage1Coeffs, Astop2, Astop1, pBypassStage1, SampleRate, ...
                pFCICNulls, pFstopStage2, pFstopStage1, pNumMagRespMeasPoints, ...
                MinimumOrderDesign, PassbandRipple, StopbandAttenuation, ...
                pCascadeFilterStopbandFrequency, pPassbandFrequency, InterpolationFactor, ...
                pM1, pM2, pM3)
            
            % Suppress MFILT deprecation warnings
            w = warning('off', 'dsp:mfilt:mfilt:Obsolete');
            restoreWarn = onCleanup(@() warning(w));
            
            % create a cascade filter object
            stage2 = dsp.internal.mfilt.firinterp(ciccompInterpolation, ciccompCoeffs);
            stage3 = dsp.internal.mfilt.cicinterp(cicInterpolation,cicDiffDelay,cicNumSections);
            stage4 = dfilt.scalar(1/cicgain);
            if ~pBypassStage1
                stage1 = dsp.internal.mfilt.firinterp(stage1Interpolation, stage1Coeffs);
                pCascadeFilter = mfilt.cascade(stage1, stage2, stage3, stage4);%#ok
            else
                pCascadeFilter = mfilt.cascade(stage2, stage3, stage4);%#ok
            end
            
            % Get ripple and attenuation measurements to adjust data type of
            % scaling normalization
            FsOut = SampleRate*prod(InterpolationFactor);
            
            if pBypassStage1
                Fmax = min(FsOut/2, pFCICNulls(1)+pFstopStage2);
                interval = [pFstopStage2 Fmax];
            else
                Fmax = min(FsOut/2, pFCICNulls(1)+pFstopStage1);
                interval = [pFstopStage1 Fmax];
            end
            % Measurement frequencies
            FVect = linspace(0,Fmax,pNumMagRespMeasPoints);
            magResp = 20*log10(abs(freqz(pCascadeFilter,FVect,FsOut)));
            
            cascadeGain =  20*log10(pM1*pM2*pM3);
            [~, pActualPassbandRipple] = ...
                dsp.internal.UpConverterFilterDesigner.measurePassbandRipple(magResp,FVect,cascadeGain, ...
                pPassbandFrequency);
            pActualStopbandAttenuation = dsp.internal.UpConverterFilterDesigner.measureAttenuation(magResp,...
                FVect,cascadeGain,interval);
            
            % set the wordlength of filter coefficients
            pCascadeFilter = dsp.internal.UpConverterFilterDesigner.setWordLengthOfFilterSections(...
                inputDataType,filterOutputDataType,pCascadeFilter,pBypassStage1,Astop2,Astop1, ...
                MinimumOrderDesign,PassbandRipple, StopbandAttenuation, ...
                SampleRate, pFCICNulls, pFstopStage2, pFstopStage1, pNumMagRespMeasPoints, ...
                pCascadeFilterStopbandFrequency, pActualPassbandRipple, pActualStopbandAttenuation, ...
                pPassbandFrequency, InterpolationFactor, pM1, pM2, pM3);
            
            if ~pBypassStage1
                fixedPointProperties.CICCompWordLength = pCascadeFilter.Stage(2).CoeffWordLength;
                fixedPointProperties.CICCompFracLength =  pCascadeFilter.Stage(2).NumFracLength;
                fixedPointProperties.CICCompProductWordLength = pCascadeFilter.Stage(2).ProductWordLength;
                fixedPointProperties.CICCompProductFracLength = pCascadeFilter.Stage(2).ProductFracLength;
                fixedPointProperties.CICCompAccumWordLength = pCascadeFilter.Stage(2).AccumWordLength;
                fixedPointProperties.CICCompAccumFracLength = pCascadeFilter.Stage(2).AccumFracLength;
                
                fixedPointProperties.FirstFilterWordLength = pCascadeFilter.Stage(1).CoeffWordLength;
                fixedPointProperties.FirstFilterFracLength =  pCascadeFilter.Stage(1).NumFracLength;
                fixedPointProperties.FirstFilterProductWordLength = pCascadeFilter.Stage(1).ProductWordLength;
                fixedPointProperties.FirstFilterProductFracLength = pCascadeFilter.Stage(1).ProductFracLength;
                fixedPointProperties.FirstFilterAccumWordLength = pCascadeFilter.Stage(1).AccumWordLength;
                fixedPointProperties.FirstFilterAccumFracLength = pCascadeFilter.Stage(1).AccumFracLength;
            else
                fixedPointProperties.CICCompWordLength = pCascadeFilter.Stage(1).CoeffWordLength;
                fixedPointProperties.CICCompFracLength =  pCascadeFilter.Stage(1).NumFracLength;
                fixedPointProperties.CICCompProductWordLength = pCascadeFilter.Stage(1).ProductWordLength;
                fixedPointProperties.CICCompProductFracLength = pCascadeFilter.Stage(1).ProductFracLength;
                fixedPointProperties.CICCompAccumWordLength = pCascadeFilter.Stage(1).AccumWordLength;
                fixedPointProperties.CICCompAccumFracLength = pCascadeFilter.Stage(1).AccumFracLength;
            end
        end
        %------------------------------------------------------------------
        function fixedPointProperties = getFixedPointPropertiesMinOrder( ...
                inputDataType, filterOutputDataType, cicInterpolation, cicDiffDelay, cicNumSections, CICNormFact, ...
                ciccompInterpolation, ciccompCoeffs, stage1Interpolation, ...
                stage1Coeffs, Astop2, Astop1, pBypassStage1, SampleRate, ...
                pFCICNulls, pFstopStage2, pFstopStage1, pNumMagRespMeasPoints, ...
                MinimumOrderDesign, PassbandRipple, StopbandAttenuation, ...
                pCascadeFilterStopbandFrequency, pPassbandFrequency, ...
                pActualPassbandRipple, pActualStopbandAttenuation, InterpolationFactor, pM1, pM2, pM3)
            
            % Suppress MFILT deprecation warnings
            w = warning('off', 'dsp:mfilt:mfilt:Obsolete');
            restoreWarn = onCleanup(@() warning(w));
            
            % create a cascade filter object
            stage2 = dsp.internal.mfilt.firinterp(ciccompInterpolation, ciccompCoeffs);
            stage3 = dsp.internal.mfilt.cicinterp(cicInterpolation,cicDiffDelay,cicNumSections);
            stage4 = dfilt.scalar(CICNormFact);
            if ~pBypassStage1
                stage1 = dsp.internal.mfilt.firinterp(stage1Interpolation, stage1Coeffs);
                pCascadeFilter = mfilt.cascade(stage1, stage2, stage3, stage4); %#ok
            else
                pCascadeFilter = mfilt.cascade(stage2, stage3, stage4); %#ok
            end
            
            % set the wordlength of filter coefficients
            pCascadeFilter = dsp.internal.UpConverterFilterDesigner.setWordLengthOfFilterSections(...
                inputDataType,filterOutputDataType,pCascadeFilter,pBypassStage1,Astop2,Astop1, ...
                MinimumOrderDesign,PassbandRipple, StopbandAttenuation, ...
                SampleRate, pFCICNulls, pFstopStage2, pFstopStage1, pNumMagRespMeasPoints, ...
                pCascadeFilterStopbandFrequency, pActualPassbandRipple, pActualStopbandAttenuation, ...
                pPassbandFrequency, InterpolationFactor, pM1, pM2, pM3);
            
            if ~pBypassStage1
                fixedPointProperties.CICCompWordLength = pCascadeFilter.Stage(2).CoeffWordLength;
                fixedPointProperties.CICCompFracLength =  pCascadeFilter.Stage(2).NumFracLength;
                fixedPointProperties.CICCompProductWordLength = pCascadeFilter.Stage(2).ProductWordLength;
                fixedPointProperties.CICCompProductFracLength = pCascadeFilter.Stage(2).ProductFracLength;
                fixedPointProperties.CICCompAccumWordLength = pCascadeFilter.Stage(2).AccumWordLength;
                fixedPointProperties.CICCompAccumFracLength = pCascadeFilter.Stage(2).AccumFracLength;
                
                fixedPointProperties.FirstFilterWordLength = pCascadeFilter.Stage(1).CoeffWordLength;
                fixedPointProperties.FirstFilterFracLength =  pCascadeFilter.Stage(1).NumFracLength;
                fixedPointProperties.FirstFilterProductWordLength = pCascadeFilter.Stage(1).ProductWordLength;
                fixedPointProperties.FirstFilterProductFracLength = pCascadeFilter.Stage(1).ProductFracLength;
                fixedPointProperties.FirstFilterAccumWordLength = pCascadeFilter.Stage(1).AccumWordLength;
                fixedPointProperties.FirstFilterAccumFracLength = pCascadeFilter.Stage(1).AccumFracLength;
            else
                fixedPointProperties.CICCompWordLength = pCascadeFilter.Stage(1).CoeffWordLength;
                fixedPointProperties.CICCompFracLength =  pCascadeFilter.Stage(1).NumFracLength;
                fixedPointProperties.CICCompProductWordLength = pCascadeFilter.Stage(1).ProductWordLength;
                fixedPointProperties.CICCompProductFracLength = pCascadeFilter.Stage(1).ProductFracLength;
                fixedPointProperties.CICCompAccumWordLength = pCascadeFilter.Stage(1).AccumWordLength;
                fixedPointProperties.CICCompAccumFracLength = pCascadeFilter.Stage(1).AccumFracLength;
            end
        end
        %-------------------------------------------------------------------------
        function pCascadeFilter =setWordLengthOfFilterSections(inputDataType,filterOutputDataType,pCascadeFilter,pBypassStage1,Astop2,Astop1, ...
                MinimumOrderDesign,PassbandRipple, StopbandAttenuation, ...
                SampleRate, pFCICNulls, pFstopStage2, pFstopStage1, pNumMagRespMeasPoints, ...
                pCascadeFilterStopbandFrequency, pActualPassbandRipple, pActualStopbandAttenuation, ...
                pPassbandFrequency, InterpolationFactor, pM1, pM2, pM3)
            % Find smallest word length that still allows the filter cascade to
            % meet specifications
            
            % Apply rule of thumb - 6 dB of attenuation per bit - to compute
            % initial word length. Use the attenuation values used in the final
            % design of the cascade (Astop1, Astop2)
            if ~pBypassStage1
                pCascadeFilter.Stage(1).Arithmetic = 'fixed';
                pCascadeFilter.Stage(1).InputWordLength = inputDataType.WordLength;
                pCascadeFilter.Stage(1).InputFracLength = inputDataType.FractionLength;
                WL1 = round(Astop1/6);
                pCascadeFilter.Stage(2).Arithmetic = 'fixed';
                pCascadeFilter.Stage(2).InputWordLength = filterOutputDataType.WordLength;
                pCascadeFilter.Stage(2).InputFracLength = filterOutputDataType.FractionLength;
                WL2 = round(Astop2/6);
            else
                WL1 = []; % don't care value
                pCascadeFilter.Stage(1).Arithmetic = 'fixed';
                pCascadeFilter.Stage(1).InputWordLength = inputDataType.WordLength;
                pCascadeFilter.Stage(1).InputFracLength = inputDataType.FractionLength;
                WL2 = round(Astop2/6);
            end
            dsp.internal.UpConverterFilterDesigner.optimizeCoefficientsWordLengths(pCascadeFilter,pBypassStage1,WL2,WL1, ...
                MinimumOrderDesign,PassbandRipple, StopbandAttenuation, ...
                SampleRate, pFCICNulls, pFstopStage2, pFstopStage1, pNumMagRespMeasPoints, ...
                pCascadeFilterStopbandFrequency, pActualPassbandRipple, pActualStopbandAttenuation, ...
                pPassbandFrequency, InterpolationFactor, pM1, pM2, pM3);
        end
        %------------------------------------------------------------------
        function pCascadeFilter = setCoefficientsWordLength(pCascadeFilter,pBypassStage1,WL2,WL1)
            if ~pBypassStage1
                pCascadeFilter.Stage(1).CoeffWordLength = WL1;
                pCascadeFilter.Stage(2).CoeffWordLength = WL2;
            else
                pCascadeFilter.Stage(1).CoeffWordLength = WL2;
            end
        end
        %------------------------------------------------------------------
        function flag = privIsSpecMet(MinimumOrderDesign,PassbandRipple, StopbandAttenuation, ...
                pBypassStage1, SampleRate, pFCICNulls, pFstopStage2, pFstopStage1, pNumMagRespMeasPoints, ...
                pCascadeFilter, pCascadeFilterStopbandFrequency, pActualPassbandRipple, ...
                pActualStopbandAttenuation, pPassbandFrequency, InterpolationFactor, pM1, pM2, pM3)
            % Protected method can be called even if a final filter design is not
            % available yet. Returns true if the cascade response meets the filter
            % specifications.
            
            if MinimumOrderDesign
                pActualPassbandRipple = PassbandRipple;
                pActualStopbandAttenuation = StopbandAttenuation;
            end
            
            FsOut = SampleRate*prod(InterpolationFactor);
            if pBypassStage1
                Fmax = ...
                    min(FsOut/2, pFCICNulls(1)+pFstopStage2);
            else
                Fmax = ...
                    min(FsOut/2, pFCICNulls(1)+pFstopStage1);
            end
            
            % Measurement frequencies
            FVect = linspace(0,Fmax,pNumMagRespMeasPoints);
            magResp = 20*log10(abs(freqz(pCascadeFilter,FVect,FsOut)));
            cascadeGain = 20*log10(pM1*pM2*pM3); 
            flag = dsp.internal.UpConverterFilterDesigner.thisIsSpecMet(magResp,FVect,cascadeGain,...
                pCascadeFilterStopbandFrequency,MinimumOrderDesign, pActualPassbandRipple, ...
                pActualStopbandAttenuation, pPassbandFrequency);
        end
        %------------------------------------------------------------------
        function optimizeCoefficientsWordLengths(pCascadeFilter,pBypassStage1,WL1,WL2, ...
                MinimumOrderDesign,PassbandRipple, StopbandAttenuation, ...
                SampleRate, pFCICNulls, pFstopStage2, pFstopStage1, pNumMagRespMeasPoints, ...
                pCascadeFilterStopbandFrequency, pActualPassbandRipple, pActualStopbandAttenuation, ...
                pPassbandFrequency, InterpolationFactor, pM1, pM2, pM3)
            % Iterate until we find a word length that meets the specifications WL1
            % and WL2 are initial word lengths for the Stage1 and CIC compensator
            % sections
            
            isDone1 = false;
            isDone2 = false;
            numIters = 0;
            while ~isDone1 && numIters < 14
                pCascadeFilter = dsp.internal.UpConverterFilterDesigner.setCoefficientsWordLength(pCascadeFilter,pBypassStage1,WL1,WL2);
                isDone1 = dsp.internal.UpConverterFilterDesigner.privIsSpecMet(MinimumOrderDesign,PassbandRipple, StopbandAttenuation, ...
                    pBypassStage1, SampleRate, pFCICNulls, pFstopStage2, pFstopStage1, pNumMagRespMeasPoints, ...
                    pCascadeFilter, pCascadeFilterStopbandFrequency, pActualPassbandRipple, ...
                    pActualStopbandAttenuation, pPassbandFrequency, InterpolationFactor, pM1, pM2, pM3);
                if ~isDone1
                    WL1 = WL1 + 4;
                    WL2 = WL2 + 4;
                else
                    idx = 3;
                    while ~isDone2
                        WL1b = max(2,WL1 - idx); % Coefficients need at least 2 bits
                        WL2b = max(2,WL2 - idx);
                        pCascadeFilter = dsp.internal.UpConverterFilterDesigner.setCoefficientsWordLength(pCascadeFilter,pBypassStage1,WL1b,WL2b);
                        isDone2 = dsp.internal.UpConverterFilterDesigner.privIsSpecMet(MinimumOrderDesign,PassbandRipple, StopbandAttenuation, ...
                            pBypassStage1, SampleRate, pFCICNulls, pFstopStage2, pFstopStage1, pNumMagRespMeasPoints, ...
                            pCascadeFilter, pCascadeFilterStopbandFrequency, pActualPassbandRipple, ...
                            pActualStopbandAttenuation,pPassbandFrequency, InterpolationFactor, pM1, pM2, pM3);
                        idx = idx - 1;
                    end
                end
                numIters = numIters + 1;
            end
            if ~isDone1
                coder.internal.warning('dsp:system:DigitalDownConverter:noConvergenceWLCoeff');
            end
        end
        %------------------------------------------------------------------------
        function flag = thisIsSpecMet(magResp,FVect,cascadeGain,...
                pCascadeFilterStopbandFrequency, MinimumOrderDesign, pActualPassbandRipple,...
                pActualStopbandAttenuation, pPassbandFrequency)
            % Returns true if the ripple and stopband attenuation specifications of
            % the filter response have been met.
            % FVect(end) must be larger than pCascadeFilterStopbandFrequency
            
            [flag1, flag2] = dsp.internal.UpConverterFilterDesigner.isRippleSpecMet(magResp,FVect,cascadeGain,MinimumOrderDesign, pActualPassbandRipple, pPassbandFrequency);
            interval = [pCascadeFilterStopbandFrequency FVect(end)];
            flag3 = dsp.internal.UpConverterFilterDesigner.isStopbandAttenuationSpecMet(magResp,FVect,cascadeGain, interval, ...
                pActualStopbandAttenuation);
            flag = flag1 & flag2 & flag3;
        end
        %------------------------------------------------------------------------
        function [equirippleFlag, rippleFlag]= isRippleSpecMet(magResp,FVect,cascadeGain, ...
                MinimumOrderDesign, pActualPassbandRipple, pPassbandFrequency)
            % Returns true if the passband ripple specification is met
            
            [equiRipple, ripple] = dsp.internal.UpConverterFilterDesigner.measurePassbandRipple(magResp,FVect,cascadeGain, ...
                pPassbandFrequency);
            
            if MinimumOrderDesign
                flag1 = equiRipple(1) <= pActualPassbandRipple/2;
                flag2 = (equiRipple(2) <= pActualPassbandRipple/2) && ...
                    (equiRipple(2) >=0);
                equirippleFlag = flag1 & flag2;
            else
                equirippleFlag = true;
            end
            
            rippleFlag = (ripple <= pActualPassbandRipple);
        end
        %------------------------------------------------------------------------
        function flag = isStopbandAttenuationSpecMet(magResp,FVect,cascadeGain,interval, ...
                pActualStopbandAttenuation)
            % Returns true if the stopband attenuation specification is met in the
            % specified frequency interval.
            attenunation = dsp.internal.UpConverterFilterDesigner.measureAttenuation(magResp,FVect,cascadeGain,interval);
            if isempty(attenunation)
                % No measurement points available since band of interest is smaller
                % than measurement resolution or has a width of 0 Hz (if interval(1)
                % equals interval(2))
                flag = true;
            else
                flag = attenunation >= pActualStopbandAttenuation;
            end
        end
        %------------------------------------------------------------------------
        function [pCICFilter,NumCICSections,CICGain] = designMinOrderCICInterpolationFilter(...
                Arithmetic, pM3, pPassbandFrequency,StopbandAttenuation, pFsStage3)
            % Design a minimum order CIC interpolation response and implement it as
            % an FIR filter when Arithmetic is 'double' or 'single', or as a CIC
            % filter when Arithmetic is 'fixed'. Output the number of CIC sections
            % and the gain of the CIC filter.
      
            if ~strcmpi(Arithmetic, 'fixed')
                % Suppress MFILT deprecation warnings
                w = warning('off', 'dsp:mfilt:mfilt:Obsolete');
                restoreWarn = onCleanup(@() warning(w));
                
                [coeffs,NumCICSections] = dsp.internal.ConverterFilterDesignerBase.getMinOrderCICFIRCoefficients(...
                    pM3, pFsStage3, pPassbandFrequency, StopbandAttenuation);
                pCICFilter = dsp.internal.mfilt.firinterp(pM3,coeffs);
            else
                % Suppress MFILT deprecation warning on calling design
                % method on an fdesign object without "SystemObject" flag
                % set to true.
                w = warning('off', 'dsp:fdesign:basecatalog:UseSystemObjectForMultirateDesigns');
                restoreWarn = onCleanup(@() warning(w));
                
                d = fdesign.interpolator(pM3,'cic',1,'fp,ast',...
                    pPassbandFrequency,StopbandAttenuation,pFsStage3);
                pCICFilter = design(d, AllowLegacyFilters=true);
                NumCICSections = pCICFilter.NumberOfSections;
            end
            CICGain = pM3^(NumCICSections-1);
        end
        %-------------------------------------------------------------------------
        function [pCICFilter,CICGain] = designSectionsCICInterpolationFilter(...
                Arithmetic, NumCICSections, pM3)
            % Design a CIC interpolation response and implement it as an FIR filter
            % when Arithmetic is ''double' or 'single', or as a CIC filter when
            % Arithmetic is 'fixed'. Output the gain of the CIC filter.
            
            % Suppress MFILT deprecation warnings
            w = warning('off', 'dsp:mfilt:mfilt:Obsolete');
            restoreWarn = onCleanup(@() warning(w));
            
            if ~strcmpi(Arithmetic, 'fixed')
                coeffs = dsp.internal.ConverterFilterDesignerBase.getCICFIRCoefficients(NumCICSections,pM3);
                pCICFilter = dsp.internal.mfilt.firinterp(pM3,coeffs);
            else
                pCICFilter = dsp.internal.mfilt.cicinterp(pM3,1,NumCICSections);
            end
            CICGain = pM3^(NumCICSections-1);
        end
        %------------------------------------------------------------------
        function fixedPointProperties = getCICFixedPointProperties(NumCICSections, pM3, ...
                inputDataType)
            % Design a mfilt CIC and return its fixed-point properties
            
            % Suppress MFILT deprecation warnings
            w = warning('off', 'dsp:mfilt:mfilt:Obsolete');
            restoreWarn = onCleanup(@() warning(w));
            
            h = dsp.internal.mfilt.cicinterp;
            h.InterpolationFactor = pM3;
            h.NumberOfSections = NumCICSections;
            h.InputWordLength = inputDataType.WordLength;
            h.InputFracLength = inputDataType.FractionLength;
            fixedPointProperties.SectionWordLengths = h.SectionWordLengths;
            fixedPointProperties.SectionFracLengths = h.SectionFracLengths;
            fixedPointProperties.OutputWordLength = h.OutputWordLength;
            fixedPointProperties.OutputFracLength = h.OutputFracLength;
        end
        %------------------------------------------------------------------
        function fixedPointProperties = getFixedPointPropertiesCoefficients(...
                inputDataType, filterOutputDataType, pBypassStage1, ...
                pM1, pM2, coeffs1, coeffs2, CoefficientsStage1DataType, CoefficientsStage2DataType)
            % Design mfilt filters and return their fixed-point properties
            
            % Suppress MFILT deprecation warnings
            w = warning('off', 'dsp:mfilt:mfilt:Obsolete');
            restoreWarn = onCleanup(@() warning(w));
            
            if ~pBypassStage1
                m1 = dsp.internal.mfilt.firinterp;
                m1.InterpolationFactor = pM1;
                m1.Numerator = coeffs1;
                m1.Arithmetic = 'fixed';
                m1.CoeffAutoScale = false;
                m1.CoeffWordLength = CoefficientsStage1DataType.WordLength;
                m1.NumFracLength = CoefficientsStage1DataType.FractionLength;
                m1.InputWordLength = inputDataType.WordLength;
                m1.InputFracLength = inputDataType.FractionLength;
                
                m2 = dsp.internal.mfilt.firinterp;
                m2.InterpolationFactor = pM2;
                m2.Numerator = coeffs2;
                m2.Arithmetic = 'fixed';
                m2.CoeffAutoScale = false;
                m2.CoeffWordLength = CoefficientsStage2DataType.WordLength;
                m2.NumFracLength = CoefficientsStage2DataType.FractionLength;
                m2.InputWordLength = filterOutputDataType.WordLength;
                m2.InputFracLength = filterOutputDataType.FractionLength;
                
                fixedPointProperties.Stage1ProductWordLength = m1.ProductWordLength;
                fixedPointProperties.Stage1ProductFracLength = m1.ProductFracLength;
                fixedPointProperties.Stage1AccumWordLength = m1.AccumWordLength;
                fixedPointProperties.Stage1AccumFracLength = m1.AccumFracLength;
            else
                m2 = dsp.internal.mfilt.firinterp;
                m2.InterpolationFactor = pM2;
                m2.Numerator = coeffs2;
                m2.Arithmetic = 'fixed';
                m2.CoeffAutoScale = false;
                m2.CoeffWordLength = CoefficientsStage2DataType.WordLength;
                m2.NumFracLength = CoefficientsStage2DataType.FractionLength;
                m2.InputWordLength = inputDataType.WordLength;
                m2.InputFracLength = inputDataType.FractionLength;
            end
            
            fixedPointProperties.CICCompProductWordLength = m1.ProductWordLength;
            fixedPointProperties.CICCompProductFracLength = m1.ProductFracLength;
            fixedPointProperties.CICCompAccumWordLength = m1.AccumWordLength;
            fixedPointProperties.CICCompAccumFracLength = m1.AccumFracLength;
        end
    end
    
    methods (Hidden)
        function [filt, figureProps] = getFvtoolParametersForVFS(obj)
            % Get filters and figure properties for the plot of
            % visualizeFilterStages method
            
            CICNorm = cascade(obj.pCICFilter, obj.pGainFilter);
            
            if length(obj.pFCICNulls)>1
                fLimit = obj.pFCICNulls(2);
            else
                fLimit = obj.pFCICNulls(end);
            end
            
            if obj.pBypassStage1
                filt = {obj.pCICCompFilter, CICNorm,obj.pCascadeFilter};
                figureProps = {'FrequencyRange','Specify freq. vector', ...
                    'FrequencyVector',linspace(0,fLimit,2048),'Fs',...
                    [obj.pFsStage2, obj.pFsStage3, obj.pFsStage3], ...
                    'ShowReference','on','Color','White'};
            else
                filt = {obj.pStage1Filter,obj.pCICCompFilter,CICNorm,obj.pCascadeFilter};
                figureProps = {'FrequencyRange','Specify freq. vector', ...
                    'FrequencyVector',linspace(0,fLimit,2048),'Fs',...
                    [obj.pFsStage1, obj.pFsStage2, obj.pFsStage3,obj.pFsStage3], ...
                    'ShowReference','on','Color','White'};
            end
        end
        
        function legendCell = getLegendStringForVFS(obj)
            % Get legend for the plot of visualizeFilterStages method
            
            st2 = ['CIC compensator, Interpolation factor = ',num2str(obj.pM2)];
            st3 = ['CIC interpolator, Interpolation factor = ',num2str(obj.pM3)];
            st4 = 'Cascade response';
            
            if obj.pBypassStage1
                legendCell = {st2, st3, st4};
            else
                if strcmpi(obj.pFilterTypeStage1,'halfband')
                    st1 = ['Halfband interpolator, Interpolation factor = ',...
                        num2str(obj.pM1)];
                else
                    st1 = ['Lowpass interpolator, Interpolation factor = ',...
                        num2str(obj.pM1)];
                end
                legendCell = {st1, st2, st3, st4};
            end
        end
    end
end

