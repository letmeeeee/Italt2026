classdef FIRHalfbandBase < dsp.internal.NormalizedSampleRateEngine        & ...
                           dsp.internal.FilterAnalysisMultirate
    %FIRHALFBANDBASE Abstract base class for FIRHalfbandDecimator and
    % FIRHalfbandInterpolator System objects.
    % dsp.FIRHalfbandDecimator and dsp.FIRHalfbandInterpolator inherit
    % from this class.
    
    % Copyright 2014-2021 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCA>
    
    properties (Nontunable, Abstract)
        Numerator; % defined in FIRHalfbandDecimator/Interpolator
    end
    
    properties (Nontunable)
        % SampleRate Input sample rate (Hz)
        %   Specify the sampling rate of the input in Hertz as a finite
        %   numeric scalar. the default is 44100 Hz.
        SampleRate = 44100;
        %Specification Filter specification
        %   Specify design parameters to design the FIR Halfband filter
        %   using equiripple or Kaiser window filter design method, or
        %   specify the Numerator coefficients directly. When you set
        %   'Specification' to one of 'Transition width and stopband
        %   attenuation' | 'Filter order and stopband attenuation' |
        %   'Filter order and transition width', you choose two of the
        %   three available design parameters to design the filter. When
        %   you set 'Specification' to 'Coefficients', you can specify the
        %   halfband filter coefficients directly through the 'Numerator'
        %   property. The default of this property is 'Transition width and
        %   stopband attenuation'.
        Specification (1, :) char {matlab.system.mustBeMemberMessageID(Specification, ...
            {'dsp:system:FIRHalfbandDecimator:Specification_NTw'; ...
            'dsp:system:FIRHalfbandDecimator:Specification_NAst'; ...
            'dsp:system:FIRHalfbandDecimator:Specification_TwAst'; ...
            'dsp:system:FIRHalfbandDecimator:Specification_Coefficients'})} = 'Transition width and stopband attenuation';  
        %FilterOrder Filter order
        %   Specify the order for the designed FIR Halfband filter, as a
        %   finite even positive scalar. This property applies when the
        %   Specification is either 'Filter order and transition width' |
        %   'Filter order and stopband attenuation'. The default value of
        %   this property is 52.
        FilterOrder = 52;
        %StopbandAttenuation Stopband attenuation (dB)
        %   Specify the stopband attenuation for the designed FIR Halfband
        %   filter in dB, as a finite positive scalar. This
        %   property applies when the Specification is either
        %   'Filter order and stopband attenuation' |
        %   'Transition width and stopband attenuation'.
        %   The default value of this property is 80dB.
        StopbandAttenuation = 80;
        %DesignMethod Design method
        %   Specify the filter design method as 'Auto'| 'Equiripple' |
        %   'Kaiser'. When DesignMethod is set to 'Auto', the filter is
        %   designed using Equiripple or Kaiser window method, based on the
        %   filter design parameters. This property applies when the
        %   Specification is either 'Transition width and stopband
        %   attenuation' | 'Filter order and stopband attenuation' |
        %   'Filter order and transition width' . The default is 'Auto'.
        DesignMethod (1, :) char {matlab.system.mustBeMemberMessageID(DesignMethod, ...
            {'dsp:system:FIRHalfbandDecimator:DesignMethod_Auto'; ...
            'dsp:system:FIRHalfbandDecimator:DesignMethod_Equiripple'; ...
            'dsp:system:FIRHalfbandDecimator:DesignMethod_Kaiser'})} = 'Auto';  

    end
    
    properties (Nontunable, Access = protected)
        IsFilterDesigned (1, 1) logical = false;
        IsHalfOrderOdd (1, 1) logical   = false;
    
        % pPrototypeCoeffs Coefficients vector (double precision)
        pPrototypeCoeffs;
        % pProtoInputType  Input numerictype
        pProtoInputType;
        % pNumeratorDims   Cached numerator dimensions
        pNumeratorDims;
    end
    
    % Fixed-point properties
    properties (Nontunable)
        %RoundingMethod Rounding method for fixed-point operations at
        %   output
        %   Specify the rounding method for output as one of 'Ceiling' |
        %   'Convergent' | 'Floor' | 'Nearest' | 'Round' | 'Simplest' |
        %   'Zero'. The default value of this property is 'Floor'.
        RoundingMethod = 'Floor';
        
        %CoefficientsDataType Coefficients word and fraction lengths
        %   Specify the coefficients fixed-point type as a signed
        %   numerictype object. The default value of this property is
        %   numerictype(1,16).
        %
        %   See also numerictype.
        CoefficientsDataType = numerictype(1,16);
    end
    
    properties(Constant, Hidden)
        % fixpt enum props
        RoundingMethodSet = matlab.system.internal.RoundingMethodSet;     
        CoefficientsDataTypeSet = matlab.system.internal.DataTypeSet(...
            { matlab.system.internal.CustomDataType( ...
            'Signedness', {'Signed'}, ...
            'Scaling', {'Unspecified', 'BinaryPoint'})});
    end
    
    properties (Access = protected)
        HFilter;
        HDelay;
        NumChannels;
        pfimath;        
    end
    
    properties (Access = protected, Nontunable)
        Coefficients;
        pSR = 44100;
    end
    
    %----------------------------------------------------------------------
    % Abstract public methods
    %----------------------------------------------------------------------
    methods (Abstract)
        h = getFilter(obj);
    end
    
    %----------------------------------------------------------------------
    % Abstract protected methods
    %----------------------------------------------------------------------
    methods (Abstract, Access = protected)
        designObjects(~);
    end
    
    %----------------------------------------------------------------------
    % Public methods
    %----------------------------------------------------------------------
    methods
        
        function obj = FIRHalfbandBase(varargin)
            % Support name-value pair arguments
            setProperties(obj, nargin, varargin{:});
            obj.NumChannels = int32(-1);
        end
        
        %------------------------------------------------------------------
        % Set methods for non-fixed point properties
        %------------------------------------------------------------------
       
        function set.StopbandAttenuation(obj,Astop)
            validateattributes(Astop,{'numeric'},{'finite','scalar',...
                'real','>',0},'','StopbandAttenuation');
            %cast to enforce double precision on Astop
            obj.StopbandAttenuation = double(Astop);
            needToDesignFilters(obj);
        end
        
        %------------------------------------------------------------------
        
        function set.FilterOrder(obj,Order)
            validateattributes(Order,{'numeric'},{'finite','scalar',...
                'real','even','>',0},'','FilterOrder');
            %cast to enforce double precision on Order
            obj.FilterOrder = double(Order);
            needToDesignFilters(obj);
        end
        
        %------------------------------------------------------------------
        
        function set.Specification(obj,s)
            obj.Specification = s;
            needToDesignFilters(obj);
        end
        
        %------------------------------------------------------------------
        function set.RoundingMethod(obj,val)
            obj.RoundingMethod = val;
            needToDesignFilters(obj)
        end
        
        %------------------------------------------------------------------
        function set.CoefficientsDataType(obj, val)
            obj.CoefficientsDataType = val;
            needToDesignFilters(obj)
        end
   
        %------------------------------------------------------------------

        function set.SampleRate(obj,value)
            validateattributes(value,...
                {'double','single'}, ...
                {'real','scalar','positive','finite'},...
                '','SampleRate');
            obj.SampleRate = value;
            postProcessSampleRate(obj,value);
        end

        %------------------------------------------------------------------
        function set.DesignMethod(obj,value)
            obj.DesignMethod = value;
            needToDesignFilters(obj);
        end
    end
    
    %----------------------------------------------------------------------
    % Protected methods
    %----------------------------------------------------------------------
    methods (Access=protected)
        function validateInputsImpl(obj,Input)
            % Check if the input is either numeric or embedded.fi with
            % finite values
            validateattributes(Input, {'numeric','embedded.fi'},...
                {},'','Input');
            
            % Input cannot be unsigned complex fixed-point since
            % dsp.FIRFilter can not handle such an input
            if isfi(Input)
                coder.internal.errorIf(~issigned(Input) && ~isreal(Input), ...
                    'dsp:system:CICCompensationDecimator:inputUnsignedComplexFixedPoint');
            end
            
            % Check if number of channels has changed since last step
            if obj.NumChannels ~= -1
                coder.internal.errorIf(size(Input,2) ~= obj.NumChannels,...
                    'dsp:system:Shared:numChannels');
            end
            
            
            if isempty(coder.target)
                if ~isempty(Input)
                    cacheInputDataType(obj,Input)
                end
            end
            
        end
        
        function outputDType = designFilter(obj,isInterpolator,varargin)
            
            coder.extrinsic('dsp.internal.FIRHalfbandBase.designHalfBand');
            
            if obj.IsFilterDesigned
                if nargout > 0
                    if nargin > 2
                        outputDType = designObjects(obj,varargin{:});
                    end
                end
                return % EARLY RETURN
            end
            
            coeffDirectlySpecified = ...
                strcmp(obj.Specification, 'Coefficients');
            
            if coeffDirectlySpecified 
                Coeff = obj.Numerator;
                HB = []; % unused
            else
                % Coefficients AUTO-DESIGNED
                if isInterpolator
                    if isSampleRateNormalized(obj) || obj.NormalizedFrequency
                        % When normalized frequency is provided, it is
                        % already normalized according to 2*Fs
                        DesignFs = getSampleRate(obj); 
                    else
                        DesignFs = 2*getSampleRate(obj);
                    end
                else
                    DesignFs = getSampleRate(obj);
                end
                
                if isempty(coder.target)
                    [Coeff, HB] = ...
                        dsp.internal.FIRHalfbandBase.designHalfBand( ...
                        obj.Specification,       ...
                        obj.FilterOrder,         ...
                        obj.TransitionWidth,     ...
                        obj.StopbandAttenuation, ...
                        DesignFs,                ...
                        obj.DesignMethod);
                else
                    % Code generation does not use
                    % HB or any fdesign properties
                    [Coeff, ~] = coder.const( ...
                        @dsp.internal.FIRHalfbandBase.designHalfBand,...
                        obj.Specification,       ...
                        obj.FilterOrder,         ...
                        obj.TransitionWidth,     ...
                        obj.StopbandAttenuation, ...
                        DesignFs,                ...
                        obj.DesignMethod);
                    HB = []; % unused
                end
            end

            % Set private Coefficients property real-world values
            if nargin>2 && ~isfi(varargin{1}) && isa(varargin{1},'single')
                obj.Coefficients = single(Coeff);
            else
                obj.Coefficients = Coeff; % double precision values
            end
            halfOrder = ceil((length(obj.Coefficients)-1)/2);
            obj.IsHalfOrderOdd = mod(halfOrder,2);
            
            if nargin > 2
                outputDType = designObjects(obj,varargin{:});
            end
            
            if isempty(coder.target)
                if ~coeffDirectlySpecified
                    % Set fdesign and fmethod on the object
                    fdes = getfdesign(HB);

                    if ~isempty(fdes)
                        if isprop(obj, 'NormalizedFrequency')
                          if obj.NormalizedFrequency
                              % Display Normalized frequencies with fvtool
                              normalizefreq(fdes);
                          end
                        end
                    end

                    setMetaData(obj, fdes, getfmethod(HB));
                end
                obj.IsFilterDesigned = true;
            end
        end
        
        function needToDesignFilters(obj)
            % Filter analysis may have been supported previously.
            % Clear previous FVTool (filter analysis) meta-data from
            % prior filter design properties here, to avoid UI issues.
            if isempty(coder.target)
                % Set fdesign and fmethod on the object to empty
                setMetaData(obj, [], []);
            end
            obj.IsFilterDesigned = false;
        end
        
        function outDT = constructFltptHFilter(obj, isInterpolator, u, CoeffDoubleVals)
            
            outDT = class(u); % floating-point (I/O same types)
            
            if isempty(coder.target)
                % MATLAB interpreted mode (use CoeffDoubleVals directly)
                obj.HFilter = dsp.FIRFilter('Numerator', CoeffDoubleVals);
            else
                % CODEGEN: Temporarily use prototype coeffs (zeros)
                obj.pPrototypeCoeffs = ...
                    coder.const(@obj.designProtoCoeffs, ...
                    size(obj.Coefficients, 2)); % ZERO-FILLED (DOUBLE)
                
                obj.HFilter = ...
                    dsp.FIRFilter('Numerator', ...
                    cast(obj.pPrototypeCoeffs, 'like', real(u)));
                
                setupHFilterForCodeGen(obj, isInterpolator, u, ...
                    cast(CoeffDoubleVals,  'like', real(u)));
            end
        end
        
        function outDT = mlConstructFixptHFilter(obj, isInterpolator, CoefFI, CoefDbl, u, uNT)
            coder.extrinsic('dsp.internal.FIRHalfbandBase.computeFIRHBOutDT');
            
            % if isinteger(CoefFI)
            %     coeffDT = numerictype(class(CoefFI));
            % else
            %     coeffDT = numerictype(CoefFI);
            % end
            coeffDT = numerictype(CoefFI);
            outDT   = coder.const(@obj.computeFIRHBOutDT, CoefFI, uNT);
            
            if isempty(coder.target)
                % MATLAB interpreted mode: use CoefDbl values directly
                obj.HFilter = dsp.FIRFilter( ...
                    'Numerator',                  CoefDbl, ...
                    'CoefficientsDataType',      'Custom', ...
                    'CustomCoefficientsDataType', coeffDT, ...
                    'FullPrecisionOverride',      false,   ...
                    'OutputDataType',            'Custom', ...
                    'CustomOutputDataType',       outDT);
            else
                % CODEGEN: Temporarily use prototype coeffs (zeros)
                obj.pPrototypeCoeffs = ...
                    coder.const(@obj.designProtoCoeffs, ...
                    size(obj.Coefficients, 2)); % ZERO-FILLED (DOUBLE)
                
                obj.HFilter = dsp.FIRFilter( ...
                    'Numerator',     obj.pPrototypeCoeffs, ...
                    'CoefficientsDataType',      'Custom', ...
                    'CustomCoefficientsDataType', coeffDT, ...
                    'FullPrecisionOverride',      false,   ...
                    'OutputDataType',            'Custom', ...
                    'CustomOutputDataType',       outDT);
                
                % Then call setup with CoefDbl values
                setupHFilterForCodeGen(obj, isInterpolator, u, CoefDbl);
            end
        end
        
        function outDT = cgConstructFixptHFilter(obj, isInterpolator, CoeffDoubleVals, u1, u2)
            coder.extrinsic('dsp.internal.FIRHalfbandBase.getBestPrecCfDT');
            coder.extrinsic('dsp.internal.FIRHalfbandBase.computeFIRHBOutDT');

            if isinteger(u1)
                % FIRHalfbandDecimator or FIRHalfbandInterpolator
                uNT = numerictype(class(u1));
            elseif nargin < 5
                % Only u1 specified (FI)
                % FIRHalfbandDecimator or FIRHalfbandInterpolator
                uNT = numerictype(u1);
            else
                % Both u1 and u2 specified (FI)
                % FIRHalfbandInterpolator ONLY
                uNT = numerictype(u1 + u2);
            end
            
            obj.pProtoInputType = uNT;
            
            % Determine coeffDT from non-tunable coefficient values
            % (obj.CoefficientsDataType might be 'Custom' and might not)
            specCoeffDT  = obj.CoefficientsDataType;
            if strcmp(specCoeffDT.DataTypeMode, ...
                    'Fixed-point: unspecified scaling')
                % Signed fixed-point, UNSPECIFIED SCALING
                cfWL = specCoeffDT.WordLength;
                cfDT = coder.const(@obj.getBestPrecCfDT, ...
                    CoeffDoubleVals, cfWL);
            else
                % Signed fixed-point, specified scaling
                cfDT = obj.CoefficientsDataType;
            end
            
            outDT = coder.const(@obj.computeFIRHBOutDT, ...
                fi(CoeffDoubleVals, cfDT), obj.pProtoInputType);

            % Construct HFilter (using all-zero prototype coeff values)
            obj.pPrototypeCoeffs = ...
                coder.const(@obj.designProtoCoeffs, ...
                size(obj.Coefficients, 2)); % ZERO-FILLED (DOUBLE)
            
            obj.HFilter = dsp.FIRFilter( ...
                'Numerator',                  obj.pPrototypeCoeffs, ...
                'CoefficientsDataType',      'Custom',              ...
                'CustomCoefficientsDataType', cfDT,              ...
                'FullPrecisionOverride',      false,                ...
                'OutputDataType',            'Custom',              ...
                'CustomOutputDataType',       outDT);

            % Then call setup with u1 (AND double precision coeff values)
            u_FI = fi(u1, uNT); % uNT may be different from u1
            setupHFilterForCodeGen(obj, isInterpolator, u_FI, CoeffDoubleVals);
        end
        
        function setupHFilterForCodeGen(obj, isInterpolator, u, CoeffHB)
            % Only use this for CODEGEN modes and WHEN LOCKED
            if isLocked(obj)
                if isInterpolator
                    u1=u;
                else
                    u1=u(1:2:end,:);
                end
                setup(obj.HFilter, u1);

                numElProtoCf = numel(obj.pPrototypeCoeffs);
                numElCoeffHB = numel(CoeffHB);

                % Replace prototype coeffs with actual
                if numElProtoCf >= numElCoeffHB
                    if isfloat(u)
                        localNumeratorVals = cast( ...
                            zeros(size(obj.pPrototypeCoeffs)), 'like', real(u));
                    else
                        localNumeratorVals = ...
                            zeros(size(obj.pPrototypeCoeffs));
                    end
                else
                    if isfloat(u)
                        localNumeratorVals = cast( ...
                            zeros(size(CoeffHB)), 'like', real(u));
                    else
                        localNumeratorVals = zeros(size(CoeffHB));
                    end
                end

                if (isInterpolator) || ...
                        (numElCoeffHB <= numel(obj.pPrototypeCoeffs))
                    localNumeratorVals(1:numElCoeffHB) = CoeffHB;
                else
                    localNumeratorVals(1:numElProtoCf) = ...
                        CoeffHB(1:numElProtoCf);
                end

                obj.HFilter.Numerator = localNumeratorVals;
            end
        end
        
        function d = convertToDFILT(obj,arith)
            % Convert the System object to a mfilt object for analysis
            d = getFilter(obj);
            d.Arithmetic = arith;
            if strcmp(arith,'fixed')
                coeffDT = obj.CoefficientsDataType;
                d.CoeffWordLength = coeffDT.WordLength;
                if strcmp(coeffDT.Signedness, 'Unsigned')
                    d.Signed = false;
                end
                if ~isscalingunspecified(coeffDT)
                    d.CoeffAutoScale = false;
                    d.NumFracLength = coeffDT.FractionLength;
                end
            end
                    
            setfdesign(d, getfdesign(obj));
            setfmethod(d, getfmethod(obj));
        end
        %------------------------------------------------------------------
        function flag = isInactivePropertyImpl(obj, prop)
            specLocal = obj.Specification;
            coeffSpec = strcmp(specLocal, 'Coefficients');
            FO_and_TW = strcmp(specLocal, 'Filter order and transition width');
            FO_and_SA = strcmp(specLocal, 'Filter order and stopband attenuation');
            TW_and_SA = strcmp(specLocal, 'Transition width and stopband attenuation');
            switch prop
                case {'Numerator'}
                    flag = (~coeffSpec);
                case {'StopbandAttenuation'}
                    flag = coeffSpec || FO_and_TW;
                case {'TransitionWidth'}
                    flag = coeffSpec || FO_and_SA;
                case {'FilterOrder'}
                    flag = coeffSpec || TW_and_SA;
                case {'DesignMethod'}
                    flag = coeffSpec;
                case {'SampleRate'}
                    if obj.getExecPlatformIndex()
                        flag = ~isSampleRateOnDialog(obj);
                    else
                        flag = obj.NormalizedFrequency;
                    end
                    flag = flag || coeffSpec;  
                case {'SampleRateMode','NormalizedFrequency'}
                    flag = coeffSpec;
                otherwise
                    flag = false;
            end
        end
        %------------------------------------------------------------------
        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end
        
        %------------------------------------------------------------------
        
        function flag = isInputComplexityMutableImpl(~,~)
            flag = false;
        end
        
        %------------------------------------------------------------------
        
        function resetImpl(obj)
            reset(obj.HFilter);
            reset(obj.HDelay);
        end
        %------------------------------------------------------------------
        function releaseImpl(obj)
            release(obj.HFilter);
            release(obj.HDelay);
            obj.NumChannels = int32(-1);
            needToDesignFilters(obj);
        end
        %------------------------------------------------------------------
        function loadObjectImpl(obj,s,wasLocked)
            if isfield(s, 'CoefficientsDataType')
                % backwards compatibility for objects saved before R2015b
                if strcmp(s.CoefficientsDataType.Signedness, 'Auto')
                    s.CoefficientsDataType.Signedness = 'Signed';
                end
            end
            loadObjectImpl@dsp.internal.NormalizedSampleRateEngine(obj,s,wasLocked);
            if wasLocked
                obj.HFilter = matlab.System.loadObject(s.HFilter);
                obj.HDelay  = matlab.System.loadObject(s.HDelay);
            end
            obj.IsHalfOrderOdd   = s.IsHalfOrderOdd;
            obj.IsFilterDesigned = s.IsFilterDesigned;
            obj.Coefficients     = s.Coefficients;
            if isfield(s, 'NumChannels')
                obj.NumChannels = s.NumChannels;
            end
            if isfield(s, 'pSR')
                obj.pSR = s.pSR;
            end
            loadFA(obj, s, wasLocked); % Load FilterAnalysis properties
        end
        %------------------------------------------------------------------
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@dsp.internal.NormalizedSampleRateEngine(obj);
            s.Coefficients     = obj.Coefficients;
            s.IsFilterDesigned = obj.IsFilterDesigned;
            s.IsHalfOrderOdd   = obj.IsHalfOrderOdd;
            s.NumChannels      = obj.NumChannels;
            s.pSR              = obj.pSR;
            if isLocked(obj)
                s.HFilter = matlab.System.saveObject(obj.HFilter);
                s.HDelay  = matlab.System.saveObject(obj.HDelay);
            end
            s = saveFA(obj, s);   % Save FilterAnalysis properties
        end
        %------------------------------------------------------------------
        function y = infoImpl(obj,varargin)
            y = infoFA(obj,varargin{:});
        end
        %------------------------------------------------------------------
        function postProcessSampleRate(obj,val)
            needToDesignFilters(obj);
            obj.pSR = val;
        end
        function Fs = getSampleRate(obj)
            if ~isInactivePropertyImpl(obj, 'SampleRateMode')
                % Call from simulink object
                if isSampleRateNormalized(obj)
                    Fs = 2;
                elseif isSampleRateInherited(obj)
                    Fs = getInheritedSampleRate(obj);
                else
                    Fs = obj.SampleRate;
                end
            else
                if obj.NormalizedFrequency
                   Fs = 2;
               else
                   Fs = obj.SampleRate;
                end
            end
        end
    end
    
    %----------------------------------------------------------------------
    % Hidden methods
    %----------------------------------------------------------------------
    methods (Hidden)
        function flag = isPropertyActive(obj,prop)
            % Needed for dsp.internal.FilterAnalysisMultirate
            flag = ~isInactivePropertyImpl(obj, prop);
        end
        
        %------------------------------------------------------------------
        function props = getFixedPointProperties(~)
            % Needed for dsp.internal.FilterAnalysisMultirate
            props = dsp.internal.FIRHalfbandBase.getDisplayFixedPointPropertiesImpl;
        end
        %------------------------------------------------------------------
        function restrictionsCell = getFixedPointRestrictions(~,~)
            % Needed for dsp.internal.FilterAnalysisMultirate
            restrictionsCell = {};
        end
        
        function [flag,errID] = isFVtoolSupported(obj)
            flag  = strcmp(obj.Specification, 'Coefficients');
            errID = '';
            if ~flag && isprop(obj, 'SampleRateMode')
                flag = true;
                if isSampleRateInherited(obj)
                    flag = false;
                    errID = 'dsp:system:Shared:fvtoolButtonInheritSRTexDropdown';
                end
            end
            
        end
    end
    
    %----------------------------------------------------------------------
    % Static Hidden methods
    %----------------------------------------------------------------------
    methods (Static, Hidden)
        function props = getDisplayFixedPointPropertiesImpl()
            % Needed for dsp.internal.FilterAnalysisMultirate
            props = {...
                'CoefficientsDataType',  ...
                'RoundingMethod'};
        end
        
        function [CF, HB] = designHalfBand( ...
                Specification,       ...
                FilterOrder,         ...
                TransitionWidth,     ...
                StopbandAttenuation, ...
                SampleRate,          ...
                varargin)
            % Filter is designed using firhalfband, and fdesign,fmethod
            % are used store filter specifications and metadata
            if isempty(varargin)
                DesignMethod ="Auto";
            else
                DesignMethod = validatestring(varargin{1},["Auto","Equiripple","Kaiser"]);
            end
            checkAutoEquiripple = false;
            if strcmpi(DesignMethod,'Auto')
                chosenMethod = dsp.internal.FIRHalfbandBase.computeAutoDesignMethod(...
                    Specification, TransitionWidth/SampleRate,...
                    StopbandAttenuation, FilterOrder);
                checkAutoEquiripple = strcmpi(chosenMethod,'Equiripple');
            end

            if strcmpi(Specification,'Filter order and transition width')
                % 'Filter order and transition width'
                if strcmpi(DesignMethod,'Equiripple') || checkAutoEquiripple
                    CF = firhalfband(FilterOrder,1/2-TransitionWidth/SampleRate);
                    m = fdfmethod.eqriphbordntw;
                else 
                    Astop = pi*2.285*FilterOrder*2*TransitionWidth/SampleRate  + 7.95;
                    beta = dsp.internal.FIRHalfbandBase.computeBeta(Astop);
                    CF = firhalfband(FilterOrder,kaiser(FilterOrder+1,beta));
                    m =fdfmethod.kaiserhbordntw;
                end
                f = fdesign.halfband('n,tw', FilterOrder, ...
                    TransitionWidth, SampleRate);
            elseif strcmpi(Specification,'Filter order and stopband attenuation')
                % 'Filter order and stopband attenuation'
                if strcmpi(DesignMethod,'Equiripple') || checkAutoEquiripple
                    CF = firhalfband(FilterOrder,db2mag(-StopbandAttenuation),'dev');
                    m = fdfmethod.eqriphbastop;
                else 
                    beta = dsp.internal.FIRHalfbandBase.computeBeta(StopbandAttenuation);
                    CF = firhalfband(FilterOrder,kaiser(FilterOrder+1,beta));
                    m = fdfmethod.kaiserhbastop;
                end
                f = fdesign.halfband('n,ast', FilterOrder, ...
                    StopbandAttenuation, SampleRate);                
            else
                % 'Transition width and stopband attenuation'
                if strcmpi(DesignMethod,'Equiripple')  || checkAutoEquiripple
                    CF = firhalfband('minorder',1/2-TransitionWidth/SampleRate,db2mag(-StopbandAttenuation));
                    m = fdfmethod.eqriphbmin;
                else 
                    CF = firhalfband('minorder',1/2-TransitionWidth/SampleRate,db2mag(-StopbandAttenuation),'kaiser');
                    m = fdfmethod.kaiserhbmin;
                end
                f = fdesign.halfband('tw,ast', TransitionWidth, ...
                    StopbandAttenuation, SampleRate);                
            end
            HB = dfilt.dffir(CF);              
            addsysobjdesignopt(m);
            setfdesign(HB,f);
            setfmethod(HB,m);
        end

        function Method = computeAutoDesignMethod(Specification, tw, Astop, N)
            % Choose design method using analytical conditions on filter
            % specification and design parameters
            if strcmpi(Specification,'Filter order and transition width')
                if tw < 5.85e4/(N+123.7)^2.39
                    Method = 'Equiripple';
                else
                    Method = 'Kaiser';
                end
            elseif strcmpi(Specification,'Filter order and stopband attenuation')
                if Astop < 240
                    Method = 'Equiripple';
                else
                    Method = 'Kaiser';
                end
            else
                if tw > 1.332e-4*exp(0.035*Astop)
                    Method = 'Equiripple';
                else
                    Method = 'Kaiser';
                end
            end
        end

        function beta = computeBeta(Astop)
            if Astop >= 50
                beta = 0.1102*(Astop - 8.7);
            elseif Astop < 50 && Astop > 21
                beta = 0.5842*(Astop - 21)^.4 + 0.07886*(Astop - 21);
            elseif Astop <= 21
                beta = 0;
            end
        end
        
        function protoCoeffRetValues = designProtoCoeffs(numCoeffsFullLength)
            numCoeffHBProtoType = floor(1 + (numCoeffsFullLength / 2));
            protoCoeffRetValues = zeros(1,numCoeffHBProtoType);
        end
        
        function cfDT = getBestPrecCfDT(CoeffDoubleVals, cfWL)
            % Use floating-point min/max value for best precision cfDT
            if any(CoeffDoubleVals ~= 0)
                minVal = min(CoeffDoubleVals);
                maxVal = max(CoeffDoubleVals);
                if abs(maxVal) >= abs(minVal)
                    dblVal = maxVal;
                else
                    dblVal = minVal;
                end
                cfFL = get(fi(dblVal, 1, cfWL), 'FractionLength');
            else
                cfFL = cfWL;
            end
            cfDT = numerictype(1, cfWL, cfFL);
        end
        
        function outDT = computeFIRHBOutDT(fiCoeffs, inputDT)
            coder.extrinsic('dsp.internal.FIRFilterPrecision');
            [A] = coder.const( ...
                @dsp.internal.FIRFilterPrecision, fiCoeffs, inputDT);
            outWL = coder.const(A.WordLength);
            outFL = coder.const(A.FractionLength);
            outDT = numerictype(1, outWL, outFL);
        end
        
        function checkNumeratorFormat(dblNumVals, isInterpolator)
            needToThrowError = false; % default: PASS
            totNumCoefValues = numel(dblNumVals(:));
            
            % Compute expected Interpolator or Decimator maximum value
            if isInterpolator
                midpointMaxVal = 1.0;
            else
                midpointMaxVal = 0.5;
            end
            
            % Compute expected (midpoint) maximum value location
            if (totNumCoefValues < 2)
                expMaximumValLoc = 1;
            elseif (totNumCoefValues < 4)
                expMaximumValLoc = 2;
            else
                % Numerator is length 4 or greater
                if (rem(totNumCoefValues,2) ~= 0)
                    % ODD length Numerator (add one to get integer index)
                    expMaximumValLoc = (totNumCoefValues + 1) / 2;
                else
                    expMaximumValLoc = totNumCoefValues / 2;
                end
                
                if isequal(dblNumVals(1),0) && isequal(dblNumVals(3),0)
                    % Expected maximum value at odd index position
                    if (rem(expMaximumValLoc,2) ~= 1)
                        expMaximumValLoc = expMaximumValLoc + 1;
                    end
                elseif isequal(dblNumVals(2),0) && isequal(dblNumVals(4),0)
                    % Expected maximum value at even index position
                    if (rem(expMaximumValLoc,2) ~= 0)
                        expMaximumValLoc = expMaximumValLoc + 1;
                    end
                end
            end

            % Get LOCATION(S) of actual ZERO VALUE(S) and MAX VALUE(S)
            logicalIdxZerVal = (dblNumVals(:) == 0);
            logicalIdxMaxVal = (dblNumVals(:) == midpointMaxVal);
            maxValueLocation = find(logicalIdxMaxVal, 1, 'first');
            
            % CHECK MAX VALUES AND ZERO VALUES
            if (max(dblNumVals(:)) ~= midpointMaxVal)
                needToThrowError = true; % Max value not found
            elseif ~isequal(sum(logicalIdxMaxVal), 1)
                needToThrowError = true; % Max value is not unique
            elseif (maxValueLocation ~= expMaximumValLoc)
                needToThrowError = true; % Incorrect max value location
            elseif (sum(logicalIdxZerVal) < 2) && (totNumCoefValues > 2)
                needToThrowError = true; % Not enough zero values
            else
                % -------------------------------------------------------
                % Finally, check all expected indices contain zero values
                % that should (based on half-order length odd / even).
                % Indirectly, also verifies midpoint max value location.
                % -------------------------------------------------------
                if dblNumVals(1) == 0
                    startIdx = 1;
                else
                    startIdx = 2;
                end
                for idx = startIdx:2:totNumCoefValues
                    if ( ~isequal(dblNumVals(idx),0) && ...
                            (idx ~= maxValueLocation) )
                        % Unexpected non-zero and NOT midpoint max value
                        needToThrowError = true;
                        break; % stop checking
                    end
                end
            end

            if needToThrowError
                if isInterpolator
                    msgID = 'dsp:firhalfband:IntrpNumeratorInvalid';
                else
                    msgID = 'dsp:firhalfband:DecimNumeratorInvalid';
                end
                coder.internal.error(msgID);
            end
        end
    end
end
