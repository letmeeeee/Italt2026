classdef FilterAnalysis < handle
%#codegen
%#ok<*EMCLS>
%#ok<*EMCA>

  %FilterAnalysis Baseclass for filter System object analysis
  
  %   Copyright 2011-2023 The MathWorks, Inc.
  
  properties (Access = protected)
    %pFdesign Fdesign metadata
    pFdesign = [];
    
    %pFmethod Fmethod metadata
    pFmethod = [];
    
    %pMeasurements Measurements metadata
    pMeasurements = [];
    
    %pDesignMethod Design method metadata
    pDesignMethod = [];
        
    %pLockedArithmetic
    pLockedArithmetic = [];   
    
    %pInputWordLength
    pInputWordLength = 16;
    
    %pInputWordLength
    pInputFractionLength = 15;
    
    %pInputSignedness
    pInputSignedness = 'Signed';              
  end
  
  methods
    function obj = FilterAnalysis(varargin)
        
    end
  end
  
  methods (Abstract, Hidden)
    restr = getFixedPointRestrictions(obj,prop)
    props = getFixedPointProperties(obj)
    props = getNonFixedPointProperties(obj)
    flag  = isPropertyActive(obj,props)
  end

  methods (Abstract, Access = protected)
    d = convertToDFILT(obj,arith)
  end
  
  methods (Hidden)
    function g = nominalgain(obj)
    %nominalgain   Return the nominal gain.    
        g = 1;

        hfdesign = obj.getfdesign();
        if ~isempty(hfdesign)
            [L,~] = rateConversionFactors(obj);
            
            % If the filter was designed with FDESIGN the nominalgain should be
            % exactly equal to the overall interpolation factor.
            g = L;
        end
    end
      
    %----------------------------------------------------------------------
    function id = validateratechangefactors(obj, varargin) %#ok
        id = [];
    end

    function [L,M] = rateConversionFactors(obj) %#ok
    % Returns the conversion factors [L,M] of multirate System objects.
    % Single rate systems are considered a special case, in which L=M=1.
        nargoutchk(2,2);
        L = 1;
        M = 1;
    end

    function FsIn = inputSampleRate(obj) 
    % Returns the input sample rate of the object.
    % By default we assume unit sample rate.

        if isprop(obj,'InputSampleRate')
            % If the object has an InputSampleRate property (usually for 
            % multirate objects such as dsp.FarrowRateConverter), use it
            FsIn = obj.InputSampleRate;
        elseif isprop(obj,'SampleRate')
            % Otherwise, if 'SampleRate' property (usually single rate 
            % objects such as dsp.LowpassFilter), use it
            FsIn = obj.SampleRate;
        else
            % Otherwise, it is a pure digital object (like dsp.FIRFilter),
            % so assume a unit sample time
            FsIn = 1;
        end
    end

    function fd = getfdesign(obj)
      if isempty(obj.pFdesign)
        fd = obj.pFdesign;
      else
        fd = copy(obj.pFdesign);
      end
    end
    
    function [flag,errID] = isFVtoolSupported(obj)
        % Specify if fvtool plot is supported, and what error should be
        % used when it is not supported.
        % Default implementation of this method
        % Children can override it for custom behavior
        flag = true;
        errID = '';
       if isprop(obj, 'InheritSampleRate')
          flag = ~obj.InheritSampleRate;
          errID = 'dsp:system:Shared:fvtoolButtonInheritSRText';
       end
    end
    
    function ipval = getHdlipval(obj,inputnumerictype)
        if isa(obj,'dsp.FIRHalfbandDecimator') == 1
            ipval = repmat(fi(0,inputnumerictype),2,1);
        elseif isa(obj,'dsp.FarrowRateConverter') == 1
            [~,M] = getRateChangeFactors(obj);
            ipval = repmat(fi(0, inputnumerictype),M,1);
        elseif isprop(obj, 'DecimationFactor') == 1
            deci = obj.DecimationFactor;
            ipval = repmat(fi(0,inputnumerictype),deci,1);
        else
            ipval = fi(0, inputnumerictype);
        end
    end
    
    function fm = getfmethod(obj)
      if isempty(obj.pFmethod)
        fm = obj.pFmethod;
      else
        fm = copy(obj.pFmethod);
        addsysobjdesignopt(fm); 
        fm.SystemObject = true;        
      end
    end

    function dm = getdesignmethod(obj)
        dm = obj.pDesignMethod;
    end

    function setMetaData(obj,fd,fm,meas,dm)
      % setMetaData Set the filter meta data
      % Inputs:
      % fd   - fdesign object
      % fm   - fmethod object
      % meas - measurements
      % dm   - design method
      if nargin > 1
        setFdesign(obj,fd);
        if nargin > 2
          setFmethod(obj,fm);
          if nargin > 3
            obj.pMeasurements = meas;
            if nargin > 4
              obj.pDesignMethod = dm;
            end
          end
        end
      end
    end
    
    function clearMetaData(obj)
      % clearMetaData Clear the filter meta data
      % This clears fdesign object, fmethod object, measurements, and 
      % design method from the object's properties
      obj.pFdesign      = [];
      obj.pFmethod      = [];
      obj.pMeasurements = [];
      obj.pDesignMethod = [];
    end
        
    function [activeProps,values] = getActiveProps(obj,type)
      switch type
        case 'fixed'
          props = getFixedPointProperties(obj);
        case 'nonfixed'
          props = getNonFixedPointProperties(obj);
        case 'all'
          props = getNonFixedPointProperties(obj);
          props = [props getFixedPointProperties(obj)];
        otherwise
          error(message(...
            'dsp:dsp:private:FilterSystemObjectBase:UnknownPropType',type))
      end
      activeProps = {};
      values = {};
      for idx = 1:length(props)
        if isPropertyActive(obj,props{idx})
          activeProps{end+1} = props{idx}; 
          if nargout > 1
            values{end+1} = get(obj,props{idx}); 
          end
        end
      end
    end
    
    function d = todfilt(obj,arith)
      % Convert System object to a DFILT object
      if (nargin==1 || isempty(arith)) && ~isFilterCascade(obj)
        if isLocked(obj) && ~isCICFilter(obj)
          arith = obj.pLockedArithmetic;
        elseif isCICFilter(obj)
          arith = 'fixed';
        else
          arith = 'double';
        end
      end
      
      d = convertToDFILT(obj,arith);
      
      if isa(obj, 'dsp.FarrowRateConverter') == 0
        % NOT dsp.FarrowRateConverter
        if isprop(d,'Arithmetic') && strcmpi(d.Arithmetic,'fixed')
          if isLocked(obj)
            d.InputWordLength = obj.pInputWordLength;
            d.InputFracLength = obj.pInputFractionLength;        
          else
            d.InputWordLength = 16;
            d.InputFracLength = 15;                  
          end
        end
      end

      % Set metadata of the converted DFILT object
      setfdesign(d,obj.getfdesign)
      setfmethod(d,obj.pFmethod)
      if ~isempty(obj.pDesignMethod)
        setdesignmethod(d,obj.pDesignMethod)
      end
      d.FromSysObjFlag = true;

      clonedObj = clone(obj);
      release(clonedObj);
      d.ContainedSysObj = clonedObj;   

      d.SupportsNLMethods = isNLMSupported(obj,arith);      
    end

    function b = isSpecMet(obj,hfdesign,varargin)
        if nargin > 1
            m = measure(obj,hfdesign);
        else
            m = measure(obj);
        end

        if isempty(m)
            b = false;
        else
            if nargin > 1
                b = isspecmet(m,hfdesign,varargin{:});
            else
                b = isspecmet(m);
            end
        end
    end

    function flag = isFilterCascade(~)
        flag = false;
    end
    
    function flag = isCICFilter(~)
      flag = false;
    end      
    
    function flag = isMultirate(~)
      flag = false;
    end          
    
    function [dobj,cobj] = sysobjHdl(obj,varargin)
        
        t = builtin('license', 'test', 'Filter_Design_HDL_Coder') && ~isempty(ver('hdlfilter'));
        if ~t
            error(message('dsp:dsp:private:FilterSystemObjectBase:HDLnolicenseavailable'));
        end
        
        indices = strcmpi(varargin, 'inputdatatype');
        pos = 1:length(indices);
        pos = pos(indices);
        if isempty(pos)
            error(message('hdlfilter:privgeneratehdl:inputdatatypenotspecified'));
        end
        inputnumerictype = varargin{pos+1};
        if ~strcmpi(class(inputnumerictype),'embedded.numerictype')
            error(message('hdlfilter:privgeneratehdl:incorrectinputdatatype'));
        end
        
        d = inputnumerictype.DataTypeMode;
        if strcmpi(d,'double') == 1
            arith = 'double';
        elseif strcmpi(d,'Fixed-point: binary point scaling') == 1
            s = inputnumerictype.Signedness;
            if strcmpi(s,'Signed') == 1
                arith = 'fixed';
            else
                error(message('dsp:dsp:private:FilterSystemObjectBase:HDLNotSupportedDataType'));
            end
        else
            error(message('dsp:dsp:private:FilterSystemObjectBase:HDLNotSupportedDataType'));
        end
        
        ipval = getHdlipval(obj,inputnumerictype);
        cobj = clone(obj);
        release(cobj);
        step(cobj,ipval);
        dobj = todfilt(cobj,arith);
    end
        
    function [cando, errstr, errorObj] = ishdlable(sobj)
        % ISHDLABLE True if HDL can be generated for the system object.
        %
        % ISHDLABLE(Hd) determines if HDL code generation is supported for the
        % system object Hd and returns true or false.
        %
        % The optional second return value is a string that specifies why HDL
        % could not be generated for the filter object Hd.

        %   Copyright 2011-2014 The MathWorks, Inc.
        
        c = class(sobj);
        supportedSystemObjs = dsp.internal.gethdlSysObj;
        if ~any(strncmpi(c, supportedSystemObjs, length(c)))
            errorObj = message('dsp:dsp:private:FilterSystemObjectBase:HDLNotSupported');
            errstr = getString(errorObj);
            cando = 0;
        else
            errstr = '';
            errorObj = [];
            cando = 1;
        end
    end
 
    function  opts = parseObjectLevelOptions(~, opts)
    % Actual signature: customAnalysisOptionsOut = parseObjectLevelOptions(obj, customAnalysisOptionsIn)
    % Overload as appropriate to parse additional flags passed to analysis
    % method that are only relevant to current concrete class
    end
    
    function  resetAnalysisOptions(~)
    end
    
    function f = callFvtool(obj)
      % Used to bring up fvtool plot when object is used in Simulink
      f = fvtool(obj);
        if isprop(obj,'SampleRateMode') && isSampleRateNormalized(obj)
            f.NormalizedFrequency = 'on';
        end
    end
      
    
    function f = updateFvtoolFigure(obj,f)
      % Used to update fvtool plot when object is used in Simulink
      setfilter(f, obj);
    end
    
    function f = updateFvtoolLegend(~, f, blkh)
      % Used to update fvtool legend when object is used in Simulink
      legend(f, get_param(blkh, 'Name'));
    end


    function B = groupDelayBand(obj,FsIn, Fc, D, tol,N)
    %groupDelayBand Find an estimated interval of frequencies containing 
    % freq wherein the group delay is within ±tol of nominal
    % 
    % Parameters:
    %   FsIn: input sample frequency 
    %   Fs:   input working frequency 
    %   D:    nominal group delay
    %   tol:  tolerance ratio (w.r.t input sample units)
    %   N:    DFT resultion (default 8192)
    %
    % Return value:
    %   B = [B1 B2] is the estimated group delay band. If B1==B2, the band
    %   amounts to a single frequency

        FnyqIn = FsIn/2;

        if islinphase(obj)
            B = [-FnyqIn FnyqIn];
        else
            [L,~] = obj.rateConversionFactors;
            Fs_Filter = FsIn*L;
            Fnyq_Filter = Fs_Filter/2;
            freq = Fc/Fnyq_Filter;

            % Map freq∈(-1,1] -> freq1∈[0,2)
            freq1 = mod(freq,2);    

            % Create N frequencies uniformly sampled on [0,2) 
            W = 0:2/N:2-2/N;

            % Obtain the group delay on that interval
            G = obj.grpdelay(N,'whole');
            G = G(:).'; % Ensure row vector

            % Mask out frequencies with non-numeric group delay values
            Wnum = ~isnan(G) & ~isinf(G);

            % Split [0,2) to frequencies below and above freq1
            Wgt = W>=freq1 & Wnum; % [freq1,2) 
            Wlt = W<=freq1 & Wnum; % [0,freq1] 

            % Mask frequencies violating group delay tolerance
            idxGD = abs(G-D)>tol*L;

            % Search clockwise, find the first index in which
            % the group delay escapes the tolerance.
            icw = find(Wgt & idxGD, 1, 'first');
            if isempty(icw)
                icw = find(Wlt & idxGD, 1, 'first');
            end

            % Search counterclockwise
            iccw = find(Wlt & idxGD, 1, 'last');
            if isempty(iccw)
                iccw = find(Wgt & idxGD, 1, 'last');
            end

            if isempty(icw) || isempty(iccw)
                % All viable frequencies are within GD tolerance
                % Note: if one is empty, then so is the other.
                % Proof:
                % Assuming ismepty(icw), then Wlt&idxGD is all false, as well 
                % Wgt & idxGD. Therefore (Wlt | Wgt)& idxGD is all false. 
                % However, at least one of Wlt or Wgt must have true entries, it 
                % so idxGD must all false, which means that iccw search 
                % will also come up empty.

                B = [-1 1];
            elseif icw==iccw || icw-iccw==1 || mod(iccw-icw,N)==1
                % If the immediate neighbors of the frequency are outside
                % the tolerance (usually happens when the FFT is too
                % coarse)
                B = [freq1 freq1];
            else
                % Two frequencies found, separated by at least two other
                % frequencies. 
                icw  = mod((icw-1)-1,N)+1;  % Step an index back into legal GD zone
                iccw = mod((iccw+1)-1,N)+1; % Step an index forward into legal GD zone
                B = W([iccw icw]);
            end

            % Translate from [0,2) to (-1,1] scale
            B = B-2*(B>1);

            % Rescale to filter Nyquist frequency
            B = Fnyq_Filter*B;

            % Clip at input Nyquist frequency
            B = min(B,FnyqIn);
            B = max(B,-FnyqIn);
        end        
    end
  end %method (Hidden)
  
  methods (Access = protected)
      function C = toMultirateChain(obj)
      % Convert a FilterAnalysis object to a MultirateChain object
      % The standard model for a FilterAnalysis object (except for
      % FilterCascade) is up->filter->down, i.e. ⟶(↑L)⟶H(z)⟶(↓M)⟶
         [L,M] = obj.rateConversionFactors();
         [num,den] = obj.tf();
         C = dsp.internal.MultirateAnalysis.MultirateChain({L, {num,den,1}, -M}, skipTrivial=true);
	  end

     function Fc=outputDelayDefaultNormalizedFc(~)
        % Return the (normalized) frequency for which group delay is evaluated in
        % outputDelay. 
        Fc = 0; % For most objects (except highpass or bandpass).
     end

     function [FsIn, Fc, tol, N, DefaultFc] = parseOutputDelayArguments(obj,varargin)
        p = inputParser;

        addParameter(p,'FsIn', obj.inputSampleRate()); 

        % Narrowband mode parameters
        addParameter(p,'FFTLength', 8192, @isnumeric);
        addParameter(p,'Tol', 0.05, @isnumeric); % Group delay tolerance ±5%
        addParameter(p,'Fc', obj.outputDelayDefaultNormalizedFc()); % Carrier frequency

        parse(p, varargin{:});

        N    = p.Results.FFTLength;
        tol  = p.Results.Tol;
        Fc   = p.Results.Fc;
        FsIn = p.Results.FsIn;

        DefaultFc = any(strcmpi(p.UsingDefaults,'Fc'));

        validateattributes(FsIn,'numeric',{'scalar','real','positive'},'outputDelay','FsIn');
        validateattributes(Fc,'numeric',{'scalar','real'},'outputDelay','Fc');
        validateattributes(N,'numeric',{'scalar','real','positive','integer'},'outputDelay','FFTLength');
        validateattributes(tol,'numeric',{'scalar','real','nonnegative'},'outputDelay','Tol');

        % Force all types to be double (to be compatible with grpdelay)
        FsIn = double(FsIn);
        Fc   = double(Fc);
        tol  = double(tol);
        N    = double(N);

        % If Fc is unspecified, scale the default normalized frequency 
        % relatively to FsIn.
        if DefaultFc 
            Fc = Fc*FsIn/2;
        end
    end

    function setFdesign(obj,fd)
      if ~isempty(fd) && ~isa(fd,'fdesign.abstracttype')
        error(message('dsp:dsp:private:FilterSystemObjectBase:InvalidInput', 'fdesign'))
      end
      obj.pFdesign = fd;
      obj.pMeasurements = []; % clear any measurements
    end
    
    function setFmethod(obj,fm)
      if ~isempty(fm) && ~isa(fm,'fmethod.abstractdesign')
        error(message('dsp:dsp:private:FilterSystemObjectBase:InvalidInput', 'fmethod'))
      end
      obj.pFmethod = fm;
      obj.pMeasurements = []; % clear any measurements
    end
    
    function sendNoAvailableCoefficientsError(~,coeffSourcePropName)
      error(message('dsp:dsp:private:FilterSystemObjectBase:InvalidCoeffSource', coeffSourcePropName))
    end
    
    
    function coeffNumericType = getCoefficientsDataType(obj,type,coeffDataTypePropName)
      warnFlag = false;
      if isLocked(obj) && strcmpi(obj.pLockedArithmetic,'fixed')
        coeffNumericType = numerictype(true,obj.pInputWordLength);
      elseif isLocked(obj) && ~strcmpi(obj.pLockedArithmetic,'fixed')
        warnFlag = true;
        id = 'dsp:dsp:private:FilterSystemObjectBase:DefaultCoeffDataTypeLocked';          
      else
        warnFlag = true;
        id = 'dsp:dsp:private:FilterSystemObjectBase:DefaultCoeffDataType';
      end      
      if warnFlag
        if strcmpi(type,'sos')
          id = [id 'SOS'];
        elseif any(strcmpi({'fir','iir','ar'},type))
          id = [id 'FIR'];
        end
        warning(message(id,coeffDataTypePropName));
        coeffNumericType = numerictype(true,16);
      end        
    end
        
    function [d, inputsCell] = parseArithmetic(obj,inputsCell,forceToDouble,noDfilt)      
      % Parse arithmetic input
      % Inputs:
      %
      % inputsCell    - cell containing PV-pairs. The method will look for
      %                 the 'Arithmetic' input, parse its value and delete
      %                 the PV-pair from the cell. It will return the 
      %                 modified cell in the second output, inputsCell.
      % forceToDouble - If true, force arithmetic to 'double' regardless of
      %                 the 'Arithmetic' input
      % noDfilt       - If true, do not generate a dfilt object from the 
      %                 System object and return the parsed arithmetic 
      %                 string instead of the dfilt object in the first 
      %                 output, d.
      
      % Convert string inputs to char inputs
      [inputsCell{:}] = convertStringsToChars(inputsCell{:});

      idx = [];      
      if nargin > 1
        idx = find(strcmpi(inputsCell,'arithmetic'));
      end
      
      forceToDoubleFlag = nargin > 2 && forceToDouble;
            
      if ~isempty(idx)
        idx = idx(1);
        if (length(inputsCell)>= idx+1 &&...
            ~any(strcmpi({'double','single','fixed'},inputsCell{idx+1})))...
            || length(inputsCell)< idx+1
          error(message(...
            'dsp:dsp:private:FilterSystemObjectBase:InvalidArithmeticInput'))
        end
        
        arith = inputsCell{idx+1};
        if strcmpi(arith, 'fixed') && ~isfixptinstalled
          error(message('dsp:dsp:private:FilterSystemObjectBase:NoFixedPointTbx'))
        end
        inputsCell([idx idx+1]) = [];
      else
        if isLocked(obj)
          arith = obj.pLockedArithmetic;
        else
          arith = 'double';        
        end
      end
      
      if forceToDoubleFlag
        arith = 'double';
      end
      
      noDfiltFlag = false;
      if nargin > 3 && noDfilt
        noDfiltFlag = noDfilt;
      end
      
      % Convert System object to dfilt using the parsed arithmetic
      if noDfiltFlag
        % If no dfilt is requested then we return the parsed arithmetic
        % value
        d = arith;
      else
        d = todfilt(obj,arith);
      end
    end
    
    function cacheInputDataType(obj,inputData)
      dataClass = lower(class(inputData));            
      switch dataClass
        case {'double','single'}
          obj.pLockedArithmetic = dataClass;
        case {'int8','int16','int32','int64',...
            'uint8','uint16','uint32','uint64'}
          nt = numerictype(dataClass);
          obj.pInputWordLength = nt.WordLength;
          obj.pInputFractionLength = nt.FractionLength;
          obj.pInputSignedness = nt.Signedness;
          obj.pLockedArithmetic = 'fixed';          
        case 'embedded.fi'
          nt = numerictype(inputData);
          obj.pInputWordLength = nt.WordLength;
          obj.pInputFractionLength = nt.FractionLength;
          obj.pInputSignedness = nt.Signedness;
          obj.pLockedArithmetic = 'fixed';            
      end
    end
    
    function flag = isNLMSupported(obj,arith)
      flag = true;
      if strcmpi(arith,'fixed')
        if ~isLocked(obj) || (isLocked(obj) && ~strcmpi(obj.pLockedArithmetic,'fixed'))
            flag = false;
        end        
      end 
    end
               
    function checkIfNLMSupportedAndSendError(obj,arith,methodName)  
      if ~isNLMSupported(obj,arith)
            error(message(...
              'dsp:dsp:private:FilterSystemObjectBase:NLMethodsNotSupported',...
              methodName));              
      end        
    end
    
    %----------------------------------------------------------------------
    function varargout = infoFA(obj,varargin)
    %INFO   Information about filter System object
    %   S = info(filt) returns a string matrix with information about the
    %   filter System object, filt.
    %
    %   S = info(filt,'Arithmetic',ARITH) assumes the filter arithmetic
    %   specified in the ARITH input. The ARITH input can be one of
    %   'double', 'single' or 'fixed'. The info method assumes that filt is a
    %   double precision filter when the arithmetic input is not specified
    %   and the filter System object is in an unlocked state.
    %
    %   An optional string argument, 'long' or 'short' can be passed to
    %   format the contents of info. The default value is 'short'.
    %
    %   S = info(filt,...,'long') returns detailed information about the
    %   filter that includes the design method, options, specifications,
    %   measurements and implementation cost.
    %
    %   S = info(filt,...,'short') returns the brief information about filter.
      
      [d, varargin] = parseArithmetic(obj, varargin);
      if nargout == 1
        varargout{1} = info(d,varargin{:});
      else
        info(d,varargin{:});
      end
    end 
    %----------------------------------------------------------------------
    function s = saveFA(obj, s)
        s.pFdesign = obj.pFdesign;
        s.pFmethod = obj.pFmethod;
        s.pMeasurements = obj.pMeasurements;
        s.pDesignMethod = obj.pDesignMethod;
        if isLocked(obj)
            s.pLockedArithmetic = obj.pLockedArithmetic;
            s.pInputWordLength = obj.pInputWordLength;
            s.pInputFractionLength = obj.pInputFractionLength;
            s.pInputSignedness = obj.pInputSignedness;
        end
    end
    %----------------------------------------------------------------------
    function loadFA(obj, s, wasLocked)
        if isfield(s, 'pFdesign')
            obj.pFdesign = s.pFdesign;
            obj.pFmethod = s.pFmethod;
            obj.pMeasurements = s.pMeasurements;
            obj.pDesignMethod = s.pDesignMethod;
            if wasLocked
                obj.pLockedArithmetic = s.pLockedArithmetic;
                obj.pInputWordLength = s.pInputWordLength;
                obj.pInputFractionLength = s.pInputFractionLength;
                obj.pInputSignedness = s.pInputSignedness;
            end
        end
    end
  end
  
  %------------------------------------------------------------------------
  %------------------------------------------------------------------------
  %                     Filter analysis methods
  %------------------------------------------------------------------------
  %------------------------------------------------------------------------
  methods
    function [Hr, W] = freqz(obj,varargin)
    %FREQZ  Frequency response of discrete-time filter System object
    %   [Hr,W] = freqz(filt,N) returns the N-point complex frequency response
    %   vector Hr and the N-point frequency vector W in radians/sample of
    %   the filter System object filt. The frequency response is evaluated at
    %   N points equally spaced around the upper half of the unit circle.
    %   If N is not specified, it defaults to 8192.
    %
    %   [Hr,W] = freqz(filt,'Arithmetic',ARITH,...) analyzes the filter System
    %   object, filt, based on the arithmetic specified in the ARITH input.
    %   ARITH can be set to one of 'double', 'single', or 'fixed'. The
    %   analysis tool assumes a double precision filter when the arithmetic
    %   input is not specified and the filter System object is in an
    %   unlocked state.
    %
    %   freqz(filt) with no output argument launches FVTool and shows the
    %   magnitude and phase responses of the filter System object, filt.
    %
    %   For additional parameters, see signal/freqz.
      
      [d, varargin] = parseArithmetic(obj, varargin);
      if nargout > 0
        [Hr, W] = freqz(d,varargin{:});
      else
        freqz(d,varargin{:})
      end
    end
    %----------------------------------------------------------------------
    function [Phi, W] = phasez(obj,varargin)
    %PHASEZ Phase response of discrete-time filter System object (unwrapped)
    %   [Phi,W] = phasez(filt,N) returns vectors Phi and W containing the
    %   phase response of the filter System object, filt, and the frequencies
    %   (in radians) at which it is evaluated. The phase response is
    %   evaluated at N points equally spaced around the upper half of the
    %   unit circle. If you do not specify N, it defaults to 8192.
    %
    %   [Phi,W] = phasez(filt,'Arithmetic',ARITH,...) analyzes the filter
    %   System object, filt, based on the arithmetic specified in the ARITH
    %   input. ARITH can be set to one of 'double', 'single', or 'fixed'.
    %   The analysis tool assumes a double precision filter when the
    %   arithmetic input is not specified and the filter System object is
    %   in an unlocked state.
    %
    %   phasez(filt) with no output argument launches FVTool and shows the
    %   phase response of the filter System object, filt.
    %
    %   For additional parameters, see signal/phasez.
      
      [d, varargin] = parseArithmetic(obj, varargin);
      if nargout > 0
        [Phi, W] = phasez(d,varargin{:});
      else
        phasez(d,varargin{:})
      end
    end
    %----------------------------------------------------------------------
    function [Hr, W] = zerophase(obj,varargin)
    %ZEROPHASE Zero-phase response of discrete-time filter System object
    %   [Hr,W] = zerophase(filt,N) returns length N vectors Hr and W
    %   containing the zero-phase response of the filter System object filt,
    %   and the frequencies (in radians) at which it is evaluated. The
    %   zero-phase response is evaluated at N points equally spaced around
    %   the upper half of the unit circle. For an FIR filter where N is a
    %   power of two, the computation is done faster using FFTs. If you
    %   don't specify N, it defaults to 8192.
    %
    %   [Hr,W] = zerophase(filt,'Arithmetic',ARITH,...) analyzes the filter
    %   System object, filt, based on the arithmetic specified in the ARITH
    %   input. ARITH can be set to one of 'double', 'single', or 'fixed'.
    %   The analysis tool assumes a double precision filter when the
    %   arithmetic input is not specified and the filter System object is
    %   in an unlocked state.
    %
    %   zerophase(filt) with no output argument launches FVTool and shows the
    %   zero-phase response of the filter System object, filt.
    %
    %   For additional parameters, see signal/zerophase.
      
      [d, varargin] = parseArithmetic(obj, varargin);      
      if nargout > 0
        [Hr, W] = zerophase(d,varargin{:});
      else
        zerophase(d,varargin{:})
      end
    end    
    %----------------------------------------------------------------------
    function [Gd, W] = grpdelay(obj,varargin)
    %GRPDELAY Group delay response of discrete-time filter System object
    %   [Gd,W] = grpdelay(filt,N) returns length N vectors Gd and W containing
    %   the group delay of the filter System object, filt, and the frequencies
    %   (in radians) at which it is evaluated. The group delay is defined
    %   as -d{angle(w)}/dw. The frequency response is evaluated at N points
    %   equally spaced around the upper half of the unit circle. For an FIR
    %   filter where N is a power of two, the computation is done faster
    %   using FFTs. If you do not specify N, it defaults to 8192.
    %
    %   [Gd,W] = grpdelay(filt,'Arithmetic',ARITH,...) analyzes the filter
    %   System object, filt, based on the arithmetic specified in the ARITH
    %   input. ARITH can be set to one of 'double', 'single', or 'fixed'.
    %   The analysis tool assumes a double precision filter when the
    %   arithmetic input is not specified and the filter System object is
    %   in an unlocked state.
    %
    %   grpdelay(filt) with no output argument launches FVTool and shows the
    %   group delay response of the filter System object, filt.
    %
    %   For additional parameters, see signal/grpdelay.
      
      [d, varargin] = parseArithmetic(obj, varargin);
      if nargout > 0
        [Gd, W] = grpdelay(d,varargin{:});
      else
        grpdelay(d,varargin{:})
      end
    end
    %----------------------------------------------------------------------
    function [Phi, W] = phasedelay(obj,varargin)
    %PHASEDELAY Phase delay response of discrete-time filter System object
    %   [PHI,W] = phasedelay(filt,N) returns the N-point phase delay response
    %   vector PHI and the N-point frequency vector W in radians/sample of
    %   the filter System object, filt. The phase response is evaluated at N
    %   points equally spaced around the upper half of the unit circle. If
    %   N is not specified, it defaults to 8192.
    %
    %   [Phi,W] = phasedelay(filt,'Arithmetic',ARITH,...) analyzes the filter
    %   System object, filt, based on the arithmetic specified in the ARITH
    %   input. ARITH can be set to one of 'double', 'single', or 'fixed'.
    %   The analysis tool assumes a double precision filter when the
    %   arithmetic input is not specified and the filter System object is
    %   in an unlocked state.
    %
    %   phasedelay(filt) with no output argument launches FVTool and shows the
    %   phase delay response of the filter System object, filt.
    %
    %   For additional parameters, see signal/phasedelay.
      
      [d, varargin] = parseArithmetic(obj, varargin);
      if nargout > 0
        [Phi, W] = phasedelay(d,varargin{:});
      else
        phasedelay(d,varargin{:})
      end
    end
    %----------------------------------------------------------------------
    function [Hr, T] = impz(obj,varargin)
    %IMPZ   Impulse response of discrete-time filter System object
    %   [Hr,T] = impz(filt) computes the impulse response of the filter System
    %   object, filt, and returns the response in column vector Hr, and a
    %   vector of times (or sample intervals) in T (T = [0 1 2...]'). The
    %   number of samples in the response is chosen automatically.
    %
    %   [Hr,T] = impz(filt,'Arithmetic',ARITH,...) analyzes the filter System
    %   object, filt, based on the arithmetic specified in the ARITH input.
    %   ARITH can be set to one of 'double', 'single', or 'fixed'. The
    %   analysis tool assumes a double precision filter when the arithmetic
    %   input is not specified and the filter System object is in an
    %   unlocked state.
    %
    %   impz(filt) with no output argument launches FVTool and shows the
    %   impulse response of the filter System object, filt.
    %
    %   For additional parameters, see signal/impz.
    
      [d, varargin] = parseArithmetic(obj, varargin);
      if nargout > 0
        [Hr, T] = impz(d,varargin{:});
      else
        impz(d,varargin{:})
      end
    end
    %----------------------------------------------------------------------
    function L = impzlength(obj,varargin)
    %IMPZLENGTH Length of impulse response of discrete-time filter System object
    %   L = impzlength(filt) returns the length, L, of the impulse response of
    %   the filter System object, filt.
    %
    %   L = impzlength(filt,TOL) specifies the tolerance, TOL, to increase or
    %   decrease the length accuracy. By default, TOL = 5e-5.
    %
    %   L = impzlength(filt,'Arithmetic',ARITH,...) analyzes the filter System
    %   object, filt, based on the arithmetic specified in the ARITH input.
    %   ARITH can be set to one of 'double', 'single', or 'fixed'. The
    %   analysis tool assumes a double precision filter when the arithmetic
    %   input is not specified and the filter System object is in an
    %   unlocked state.

      [d, varargin] = parseArithmetic(obj, varargin);
      L = impzlength(d,varargin{:});    
    end
    %----------------------------------------------------------------------
    function [Hr, T] = stepz(obj,varargin)
    %STEPZ Step response of discrete-time filter System object
    %   [Hr,T] = stepz(filt) returns the step response Hr of the filter System
    %   object, filt. The length of column vector filt is computed using
    %   IMPZLENGTH. The vector of time samples at which filt is evaluated is
    %   returned in vector T.
    %
    %   [Hr,T] = impz(filt,'Arithmetic',ARITH,...) analyzes the filter System
    %   object, filt, based on the arithmetic specified in the ARITH input.
    %   ARITH can be set to one of 'double', 'single', or 'fixed'. The
    %   analysis tool assumes a double precision filter when the arithmetic
    %   input is not specified and the filter System object is in an
    %   unlocked state.
    %
    %   stepz(filt) with no output argument launches FVTool and shows the step
    %   response of the filter System object, filt.
    %
    %   For additional parameters, see signal/stepz.
    
      [d, varargin] = parseArithmetic(obj, varargin);
      if nargout > 0
        [Hr, T] = stepz(d,varargin{:});
      else
        stepz(d,varargin{:})
      end
    end      
    %----------------------------------------------------------------------
    function [HZ,HP,Hl] = zplane(obj,varargin)  
    %ZPLANE Z-plane zero-pole plot for discrete-time filter System object
    %   zplane(filt) plots the zeros and poles of the filter System object, filt,
    %   with the unit circle for reference in the Filter Visualization Tool
    %   (FVTool). Each zero is represented with a 'o' and each pole with a
    %   'x' on the plot. Multiple zeros and poles are indicated by the
    %   multiplicity number shown to the upper right of the zero or pole.
    %
    %   zplane(filt,'Arithmetic',ARITH,...) analyzes the filter System object,
    %   filt, based on the arithmetic specified in the ARITH input. ARITH can
    %   be set to one of 'double', 'single', or 'fixed'. The analysis tool
    %   assumes a double precision filter when the arithmetic input is not
    %   specified and the filter System object is in an unlocked state.
    %
    %   [Z, P, k] = zplane(filt)  returns the zeros, poles, and gain of
    %   filt.
    %
    %   For additional parameters, see signal/zplane.
    
      [d, varargin] = parseArithmetic(obj, varargin);
      if nargout > 0
       [HZ,HP,Hl] = zplane(d,varargin{:});
      else
        zplane(d,varargin{:})
      end
    end            
    %----------------------------------------------------------------------
    function c = cost(obj,varargin)  
    %COST   Cost estimate for implementation of filter System object
    %   C = cost(filt) return a cost estimate C for the filter System object,
    %   filt. The cost estimate contains the following fields:
    %   NumCoefficients               : Number of filter coefficients
    %                                   (excluding coefficients with
    %                                   values 0, 1 or -1)
    %   NumStates                     : Number of states
    %   MultiplicationsPerInputSample : Number of multiplications per
    %                                   input sample
    %   AdditionsPerInputSample       : Number of additions per
    %                                   input sample
    %
    %   C = cost(filt,'Arithmetic',ARITH,...) analyzes the filter System
    %   object, filt, based on the arithmetic specified in the ARITH input.
    %   ARITH can be set to one of 'double', 'single', or 'fixed'. The
    %   analysis tool assumes a double precision filter when the arithmetic
    %   input is not specified and the filter System object is in an
    %   unlocked state.
    
      [d, varargin] = parseArithmetic(obj, varargin);
      cst = cost(d,varargin{:});
      
      c.NumCoefficients = cst.NMult;
      c.NumStates = cst.NStates;
      c.MultiplicationsPerInputSample = cst.MultPerInputSample;
      c.AdditionsPerInputSample = cst.AddPerInputSample;
    end
   %----------------------------------------------------------------------
    function m = measure(obj,varargin)
    %MEASURE  Measure frequency response characteristics of filter System object
    %   measure(filt) displays measurements of various quantities from the
    %   frequency response of the filter System object, filt. Values that are
    %   measured can include the actual passband ripple, the minimum
    %   stopband attenuation, the frequency point at which the filter's
    %   gain is 3 dB below the nominal passband gain, etc. In order for
    %   measure to work, the filter filt needs to be designed using FDESIGN.
    %
    %   M = measure(filt) returns the measurements, M, such that they can be
    %   queried programmatically. For example, to query the 3 dB point, one
    %   would type M.F3dB. Type GET(M) to see the full list of properties
    %   that can be queried. Note that different filter responses will
    %   generate different measurements.
    %
    %   M = measure(filt,'Arithmetic',ARITH,...) analyzes the filter System
    %   object, filt, based on the arithmetic specified in the ARITH input.
    %   ARITH can be set to one of 'double', 'single', or 'fixed'. The
    %   analysis tool assumes a double precision filter when the arithmetic
    %   input is not specified and the filter System object is in an
    %   unlocked state.
    %  
    %   For designs that do not specify some of the frequency constraints,
    %   it may not be possible to determine corresponding magnitude
    %   measurements. In these cases, a frequency value can be passed in to
    %   measure in order to determine the magnitude measurements that
    %   corresponds to such value.
    %
    %   %   Example #1: Measure an equiripple FIR design of a bandpass filter
    %   f = fdesign.bandpass('Fst1,Fp1,Fp2,Fst2,Ast1,Ap,Ast2',0.3,0.4,0.6,0.7,80,1,75);
    %   filt = design(f,'equiripple','SystemObject',true);
    %   measure(filt)
    %  
    %   % Example #2: Specify the passband frequency of the filter
    %   f = fdesign.lowpass('N,F3dB,Ast',8,0.5,80);
    %   filt = design(f,'cheby2','SystemObject',true);
    %   measure(filt,'Fpass',0.4)    
         
      [d, varargin] = parseArithmetic(obj, varargin);
      m = measure(d,varargin{:});      
    end
   %----------------------------------------------------------------------
    function N = order(obj,varargin)      
    %ORDER  Order of discrete-time filter System object
    %   N = order(filt) returns the order, N, of the filter System object, filt.
    %   The order depends on the filter structure and the reference
    %   double-precision floating-point coefficients.
    
      % This analysis is insensitive to the filter arithmetic. Parse the
      % arithmetic just to get rid of a possible arithmetic input. We do
      % not prevent users from passing the arithmetic input for consistency
      % of all the analysis methods.
      [d, varargin] = parseArithmetic(obj, varargin, true);      
      N = order(d,varargin{:});        
    end   
   %----------------------------------------------------------------------
    function s = coeffs(obj,varargin)    
    %COEFFS Returns the filter System object coefficients in a structure
    %   S = coeffs(filt) Returns the coefficients of filter System object, filt,
    %   in the structure S.
    %
    %   S = coeffs(filt,'Arithmetic',ARITH,...) analyzes the filter System
    %   object, filt, based on the arithmetic specified in the ARITH input.
    %   ARITH can be set to one of 'double', 'single', or 'fixed'. The
    %   analysis tool assumes a double precision filter when the arithmetic
    %   input is not specified and the filter System object is in an
    %   unlocked state. The coeffs method returns the quantized filter
    %   coefficients when ARITH is set to 'single' or 'fixed'.
    
     [d, varargin] = parseArithmetic(obj, varargin);
     s = coeffs(d,varargin{:});                   
    end    
    %----------------------------------------------------------------------
    function t = firtype(obj,varargin)      
    %FIRTYPE Determine the type (1-4) of a linear phase FIR filter System object
    %   T = firtype(filt) determines the type (1 through 4) of the FIR filter
    %   System object filt. The filter must be real and have linear phase.
    %
    %   Types 1 through 4 are defined as follows:
    %       
    %   Type 1: Even order symmetric coefficients.
    %   Type 2: Odd order symmetric coefficients.
    %   Type 3: Even order antisymmetric coefficients.
    %   Type 4: Odd order antisymmetric coefficients.
     
      % This analysis is insensitive to the filter arithmetic. Parse the
      % arithmetic just to get rid of a possible arithmetic input. We do
      % not prevent users from passing the arithmetic input for consistency
      % of all the analysis methods. 
      [d, varargin] = parseArithmetic(obj, varargin, true);
      t = firtype(d,varargin{:});        
    end   
    %----------------------------------------------------------------------
    function [b,a] = tf(obj,varargin)      
    %TF Convert discrete-time filter System object to transfer function
    %   [NUM,DEN] = tf(filt) converts discrete-time filter System object, filt,
    %   to numerator and denominator vectors.
    %
    %   [NUM,DEN] = tf(filt,'Arithmetic',ARITH) analyzes the filter System
    %   object, filt, based on the arithmetic specified in the ARITH input.
    %   ARITH can be set to one of 'double', 'single', or 'fixed'. The
    %   analysis tool assumes a double precision filter when the arithmetic
    %   input is not specified and the filter System object is in an
    %   unlocked state.
    
      [d, varargin] = parseArithmetic(obj, varargin);
      [b,a] = tf(d,varargin{:});                
    end
    %----------------------------------------------------------------------
    function [z,p,k] = zpk(obj,varargin)      
    %ZPK Zero-pole-gain conversion of discrete-time filter System object
    %   [Z,P,K] = zpk(filt) returns the zeros, poles, and gain corresponding
    %   to the filter System object, filt, in vectors Z, P, and scalar K
    %   respectively.
    %
    %   [Z,P,K] = zpk(filt,'Arithmetic',ARITH) analyzes the filter System
    %   object, filt, based on the arithmetic specified in the ARITH input.
    %   ARITH can be set to one of 'double', 'single', or 'fixed'. The
    %   analysis tool assumes a double precision filter when the arithmetic
    %   input is not specified and the filter System object is in an
    %   unlocked state.
    
      [d, varargin] = parseArithmetic(obj, varargin);
      [z,p,k] = zpk(d,varargin{:});   
    end
    %----------------------------------------------------------------------
    function [A,B,C,D] = ss(obj,varargin)    
    %SS     Convert discrete-time filter System object to state-space representation
    %   [A,B,C,D] = ss(filt) converts filter System object, filt, to
    %   state-space representation given by:    
    %   x(k+1) = A*x(k) + B*u(k)
    %   y(k)   = C*x(k) + D*u(k)
    %   where x is the state vector, u is the input vector, and y is the 
    %   output vector. 
    %
    %   [A,B,C,D] = ss(filt,'Arithmetic',ARITH) analyzes the filter System
    %   object, filt, based on the arithmetic specified in the ARITH input.
    %   ARITH can be set to one of 'double', 'single', or 'fixed'. The
    %   analysis tool assumes a double precision filter when the arithmetic
    %   input is not specified and the filter System object is in an
    %   unlocked state.
    
      [d, varargin] = parseArithmetic(obj, varargin);
      [A,B,C,D] = ss(d,varargin{:});             
    end
    %----------------------------------------------------------------------
    function flag = isallpass(obj,varargin)
    %ISALLPASS Verify that discrete-time filter System object is allpass
    %   FLAG = isallpass(filt) returns true if filter System object, filt, is
    %   all-pass.
    % 
    %   FLAG = isallpass(filt,TOL) uses tolerance TOL to determine when two
    %   numbers are close enough to be considered equal.
    %
    %   FLAG = isallpass(filt,'Arithmetic',ARITH,...) analyzes the filter
    %   System object, filt, based on the arithmetic specified in the ARITH
    %   input. ARITH can be set to one of 'double', 'single', or 'fixed'.
    %   The analysis tool assumes a double precision filter when the
    %   arithmetic input is not specified and the filter System object is
    %   in an unlocked state.
    
      [d, varargin] = parseArithmetic(obj, varargin);
      flag = isallpass(d,varargin{:});                 
    end  
    %----------------------------------------------------------------------
    function flag = islinphase(obj,varargin)
    %ISLINPHASE Verify that discrete-time filter System object is linear phase
    %   FLAG = islinphase(filt) returns true if filter System object, filt, is
    %   linear phase.
    %
    %   FLAG = islinphase(filt,TOL) uses tolerance TOL to determine when two
    %   numbers are close enough to be considered equal.
    %
    %   FLAG = islinphase(filt,'Arithmetic',ARITH,...) analyzes the filter
    %   System object, filt, based on the arithmetic specified in the ARITH
    %   input. ARITH can be set to one of 'double', 'single', or 'fixed'.
    %   The analysis tool assumes a double precision filter when the
    %   arithmetic input is not specified and the filter System object is
    %   in an unlocked state.
    
      [d, varargin] = parseArithmetic(obj, varargin);
      flag = islinphase(d,varargin{:});                         
    end        
    %----------------------------------------------------------------------
    function flag = ismaxphase(obj,varargin)
    %ISMAXPHASE Verify that discrete-time filter System object is maximum phase
    %   FLAG = ismaxphase(filt) returns true if filter System object, filt, is
    %   maximum phase.
    %
    %   FLAG = ismaxphase(filt,TOL) uses tolerance TOL to determine when two
    %   numbers are close enough to be considered equal.
    %
    %   FLAG = ismaxphase(filt,'Arithmetic',ARITH,...) analyzes the filter
    %   System object, filt, based on the arithmetic specified in the ARITH
    %   input. ARITH can be set to one of 'double', 'single', or 'fixed'.
    %   The analysis tool assumes a double precision filter when the
    %   arithmetic input is not specified and the filter System object is
    %   in an unlocked state.
    
      [d, varargin] = parseArithmetic(obj, varargin);
      flag = ismaxphase(d,varargin{:});                                 
    end        
    %----------------------------------------------------------------------
    function flag = isminphase(obj,varargin)
    %ISMINPHASE Verify that discrete-time filter System object is minimum phase
    %   FLAG = isminphase(filt) returns true if filter System object, filt, is
    %   maximum phase.
    %
    %   FLAG = isminphase(filt,TOL) uses tolerance TOL to determine when two
    %   numbers are close enough to be considered equal.
    %
    %   FLAG = isminphase(filt,'Arithmetic',ARITH,...) analyzes the filter
    %   System object, filt, based on the arithmetic specified in the ARITH
    %   input. ARITH can be set to one of 'double', 'single', or 'fixed'.
    %   The analysis tool assumes a double precision filter when the
    %   arithmetic input is not specified and the filter System object is
    %   in an unlocked state.
    
      [d, varargin] = parseArithmetic(obj, varargin);
      flag = isminphase(d,varargin{:});                                 
    end        
    %----------------------------------------------------------------------
    function flag = isreal(obj,varargin)
    %ISREAL Verify that discrete-time filter System object is real
    %   FLAG = isreal(filt) returns true if filter System object, filt, has real
    %   coefficients.
    
     [d, varargin] = parseArithmetic(obj, varargin, true);
     flag = isreal(d,varargin{:});     
    end
    %----------------------------------------------------------------------
    function flag = isstable(obj,varargin)
    %ISSTABLE Verify that discrete-time filter System object is stable
    %   FLAG = isstable(filt) returns true if filter System object, filt, is
    %   stable.
    %
    %   FLAG = isstable(filt,'Arithmetic',ARITH,...) analyzes the filter
    %   System object, filt, based on the arithmetic specified in the ARITH
    %   input. ARITH can be set to one of 'double', 'single', or 'fixed'.
    %   The analysis tool assumes a double precision filter when the
    %   arithmetic input is not specified and the filter System object is
    %   in an unlocked state.
    
     [d, varargin] = parseArithmetic(obj, varargin);
     flag = isstable(d,varargin{:});           
    end
    %----------------------------------------------------------------------
    function flag = isfir(obj,varargin)
    %ISFIR  Verify if discrete-time System object filter is FIR
    %   FLAG = isfir(filt) returns true if filter System object, filt, is FIR.
    
     [d, varargin] = parseArithmetic(obj, varargin, true);
     flag = isfir(d,varargin{:});           
      
    end
    %----------------------------------------------------------------------
    function flag = issos(obj,varargin)
    %ISSOS  Verify if discrete-time System object filter is in second-order sections form
    %   FLAG = issos(filt) returns true if filter System object, filt, is in
    %   second-order sections form.
    
     [d, varargin] = parseArithmetic(obj, varargin, true);
     flag = issos(d,varargin{:});                 
    end    
    %----------------------------------------------------------------------
    function realizemdl(obj,varargin)
    %REALIZEMDL Filter realization (Simulink diagram)
    %   realizemdl(filt) automatically generates architecture model of filter
    %   System object, filt, in a Simulink subsystem block using individual
    %   sum, gain, and delay blocks, according to user-defined
    %   specifications.
    %    
    %   realizemdl(filt,'Arithmetic',ARITH,...) analyzes the filter System
    %   object, filt, based on the arithmetic specified in the ARITH input.
    %   ARITH can be set to one of 'double' or 'single'. The analysis tool
    %   assumes a double precision filter when the arithmetic input is not
    %   specified. The realizemdl method for filter System objects does not
    %   support fixed-point arithmetic. 
    %
    %   realizemdl(filt, PARAMETER1, VALUE1, PARAMETER2, VALUE2, ...)
    %   generates the model with parameter/value pairs. Valid properties
    %   and values for realizemdl are listed in this table, with the
    %   default value noted and descriptions of what the properties do.
    %
    %     -------------       ---------------      ----------------------------
    %     Property Name       Property Values      Description
    %     -------------       ---------------      ----------------------------
    %     Destination         [{'current'}         Specify whether to add the block
    %                          'new'               to your current Simulink model,
    %                          <user defined>]     create a new model to contain the
    %                                              block, or specify the name of the
    %                                              target subsystem.
    %
    %     Blockname           {'filter'}           Provides the name for the new
    %                                              subsystem block. By default the
    %                                              block is named 'filter'.
    %
    %     OverwriteBlock      ['on' {'off'}]       Specify whether to overwrite an
    %                                              existing block with the same name
    %                                              as specified by the Blockname
    %                                              property or create a new block.
    %
    %     OptimizeZeros       [{'on'} 'off']       Specify whether to remove zero-gain
    %                                              blocks.
    %
    %     OptimizeOnes        [{'on'} 'off']       Specify whether to replace unity-gain
    %                                              blocks with direct connections.
    %
    %     OptimizeNegOnes     [{'on'} 'off']       Specify whether to replace negative
    %                                              unity-gain blocks with a sign
    %                                              change at the nearest sum block.
    %
    %     OptimizeDelayChains [{'on'} 'off']       Specify whether to replace cascaded
    %                                              chains of delay blocks with a
    %                                              single integer delay block to
    %                                              provide an equivalent delay.
    %
    %     MapStates           ['on' {'off'}]       Specify whether to map the States
    %                                              of the filter as initial conditions
    %                                              of the block.
    %
    %     MapCoeffsToPorts    ['on' {'off'}]       Specify whether to map the
    %                                              coefficients of the filter
    %                                              to the ports of the block.
    %
    %     CoeffNames          {'Num'}              Specify the coefficient
    %                                              variables names. MapCoeffsToPorts
    %                                              must be 'on' for this property
    %                                              to apply.
    %
    %     InputProcessing   [{'columnsaschannels'} Specify sample-based
    %                        'elementsaschannels'] ('elementsaschannels') vs.
    %                                              frame-based ('columnsaschannels')
    %                                              processing.
    %
    %     RateOption(*)      [{'enforcesinglerate'} Specify how the block adjusts
    %                       'allowmultirate']      the rate at the output to accommodate
    %                                              the reduced number of samples.
    %                                              Apply only to multirate blocks
    %                                              when InputProcessing is set to
    %                                              'columnsaschannels'.
    
      % When the fourth input argument to parseArithmetic is true, then
      % first output is the arithmetic string instead of a dfilt object
      [arith, varargin] = parseArithmetic(obj, varargin,false,true);
      if strcmpi(arith,'fixed')
        error(message(...
          'dsp:dsp:private:FilterSystemObjectBase:InvalidArithRealizeMdl'));
      end
      d = todfilt(obj,arith);
      realizemdl(d,varargin{:});    
    end

    %----------------------------------------------------------------------    
    function [Hr, W] = freqrespest(obj,varargin)
    %FREQRESPEST  Frequency response estimate via filtering
    %   [Hr,W] = freqrespest(filt,L) computes the frequency response estimate
    %   of the filter System object filt by running input data made up from
    %   sinusoids with uniformly distributed random frequencies through
    %   the filter and forming the ratio between output data and input
    %   data. This is particularly useful for fixed-point filters, a
    %   frequency response estimate that is close to the frequency response
    %   obtained by using only the quantized coefficients but ignoring the
    %   fixed-point additions/multiplications is a good indication that the
    %   filter's fixed-point performance closely matches a floating point
    %   implementation with the same (quantized) coefficients.
    %
    %   L is the number of trials used to compute the estimate. If not
    %   specified, L defaults to 10. In general, the more trials used, the
    %   more accurate estimate obtained at the expense of a longer time
    %   needed to compute the estimate.
    %
    %   Hr is the estimate of the complex frequency response. W is a vector
    %   of frequencies at which filt is estimated.
    %
    %   [Hr,W] = freqrespest(filt,L,P1,V1,P2,V2,...) specifies optional
    %   parameters via parameter-value pairs. Valid pairs are:
    %
    %         Parameter           Default        Description/Valid values
    %   ---------------------  -----------  ----------------------------------
    %    'NFFT'                 512          Number of FFT points.
    %    'NormalizedFrequency'  true         {true,false}
    %    'Fs'                   'Normalized' Sampling frequency. Only used when
    %                                        'NormalizedFrequency' is false.
    %    'SpectrumRange'        'Half'       {'Half','Whole'}
    %    'CenterDC'             false        {true,false}
    %
    %   [Hr, W] = freqrespest(filt,L,OPTS) uses an options object to specify
    %   the optional parameters in lieu of specifying parameter-value
    %   pairs. The OPTS object can be created with OPTS = freqrespopts(filt).
    %   Settings can be changed in OPTS before calling freqrespest, e.g.
    %   set(OPTS,'Fs',48e3);
    %   
    %   [Hr,W] = freqrespest(filt,'Arithmetic',ARITH,...) analyzes the filter
    %   System object, filt, based on the arithmetic specified in the ARITH
    %   input. ARITH can be set to one of 'double', 'single', or 'fixed'.
    %   The analysis tool assumes a double precision filter when the
    %   arithmetic input is not specified and the filter System object is
    %   in an unlocked state.
    %
    %   freqrespest(filt,...) with no output argument launches FVTool and shows
    %   the magnitude response estimate of the filter System object, filt.            
      
      arith = parseArithmetic(obj,varargin,false,true); 
      checkIfNLMSupportedAndSendError(obj,arith,'freqrespest');
      
      [d, varargin] = parseArithmetic(obj, varargin);
            
      if nargout > 0
        [Hr, W] = freqrespest(d,varargin{:});
      else
        freqrespest(d,varargin{:})
      end        
    end   
    %----------------------------------------------------------------------    
    function OPTS = freqrespopts(obj,varargin)   
    %FREQRESPOPTS Create an options object for frequency response estimate
    %   OPTS = freqrespopts(filt) uses the current settings in the filter
    %   System object filt to create an options object OPTS that contains
    %   options for frequency response estimation.  The OPTS object can be
    %   passed in as an argument to the FREQRESPEST method.
       
      % This analysis is insensitive to the filter arithmetic. Parse the
      % arithmetic just to get rid of a possible arithmetic input. We do
      % not prevent users from passing the arithmetic input for consistency
      % of all the analysis methods.
      [d, varargin] = parseArithmetic(obj, varargin, true);      
      OPTS = freqrespopts(d,varargin{:});            
    end
    %----------------------------------------------------------------------    
    function Hpsd = noisepsd(obj,varargin)       
    %NOISEPSD Power spectral density of filter output due to roundoff noise
    %   Hpsd = noisepsd(filt,L) computes the power spectral density (PSD) at
    %   the output of the filter System object filt due to roundoff noise
    %   produced by quantization errors within the filter. The PSD is
    %   computed from an average over the L trials. The larger the number
    %   of trials, the better the estimate (at the expense of longer
    %   computation time). If L is not specified, it defaults to 10 trials.
    %
    %   Output Hpsd is a PSD data object. The PSD vector can be extracted
    %   from Hpsd using GET(Hpsd,'Data') and it can be plotted using
    %   PLOT(Hpsd). The average power of the output noise (the integral of
    %   the PSD) can be computed using AVGPOWER(Hpsd).
    %
    %   Hpsd = noisepsd(filt,L,P1,V1,P2,V2,...) specifies optional parameters
    %   via parameter-value pairs. Valid pairs are:
    %
    %        Parameter           Default        Description/Valid values
    %   ---------------------  -----------  ----------------------------------
    %   'NFFT'                 512          Number of FFT points.
    %   'NormalizedFrequency'  true         {true,false}
    %   'Fs'                   'Normalized' Sampling frequency. Only used when
    %                                       'NormalizedFrequency' is false.
    %   'SpectrumType'         'Onesided'   {'Onesided','Twosided'}
    %   'CenterDC'             false        {true,false}
    %
    %   Hpsd = noisepsd(filt,L,OPTS) uses an options object to specify the
    %   optional parameters in lieu of specifying parameter-value pairs.
    %   The OPTS object can be created with OPTS = noisepsdopts(filt).
    %   Settings can be changed in OPTS before calling noisepsd, e.g.
    %   set(OPTS,'Fs',48e3);
    %
    %   Hpsd = noisepsd(filt,'Arithmetic',ARITH,...) analyzes the filter
    %   System object, filt, based on the arithmetic specified in the ARITH
    %   input. ARITH can be set to one of 'double', 'single', or 'fixed'.
    %   The analysis tool assumes a double precision filter when the
    %   arithmetic input is not specified and the filter System object is
    %   in an unlocked state.
    %
    %   noisepsd(filt,...) with no output argument launches FVTool and shows
    %   the noise PSD estimate of the filter System object, filt.

      arith = parseArithmetic(obj,varargin,false,true); 
      checkIfNLMSupportedAndSendError(obj,arith,'noisepsd');
    
      [d, varargin] = parseArithmetic(obj, varargin);    
    
      if nargout > 0
        Hpsd = noisepsd(d,varargin{:});
      else
        noisepsd(d,varargin{:})
      end
    end
    %----------------------------------------------------------------------    
    function OPTS = noisepsdopts(obj,varargin)       
    %NOISEPSDOPTS Create an options object for output noise PSD computation
    %   OPTS = noisepsdopts(filt) uses the current settings in the filter
    %   System object filt to create an options object OPTS that contains
    %   options for output noise PSD computation.  The OPTS object can be
    %   passed in as an argument to the noisepsd method.
      [d, varargin] = parseArithmetic(obj, varargin, true);      
      OPTS = noisepsdopts(d,varargin{:});                
    end
    %----------------------------------------------------------------------
    function specifyall(obj,flg)
    %SPECIFYALL Fully specify fixed-point filter System object settings
    %   specifyall(filt) sets all the data type fixed-point properties of the
    %   filter System object, filt, to 'Custom' so that you can easily specify
    %   all the fixed-point settings. If the object has a
    %   FullPrecisionOverride property, its value is set to false.
    %   specifyall is intended as a shortcut to changing all the
    %   fixed-point properties one-by-one.
    %
    %   specifyall(filt,FLAG) when FLAG is false, is essentially the opposite
    %   of specifyall(filt). All fixed-point properties are set to their
    %   default values and the filter is set to full precision mode if one
    %   is available.
    %
    %   specifyall(filt,FLAG) is equivalent to specifyall(filt) when FLAG is
    %   true.
    
      if isLocked(obj)
        release(obj)
        msg = getString(message('dsp:dsp:private:FilterSystemObjectBase:FpProperties'));
        warning(message('dsp:dsp:private:FilterSystemObjectBase:Release',msg))
      end
        
      if nargin == 1
       flag = true;
      else
        validateattributes( flg, { 'logical' }, { 'scalar' }, '', 'FLAG input');
        flag = flg;
      end
      
      fpProps = getFixedPointProperties(obj);
      if ~flag
        defaultObj = feval(class(obj));
      end
          
      if any(strcmpi(fpProps,'FullPrecisionOverride'))
        obj.FullPrecisionOverride = ~flag;  %#ok<*MCNPR>
      end
            
      if any(strcmpi(fpProps,'FixedPointDataType'))
        if flag
          obj.FixedPointDataType = 'Specify word and fraction lengths';
        else
          obj.FixedPointDataType = 'Full precision';
        end
        return;
      end
      
      wId = 'MATLAB:system:nonRelevantProperty';
      wState =  warning('QUERY', wId);
      warning('off',wId);
      
      for idx = 1:length(fpProps)
        propName = fpProps{idx};
        if flag
          if ~strncmpi(propName,'custom',6) && ...
              ~strcmpi(propName,'FullPrecisionOverride') && ...
              ~any(strcmp({'RoundingMethod','OverflowAction'},propName)) ...
              && contains(propName,'DataType')
              enumValues = set(obj,propName);
              if any(strcmp(enumValues,'Custom'))
              obj.(propName) = 'Custom';
              end
          end
        else
          if ~strncmpi(propName,'custom',6) && ...
              ~any(strcmp({'RoundingMethod','OverflowAction'},propName) )
            obj.(propName) = defaultObj.(propName);
          end
        end
      end
      warning(wState)               
    end

    %----------------------------------------------------------------------
    function FC = cascade(obj,varargin)
    %CASCADE Create a dsp.FilterCascade System object
    %   FC = cascade(obj1,obj2,...) returns an object of type
    %   dsp.FilterCascade that cascades filter System objects.  
        FC = dsp.FilterCascade(obj,varargin{:});
    end

    %----------------------------------------------------------------------
    function PF = parallel(obj,varargin)
    %PARALLEL Create a dsp.ParallelFilter System object
    %   PF = parallel(obj1,obj2,...) returns an object of type
    %   dsp.ParallelFilter that takes the output sum of filter System 
    %   objects.  
        PF = dsp.ParallelFilter(obj,varargin{:});
    end
    
    %----------------------------------------------------------------------
    function [D,varargout] = outputDelay(obj,varargin)
    %outputDelay Output delay of a single rate or a multirate filter.
    %
    % The function outputDelay calculates the delay of a multirate filter, 
    % which results from the group delay of its convolution stages.
    %
    % A multirate filter is any cascade combining upsampling, downsampling, 
    % and convolution filters (FIR or IIR). Most filter System objects in 
    % the DSP System Toolbox(TM) are classified as multirate filters. For
    % example, dsp.FIRDecimator(5) is the multirate filter ->H(z)->(↓5)->. 
    % Single rate filters are a special case of multirate filters with
    % a rate conversion ratio of 1. Single stage filters are also a special
    % case of multirate cascades. For example, dsp.LowpassFilter is 
    % a single-rate, single-stage filter of the form ->H(z)->.
    %
    % The outputDelay(sys) function assumes the multirate filter sys models 
    % a resampling system. Namely, a system whose output is a filtered and 
    % resampled version of the input (at a different rate). In such models, 
    % the input is interpolated to a continuous domain function f(t). The
    % input can then be approximated as u(n) ≈ f(n/FsIn) and the output is
    % y(k) = A⋅f(k/FsOut - D). The values FsIn and FsOut are the input 
    % and output sample rates respectively, and D is the resampling delay.
    % 
    % The outputDelay function returns the delay D and the output sample 
    % rate FsOut for a multirate filter System object operating at an input 
    % sample rate FsIn. 
    %
    % The delay value D depends on the filter structure and order, rate 
    % conversion factors, and sometimes the input signal itself. The value 
    % D is determined by the group delay of the convolution filter stages.
    % 
    % The outputDelay function can operate in two modes, depending on the
    % group delay of filter stages. If all filter stages have a linear 
    % phase, then outputDelay operates in a full band mode. Similarly, if 
    % the filter can be reordered (through noble identity operations) to
    % have equivalent stages with linear phases, the outputDelay function 
    % also operates in a full band mode. If one or more of the stages have 
    % a nonlinear phase, and the filter does not have a linear phase 
    % equivalent, outputDelay operates in a bandlimited mode.
    %
    % • In the full band mode, the returned delay value D applies to all 
    %   inputs. All symmetric filter designs work in that mode. 
    %
    % • In the bandlimited mode, the outputDelay function calculates the 
    %   delay D for a specific input frequency. Specify the input frequency 
    %   through the parameter Fc. This mode is used with filters that have
    %   nonlinear phase stages, which cause a distortion due to the varying 
    %   group delay. In such cases, the resampling model and the delay 
    %   value D are valid only for bandlimited inputs around Fc. The width 
    %   of the band is determined by the frequency region over which the 
    %   group delay is approximately constant. Use the grpdelay function to 
    %   inspect the flatness of the group delay of the filter stages.
    %
    %   The outputDelay function alerts the user if the filter has stages 
    %   with a nonlinear phase. You can use the islinphase function to 
    %   determine if the filter has a linear phase. 
    %   
    % The outputDelay function can estimate a band of input frequencies ƒ 
    % for which the delay is close to D up to a given tolerance Tol.
    % That is |D(ƒ)-D|<=Tol/FsIn. Band measurement is available only for 
    % systems that can be reduced to a rational rate converter, namely, 
    % a cascade of the form ->(↑L)->H(z)->(↓M)->. For a linear phase 
    % system, the returned band is always full (flat group delay). 
    %
    % Usage:
    % D = outputDelay(sys) returns the system output delay. Use this 
    %   syntax when sys is a linear phase single-rate filter. 
    %
    % [D, FsOut] = outputDelay(sys) returns the output delay D and the
    %   output sample rate FsOut. Use this syntax when sys is a linear 
    %   phase multirate filter. 
    %
    % D = outputDelay(sys, FsIn = fin) returns the system output delay
    %   where the input sample rate is the FsIn that you specify. If you do
    %   not specify FsIn, the function uses the built-in input sample rate
    %   property of sys if exists, otherwise the function uses FsIn=1. Use 
    %   this syntax when you want to override the input sample rate.
    %    
    % D = outputDelay(sys, Fc = fc) returns the system output delay, where
    %   the input center frequency is the Fc that you specify. The
    %   frequency Fc determines the value of D through sampling the group 
    %   delay appropriately. If you do not specify Fc, the function uses
    %   the default center frequency of Fc=0 for most filters, except for 
    %   bandpass and highpass filters. Make sure that |fc|<=FsIn/2. Use
    %   this syntax when sys has stages of nonlinear phase.
    %
    % [D, FsOut, B] = outputDelay(sys, Fc = fc, Tol = T, FFTLength = N) 
    %   returns the estimated input frequency band on which the delay value 
    %   is within tolerance Tol (in input sample units) of D. The FFTLength 
    %   parameter sets the resolution at which B is calculated. The default
    %   value of Tol is 0.05, and the default value of FFTLength is 8192.
    %   The returned vector B=[ƒ1 ƒ2] is a pair of boudary frequencies, and
    %   the band stretches from ƒ1 counterclockwise to ƒ2. That is, if 
    %   ƒ2>ƒ1 then the band is {ƒ1<ƒ<ƒ2}. If ƒ2<ƒ1 then the band wraps
    %   around the Nyquist frequency, that is the union of {-FsIn/2<ƒ<ƒ2}
    %   and {ƒ1<ƒ<FsIn/2}. If ƒ1=ƒ2 then band has a single frequency
    %   due to the FFT resolution being too coarse. In such cases, increase 
    %   the value of FFTLength or the tolerance Tol. Use this syntax when 
    %   sys has stages of nonlinear phase.
    %
    %
    % % EXAMPLE 1: Find output times for a dsp.FarrowRateConverter
    % u = sin(6*pi*(1:50)'/200);
    % FsIn = 48000;
    % frc = dsp.FarrowRateConverter(FsIn, 44100);
    % [D, FsOut] = frc.outputDelay();
    % y = frc(u);
    % ts = timescope(NumInputPorts = 2, SampleRate = [FsIn FsOut], ...
    %               TimeDisplayOffset = [0, -D],...
    %               ChannelNames = {'Input','Output'}, ...
    %               TimeSpan = length(y)*1.1/FsIn, ...
    %               PlotType = 'stem')
    % ts(u, y);
    %
    % % EXAMPLE 2: Find output times for dsp.FIRRateConverter (streaming)
    % N = 20; % Frame size
    % inbuf = dsp.AsyncBuffer;
    % inbuf.write(cos(6*pi*(0:2000)'/147));
    % frc = dsp.FIRRateConverter(13, N, 'Auto');
    % [D, FsOut] = frc.outputDelay();
    % ts = timescope(2, [1 FsOut], ...
    %                   TimeDisplayOffset = [0, -D], ...
    %                   TimeSpan=1.1*5*N)
    % for i=1:5
    %   u = inbuf.read(N);
    %   y = frc(u);
    %   ts(u, y);
    % end
    %
    % % EXAMPLE 3: Find output sample times of dsp.FIRRateConverter 
    % n = (0:146)';
    % u = cos(6*pi*n/147);
    % frc = dsp.FIRRateConverter(12,21,'Auto');
    % [D, FsOut] = outputDelay(frc);
    % y = frc(u);
    % stem(y);
    % hold on;
    % stem((n+D)*FsOut+1,u);  % Map input samples to output times
    % hold off;
    %
    % % EXAMPLE 4: Find output times for a dsp.SampleRateConverter
    % FsIn = 44.1e4; 
    % FsOut = 96e3;
    % src = dsp.SampleRateConverter(Bandwidth=40e3,...
    %        InputSampleRate = FsIn, OutputSampleRate = FsOut);
    % D = outputDelay(src);
    % y = src(u);
    % ts = timescope(NumInputPorts = 2, SampleRate = [FsIn FsOut], ...
    %               TimeDisplayOffset = [0, -D],...
    %               ChannelNames={'Input', 'Output'});
    % ts(u, y);    
    %
    % % EXAMPLE 5: Calculate band for a nonlinear phase filter
    % FsIn = 10; 
    % Fc   = 3.3;
    % h = cascade(dsp.FIRFilter(designFracDelayFIR(0.8, 7)), ...
    %             dsp.FIRDecimator);
    % [D,~,B] = outputDelay(h, FsIn = FsIn, Fc=Fc, Tol = 0.1)
    % 
    % [G,W] = h.grpdelay(8192,FsIn);
    % I = W>=B(1) & W<=B(2);  % Mask applicable frequencies
    % plot(W,G /FsIn); 
    % hold on
    % plot(W(I), G(I)/FsIn, 'r', LineWidth=2); 
    % plot(Fc, D, 'ro'); 
    % title(sprintf('Applicable Band (FsIn=%iHz, Fc=%1.1fHz)',FsIn,Fc))
    % legend('Group delay (in sample time units)',...
    %        'Applicable input frequencies band',...
    %        'Output delay for Fc')
    % ylabel('Delay (sec)')
    % xlabel('Frequency (Hz)')
    % hold off
    %
    % See also grpdelay, timescope, islinphase

        [FsIn, Fc, tol, N, DefaultFc] = parseOutputDelayArguments(obj,varargin{:});

        coder.internal.errorIf(abs(2*Fc)>FsIn,'dsp:system:FilterAnalysis:ExceedsNyquist',num2str(abs(Fc)),num2str(FsIn/2));
        [L,M] = obj.rateConversionFactors();

        BandOutputRequested = nargout>2;

        coder.internal.warningIf(~obj.islinphase && ~(BandOutputRequested || ~DefaultFc),'dsp:system:FilterAnalysis:NonlinearPhase',Fc);

        % Sample group delay at a single frequency f
        % First, scale the input sample rate to the filter sample rate
        Fs_Filter = FsIn*L;        
        Fnyq_Filter = Fs_Filter/2;
        
        f_filter = Fc/Fnyq_Filter;

        % Compute the group delay of the filter at the scaled frequency
        G = obj.grpdelay([pi*f_filter 0]);

        % Output sample rate and sample time
        FsOut = FsIn*L/M;
        TsOut = 1/FsOut;

        % Scale the delay to sample units
        D = TsOut*G(1)/M; % Same as TsIn*G(1)/L;

        if nargout>1
            varargout{1} = FsOut;
        end

        % If bandwidth requested
        if BandOutputRequested
            varargout{2} = obj.groupDelayBand(FsIn, Fc, G(1), tol, N);
        end
    end
  end % methods
  
  methods (Static)
   function helpFilterAnalysis()    
   %   The following analysis methods are available for discrete-time filter System objects:
   %
   %   <a href="matlab:help fvtool">fvtool</a>       -  Filter visualization tool
   %   <a href="matlab:help dsp.internal.FilterAnalysis.infoFA">info</a>         -  Filter information
   %   <a href="matlab:help dsp.internal.FilterAnalysis.freqz">freqz</a>        -  Frequency response
   %   <a href="matlab:help dsp.internal.FilterAnalysis.phasez">phasez</a>       -  Phase response
   %   <a href="matlab:help dsp.internal.FilterAnalysis.zerophase">zerophase</a>    -  Zero-phase response
   %   <a href="matlab:help dsp.internal.FilterAnalysis.grpdelay">grpdelay</a>     -  Group delay response
   %   <a href="matlab:help dsp.internal.FilterAnalysis.phasedelay">phasedelay</a>   -  Phase delay response
   %   <a href="matlab:help dsp.internal.FilterAnalysis.impz">impz</a>         -  Impulse response
   %   <a href="matlab:help dsp.internal.FilterAnalysis.impzlength">impzlength</a>   -  Length of impulse response
   %   <a href="matlab:help dsp.internal.FilterAnalysis.stepz">stepz</a>        -  Step response
   %   <a href="matlab:help dsp.internal.FilterAnalysis.zplane">zplane</a>       -  Pole/zero plot
   %   <a href="matlab:help dsp.internal.FilterAnalysis.cost">cost</a>         -  Cost estimate for implementation of the filter System object
   %   <a href="matlab:help dsp.internal.FilterAnalysis.measure">measure</a>      -  Measure characteristics of the frequency response   
   %
   %   <a href="matlab:help dsp.internal.FilterAnalysis.outputDelay">outputDelay</a>  -  Output delay value
   %   <a href="matlab:help dsp.internal.FilterAnalysis.order">order</a>        -  Filter order
   %   <a href="matlab:help dsp.internal.FilterAnalysis.coeffs">coeffs</a>       -  Filter coefficients in a structure
   %   <a href="matlab:help dsp.internal.FilterAnalysis.firtype">firtype</a>      -  Determine the type (1-4) of a linear phase FIR filter System object
   %   <a href="matlab:help dsp.internal.FilterAnalysis.tf">tf</a>           -  Convert to transfer function
   %   <a href="matlab:help dsp.internal.FilterAnalysis.zpk">zpk</a>          -  Convert to zero-pole-gain
   %   <a href="matlab:help dsp.internal.FilterAnalysis.ss">ss</a>           -  Convert to state space representation
   %
   %   <a href="matlab:help dsp.internal.FilterAnalysis.isallpass">isallpass</a>    -  Verify if filter System object is allpass
   %   <a href="matlab:help dsp.internal.FilterAnalysis.isfir">isfir</a>        -  Verify if filter System object is FIR
   %   <a href="matlab:help dsp.internal.FilterAnalysis.islinphase">islinphase</a>   -  Verify if filter System object is linear phase
   %   <a href="matlab:help dsp.internal.FilterAnalysis.ismaxphase">ismaxphase</a>   -  Verify if filter System object is maximum phase
   %   <a href="matlab:help dsp.internal.FilterAnalysis.isminphase">isminphase</a>   -  Verify if filter System object is minimum phase
   %   <a href="matlab:help dsp.internal.FilterAnalysis.isreal">isreal</a>       -  Verify if filter System object is minimum real
   %   <a href="matlab:help dsp.internal.FilterAnalysis.issos">issos</a>        -  Verify if filter System object is in second-order sections form
   %   <a href="matlab:help dsp.internal.FilterAnalysis.isstable">isstable</a>     -  Verify if filter System object is stable
   %
   %   <a href="matlab:help dsp.internal.FilterAnalysis.realizemdl">realizemdl</a>   -  Filter realization (Simulink diagram)   
   %
   %   <a href="matlab:help dsp.internal.FilterAnalysis.specifyall">specifyall</a>   -  Fully specify fixed-point filter System object settings  
   %
   %   <a href="matlab:help dsp.internal.FilterAnalysis.cascade">cascade</a>      -  Create a dsp.FilterCascade System object  
   %   <a href="matlab:help dsp.internal.FilterAnalysis.parallel">parallel</a>     -  Create a dsp.ParallelFilter System object  
   %
   %   Second-order sections:
   %
   %   <a href="matlab:help dsp.BiquadFilter.scale">scale</a>        -  Scale second-order sections of BiquadFilter System object
   %   <a href="matlab:help dsp.BiquadFilter.scalecheck">scalecheck</a>   -  Check scaling of BiquadFilter System object
   %   <a href="matlab:help dsp.BiquadFilter.reorder">reorder</a>      -  Reorder second-order sections of BiquadFilter System object
   %   <a href="matlab:help dsp.BiquadFilter.cumsec">cumsec</a>       -  Cumulative second-order section of BiquadFilter System object
   %   <a href="matlab:help dsp.BiquadFilter.scaleopts">scaleopts</a>    -  Create an options object for second-order section scaling
   %   <a href="matlab:help dsp.IIRFilter.sos">sos</a>          -  Convert to second-order-sections (for IIRFilter System objects only)
   %
   %   Fixed-Point (Fixed-Point Designer Required):
   %
   %   <a href="matlab:help dsp.internal.FilterAnalysis.freqrespest">freqrespest</a>  -  Frequency response estimate via filtering
   %   <a href="matlab:help dsp.internal.FilterAnalysis.freqrespopts">freqrespopts</a> -  Create an options object for frequency response estimate
   %   <a href="matlab:help dsp.internal.FilterAnalysis.noisepsd">noisepsd</a>     -  Power spectral density of filter output due to roundoff noise
   %   <a href="matlab:help dsp.internal.FilterAnalysis.noisepsdopts">noisepsdopts</a> -  Create an options object for output noise PSD computation
   %
   %   Multirate Analysis:
   %
   %   <a href="matlab:help dsp.internal.FilterAnalysisMultirate.polyphase">polyphase</a>                - Polyphase decomposition of multirate filter System object
   %   <a href="matlab:help dsp.CICDecimator.gain">gain (CIC decimator)</a>     - Gain of CIC decimator filter System object
   %   <a href="matlab:help dsp.CICInterpolator.gain">gain (CIC interpolator)</a>  - Gain of CIC interpolator filter System object
   %
   %   For decimator, interpolator, or rate change filter System objects
   %   the analysis tools perform computations relative to the rate at
   %   which the filter is running. If a sampling frequency is specified,
   %   it is assumed that the filter is running at that rate.
   
     help dsp.internal.FilterAnalysis.helpFilterAnalysis
   end  

   function supportedObjects = listFilterAnalysisObjects(ListAudioSysObj)
        arguments
            ListAudioSysObj (1,1) logical = true;
        end

        loc1 = fullfile(matlabroot,'toolbox','dsp','dsp','+dsp','*.m');
        sysobjlist1 = dir(loc1);
        sysobjlist1 = {sysobjlist1.name};
        sysobjlist1 = cellfun(@(x) strtrim(strrep(x,'.m','')), ...
                      sysobjlist1,'UniformOutput', false);
        loc2 = fullfile(matlabroot,'toolbox','dsp','dsp','+dsp','*.p');
        sysobjlist2 = dir(loc2);
        sysobjlist2 = {sysobjlist2.name};
        sysobjlist2 = cellfun(@(x) strtrim(strrep(x,'.p','')), ...
                      sysobjlist2,'UniformOutput', false);
        loc3 = fullfile(matlabroot,'toolbox','dsp','dsp','compiled','+dsp','*.p');
        sysobjlist3 = dir(loc3);
        sysobjlist3 = {sysobjlist3.name};
        sysobjlist3 = cellfun(@(x) strtrim(strrep(x,'.p','')), ...
                      sysobjlist3,'UniformOutput', false);

        % If Audio Toolbox is installed, and has a license, list audio
        % objets too
        isAudioInstalled = ~isempty(ver('audio'));
        [hasAudioLicense, ~] = builtin('license','checkout','Audio_System_Toolbox');
        if ListAudioSysObj && isAudioInstalled&& hasAudioLicense
            loc4 = fullfile(matlabroot,'toolbox','audio','audio','*.m');
            sysobjlist4 = dir(loc4);
            sysobjlist4 = {sysobjlist4.name};
            sysobjlist4 = cellfun(@(x) strtrim(strrep(x,'.m','')), ...
                          sysobjlist4,'UniformOutput', false);
        else
            sysobjlist4 = {};
        end

        % Remove scopes from list of potential matches
        removeObjs = {'ArrayPlot', 'SpectrumAnalyzer', 'TimeScope'};
        sysobjlist1 = setdiff(sysobjlist1,removeObjs);
        sysobjlist2 = setdiff(sysobjlist2,removeObjs);
        sysobjlist3 = setdiff(sysobjlist3,removeObjs);

        % Add dsp prefix
        addprefix = @(s) ['dsp.' s];
        sysobjlist1 = cellfun(addprefix, sysobjlist1, UniformOutput = false);
        sysobjlist2 = cellfun(addprefix, sysobjlist2, UniformOutput = false);
        sysobjlist3 = cellfun(addprefix, sysobjlist3, UniformOutput = false);

        sysobjlistall = setdiff([sysobjlist1 sysobjlist2 sysobjlist3 sysobjlist4],'Contents');
        [~,I] = sort(lower(sysobjlistall));
        sysobjlistallsorted = sysobjlistall(I);

        objectIsSupported = @(sysObjStr) (~isempty(intersect(superclasses(sysObjStr), 'dsp.internal.FilterAnalysis')));
        supportedObjects = sysobjlistallsorted(cellfun(objectIsSupported, sysobjlistallsorted));
   end
  end  
end
