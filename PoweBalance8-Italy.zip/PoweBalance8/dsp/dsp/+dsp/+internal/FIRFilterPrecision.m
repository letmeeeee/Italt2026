function [A,Q] = FIRFilterPrecision(W,X)
%FIRFilterPrecision Determine FIR filter precision settings and signal limits
%
%  [A,Q] = FIRFilterPrecision(W,X) Determines the 'Full precision' accumulator data type and
%  'Same wordlength as input' output data type for a set of FIR filters.
%  The maximum (most +ve) and minimum (most -ve) possible values of the accumulator and output
%  signals are also returned.
%
%  Each row of W is treated a coefficient set (or branch). The worst case precision
%  settings and signal limits across all branches are returned. For example W could contain
%  the branches of a polyphase interpolation or resampling filter.
%
%  * W is a matrix of filter weights of type fi. Each row represents one branch.
%  * X is a numerictype object describing the input fixedpoint precision.
%  * A is a fi vector where A(1) and A(2) are the min and max values of the
%    accumulator respectively with fixed-point properties set to full
%    precision.
%  * Q is a fi vector where Q(1) and Q(2) are the min and max values of the
%    output respectively with fixed-point properties set according to the
%    "Same word length as input" rule.

%   Copyright 2015-2021 The MathWorks, Inc.

% Checking the input data type, coefficient data type, coefficient values.
%--------------------------------------------------------------
% determine output limits
%--------------------------------------------------------------

Xw   = X.WordLength;        % input wordlength
Xf   = X.FractionLength;    % input fraction length
Xs   = strcmpi(X.Signedness,'Signed');
Xint = Xw - Xf;             % input integer length
Wf   = W.FractionLength;    % weights fraction length

if strcmp(X.Signedness,'Unsigned')
    Xmin = 0;
    Xmax = 2^Xint - 2^-Xf;
else
    Xmin = -2^(Xint-1);
    Xmax = 2^(Xint-1) - 2^-Xf;
end

%--------------------------------------------------------------
% determine output limits of an FIR filter
%--------------------------------------------------------------

Wre = double(real(W));
Wim = double(imag(W));

GreP = sum(Wre.*(Wre>0),2);
GreN = sum(Wre.*(Wre<0),2);
GimP = sum(Wim.*(Wim>0),2);
GimN = sum(Wim.*(Wim<0),2);

Vmin = GreP*Xmin + GreN*Xmax;
Vmax = GreP*Xmax + GreN*Xmin;
Wmin = GimP*Xmin + GimN*Xmax;
Wmax = GimP*Xmax + GimN*Xmin;

YreMin = Vmin - Wmax;
YreMax = Vmax - Wmin;
YimMin = Vmin + Wmin;
YimMax = Vmax + Wmax;

YrealLim = [min(YreMin), max(YreMax)];
YimagLim = [min(YimMin), max(YimMax)];

%--------------------------------------------------------------------------
% determine required wordlength to avoid loss of precision and overflow
%--------------------------------------------------------------------------

Ymin = min(YrealLim(1), YimagLim(1));
Ymax = max(YrealLim(2), YimagLim(2));

% accumulator fraction length
Af = Wf + Xf;

if (Ymin >= 0)
    % unsigned accumulator rule
    As = 0;
    Aw = ceil(log2( Ymax*2^Af + 1 ));
else
    % signed accumulator rule
    As = 1;
    Aw = ceil(log2(max( -Ymin*2^Af, Ymax*2^Af + 1 ))) + 1;
end

if Aw == 0
    % special case - if output is always zero (i.e. all coefficients get
    % quantized to 0)
    
    % set output data type = input data type
    A = fi([0,0],Xs,Xw,Xf);
    Q = fi([0,0],Xs,Xw,Xf);
else
    A = fi([Ymin,Ymax],As,Aw,Af);
    
    %--------------------------------------------------------------------------
    % determine output precision for "same word length as input" rule
    %--------------------------------------------------------------------------
    
    % Remove Wa-Wx LSBs to make the output wordlength the same as that of the
    % input while avoiding overflow
    Os = As;           % signedness same as accumulator
    Ow = Xw;           % wordlength same as input
    Of = Af - (Aw-Xw); % reduce fractional length by Wa-Wx
    Q = fi([Ymin,Ymax],Os,Ow,Of);
end


end