classdef MedianFilterSim < dsp.internal.AbstractSlidingWindowStatistic
% MedianFilterSim This class is used in dsp.MedianFilter

%   Copyright 2016-2020 The MathWorks, Inc.

    %#codegen
    %#ok<*EMCLS>
    
    properties (Access = protected)
        InitialBufferValue = 0;
    end
    
    methods
        function obj = MedianFilterSim(varargin)
            setProperties(obj,nargin,varargin{:});
        end
    end
    
    methods(Access = protected)
        
        function y = computeStatistic(obj,u)
            y = movmedian(u,obj.WindowLength,'Endpoints','discard');
        end
        
         function s = saveObjectImpl(obj)
            s = saveObjectImpl@dsp.internal.AbstractSlidingWindowStatistic(obj);
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            loadObjectImpl@dsp.internal.AbstractSlidingWindowStatistic(obj, s, wasLocked);
        end
        
    end
end