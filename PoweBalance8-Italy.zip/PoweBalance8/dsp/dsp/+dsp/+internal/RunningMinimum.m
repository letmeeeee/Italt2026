classdef RunningMinimum < matlab.System
%   RunningMinimum This class is used in dsp.MovingMinimum

%   Copyright 2016 The MathWorks, Inc.
   
%#codegen
%#ok<*EMCLS>

    
    properties (Access = protected)
        % pCumMin Cumulative minimum
        pCumMin
    end
    
    properties (Nontunable)
        % NumChans Number of channels
        NumChans = 1
    end
    
    methods
        function obj = RunningMinimum(varargin)
            setProperties(obj,nargin,varargin{:});
        end
    end
    
    methods(Access = protected)
        
        function setupImpl(obj,u)
            obj.pCumMin = Inf * ones(1,obj.NumChans,'like',u);
        end

        function m = stepImpl(obj,u)
            y      = cummin([obj.pCumMin;u]);
            m      = y(2:end,:);
            obj.pCumMin = y(end,:);
        end
        
        function resetImpl(obj)
           obj.pCumMin = Inf * ones(size(obj.pCumMin),'like',obj.pCumMin);
        end
        
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            if isLocked(obj)
                s.pCumMin = obj.pCumMin;
            end
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            if wasLocked
               obj.pCumMin = s.pCumMin;
            end
            loadObjectImpl@matlab.System(obj, s, wasLocked);
        end
        
    end
end