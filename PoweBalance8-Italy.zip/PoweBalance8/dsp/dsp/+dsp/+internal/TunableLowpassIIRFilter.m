classdef TunableLowpassIIRFilter < dsp.internal.TunableLowpassHighpassIIRFilter
% TunableLowpassIIRFilter

%   Copyright 2022-2023 The MathWorks, Inc.

%#codegen

    methods(Access = protected)
        %------------------------------------------------------------------
        function [b,a,varargout] = designFilter(this)
            dt = this.OutputDataType;
            oneCast = cast(1, dt);
            twoCast = cast(2, dt);
            if strcmpi(this.DesignMethod, 'Butterworth')
                if isScaleValueAllowed(this)
                    [b,a,varargout{1}] = dsp.filterdesign.internal.iir.lphpbutter(cast(this.FilterOrder,dt), cast(this.F3dB,dt), twoCast, oneCast, cast(this.MaxOrder,dt));
                else
                    [b,a] = dsp.filterdesign.internal.iir.lphpbutter(cast(this.FilterOrder,dt), cast(this.F3dB,dt), twoCast, oneCast, cast(this.MaxOrder,dt));
                end
            elseif strcmpi(this.DesignMethod, 'Chebyshev Type I')
                if isScaleValueAllowed(this)
                    [b,a,varargout{1}] = dsp.filterdesign.internal.iir.lphpcheby1(cast(this.FilterOrder,dt), cast(this.F3dB,dt), cast(this.Apass,dt), twoCast, oneCast, cast(this.MaxOrder,dt));
                else
                    [b,a] = dsp.filterdesign.internal.iir.lphpcheby1(cast(this.FilterOrder,dt), cast(this.F3dB,dt), cast(this.Apass,dt), twoCast, oneCast, cast(this.MaxOrder,dt));
                end
            else
                if isScaleValueAllowed(this)
                    [b,a,varargout{1}] = dsp.filterdesign.internal.iir.lphpcheby2(cast(this.FilterOrder,dt), cast(this.F3dB,dt), cast(this.Astop,dt), twoCast, oneCast, cast(this.MaxOrder,dt));
                else
                    [b,a] = dsp.filterdesign.internal.iir.lphpcheby2(cast(this.FilterOrder,dt), cast(this.F3dB,dt), cast(this.Astop,dt), twoCast, oneCast, cast(this.MaxOrder,dt));
                end
            end
        end
    end
end
