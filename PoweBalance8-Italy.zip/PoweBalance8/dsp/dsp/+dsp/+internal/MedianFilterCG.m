classdef MedianFilterCG < matlab.System
% MedianFilterCG This class is used in dsp.MedianFilter

% This class implements a sliding window median using a min-max heap. 
% Each heap contains one-half of the data. All min-heap elements are
% greater than or equal to the median. All max-heap elements are smaller
% than or equal to the median. 

% Reference: "Min-Max Heaps and Generalized Priority Queues", M.D.
% Atkinson, J.R. Sack, N. Santoro, and T. Strothotte, Communications of the
% ACM, October 1986, Volume 29, Number 10.
   
% EXAMPLE
% Consider a sliding window of length 7. Assume the 7 most recent samples
% were: [5 2 6 1 8 3 9]
%
% At this point, the heap is: 
%                    5 <--
%                 3     6
%                1 2   9 8
% 
% The arrow points to the element that will be removed next. Note that all
% elements of the max heap (left) are smaller than the median (root). All
% elements in the max heap (right) are larger than the median. 
% Now assume a new element (0) is inserted. After insertion, the heap is
% now:
%                     0
%                 3        6
%                1 2<--   9 8
%
%  The arrow points to the element that will be removed at the next
%  insertion. 
%  The value at the median is trickled down the max heap:
%                      3
%                 0        6
%                1 2<--   9 8
%
%                      3
%                 2<--    6
%                1 0     9 8
%
% The max heap is now balanced. 
% Since the value at the median (3) is smaller than the root of the min
% heap (6), there is no need to trickle the median down the min heap. the
% median is 3. 
%
% Now assume the next element (10) is inserted. The heap is now:
%                    3
%                 10    6<--
%                1 0   9 8
%
% The new value is in the max heap and is larger than the median value.
% The value is bubbled up:
%                    10
%                 3     6<--
%                1 0   9 8
% 
% The median value changed, and is now larger than the root of the min
% heap. The new median value trickles down the min heap:
%                    6<--
%                 3     10
%                1 0   9 8
%
%                    6<--
%                 3     8
%                1 0   9 10
%
% The heap is now balanced. The median is 6. 

%   Copyright 2016 The MathWorks, Inc.

%#codegen
%#ok<*EMCLS>

    properties (Nontunable)
        % WindowLength Sliding window length
        WindowLength;
        % NumChans Number of input channels
        NumChans  = int32(1);
    end
    
    properties (Access = private, Nontunable)
       % pDatatype Cache input datatype
       pDatatype; 
    
    
       % pIsWindowLengthEven True is window length is even, false if odd
       pIsWindowLengthEven (1, 1) logical 
    end
    
    properties (Access = private)
        % pWinLen Window length cast to input datatype
        pWinLen    
        % pBuf Buffer of data values, hold most recent WindowLength samples
        pBuf 
        % pHeap Heap indices. The middle of pHeap holds the index to the
        % median in pBuf. The first half of pHeap holds the indices of the
        % max heap in pBuf. the second half of pHeap holds the indices of
        % the min heap in pBuf
        pHeap
        % pMidHeap Index value pointing to the middle of the heap (holds
        % median value)
        pMidHeap
        % pIdx Position in pBuf. Indicates which value should be
        % overwritten next in pBuf
        pIdx 
        % pPos Heap position. Indicates where we are in the heap (min, max
        % or median)
        pPos   
        % pMinHeapLength Number of elements in min heap
        pMinHeapLength
        % pMaxHeapLength Number of elements in max heap
        pMaxHeapLength
    end

    methods
        % Constructor
        function obj = MedianFilterCG(varargin)
            setProperties(obj, nargin, varargin{:});
        end
    end
    
    methods (Access = protected)
        
        function setupImpl(obj,x)
            obj.pDatatype = class(x);
            obj.pIsWindowLengthEven = mod(cast(obj.WindowLength, obj.pDatatype),2)==0;
        end
        
        function y = stepImpl(obj,x)
            y = zeros(size(x),class(x));
            % Loop through channels
            for chanIndex = 1:obj.NumChans
                for index = 1:size(x,1)
                    % For each sample, insert new value into heap, re-order
                    % the heap if necessary, and return the median value
                    insertElement(obj,x(index,chanIndex),chanIndex);
                    y(index,chanIndex) = getMedian(obj,chanIndex);
                end
            end
        end
        
        function resetImpl(obj)
            
            % Reset states
            
            nchan    = obj.NumChans;
            wlen     = obj.WindowLength;
            dt       = obj.pDatatype;
            
            obj.pBuf       = zeros(wlen,nchan, dt);
            obj.pPos       = zeros(wlen,nchan, dt);
            obj.pHeap      = zeros(wlen,nchan, dt);
            obj.pWinLen    = cast(wlen, dt);
            obj.pIdx       = obj.pWinLen * cast(ones(1,nchan),dt);
            obj.pMidHeap   = ceil((obj.pWinLen +1) / 2);
            
            % For odd window lengths, min and max heaps have the same
            % number of elements
            % For even window length, max heap has one more element
            obj.pMinHeapLength = fix((obj.pWinLen-1)/2);
            obj.pMaxHeapLength = fix((obj.pWinLen)/2);
            
            % The middle of pHeap holds the index of the median value in
            % pBuf. The first half of pHeap holds the indices to the
            % max-heap values in pBuf. The second half of pHeap holds the
            % indices to the min-heap values in pBuf. pPos holds indices
            % into pHeap and is used to decide where in the heap structure
            % the next element should be inserted Incoming elements are
            % inserted in the following order: median, max, min, max, min..
            %
            % For example, for a window length of 5:
            % The first two elements in pHeap hold the max heap indices
            % The last two elements in pHeap hold the min heap indices
            % The middle element in pHeap holds the max heap index
            % pPos holds the order of insertion: [3 2 4 1 5]
            % pHeap holds the location in the buffer: [4 2 1 3 5]
            cnt1 = cast(1, obj.pDatatype);
            cnt2 = obj.pWinLen;
            for index =cast(wlen,obj.pDatatype):-1:1
                if mod(index,2)==0
                    obj.pPos(index,:) = cnt1;
                    cnt1 = cnt1 + 1;
                else
                    obj.pPos(index,:) = cnt2;
                    cnt2 = cnt2 - 1;
                end
                obj.pHeap(obj.pPos(index),:)= index;
            end
        end

        function val = compareItems(obj,  ind1,  ind2, chanIdx)
            %Compare items ind1 and ind2. Return true if first element less than second element 
            val =  (obj.pBuf(obj.pHeap(ind1 + obj.pMidHeap,chanIdx),chanIdx) < obj.pBuf(obj.pHeap(ind2+ obj.pMidHeap,chanIdx),chanIdx));
        end

        function swapElements(obj, ind1, ind2 , chanIdx)
        % Swap elements in heap   
            ind1 = ind1 + obj.pMidHeap;
            ind2 = ind2 + obj.pMidHeap;
            
            temp = obj.pHeap(ind1,chanIdx);
            obj.pHeap(ind1,chanIdx)=obj.pHeap(ind2,chanIdx);
            obj.pHeap(ind2,chanIdx)=temp;
            obj.pPos(obj.pHeap(ind1,chanIdx),chanIdx)=ind1;
            obj.pPos(obj.pHeap(ind2,chanIdx),chanIdx)=ind2;
        end

        function trickleDownMin(obj, i , chanIdx)
            % Trickle element down the min-heap until heap is in good order
            while (i <= obj.pMinHeapLength)
                if (i>1 && i < obj.pMinHeapLength && compareItems(obj, i+1, i , chanIdx))
                    i = i + 1;
                end
                flag = compareItems(obj,i,fix(i/2),chanIdx);
                if (~flag)
                    break;
                end
                swapElements(obj,i,fix(i/2) , chanIdx);
                i = i * 2;
            end
        end
        
        function trickleDownMax( obj,  i , chanIdx)
        % Trickle element down the max-heap until heap is in good order
            while (i >= -obj.pMaxHeapLength)
                if (i<-1 && i > -obj.pMaxHeapLength && compareItems(obj, i, i-1 , chanIdx))
                    i = i - 1;
                end
                flag = compareItems(obj,fix(i/2),i,chanIdx);
                if (~flag)
                    break;
                end
                swapElements(obj,fix(i/2),i , chanIdx);
                i = i * 2;
            end
        end
        
        function medianChanged =  bubbleUpMin( obj, i, chanIdx)
            % Bubble element up the min-heap until heap is in good order
            i = i - obj.pMidHeap;
            while (i>0)
                flag = compareItems(obj,i,fix(i/2),chanIdx);
                if (~flag)
                    break;
                end
                swapElements(obj,i,fix(i/2),chanIdx);
                i = fix(i/2);
            end
            medianChanged =  (i==0);
        end
        
        function medianChanged =  bubbleUpMax(obj,  i, chanIdx)
        % Bubble element up the max-heap until heap is in good order   
            i = i - obj.pMidHeap;
            
            while (i<0)
                flag = compareItems(obj,fix(i/2),i, chanIdx);
                if (~flag)
                    break;
                end
                swapElements(obj,fix(i/2),i, chanIdx);
                i = fix(i/2);
            end
            medianChanged =  (i  == 0);
        end
        
        function insertElement(obj,  v, chanIdx)
            % Overwrite the oldest element in the buffer
            vprev   = obj.pBuf(obj.pIdx(chanIdx),chanIdx);
            obj.pBuf(obj.pIdx(chanIdx),chanIdx) = v;
            % p holds the heap position that was overwritten 
            p     = obj.pPos(obj.pIdx(chanIdx),chanIdx);
            % Increment 'oldest element' index
            obj.pIdx(chanIdx) = obj.pIdx(chanIdx) + 1;
            % Roll index back to 1 if w have reached the end of the
            % buffer
            if (obj.pIdx(chanIdx) == obj.pWinLen + 1)
                obj.pIdx(chanIdx) = cast(1,obj.pDatatype);
            end

            if (p>  obj.pMidHeap) % new element inserted in min heap
                if (vprev < v)
                    % The new element is larger than the deleted element.
                    % All elements above this new element (including the
                    % median) do not need to move. Push the new element
                    % down until the max heap is reordered
                    trickleDownMin(obj,(p-obj.pMidHeap)*2 , chanIdx);
                else
                    % Move the new value up until the min heap is
                    % re-ordered
                    medianChanged = bubbleUpMin(obj,p,chanIdx);
                    % If the median changed, we need to re-order the max
                    % heap (push median value down the max heap until max
                    % heap is re-ordered)
                    if medianChanged
                        trickleDownMax(obj,cast(-1,class(v)),chanIdx);
                    end
                end
            elseif (p<  obj.pMidHeap)  % new element inserted in max heap
                if (v<vprev)
                    % The new element is smaller than the deleted element.
                    % All elements above this new element (including the
                    % median) do not need to move. Push the new element
                    % down until the max heap is reordered
                    trickleDownMax(obj,(p-obj.pMidHeap)*2,chanIdx);
                else
                    % Move the new value up until the max heap is
                    % re-ordered
                    medianChanged = bubbleUpMax(obj,p,chanIdx);
                    % If the median changed, we need to re-order the min
                    % heap (push median value down the min heap until min
                    % heap is re-ordered)
                    if medianChanged
                        trickleDownMin(obj, cast(1,class(v)),chanIdx);
                    end
                end
            else  % the median value was overwritten
                if (obj.pMaxHeapLength)
                    % If there are elements in the max heap, keep moving
                    % new median value down the max heap until all elements
                    % in the max heap are smaller than the median
                    trickleDownMax(obj,cast(-1,class(v)),chanIdx);
                end
                if (obj.pMinHeapLength > 0)
                    % If there are elements in the min heap, keep moving
                    % new median value down the min heap until all elements
                    % in the min heap are larger than the median
                    trickleDownMin(obj, cast(1,class(v)),chanIdx);
                end
            end

        end
        
        function v = getMedian(obj,chanIdx)
            % If the window length is odd, the median is the value in the
            % middle of the heap.
            % If the window length is even, the median is the average of
            % the two middle values.
            v = obj.pBuf(obj.pHeap(obj.pMidHeap,chanIdx),chanIdx);
            if obj.pIsWindowLengthEven
                v = (v + obj.pBuf(obj.pHeap(obj.pMidHeap-1,chanIdx),chanIdx)) / 2;
            end
        end
         
       function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            if isLocked(obj)
                s.pBuf = obj.pBuf;
                s.pPos = obj.pPos;
                s.pHeap = obj.pHeap;
                s.pWinLen = obj.pWinLen;
                s.pIdx = obj.pIdx;
                s.pMidHeap = obj.pMidHeap;
                s.pDatatype = obj.pDatatype;
                s.pMinHeapLength = obj.pMinHeapLength;
                s.pMaxHeapLength = obj.pMaxHeapLength;
                s.pIsWindowLengthEven = obj.pIsWindowLengthEven;
            end
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                obj.pBuf = s.pBuf;
                obj.pPos = s.pPos;
                obj.pHeap = s.pHeap;
                obj.pWinLen = s.pWinLen;
                obj.pIdx = s.pIdx;
                obj.pMidHeap = s.pMidHeap;
                obj.pDatatype = s.pDatatype;
                obj.pMinHeapLength = s.pMinHeapLength;
                obj.pMaxHeapLength = s.pMaxHeapLength;
                obj.pIsWindowLengthEven = s.pIsWindowLengthEven;
            end
            loadObjectImpl@matlab.System(obj, s, wasLocked);
        end
        
    end
end