classdef FourthOrderSectionFilterAnalysis < dsp.internal.FilterAnalysis
    % FourthOrderSectionFilterAnalysis Baseclass for Fourth-Order Section
    % filter System object analysis
    
    % Copyright 2021 The MathWorks, Inc.
    %#codegen
    methods (Access = protected)
        function d = convertToDFILT(obj, arith)
            % Returns equivalent dfilt to current object.
            % Fixed-point analysis is not currently supported
            assert(strcmpi(arith,'single') || strcmpi(arith,'double'));
            if(~isLocked(obj))
                sysObjToAnalyze = clone(obj);
                setup(sysObjToAnalyze, 1)
            else
                sysObjToAnalyze = obj;
            end
            % Create cascade of fourth-order sections
            Hd = dfilt.df2t(sysObjToAnalyze.Numerator(1,:), sysObjToAnalyze.Denominator(1,:));
            nSections = size(sysObjToAnalyze.Numerator,1);
            for i=2:nSections
                Hdi = dfilt.df2t(sysObjToAnalyze.Numerator(i,:), sysObjToAnalyze.Denominator(i,:));
                Hd = dfilt.cascade(Hd,Hdi);
            end
            d = Hd;
        end
        
    end

    methods  (Hidden=true,Sealed=true)
        % Methods required for filter analysis functionality
        function restrictionsCell = getFixedPointRestrictions(~,~)
            restrictionsCell = {};
        end
        %------------------------------------------------------------------
        function props = getFixedPointProperties(~)
            props = {};
        end
        %------------------------------------------------------------------
        function props = getNonFixedPointProperties(~)
            props = {};
        end
        %------------------------------------------------------------------
        function flag = isPropertyActive(obj,prop)
            flag = ~isInactiveProperty(obj, prop);
        end
    end
end
