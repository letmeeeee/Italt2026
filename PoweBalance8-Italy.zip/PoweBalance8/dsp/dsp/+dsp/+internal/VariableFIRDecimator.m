classdef (StrictDefaults) VariableFIRDecimator < dsp.internal.SupportScalarVarSize ...
        & dsp.enhancedsim.UpdateSysObjBuildInfo
%VARIABLEFIRDECIMATOR Variable FIR Decimator
%   VFD = dsp.internal.VariableFIRDecimator returns a System object, VFD,
%   which decimates the input using a common filter structure. The
%   decimation factor can vary at each step and has to be a factor of the
%   maximum decimation factor. The filter coefficients correspond to the
%   maximum decimation factor. They are auto computed by default and can be
%   specified externally.
%
%   VFD = dsp.internal.VariableFIRDecimator(Name=Value, ...) returns a
%   Variable FIR Decimator System object, VFD, with each specified
%   property name set to the specified value. You can specify additional
%   name-value pair arguments in any order as (Name1=Value1,...,NameN = ValueN).
%
%   Step method syntax:
%
%   Y = step(VFD, X) decimates the real or complex input signal X using the
%   specified filter to produce the output Y. The System object filters
%   each channel of the input signal independently over time.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   Variable FIR Decimator methods:
%
%   step          - See above description for use of this method
%   release       - Allow property value and input characteristics changes
%   clone         - Create Variable FIR Decimator object with
%                   same property values
%   isLocked      - Locked status (logical)
%   reset         - Reset the internal states to initial conditions
%
%   VariableFIRDecimator properties:
%
%   MaxDecimationFactor      - Maximum decimation factor
%   DecimationFactor         - Decimation factor
%   CoefficientSource        - Coefficient source
%   Coefficients             - Prototype filter coefficients
%
%   % EXAMPLE #1: Decimate the input by a factor of 24 followed by a factor
%   of 6 
%   varFIRDecim = dsp.internal.VariableFIRDecimator(24);
%   x = (0:10)';
%   y = varFIRDecim(x);
%   varFIRDecim.DecimationFactor = 6;
%   y = varFIRDecim(x);
%
%   See also dsp.FIRDecimator, dsp.FIRRateConverter, designMultirateFIR

%   Copyright 2022-2023 The MathWorks, Inc.
    %#codegen
    %#ok<*EMCA>
    %#ok<*EMCLS>
    
    properties
        % Coefficients Prototype filter coefficients
        % This property is overwritten when CoefficientSource is set to 'Dialog
        % parameter' or 'Input port'.
        Coefficients = designMultirateFIR(1, 24);
        % DecimationFactor Decimation factor
        % Specifies the instantaneous decimation factor. This value has to be
        % a factor of MaxDecimationFactor. The default value of this property is 24.
        DecimationFactor = 24;
    end

    properties(Nontunable)
        % MaxDecimationFactor Maximum decimation factor Specify the maximum
        % decimation factor which is used to compute the polyphase filter
        % structure. Decimation factor must be less than or equal to the
        % maximum decimation factor. The default value of this property is
        % 24.
        MaxDecimationFactor = 24;
        % CoefficientSource Coefficient source 
        % Specify the input source for coefficients as "Auto", "Dialog
        % parameter" or "Input port". The default is "Auto".
        CoefficientSource (1, :) char {matlab.system.mustBeMemberMessageID(CoefficientSource, ...
            {'dsp:system:VariableFIRDecimator:CoefficientSource_Auto'; ...
            'dsp:system:VariableFIRDecimator:CoefficientSource_Dialogparameter'; ...
            'dsp:system:VariableFIRDecimator:CoefficientSource_Inputport'})} = 'Auto';
        % Specification Output frame length specification
        % Set the output frame length specification as "Decimation factor"
        % or "Output frame length". The default is "Decimation factor".
        Specification (1, :) char {matlab.system.mustBeMemberMessageID(Specification, ...
            {'dsp:system:VariableFIRDecimator:Specification_Decimationfactor'; ...
            'dsp:system:VariableFIRDecimator:Specification_Outputframelength'})} = 'Decimation factor';
        % OutputFrameLength Output signal frame length
        % Specify the output signal frame length as a positive integer.
        % To enable this property set the Specification is "Output frame
        % length". The default is 48.
        OutputFrameLength = 48;
    end

    properties(Hidden, Access = protected)
        pStates;
        pAccumulator;
        pCommutatorPhase = uint32(0);
        pPolyphaseCoefficients;
        pFlippedPolyphaseCoefficients;
        pNumChannels = int32(-1);
        pInputFrameLength = int32(-1);
        pPrivNumCoefficients;
        pInputDataType;
        pPrevDecimationFactor = uint32(24);
    end

    properties(Access = private, Nontunable)
        pCompiledNumChannels = int32(-1);
        pCompiledMaxDecimationFactor = uint32(24);
        pDecimFactorSpec (1, 1) logical = true;
    end

    methods
        function obj = VariableFIRDecimator(varargin)
            % Support name-value pair arguments when constructing object
            setProperties(obj,nargin,varargin{:},'MaxDecimationFactor');
        end
        %------------------------------------------------------------------
        function set.MaxDecimationFactor(obj, Mmax)
            validateattributes(Mmax, {'numeric'},{'scalar', 'finite', 'integer', 'positive'},'','MaxDecimationFactor');
            obj.MaxDecimationFactor = Mmax;
        end
        %------------------------------------------------------------------
        function set.DecimationFactor(obj, M)
            validateattributes(M,{'numeric'},{'scalar', 'finite', 'integer'},'','DecimationFactor');
            obj.DecimationFactor = M;
        end
        %------------------------------------------------------------------
        function set.Coefficients(obj, h)
            validateattributes(h,{'single','double'},{'finite','row'},'','Coefficients');
            obj.Coefficients = h;
        end
    end
    %----------------------------------------------------------------------
    methods(Access = protected)
        %------------------------------------------------------------------
        function setupImpl(obj,u)
            [L,N] = getInputDataSize(obj,u);
            obj.pNumChannels = int32(N);
            obj.pCompiledNumChannels = int32(N);
            obj.pInputFrameLength = int32(L);
            obj.pInputDataType = cast(1, class(u));
            obj.pDecimFactorSpec = strcmpi(obj.Specification, 'Decimation factor');
            if obj.pDecimFactorSpec
                obj.pCompiledMaxDecimationFactor = uint32(obj.MaxDecimationFactor);
            else
                obj.pCompiledMaxDecimationFactor = uint32(L / obj.OutputFrameLength);
            end
            % Error if the Input frame length is not a multiple of the
            % output frame length
            coder.internal.errorIf(~obj.pDecimFactorSpec && mod(L,obj.OutputFrameLength), 'dsp:system:VariableFIRDecimator:InputNotMultipleOfOutput', obj.OutputFrameLength);
            designFilter(obj);
            if ~strcmp(obj.CoefficientSource, 'Auto')
                obj.pPrivNumCoefficients = numel(obj.Coefficients);
            else
                obj.pPrivNumCoefficients = numel(obj.pPolyphaseCoefficients);
            end
            Mmax = obj.pCompiledMaxDecimationFactor;
            obj.pPrevDecimationFactor = uint32(getDecimationFactor(obj));
            Np = coder.const(size(obj.pPolyphaseCoefficients, 2));
            %Halide implementation requires more states than Plain C
            %implementation
            if isempty(coder.target)
                obj.pStates = zeros((Np*Mmax - 1),  N, 'like', u);
            else
                if coder.const(feval('dsp.enhancedsim.IsSysObjSimInCodeGen', coder.target))
                    obj.pStates = zeros((Np*Mmax - 1),  N, 'like', u);
                else
                    obj.pStates = zeros((Np-1)*Mmax, N, 'like', u);
                end
            end
            
            if ~isreal(obj.pPolyphaseCoefficients)
                obj.pAccumulator = cast(zeros(1, N), 'like', obj.pPolyphaseCoefficients);
            else
                obj.pAccumulator = cast(zeros(1, N), 'like', u);
            end
        end
        %------------------------------------------------------------------
        function y = stepImpl(obj, u)
            FL = uint32(size(u, 1));
            N = uint32(obj.pCompiledNumChannels);
            Mmax = uint32(obj.pCompiledMaxDecimationFactor);
            M = uint32(getDecimationFactor(obj));
            %Verify Decimation Factor

            coder.internal.errorIf(mod(Mmax, M) ~= 0, 'dsp:system:VariableFIRDecimator:DecimationFactorNotDividing', M, Mmax);
            % Reset the phase counter if needed
            if ~obj.pDecimFactorSpec
                resetPhaseCounter(obj);
            end
            pflipped = obj.pFlippedPolyphaseCoefficients;
            Np = uint32(size(pflipped, 1));
            phase = obj.pCommutatorPhase;
            if obj.pDecimFactorSpec
                yLen = dsp.internal.VariableFIRDecimator.getOutputLen(FL, phase, M);
                assert(yLen <= FL);
            else
                yLen = obj.OutputFrameLength;
            end
            if ~isreal(pflipped)
                y = zeros(yLen, N, 'like', pflipped);
            else
                y = zeros(yLen, N, 'like', u);
            end
            accumulator = obj.pAccumulator;
            z = obj.pStates;
            if isempty(coder.target)
                [y, z, phase, accumulator] = dsp.internal.builtins.variableFIRDecimator(u, z, pflipped, Mmax, M, Np, yLen, accumulator, phase, y);
            else
                if coder.const(feval('dsp.enhancedsim.IsSysObjSimInCodeGen', coder.target))
                    [y, z, phase, accumulator] = dsp.internal.VariableFIRDecimator.variableFIRDecimatorHalideCG(u, z, pflipped, Mmax, M, Np, FL, N, yLen, accumulator, phase, y);
                else
                    [y, z, phase, accumulator] = dsp.internal.VariableFIRDecimator.variableFIRDecimatorImpl(u, z, pflipped, Mmax, M, Np, FL, accumulator, phase, y);
                end
            end
            obj.pStates = z;
            obj.pCommutatorPhase = phase;
            obj.pAccumulator = accumulator;
        end
        %------------------------------------------------------------------
        function resetImpl(obj)
            % Initialize / reset discrete-state properties
            obj.pCommutatorPhase = uint32(0);
            if ~isempty(obj.pAccumulator) 
                obj.pAccumulator = zeros(size(obj.pAccumulator), 'like', obj.pAccumulator);
            end
            if ~isempty(obj.pStates)
                obj.pStates = zeros(size(obj.pStates), 'like', obj.pStates);
            end
        end
        %------------------------------------------------------------------
        function releaseImpl(obj)
            obj.pNumChannels = int32(-1);
            obj.pInputFrameLength = int32(-1);
        end
        %------------------------------------------------------------------
        function validateInputsImpl(obj,u,~,~)
            validateattributes(u, {'single', 'double'}, {'2d'},'','');
            % Verify number of channels
            [L,N] = size(u);
            if obj.pNumChannels == -1 || obj.pNumChannels ==  0 || N == 0 || ...
                    obj.pInputFrameLength == -1 || obj.pInputFrameLength == 0 || L == 0
                return;
            end
            % Error if number of channels changes
            coder.internal.errorIf(N ~= obj.pNumChannels, 'dsp:system:Shared:numChannels');
            if (L ~= obj.pInputFrameLength) && isLocked(obj) && obj.pNumChannels
                % Cache the new frame length
                obj.pInputFrameLength = int32(L);
            end
        end
        %------------------------------------------------------------------
        function processTunedPropertiesImpl(obj)
            if ~strcmpi(obj.CoefficientSource, 'Auto')
                coder.internal.errorIf(numel(obj.Coefficients) ~= obj.pPrivNumCoefficients,'dsp:system:VariableFIRDecimator:noChangeNumCoeffs');
                designFilter(obj);
            end
            resetPhaseCounter(obj);
        end
        %------------------------------------------------------------------
        function flag = isInactivePropertyImpl(obj, prop)
            flag = false;
            switch prop
                case {'OutputFrameLength'}
                    flag = strcmpi(obj.Specification, 'Decimation factor');
                case {'MaxDecimationFactor', 'DecimationFactor'}
                    flag = strcmpi(obj.Specification, 'Output frame length');
                case {'Coefficients'}
                    flag = ~strcmpi(obj.CoefficientSource, 'Dialog parameter'); 
            end
        end
        %------------------------------------------------------------------
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            if isLocked(obj)
                % All the following are set at setup
                s.pInputDataType                = obj.pInputDataType;
                s.pNumChannels                  = obj.pNumChannels;
                s.pInputFrameLength             = obj.pInputFrameLength;
                s.pPrivNumCoefficients          = obj.pPrivNumCoefficients;
                s.pPolyphaseCoefficients        = obj.pPolyphaseCoefficients;
                s.pFlippedPolyphaseCoefficients = obj.pFlippedPolyphaseCoefficients;
                s.pStates                       = obj.pStates;
                s.pCommutatorPhase              = obj.pCommutatorPhase;
                s.pAccumulator                  = obj.pAccumulator;
                s.Coefficients                  = obj.Coefficients;
                s.DecimationFactor              = obj.DecimationFactor;
                s.pPrevDecimationFactor         = obj.pPrevDecimationFactor;
                s.pCompiledMaxDecimationFactor  = obj.pCompiledMaxDecimationFactor;
                s.pDecimFactorSpec              = obj.pDecimFactorSpec;
                s.pCompiledNumChannels          = obj.pCompiledNumChannels;
            end
        end
        %------------------------------------------------------------------
        function loadObjectImpl(obj,s,wasLocked)
            % Set properties in object obj to values in structure s
            % Set private and protected properties
            if wasLocked
                % All the following were set at setup
                obj.pInputDataType                = s.pInputDataType;
                obj.pNumChannels                  = s.pNumChannels;
                obj.pInputFrameLength             = s.pInputFrameLength;
                if isfield(s,'pPrivNumCoefficients')
                    obj.pPrivNumCoefficients      = s.pPrivNumCoefficients;
                else
                    if ~strcmpi(obj.CoefficientSource,'Auto')
                        obj.pPrivNumCoefficients  = numel(s.pPrivNumCoefficients);
                    end
                end
                obj.pPolyphaseCoefficients        = s.pPolyphaseCoefficients;
                obj.pFlippedPolyphaseCoefficients = s.pFlippedPolyphaseCoefficients;
                obj.pStates                       = s.pStates;
                obj.pCommutatorPhase              = s.pCommutatorPhase;
                obj.pAccumulator                  = s.pAccumulator;
                obj.Coefficients                  = s.Coefficients;
                obj.MaxDecimationFactor           = s.MaxDecimationFactor;
                obj.DecimationFactor              = s.DecimationFactor;
                if isfield(s, 'pPrevDecimationFactor')
                    obj.pPrevDecimationFactor         = s.pPrevDecimationFactor;
                end
                if isfield(s, 'pCompiledNumChannels')
                    obj.pCompiledNumChannels         = s.pCompiledNumChannels;
                end
                if isfield(s,'pCompiledMaxDecimationFactor')
                    obj.pCompiledMaxDecimationFactor = s.pCompiledMaxDecimationFactor;
                end
                if isfield(s,'pDecimFactorSpec')
                    obj.pDecimFactorSpec = s.pDecimFactorSpec;
                end
            end
            % Set public properties and states
            loadObjectImpl@matlab.System(obj,s,wasLocked);
        end
        %------------------------------------------------------------------
        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end
        %------------------------------------------------------------------
        function flag = isInputComplexityMutableImpl(~,~)
            % Return false if input complexity cannot change
            % between calls to the System object
            flag = false;
        end
        %------------------------------------------------------------------
        function flag = isInputDataTypeMutableImpl(~,~)
            % Return false if input data type cannot change
            % between calls to the System object
            flag = false;
        end
        %------------------------------------------------------------------
        function b = polyphase2coeffs(obj)
            p = polyphase(obj);
            b = reshape(p,1,numel(p));
        end
        %------------------------------------------------------------------
        function designFilter(obj)
            Mmax = uint32(getMaxDecimationFactor(obj));
            if strcmp(obj.CoefficientSource, 'Auto')
                b = coder.const(cast(designMultirateFIR(1, Mmax), class(obj.pInputDataType)));
                Np = ceil(uint32(size(b,2))/Mmax);
                obj.pPolyphaseCoefficients = reshape(b, [Mmax, Np]);
            else
                setPolyphaseMatrixFromCustomCoeffs(obj);
            end
            obj.pFlippedPolyphaseCoefficients = cast(fliplr(rot90(obj.pPolyphaseCoefficients)), 'like', obj.pPolyphaseCoefficients);
        end
        %------------------------------------------------------------------
        function setPolyphaseMatrixFromCustomCoeffs(obj)
            Mmax = int32(getMaxDecimationFactor(obj));
            b = obj.Coefficients;
            blen = int32(length(b));
            bmod = mod(blen, Mmax);

            if bmod ~= 0
                bnew = [b(:); zeros(Mmax-bmod,1,'like',b)];
            else
                bnew = b;
            end
            Np = ceil(numel(bnew) / Mmax);
            obj.pPolyphaseCoefficients = cast(reshape(bnew, [Mmax, Np]),class(obj.pInputDataType)); 
        end
        %------------------------------------------------------------------
        function [L,N] = getInputDataSize(~, u)
            % fetch the number of channels
            [L,N] = size(u);
        end
        %------------------------------------------------------------------
        function M = getDecimationFactor(obj)
            if strcmpi(obj.Specification, 'Decimation Factor')
                M = obj.DecimationFactor;
            else
                M = obj.pInputFrameLength / int32(obj.OutputFrameLength);
            end
        end
        %------------------------------------------------------------------
        function Mmax = getMaxDecimationFactor(obj)
            if strcmpi(obj.Specification, 'Output frame length') 
                Mmax = obj.pCompiledMaxDecimationFactor;
            else
                Mmax = obj.MaxDecimationFactor;
            end
        end
        %------------------------------------------------------------------
        function resetPhaseCounter(obj)
            % If the decimation factor changes between steps,
            % reset the commutator phase.
            currDecimFactor = uint32(getDecimationFactor(obj));
            if  currDecimFactor ~= obj.pPrevDecimationFactor
                obj.pCommutatorPhase = uint32(0);
                if ~isempty(obj.pAccumulator)
                    cplx = ~isreal(obj.pAccumulator);
                    obj.pAccumulator(1,1:obj.pCompiledNumChannels) = cast(zeros(1,obj.pCompiledNumChannels),'like',obj.pAccumulator);
                    if cplx
                        obj.pAccumulator = complex(obj.pAccumulator);
                    end
                end
                obj.pPrevDecimationFactor = currDecimFactor;
            end
        end
    end
    %----------------------------------------------------------------------
    methods (Static, Access = protected)
        %------------------------------------------------------------------
        function [y, z, phase, acc] = variableFIRDecimatorImpl(x, z, pflipped, Mmax, M, Np, FL, acc, phase, y)

            currStatesLen = (Np - 1)*M;
            maxStatesLen = (Np - 1)*Mmax;
            in = [z(end-currStatesLen+1:end, :); x];

            yIdx = uint32(1);
            r = Mmax/M;
            ps = r:r:Mmax; % Polyphase selector for a flipped polyphase filter
            r = cast(r, class(pflipped));

            if phase == 0
                k = M;
            else
                k = phase;
            end

            for i = 1 : FL 

                acc(1, :) = acc(1, :) + sum(in(i : M : i + currStatesLen, :) .* (r*pflipped(:, ps(k))));

                if k == M
                    y(yIdx, :) = acc;
                    acc = cast(zeros(size(acc)), 'like', acc);
                    k = uint32(1);
                    yIdx = yIdx + 1;
                else
                    k = k + 1;
                end

            end

            if (FL + currStatesLen) > maxStatesLen
                z(1:maxStatesLen, :) = in(end - (maxStatesLen) + 1 : end, :);
            else
                z(1:maxStatesLen, :) = [z(end - (maxStatesLen - FL) + 1:end, :); x(1:min(FL, maxStatesLen), :)];
            end

            phase = k;
        end
        %------------------------------------------------------------------
        function [y, z, phase, accumulator] = variableFIRDecimatorHalideCG(u, z, pflipped, Mmax, M, Np, FL, N, yLen, accumulator, phase, y)
            coder.cinclude('iHalideVariableFIRDecimator.hpp');

            if isa(u,'single') && ~isreal(u)
                if isreal(pflipped)
                    func = 'processHalide_variableFIRDecimatorCRS';
                else
                    func = 'processHalide_variableFIRDecimatorCCS';
                end
            elseif isa(u,'double') && ~isreal(u)
                if isreal(pflipped)
                    func = 'processHalide_variableFIRDecimatorCRD';
                else
                    func = 'processHalide_variableFIRDecimatorCCD';
                end
            elseif isa(u,'single') && isreal(u)
                if isreal(pflipped)
                    func = 'processHalide_variableFIRDecimatorRRS';
                else
                    func = 'processHalide_variableFIRDecimatorRCS';
                end
            elseif isa(u,'double') && isreal(u)
                if isreal(pflipped)
                    func = 'processHalide_variableFIRDecimatorRRD';
                else
                    func = 'processHalide_variableFIRDecimatorRCD';
                end
            end

            if phase == 0
                phase = M;
            end

            halideStatesLen = uint32((Np - 1) * M + phase - 1);
            bufferLen = uint32(FL + halideStatesLen);

            assert(bufferLen <= FL + Np*Mmax - 1); %Maximum halideStatesLen = Np*Mmax - 1

            buffer = zeros(bufferLen, N, 'like', u);
          
            coder.ceval(func, coder.ref(u), coder.ref(buffer), coder.ref(pflipped), ...
                uint32(Mmax), uint32(M), uint32(FL), uint32(N), ...
                uint32(halideStatesLen), uint32(bufferLen), uint32(Np), ...
                uint32(yLen), coder.ref(accumulator), coder.ref(phase), ...
                coder.ref(z), coder.ref(y));

        end
        %------------------------------------------------------------------
        function groups = getPropertyGroupsImpl
            % Modify order of display
            parameterString = getString(message('dsp:system:Shared:Parameters'));
            groups =  matlab.system.display.Section(...
                'Title', parameterString, ...
                'PropertyList', {'Specification','OutputFrameLength','MaxDecimationFactor','DecimationFactor','CoefficientSource','Coefficients'});
        end
    end
    %----------------------------------------------------------------------
    methods (Static, Access = private)
        %------------------------------------------------------------------
        function outputLen = getOutputLen(FL, phase, M)
            tmpPhaseIdx = phase;
            outputLen = uint32(0);

            for i=1:FL
                if tmpPhaseIdx == M || tmpPhaseIdx == 0
                    outputLen = outputLen + 1;
                    tmpPhaseIdx = uint32(1);
                else
                    tmpPhaseIdx = tmpPhaseIdx + 1;
                end
            end
        end
    end
    %----------------------------------------------------------------------
    methods(Access = public)
        %------------------------------------------------------------------
        function p = polyphase(obj)
            %p = polyphase(obj) Return polyphase matrix
            %   p = polyphase(obj) returns the polyphase matrix used by the
            %   filter bank. Each row in the matrix corresponds to a
            %   polyphase branch. The number of columns of p corresponds to
            %   the number of filter taps per branch.
            if ~isLocked(obj)
                if strcmpi(obj.CoefficientSource,'Auto')
                    designFilter(obj);
                else
                    setPolyphaseMatrixFromCustomCoeffs(obj);
                end
            end
            p = obj.pPolyphaseCoefficients;
        end
        %------------------------------------------------------------------
        function fvt = fvtool(obj)
            if strcmp(obj.CoefficientSource, 'Auto')
                h = obj.polyphase2coeffs;
            else
                h = obj.Coefficients;
            end

            Mmax = obj.MaxDecimationFactor;
            filt = dsp.FIRDecimator(DecimationFactor = Mmax, Numerator = h);
            fvt = fvtool(filt);
        end
    end
end
