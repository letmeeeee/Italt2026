classdef FilterAnalysisMultirate < dsp.internal.FilterAnalysis
  %FilterAnalysisMultirate Baseclass for multirate filter System object analysis
  
  %   Copyright 2011-2020 The MathWorks, Inc.
  
  %#codegen  
  methods (Hidden)
    function flag = isMultirate(~)
      flag = true;
    end
  end
  
  methods
    function obj = FilterAnalysisMultirate(varargin)

    end
      
    function P = polyphase(obj,varargin)
      %Polyphase decomposition of System object
      %   P = polyphase(H) returns the polyphase matrix of the filter
      %   System object, H. The i-th row of the matrix P represents the
      %   i-th subfilter.
      %
      %   P = polyphase(H,'Arithmetic',ARITH,...) analyzes the filter
      %   System object, H, based on the arithmetic specified in the ARITH
      %   input. ARITH can be set to one of 'double', 'single', or 'fixed'.
      %   The analysis tool assumes a double precision filter when the
      %   arithmetic input is not specified and the filter System object is
      %   in an unlocked state.
      %
      %   polyphase(H) called with no outputs launches the Filter
      %   Visualization Tool (FVTool) with all the polyphase subfilters to
      %   allow analyses of each component individually.
      
      [d, varargin] = parseArithmetic(obj, varargin);
      
      if nargout > 0
        P = polyphase(d,varargin{:});
      else
        polyphase(d,varargin{:})
      end
    end 
   %----------------------------------------------------------------------
    function [A,B,C,D] = ss(~,varargin)     %#ok<*STOUT>
      error(message(...
        'dsp:dsp:private:FilterSystemObjectBase:SSNotDefinedForMultirate'))
    end
   %----------------------------------------------------------------------
    function [Hpsd,W] = freqrespest(obj,varargin)    
      error(message(...
        'dsp:dsp:private:FilterSystemObjectBase:NLMNotDefinedForMultirate',...
        'freqrespest',class(obj)));
    end 
   %----------------------------------------------------------------------
    function OPTS = freqrespopts(obj,varargin)    
      error(message(...
        'dsp:dsp:private:FilterSystemObjectBase:NLMNotDefinedForMultirate',...
        'freqrespopts',class(obj)));
    end        
   %----------------------------------------------------------------------
    function Hpsd = noisepsd(obj,varargin)    
      error(message(...
        'dsp:dsp:private:FilterSystemObjectBase:NLMNotDefinedForMultirate',...
        'noisepsd',class(obj)));
    end 
   %----------------------------------------------------------------------
    function OPTS = noisepsdopts(obj,varargin)    
      error(message(...
        'dsp:dsp:private:FilterSystemObjectBase:NLMNotDefinedForMultirate',...
        'noisepsdopts',class(obj)));
    end    
  end
  
  methods (Access = protected)
    function flag = isNLMSupported(obj,~)  %#ok<INUSD>
      flag = false;
    end 
  end
end