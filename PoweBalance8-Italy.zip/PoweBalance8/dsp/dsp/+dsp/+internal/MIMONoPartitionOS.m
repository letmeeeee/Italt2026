classdef MIMONoPartitionOS < dsp.internal.MIMONoPartitionOAOSBase
    % MIMONoPartitionOS MIMO Overlap-save for multiple filters.
    % This class is used in dsp.FrequencyDomainFIRFilter

    % Copyright 2023 The MathWorks, Inc.

    %#codegen
    methods
        function obj = MIMONoPartitionOS(varargin)
            setProperties(obj, nargin, varargin{:});
        end
    end

    methods (Access = protected)
        function setupImpl(obj,u)
            setupImpl@dsp.internal.MIMONoPartitionOAOSBase(obj, u);
            obj.pStates = zeros(obj.pFilterLength - 1, size(u, 2), 'like', u);
        end
    end

    methods (Static)
        % Implement MIMO No Partition Overlap-Save
        function [y, prevsec] = computeOutput(u, freqNum, prevsec, ...
                numChan, numReceivers, numPaths, numFrames, ...
                L, fftLen, filterLen, dataType, isOutReal, useEqvFilter, sumOutputs)

            if sumOutputs
                if isOutReal
                    y = zeros(L*numFrames, numReceivers, dataType);
                else
                    y = complex(zeros(L*numFrames, numReceivers, dataType));
                end
            else
                if isOutReal
                    y = zeros(L*numFrames, numReceivers, numChan, dataType);
                else
                    y = complex(zeros(L*numFrames, numReceivers, numChan, dataType));
                end
            end

            zout = complex(zeros(fftLen, numReceivers, numChan, dataType));

            if ~useEqvFilter
                ztmp = complex(zeros(fftLen, numPaths, dataType));
            end

            for i = 1:numFrames
                z       = [prevsec; u((i-1)*L+1:i*L,:)];
                prevsec = z((L + 1):(L + filterLen - 1),:);
                xfft    = fft(z, fftLen);
                rxIndex = 1;

                if ~useEqvFilter
                    % Summing across all the paths between a given Tx-Rx
                    for ii = 1:numChan
                        for jj = 1:numReceivers
                            index                   = (ii-1)*numReceivers*numPaths + (jj - 1)*numPaths;

                            for kk = 1:numPaths
                                ztmp(:, kk)         = xfft(:, ii).*freqNum(:, index + kk);
                            end
                            zout(:, jj, ii)    = sum(ztmp, 2);
                        end
                    end
                else
                    for ii = 1:numChan
                        for jj = 1:numReceivers
                            index                   = (ii-1)*numReceivers + jj;
                            zout(:, rxIndex, ii)    = sum(xfft(:, ii).*freqNum(:, index), 2);
                            rxIndex                 = rxIndex + 1;
                        end
                    end
                end

                % Summing up the inputs at the receiver end
                if sumOutputs
                    yy = sum(zout, 3);
                else
                    yy = zout;
                end
                
                if isOutReal
                    o = real(ifft(yy, fftLen, 1));
                else
                    o = ifft(yy, fftLen, 1);
                end

                y((i-1)*L + 1: L*i, :, :) = o(filterLen:end, :, :);

            end

        end

    end
end