classdef PolyphaseFFTBase < dsp.internal.SupportScalarVarSize
    % PolyphaseFFTBase Polyphase FFT Filter banks base class
    
    % Copyright 2016-2020 The MathWorks, Inc.
    
    %#codegen
    
    properties (Nontunable)
        %Specification Polyphase filter specification
        %   Set the specification as one of 'Number of taps per band and
        %   stopband attenuation' | 'Coefficients'. The default is 'Number
        %   of taps per band and stopband attenuation'.
        Specification (1, :) char {matlab.system.mustBeMemberMessageID(Specification, ...
            {'dsp:system:Channelizer:Specification_Coefficients'; ...
            'dsp:system:Channelizer:Specification_Numberoftapsperbandandstopbandattenuation'})} ='Number of taps per band and stopband attenuation';
        %NumTapsPerBand Number of filter taps per frequency band
        %   Specify the number of filter coefficients or taps for each
        %   frequency band. This also corresponds to the number of filter
        %   coefficients per polyphase branch. The total number of filter
        %   coefficients is given by NumTapsPerBand times the number of
        %   frequency bands. This property applies when you set
        %   Specification to 'Number of taps per band and stopband
        %   attenuation'. The default is 12.
        NumTapsPerBand = 12;
        %StopbandAttenuation Stopband attenuation (dB)
        %   Set the stopband attenuation in decibels for the prototype
        %   lowpass filter that is designed. This value controls the
        %   maximum amount of aliasing from one frequency band to the next.
        %   The larger the stopband attenuation, the smaller the passband
        %   ripple. This property applies when you set Specification to
        %   'Number of taps per band and stopband attenuation'. The default
        %   is 80 dB.
        StopbandAttenuation = 80;
    end
    
    properties
        %LowpassCoefficients Prototype lowpass filter coefficients
        %   Specify the coefficients of the prototype lowpass filter as a
        %   real or complex row vector. There must be at least one
        %   coefficient per frequency band. If the length of the lowpass
        %   filter is less than the number of frequency bands, the
        %   coefficients will be zero-padded. This property applies when
        %   you set Specification to 'Coefficients'. The default vector of
        %   coefficients is obtained using rcosdesign(0.25,6,8,'sqrt').
        %   This property is tunable.
        LowpassCoefficients = rcosdesign(0.25, 6, 8,'sqrt');
    end        
    
    properties (Access=protected, Nontunable)
        %InputDataType Data type of the inputs
        %   This is a private property that stores the data type of the
        %   inputs and it is used to set the data type of all the
        %   DiscreteState properties and the outputs.
        InputDataType = 'double';
        privNumFrequencyBands
        % privNumCoefficients Keep track of the number of coefficients for
        % Specification = 'Coefficients'
        privNumCoefficients
    end
    
    properties (Access=protected)
        States
        PolyphaseMatrix
        actpmatrix
        numChannels = int16(-1);
        oldNumFrequencyBands = int16(-1); 
    end
    %----------------------------------------------------------------------
    % Public methods
    %----------------------------------------------------------------------
    methods
        %------------------------------------------------------------------
        function set.NumTapsPerBand(obj,P)
            validateattributes(P,...
                {'numeric'},...
                {'finite','real','scalar','>',0,'integer','even'},...
                '','NumTapsPerBand');
            obj.NumTapsPerBand = P;
        end
        %------------------------------------------------------------------
        function set.StopbandAttenuation(obj,SA)
            validateattributes(SA,...
                {'single','double'},...
                {'finite','real','scalar','positive'},...
                '','StopbandAttenuation');
            obj.StopbandAttenuation = SA;
        end
        %------------------------------------------------------------------
        function set.LowpassCoefficients(obj,b)
            validateattributes(b,...
                {'single','double'},...
                {'finite','row'},...
                '','LowpassCoefficients');
            obj.LowpassCoefficients = b;
        end
    end
    %----------------------------------------------------------------------
    % Protected methods
    %----------------------------------------------------------------------
    methods (Access=protected)
        %------------------------------------------------------------------
        function resetImpl(obj)
            % Specify initial values for DiscreteState properties
            obj.States = zeros(size(obj.States),'like',obj.States);
        end
        %------------------------------------------------------------------
        function setupImpl(obj)
            if strcmpi(obj.Specification,'Coefficients')
                obj.privNumCoefficients = numel(obj.LowpassCoefficients);
            end
        end
        %------------------------------------------------------------------
        function s = saveObjectImpl(obj)
            % Default implementation saves all public properties
            s = saveObjectImpl@matlab.System(obj);
            
            if isLocked(obj)
                % All the following are set at setup
                s.InputDataType         = obj.InputDataType;
                s.numChannels           = obj.numChannels;
                s.privNumFrequencyBands = obj.privNumFrequencyBands;
                s.oldNumFrequencyBands  = obj.oldNumFrequencyBands;
                s.PolyphaseMatrix       = obj.PolyphaseMatrix;
                s.States                = obj.States;
                s.actpmatrix            = obj.actpmatrix;
                s.privNumCoefficients    = obj.privNumCoefficients;
            end
        end
        %------------------------------------------------------------------
        function s = loadObjectImpl(obj, s, wasLocked)
            % Re-load state if saved version was locked
            if wasLocked
                % All the following were set at setup
                obj.InputDataType         = s.InputDataType;
                obj.numChannels           = s.numChannels;
                obj.privNumFrequencyBands = s.privNumFrequencyBands;
                obj.oldNumFrequencyBands  = s.oldNumFrequencyBands;
                obj.PolyphaseMatrix       = s.PolyphaseMatrix;
                obj.States                = s.States;
                if isfield(s,'actpmatrix')
                    obj.actpmatrix            = s.actpmatrix;
                else
                    obj.actpmatrix            = s.PolyphaseMatrix;
                end
                if isfield(s,'privNumCoefficients')
                    obj.privNumCoefficients = s.privNumCoefficients;
                else
                    if strcmpi(obj.Specification,'Coefficients')
                        obj.privNumCoefficients = numel(s.LowpassCoefficients);
                    end
                end
                
            end
            
            % Call base class method
            loadObjectImpl@matlab.System(obj,s,wasLocked);
        end
        %------------------------------------------------------------------
        function flag = isInactivePropertyImpl(obj, prop)
            flag = false;
            specLocal = obj.Specification;
            switch prop
                case {'LowpassCoefficients'}
                    if ~strcmp(specLocal, 'Coefficients')
                        flag = true;
                    end
                case {'NumTapsPerBand','StopbandAttenuation'}
                    if strcmp(specLocal, 'Coefficients')
                        flag = true;
                    end
            end
        end
        %------------------------------------------------------------------
        function processTunedPropertiesImpl(obj)
            
            if strcmpi(obj.Specification,'Coefficients')
                
                coder.internal.errorIf(numel(obj.LowpassCoefficients) ~= obj.privNumCoefficients,'dsp:system:Channelizer:noChangeNumCoeffs');
                
                M = obj.privNumFrequencyBands;
                setPolyphaseMatrixFromCustomCoeffs(obj,M);
            end
        end
        %------------------------------------------------------------------
        function setPolyphaseMatrixFromCustomCoeffs(obj,NumFreqBands)
            M = uint32(NumFreqBands);
            b = obj.LowpassCoefficients;
            N = uint32(length(b)); % Make sure mod is in right data type
            L = mod(N,M);
            if L ~= 0
                bnew = [b(:); zeros(M-L,1,'like',b)];
            else
                bnew = b;
            end
            obj.PolyphaseMatrix = cast(reshape(bnew,M,length(bnew)./M),obj.InputDataType);
        end
        %------------------------------------------------------------------
        function releaseImpl(obj)
            obj.numChannels = int16(-1);
            obj.oldNumFrequencyBands = int16(-1);
        end
        %------------------------------------------------------------------
        function b = poly2coeffs(obj)
            p = polyphase(obj);
            b = reshape(p,1,numel(p));
        end
    end
    %----------------------------------------------------------------------
    % Abstract Protected methods
    %----------------------------------------------------------------------  
     methods (Access=protected,Abstract)
         designPrototypeLowpass(obj)
     end
end
