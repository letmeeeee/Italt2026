classdef (StrictDefaults)AsyncBuffercgHelper < matlab.System
    %AsyncBuffercgHelper Codegen class for dsp.AsyncBuffer
    
    % Copyright 2016-2021 The MathWorks, Inc.
    
    %#codegen
    
    properties (Nontunable)
        %Capacity Number of writable/readable samples per channel in buffer
        % The default is 192000.
        Capacity = int32(192000);
    end
    properties (Dependent, SetAccess = private)
        %NumUnreadSamples Number of unread samples per channel in buffer
        % The total number of unread samples in the buffer is
        % NumUnreadSamples*(number of channels). This is a read-only
        % property.
        NumUnreadSamples
    end
    
    properties(Access = private)
        NumChannels        = int32(-1);
    end
    
     properties(Access = private, Nontunable)
        CompiledNumChannels        = int32(-1);
    end
    
    properties(Access = protected)
        Cache
        CumulativeOverrun  = int32(0);
        CumulativeUnderrun = int32(0);
        ReadPointer        = int32(1);
        WritePointer       = int32(2);
        isInitialized      = false;
    end
    %-----------------------------------------------------------------------
    % Protected methods
    %-----------------------------------------------------------------------
    methods (Access = protected)
        
        %-------------------------------------------------------------------
        % Release
        %-------------------------------------------------------------------
        function releaseImpl(obj)
            % The public dependent property NumUnreadSamples depends on the
            % read and write pointers, so they are reset during release
            % since they are no longer visible.
            obj.ReadPointer        = int32(1);
            obj.WritePointer       = int32(2);
            obj.CumulativeOverrun  = int32(0);
            obj.CumulativeUnderrun = int32(0);
            obj.isInitialized      = false;
            obj.NumChannels        = int32(-1);
            if isempty(coder.target)
                obj.Cache = [];
            end
        end
        
        %-------------------------------------------------------------------
        % Reset
        %-------------------------------------------------------------------
        function resetImpl(obj)
            obj.ReadPointer        = int32(1);
            obj.WritePointer       = int32(2);
            obj.CumulativeOverrun  = int32(0);
            obj.CumulativeUnderrun = int32(0);
            obj.Cache = zeros(obj.Capacity+int32(1),size(obj.Cache,2), ...
                'like',obj.Cache);
        end
        
        %-------------------------------------------------------------------
        % Setup
        %-------------------------------------------------------------------
        function setupImpl(obj,in)
            numChan                  = int32(size(in,2));
            
            % Disallow a first step with zero channels
            coder.internal.errorIf(numChan == int32(0),'dsp:system:Shared:EmptyFirstStep');
            
            obj.NumChannels          = numChan;     
            obj.CompiledNumChannels  = numChan;
            obj.isInitialized        = true;
            obj.Cache                = zeros(obj.Capacity+int32(1),numChan,'like',in);
        end
        
        %-------------------------------------------------------------------
        % Validate inputs to step method
        %-------------------------------------------------------------------
        function validateInputsImpl(obj,in)
            validateattributes(in,{'numeric','logical'},{'2d'},'validateInputs','input');
            
            coder.internal.errorIf(size(in,1)>int32(obj.Capacity),['dsp:system',...
                ':AsyncBuffer:numRows']);
            
            if obj.NumChannels == int32(-1)
                return
            end
            
            % Check that occurs on input after initialization
            coder.internal.errorIf(size(in,2)~=obj.NumChannels,['dsp:system',...
                ':Shared:numChannels']);
        end
        
        %-------------------------------------------------------------------
        % Flag to unlock input size
        %-------------------------------------------------------------------
        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end
        
        %-------------------------------------------------------------------
        % Step
        %-------------------------------------------------------------------
        function overrun = stepImpl(obj,in)
            overrun = write(obj,in);
        end
        
        %-------------------------------------------------------------------
        % Load object (used for clone method)
        %-------------------------------------------------------------------
        function loadObjectImpl(obj,s,wasLocked)
            % Re-load state if saved version was locked
            % Casts for backwards compatibility before R2017b.
            if wasLocked
                obj.CumulativeOverrun    = int32(s.CumulativeOverrun);
                obj.CumulativeUnderrun   = int32(s.CumulativeUnderrun);
                obj.Cache                = s.Cache;
                obj.ReadPointer          = int32(s.ReadPointer);
                obj.WritePointer         = int32(s.WritePointer);
                obj.isInitialized        = s.isInitialized;
                obj.NumChannels          = int32(s.NumChannels);
            end
            loadObjectImpl@matlab.System(obj,s,wasLocked);
        end
        
        %-------------------------------------------------------------------
        % Save object (used for clone method)
        %-------------------------------------------------------------------
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            if isLocked(obj)
                s.CumulativeOverrun    = obj.CumulativeOverrun;
                s.CumulativeUnderrun   = obj.CumulativeUnderrun;
                s.Cache                = obj.Cache;
                s.ReadPointer          = obj.ReadPointer;
                s.WritePointer         = obj.WritePointer;
                s.isInitialized        = obj.isInitialized;
                s.NumChannels          = obj.NumChannels;
            end
        end
        
        %-------------------------------------------------------------------
        % Info
        %-------------------------------------------------------------------
        function s = infoImpl(obj)
            %INFO Get cumulative overrun and underrun
            %   CumulativeOverrun - Number of samples overrun per channel since
            %       last call to reset. The number of samples overrun is the
            %       number of unread samples overwritten.
            %
            %   CumulativeUnderrun - Number of samples underrun per channel
            %       since last call to reset. Underrun occurs if you attempt to
            %       read more samples than available.
            %
            s = struct( ...
                'CumulativeOverrun',obj.CumulativeOverrun, ...
                'CumulativeUnderrun',obj.CumulativeUnderrun);
        end
    end
    
    %-----------------------------------------------------------------------
    % Public methods for reading and writing and getting unread samples
    %-----------------------------------------------------------------------
    methods
        function obj = AsyncBuffercgHelper(varargin)
            setProperties(obj,nargin,varargin{:},'Capacity');
        end
        function set.Capacity(obj,val)
            validateattributes(val,{'numeric'}, ...
                {'finite','real','scalar','integer','positive','>=',2},...
                'set.Capacity','Capacity');
            obj.Capacity  = int32(val);
        end
        function overrun = write(obj,in)
            %WRITE Write to buffer
            % nOverrun = write(Q,x) writes the samples, x, to the
            %   buffering object, Q. It also returns the number of samples
            %   overrun in the current call to write. The number of samples
            %   overrun is the number of unread samples overwritten.
            % Write properties to local variables -------------------------
            oneCast  = int32(1);
            zeroCast = int32(0);
            wPtr     = obj.WritePointer;
            rPtr     = obj.ReadPointer;
            cap      = obj.Capacity + oneCast;
            overrun  = zeroCast;
            row      = int32(size(in,1));
            chan     = int32(size(in,2));
            %--------------------------------------------------------------
            
            if (wPtr<oneCast) || (wPtr>cap)
                % This if-statement is required for codegen with dynamic
                % memory allocation set to false.  This if-statement cannot
                % be hit due to dsp.AsyncBuffer's internal book-keeping
                % of read and write pointers, so the error message does not
                % need to be in the message catalog.
                error('Pointers must be bounded.')
            end
            
            c = wPtr + row - oneCast;
            
            if c > cap                             %   |---w------| c
                c = c - cap;
                bc = [wPtr:cap,oneCast:c];
                if wPtr <= rPtr                    %   |---c---w-r-|
                    overrun = cap - rPtr + oneCast + c;
                elseif rPtr <= c                   %   |-r-c---w---|
                    overrun = c - rPtr + oneCast;
                end
            else                                   %   |---w---c---|
                bc = wPtr:c;
                if (wPtr<=rPtr) && (rPtr<=c)       %   |---w-r-c---|
                    overrun = c - rPtr + oneCast;
                end
            end
            obj.Cache(bc,1:chan) = in;
            
            if (c+oneCast)>cap
                wPtr = oneCast;
            else
                wPtr = c + oneCast;
            end
            if overrun ~= zeroCast
                rPtr = wPtr;
            end
            
            % Update properties -------------------------------------------
            obj.CumulativeOverrun = obj.CumulativeOverrun + overrun;
            obj.WritePointer      = wPtr;
            obj.ReadPointer       = rPtr;
            % -------------------------------------------------------------
        end
        function [out,underrun] = peek(obj,numRows,overlap)
            %PEEK Read from buffer without changing the number of unread 
            %     samples
            % out = peek(Q) returns all unread samples in buffer.
            %
            % out = peek(Q,NumRows) returns NumRows samples from each
            %   channel (column) of buffer. If the requested number of
            %   samples is greater than the number of unread samples, the
            %   output is zero-padded.
            %
            % out = peek(Q,NumRows,Overlap) returns NumRows samples from
            %   each channel and overlaps previously read samples by
            %   Overlap. The total number of samples read is NumRows *
            %   (number of channels). The total number of new samples read
            %   is (NumRows - Overlap) * (number of channels). If the
            %   overlap portion read contains samples that are
            %   overwritten, and are therefore not contiguously written,
            %   the output is zero-padded.
            %
            % [out,nUnderrun] = peek(Q,...) additionally returns the
            %   number of rows zero-padded if underrun occurred. Underrun
            %   occurs if you attempt to read more samples than available.
            %   Samples zero-padded in overlapped portions are not counted
            %   as underrun.
            %
            % % Example: Peek at contents of buffer
            % % Create AsyncBuffer object
            %   Q = dsp.AsyncBuffer;
            % 
            % % Create input signal
            % signal = (1:100).';
            % 
            % %% Write Signal to buffer
            % write(Q,signal);
            % 
            % %% Peek at first 3 samples
            % out1  = peek(Q,3); % out1 = [1; 2; 3];
            % 
            % %% Read first 50 samples
            % out2  = read(Q,50); % out2 = (1:50).';
            % 
            % %% Now peek again at first 3 samples
            % out1  = peek(Q,3); % out1 = [51; 52; 53];
            % 
            % %% Read remaining samples
            % out2  = read(Q); % out2 = (51:100).';

            %--------------------------------------------------------------
            % Return error if buffer not initialized ----------------------
            coder.internal.errorIf(obj.isInitialized ~= true,['dsp:system',...
                ':AsyncBuffer:isInitialized']);
            
            [out,underrun,~,~] = obj.ReadSamplesFromBuffer(obj,numRows,overlap);
        end
        function [out,underrun] = read(obj,numRows,overlap)
            %READ Read from buffer
            % out = read(Q) returns all unread samples in buffer.
            %
            % out = read(Q,NumRows) returns NumRows samples from each
            %   channel (column) of buffer. If the requested number of
            %   samples is greater than the number of unread samples, the
            %   output is zero-padded.
            %
            % out = read(Q,NumRows,Overlap) returns NumRows samples from
            %   each channel and overlaps previously read samples by
            %   Overlap. The total number of samples read is NumRows *
            %   (number of channels). The total number of new samples read
            %   is (NumRows - Overlap) * (number of channels). If the
            %   overlap portion read contains samples that are
            %   overwritten, and are therefore not contiguously written,
            %   the output is zero-padded.
            %
            % [out,nUnderrun] = read(Q,...) additionally returns the
            %   number of rows zero-padded if underrun occurred. Underrun
            %   occurs if you attempt to read more samples than available.
            %   Samples zero-padded in overlapped portions are not counted
            %   as underrun.
            
            %--------------------------------------------------------------
            % Return error if buffer not initialized ----------------------
            coder.internal.errorIf(obj.isInitialized ~= true,['dsp:system',...
                ':AsyncBuffer:isInitialized']);
            %--------------------------------------------------------------
            
            % Write properties to local variables--------------------------
            
            wPtr            = obj.WritePointer;
            oneCast         = int32(1);
            zeroCast        = int32(0);
            % -------------------------------------------------------------
            [out, underrun,overlapUnderrun,c] = obj.ReadSamplesFromBuffer(obj,numRows,overlap);
            % If underrun occurred, adjust pointers ---
            if underrun ~= zeroCast
                rPtr = wPtr - oneCast;
            elseif overlapUnderrun ~= zeroCast
                rPtr = c;
            else
                rPtr = c;
            end
            % Update properties--------------------------------------------
            obj.CumulativeUnderrun = obj.CumulativeUnderrun + underrun;
            obj.ReadPointer        = rPtr;
            %--------------------------------------------------------------
        end
        
        function unreadSamples = get.NumUnreadSamples(obj)
            if obj.ReadPointer < obj.WritePointer
                unreadSamples = obj.WritePointer - obj.ReadPointer - int32(1);
            elseif obj.ReadPointer == obj.WritePointer
                unreadSamples = obj.Capacity;
            else
                unreadSamples = obj.Capacity - obj.ReadPointer + obj.WritePointer;
            end
        end
    end
    
    %----------------------------------------------------------------------
    % Hidden Static methods
    %----------------------------------------------------------------------
    methods (Hidden, Static)
        function flag = isAllowedInSystemBlock(~)
            flag = false;
        end
        
        function [out,underrun,overlapUnderrun,c] = ReadSamplesFromBuffer(obj,numRowsCast,overlapCast)
            oneCast         = int32(1);
            zeroCast        = int32(0);
            rPtr            = obj.ReadPointer;
            wPtr            = obj.WritePointer;
            underrun        = zeroCast;
            overlapUnderrun = zeroCast;
            capCheck        = obj.Capacity;
            cap             = capCheck + oneCast;
            

            % -------------------------------------------------------------
            
            % Push read pointer forward one and wrap if necessary ---------
            rPtr = rPtr + oneCast;
            if rPtr > cap
                rPtr = oneCast;
            end
            % -------------------------------------------------------------
            
            % Force coder to recognize pointers are bounded ---------------
            if (wPtr<oneCast) || (wPtr>cap) || (rPtr<oneCast) || (rPtr>cap) || (numRowsCast>cap)
                % This if-statement is required for codegen with dynamic
                % memory allocation set to false.  This if-statement cannot
                % be hit due to dsp.AsyncBuffer's internal book-keeping
                % of read and write pointers, so the error message does not
                % need to be in the message catalog.
                error('Pointers must be bounded.')
            end
            % -------------------------------------------------------------
            
            % Calculate read index and then read from cache ---------------
            if overlapCast == zeroCast
                c = rPtr + numRowsCast - oneCast;
                
                if (c>cap)                                %  |-------r---| c
                    c = c - cap;
                    readIdx = [rPtr:cap,oneCast:c];       %  |---c---r---|
                    
                    if (rPtr <= wPtr)                     %  |---c---r-w-|
                        underrun = cap - wPtr + oneCast + c;
                    elseif (wPtr<=c)                      %  |-w-c---r---|
                        underrun = c - wPtr + oneCast;
                    end
                    
                else                                      %  |---r---c---|
                    readIdx = rPtr:c;
                    
                    if (rPtr<=wPtr)&&(wPtr<=c)            %  |---r-w-c---|
                        underrun = c - wPtr + oneCast;
                    end
                end
            else % case: overlap ~= 0
                a = rPtr - overlapCast;
                c = rPtr - overlapCast + numRowsCast - oneCast;
                if (a<1)                               % a|---r---c-------|
                    a = a + cap;
                    readIdx = [a:cap,oneCast:c];       %  |---r---c---a---|
                    
                    if (rPtr<=wPtr)&&(wPtr<=c)         %  |---r-w-c---a---|
                        underrun = c - wPtr + oneCast;
                    elseif (wPtr<rPtr)                 %  |-w-r---c---a---|
                        overlapUnderrun = (cap - a + oneCast) + wPtr;
                    elseif (wPtr>a)                    %  |---r---c---a-w-|
                        overlapUnderrun = wPtr - a + oneCast;
                    end
                    
                elseif (c>cap)                         %  |------a---r---| c
                    c = c - cap;
                    readIdx = [a:cap,oneCast:c];       %  |---c---a---r---|
                    
                    if (rPtr<=wPtr)                    %  |---c---a---r-w-|
                        underrun = cap - wPtr + oneCast + c;
                    elseif (wPtr<=c)                   %  |-w-c---a---r---|
                        underrun = c - wPtr + oneCast;
                    elseif (a<wPtr)&&(wPtr<rPtr)       %  |---c---a-w-r---|
                        overlapUnderrun = wPtr - a + oneCast;
                    end
                    
                else                                   %  |---a---r---c---|
                    readIdx = a:c;
                    
                    if (rPtr<=wPtr)&&(wPtr<=c)         %  |---a---r-w-c---|
                        underrun = c - wPtr + oneCast;
                    elseif (a<=wPtr)&&(wPtr<rPtr)      %  |---a-w-r---c---|
                        overlapUnderrun = wPtr - a + oneCast;
                    end
                end
            end
            out = obj.Cache(readIdx,:);
            %--------------------------------------------------------------
            
            % If underrun occurred, zero-pad output -----------------------
            if underrun ~= zeroCast
                out(numRowsCast-underrun+oneCast:numRowsCast,oneCast:obj.CompiledNumChannels) = ...
                    zeros(underrun,obj.CompiledNumChannels,'like',out);
                
            elseif overlapUnderrun ~= zeroCast
                if overlapUnderrun == numRowsCast
                    out = zeros(overlapUnderrun,obj.CompiledNumChannels,'like',out);
                else
                    out(oneCast:overlapUnderrun,oneCast:obj.CompiledNumChannels) = ...
                        zeros(overlapUnderrun,obj.CompiledNumChannels,'like',out);
                end
            end
            assert(size(out,1) == numRowsCast);
        end
    end
end
