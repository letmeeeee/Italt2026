classdef FourthOrderSectionFiltercg < handle & ...
        matlab.mixin.internal.indexing.Paren
    %FOURTHORDERSECTIONFILTERCG Codegen class for
    %dsp.FourthOrderSectionFilter
        
    % Copyright 2018-2020 The MathWorks, Inc.
    
    %#codegen
    
    properties(Dependent)
        % Numerator - Numerator coefficients of size Lx5, where L is the
        % number of sections.
        Numerator
        % Denominator - Denominator coefficients of size Lx4, where L is
        % the number of sections.
        Denominator
    end
    
    properties (Access = private)
        % pStates Filter states. 4 states per section.
        pStates
    end
    
    properties (Hidden,SetAccess = private)
        %pFilter FOS filter system object used for codegen
        pFilter
    end
    
   
    %----------------------------------------------------------------------
    % Public methods
    %----------------------------------------------------------------------
    
    methods
        function obj = FourthOrderSectionFiltercg(varargin)
            obj.pFilter = dsp.internal.FourthOrderSectionFiltercgHelper(varargin{:});
        end
        %------------------------------------------------------------------
        function set.Numerator(obj,val)
            validateattributes(val,{'numeric'},{'finite','nonnan','2d',...
                'ncols',5},'set.Numerator','Numerator');
            obj.pFilter.Numerator = val;
        end
        
        function num = get.Numerator(obj)
            num = obj.pFilter.Numerator;
        end
        %------------------------------------------------------------------               
        function set.Denominator(obj,val)
            validateattributes(val,{'numeric'},{'finite','nonnan','2d',...
                },'set.Denominator','Denominator');
            
            obj.pFilter.Denominator = val;
        end
        
        function den = get.Denominator(obj)
            den = obj.pFilter.Denominator;
        end
        %------------------------------------------------------------------
    end
    
    methods (Hidden, Access = public)
        function y = step(obj,x)                        
            y = step(obj.pFilter,x);         
        end
        
        function reset(obj)
            reset(obj.pFilter);            
        end
        
        function s = clone(obj)
            s = clone(obj.pFilter);
        end
        
        function release(obj)
            release(obj.pFilter);
        end
        
        function setup(obj,x)
            setup(obj.pFilter,x);
        end
        
        function setNumChans(obj,val)
            setNumChans(obj.pFilter,val);
        end
    end
    
    %----------------------------------------------------------------------
    % Hidden, Sealed methods
    %----------------------------------------------------------------------
    methods  (Hidden=true,Sealed=true)
        function y = parenReference(obj,x)
            % This is used to enable stepping the object with function
            % notation.
            y = step(obj,x);
        end
        

    end
    %----------------------------------------------------------------------
    % Hidden and Static methods
    %----------------------------------------------------------------------
    
    methods (Static)
        function out = matlabCodegenToRedirected(~)
            out  = dsp.internal.FourthOrderSectionFiltercg;
        end
        
        function out = matlabCodegenFromRedirected(~)
            out = dsp.FourthOrderSectionFilter;
        end
              
    end
    methods (Hidden, Static)
        function name = matlabCodegenUserReadableName
            name = 'dsp.FourthOrderSectionFilter';
        end
    end
end