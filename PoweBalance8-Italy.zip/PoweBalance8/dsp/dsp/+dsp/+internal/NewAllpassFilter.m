classdef (StrictDefaults)NewAllpassFilter < matlab.System & dsp.internal.FilterAnalysis
    %AllpassFilter Single-section or cascaded allpass filter with
    %   Minimum-multiplier, Lattice, or Wave Digital structure
    %
    %   APF = dsp.AllpassFilter returns an allpass filter APF that filters
    %   each channel of the input signal independently using an allpass
    %   filter with the default structure and coefficients.
    %
    %   APF = dsp.AllpassFilter('PropertyName', PropertyValue, ...) returns
    %   an allpass filter, APF, with each specified property set to a
    %   specified value.
    %
    %   Step method syntax:
    %
    %   Y = step(APF, X) filters the real or complex input signal X using
    %   the specified filter to produce the output Y. Each column of X is
    %   treated and filtered independently as a separate channel over time.
    %
    %   AllpassFilter methods:
    %
    %   step                - See above description for use of this method.
    %   release             - Allow changes to non-tunable properties
    %                         values and input characteristics.
    %   clone               - Create an allpass filter object with the same
    %                         property values and internal states.
    %   isLocked            - Locked status (logical).
    %   reset               - Reset the internal states to initial
    %                         conditions.
    %
    %   AllpassFilter properties:
    %
    %   Structure                 - Internal allpass filter structure.    
    %   AllpassCoefficients       - Coefficients used with 'Minimum 
    %                               multiplier' structure.
    %   LatticeCoefficients       - Coefficients used with 'Lattice'
    %                               structure.
    %   WDFCoefficients           - Coefficients used with the 'Wave Digital
    %                               Filter' structure.
    %   TrailingFirstOrderSection - Is the last section first order.
    %
    %   This filter supports several filter analysis methods. For more
    %   information, type dsp.AllpassFilter.helpFilterAnalysis.
    %
    %   % EXAMPLE: Implement a lowpass filter using two allpass filters.
    %
    %     Fs  = 48000;    % in Hz
    %     FL = 1024;
    %     APF1 = dsp.AllpassFilter('AllpassCoefficients',...
    %                        [-0.710525516540603   0.208818210000029]);
    %     APF2 =  dsp.AllpassFilter('AllpassCoefficients',...
    %                        [-0.940456403667957   0.6;...
    %                         -0.324919696232907   0],...
    %                         'TrailingFirstOrderSection',true);    
    %     TFE = dsp.TransferFunctionEstimator('FrequencyRange',...
    %           'onesided','SpectralAverages',2);
    %     AP = dsp.ArrayPlot('PlotType','Line','YLimits', [-80 5],...
    %         'YLabel','Magnitude (dB)','SampleIncrement', Fs/FL,...
    %         'XLabel','Frequency (Hz)','Title','Magnitude Response',...
    %         'ShowLegend', true);
    %     tic;
    %     while toc < 5
    %         in  = randn(FL,1);
    %         out = 0.5.*(step(APF1,in) + step(APF2,in));        
    %         A = step(TFE, in, out);
    %         step(AP,db(A));
    %     end
    %
    %   See also dsp.CoupledAllpassFilter, dsp.BiquadFilter, dsp.IIRFilter,
    %   dsp.IIRHalfbandInterpolator, dsp.IIRHalfbandDecimator.
    
    %   Copyright 2015-2022 The MathWorks, Inc.
    
    %#codegen
    properties(Nontunable)
        %Structure Internal allpass structure
        %   Specify the internal allpass filter implementation structure as
        %   one of {'Minimum multiplier' | 'Wave Digital Filter' |
        %   'Lattice'}. Each structure uses a different coefficients set,
        %   independently stored in the corresponding object property
        Structure (1, :) char {matlab.system.mustBeMemberMessageID(Structure, ...
            {'dsp:system:AllpassFilter:Structure_Minimummultiplier'; ...
            'dsp:system:AllpassFilter:Structure_WaveDigitalFilter'; ...
            'dsp:system:AllpassFilter:Structure_Lattice'})} = 'Minimum multiplier';
    end
    
    properties
        %AllpassCoefficients Allpass polynomial coefficients
        %   Specify the real allpass polynomial filter coefficients. This
        %   property is only applicable when the Structure property is set
        %   to 'Mininimum multiplier'. The value of this property can be
        %   either a Nx1 or Nx2 matrix of N first or second-order allpass
        %   sections. The default value for this property is [-2^(-1/2)
        %   0.5]. This property is tunable.
        AllpassCoefficients = [-2^(-1/2), 1/2]
        
        %LatticeCoefficients Lattice allpass coefficients
        %   Specify the real or complex allpass coefficients as lattice
        %   reflection coefficients form. This property is only applicable
        %   when the Structure property is set to 'Lattice'. The value of
        %   this property can be either a row vector  or a column vector.
        %   The default value for this property is [-2^(1/2)/3, 1/2]. This
        %   property is tunable.
        LatticeCoefficients = [-2^(1/2)/3, 1/2]
    end
    
    properties(Nontunable)
        %WDFCoefficients Wave Digital Filter allpass coefficients
        %   Specify the real allpass coefficients in Wave Digital Filter
        %   form. This property is only applicable when the Structure
        %   property is set to 'Wave Digital Filter'. The value of this
        %   property can be either a Nx1 or Nx2 matrix of N first or
        %   second-order allpass sections.  All elements must have absolute
        %   value <= 1. The default value for this property is [1/2,
        %   -2^(1/2)/3]. 
        WDFCoefficients = [1/2, -2^(1/2)/3]
    
        %TrailingFirstOrderSection Indicate if last section is first order
        %   For the minimum-multiplier structure, specify whether the last
        %   section is a first order section (true) or whether it is a
        %   second order section (false). The default is false.
        TrailingFirstOrderSection (1, 1) logical = false
    end
        
    properties(Access = private)

        PrivCoefficients
        
        %InputFloatProto holds a lightweight prototype of the input signal
        % for the purpose of casting the filter coefficients to the right
        % data type. This property is set at setup, used at coefficients
        % tuning.
        InputFloatProto
                               
        NumChannels = int32(1)
        
        % Initial conditions cast to input datatype
        %   Specify the initial value of the internal filter states. The
        %   default value of this property is 0. Acceptable values include
        %   numeric scalar, numeric 1-D or 2-D array, and 3-D array where
        %   the length of the third dimension corresponds to the number of
        %   filter sections. The numeric scalar is used for all filter
        %   states, and the numeric 1-D or 2-D array is single-section
        %   only.
        pInitialConditions
        
        % Define any discrete-time states
        %States Holds internal filter states within a zero-padded
        %  3-D array of size (maxStatesPerSection x numChannels x
        %  numSections).
        States
    end
    
    properties(Nontunable,Access = private)
        privNumChannels

        %PrivWDFStageTypes Internal WDF stage type (WDF structure-specific)
        % This property is only applicable when the Structure property is
        % set to 'Wave Digital Filter'.
        PrivWDFStageTypes = 1
    
        privTrailingFirstOrderSection (1, 1) logical = false        
    end
    
    methods
        
        % Constructor
        
        function obj = NewAllpassFilter(varargin)       
            % Support name-value pair arguments
            setProperties(obj, nargin, varargin{:});
            
            obj.NumChannels = int32(-1);
        end
        
        % Accessor methods
        
        function set.AllpassCoefficients(obj, value)        
            validateattributes(value, {'numeric'}, ...
                {'finite','real'},...
                'set.AllpassCoefficients','AllpassCoefficients');
            [r,c] = size(value);
            if (r >= 1) && (c > 2)
                coder.internal.errorIf(true, ['dsp:system',...
                    ':AllpassFilter:coeffSize']);
            end
            
            clearMetaData(obj)
            obj.AllpassCoefficients = value;
            
        end
        
        function set.LatticeCoefficients(obj, value)        
            validateattributes(value, {'numeric'}, ...
                {'finite'},...
                'set.LatticeCoefficients','LatticeCoefficients');
            
            if ~isempty(value) && ~isvector(value)
                
                coder.internal.errorIf(true, ['dsp:system',...
                    ':AllpassFilter:latticeCoeffSize']);
            end
            clearMetaData(obj)
            obj.LatticeCoefficients = value;
        end
        
        function set.WDFCoefficients(obj, value)
            validateattributes(value, {'numeric'}, ...
                {'finite', 'real'},'set.WDFCoefficients', 'WDFCoefficients')
            
            [~,c] = size(value);
            coder.internal.errorIf(c > 2, ['dsp:system',...
                ':AllpassFilter:wdfcoeffSize']);
            coder.internal.errorIf(any(any(abs(value) > 1)), ['dsp:system',...
                ':AllpassFilter:wdfCoeBiggerThanOne']);
            clearMetaData(obj);
            obj.WDFCoefficients = value;
            
        end
    end
    
    methods (Access = protected)
        
        % Relevant to matlab.System
        
        function processTunedPropertiesImpl(obj)        
            
            
            inProto = obj.InputFloatProto;
            
            % Cast coefficients to the right data type and recompute
            % section orders.
            newCoe  = setupCoefficients(obj, inProto);
            
            if isempty(coder.target)
                % Check that orders hasn't changed
                if ~isequal(size(obj.PrivCoefficients),size(newCoe))
                    coder.internal.errorIf(true, ['dsp:system',...
                        ':AllpassFilter:noChangeNumOfSections']);
                end
            end
            
            % Save new coefficients values
            obj.PrivCoefficients = newCoe;
        end
        
        function setupImpl(obj, u)          
            inPrototype = obj.getPrototype(u);
            
            obj.pInitialConditions = cast(0,class(u));
            
            ic = obj.pInitialConditions;
            % *** Coefficients SETUP ***
            
            % Parse user-provided coefficients and cast to the right
            % data type and complexity.
            [coe, types] = setupCoefficients(obj, inPrototype);
            
            % Save property values relevant to coefficients.
            obj.PrivCoefficients = coe;
            obj.PrivWDFStageTypes = types;
            
            % privTrailingFirstOrderSection SETUP
            [r,c] = size(coe);            
            
            if obj.TrailingFirstOrderSection || (r==1 && c==1)
                obj.privTrailingFirstOrderSection = true;
            end
            
            % *** States SETUP ***
            
            % Get system dimensions.
            numChannels = int32(getNumChs(obj,u));
            numSections = r;

            % Allocate internal states.
            switch(obj.Structure)
                case 'Minimum multiplier'
                    % Minimum multiplier case needs twice as many states
                    tmpstates = zeros(2*c, numChannels, numSections,'like',u);
                case 'Lattice'
                    tmpstates = zeros(length(coe), numChannels, numSections,'like',u);
                case 'Wave Digital Filter'
                    tmpstates = zeros(c, numChannels, numSections,'like',u);
            end

            % Allocate internal states.
            states = cast(tmpstates,'like',coe);
            
            % Most checks performed by validatePropertiesImpl
            % Check here that number of channels in InitialConditions is
            % equal to that of States.
            icSimpleScalar = isscalar(ic);
            icAndStatesColumnsMatch = size(ic, 2) == size(states,2);
            if(~icSimpleScalar) && (~icAndStatesColumnsMatch)
                % Inner arrays within InitialConditions  must have as many
                % columns as input signals to the filter
                coder.internal.errorIf(true, ['dsp:system',...
                    ':AllpassFilter:initCondCellInnerColsToMatchChannels'])
            end
            
            % Save property values relevant to internal states.
            obj.States = states;
            obj.InputFloatProto = inPrototype;

            obj.NumChannels = numChannels;
            obj.privNumChannels = numChannels;
        end
        
        function releaseImpl(obj)       
            obj.NumChannels = int32(-1);
        end
        
        function resetImpl(obj)     
            % Cache initial conditions and internal states.
            ic = obj.pInitialConditions;
            states = obj.States;
            [maxStatesPerSection, numChannels, numSections] = size(states);
            
            % Reset states using different approaches based on size of
            % initial conditions.
            obj.States = ic.*ones(maxStatesPerSection, numChannels, numSections,'like',states);
            
        end
        
        function x = stepImpl(obj, u)       
            Z     = obj.States;
            coefs = obj.PrivCoefficients;
            if ~isreal(coefs)
                x = cast(u,'like',coefs);
            else
                x = u;
            end
            LFO   = obj.privTrailingFirstOrderSection; % Has trailing 1st order section (true/false)
            
            switch obj.Structure
                case 'Minimum multiplier'
                    % ----- Minimum multiplier implementation
                    nCoefsPerSection  = size(coefs,2);
                    zTop              = Z(1:nCoefsPerSection, :, :);
                    zBottom           = Z(nCoefsPerSection+1:2*nCoefsPerSection, :, :);
                    
                    [x, zTop,zBottom] = dsp.internal.AllpassMinMult.stepMultipleSections(real(coefs),x,zTop,zBottom,LFO);
                    
                    Z(1:nCoefsPerSection, :, :)                    = zTop;
                    Z(nCoefsPerSection+1:2*nCoefsPerSection, :, :) = zBottom;
                    % ----- End of Minimum multiplier implementation
                case 'Lattice'
                    numSections = size(Z, 3);
                    Nchan       = obj.privNumChannels;
                    % ----- Lattice implementation
                    for kS = 1:numSections
                        
                        z = Z(:,1:Nchan,kS);
                        
                        [x, z] = obj.latticeSingleSection(coefs, x, z);
                        
                        Z(:,1:Nchan,kS) = z;
                    end
                    % ----- End of Lattice implementation
                    
                case 'Wave Digital Filter'
                    % ----- WDF implementation
                    % Reference: 
                    % M. Lutovac, D. Tosic, B. Evans.
                    % Filter Design for Signal Processing using MATLAB and
                    % Mathematica. Prentice Hall, 2001.
                    
                    numSections = size(Z, 3);% Number of sections
                    L = size(coefs,2); %filter order 
                    T = obj.PrivWDFStageTypes;
                    
                    for kS = 1:numSections
                       if  LFO && (kS == numSections)
                           L = 1;
                       end
                        a = coefs(kS, :);
                        types = T(kS, :);
                        z = Z(:,:,kS);

                        [x, z] = dsp.internal.WaveDigitalFilter.filterSingleSection(a, types, x, z, L,obj.privNumChannels);

                        Z(:,:,kS) = z;
                    end
                    % ----- End of WDF implementation
                otherwise
                    assert(false);
            end
            obj.States = Z;
            
        end
        
        function validateInputsImpl(obj, u)         
            % Invoked at first call to setup/step, and then every time the
            % input dimensions change
            validateattributes(u, {'single', 'double'}, {'2d'},'','');
            
            if obj.NumChannels ~= -1
                coder.internal.errorIf(size(u,2) ~= obj.NumChannels, ['dsp:system',...
                    ':Shared:numChannels']);
            end
            
            % Cache input data type for filter analysis
            if isempty(coder.target)
                if ~isempty(u)
                    cacheInputDataType(obj,u)
                end
            end
        end
        
        function flag = isInactivePropertyImpl(obj, propertyName)   
            flag = false;
            if(strcmp(propertyName, 'AllpassCoefficients'))
                flag = ~strcmp(obj.Structure, 'Minimum multiplier');
            elseif(strcmp(propertyName, 'TrailingFirstOrderSection'))
                flag = ~( strcmp(obj.Structure, 'Minimum multiplier') || ...
                    strcmp(obj.Structure, 'Wave Digital Filter'));
            elseif(strcmp(propertyName, 'WDFCoefficients'))
                flag = ~strcmp(obj.Structure, 'Wave Digital Filter');
            elseif(strcmp(propertyName, 'LatticeCoefficients'))
                flag = ~strcmp(obj.Structure, 'Lattice');
            end
        end
        
        function s = saveObjectImpl(obj)            
            % Default implementation saves all public properties
            s = saveObjectImpl@matlab.System(obj);
            
            if isLocked(obj)
                % All the following are set at setup
                s.States = obj.States;
                s.PrivCoefficients = obj.PrivCoefficients;
                
                s.InputFloatProto = obj.InputFloatProto;                
                % This ensures analysis has all needed information in
                % floating-point mode
                s.pLockedArithmetic = obj.pLockedArithmetic;
                s.NumChannels = obj.NumChannels;
                s.privNumChannels = obj.privNumChannels;
                s.PrivWDFStageTypes = obj.PrivWDFStageTypes;
                s.privTrailingFirstOrderSection = obj.privTrailingFirstOrderSection;
                s.pInitialConditions = obj.pInitialConditions;
            end
            % Save filter analysis class properties
            s = saveFA(obj, s);
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)      
            % Re-load state if saved version was locked
            if wasLocked
                % All the following were set at setup
                obj.States = s.States;
                obj.PrivCoefficients = s.PrivCoefficients;
                
                obj.InputFloatProto = s.InputFloatProto;                
                % This ensures analysis has all needed information in
                % floating-point mode
                obj.pLockedArithmetic = s.pLockedArithmetic;
                obj.NumChannels = s.NumChannels;
                obj.privNumChannels = s.privNumChannels;
                obj.privTrailingFirstOrderSection = s.privTrailingFirstOrderSection;
                if isfield(s, 'PrivWDFStageTypes') %prop started in 16a.
                    obj.PrivWDFStageTypes = s.PrivWDFStageTypes;
                else
                    obj.PrivWDFStageTypes = 1;  %pre 16a
                end
                
                if isfield(s, 'pInitialConditions') %prop started in 18a.
                    obj.pInitialConditions = s.pInitialConditions;
                else
                    obj.pInitialConditions = 1;  %pre 18a
                end

            end
            
            % Call base class method
            loadObjectImpl@matlab.System(obj,s,wasLocked);
            
            % Load filter analysis class properties
            loadFA(obj, s, wasLocked);
        end
        
        function y = infoImpl(obj,varargin)     
            y = infoFA(obj,varargin{:});
        end

        function flag = isInputSizeMutableImpl(~,~)
            % Support mutable input size
            flag = true;
        end  
        
        % Relevant to dsp.internal.FilterAnalysis
        
        function d = convertToDFILT(obj, arith)         
            % Returns equivalent dfilt to current object.
            
            % Fixed-point analysis is not currently supported
            assert(strcmpi(arith,'single') || strcmpi(arith,'double'))
            
            % You want to use typed coefficients available to the step
            % method to construct the equivalent dfilt. If setup has not
            % been run yet, then parse and cast the coefficients provided
            % by the user.
            if(isLocked(obj))
                coe = obj.PrivCoefficients;
                types = obj.PrivWDFStageTypes;
            else
                [coe, types] = setupCoefficients(obj, []);
            end
            
            % Depending on structure, set relevant string for dfilt cascade
            % sections and for WDF structure convert back coefficients to
            % polynomial allpass form, as accepted by dfilt.wdfallpass
            switch obj.Structure
                case 'Minimum multiplier'
                    ssname = 'allpass';
                    
                case 'Wave Digital Filter'
                    ssname = 'wdfallpass';
                    
                case 'Lattice'
                    ssname = 'latticeallpass';
                    
                otherwise
                    assert(false)
                    ssname = '';
            end
            
            % Create empty cascade dfilt.
            d = dfilt.cascade;
            % The default cascade object comes with two dummy sections.
            % First remove them:
            d.removestage(1:2);
            % then, add actual sections (iterate through sections of obj).
            if(~isempty(coe))
                for k = 1:size(coe, 1)
                    L = length(coe(k,:));
                    if L == 2 && (k == size(coe, 1)) && obj.TrailingFirstOrderSection
                        L = 1;                    
                    end
                    c = double(coe(k, 1:L));
                    if strcmp(obj.Structure, 'Wave Digital Filter')
                       t = types(k,1:L);
                       order = size(c,2);
                        % c here hold WDF alpha coefficients - two conversion steps
                        % needed: alpha to WDF, then WDF to allpass polynomial
                        w = dsp.internal.WaveDigitalFilter.alpha2wdf(c, order, t);
                        c = dsp.internal.WaveDigitalFilter.wdf2allpass(w, order);
                    end
                    
                    if(~isempty(c))
                        thissection = dfilt.(ssname)(c);
                    else
                        thissection = dfilt.(ssname);
                    end
                    
                    if(strcmp(ssname, 'latticeallpass'))
                        thissection.Arithmetic = arith;
                    end
                    
                    d.addstage(thissection);
                end
            else
                thissection = dfilt.(ssname);
                d.addstage(thissection);
            end
            
        end
        
        
        function [d, inputsCell] = parseArithmetic(...
                obj,inputsCell,forceToDouble,noDfilt)
            % This overrides the same method of dsp.internal.FilterAnalysis
            
            % Parse arithmetic input
            % Inputs:
            %
            % inputsCell    - cell containing PV-pairs. The method will look
            %                 for the 'Arithmetic' input, parse its value and
            %                 delete the PV-pair from the cell. It will
            %                 return the modified cell in the second output,
            %                 inputsCell.
            % forceToDouble - If true, force arithmetic to 'double'
            %                 regardless of the 'Arithmetic' input
            % noDfilt       - If true, do not generate a dfilt object from
            %                 the System object and return the parsed
            %                 arithmetic string instead of the dfilt object
            %                 in the first output, d.
            
            idx = [];
            if nargin > 1
                idx = find(strcmpi(inputsCell,'arithmetic'));
            end
            
            forceToDoubleFlag = nargin > 2 && forceToDouble;
            
            if ~isempty(idx)
                idx = idx(1);
                if (length(inputsCell)>= idx+1 &&...
                        ~any(strcmpi({'double','single','fixed'},...
                        inputsCell{idx+1}))) || ...
                        length(inputsCell)< idx+1  
                    
                    coder.internal.errorIf(true, ['dsp:dsp:private',...
                        ':FilterSystemObjectBase:InvalidArithmeticInput'])
                end
                
                arith = inputsCell{idx+1};  
                
                if strcmpi(arith, 'fixed')
                    
                    % AllpassFilter does not supports fixed-point analysis
                    coder.internal.errorIf(true, ['dsp:system',...
                        ':AllpassFilter:fixedAnalysisNotSupported'])
                    
                end
                
                % arith single but object has other Structure than 'Lattice':
                % no analysis possible - dfilt.allpass and dfilt.wdfallpass
                % only support doubles
                if(strcmpi(arith, 'single') && ...
                        ~strcmp(obj.Structure,'Lattice'))
                    coder.internal.errorIf(true, ['dsp:system',...
                        ':AllpassFilter:onlyDoubleAnalysisSupported'])
                end
                
                inputsCell([idx idx+1]) = [];
            else
                if isLocked(obj)
                    assert(strcmpi(obj.pLockedArithmetic,'single') || ...
                        strcmpi(obj.pLockedArithmetic,'double'))
                    if(strcmpi(obj.pLockedArithmetic, 'single') && ...
                            ~strcmp(obj.Structure,'Lattice'))
                        % Could not run the requested analysis. When
                        % 'Structure' is set to 'Minimum multiplier' or
                        % 'Wave Digital Filter', AllpassFilter only
                        % supports double-precision analysis
                        coder.internal.errorIf(true, ['dsp:system',...
                            ':AllpassFilter:onlyDoubleAnalysisSupported'])
                    end
                    arith = obj.pLockedArithmetic;
                else
                    arith = 'double';
                end
            end
            
            if forceToDoubleFlag
                arith = 'double';
            end
            
            noDfiltFlag = false;
            if nargin > 3 && noDfilt
                noDfiltFlag = noDfilt;
            end
            
            % Convert System object to dfilt using the parsed arithmetic
            if noDfiltFlag
                % If no dfilt is requested then we return the parsed
                % arithmetic value
                d = arith;
            else
                d = todfilt(obj,arith);
            end
        end
        
        function coe = getCoefficients(obj)     
            switch obj.Structure
                case 'Minimum multiplier'
                    coe = obj.AllpassCoefficients;
                case 'Lattice'
                    coe = obj.LatticeCoefficients;
                case 'Wave Digital Filter'
                    coe = obj.WDFCoefficients;
            end
        end
        
        function sz = getNumChs(~,u)
           
            sz = size(u,2);
            
        end
        
        
    end
    
    methods(Access = private)
        
        % Instance-specific coefficient-management utilities
        
        function [coeCast, typesCast] = setupCoefficients(...
                obj, inputPrototype)                                
            
            % Get user-provided coefficients relevant to current structure.
            coe = getCoefficients(obj);
            
            if(isempty(inputPrototype))
                inputPrototype = obj.getPrototype(coe);
            end
            
            % Transform (WDF only) and cast
            if(strcmp(obj.Structure, 'Wave Digital Filter'))
                % Convert WDFCoefficients to Alpha and Types.
                % and cast them to right type into PrivCoefficients
                [types, alphas] = dsp.internal.WaveDigitalFilter.wdf2alpha(coe, ...
                    obj.TrailingFirstOrderSection);
                % Convert coefficients to data type of input.
                [coeCast, typesCast] = castCoefficients(...
                    inputPrototype, alphas, types);
            else
                % Convert coefficients to data type of input.
                coeCast = cast(coe, 'like', inputPrototype);
                typesCast = [];  
            end
        end
    end
    
    methods (Hidden, Static)
        
        function outproto = getPrototype(varargin)          
            % p = dsp.AllpassFilter.getPrototype(x) returns a lightweight
            %   prototype for the numerical variable x. x can be a
            %   - Numeric array (empty or non-empty)
            %   - Cell array with numeric arrays is all cells
            %   For valid cell arrays outproto is complex if at least one
            %   cell has complex content and it has the numeric class of
            %   the content in the first cell
            %   If x is none of the above then outproto = [].
            % p = dsp.AllpassFilter.getPrototype(x, y) returns a prototype
            %   based on the product of x and y if they are both valid
            %   numeric or cell arrays (see above)
            %   If any of the two has complex prototype the result is still
            %   complex even if all input imaginary parts were 0.
            %   For valid inputs the value of outproto is either 1 or 1+0i.
            %   If any of x or y is not a valid option then outproto = []
            
            
            % Only one or two inputs allowed.
            assert((nargin == 1) || (nargin == 2))
            
            x = varargin{1};
            outproto = dsp.internal.NewAllpassFilter.getNumericPrototype(x);
            if(isempty(outproto))
                coder.internal.warning(...
                    'dsp:system:AllpassFilter:badTypeForProto')
                return
            end
            
            if(nargin == 1)
                return
            end
            
            y = varargin{2};
            yproto = dsp.internal.NewAllpassFilter.getNumericPrototype(y);
            if(isempty(yproto))
                outproto = yproto;
                coder.internal.warning(...
                    'dsp:system:AllpassFilter:badTypeForProto')
                return
            end
            
            % Take care of data type propagation first
            dtproto = outproto * yproto;
            % Set complexity right
            if(~isreal(outproto) || ~isreal(yproto))
                % Any of the two complex: result should be complex
                % dtroto so far is always real: add 0 imag part
                cplxproto = complex(dtproto);
                outproto = cplxproto;
            else
                % Both x and y real
                outproto = dtproto;
            end
            
        end
    end
    
    methods (Access = private, Static)
        
        % Filtering routines - all used by stepImpl
        
        function [u, Z] = latticeSingleSection(k, u, Z)         
            
            % Local assumptions:
            order = length(k);
            nc = size(Z,2);
            if(order > 0)
                
                for t = 1:size(u, 1)
                    
                    % Preallocate top lattice path - simply set to Z for
                    % efficiency. All tmp will be overwritten
                    tmp = Z;
                    
                    % Step 1 -  tmp holds the values at the nodes of the
                    %           stateless instantaneous top lattice path
                    for kCh = 1:size(Z,2)
                        tmp2 = u(t, kCh);
                        for idx = order:-1:1
                            tmp(idx, kCh) = tmp2 - k(idx) * Z(idx, kCh);
                            tmp2 = tmp(idx, kCh);
                        end
                        u(t, kCh) = tmp2;
                    end
                    
                    % Loop top branch and bottom branch at the end of the
                    % lattice
                    sectionReturn = u(t, 1:nc);
                    
                    % Step 2 -  Bottom path of the lattice, where the
                    %           states are.
                    %           tmp now to hold the outputs of all the sum
                    %           units in the bottom path.
                    % (All 2d arrays here below are [order x numchannels])
                    % Manually loop through channels
                    for kCh = 1:size(Z,2)
                        tmp(:, kCh) = conj(k(:)).*tmp(:, kCh) + Z(:, kCh);
                    end
                    
                    % State update and output
                    Z = [sectionReturn; tmp(1:end-1, :)];
                    u(t, :) = tmp(end, :);
                    
                end
                
            end
            
        end

        % Data type and complexity handling for numerical arrays
        function proto = getNumericPrototype(value)         
            % Check that value is numeric
            if(isnumeric(value))
                vreal = isreal(value);
                vclass = class(value);
            else
                % If none of the above, return empty value for prototype
                proto = [];
                return
            end
            
            xp = ones(1, vclass);
            
            if(vreal)
                proto = xp;
            else
                proto = complex(xp);
            end
        end
    end

    methods(Hidden)
        function restrictionsCell = getFixedPointRestrictions(~,~)  
            restrictionsCell = {};
        end
        function props = getFixedPointProperties(~) 
            props = {};
        end
        function props = getNonFixedPointProperties(~)  
            props = {...
                'Structure',...
                'AllpassCoefficients',...
                'LatticeCoefficients', ...
                'WDFCoefficients'};
        end
        function flag = isPropertyActive(obj,prop)      
            flag = ~isInactivePropertyImpl(obj, prop);
        end
        
        function setActiveCoefficients(obj, coe)        
            switch obj.Structure
                case 'Minimum multiplier'
                    obj.AllpassCoefficients = coe;
                case 'Lattice'
                    obj.LatticeCoefficients = coe;
                case 'Wave Digital Filter'
                    obj.WDFCoefficients = coe;
                otherwise
                    assert(false)
            end
            
        end
        function coe = getActiveCoefficients(obj)  
            switch obj.Structure
                case 'Minimum multiplier'
                    coe = obj.AllpassCoefficients;
                case 'Lattice'
                    coe = obj.LatticeCoefficients;
                case 'Wave Digital Filter'
                    coe = obj.WDFCoefficients;
                otherwise
                    assert(false)
            end
            
        end
    end
    
end
function [coeCast, typesCast] = castCoefficients(...    
        dataTypePrototype, varargin)                    
    % Cast internal coefficient matrix to dataTypePrototype.
        assert(length(varargin) == 2)
        % For WDF structure, the coefficients to use at runtime are
        % the precomputed Alphas and the section Types
        alphas = varargin{1};
        types = varargin{2};
        coeCast = cast(alphas, 'like', dataTypePrototype);
        typesCast = cast(types, 'like', dataTypePrototype);
end
