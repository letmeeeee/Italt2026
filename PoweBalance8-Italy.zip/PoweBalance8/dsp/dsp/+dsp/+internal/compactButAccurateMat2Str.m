function decimalMatrixStr = compactButAccurateMat2Str(origNumberInDouble)
%compactButAccurateMat2Str Convert scalars, vectors and 2-d Matrices to
%                          strings that evaluate back to same 
%                          double-precision values.

% Copyright 2014-2019 The MathWorks, Inc.

% Find compact string for cases that are messy when crossing the
% decimal to/from binary canyon
% For example, 0.05 can't be represented perfectly in binary representations
% such as IEEE floating point representations.
% For proof of this try the following snippet of MATLAB code,
%   ideallyEqualButNotBecauseOfErrorInBinaryRep = ( 3*0.05 == 0.15 )

% Based on SimulinkFixedPoint.DataType.compactButAccurateNum2Str

origNumberInDouble = double(origNumberInDouble);
if all(isfinite(origNumberInDouble(:)))
    for numDecimalDigits = 15:19
        decimalMatrixStr = mat2str(origNumberInDouble,numDecimalDigits);
        if eval(decimalMatrixStr) == origNumberInDouble
            break
        end
    end
else
    % inf, -inf, nan are present: Need to go element-by-element
    [nRows, nCols] = size(origNumberInDouble);
    decimalMatrixStr = '[';
    for rowIdx = 1:nRows
        for colIdx = 1:nCols
            decimalMatrixStr = [decimalMatrixStr, ...
                 convertScalarToString(origNumberInDouble(rowIdx,colIdx)),', ']; %#ok<AGROW>
        end
        decimalMatrixStr  = [decimalMatrixStr(1:end-2), '; '];
    end
    decimalMatrixStr = [decimalMatrixStr(1:end-2), ']'];
end
end

function str = convertScalarToString(val)
    if ~isfinite(val)
        str = num2str(val);
    else
        for numDecimalDigits = 15:19
            str = num2str(val,numDecimalDigits);
            if eval(str) == val
                break
            end
        end
    end
end
