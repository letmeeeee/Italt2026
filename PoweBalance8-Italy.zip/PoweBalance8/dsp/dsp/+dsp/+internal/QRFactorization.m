classdef QRFactorization < matlab.System
    % QRFactorization Factor arbitrary matrix into unitary and upper
    % triangular components
    
    %   Copyright 2019-2023 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCLS>
    
    % Public, non-tunable properties
    properties(Nontunable)
        % outputSize Output size
        outputSize (1, :) char {matlab.system.mustBeMemberMessageID(outputSize, ...
                    {'dsp:system:QRFactorization:outputSize_Economy',;...
                    'dsp:system:QRFactorization:outputSize_Full'})} = 'Economy';
    end
    
    properties(Access = private, Nontunable)
        privOutputSizeOption;
    end
        
    methods
        %------------------------------------------------------------------
        % Constructor
        function obj = QRFactorization(varargin)
            % Support name-value pair arguments when constructing object
            setProperties(obj,nargin,varargin{:})
        end
    end
    
    methods(Access = protected)
        %------------------------------------------------------------------
        function setupImpl(obj,~)
            if(strcmpi(obj.outputSize,'Economy'))
                obj.privOutputSizeOption = coder.const(0);
            else
                obj.privOutputSizeOption = coder.const('vector');
            end
        end
        %------------------------------------------------------------------
        function [Q,R,E] = stepImpl(obj,u)
            % Implement algorithm. Calculate y as a function of input u and
            % discrete states.
            [Q,R,e] = qr(u,obj.privOutputSizeOption);
            E = cast(e,class(u));
        end
        %------------------------------------------------------------------
        % Backup/restore functions
        function s = saveObjectImpl(obj)
            % Set properties in structure s to values in object obj
            % Set public properties and states
            s = saveObjectImpl@matlab.System(obj);
            s.privOutputSizeOption = obj.privOutputSizeOption;
        end
        %------------------------------------------------------------------
        function loadObjectImpl(obj,s,wasLocked)
            % Set properties in object obj to values in structure s
            % Set public properties and states
            loadObjectImpl@matlab.System(obj,s,wasLocked);
            obj.privOutputSizeOption = s.privOutputSizeOption;
        end
    end
end
