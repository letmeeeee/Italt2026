function name = GetCompilerManufacturer(lang)
%

%   Copyright 2021 The MathWorks, Inc.

    name = mex.getCompilerConfigurations(lang).Manufacturer;
end