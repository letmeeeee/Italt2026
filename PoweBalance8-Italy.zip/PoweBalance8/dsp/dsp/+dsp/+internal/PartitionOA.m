classdef PartitionOA <  dsp.internal.PartitionOAOSBase
    
    % PartitionOA Partitioned overlap-add filter.
    % This class is used in dsp.FrequencyDomainFIRFilter
    
    % Copyright 2017-2022 The MathWorks, Inc.
    
    %#codegen
    methods
        function obj = PartitionOA(varargin)
            setProperties(obj,nargin,varargin{:});
        end
    end
    
    methods(Access = protected)
         function setupImpl(obj, u)
            
            if strcmp(obj.Domain,'Time')
                obj.pPartitionLength = obj.PartitionLength;
            else
                obj.pPartitionLength = (size(obj.Numerator,1)) / 2;
            end
            
            obj.pFFTLength         = cast(2 * obj.pPartitionLength ,class(u));
            obj.pLastSectionLength = obj.pPartitionLength;
            setupImpl@dsp.internal.PartitionOAOSBase(obj,u);
            if obj.pIsOutputReal
                obj.pLastSection = zeros(obj.pLastSectionLength,size(obj.pSum,3),class(u));
            else
                obj.pLastSection = zeros(obj.pLastSectionLength,size(obj.pSum,3),class(u)) + 1j * zeros(obj.pLastSectionLength,size(obj.pSum,3),class(u));
            end
        end
    end
    
    methods (Static)
        function [o,prevsec,sumY,p] = computeOutput(input,sumY,p,L0,numFrames,numchan,H,fftlen,P,K,prevsec,outIsReal,IsHalideEnabled)
            
            z     = input;
            x     = reshape(z,L0,numFrames,numchan);
            Xall  = fft(x, fftlen);
            
            if outIsReal
                o = zeros(L0*numFrames,numchan,class(input));
            else
                o = zeros(L0*numFrames,numchan,class(input)) + 1j * zeros(L0*numFrames,numchan,class(input)) ;
            end

            if isempty(coder.target)
                if IsHalideEnabled
                    Z = complex(zeros(fftlen, P, numchan, class(input)));
                    if isreal(H)
                        H = complex(H);
                    end
                end
            elseif coder.const(IsHalideEnabled) && coder.const(feval('dsp.enhancedsim.IsSysObjSimInCodeGen', coder.target))
                Z = complex(zeros(fftlen, P, numchan, class(input)));
                if isreal(H)
                    pH = complex(H);
                end
            end

            for frameIdx = 1:numFrames

                X = Xall(:,frameIdx,:);

                % Multiply fft of data with fft of all impulses
                % Sum it up. Use 'p' as the index to track circular
                % shift in columns of sumY

                if(isempty(coder.target))
                    if IsHalideEnabled
                        X1 = squeeze(complex(X));
                        dsp.internal.builtins.FrequencyDomainFIRFilter(2, X1, H, Z, fftlen, P, numchan);
                    else
                        Z = bsxfun(@times, H, X);
                    end
                else
                    if coder.const(IsHalideEnabled) && coder.const(feval('dsp.enhancedsim.IsSysObjSimInCodeGen', coder.target))

                        X1 = squeeze(complex(X));

                        if isreal(H)
                            Z = dsp.internal.FrequencyDomainFIRFilterCGSim("Partition", X1, pH, Z, fftlen, numchan, P);
                        else
                            Z = dsp.internal.FrequencyDomainFIRFilterCGSim("Partition", X1, H, Z, fftlen, numchan, P);
                        end

                    else
                        Z = bsxfun(@times, H, X);
                    end
                end

                sumY = sumY +  circshift(Z,-P+p-1,2);
                
                % IFFT of pth segment
                if outIsReal
                    ifftSumY = real(ifft(sumY(:,p,:),fftlen));
                else
                    ifftSumY = ifft(sumY(:,p,:),fftlen);
                end
                
                ifftSumY(1:K,:) = ifftSumY(1:K,:) + prevsec;
                prevsec = ifftSumY(fftlen - K + 1:end,:);
                
                
                % Select last L-K points
                o((frameIdx-1)*L0+1:L0*frameIdx,:) = ifftSumY(1:L0,:);
                
                % Set pth sum back to zero
                sumY(:,p,:) = zeros(fftlen,1,numchan);
                
                % p is the index for circular shift
                if p<P
                    p = p+1;
                else
                    p = cast(1,class(p));
                end
            end
        end
    end
    
end
