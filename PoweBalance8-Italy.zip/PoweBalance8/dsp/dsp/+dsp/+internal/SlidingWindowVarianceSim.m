classdef SlidingWindowVarianceSim < dsp.internal.AbstractSlidingWindowStatistic
    % SlidingWindowVarianceSimOverlap This class is internally used by
    % dsp.MovingVariance
    
    %   Copyright 2015-2021 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCLS>
    
    properties (Access = protected)
        InitialBufferValue = 0;
    end
    properties (Nontunable)
        HopSize (1, 1) {mustBePositive, mustBeInteger} = 1;
    end
    properties(Access = private)
        % pModValue 
        pModValue;
    end  
    
    methods
        function obj = SlidingWindowVarianceSim(varargin)
            setProperties(obj,nargin,varargin{:});
        end
    end
    
    methods(Access = protected)
        
        function y = computeStatistic(obj,u)
            yFullLength = movvar(u,obj.WindowLength,0,'Endpoints','discard');
            if obj.HopSize == 1
                y = yFullLength;
            else
                firstOut = mod(obj.HopSize-obj.pModValue,obj.HopSize)+1;
                y = yFullLength(firstOut:obj.HopSize:end,:);
                obj.pModValue = mod(obj.pModValue + size(yFullLength,1),obj.HopSize);   
            end
        end
        
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@dsp.internal.AbstractSlidingWindowStatistic(obj);
            if isLocked(obj)
                s.pModValue = obj.pModValue;
            end
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            if wasLocked && isfield(s,'pModValue')
                obj.pModValue = s.pModValue;
            end            
            loadObjectImpl@dsp.internal.AbstractSlidingWindowStatistic(obj, s, wasLocked);
        end
        function setupImpl(obj,u)
            % Setup the buffer
            obj.pBuffer = zeros(obj.WindowLength - 1,obj.NumChans,'like',u);
            obj.pModValue = 1;
        end        
        function resetImpl(obj)
            % Reset buffer
            obj.pBuffer = cast(obj.InitialBufferValue,class(obj.pBuffer)) * ones(size(obj.pBuffer),'like',obj.pBuffer);
            obj.pModValue = 1;
        end         
        
    end
end
