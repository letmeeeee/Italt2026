function paramStr = convertToChar(param)
% convert numerical param to string

% Copyright 2014-2020 The MathWorks, Inc.

paramStr = HelperConvertToString(param);
% Remove redundant spaces
while contains(paramStr,'  ')
    paramStr = strrep(paramStr,'  ',' ');
end

% ----------------------------------------------------------------------

function paramStr = HelperConvertToString(param)

if numel(param)==1
    paramStr = num2str(param,20);
    return;
end

if ~ismatrix(param) % ND
    dim = size(param);
    paramStrTemp = dsp.internal.convertToChar(reshape(param,numel(param),1));
    paramStr = sprintf('reshape(%s,[%s])',...
        paramStrTemp,...
        num2str(dim));
    return;
end

% Row vector
if size(param,1)==1
    paramStr = ['[' num2str(param,20) ']'];
    return;
end

% Matrix case
d1 = size(param,1);
d2 = size(param,2);
paramStr = '';
for i=1:d1
    for j=1:d2
        paramStr = sprintf('%s %s',paramStr,num2str(param(i,j),20));
    end
    if (i<d1)
        paramStr = sprintf('%s;',paramStr);
    end
end
paramStr = ['[' paramStr ']'];
