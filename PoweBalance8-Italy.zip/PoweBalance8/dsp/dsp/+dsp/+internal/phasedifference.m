function [phase,lastSample] = phasedifference(x,varargin)
%PHASEDIFFERENCE Compute phase difference of input
%   phase = phasedifference(x) returns the phase difference, p, between
%   consecutive samples of the input x. x must be a matrix. Each column of
%   x is treated as an independent channel. The initial sample used to
%   compute the first element of phase is assumed to be equal to 1.
%
%   phase = phasedifference(x,ic) uses ic for the initial sample. ic must
%   be a vector of length equal to the number of input channels.
%  
% 
%   [phase,lastSample] = phasedifference(x) returns lastSample, the last
%   sample in x. lastSample is a vector of length equal to the number of
%   input channels.
%
%   % Example
%   % Compute phase difference of input with three channels
%   x = exp(1j * [0.1 .2 .4;0 .8 .3;0.2 -.3 -0.1] * pi);
%   phase = dsp.internal.phasedifference(x) / pi

%   Copyright 2014-2020 The MathWorks, Inc.

%#codegen

if nargin==2
   lastSample = varargin{1}; 
else
   lastSample = ones(1,size(x,2),'like',x);
end

phase =  angle(x .* conj([lastSample;x(1:end-1,:)]));
lastSample = x(end,:);

end