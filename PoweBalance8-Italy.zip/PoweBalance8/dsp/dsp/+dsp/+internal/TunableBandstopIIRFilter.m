classdef TunableBandstopIIRFilter < dsp.internal.TunableBandpassBandstopIIRFilter
% TunableBandstopIIRFilter

%   Copyright 2022-2023 The MathWorks, Inc.

%#codegen
    methods(Access = protected)
        %------------------------------------------------------------------
        function [b,a,varargout] = designFilter(this)
            dt = this.OutputDataType;
            negOneCast = cast(-1, dt);
            twoCast = cast(2, dt);
            isScaleValueAllowed = this.HasScaleValues && this.pIsUsingSOS;
            if strcmpi(this.DesignMethod, 'Butterworth')
                if isScaleValueAllowed
                    [b,a,varargout{1}] = dsp.filterdesign.internal.iir.bpbsbutter(cast(this.FilterOrder, dt), cast(this.F3dB1, dt), cast(this.F3dB2, dt), twoCast, negOneCast, this.pIsUsingSOS, cast(this.MaxOrder, dt));
                else
                    [b,a] = dsp.filterdesign.internal.iir.bpbsbutter(cast(this.FilterOrder, dt), cast(this.F3dB1, dt), cast(this.F3dB2, dt), twoCast, negOneCast, this.pIsUsingSOS, cast(this.MaxOrder, dt));
                end
            elseif strcmpi(this.DesignMethod, 'Chebyshev Type I')
                if isScaleValueAllowed
                    [b,a,varargout{1}] = dsp.filterdesign.internal.iir.bscheby1(cast(this.FilterOrder, dt), cast(this.F3dB1, dt), cast(this.F3dB2, dt), cast(this.Apass, dt), twoCast, this.pIsUsingSOS, cast(this.MaxOrder, dt));
                else
                    [b,a] = dsp.filterdesign.internal.iir.bscheby1(cast(this.FilterOrder, dt), cast(this.F3dB1, dt), cast(this.F3dB2, dt), cast(this.Apass, dt), twoCast, this.pIsUsingSOS, cast(this.MaxOrder, dt));
                end
            else
                if isScaleValueAllowed
                    [b,a,varargout{1}] = dsp.filterdesign.internal.iir.bscheby2(cast(this.FilterOrder, dt), cast(this.F3dB1, dt), cast(this.F3dB2, dt), cast(this.Astop, dt), twoCast, this.pIsUsingSOS, cast(this.MaxOrder, dt));
                else
                    [b,a] = dsp.filterdesign.internal.iir.bscheby2(cast(this.FilterOrder, dt), cast(this.F3dB1, dt), cast(this.F3dB2, dt), cast(this.Astop, dt), twoCast, this.pIsUsingSOS, cast(this.MaxOrder, dt));
                end
            end
        end
    end
end
