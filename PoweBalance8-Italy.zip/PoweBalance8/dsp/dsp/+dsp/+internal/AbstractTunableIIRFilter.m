classdef AbstractTunableIIRFilter < matlab.System
% AbstractTunableIIRFilter Tunable IIR filter

%   Copyright 2022-2023 The MathWorks, Inc.

%#codegen
    properties
        %FilterOrder Filter order
        %   Specify the order filter, as a finite positive integer scalar.
        %   The default value of this property is 6. This property is
        %   tunable.
        FilterOrder = 6
        %Apass Passband ripple (dB)
        %   Specify the amount of ripple allowed in the passband in dB. The
        %   default is 1. This property is tunable.
        Apass = 1;
        %Astop Stopband attenuation (dB)
        %   Specify the attenuation in the stop band in dB. The default is
        %   60. This property is tunable.
        Astop = 60;
    end

    properties(Nontunable)
        %MaxOrder Filter maximum order
        %   Specify the filter maximum order as a finite positive integer
        %   scalar. The default value is 10.
        MaxOrder = 10
        %DesignMethod Design method
        %   Specify the filter design method as one of ["Butterworth" |
        %   "Chebyshev Type I" | "Chebyshev Type II"]. The default is
        %   "Butterworth".
        DesignMethod (1, :) char {matlab.system.mustBeMemberMessageID(DesignMethod, ...
            {'dsp:system:TunableIIRFilter:DesignMethod_Butterworth'; ...
            'dsp:system:TunableIIRFilter:DesignMethod_ChebyshevTypeI'; ...
            'dsp:system:TunableIIRFilter:DesignMethod_ChebyshevTypeII'})} = 'Butterworth';
        %OutputDataType Output data type
        %   Specify the output data type as "single" or "double". The
        %   default is "double".
        OutputDataType (1, :) char {matlab.system.mustBeMemberMessageID(OutputDataType, ...
            {'dsp:system:TunableIIRFilter:OutputDataType_double'; ...
            'dsp:system:TunableIIRFilter:OutputDataType_single'})} = 'double';
        %HasScaleValues Has scale values
        %   Specify if design has scale values for each section.
        HasScaleValues (1, 1) logical = false;
    end

    properties(Access = protected)
        num;
        den;
        gain;
        isInit = false;
    end

    methods
        %------------------------------------------------------------------
        % Constructor
        function this = AbstractTunableIIRFilter(varargin)
            % Support name-value pair arguments when constructing object
            setProperties(this,nargin,varargin{:})
        end
        %------------------------------------------------------------------
        function set.FilterOrder(this, value)
            validateFilterOrder(this, value, false);
            this.FilterOrder = value;
        end
        %------------------------------------------------------------------
        function set.MaxOrder(this, value)
            validateMaxOrder(this, value);
            this.MaxOrder = value;
        end
        %------------------------------------------------------------------
        function set.Apass(this, value)
            validateApass(this, value);
            this.Apass = value;
        end
        %------------------------------------------------------------------
        function set.Astop(this, value)
            validateAstop(this, value);
            this.Astop = value;
        end
    end

    methods(Access = protected)
        %------------------------------------------------------------------
        function setupImpl(this)
            % Perform one-time calculations, such as computing constants
            %coder.extrinsic('getCoefficientsDimensions');
            dims = getCoefficientsDimensions(this);
            dt = this.OutputDataType;
            this.num = zeros(dims(1), dims(2), dt);
            this.den = zeros(dims(1), dims(2), dt);
            if isScaleValueAllowed(this)
                this.gain = ones(dims(1) + 1, 1, dt);
            end
        end
        %------------------------------------------------------------------
        function [b,a,varargout] = stepImpl(this)
            if ~this.isInit
                processTunedPropertiesImpl(this);
            end
            b = this.num;
            a = this.den;
            if isScaleValueAllowed(this)
                varargout{1} = this.gain;
            end
        end
        %------------------------------------------------------------------
        function resetImpl(this)
            this.num(:,1) = 1;
            this.den(:,1) = 1;
            if isScaleValueAllowed(this)
                this.gain(:,1) = 1;
            end
        end
        %------------------------------------------------------------------
        function releaseImpl(this)
            this.num(:,1) = 1;
            this.den(:,1) = 1;
            if isScaleValueAllowed(this)
                this.gain(:,1) = 1;
            end
            this.isInit = false;
        end
        %------------------------------------------------------------------
        function processTunedPropertiesImpl(this)
            crossValidateProperties(this);
            % If Apass or Astop are coming from an input port, the Simulink
            % engine sets their value to zero before actually reading the
            % correct value provided at the input.
            if ~isDesignFilterAllowed(this)
                return;
            end
            % we need to reset the coefficients cache, specially for cases
            % when the filter order decreases.
            resetCoefficientsCache(this);
            this.isInit = true;
            n = this.num;
            d = this.den;

            if isScaleValueAllowed(this)
                g = this.gain;
                [b,a,sv] = designFilter(this);
                g(1:size(sv,1),1) = sv;
                this.gain = g;
            else
                [b,a] = designFilter(this);
            end

            n(1:size(b,1),:) = b;
            d(1:size(b,1),:) = a;

            this.num = n;
            this.den = d;
        end
        %------------------------------------------------------------------
        function validatePropertiesImpl(this)
            crossValidateProperties(this);
        end
        %------------------------------------------------------------------
        function s = saveObjectImpl(this)
            % Set properties in structure s to values in object obj
            % Set public properties and states
            s = saveObjectImpl@matlab.System(this);
            s.num = this.num;
            s.den = this.den;
            s.gain = this.gain;
            s.isInit = this.isInit;
        end
        %------------------------------------------------------------------
        function loadObjectImpl(this,s,wasLocked)
            % Set properties in object obj to values in structure s
            % Set public properties and states
            loadObjectImpl@matlab.System(this,s,wasLocked);
            if wasLocked
                this.num = s.num;
                this.den = s.den;
                if isfield(s,'gain')
                    this.gain = s.gain;
                end
                this.isInit = s.isInit;
            end
        end
        %------------------------------------------------------------------
        function flag = isInputSizeMutableImpl(~,~)
            % Return false if input size cannot change
            % between calls to the System object
            flag = false;
        end
        %------------------------------------------------------------------
        function crossValidateProperties(this)
            validateFilterOrder(this, this.FilterOrder, true);
            validateApass(this, this.Apass);
            validateAstop(this, this.Astop);
        end
        %------------------------------------------------------------------
        function flag = isInactivePropertyImpl(this, prop)
            flag = false;
            switch prop
                case 'Apass'
                    flag = ~strcmp(this.DesignMethod, 'Chebyshev Type I');
                case 'Astop'
                    flag = ~strcmp(this.DesignMethod, 'Chebyshev Type II');
            end
        end
        %------------------------------------------------------------------
        function validateFilterOrder(this, value, compareWithMax)
            if compareWithMax
                validateattributes(value, {'numeric'}, {'finite','real','scalar','integer','nonnegative','<=',this.MaxOrder}, 'set.FilterOrder', 'FilterOrder');
            else
                validateattributes(value, {'numeric'}, {'finite','real','scalar','integer','nonnegative'}, 'set.FilterOrder', 'FilterOrder');
            end
        end
        %------------------------------------------------------------------
        function validateMaxOrder(~, value)
            validateattributes(value, {'numeric'}, {'finite','real','scalar','integer','positive'}, 'set.MaxOrder','MaxOrder');
        end
        %------------------------------------------------------------------
        function validateApass(~, value, varargin)
            allowZero = false;
            if numel(varargin) > 0
                allowZero = varargin{1};
            end
            if allowZero
                validateattributes(value, {'double','single'}, {'finite','real','scalar','nonnegative'}, 'set.Apass','Apass');
            else
                validateattributes(value, {'double','single'}, {'finite','real','scalar','positive'}, 'set.Apass','Apass');
            end
        end
        %------------------------------------------------------------------
        function validateAstop(~, value, varargin)
            allowZero = false;
            if numel(varargin) > 0
                allowZero = varargin{1};
            end
            if allowZero
                validateattributes(value, {'double','single'}, {'finite','real','scalar','nonnegative'}, 'set.Astop','Astop');
            else
                validateattributes(value, {'double','single'}, {'finite','real','scalar','positive'}, 'set.Astop','Astop');
            end
        end
        %------------------------------------------------------------------
        function dims = getCoefficientsDimensions(this)
            N = this.MaxOrder;
            sectionOrder = 3;
            r = rem(N,2);
            K = (N - r) / 2;
            L = K + r;
            dims = [L sectionOrder];
        end
        %------------------------------------------------------------------
        function flag = isDesignFilterAllowed(this)
            flag = this.FilterOrder > 0 && this.Astop >= 0 && this.Apass >= 0;
        end
        %------------------------------------------------------------------
        function flag = isScaleValueAllowed(this)
            flag = this.HasScaleValues;
        end
        %------------------------------------------------------------------
        function resetCoefficientsCache(this)
            dt = this.OutputDataType;
            zeroCast = cast(0,'like',dt);
            oneCast = cast(1, 'like', dt);
            this.num(:,:) = zeroCast;
            this.den(:,:) = zeroCast;
            this.num(:,1) = oneCast;
            this.den(:,1) = oneCast;
            if this.HasScaleValues
                this.gain(:,1) = oneCast;
            end
        end
    end

    methods(Access=protected, Abstract)
        %------------------------------------------------------------------
        [b,a] = designFilter(this);
    end
end
