classdef (StrictDefaults)FourthOrderSectionFiltercgHelper < matlab.System
    %FOURTHORDERSECTIONFILTERCGHELPER Codegen helper class for
    %dsp.FourthOrderSectionFilter
    
    % Copyright 2018-2021 The MathWorks, Inc.
    
    %#codegen
    
    properties
        % Numerator - Numerator coefficients of size Lx5, where L is the
        % number of sections.
        Numerator = [1 .1 .2 .3 .4];
        % Denominator - Denominator coefficients of size Lx5, where L is
        % the number of sections.
        Denominator = [1 .1 .2 .3 .4];
    end
    
    properties (Access = private)
        % pStates Filter states. 4 states per section.
        pStates;
        
        %pNum Store the value of the numerator casted to the data type and
        % complexity of the input
        pNum
        
        %pDen Store the value of the denominator casted to the data type
        % and complexity of the input
        pDen
        
        %pType Store the data type and complexity of the input
        pType
        
        %pNumChans Store the number of channels of input signal
        pNumChans = int32(-1);
    end
    
    properties (Access = private,Nontunable)
        %nCompiledNumChans Store the number of channels of input signal.
        % This Nontunable property is set when dsp.FourthOrderSectionFilter
        % is called via another object (ex- dsp.VariableBandwidthIIRFilter)
        % using the setNumChans method
        nCompiledNumChans = int32(-1);
    end
    
    %----------------------------------------------------------------------
    % Public methods
    %----------------------------------------------------------------------
    methods
        function obj = FourthOrderSectionFiltercgHelper(varargin)
            % Constructor
            % Accept as Name-Value or Value only pairs
            setProperties(obj,nargin,varargin{:},'Numerator','Denominator');
        end
        %------------------------------------------------------------------
        function set.Numerator(obj,val)
            validateattributes(val,{'numeric'},{'finite','nonnan','2d',...
                'ncols',5},'set.Numerator','Numerator');
            obj.Numerator = val;
        end
        %------------------------------------------------------------------
        function set.Denominator(obj,val)
            validateattributes(val,{'numeric'},{'finite','nonnan','2d',...
                },'set.Denominator','Denominator');
            % The Denominator property can be of size Lx4 or Lx5. Depending
            % on the size, append one(s) accordingly
            if size(val,2) == 4
                den = cast([ones(size(val,1),1) val(:,1:4)],'like',val);
            elseif size(val,2) == 5
                den = cast([ones(size(val,1),1) val(:,2:5)],'like',val);
            else
                % Denominator should be atleast of size Lx4.
                coder.internal.error('dsp:system:FourthOrderSectionFilter:incorrectNumCols',size(val,2));
            end
            
            obj.Denominator = den; 
        end
        %------------------------------------------------------------------
        function set.pNum(obj,val)
            obj.pNum = cast(val,'like',obj.pType); %#ok<*MCSUP>
        end
        %------------------------------------------------------------------
        function set.pDen(obj,val)
            obj.pDen = cast(val,'like',obj.pType);
        end
        %------------------------------------------------------------------
    end
    
    %----------------------------------------------------------------------
    % Protected methods
    %----------------------------------------------------------------------
    methods (Access = protected)
        function setupImpl(obj, x)
            
            % Set the number of sections
            nSections = size(obj.Numerator,1);
            
            % Set the number of channels.
            if obj.nCompiledNumChans >= 0
                % If nCompiledNumChans is >= 0, then the
                % dsp.FourthOrderSectionFilter is being called for codegen
                % via another object (for ex.
                % dsp.VariableBandwidthIIRFilter)
                nNumChans = obj.nCompiledNumChans;                
            else
                % Else, use the getNumChans method to get the number of
                % channels
                nNumChans = getNumChans(obj,x);
                obj.pNumChans = nNumChans;
            end
            
            % Disallow a first step with zero channels
            coder.internal.errorIf(nNumChans == 0,'dsp:system:Shared:EmptyFirstStep');
            
            % Set the pType - double/single follows input. Complexity is
            % the union of the input and the coefficients      
            if isreal(obj.Numerator) && isreal(obj.Denominator)
                obj.pType = cast(1,'like',x);
            else
                obj.pType = cast(1i,'like',x);
            end
            
            % Initialize state matrix. Each input channel has seperate states.
            obj.pStates   = zeros(4,nNumChans,nSections,'like',obj.pType);
            
            % Cast the Num and Den to the input type and complexity
            obj.pNum = cast(obj.Numerator,'like',obj.pType);
            obj.pDen = cast(obj.Denominator,'like',obj.pType);
        end
        %------------------------------------------------------------------
        function y = stepImpl(obj, x )
            % Pre-allocate variables for performance
            pstate = obj.pStates;
            num    = obj.pNum;
            denom  = obj.pDen;
            
            nSections   = size(num,1);                                    
            
            % pType is used to cast num, den, state. To ensure, all the
            % variables are of same type, use pType to cast input
            in = cast(x,'like',obj.pType);
                        
            if coder.target('MATLAB')
                % Executing in MATLAB
                if ~isreal(in)
                    % Make both num and den complex
                    pnum = complex(num.');
                    pden = complex(denom(:,2:end).');
                    % Force input states to be complex so that output states are complex
                    pstate = complex(pstate);
                else
                    pnum = num.';
                    pden = denom(:,2:end).';
                end
                [y,pstate] = dsp.internal.builtins.fourthOrderMultiSectionFilt(pnum,pden,in,pstate);

            else
                % Executing in code generation 
                [Rows,Cols] = size(in);
                y = zeros(size(in),'like',in);  
                % Loop over each section
                for k = 1:Cols
                    for n = 1:Rows
                        yt = in(n,k);
                        for r = 1:nSections
                            xi = yt;
                            yt = num(r,1)*xi + pstate(1,k,r);
                            
                            pstate(1,k,r)   = num(r,2)*xi + pstate(2,k,r) - denom(r,2)*yt;
                            pstate(2,k,r)   = num(r,3)*xi + pstate(3,k,r) - denom(r,3)*yt;
                            pstate(3,k,r)   = num(r,4)*xi + pstate(4,k,r) - denom(r,4)*yt;
                            pstate(4,k,r)   = num(r,5)*xi - denom(r,5)*yt;         
                        end
                        y(n,k) = yt;
                    end
                end
            end
            
            % Update state matrix
            obj.pStates = pstate;
        end
        %------------------------------------------------------------------
        function validateInputsImpl(obj,varargin)
            
            nSections = size(obj.Numerator,1);
            
            % Validate if Denominator has the same number of rows as
            % Numerator.
            validateattributes(obj.Denominator,{'numeric'},{'nrows',nSections...
                },'FourthOrderSectionFilter','Denominator');
            
            x = varargin{1};
            % Input x is a column vector
            validateattributes(x,{'single', 'double'},{'2d','finite','nonnan'},'step','Input');
            
            if obj.pNumChans == int32(-1)
                return
            end
            
            % Error if number of input channels changes after setup()            
            nNumChans = obj.pNumChans;
            coder.internal.errorIf((int32(size(x,2))~= nNumChans),...
                'dsp:system:FourthOrderSectionFilter:incorrectNumChannel');
        end
        %------------------------------------------------------------------
        function processTunedPropertiesImpl(obj)
            propChange = isChangedProperty(obj,'Numerator') ||...
                isChangedProperty(obj,'Denominator');
            if propChange
                % Cast the Num and Den to the input type and complexity
                obj.pNum = cast(obj.Numerator,'like',obj.pType);
                if size(obj.Denominator,2) == 4
                    obj.pDen = cast([ones(size(obj.Denominator,1),1) obj.Denominator(:,1:4)],'like',obj.pType);
                elseif size(obj.Denominator,2) == 5
                    obj.pDen = cast(obj.Denominator,'like',obj.pType);
                end
            end
        end
        %------------------------------------------------------------------
        function resetImpl(obj)
            % State is 4xMxL where M is the number of channels, and of
            % the same type as Input
            obj.pStates(:)   = 0;
        end
        %------------------------------------------------------------------
        function releaseImpl(obj)
            obj.pNumChans = int32(-1);
        end
        %------------------------------------------------------------------
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            if isLocked(obj)
                s.pStates      = obj.pStates;
                s.pType        = obj.pType;
            end
        end
        %------------------------------------------------------------------
        function loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                obj.pStates      = s.pStates;
                obj.pType        = s.pType;
                if isfield(s,'ScaleValues')
                    s.Numerator =  s.Numerator .* repmat(s.ScaleValues(1:end-1),1,5);
                end
            end
            loadObjectImpl@matlab.System(obj, s);
        end
        %------------------------------------------------------------------
        % Flag to enable mutable input size
        %------------------------------------------------------------------
        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end
    end
    
    methods(Hidden)
        function setNumChans(obj,val)
            obj.pNumChans = int32(val);
            obj.nCompiledNumChans = int32(val);
        end
        %------------------------------------------------------------------
        function numChans = getNumChans(obj,x)
            % Return the number of input channels depending on execution
            % platform
            if obj.getExecPlatformIndex()
                thisSize = propagatedInputSize(obj, 1);
                out = thisSize(2);
            else
                out = size(x,2);
            end     
            numChans = int32(out);
        end
    end
end
