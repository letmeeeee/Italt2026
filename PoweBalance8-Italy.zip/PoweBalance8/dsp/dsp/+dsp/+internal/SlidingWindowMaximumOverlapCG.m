classdef SlidingWindowMaximumOverlapCG < dsp.internal.AbstractSlidingWindowMinMaxOverlapCG
    % SlidingWindowMaximumCGOverlap This class is internally used by
    % dsp.MovingMinimum

%   Copyright 2021 The MathWorks, Inc.
    
    %#codegen
    
    methods
        function obj = SlidingWindowMaximumOverlapCG(varargin)
            setProperties(obj,nargin,varargin{:});
        end
    end
    
    methods (Access = protected)
        
        function z = compareElements(obj,x,y) %#ok
           z = (x<y); 
        end
        
    end

end
