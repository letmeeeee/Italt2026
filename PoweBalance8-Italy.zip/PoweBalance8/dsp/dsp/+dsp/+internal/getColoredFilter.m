function [sos,gain,maxInitStates,impzlen] = getColoredFilter(color, dataType)
%GETCOLOREDFILTER Return a filter for generating colored noise
%   Return SOS coefficients for a colored filter, a gain that will avoid
%   clipping, and the length of the impulse response. The first impzLen
%   samples output from the filter should be thrown away.

%   Copyright 2019 The MathWorks, Inc.

%#codegen

switch lower(string(color))
    
    case {"pink","flicker"}

        sos = cast([ 1  -0.081103562684136  -0.003215742824561   1  -0.266130985085189   0.010317450107979 ; ...
                     1  -0.021455214493458  -0.122833655807536   1  -0.155181680160634  -0.144535692175397 ; ...
                     1  -0.054938174575504  -0.273185265344832   1  -0.170056227289613  -0.311407334746426 ; ...
                     1   0.054684561537268  -0.587315121770731   1  -0.022321214524782  -0.641431026774982 ; ...
                     1  -0.002242864881224  -0.763211517807612   1  -0.054323866880549  -0.805138480212215 ; ...
                     1  -1.956123917467779   0.956358301707405   1  -1.982002052961236   0.982036041568517 ], ...
                     dataType);

        maxInitStates = cast([ 0.17 0.13 0.16 0.18 0.24 0.95 ; ...
                               0.16 0.16 0.22 0.33 0.45 0.01 ], ...
                               dataType);

    case {"brown","brownian","red"}

        sos = cast([ 1   0.768234948541554   0.160000000000000   1   0.576176211406166   0.090000000000000 ; ...
                     1   0.864504936506425   0.003466282314942   1  -0.102709775958803  -0.827897282528250 ; ...
                     1  -1.961428522477521   0.961476155209161   1  -1.998239728763127   0.998240489034364 ; ...
                     1   0.060383703505529   0.037249000000000   1   0.036918533749494   0.013924000000000 ; ...
                     1  -0.227172523705096   0.017161000000000   1  -0.176882423037556   0.010404000000000 ], ...
                     dataType);

        maxInitStates = zeros(0,0,dataType); % return empty, initial states not supported/precomputed for red noise

    otherwise
    
        assert(false, 'Undefined color');
    
end

hd = dfilt.df1sos(sos);
gain = cast(1 / norm(hd,'l1',1e-16), dataType);
if nargout >= 4
    impzlen = cast(impzlength(sos, 1e-5), dataType);
end

end
