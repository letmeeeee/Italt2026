classdef (StrictDefaults) ShortTimeFFTSysObj < matlab.System
% This class is used for code generation of dsp.STFT    

% Copyright 2018-2021 The MathWorks, Inc.

%#codegen

    properties 
        Window = kaiser(512,20)
    end
    
    % Public, tunable properties
    properties (Nontunable)
        OverlapLength (1, 1) {mustBePositive, mustBeInteger}  = 256
        FFTLength (1, 1) {mustBePositive, mustBeInteger}      = 512
    end

    properties(Access = private)
        pBuff
        pWindow = hann(512)
        % pNumChans - Number of channels. This property is used to disallow
        % variable number of channels while allowing variable frame length.
        pNumChans;
    end

    properties(Access = private, Nontunable)
        HopLength    = 256
        WindowLength = 512
    end
    
    methods
        function obj = ShortTimeFFTSysObj(varargin)
            setProperties(obj, nargin, varargin{:}, 'Window' , 'OverlapLength', 'FFTLength');
            obj.pNumChans = int32(-1);
        end
        
        function set.Window(obj,val)
            validateattributes(val,{'single','double'}, ...
                {'vector','real','nonnan'}, ...
                'set.Window','Window');
            obj.Window = val;
        end
        
    end
    
    methods(Access = protected)
       
        function setupImpl(obj,u)
           obj.pBuff        = dsp.AsyncBuffer('Capacity',numel(obj.Window));  
           obj.HopLength    = numel(obj.Window) - obj.OverlapLength;
           obj.WindowLength = numel(obj.Window);           
           numChans         = getNumChannels(obj,u);
           obj.pNumChans    = int32(numChans);
           win              =  cast(reshape(obj.Window,numel(obj.Window),1),class(u));
           obj.pWindow      = repmat(win,1,size(u,2));
        end
        
        function numchans = getNumChannels(obj,u)
            % GETNUMCHANNELS Return the number of input channels
            if obj.getExecPlatformIndex()
                thisSize = propagatedInputSize(obj, 1);
                numchans = thisSize(2);
            else
                numchans = size(u,2);
            end
        end
                
        function Y = stepImpl(obj,u)   
            write(obj.pBuff,u);
            if obj.pBuff.NumUnreadSamples >= obj.HopLength
               y = read(obj.pBuff ,obj.WindowLength , obj.OverlapLength );
               y  = y .* obj.pWindow;
               Y = fft(y,obj.FFTLength);
            else
               Y =  complex(zeros(obj.FFTLength,0,class(u)));
            end
        end

        function resetImpl(obj)
            reset(obj.pBuff);
        end
        
       function releaseImpl(obj)
            obj.pNumChans = int32(-1);
            release(obj.pBuff);
        end
        
        function validateInputsImpl(obj,u)
            % Validate inputs to the step method at initialization.
            validateattributes(u,{'double','single'}, {'2d',...
                'nonsparse'},'','input');
            % The number of input channels is not allowed to change.
            coder.internal.errorIf(obj.pNumChans~=-1 && ...
                obj.pNumChans ~= size(u,2), ...
                'dsp:system:varSizeChannelsNotSupported')
            
            coder.internal.errorIf(size(u,1) > numel(obj.Window) - obj.OverlapLength, ...
                'dsp:system:varSizeChannelsNotSupported')
        end
        
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            % Save private properties
            if isLocked(obj)
                s.pWindow    = obj.pWindow;
                s.pNumChans = obj.pNumChans;
                s.HopLength = obj.HopLength;
                s.WindowLength = obj.WindowLength;
                s.pBuff = matlab.System.saveObject(obj.pBuff);
            end
        end
        
        function loadObjectImpl(obj,s,wasLocked)
            % Re-load private properties
            if wasLocked
                obj.pWindow = s.pWindow;
                obj.pNumChans = s.pNumChans;
                obj.HopLength = s.HopLength;
                obj.WindowLength = s.WindowLength;
                obj.pBuff = matlab.System.loadObject(s.pBuff);
            end
            % Call base class method
            loadObjectImpl@matlab.System(obj, s, wasLocked);
        end

    end
    
    % ---------------------------------------------------------------------
    % STATIC, PROTECTED METHODS
    % ---------------------------------------------------------------------
    methods (Static, Access = protected)
        function groups = getPropertyGroupsImpl
            mainProps = { ...
                'Window',...
                'OverlapLength', ...
                'FFTLength'};

            mainGroup = matlab.system.display.SectionGroup( ...
                'Title','Properties', ...
                'PropertyList',mainProps);

            groups = mainGroup;
        end
    end
    
end
