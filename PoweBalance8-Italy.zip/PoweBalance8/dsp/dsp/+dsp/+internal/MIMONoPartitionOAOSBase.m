classdef MIMONoPartitionOAOSBase < matlab.System
    % MIMONoPartitionOAOSBase Base class for MIMO overlap-add and
    % overlap-save with multiple filters. This class is used in
    % dsp.FrequencyDomainFIRFilter

    % Copyright 2023 The MathWorks, Inc.
    
    %#codegen
    properties
        % Numerator FIR numerator
        Numerator = fir1(100,0.3);
    end

    properties(Nontunable)
        FFTLength = 256;
        NumeratorDomain = 'Time';
        NumeratorLength (1, 1) {mustBePositive, mustBeInteger} = 101;
        FilterIsReal (1, 1) logical = true;
        NumPaths(1, 1) {mustBePositive, mustBeInteger} = 1
        SumFilteredOutputs (1, 1) logical = true;
    end

    properties (Access = protected)
        % pStates Samples from Previous Computed Segment
        pStates
        % H FFT of Numerator coefficients
        H
        % pInBuff Input buffer
        pInBuff
        % pOutBuff Output buffer
        pOutBuff
        % pEqvFreqNum FFT of equivalent filter
        pEqvFreqNum
    end

    properties (Access = protected, Nontunable)
        pFilterLength
        pDatatype
        pNumChannels
        pFFTLength
        pIsOutputReal
        pNumFilters
        pNumReceivers
        % pCalculateEqvFilter Compute equivalent filter when number of
        % paths is greater than 1
        pCalculateEqvFilter = 0;
        % pIs2DOutput Compute if output size is 2D or 3D
        pIs2DOutput = true;
    end

    methods
        function obj = MIMONoPartitionOAOSBase(varargin)
            setProperties(obj, nargin, varargin{:});
        end
    end

    methods (Access = public, Hidden)
        function setNumchans(obj,val)
            obj.pNumChannels   = val;
        end
    end

    methods (Access = protected)

        function setupImpl(obj, u)

            obj.pDatatype     = class(u);
            obj.pFFTLength    = cast(obj.FFTLength,obj.pDatatype);
           
            if strcmp(obj.NumeratorDomain,'Time')
                %Each row is a filter
                [obj.pNumFilters, obj.pFilterLength] = size(obj.Numerator); 
                obj.pIsOutputReal = isreal(u) && isreal(obj.Numerator);
            else
                obj.pNumFilters = size(obj.Numerator, 1);
                obj.pFilterLength = obj.NumeratorLength;
                obj.pIsOutputReal = isreal(u) && obj.FilterIsReal;
            end
            
            obj.pNumReceivers = obj.pNumFilters/(size(u, 2) * obj.NumPaths); 
            obj.pNumChannels = size(u, 2);

            coder.internal.errorIf(obj.pNumFilters>1 && ...
                mod(obj.pNumFilters, obj.pNumChannels*obj.NumPaths)~=0, ...
                'dsp:system:FrequencyDomainFIRFilter:InvalidNumberofFilters');

            % Calculate equivalent filters for all paths between a given Tx-Rx
            % pair and/or the FFT 
            computeFilter(obj)

            %Output Samples Buffer
            bufferLength = coder.const(obj.pFFTLength - obj.pFilterLength + 1);

            obj.pIs2DOutput = obj.SumFilteredOutputs || (~obj.SumFilteredOutputs && obj.pNumChannels == 1);

            if obj.pIs2DOutput
                obj.pOutBuff = dsp.AsyncBuffer('Capacity', max(bufferLength, 2));

                if ~obj.pIsOutputReal
                    setup(obj.pOutBuff, complex(zeros(bufferLength, obj.pNumReceivers, 'like', u)));
                else
                    setup(obj.pOutBuff, zeros(bufferLength, obj.pNumReceivers, 'like', u));
                end
            else
                obj.pOutBuff = cell(obj.pNumChannels, 1);

                if ~obj.pIsOutputReal
                    for i=1:obj.pNumChannels
                        obj.pOutBuff{i} = dsp.AsyncBuffer('Capacity', max(bufferLength, 2));
                        setup(obj.pOutBuff{i}, complex(zeros(bufferLength, obj.pNumReceivers, 'like', u)));
                    end
                else
                    for i=1:obj.pNumChannels
                        obj.pOutBuff{i} = dsp.AsyncBuffer('Capacity', max(bufferLength, 2));
                        setup(obj.pOutBuff{i}, zeros(bufferLength, obj.pNumReceivers, 'like', u));

                    end
                end
            end
          
            % Input Samples Buffer
            obj.pInBuff  = dsp.AsyncBuffer('Capacity',max(obj.pFFTLength - obj.pFilterLength + 1, 2));
            setup(obj.pInBuff, zeros(obj.pFFTLength - obj.pFilterLength + 1, obj.pNumChannels,'like', u));

        end

        function resetImpl(obj)
            % Initialize / reset discrete-state properties
            obj.pStates    = zeros(size(obj.pStates),'like', obj.pStates);
           
            reset(obj.pInBuff);
            bufferLength = coder.const(obj.pFFTLength - obj.pFilterLength + 1);

            if obj.pIs2DOutput  
                reset(obj.pOutBuff);

                if obj.pIsOutputReal
                    step(obj.pOutBuff,zeros(bufferLength, obj.pNumReceivers, obj.pDatatype));
                else
                    step(obj.pOutBuff, complex(zeros(bufferLength, obj.pNumReceivers, obj.pDatatype)));
                end

            else
                 if ~obj.pIsOutputReal
                    for i=1:obj.pNumChannels
                        reset(obj.pOutBuff{i});
                        step(obj.pOutBuff{i}, complex(zeros(bufferLength, obj.pNumReceivers, obj.pDatatype)));
                    end
                else
                    for i=1:obj.pNumChannels
                        reset(obj.pOutBuff{i});
                        step(obj.pOutBuff{i}, zeros(bufferLength, obj.pNumReceivers, obj.pDatatype));
                    end
                end
            end
        end

        function processTunedPropertiesImpl(obj)
            computeFilter(obj);
        end

        function loadObjectImpl(obj,s,wasLocked)
            if wasLocked
                obj.pStates = s.pStates;
                obj.H = s.H;
                obj.pInBuff =  saveobj(clone(s.pInBuff));
                if ~iscell(s.pOutBuff)
                    obj.pOutBuff = saveobj(clone(s.pOutBuff));
                else
                    for i=1:s.pNumChannels
                        obj.pOutBuff{i} = saveobj(clone(s.pOutBuff{i})); 
                    end
                end
                obj.pCalculateEqvFilter = s.pCalculateEqvFilter;
                obj.pEqvFreqNum = s.pEqvFreqNum;
                obj.pFilterLength = s.pFilterLength;
                obj.pDatatype = s.pDatatype;
                obj.pNumChannels = s.pNumChannels;
                obj.pFFTLength = s.pFFTLength;
                obj.pIsOutputReal = s.pIsOutputReal;
                obj.pNumFilters = s.pNumFilters;
                obj.pNumReceivers = s.pNumReceivers;
                obj.pIs2DOutput = s.pIs2DOutput;
            end

            loadObjectImpl@matlab.System(obj, s, wasLocked);
        end

        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);

           if isLocked(obj)
                s.pStates = obj.pStates;
                s.H = obj.H;
                s.pInBuff =  saveobj(clone(obj.pInBuff));
                if ~iscell(obj.pOutBuff)
                    s.pOutBuff = saveobj(clone(obj.pOutBuff));
                else
                    for i=1:obj.pNumChannels
                        s.pOutBuff{i} = saveobj(clone(obj.pOutBuff{i})); 
                    end
                end
                s.pCalculateEqvFilter = obj.pCalculateEqvFilter;
                s.pEqvFreqNum = obj.pEqvFreqNum;
                s.pFilterLength = obj.pFilterLength;
                s.pDatatype = obj.pDatatype;
                s.pNumChannels = obj.pNumChannels;
                s.pFFTLength = obj.pFFTLength;
                s.pIsOutputReal = obj.pIsOutputReal;
                s.pNumFilters = obj.pNumFilters;
                s.pNumReceivers = obj.pNumReceivers;
                s.pIs2DOutput = obj.pIs2DOutput;
            end
        end

        function y = stepImpl(obj, u)

            numPaths        = obj.NumPaths;
            numReceivers    = obj.pNumReceivers;
            freqNum         = obj.pEqvFreqNum;
            filterLen       = obj.pFilterLength;
            FL              = size(u, 1);
            numChan         = obj.pNumChannels;
            fftLen          = obj.pFFTLength;
            datatype        = obj.pDatatype;
            is2DOutput      = obj.pIs2DOutput; 

            inbuff     = obj.pInBuff;
            inSamples  = cast(inbuff.NumUnreadSamples, datatype);

            outbuff     = obj.pOutBuff;
            if is2DOutput
                outSamples = cast(outbuff.NumUnreadSamples, datatype);
            else
                outSamples = cast(outbuff{1}.NumUnreadSamples, datatype);
            end

            L           = fftLen - filterLen + 1;
            numFrames   = cast(floor((FL+min(inSamples, L))/L), datatype);
            prevsec     = obj.pStates;
            inputBuf    = zeros(L*numFrames, numChan, 'like', u);
            % Samples to be read from u after filling in previous unused
            % input samples
            remSamples  = L*numFrames;
            inpStart    = cast(1, datatype);
            
            % Fill previously unused input samples
            if inSamples>0
                inputBufferSamples = min(L*numFrames, inSamples);
                if numFrames>0
                    inputBuf(1:inputBufferSamples, :) = read(inbuff,int32(inputBufferSamples));  
                    inpStart = inputBufferSamples + cast(1, datatype);
                    remSamples = remSamples - inputBufferSamples;
                end
            end

            if remSamples > 0
                inputBuf(inpStart:inpStart + remSamples - 1, :) = u(1:remSamples, :);
            end

            % Put unused input samples in input buffer
            if FL>remSamples
                 write(inbuff, u(remSamples + 1:end, :));
            end

            % Computing output
            if is2DOutput
                if obj.pIsOutputReal
                    y  = zeros(FL, numReceivers, datatype);
                else
                    y  = complex(zeros(FL, numReceivers, datatype));
                end
            else
                if obj.pIsOutputReal
                    y  = zeros(FL, numReceivers, numChan, datatype);
                else
                    y  = complex(zeros(FL, numReceivers, numChan, datatype));
                end
            end

            fillOutSamples = cast(1, datatype);
            samplesToFill  = cast(FL, datatype);

            if outSamples>0
                fillOutSamples              = min(outSamples, FL);
                if is2DOutput
                    y(1:fillOutSamples, :)      = read(outbuff, int32(fillOutSamples));
                else
                    for i=1:numChan
                        y(1:fillOutSamples, :, i) = read(outbuff{i}, int32(fillOutSamples));
                    end
                end
                samplesToFill               = samplesToFill - fillOutSamples;
                fillOutSamples              = fillOutSamples + 1;
            end

            if numFrames > 0
                [yout, prevsec] = obj.computeOutput(inputBuf, freqNum, prevsec, numChan, ...
                    numReceivers, numPaths, numFrames, L, fftLen, filterLen, obj.pDatatype, ...
                    obj.pIsOutputReal, obj.pCalculateEqvFilter, obj.SumFilteredOutputs);

                y(fillOutSamples:end, :, :) = yout(1:samplesToFill, :, :);

                if samplesToFill  < L*numFrames
                    if is2DOutput
                        write(outbuff , yout(samplesToFill + 1:end, :));
                    else
                        for i=1:numChan
                            write(outbuff{i} , yout(samplesToFill + 1:end, :, i));
                        end
                    end
                end
            end

            obj.pStates = prevsec;

        end

        function computeFilter(obj)
            % Compute the equivalent filter across all paths for a given
            % Tx-Rx pair and/or the FFT of the filters

            numPaths = obj.NumPaths;
            coeffs = cast(obj.Numerator, obj.pDatatype);

            if obj.pCalculateEqvFilter && numPaths ~=1

                eqvFilter = zeros(obj.pNumFilters/numPaths, obj.pFilterLength, 'like', coeffs);

                for i = 1:obj.pNumFilters/numPaths
                    eqvFilter(i, :) = sum(coeffs(1 + (i-1)*numPaths + (0:numPaths-1),:), 1);
                end
            else
                eqvFilter = coeffs;
            end

            if strcmp(obj.NumeratorDomain,'Time')
                ptranspose      = eqvFilter.';
                obj.pEqvFreqNum = fft(ptranspose, obj.pFFTLength, 1);
            else
                obj.pEqvFreqNum = eqvFilter.';
            end

        end

    end

end
