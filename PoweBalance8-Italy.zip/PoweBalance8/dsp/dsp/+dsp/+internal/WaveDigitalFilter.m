classdef WaveDigitalFilter
%WAVEDIGITALFILTER- design and filtering functions

%   Copyright 2015-2023 The MathWorks, Inc.

    %#codegen
    methods (Static)
        function [y, Z] = stepWDFCascade(u, Z, branchInfo, branchCoef,nc)
            CF = branchCoef.FirstOrderSectionCoeffs;
            CS = branchCoef.SecondOrderSectionCoeffs;
            numFOS = branchInfo.NumFOS; 
            numSOS = branchInfo.NumSOS;
            wdftype1 = branchInfo.WDFTypeFOS;
            wdftype2 = branchInfo.WDFTypeSOS;

            %Second order sections
            [ysos,Z] =dsp.internal.WaveDigitalFilter.stepSecondOrderWDFSections(u,CS, wdftype2, Z, numSOS,nc);
            
            %Trailing First order sections
            [y,Z] = dsp.internal.WaveDigitalFilter.stepFirstOrderWDFSections(ysos, CF, wdftype1, ...
                Z, numFOS, numSOS, nc);
        end

        function [y, Z] = stepSecondOrderWDFSections(u,coe, wdfTypes, Z, numSOS,nc)
            %Implements a cascade of 2nd order Wave Digital Filter sections
            y = u;
            for idx = 1:numSOS
                c = coe(idx, :);
                z = Z(:, :, idx);
                tp = wdfTypes(idx,:); 

                [y, z ] = ...
                    dsp.internal.WaveDigitalFilter.filterSingleSection(c, tp, y, z,2,nc);
                
                Z(:, :, idx) = z;
            end
        end

        function [y, Z] = stepFirstOrderWDFSections(u, coe, wdfTypes, Z, numFOS, zoffset, nc) 
            %Implements a cascade of 1st order Wave Digital Filter sections.
            %'zoffset' is the ending index of the preceding SOS into the
            %state matrix. 
            y = u; 
            for idx = 1:numFOS
                c = coe(idx);
                z = Z(1, :, zoffset+idx);
                tp =  wdfTypes(idx);
                [y, z] = ...
                    dsp.internal.WaveDigitalFilter.filterSingleSection(c,tp, y, z,1,nc);
                Z(1, :, zoffset+idx) = z;
            end
        end

        function [u, ZI] = filterSingleSection(a, types, u, ZI, order,nc)
            % Reference: 
            % M. Lutovac, D. Tosic, B. Evans.
            % Filter Design for Signal Processing using MATLAB and
            % Mathematica. Prentice Hall, 2001.
            
        
            if isempty(coder.target) %simulation mode
                
                %Guard against flushing the imag part
                outCplx = ~isreal(u) || ~isreal(ZI);
                if outCplx
                    u = complex(u);
                    Z = complex(ZI(1:order,:));
                else
                    Z = ZI(1:order, :);
                end
                [u, Z] = dsp.internal.builtins.wavedigitalfilt(a, uint8(types),u,Z, double(order));
            else
                [u, Z] = dsp.internal.WaveDigitalFilter.filterSingleSectionCG(...
                    a, types, u, ZI, order,nc);
            end %codegen version

            ZI(1:order, :) = Z(1:order,:);
        end

        function [u, Z] = filterSingleSectionCG(a, types, u, ZI, order,nc)
            %Codegen compatible version of single section filtering
            
            Z = ZI(1:order, :);

            % Local assumptions:
            % assert(isrow(a))
            % assert(isrow(types))
            % assert(length(a) == length(types))
            % assert(size(Z, 1) == order)
            % assert(size(Z, 2) == size(u, 2))

            for t = 1:size(u, 1)

                % Filter in reverse order so the output of one stage is 
                % the input of the previous
                xv = [u(t, 1:nc); Z];

                for n = order:-1:1
                    
                     switch types(n)
                        case 1
                            % Figure 8.51 in reference
                            v  = xv(n, :) - xv(n+1, :);
                            % In-place equivalent of
                            % y  = xb + a*v;
                            % yb = y + v;
                            xv(n, :)  = xv(n+1, :) + a(n)*v;
                            xv(n+1, :) = xv(n, :) + v;
                        case 2
                            % Figure 8.52 in reference
                            v  = xv(n, :) - xv(n+1, :);
                            % In-place equivalent of
                            % yb = xb + a*v;
                            % y  = yb - v;
                            xv(n+1, :) = xv(n+1, :) + a(n)*v;
                            xv(n, :)  = xv(n+1, :) - v;
                        case 3
                            % Figure 8.48 in reference
                            v  = xv(n, :) + xv(n+1, :);
                            % In-place equivalent of
                            % yb = a*v - xb;
                            % y  = v - yb;            
                            xv(n+1, :) = a(n)*v - xv(n+1, :);
                            xv(n, :)  = v - xv(n+1, :);            
                        case 4
                            % Figure 8.49 in reference
                            v  = xv(n+1, :) - xv(n, :);
                            % In-place equivalent of
                            % y  = a*v + xb;
                            % yb = y - v;
                            xv(n, :)  = a(n)*v + xv(n+1, :);
                            xv(n+1, :) = xv(n, :) - v;
                        case 5
                            % Figure 8.50 in reference
                            tmp = xv(n+1, :);
                            % In-place equivalent of
                            % y  = xb;
                            % yb = x;
                            xv(n+1, :) = xv(n, :);
                            xv(n, :) = tmp;
                        otherwise
                            xv(n, :)  = zeros(size(xv(n, :)), 'like', xv);
                            xv(n+1, :) = xv(n, :);
                            assert(false, 'bad wdf type')
                    end
                end

                u(t, :) = xv(1, :);
                Z = xv(2:order+1, :);

            end

        end

        function W = alpha2wdf(A, orders, Types)        

            % Reference: 
            % M. Lutovac, D. Tosic, B. Evans.
            % Filter Design for Signal Processing using MATLAB and
            % Mathematica. Prentice Hall, 2001.
            
            W = zeros(size(A));

            for k = 1:length(orders)
                coeVector = A(k, :);
                typesVector = Types(k, :);
                
                % All alpha coefficients are less than 0.5 in abs value
                assert(all(abs(coeVector) <= 0.5))
                % Size of types and coefficients are equal
                assert(all(size(typesVector) == size(coeVector)))
                assert(size(coeVector, 1) == 1);
            
                for n = 1:orders(k)
                    switch typesVector(n)
                        case 1
                            % Figure 8.51 in reference
                            coeVector(n) = coeVector(n);
                        case 2
                            % Figure 8.52 in reference
                            coeVector(n) = coeVector(n) - 1;
                        case 3
                            % Figure 8.48 in reference
                            coeVector(n) = 1 - coeVector(n);
                        case 4
                            % Figure 8.49 in reference
                            coeVector(n) = - coeVector(n);
                        case 5
                            % Figure 8.50 in reference
                            coeVector(n) = 0;
                        otherwise
                            coeVector(n) = 0;
                            assert(false)
                    end
                end
                W(k, 1:orders(k)) = coeVector(1:orders(k));
            end
        end
        
        function C = wdf2allpass(W, orders)     

            % Reference: 
            % M. Lutovac, D. Tosic, B. Evans.
            % Filter Design for Signal Processing using MATLAB and
            % Mathematica. Prentice Hall, 2001.
            
            C = zeros(size(W));

            for k = 1:length(orders)
                C(k, 1:orders(k)) = ...
                    dsp.internal.LegacyAllpassFilter.wdf2poly(W(k, 1:orders(k)));
            end


        end

        function [types, coe] = wdf2alpha(coe, hasTrailingFirstOrderSection)
            % Reference: 
            % M. Lutovac, D. Tosic, B. Evans.
            % Filter Design for Signal Processing using MATLAB and
            % Mathematica. Prentice Hall, 2001.
            
            % Check all WDF coefficients are less than 1 in abs value
            % else no adaptor type selection allowed
            assert(all(all(abs(coe) <= 1)));
            [numSections, orders] = size(coe);
            types = zeros(size(coe));

            if hasTrailingFirstOrderSection && orders > 1
                %If there's a trailing first order section and there are 2
                %columns, set the trailing first order coeff to 0. The loop
                %below will run without issue. The coeff is ignored later.
                coe(end) = 0;
            end

            for s = 1:numSections
                for a = 1:orders
                    % Type 1 - Figure 8.51 in reference
                    if(coe(s, a) > 0 && coe(s, a) <= 0.5)
                        % NOP [in and out equal]
                        types(s, a) = 1;

                    % Type 2 - Figure 8.52 in reference
                    elseif(coe(s, a) >= -1 && coe(s, a) < -0.5)
                        coe(s, a) = 1 + coe(s, a);
                        types(s, a) = 2;

                    % Type 3 - Figure 8.48 in reference
                    elseif(coe(s, a) <= 1 && coe(s, a) > 0.5)
                        coe(s, a) = 1 - coe(s, a);
                        types(s, a) = 3;

                    % Type 4 - Figure 8.49 in reference
                    elseif(coe(s, a) < 0 && coe(s, a) >= -0.5)
                        coe(s, a) = - coe(s, a);
                        types(s, a) = 4;

                    % Type 5 - Figure 8.50 in reference
                    elseif(coe(s, a) == 0)
                        coe(s, a) = 0;
                        types(s, a) = 5;

                    else
                        coe(s, a) = 0;
                        types(s, a) = 0;
                        assert(false)
                    end
                end
            end
        end

        function [filterInfo, filterCoef] = makeAllpassSpec(coef, dType, hasTrailing1st, isDelay)
            %coef - WDFCoefficients. Coefficients in wave digital form.
            %dType - datatype of input to cast coefs to.
            %hasTrailing1st -  filter has a trailing 1st order section. So
            %   ignore coef(end,2) if coef is nx2.
            %isDelay - the branch is a pure delay. Make an "empty" struct

            coder.extrinsic('dsp.internal.WaveDigitalFilter.wdf2alpha');

            if isDelay%filter is just a delay
                    filterInfo = struct('NumFOS', 0, ...
                        'NumSOS', 0,...
                        'MaxOrder', 0,...
                        'WDFTypeFOS', [], ...
                        'WDFTypeSOS', []);
                    filterCoef  = struct(...
                        'FirstOrderSectionCoeffs', [],...
                        'SecondOrderSectionCoeffs', []);
            else
                if isempty(coder.target)
                    [wdftype, coef] = ...
                        dsp.internal.WaveDigitalFilter.wdf2alpha(coef, ...
                            hasTrailing1st);
                else
                    [wdftype, coef] = coder.const( ...
                        @dsp.internal.WaveDigitalFilter.wdf2alpha, coef, ...
                            hasTrailing1st);
                end

                coef = cast(coef, dType);
                [r,c] = size(coef);

                if c == 1 %first order sections
                    filterInfo= struct('NumFOS', r, ...
                        'NumSOS', 0,...
                        'MaxOrder', 1,...
                        'WDFTypeFOS', wdftype, ...
                        'WDFTypeSOS', []);

                    filterCoef  = struct(...
                        'FirstOrderSectionCoeffs', coef,...
                        'SecondOrderSectionCoeffs', []);

                else %second order
                    if hasTrailing1st 
                        fosCoe = coef(r,1);
                        fosWDFtype = wdftype(r,1);
                        sosWDFtype = wdftype(1:(r-1),:);
                        r = r - 1;
                        nfos = 1;
                    else
                        fosCoe = []; 
                        fosWDFtype = [];
                        sosWDFtype = wdftype;
                        nfos = 0;
                    end
                    filterInfo = struct('NumFOS', nfos, ...
                        'NumSOS', r,...
                        'MaxOrder', 2,...
                        'WDFTypeFOS', fosWDFtype, ...
                        'WDFTypeSOS', sosWDFtype); 

                    filterCoef  = struct(...
                        'FirstOrderSectionCoeffs', fosCoe,...
                        'SecondOrderSectionCoeffs', coef(1:r,:));
                end

            end
        end

    end
end
