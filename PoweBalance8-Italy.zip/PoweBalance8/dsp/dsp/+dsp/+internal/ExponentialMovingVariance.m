classdef ExponentialMovingVariance < matlab.System
    % ExponentialMovingVariance This class is internally used by
    % dsp.MovingVariance in the exponentially weighted mode
    
    % The variance of the Nth output sample is equal to
    % psN = (1/pvN) * sum( plambda.^(N-1:-1:0) .* (X(end:-1:1) - pmN).^2 );
    % where:
    % X = [x1 x2 ... xN] is the vector holding the current input sample xN
    % and the N-1 previous samples.
    % plambda is the forgetting factor
    % pmN is the moving average
    % pvN = (2 * plambda * (1-plambda^(N-1))) / ((1-plambda)*(1+plambda));
    %
    % This class implements the recursive version of this algorithm
    %
    % Reference: Adaptive Filtering and Change Detection for Streaming Data,
    % Dean Bodenham, Imperial College London, section 3.2.7
    
    %   Copyright 2016-2020 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCLS>
    
    properties
        ForgettingFactor = 0.9;
    end
    
    properties (Nontunable)
       NumChans = 1
    end
    
    properties(Access = private)
        % Internal states
        pwN 
        puN
        pmN
        pvN
        psN
        plambda
    end
    
    properties (Access = private, Nontunable)
       pDatatype 
    end
    
    methods
        function obj = ExponentialMovingVariance(varargin)
            setProperties(obj,nargin,varargin{:});
        end
    end
    
    methods(Access = protected)
        
        function processTunedPropertiesImpl(obj)
            obj.plambda = cast(obj.ForgettingFactor,obj.pDatatype);
        end
        
        function setupImpl(obj,u)
            
            if isreal(u)
                NumChannels =  obj.NumChans;
            else
                NumChannels =  2 * obj.NumChans;
            end
            
            obj.pwN   = cast(1,class(u));
            obj.puN   = cast(1,class(u));
            obj.pvN   = cast(0,class(u));
            obj.pmN   = cast(zeros(1,NumChannels),class(u));
            obj.psN = cast(zeros(1,NumChannels),class(u));
            obj.plambda = cast(obj.ForgettingFactor,class(u)); 
            obj.pDatatype = class(u);
        end
        
        function z = stepImpl(obj,x)
            [z,obj.pwN,obj.pmN,obj.puN,obj.psN,obj.pvN] = dsp.internal.ExponentialMovingVariance.computeStatistic(obj.pwN,obj.pmN,obj.puN,obj.psN,obj.pvN,obj.plambda,x);
        end
        
        function resetImpl(obj)
            obj.pwN   = ones(size(obj.pwN), 'like',obj.pwN);
            obj.puN   = ones(size(obj.puN), 'like',obj.pwN);
            obj.pvN   = ones(size(obj.pvN), 'like',obj.pwN);
            obj.pmN   = zeros(size(obj.pmN),'like',obj.pmN);
            obj.psN   = zeros(size(obj.pmN),'like',obj.pmN);
        end
        
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            if isLocked(obj)
                s.pwN     = obj.pwN;
                s.puN     = obj.puN;
                s.pvN     = obj.pvN;
                s.pmN     = obj.pmN;
                s.psN     = obj.psN;
                s.plambda = obj.plambda;
            end
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                obj.pwN     = s.pwN;
                obj.puN     = s.puN;
                obj.pvN     = s.pvN;
                obj.pmN     = s.pmN;
                obj.psN     = s.psN;
                obj.plambda = s.plambda;
            end
            loadObjectImpl@matlab.System(obj, s, wasLocked);
        end
        
    end
    
    methods (Static, Access = protected)
        function [z,pwLocal,pmLocal,puLocal,psLocal,v_prev] = computeStatistic(pwLocal,pmLocal,puLocal,psLocal,v_prev,lambda,x)
            
            if isreal(x)
                y = zeros(size(x),class(x));
                u = x;
            else
                % Split real and imaginary parts to separate channels
                y = zeros(size(x,1),2*size(x,2),class(x));
                u = zeros(size(x,1),2*size(x,2),class(x));
                for index = 1:size(x,2)
                    u(:,(index-1) *2+1) = real(x(:,index));
                    u(:,(index-1) *2+2) = imag(x(:,index));
                end
            end

            for index = 1:size(u,1)
                pmLocal_prev = pmLocal;
                pmLocal = (1-1/pwLocal) * pmLocal + (1/pwLocal) * u(index,:);
                puLocal = ((pwLocal - 1)/pwLocal)^2 * puLocal + (1/pwLocal)^2;    
                v       = pwLocal * (1 - puLocal);
                if v(1) ~=0 % skip at first iteration
                  psLocal = (1./v) .* ( lambda * v_prev .* psLocal + ((pwLocal-1)/pwLocal) .* (pmLocal_prev - u(index,:)).^2 );  
                  y(index,:) = psLocal;
                end
                v_prev    = v;
                pwLocal   = lambda * pwLocal + 1;
            end
            
            if isreal(x)
                z = y;
            else
                % sum variance of real and imaginary parts
                z = zeros(size(x),class(x));
                for index = 1:size(x,2)
                    z(:,index) = y(:,(index-1) *2+1) + y(:,(index-1) *2+2);
                end
            end 
        end
    end
end