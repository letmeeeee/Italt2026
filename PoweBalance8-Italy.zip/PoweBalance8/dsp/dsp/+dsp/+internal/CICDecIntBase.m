classdef CICDecIntBase < matlab.System & dsp.internal.FilterAnalysisCIC
    %CICDecIntBase Base class for CIC Decimator/Interpolator filter classes
    %
    %   See also dsp.CICDecimator,  dsp.CICInterpolator
    
    %   Copyright 1995-2021 The MathWorks, Inc.

%#codegen
%#ok<*EMCLS>
%#ok<*EMCA>
    
properties(Access = protected)
    % pDelayStates holds internal states due to the integrator stages
    %              with size [nSections, nChannels]. It is tunable.
    pDelayStates;
end

properties(Access = protected, Nontunable)
    % properties added for double and single data type support
    % pFIRFilter Discrete FIR (Boxcar) filter object
    pFIRFilter = [];
    % pArithmetic Arithmetic of filters ('double', 'single', or 'fixed')
    pArithmetic = 'fixed';
    pInputNT = numerictype(1,16,15);
    
    cOutWL;      cOutFL;
    cCmbStage1;  cIntgStage1;
    cCmbStage2;  cIntgStage2;
    cCmbStage3;  cIntgStage3;
    cCmbStage4;  cIntgStage4;
    cCmbStage5;  cIntgStage5;
    cCmbStage6;  cIntgStage6;
    cCmbStage7;  cIntgStage7;
    cCmbStage8;  cIntgStage8;
    cCmbStage9;  cIntgStage9;
    cCmbStage10; cIntgStage10;
    cCmbStage11; cIntgStage11;
    cCmbStage12; cIntgStage12;
    cCmbStage13; cIntgStage13;
    cCmbStage14; cIntgStage14;
    cCmbStage15; cIntgStage15;
end

methods (Abstract)
    computeCICWLsFLs(obj)
end

methods
    function fdhdltool(obj,InputNumericType)
      %FDHDLTOOL Launch the GUI to generate HDL
      %   FDHDLTOOL(CIC, nt) launches the Generate HDL dialog that lets you
      %   customize and generate Verilog or VHDL code and test benches for
      %   the quantized System object filter, CIC. You have to call FDHDLTOOL
      %   again if you make changes in the filter, CIC, in the command line.
      %
      %   The main dialog and two subordinate dialogs provide access to many
      %   options for customizing the generated filter and test bench code.
      %
      %   The Generate HDL main dialog categorizes options in two frames:
      %
      %   * HDL Filter - Options you are most likely to customize at least once:
      %   language selection, name and location of generated files, reset
      %   specifications, and optimizations.
      %
      %   * Test bench types - Options for naming and specifying the type of test
      %   bench files to generate, and specific types of stimuli the test benches
      %   are to apply.
      %
      %   EXAMPLE:
      %   cicdecimfilt  = dsp.CICDecimator;
      %   cicinterpfilt = dsp.CICInterpolator;
      %   T = numerictype(1,16,15);
      %   fdhdltool(cicdecimfilt,  T)
      %   fdhdltool(cicinterpfilt, T)
      
      if ~exist('InputNumericType','var')
          error(message('hdlfilter:privgeneratehdl:fdhdltoolinputdatatypenotspecified'));
      end
      cicDecOrIntFilt = sysobjHdl(obj, 'InputDataType', InputNumericType);
      fdhdltool(cicDecOrIntFilt, 'InputDataType', InputNumericType);
    end
    
    function generatehdl(obj,varargin)
      %   GENERATEHDL(CIC, 'InputDataType', nt) automatically generates VHDL
      %   or Verilog code for the quantized filter, CIC. The default
      %   language is VHDL; to generate Verilog, supply the
      %   property/value pair 'TargetLanguage','Verilog'. The file is written to
      %   the HDL source directory which defaults to 'hdlsrc' under the
      %   current directory. This directory will be created if necessary.
      %
      %   GENERATEHDL(CIC, PARAMETER1, VALUE1, PARAMETER2, VALUE2, ...)
      %   generates the HDL code with parameter/value pairs. Valid properties
      %   and values for GENERATEHDL are listed in the Filter Design HDL
      %   Coder documentation section "Property Reference."
      %
      %   EXAMPLE:
      %   cicdecimfilt  = dsp.CICDecimator;
      %   cicinterpfilt = dsp.CICInterpolator;
      %   T = numerictype(1,16,15);
      %   generatehdl(cicdecimfilt,  'InputDataType', T)
      %   generatehdl(cicinterpfilt, 'InputDataType', T)
      
      for k = 1:length(varargin)
          if iscell(varargin{k})
              [varargin{k}{:}] = convertStringsToChars(varargin{k}{:});
          else
              varargin{k} = convertStringsToChars(varargin{k});
          end
      end
      
      cicDecOrIntFilt = sysobjHdl(obj,varargin{:});
      generatehdl(cicDecOrIntFilt,varargin{:}, ...
          'FilterSystemObject', clone(obj));
    end
    
    function [WLs, FLs] = getFixedPointInfo(obj, InputNumericType)
      %getFixedPointInfo Get fixed-point word and fraction lengths
      %   [WLs, FLs] = getFixedPointInfo(CIC, NT) returns all fixed-point
      %   Section and Output word lengths and fraction lengths for the
      %   CIC filter System object, CIC, and input numerictype, NT. For
      %   locked objects, the input numerictype argument NT is optional.
      %
      %   The WLs are returned as a row vector containing all of the
      %   integrator section, comb section, and output word lengths,
      %   in the signal flow order from the first section to the output,
      %   i.e., [Sec1_WL, Sec2_WL, ..., SecN_WL, Output_WL].
      %
      %   The FLs are returned as a row vector containing all of the
      %   integrator section, comb section, and output fraction lengths,
      %   in the signal flow order from the first section to the output,
      %   i.e., [Sec1_FL, Sec2_FL, ..., SecN_FL, Output_FL].
      %
      %   EXAMPLE:
      %   inputNT       = numerictype(1,16,15);
      %   cicdecimfilt  = dsp.CICDecimator;
      %   [dWLs, dFLs]  = getFixedPointInfo(cicdecimfilt, inputNT);
      %   cicinterpfilt = dsp.CICInterpolator;
      %   [iWLs, iFLs]  = getFixedPointInfo(cicinterpfilt, inputNT);
      
      dtsAllSpecified = strcmp(obj.FixedPointDataType, ...
          'Specify word and fraction lengths');
      
      coder.internal.errorIf( ...
          (~dtsAllSpecified && (nargin < 2) && ~isLocked(obj)), ...
          'dsp:dspblkcicfilter:getFixPtInfoInpDTUnknown');
      
      if dtsAllSpecified
          % Get WLs and FLs directly from the specified property values
          if length(obj.SectionWordLengths) == 1
              % Scalar expansion of word lengths parameter
              secWLs = ...
                  obj.SectionWordLengths * ones(1,2*obj.NumSections);
          else
              secWLs = obj.SectionWordLengths;
          end
          if length(obj.SectionFractionLengths) == 1
              % Scalar expansion of fraction lengths parameter
              secFLs = ...
                  obj.SectionFractionLengths * ones(1,2*obj.NumSections);
          else
              secFLs = obj.SectionFractionLengths;
          end
          outWL = obj.OutputWordLength;
          outFL = obj.OutputFractionLength;
      elseif nargin > 1
          % Compute WLs and FLs from object and input numerictype
          [secWLs, secFLs, outWL, outFL] = ...
              getWLsFLsFromInputNT(obj, InputNumericType);
      else
          % Compute WLs and FLs from locked object configuration
          [secWLs, secFLs, outWL, outFL] = ...
              getWLsFLsFromInputNT(obj, obj.pInputNT);
      end
      WLs = [secWLs, outWL]; % return word length values
      FLs = [secFLs, outFL]; % return frac length values
    end
    
end

%----------------------------------------------------------------------
% Hidden methods
%----------------------------------------------------------------------
methods (Hidden)
    function restrictionsCell = getFixedPointRestrictions(~,~)
        restrictionsCell = {};
    end
    
    function props = getFixedPointProperties(~)
        props = {...
            'FixedPointDataType',...
            'SectionWordLengths',...
            'SectionFractionLengths',...
            'OutputWordLength',...
            'OutputFractionLength'};
    end
    
    function flag = isPropertyActive(obj,prop)
        flag = ~isInactivePropertyImpl(obj, prop);
    end
end

methods (Access=protected)
    function flag = isInputSizeMutableImpl(~,~)
      flag = false; 
    end
    
    function validateInputsImpl(obj,varargin)
      
      inputData = varargin{1};
      
      % Only valid fixed point and floating-point inputs are supported
      isSizePropRunning = ~isempty( coder.target ) && eml_ambiguous_types;
      if( ~isSizePropRunning )
          % error for logical and scaled doubles,
          % and slope-bias fixed-point input
          if isa(inputData, 'embedded.fi')
              % NOTE: fi scaled double and boolean are supported
              isValidInput = isfloat(inputData) || ...
                  (isfixed(inputData)&& isscalingbinarypoint(inputData));
          else
              isValidInput = isnumeric(inputData);
          end
          coder.internal.assert(isValidInput, ...
              'dspshared:system:inDataTypeSDblNotFloatIntFixpt', '');
      end

      throwInDTError = false;
      
      if isfi(inputData)
        if ~isfloat(inputData)
          % if input is NOT fi double or fi single
          wl = get(inputData,'WordLength');
          signedStr = get(inputData, 'Signedness');
          valid_fiInput = ...
              (wl>1 && wl<129 && strncmp(signedStr, 'Signed', 6)) || ...
              (wl>=1 && wl <128 && strncmp(signedStr, 'Unsigned', 8));
          throwInDTError = ~valid_fiInput;
        end
      elseif ~isfloat(inputData)
        inStr = class(inputData);
        valid_integerInput = ...
            strncmp(inStr,'int8',4)   || ...
            strncmp(inStr,'int16',5)  || ...
            strncmp(inStr,'int32',5)  || ...
            strncmp(inStr,'int64',5)  || ...
            strncmp(inStr,'uint8',5)  || ...
            strncmp(inStr,'uint16',6) || ...
            strncmp(inStr,'uint32',6) || ...
            strncmp(inStr,'uint64',6);
        throwInDTError = ~valid_integerInput;
      end
      
      if ~isSizePropRunning
          coder.internal.errorIf(throwInDTError, ...
            'dsp:system:CICFilter:inputMustBeSignedOrUnsignedFixedPoint');
      end
      
      % Cache input data type for filter analysis
      if isempty(coder.target)
          if ~isempty(varargin)
              cacheInputDataType(obj,inputData)
          end
      end
    end
    
    function resetImpl(obj)
      coder.extrinsic('int2str');
      if strcmpi(obj.pArithmetic,'fixed')
        n = obj.NumSections;
        for i = coder.unroll(1:n)
          intgStageName = coder.internal.const(['cIntgStage' int2str(i)]);
          cmbStageName  = coder.internal.const(['cCmbStage'  int2str(i)]);
          reset(obj.(intgStageName));
          reset(obj.(cmbStageName));
        end
      end
        
      if ~isempty(obj.pFIRFilter)
        reset(obj.pFIRFilter);
        % reset states
        obj.pDelayStates.States = zeros(size(obj.pDelayStates.States), ...
            'like', obj.pDelayStates.States);
      end
    end
    
    function releaseImpl(obj)
      coder.extrinsic('int2str');
      if strcmpi(obj.pArithmetic,'fixed')
        n = obj.NumSections;
        for i = coder.unroll(1:n)
          intgStageName = coder.internal.const(['cIntgStage' int2str(i)]);
          cmbStageName  = coder.internal.const(['cCmbStage'  int2str(i)]);
          if ~isempty(obj.(intgStageName))
            release(obj.(intgStageName));
          end
          if ~isempty(obj.(cmbStageName))
            release(obj.(cmbStageName));
          end
        end
      end
      if ~isempty(obj.pFIRFilter)
        release(obj.pFIRFilter);
      end
    end
    
    function s = saveObjectImpl(obj)
      s = saveObjectImpl@matlab.System(obj);
      
      if isLocked(obj)
        s.pArithmetic = obj.pArithmetic;
        s.pInputNT    = obj.pInputNT;
        if strcmpi(obj.pArithmetic,'fixed')
          s.cOutWL = obj.cOutWL;
          s.cOutFL = obj.cOutFL;
          n = obj.NumSections;
          for i = coder.unroll(1:n)
            intgStageName = coder.internal.const(['cIntgStage' int2str(i)]);
            cmbStageName  = coder.internal.const(['cCmbStage'  int2str(i)]);
            s.(intgStageName) = saveobj(obj.(intgStageName));
            s.(cmbStageName)  = saveobj(obj.(cmbStageName));
          end
        end
        if ~isempty(obj.pFIRFilter)
          s.pFIRFilter = matlab.System.saveObject(obj.pFIRFilter);
          s.pDelayStates  = obj.pDelayStates;
        end
      end
      
      s = saveFA(obj, s); % Save filter analysis class properties
    end
    
    function loadObjectImpl(obj, s, wasLocked)
      % Call the base class method
      loadObjectImpl@matlab.System(obj, s);
      
      if wasLocked
        if isfield(s, 'pArithmetic')
          obj.pArithmetic = s.pArithmetic;
          if isfield(s, 'pInputNT')
              obj.pInputNT = s.pInputNT;
          end
          if strcmpi(obj.pArithmetic,'fixed')
            obj.cOutWL = s.cOutWL;
            obj.cOutFL = s.cOutFL;
            n = s.NumSections;
            for i = coder.unroll(1:n)
              intgStageName = coder.internal.const(['cIntgStage' int2str(i)]);
              cmbStageName  = coder.internal.const(['cCmbStage'  int2str(i)]);
              obj.(intgStageName) = matlab.system.CoreBlockSystem.loadobj(s.(intgStageName));
              obj.(cmbStageName)  = matlab.System.loadobj(s.(cmbStageName));
            end
          else
            if ~isempty(s.pFIRFilter)
              obj.pFIRFilter =  matlab.System.loadObject(s.pFIRFilter);
              obj.pDelayStates  = s.pDelayStates;
            end
          end
        else
          % load objects saved before R2015b
          obj.cOutWL = s.cOutWL;
          obj.cOutFL = s.cOutFL;
          n = s.NumSections;
          for i = coder.unroll(1:n)
            intgStageName = coder.internal.const(['cIntgStage' int2str(i)]);
            cmbStageName  = coder.internal.const(['cCmbStage'  int2str(i)]);
            obj.(intgStageName) = matlab.system.CoreBlockSystem.loadobj(s.(intgStageName));
            obj.(cmbStageName)  = matlab.System.loadobj(s.(cmbStageName));
          end
        end
      end
        
      % Load filter analysis class properties
      loadFA(obj, s, wasLocked);
    end
    
    function flag = isInactivePropertyImpl(obj, prop)
      flag = false;
      switch prop
        case {'SectionFractionLengths', 'OutputFractionLength'}
          if ( strcmp(obj.FixedPointDataType, 'Full precision') || ...
                  strcmp(obj.FixedPointDataType, 'Minimum section word lengths') || ...
                  strcmp(obj.FixedPointDataType, 'Specify word lengths') )
              flag = true;
          end
        case 'SectionWordLengths'
          if ( strcmp(obj.FixedPointDataType, 'Full precision') || ...
                  strcmp(obj.FixedPointDataType, 'Minimum section word lengths') )
              flag = true;
          end
        case 'OutputWordLength'
          if strcmp(obj.FixedPointDataType, 'Full precision')
              flag = true;
          end
      end
    end
    
    function y = infoImpl(obj,varargin)
        
        includeFixedPointInfo = isLocked(obj) ...
            && strcmp(obj.pArithmetic, 'fixed') ...
            && (nargin > 1) && strcmpi(varargin(1),'long');
        
        if includeFixedPointInfo
            yFA = infoFA(obj,varargin{:});
            szY = size(yFA);
            nrY = szY(1);
            s   = StringWriter;
            for idx=1:nrY
                addcr(s,yFA(idx,:));
            end
            % Append fixed-point info
            addcr(s, sprintf(''));
            addcr(s, sprintf(''));
            addcr(s, sprintf('Fixed-Point Info'));
            [allWLs, allFLs] = getFixedPointInfo(obj);
            addcr(s, sprintf('Section word lengths     : %s', ...
                int2str(allWLs(1:end-1))));
            addcr(s, sprintf('Section fraction lengths : %s', ...
                int2str(allFLs(1:end-1))));
            addcr(s, sprintf('Output  word length      : %s', ...
                int2str(allWLs(end))));
            addcr(s, sprintf('Output  fraction length  : %s', ...
                int2str(allFLs(end))));
            y = char(s);
        else
            y = infoFA(obj,varargin{:});
        end
    end
    
    function setPortDataTypeConnections(obj)
        setPortDataTypeConnection(obj,1,1);
    end

    function [secWLs, secFLs, outWL, outFL] = getWLsFLsFromInputNT(obj, inputNT)
        coder.internal.errorIf(isempty(inputNT) || ~isfixed(inputNT), ...
            'dsp:system:CICFilter:inputMustBeSignedOrUnsignedFixedPoint');
        
        % Fixed-point CIC configuration
        inWL = inputNT.WordLength + (~(inputNT.Signed));
        inFL = inputNT.FractionLength;
        n    = obj.NumSections;
        
        fixptDTModeStr = obj.FixedPointDataType;
        allDTsSpecfied = false;
        
        if strncmp(fixptDTModeStr, 'Full precision',4)
            modestr = 'fullprecision';
        elseif strncmp(fixptDTModeStr, 'Minimum section word lengths',4)
            modestr = 'minwordlengths';
        elseif strncmp(fixptDTModeStr, 'Specify word lengths', 20)
            modestr = 'specifywordlengths';
            nSecWLs = numel(obj.SectionWordLengths);
            coder.internal.errorIf( ...
                ~(isequal(nSecWLs, 1) || isequal(nSecWLs, 2*n)), ...
                'dsp:system:wlParamNotMatchNumSections');
        else
            allDTsSpecfied = true;
            modestr = ''; % unused
            nSecWLs = numel(obj.SectionWordLengths);
            nSecFLs = numel(obj.SectionFractionLengths);
            coder.internal.errorIf( ...
                ~(isequal(nSecWLs, 1) || isequal(nSecWLs, 2*n)), ...
                'dsp:system:wlParamNotMatchNumSections');
            coder.internal.errorIf(...
                ~(isequal(nSecFLs, 1) || isequal(nSecFLs, 2*n)), ...
                'dsp:system:flParamNotMatchNumSections');
        end
        
        if length(obj.SectionWordLengths) == 1
            % Scalar expansion of word lengths parameter
            localSecWL = obj.SectionWordLengths * ones(1,2*n);
        else
            localSecWL = obj.SectionWordLengths;
        end
        
        if allDTsSpecfied
            if length(obj.SectionFractionLengths) == 1
                % Scalar expansion of fraction lengths parameter
                localSecFL = obj.SectionFractionLengths * ones(1,2*n);
            else
                localSecFL = obj.SectionFractionLengths;
            end
            secWLs = localSecWL;
            secFLs = localSecFL;
            outWL  = obj.OutputWordLength;
            outFL  = obj.OutputFractionLength;
        else
            a = computeCICWLsFLs(obj, inWL, inFL, modestr, n, localSecWL);
            secWLs = a(1:2*n);
            secFLs = a(2*n+1:4*n);
            outWL  = a(end-1);
            outFL  = a(end);
        end
    end
    
end % methods, protected API

end

