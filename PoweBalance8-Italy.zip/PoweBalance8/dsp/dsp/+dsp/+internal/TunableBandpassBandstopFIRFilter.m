classdef TunableBandpassBandstopFIRFilter < dsp.internal.AbstractTunableFIRFilter

%#codegen

    properties
        %CenterFrequency  Filter center frequency (Hz)
        %   Specify the normalized filter center frequency as a real,
        %   positive scalar less than or equal to 1. The default is 0.5.
        %   Hz. This property is tunable.
        CenterFrequency = 0.5;
        % Bandwidth  Filter bandwidth (Hz)
        %   Specify the normalized filter bandwidth in Hertz as a real,
        %   positive scalar less than or equal to 1. The default is 0.1.
        %   This property is tunable.
        Bandwidth = 0.1;
    end

    methods
        %------------------------------------------------------------------
        function set.CenterFrequency(this, value)
            validateCenterFrequency(this, value);
            this.CenterFrequency = value;
        end
        %------------------------------------------------------------------
        function set.Bandwidth(this, value)
            validateBandwidth(this, value);
            this.Bandwidth = value;
        end
    end

    methods(Access = protected)
        %------------------------------------------------------------------
        function crossValidateProperties(this)
            crossValidateProperties@dsp.internal.AbstractTunableFIRFilter(this);
            validateCenterFrequency(this, this.CenterFrequency);
            validateBandwidth(this, this.Bandwidth);
            validateCenterFrequencyBandwidth(this);
        end
        %------------------------------------------------------------------
        function validateCenterFrequency(~, value, varargin)
            allowZero = false;
            if numel(varargin) > 0
                allowZero = varargin{1};
            end
            if allowZero
                validateattributes(value, {'double','single'}, {'real','scalar','nonnegative','finite', '<=', 1}, 'set.CenterFrequency','CenterFrequency');
            else
                validateattributes(value, {'double','single'}, {'real','scalar','positive','finite', '<=', 1}, 'set.CenterFrequency','CenterFrequency');
            end
        end
        %------------------------------------------------------------------
        function validateBandwidth(~, value, varargin)
            allowZero = false;
            if numel(varargin) > 0
                allowZero = varargin{1};
            end
            if allowZero
                validateattributes(value, {'double','single'}, {'real','scalar','nonnegative','finite', '<=', 1}, 'set.Bandwidth','Bandwidth');
            else
                validateattributes(value, {'double','single'}, {'real','scalar','positive','finite', '<=', 1}, 'set.Bandwidth','Bandwidth');
            end
        end
        %------------------------------------------------------------------
        function validateCenterFrequencyBandwidth(this, varargin)
            coder.internal.errorIf(this.CenterFrequency > 0 && this.Bandwidth > 0 && (this.CenterFrequency + this.Bandwidth/2 >= 1), 'dsp:system:TunableFIRFilter:CFPlusBWLarge');
            coder.internal.errorIf(this.CenterFrequency > 0 && this.Bandwidth > 0 && (this.CenterFrequency - this.Bandwidth/2 <= 0), 'dsp:system:TunableFIRFilter:CFMinusBWNegative');
        end
        %------------------------------------------------------------------
        function flag = isDesignFilterAllowed(this)
            flag = isDesignFilterAllowed@dsp.internal.AbstractTunableFIRFilter(this);
            flag = flag && this.CenterFrequency > 0 && this.Bandwidth > 0;
        end
        %------------------------------------------------------------------
        function Fc = getCutoffFrequency(this)
            Fc = this.Bandwidth;
        end
    end
end
