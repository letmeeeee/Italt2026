classdef TunableHighpassFIRFilter < dsp.internal.TunableLowpassHighpassFIRFilter
% TunableHighpassFIRFilter

    %   Copyright 2022-2023 The MathWorks, Inc.

    %#codegen

    methods(Access = protected)
        %------------------------------------------------------------------
        function b = designFilter(this)
            % Compute the design window
            computePrototypeWindow(this);
            dt = this.OutputDataType;
            Fc = cast(getCutoffFrequency(this),dt);
            twoCast = cast(2, dt);
            b = dsp.filterdesign.internal.fir.hpfir(cast(this.FilterOrder,dt), Fc, twoCast, this.pProtoypeWindow, cast(this.MaxOrder,dt));
        end
    end

    methods(Static, Access=protected)
        function mainS = getPropertyGroupsImpl
            % Modify order of display
            mainS =  matlab.system.display.Section(...
                'Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', {'FilterOrder','MaxOrder','CutoffFrequency','Window','SidelobeAttenuation','OutputDataType'});
        end
    end
end
