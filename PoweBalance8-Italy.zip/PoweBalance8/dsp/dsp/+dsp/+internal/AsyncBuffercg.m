classdef AsyncBuffercg < handle
    %AsyncBuffercg Codegen class for dsp.AsyncBuffer
    
    % Copyright 2016-2020 The MathWorks, Inc.
    
    %#codegen
    properties (Dependent)
        Capacity
    end
    properties (Dependent, SetAccess = private)
        %NumUnreadSamples Number of unread samples per channel in buffer
        % The total number of unread samples in the buffer is
        % NumUnreadSamples*(number of channels). This is a read-only
        % property.
        NumUnreadSamples
    end
    properties (Hidden,SetAccess = private)
        pBuffer
    end

    %-----------------------------------------------------------------------
    % Public methods for reading and writing and getting unread samples
    %-----------------------------------------------------------------------
    methods
        
        function setup(obj,in)
            setup(obj.pBuffer,in);
        end

        function obj = AsyncBuffercg(varargin)
            obj.pBuffer = dsp.internal.AsyncBuffercgHelper(varargin{:});
        end
        
        function set.Capacity(obj,val)
            validateattributes(val,{'numeric'}, ...
                {'finite','real','scalar','integer','positive','>=',2},...
                'set.Capacity','Capacity');
            obj.pBuffer.Capacity = int32(val);
        end
        
        function cap = get.Capacity(obj)
                cap = obj.pBuffer.Capacity;
        end
        
        function unreadSamples = get.NumUnreadSamples(obj)
            unreadSamples = obj.pBuffer.NumUnreadSamples;
        end
        
        function release(obj)
            release(obj.pBuffer)
        end
        
        function reset(obj)
            reset(obj.pBuffer);
        end
        
        function overrun = write(obj,in)
            %WRITE Write to buffer
            [overrun] = obj.pBuffer.step(in);
        end
        
        function overrun = step(obj,in)
            overrun = write(obj,in);
        end
        
        function [out,underrun] = peek(obj,numRows,overlap)
            if nargin < 2
                numRows = obj.pBuffer.NumUnreadSamples;
            end
            if nargin < 3
                overlapCast = int32(0);
                validateattributes(numRows,{'numeric'},...
                    {'nonnegative','real','finite','integer','scalar'},'read','number of rows');
                coder.internal.errorIf(numRows > obj.Capacity,['dsp:system',...
                    ':AsyncBuffer:readTooManyRows']);
                numRowsCast = int32(numRows);
            end
            if nargin == 3
                validateattributes(numRows,{'numeric'},...
                    {'nonnegative','real','finite','integer','scalar'},'read','number of rows');
                coder.internal.errorIf(numRows > obj.Capacity,['dsp:system',...
                    ':AsyncBuffer:readTooManyRows']);
                validateattributes(overlap,{'numeric'},...
                    {'nonnegative','real','finite','integer','scalar'},'read','overlap');
                coder.internal.errorIf(overlap > numRows,['dsp:system',...
                    ':AsyncBuffer:overlapSize']);
                overlapCast = int32(overlap);
                numRowsCast = int32(numRows);
            end
            
            [out, underrun] = obj.pBuffer.peek(numRowsCast,overlapCast);
        end
        function [out,underrun] = read(obj,numRows,overlap)         
            % Error check input and cast as necessary ---------------------
            if nargin < 2
                numRows = obj.pBuffer.NumUnreadSamples;
            end
            numRowsCast = int32(numRows);
            if nargin <= 3
                overlapCast = int32(0);
                validateattributes(numRows,{'numeric'},...
                    {'nonnegative','real','finite','integer','scalar'},'read','number of rows');
                coder.internal.errorIf(numRows > obj.pBuffer.Capacity,['dsp:system',...
                    ':AsyncBuffer:readTooManyRows']);
            end
            if nargin == 3
                validateattributes(overlap,{'numeric'},...
                    {'nonnegative','real','finite','integer','scalar'},'read','overlap');
                coder.internal.errorIf(overlap > numRows,['dsp:system',...
                    ':AsyncBuffer:overlapSize']);
                overlapCast = int32(overlap);
            end
            
            [out,underrun] = obj.pBuffer.read(numRowsCast,overlapCast);
        end
    end
    
    %----------------------------------------------------------------------
    % Hidden Static methods
    %----------------------------------------------------------------------

    methods
        function s = info(obj)
             s =  info(obj.pBuffer);     
        end
    end
    
    methods (Static)
        function out = matlabCodegenToRedirected(~)
            out  = dsp.internal.AsyncBuffercg;
        end
        
        function out = matlabCodegenFromRedirected(~)
            out = dsp.AsyncBuffer;
        end
    end
    methods (Hidden, Static)
        function name = matlabCodegenUserReadableName
            name = 'dsp.AsyncBuffer';
        end
    end
    
end