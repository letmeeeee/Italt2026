classdef (StrictDefaults) STFTSysObj < matlab.System
% This class is used for code generation of dsp.STFT    

% Copyright 2018-2023 The MathWorks, Inc.

%#codegen

    properties 
        Window = sqrt(hann(512,'periodic'))
    end
    
    properties (Nontunable)
        OverlapLength  = 256
        FrequencyRange (1, :) char {matlab.system.mustBeMemberMessageID(FrequencyRange, ...
                                    {'dsp:system:STFT:FrequencyRange_onesided',;...
                                    'dsp:system:STFT:FrequencyRange_twosided'})} = 'twosided'

        FFTLength (1, 1) {mustBePositive, mustBeInteger}      = 512
    end

    properties(Access = private)
        pBuff
        pWindow = kaiser(512,20)
        % pNumChans - Number of channels. This property is used to disallow
        % variable number of channels while allowing variable frame length.
        pNumChans;
    end

    properties(Access = private, Nontunable)
        HopLength           = 256
        WindowLength        = 512
        NumFrequencySamples = 0;
    end
        
    methods
        function obj = STFTSysObj(varargin)
            setProperties(obj, nargin, varargin{:}, 'Window' , 'OverlapLength', 'FFTLength');
            obj.pNumChans = int32(-1);
        end
        
        function F = getFrequencyVector(obj,varargin)
        % getFrequencyVector Get the vector of frequencies at which the
        % short-time FFT is computed.
            pCenterDC = false;
            Npts      = obj.FFTLength;

            if nargin == 1
                Fs = 2 * pi;
            else
                Fs = varargin{1};
            end

            F = dsp.internal.SpectrumEstimatorBase.frequencygrid...
                (isOneSided(obj),Npts,Fs,pCenterDC);
        end
    end
    
    methods(Access = protected)
       
        function processTunedPropertiesImpl(obj)
            win              =  cast(reshape(obj.Window,numel(obj.Window),1),class(obj.pWindow));
            obj.pWindow      = repmat(win,1,size(obj.pWindow,2));
        end
        
        function setupImpl(obj,u)
           obj.pBuff        = dsp.AsyncBuffer('Capacity',numel(obj.Window));  
           obj.HopLength    = numel(obj.Window) - obj.OverlapLength;
           obj.WindowLength = numel(obj.Window);           
           numChans         = getNumChannels(obj,u);
           obj.pNumChans    = int32(numChans);
           win              =  cast(reshape(obj.Window,numel(obj.Window),1),class(u));
           obj.pWindow      = repmat(win,1,size(u,2));
           obj.NumFrequencySamples = getNumFrequencySamples(obj);
        end
        
        function numchans = getNumChannels(obj,u)
            % GETNUMCHANNELS Return the number of input channels
            if obj.getExecPlatformIndex()
                thisSize = propagatedInputSize(obj, 1);
                numchans = thisSize(2);
            else
                numchans = size(u,2);
            end
        end
                
        function Y = stepImpl(obj,u)   
            write(obj.pBuff,u);
            NFFT = obj.FFTLength;
            if obj.pBuff.NumUnreadSamples >= obj.HopLength
                % If data in buffer is greater than or equal to hop length
                % read data in buffer
                y = read(obj.pBuff ,obj.WindowLength , obj.OverlapLength );
                y = y .* obj.pWindow;
                yTwoSided = fft(y,NFFT);
                Y = yTwoSided(1:obj.NumFrequencySamples,:);
            else
                Y = complex(zeros(obj.NumFrequencySamples,0,class(u)));
            end
        end

        function resetImpl(obj)
            reset(obj.pBuff);
        end
        
       function releaseImpl(obj)
            obj.pNumChans = int32(-1);
            release(obj.pBuff);
       end
       
       function validatePropertiesImpl(obj)
           coder.internal.errorIf(obj.FFTLength < numel(obj.Window), ...
               'dsp:system:STFT:FFTLengthTooShort')
           
           coder.internal.errorIf(obj.OverlapLength >= numel(obj.Window), ...
               'dsp:system:STFT:OverlapTooLong')
       end
       
        function validateInputsImpl(obj,u)
            % Validate inputs to the step method at initialization.
            validateattributes(u,{'double','single'}, {'2d',...
                'nonsparse'},'','input');
            % The number of input channels is not allowed to change.
            coder.internal.errorIf(obj.pNumChans~=-1 && ...
                obj.pNumChans ~= size(u,2), ...
                'dsp:system:varSizeChannelsNotSupported')
            
            coder.internal.errorIf(size(u,1) > numel(obj.Window) - obj.OverlapLength, ...
                'dsp:system:STFT:InputLengthTooLong')
            % If input is complex and frequency range is one-sided error
            % out
            coder.internal.errorIf(~isreal(u) && strcmpi(obj.FrequencyRange,'onesided'), ...
                'dsp:system:STFT:InvalidInputDataTypeWithOnesided')
        end
        
        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end
        
        function flag = isOneSided(obj)
           flag = strcmpi(obj.FrequencyRange,'onesided'); 
        end

        function nSamples = getNumFrequencySamples(obj)
            % Return the number of frequency samples based on the
            % FrequencyRange and FFTLength
            nSamples = obj.FFTLength;
            if isOneSided(obj)
                if mod(nSamples,2) == 0
                    % For even NFFT choose samples from 1 to NFFT/2  + 1
                    nSamples = nSamples/2 + 1;
                else
                    % For odd NFFT choose samples from 1 to (NFFT + 1)/2
                    nSamples = (nSamples + 1)/2;
                end
            end
        end
    end
    
    % ---------------------------------------------------------------------
    % STATIC, PROTECTED METHODS
    % ---------------------------------------------------------------------
    methods (Static, Access = protected)
        function groups = getPropertyGroupsImpl
            mainProps = { ...
                'Window',...
                'OverlapLength', ...
                'FFTLength', ...
                'FrequencyRange'};

            mainGroup = matlab.system.display.SectionGroup( ...
                'Title','Properties', ...
                'PropertyList',mainProps);

            groups = mainGroup;
        end
    end
    
end
