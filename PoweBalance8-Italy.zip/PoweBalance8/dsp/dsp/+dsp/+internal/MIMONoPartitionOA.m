classdef MIMONoPartitionOA < dsp.internal.MIMONoPartitionOAOSBase

    % MIMONoPartitionOA MIMO Overlap-add for multiple filters.
    % This class is used in dsp.FrequencyDomainFIRFilter

    % Copyright 2023 The MathWorks, Inc.

    %#codegen
    methods
        function obj = MIMONoPartitionOA(varargin)
            setProperties(obj, nargin, varargin{:});
        end
    end

    methods (Access = protected)
        function setupImpl(obj,u)
            setupImpl@dsp.internal.MIMONoPartitionOAOSBase(obj, u);

            if obj.SumFilteredOutputs
                if obj.pIsOutputReal
                    obj.pStates = zeros(obj.pFilterLength - 1, obj.pNumReceivers, 'like', u);
                else
                    obj.pStates = complex(zeros(obj.pFilterLength - 1, obj.pNumReceivers, 'like', u));
                end
            else
                if obj.pIsOutputReal
                    obj.pStates = zeros(obj.pFilterLength - 1, obj.pNumReceivers*obj.pNumChannels, 'like', u);
                else
                    obj.pStates = complex(zeros(obj.pFilterLength - 1, obj.pNumReceivers*obj.pNumChannels, 'like', u));
                end
            end

            if ~obj.pIsOutputReal
                obj.pStates = complex(obj.pStates);
            end

        end
    end

    methods (Static)
        % Implement MIMO No Partition Overlap-Add
        function [y, prevsec] = computeOutput(u, freqNum, prevsec, ...
                numChan, numReceivers, numPaths, numFrames, ...
                L, fftLen, filterLen, dataType, isOutReal, useEqvFilter, sumOutputs)

            z   = reshape(u, L, numFrames, numChan);
            xfft = fft(z, fftLen, 1);

            rxIndex = 1;
            zout = complex(zeros(fftLen, numFrames, numChan*numReceivers, dataType));

            if ~useEqvFilter
                % Summing across all the paths between a given Tx-Rx

                ztmp = complex(zeros(fftLen, numFrames, numPaths, dataType));

                for ii = 1:numChan
                    for jj = 1:numReceivers
                        index  = (ii-1)*numReceivers*numPaths + (jj - 1)*numPaths;

                        for kk = 1:numPaths
                            ztmp(:, :, kk)  = xfft(:, :, ii).*freqNum(:, index + kk);
                        end
                        zout(:, :, rxIndex) = sum(ztmp, 3);
                        rxIndex             = rxIndex + 1;
                    end
                end
            else  
                for ii = 1:numChan
                    for jj = 1:numReceivers
                        index               = (ii-1)*numReceivers + jj ;
                        zout(:, :, rxIndex) = sum(xfft(:, :, ii).*freqNum(:, index), 3);
                        rxIndex             = rxIndex + 1;
                    end
                end
            end

            yy = zeros(fftLen, numFrames, numReceivers, 'like', zout);

            % Summing up the inputs at the receiver end
            if sumOutputs
                for kk = 1:numReceivers
                    yy(:, :, kk) = sum(zout(:, :, (kk:numReceivers:end)), 3);
                end
            else
                yy = zout;
            end

            if sumOutputs
                if isOutReal
                    y = zeros(L*numFrames, numReceivers, dataType);
                    o = real(ifft(yy, fftLen));
                else
                    y = complex(zeros(L*numFrames, numReceivers, dataType));
                    o = ifft(yy, fftLen);
                end

                for i = 1:numFrames
                    o(1:filterLen-1, i, :)  = squeeze(o(1:filterLen-1, i, :)) + prevsec;
                    y((i-1)*L + 1: L*i,:)   = o(1:L, i, :);
                    prevsec(:, :)           = squeeze(o(L+1:end, i, :));
                end
            else

                if isOutReal
                    y = zeros(L*numFrames, numReceivers, numChan, dataType);
                    o = real(ifft(yy, fftLen));
                else
                    y = complex(zeros(L*numFrames, numReceivers, numChan, dataType));
                    o = ifft(yy, fftLen);
                end

                for i = 1:numFrames
                    o(1:filterLen-1, i, :)  = squeeze(o(1:filterLen-1, i, :)) + prevsec;
                    for k = 1:numChan*numReceivers
                        idx2 = mod(k, numReceivers); %index 2
                        if idx2 == 0
                            idx2 = numReceivers;
                        end
                        idx3 = ceil(k/numReceivers); %index 3

                        y((i-1)*L + 1: L*i, idx2, idx3) = o(1:L, i, k);
                    end
                    prevsec(:, :) = squeeze(o(L+1:end, i, :));
                end
            end

        end %End of function

    end

end
