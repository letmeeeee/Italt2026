classdef (Hidden,StrictDefaults)ParametricEQFilterBase < dsp.internal.SampleRateEngine & ...
        dsp.internal.FilterAnalysis
    
    %ParametricEQFilter Second-order parametric equalizer filter. Super
    %class for dsp.ParametricEQFilter and dsp.simulink.ParametricEQFilter
    
    % Copyright 2018-2023 The MathWorks, Inc.
    
    %#codegen
    
    properties (Nontunable)
        %Specification Filter specification
        %   Set the specification as one of 'Bandwidth and center
        %   frequency' | 'Quality factor and center frequency' |
        %   'Coefficients'. The default is 'Bandwidth and center
        %   frequency'.
        Specification (1, :) char {matlab.system.mustBeMemberMessageID(Specification, ...
                                  {'dsp:system:ParametricEQFilter:Specification_Coefficients',;...
                                   'dsp:system:ParametricEQFilter:Specification_BandwidthAndCenterFreq',;...
                                   'dsp:system:ParametricEQFilter:Specification_QualityFactorAndCenterFreq'})} ...
                                   = 'Bandwidth and center frequency';
    end
    
    properties
        %BandwidthCoefficient Bandwidth coefficient
        %   Specify the value that determines the filter's bandwidth as a
        %   finite numeric scalar between 0 and 1. 0 corresponds to the
        %   maximum bandwidth. 1 corresponds to the minimum bandwidth (0
        %   Hz; i.e. an allpass filter). The default is 0.72654. This
        %   property is tunable.
        BandwidthCoefficient = 0.72654;
        %CenterFrequencyCoefficient Center frequency coefficient
        %   Specify the value that determines the filter's center frequency
        %   as a finite numeric scalar between -1 and 1. -1 corresponds to
        %   the minimum center frequency (0 Hz). 1 corresponds to the
        %   maximum center frequency (SampleRate/2 Hz). The default is 0
        %   which corresponds to SampleRate/4 Hz. This property is tunable.
        CenterFrequencyCoefficient = 0;
        %Bandwidth Filter bandwidth (Hz)
        %   Specify the filter's bandwidth as a finite positive numeric
        %   scalar in Hertz. The bandwidth is measured at the arithmetic
        %   mean between the peak gain in absolute power units and one. The
        %   default is 2205 Hz. This property is tunable.
        Bandwidth = 2205;
        %CenterFrequency Equalizer center frequency (Hz)
        %   Specify the filter's center frequency as a finite positive
        %   numeric scalar in Hertz. The default is 11025 Hz. This property
        %   is tunable.
        CenterFrequency = 11025;
        %QualityFactor Quality factor
        %   Specify the quality factor (Q factor) for the parametric EQ
        %   filter. The default value is 5. This property is tunable.
        QualityFactor = 5;
    end

    properties
        %PeakGain Gain (Linear Units)
        %   Specify the peak or dip of the filter in linear units. Values
        %   greater than one correspond to a boost while values less than
        %   one correspond to a dip or cut. The default is 2 (6.0206 dB).
        %   This property is tunable.
        PeakGain = 2;
        %PeakGaindB Gain (dB)
        %   Specify the peak or dip of the filter in decibels. Values
        %   greater than zero correspond to a boost while values less than
        %   zero correspond to a dip or cut. The default is 6.02036dB. This
        %   property is tunable.
        PeakGaindB = 6.0206;
    end
    
    properties (Nontunable)
        % SampleRate Input sample rate (Hz)
        %   Specify the sampling rate of the input in Hertz as a finite
        %   numeric scalar. The default is 44100 Hz.
        SampleRate = 44100;
    end
    
    properties (Access=private)
        NotchPeakFilterObj  
        privReferenceGain
        privPeakGain
        NumChannels = int32(1)
    end
    
    properties (Access=private, Nontunable)
        ReferenceGain       =  1;
        ReferenceGaindB     =  0;
    end
    
    properties (Constant, Hidden)
        % SampleRateSet is used to setup the choices for SampleRate. 
        SampleRateSet = matlab.system.SourceSet({'PropertyOrMethod', ...
            'SystemBlock', 'InheritSampleRate', 'getInheritedSampleRate',true});
    end
    
    properties (Access=protected, Nontunable)
        %InputDataType Data type of the inputs
        %   This is a private property that stores the data type of the
        %   inputs and it is used to set the data type of all the
        %   DiscreteState properties and the outputs.
        InputDataType;
    end
    
    methods
        function obj = ParametricEQFilterBase(varargin)
            % Support name-value pair arguments
            setProperties(obj,nargin,varargin{:}); 
            obj.NumChannels = int32(-1);
        end
        
        function set.SampleRate(obj,val)
            validateattributes(val,...
                {'double','single'}, ...
                {'real','scalar','positive','finite'},...
                '','SampleRate');
            obj.SampleRate = val;
        end
        
        function set.Bandwidth(obj,bw)
            validateattributes(bw,...
                {'double','single'},...
                {'real','scalar','finite','>=',0},...
                '','Bandwidth');
            obj.Bandwidth = bw;
        end

        function bw = get.Bandwidth(obj)
            bw = obj.Bandwidth;
        end
        function set.CenterFrequency(obj,cf)
             validateattributes(cf,...
                {'double','single'},...
                {'real','scalar','finite','>=',0},...
                '','CenterFrequency');
            obj.CenterFrequency = cf;
        end
        function cf = get.CenterFrequency(obj)
            cf = obj.CenterFrequency ;
        end
        function set.QualityFactor(obj,Q)
            obj.checkVal(Q);
            obj.QualityFactor = Q;
        end
        function Q = get.QualityFactor(obj)
            Q = obj.QualityFactor;
        end
        function set.BandwidthCoefficient(obj,bwc)
            coder.internal.errorIf(~isnumeric(bwc) || ~isscalar(bwc) ...
                || ~isreal(bwc) || (bwc < -1 || bwc > 1), ['dsp:system',...
                ':NotchPeakFilter:BWCoeff']);  
            obj.BandwidthCoefficient = bwc;
        end
        function bwc = get.BandwidthCoefficient(obj)
            bwc = obj.BandwidthCoefficient;
        end
        function set.CenterFrequencyCoefficient(obj,cfc)
           coder.internal.errorIf(~isnumeric(cfc) || ~isscalar(cfc) ...
                || ~isreal(cfc) || (cfc < -1 || cfc > 1), ['dsp:system',...
                ':NotchPeakFilter:centerFreqCoeff']);
            obj.CenterFrequencyCoefficient = cfc;
        end
        function cfc = get.CenterFrequencyCoefficient(obj)
            cfc = obj.CenterFrequencyCoefficient;
        end
        function set.PeakGain(obj,G)
            coder.internal.errorIf(~isnumeric(G) || ~isscalar(G) ||...
                ~isreal(G) || G < 0, ['dsp:system',...
                ':ParametricEQFilter:peakGain']);
            obj.PeakGain = G;
        end
        function set.PeakGaindB(obj,G)
            coder.internal.errorIf(~isnumeric(G) || ~isscalar(G) || ...
                ~isreal(G), ['dsp:system',...
                ':ParametricEQFilter:peakGaindB']);
            obj.PeakGaindB = G;
        end
        % Public Methods
        function bw = getBandwidth(obj)
            %BW = getBandwidth(obj) get filter bandwidth
            %   BW = getBandwidth(obj) returns the bandwidth for the
            %   parametric EQ filter. The bandwidth is measured halfway
            %   between 1 and the peak gain/cut of the filter measured in
            %   absolute power units (magnitude squared of the filter). If
            %   the Specification is set to 'Quality factor and center
            %   frequency', the bandwidth is determined from the quality
            %   factor value. If the Specification property is set to
            %   'Coefficients', the bandwidth is determined from the
            %   BandwidthCoefficient value and the sample rate.
            crossValidateProperties(obj);
            
            if strcmpi(obj.Specification,'Bandwidth and center frequency')
                bw = obj.Bandwidth;
            elseif strcmpi(obj.Specification,'Quality factor and center frequency')
                bw = obj.CenterFrequency/obj.QualityFactor;
            else
                Fs = obj.SampleRate;
                t = 2/(obj.BandwidthCoefficient + 1) - 1;
                bw = Fs/pi*atan(t);
            end
        end
        
        function bwc = getBandwidthCoefficient(obj)  
            %BWC = getBandwidthCoefficient(obj) get bandwidth coefficient
            %   BWC = getBandwidthCoefficient(obj) returns lattice allpass
            %   filter coefficient corresponding to the bandwidth for the
            %   parametric EQ filter. If the Specification is set to
            %   'Quality factor and center frequency', the bandwidth
            %   coefficient is determined from the quality factor value.
            crossValidateProperties(obj);
            
            Fs = obj.SampleRate;
            BW = getBandwidth(obj);            
            t  = tan(BW*pi/Fs);
            bwc = 2/(1+t)-1;         
        end

        function N = getOctaveBandwidth(obj)
            %N = getOctaveBandwidth(obj) bandwidth in number of octaves
            %   N = getOctaveBandwidth(obj) returns the bandwidth of the
            %   parametric EQ filter measured in number of octaves rather
            %   than Hz.
            crossValidateProperties(obj);
            
            Q = getQualityFactor(obj) ;
            N = 2/log(2)*asinh(1/(2*Q));
        end
        
        function Q = getQualityFactor(obj)
            %Q = getQualityFactor(obj) get quality (Q) factor
            %   Q = getQualityFactor(obj) returns the quality factor (Q
            %   factor) for the parametric EQ filter. The Q factor is
            %   defined as the center frequency divided by the bandwidth.
            crossValidateProperties(obj);
            
            if strcmpi(obj.Specification,'Bandwidth and center frequency')
                Q = obj.CenterFrequency/obj.getBandwidth;
            elseif strcmpi(obj.Specification,'Quality factor and center frequency')
                Q = obj.QualityFactor;
            else
                Q = getCenterFrequency(obj)/getBandwidth(obj);
            end
        end
        
        function cf = getCenterFrequency(obj)
            %CF = getCenterFrequency(obj) get center frequency
            %   CF = getCenterFrequency(obj) returns the center frequency
            %   for the parametric EQ filter. If the Specification property
            %   is set to 'Coefficients', the center frequency is
            %   determined from the CenterFrequencyCoefficient value and
            %   the sample rate.
            crossValidateProperties(obj);
            
            if strcmpi(obj.Specification,'Coefficients')
                Fs = obj.SampleRate;
                cf = Fs/(2*pi)*acos(-obj.CenterFrequencyCoefficient);
            else
                cf = obj.CenterFrequency;
            end
        end
        
        function cfc = getCenterFrequencyCoefficient(obj)  
            %CFC = getCenterFrequencyCoefficient(obj) get center freq coeff
            %   CFC = getCenterFrequencyCoefficient(obj) returns the
            %   lattice allpass coefficient corresponding to the center
            %   frequency for the parametric EQ filter.
                        %CFC = getCenterFrequencyCoefficient(obj) get center freq coeff
            %   CFC = getCenterFrequencyCoefficient(obj) returns the
            %   lattice allpass coefficient corresponding to the center
            %   frequency for the notch/peak filter.
            crossValidateProperties(obj);
            
            Fs = obj.SampleRate;            
            CF = getCenterFrequency(obj);            
            cfc = -cos(2*CF/Fs*pi);
        end
        
        function G = getPeakGain(obj)
            %G = getPeakGain(obj) get peak gain
            %   G = getPeakGain(obj) returns the peak gain/cut for the
            %   parametric EQ filter in absolute units.
            if strcmpi(obj.Specification,'Coefficients')
                G = obj.PeakGain;
            else
                GdB = getPeakGaindB(obj);
                G = 10^(GdB/20);
            end
        end
        
        function GdB = getPeakGaindB(obj)
            %GdB = getPeakGaindB(obj) get peak gain in dB
            %   G = getPeakGaindB(obj) returns the peak gain/cut for the
            %   parametric EQ filter in decibels.
            if strcmpi(obj.Specification,'Coefficients')
                G = obj.PeakGain;
                GdB = 20*log10(G);
            else
                GdB = obj.PeakGaindB;                
            end
        end
        function [b,a] = tf(obj)
            %[B,A] = tf(obj) Transfer function
            %   [B,A] = TF(obj) returns the vector of numerator
            %   coefficients B and the vector of denominator coefficients A
            %   for the equivalent transfer function corresponding to the
            %   parametric EQ filter.
            Fs = obj.SampleRate;
            bw = getBandwidth(obj);       dw = 2*pi*bw/Fs;
            f0 = getCenterFrequency(obj); w0 = 2*pi*f0/Fs;
            s  = tan(dw/2); sp1 = 1+s;
            G  = getPeakGain(obj); 
            a  = [1, -2*cos(w0)/sp1, (1-s)/sp1];
            b  = [(1+G*s)/sp1, -2*cos(w0)/sp1, (1-G*s)/sp1];
        end
        function realizemdl(~)
            coder.internal.errorIf(true, ['dsp:system',...
                ':ParametricEQFilter:realizemdl']);            
        end
        function c = coeffs(obj)
            c = coeffs(obj.NotchPeakFilterObj);
            c.Gain = getPeakGain(obj);
            c = rmfield(c,'Beta');
        end
        
        function c = cost(obj)           
            crossValidateProperties(obj);
            
            c.NumCoefficients = 4;
            c.NumStates =  2;
            c.MultiplicationsPerInputSample = 4;
            c.AdditionsPerInputSample = 9;
        end
    end
    
    methods (Access=protected)
        function setupImpl(obj, u)
            if strcmpi(obj.Specification,'Bandwidth and center frequency')
                obj.NotchPeakFilterObj = dsp.NotchPeakFilter(...
                    'Specification',obj.Specification,...
                    'Bandwidth', obj.Bandwidth, ...
                    'CenterFrequency',obj.CenterFrequency);
            elseif strcmpi(obj.Specification,'Quality factor and center frequency')
                Q = obj.getQualityFactor();
                obj.NotchPeakFilterObj = dsp.NotchPeakFilter(...
                    'Specification',obj.Specification,...
                    'QualityFactor',Q, ...
                    'CenterFrequency',obj.CenterFrequency);
            else
               obj.NotchPeakFilterObj = dsp.NotchPeakFilter(...
                    'Specification',obj.Specification,...
                    'BandwidthCoefficient', obj.BandwidthCoefficient, ...
                    'CenterFrequencyCoefficient',obj.CenterFrequencyCoefficient); 
            end
            setupImpl@dsp.internal.SampleRateEngine(obj,u);
            obj.NotchPeakFilterObj.SampleRate = obj.SampleRate;

            obj.InputDataType = class(u);
               
            processTunedPropertiesImpl(obj);

            numchan = getNumChannels(obj,u);

            cacheInputDimensions(obj.NotchPeakFilterObj , numchan);
            obj.NumChannels = int32(numchan);
        end
        
        function crossValidateProperties(obj)
            Fs = obj.SampleRate;
            if strcmpi(obj.Specification,'Bandwidth and center frequency')
                % Center frequency must be between 0 and Fs/2.
                CF = obj.CenterFrequency;
                coder.internal.errorIf(CF < 0 || CF > Fs/2, ['dsp:system',...
                    ':NotchPeakFilter:centerFreq'],floor(Fs) , ...
                    round((Fs - floor(Fs)) * 10));
                
                % Bandwidth must be between 0 and Fs/2.
                BW = obj.Bandwidth;
                coder.internal.errorIf(BW < 0 || BW > Fs/2, ['dsp:system',...
                    ':NotchPeakFilter:BW'],floor(Fs),...
                    round((Fs - floor(Fs)) * 10));
                
            elseif strcmpi(obj.Specification,'Quality factor and center frequency')
                % Center frequency must be between 0 and Fs/2.
                CF = obj.CenterFrequency;
                coder.internal.errorIf(CF < 0 || CF > Fs/2, ['dsp:system',...
                    ':NotchPeakFilter:centerFreq'],floor(Fs),...
                    round((Fs - floor(Fs)) * 10));
                
            end
        end
        
        function resetImpl(obj)
            % Specify initial values for DiscreteState properties
            reset(obj.NotchPeakFilterObj);
        end
        
        function y = stepImpl(obj, u)
            [y_notch,y_peak] = step(obj.NotchPeakFilterObj, u);
            
            % Final Output
            y = obj.privReferenceGain*y_notch + obj.privPeakGain*y_peak;
        end
                
        function processTunedPropertiesImpl(obj)
            inputDataTypeLocal = obj.InputDataType;
            if strcmpi(obj.Specification,'Bandwidth and center frequency')
                
                G0dB = cast(obj.ReferenceGaindB,inputDataTypeLocal);
                obj.privReferenceGain = 10^(G0dB/20);
                GdB  = cast(obj.PeakGaindB,inputDataTypeLocal);
                obj.privPeakGain = 10^(GdB/20);
                % Sync the NotchPeakFilterObj properties with the
                % ParametricEQFilter properties
                obj.NotchPeakFilterObj.Bandwidth = obj.Bandwidth;
                obj.NotchPeakFilterObj.CenterFrequency = obj.CenterFrequency;
            elseif strcmpi(obj.Specification,'Quality factor and center frequency')
                
                G0dB = cast(obj.ReferenceGaindB,inputDataTypeLocal);
                obj.privReferenceGain = 10^(G0dB/20);
                GdB  = cast(obj.PeakGaindB,inputDataTypeLocal);
                obj.privPeakGain = 10^(GdB/20);
                % Sync the NotchPeakFilterObj properties with the
                % ParametricEQFilter properties
                obj.NotchPeakFilterObj.CenterFrequency = obj.CenterFrequency;
                if obj.QualityFactor~=0
                    obj.NotchPeakFilterObj.QualityFactor = obj.QualityFactor;
                end

            else
               
                obj.privReferenceGain = ...
                    cast(obj.ReferenceGain,inputDataTypeLocal);
                obj.privPeakGain = ...
                    cast(obj.PeakGain,inputDataTypeLocal);
                % Sync the NotchPeakFilterObj properties with the
                % ParametricEQFilter properties
                obj.NotchPeakFilterObj.BandwidthCoefficient = obj.BandwidthCoefficient;
                obj.NotchPeakFilterObj.CenterFrequencyCoefficient = obj.CenterFrequencyCoefficient;
            end
            
            
        end
        
        function releaseImpl(obj)
            release(obj.NotchPeakFilterObj);           
            obj.NumChannels = int32(-1);        
        end
        
        function validateInputsImpl(obj,varargin)
            u = varargin{1};
            validateattributes(u, {'single', 'double'}, {'2d'},'','')
            if obj.NumChannels ~= -1
                coder.internal.errorIf(size(u,2) ~= obj.NumChannels, ['dsp:system',...
                    ':Shared:numChannels']);
            end
            
            % Cache input data type for filter analysis 
            if isempty(coder.target) 
                if ~isempty(u) 
                    cacheInputDataType(obj,u) 
                end 
            end
        end
        
        function flag = isInactivePropertyImpl(obj, prop)
            flag = false;
            specLocal = obj.Specification;
            switch prop
                case {'BandwidthCoefficient'}
                    if ~strcmp(specLocal, 'Coefficients')
                        flag = true;
                    end
                case {'CenterFrequencyCoefficient'}
                    if ~strcmp(specLocal, 'Coefficients')
                        flag = true;
                    end
                case {'ReferenceGain'}
                    if ~strcmp(specLocal, 'Coefficients')
                        flag = true;
                    end
                case {'PeakGain'}
                    if ~strcmp(specLocal, 'Coefficients')
                        flag = true;
                    end
                case {'Bandwidth'}
                    if ~strcmp(specLocal, 'Bandwidth and center frequency')
                        flag = true;
                    end
                case {'QualityFactor'}
                    if ~strcmp(specLocal, 'Quality factor and center frequency')
                        flag = true;
                    end
                case {'CenterFrequency'}
                    if strcmp(specLocal, 'Coefficients')
                        flag = true;
                    end
                case {'ReferenceGaindB'}
                    if strcmp(specLocal, 'Coefficients')
                        flag = true;
                    end
                case {'PeakGaindB'}
                    if strcmp(specLocal, 'Coefficients')
                        flag = true;
                    end
                otherwise
            end
        end
        
        function s = saveObjectImpl(obj)
            % Default implementation saves all public properties
            s = saveObjectImpl@dsp.internal.SampleRateEngine(obj);
            s.NotchPeakFilterObj = matlab.System.saveObject(obj.NotchPeakFilterObj);
            if isLocked(obj)
                % All the following are set at setup                                 
                s.privReferenceGain = obj.privReferenceGain;
                s.privPeakGain = obj.privPeakGain;               
                s.InputDataType = obj.InputDataType;
                s.NumChannels = obj.NumChannels;
            end
            s = saveFA(obj, s);   % Save filter analysis class properties
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            % Re-load state if saved version was locked
            if wasLocked
                % All the following were set at setup                
                obj.privReferenceGain = s.privReferenceGain;
                obj.privPeakGain = s.privPeakGain;                               
                obj.InputDataType = s.InputDataType;
                if isfield(s,'NumChannels')
                    obj.NumChannels = s.NumChannels;
                else
                    obj.NumChannels = int32(1);
                end
            end
            obj.NotchPeakFilterObj = matlab.System.loadObject(s.NotchPeakFilterObj);
            
            if ~isfield(s,'SampleRate')
               s.SampleRate =  obj.NotchPeakFilterObj.SampleRate;
            end

            % Call base class method
            loadObjectImpl@dsp.internal.SampleRateEngine(obj,s,wasLocked);
            % Load filter analysis class properties
            loadFA(obj, s, wasLocked); 
        end
        function D = convertToDFILT(obj, arith)
        	crossValidateProperties(obj);
        	
            % Fixed-point analysis is not currently supported
            assert(strcmpi(arith,'single') || strcmpi(arith,'double'));
            
            if ~isLocked(obj)
                obj.NotchPeakFilterObj.SampleRate = obj.SampleRate;
            end
            
            G  = cast(getPeakGain(obj),arith); 
            a1 = cast(getBandwidthCoefficient(obj),arith);
            a2 = cast(getCenterFrequencyCoefficient(obj),arith);
            D  = cascade(...
                    dfilt.scalar(0.5),...
                    parallel(...
                        parallel(dfilt.scalar(1),dfilt.latticeallpass([a2;a1])),...
                        cascade(...
                            parallel(...
                                dfilt.scalar(1),...
                                cascade(dfilt.latticeallpass([a2;a1]),dfilt.scalar(-1))...
                            ),...
                            dfilt.scalar(G)...
                        )...
                    )...
                 );
             D.SystemObjParams.SampleRate = obj.SampleRate;
        end
        
        function dt = getTunablePropertiesSpecificationImpl(obj,~)
            dt = propagatedInputDataType(obj,1);
        end
        
    end
    
    %--------------------------------------------------------------------------
    % Hidden methods
    %--------------------------------------------------------------------------
    methods (Hidden)
        % Methods required for filter analysis functionality
        function restrictionsCell = getFixedPointRestrictions(~,~)
            restrictionsCell = {};
        end
        %------------------------------------------------------------------------
        function props = getFixedPointProperties(~)
            props = {}; 
        end
        %------------------------------------------------------------------------
        function props = getNonFixedPointProperties(obj)
            props = obj.getPropertyNames;
            idxtoprune = [];
            for k = 1:length(props)
                if(isInactiveProperty(obj, props{k})) 
                    idxtoprune = [idxtoprune, k]; %#ok
                end
            end
            props(idxtoprune) = [];
        end
        %------------------------------------------------------------------------
        function flag = isPropertyActive(obj,prop)
            flag = ~isInactiveProperty(obj, prop);
        end
        %------------------------------------------------------------------
        function f = callFvtool(obj)
            % Used to bring up fvtool plot when object is used in Simulink
            f = fvtool(obj);
            set(f, 'Fs', obj.SampleRate);
        end
        
        function f = updateFvtoolFigure(obj,f)
            % Used to update fvtool plot when object is used in Simulink
            setfilter(f, obj);
            set(f, 'Fs', obj.SampleRate);
        end
    end
    
    %------------------------------------------------------------------------
    methods(Static, Hidden)
        function checkVal(Q)
            coder.internal.errorIf(~isnumeric(Q) || ~isscalar(Q) ||...
                 ~isreal(Q) || Q <= 0, ['dsp:system',...
                ':NotchPeakFilter:QFactor']);
        end
    end    
    
    methods(Static, Access=protected)
        function mainS = getPropertyGroupsImpl
            %Get default parameters group for this System object
            
            propertyList = {'Specification','Bandwidth',...
                'CenterFrequency','BandwidthCoefficient','PeakGaindB',...
                'CenterFrequencyCoefficient','QualityFactor',...
                'PeakGain'};
            depPropertyList = {'Specification','Bandwidth',...
                'CenterFrequency','BandwidthCoefficient',...
                'CenterFrequencyCoefficient','QualityFactor'};
            mainS = matlab.system.display.Section(...
                'Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', [propertyList,'InheritSampleRate' , 'SampleRate' ],...
                'DependOnPrivatePropertyList',depPropertyList);
            
            filterVis = dsp.internal.FilterVisualizationButton;
            mainS.Actions = filterVis.fvtoolAction;
        end
        
         %------------------------------------------------------------------
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.ParametricEQFilter', ...
                'ShowSourceLink', true, ...
                'Title', getString(message('dsp:system:ParametricEQFilter:BlockTitle')),...
                'Text',  getString(message('dsp:system:ParametricEQFilter:BlockHeader')));
        end
    end
end
