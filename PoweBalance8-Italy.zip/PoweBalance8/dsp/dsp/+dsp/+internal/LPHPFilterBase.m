classdef LPHPFilterBase < dsp.internal.NormalizedSampleRateEngine & ...
        dsp.internal.FilterAnalysis
    %

    % Copyright 2014-2020 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCA>
    properties (Nontunable)
        %FilterType Filter type
        %   Set the specification as one of 'FIR' | 'IIR'. The default is
        %   'FIR'.
        FilterType (1, :) char {matlab.system.mustBeMemberMessageID(FilterType, ...
            {'dsp:system:HPLPFilter:FilterType_FIR'; ...
            'dsp:system:HPLPFilter:FilterType_IIR'})} = 'FIR';        
    end

    properties (Nontunable)
        % SampleRate Input sample rate (Hz)
        %   Specify the sampling rate of the input in Hertz as a finite
        %   numeric scalar. the default is 44100 Hz.
       SampleRate = 44100; 

        %DesignForMinimumOrder Design minimum order filter
        %   When you set this property to true, the object designs filters
        %   with the minimum order that meets the passband frequency,
        %   stopband frequency, passband ripple, and stopband attenuation
        %   specifications that you set using the corresponding properties.
        %   When you set this property to false, the object designs filters
        %   with order that you specify in the FilterOrder property. This
        %   filter design meets the passband frequency, passband ripple,
        %   and stopband attenuation specifications that you set using the
        %   respective properties. Specify it as a logical scalar. The
        %   default value of this property is true.
        DesignForMinimumOrder (1, 1) logical = true;
    
        %FilterOrder Filter order
        %   Specify the order for the designed filter, as a positive
        %   integer scalar. This property applies when you set the
        %   DesignForMinimumOrder property to false. The default value of
        %   this property is 50.
        FilterOrder = 50;
        %PassbandRipple Maximum passband ripple (dB)
        %   Specify the maximum allowed ripple in the passband of the
        %   filter response, as a positive real scalar in decibels (dB).
        %   The default value of this property is 0.1 dB.
        PassbandRipple = 0.1;
        %StopbandAttenuation Minimum stopband attenuation (dB)
        %   Specify the attenuation to be achieved in the stopband of the
        %   designed filter response, as a positive real scalar in
        %   decibels (dB). The default value of this property is 80 dB.
        StopbandAttenuation = 80;
        
        %RoundingMethod Rounding method for fixed-point operations 
        %   Specify the rounding method for output as one of ['Ceiling' |
        %   'Convergent' | 'Floor' | 'Nearest' | 'Round' | 'Simplest' |
        %   'Zero']. The default value of this property is 'Floor'.
        RoundingMethod = 'Floor';
        
        %CoefficientsDataType Coefficients word and fraction lengths
        %   Specify the coefficients fixed-point type as a signed
        %   numerictype object. The default value of this property is
        %   numerictype(1,16).
        %
        %   See also numerictype.
        CoefficientsDataType = numerictype(1, 16);
    end
    
    properties (Constant, Hidden)
        RoundingMethodSet = matlab.system.internal.RoundingMethodSet;
        CoefficientsDataTypeSet = matlab.system.internal.DataTypeSet(...
            { matlab.system.internal.CustomDataType( ...
            'Signedness', {'Signed'}, 'Scaling', {'Unspecified', 'BinaryPoint'})});
        % Filter types
    end
    
    properties (Access = protected)
        NumChannels = int32(-1)
        FilterObj
        IsFilterDesigned = false;
    end
    
    %--------------------------------------------------------------------------
    % Abstract methods
    %--------------------------------------------------------------------------
    methods (Abstract, Access = protected)
        % Abstract method. Children objects re-define this method.
        b = computeFIRCoefficients(~,~)
    end

    methods

        function set.SampleRate(obj,val)
            validateattributes(val,...
                {'double','single'}, ...
                {'real','scalar','positive','finite'},...
                '','SampleRate');
            obj.SampleRate = val;
            needToDesignFilters(obj);
        end
        
        function set.FilterType(obj,t)
            
            obj.FilterType = t;
            needToDesignFilters(obj);
        end
        
        function set.DesignForMinimumOrder(obj,flag)
            validateattributes(flag,{'logical'},{'scalar'},'');
            obj.DesignForMinimumOrder = flag;
            needToDesignFilters(obj);
        end
        
        function set.FilterOrder(obj,N)
            validateattributes(N,{'numeric'},{'finite','scalar','real',...
                'integer','positive'},'','FilterOrder');
            obj.FilterOrder = N;
            needToDesignFilters(obj);
        end              
        
        function set.PassbandRipple(obj,Apass)
            validateattributes(Apass,{'numeric'},{'finite','scalar','real',...
                'positive','<=',10},'','PassbandRipple');
            obj.PassbandRipple = Apass;
            needToDesignFilters(obj);
        end
        
        function set.StopbandAttenuation(obj,Astop)
            validateattributes(Astop,{'numeric'},{'finite','scalar','real',...
                'positive','<=',180},'','StopbandAttenuation');
            obj.StopbandAttenuation = Astop;
            needToDesignFilters(obj);
        end
        
        function set.RoundingMethod(obj,val)
            obj.RoundingMethod = val;
            needToDesignFilters(obj)
        end

        function set.CoefficientsDataType(obj, val)
            obj.CoefficientsDataType = val;
            needToDesignFilters(obj)
        end
        
        function F = getFilter(obj, varargin)
            %F = getFilter(obj) get underlying FIR or Biquad filter
            %   F = getFilter(obj) returns the underlying filter F
            %   used to implement the filter designed for the given
            %   specifications.
            %
            %   F = getFilter(obj, inNT) returns the underlying filter F
            %   used to implement the filter designed for the given
            %   specifications for the input numerictype inNT.
            if nargin > 1
                inNT = varargin{1};
                if isfixed(inNT)
                    designFilter(obj, fi(0, inNT));
                else
                    designFilter(obj,inNT);
                end
            else
                % Design with doubles
                designFilter(obj,0);
            end
            F = clone(obj.FilterObj);
        end
        
        function fdhdltool(obj,InputNumericType)
            %   FDHDLTOOL(FO, nt) launches the Generate HDL dialog that lets you
            %   customize and generate Verilog or VHDL code and test benches for
            %   the filter System object, FO. You have to call FDHDLTOOL
            %   again if you make changes in the filter, FO, in the command line.
            %
            %   The main dialog and two subordinate dialogs provide access to many
            %   options for customizing the generated filter and test bench code.
            %
            %   The Generate HDL main dialog categorizes options in two frames:
            %
            %   * HDL Filter - Options you are most likely to customize at least once:
            %   language selection, name and location of generated files, reset
            %   specifications, and optimizations.
            %
            %   * Test bench types - Options for naming and specifying the type of test
            %   bench files to generate, and specific types of stimuli the test benches
            %   are to apply.
            %
            %   EXAMPLE:
            %   fo  = dsp.LowpassFilter;
            %   inT = numerictype(1,16,15);
            %   fdhdltool(fo, inT)
            
            if ~exist('InputNumericType','var')
                error(message('hdlfilter:privgeneratehdl:fdhdltoolinputdatatypenotspecified'));
            end
            
            sysObj = getFilter(obj, InputNumericType);
            fo     = sysobjHdl(sysObj, 'InputDataType', InputNumericType);
            fdhdltool(fo);
        end
        
        function generatehdl(obj,varargin)
            %   GENERATEHDL(FO, 'InputDataType', nt) automatically generates VHDL
            %   or Verilog code for the filter System object, FO. The default
            %   language is VHDL; to generate Verilog, supply the
            %   property/value pair 'TargetLanguage','Verilog'. The file is written to
            %   the HDL source directory which defaults to 'hdlsrc' under the
            %   current directory. This directory will be created if necessary.
            %
            %   GENERATEHDL(FO, PARAMETER1, VALUE1, PARAMETER2, VALUE2, ...)
            %   generates the HDL code with parameter/value pairs. Valid properties
            %   and values for GENERATEHDL are listed in the Filter Design HDL
            %   Coder documentation section "Property Reference."
            %
            %   EXAMPLE:
            %   fo  = dsp.LowpassFilter;
            %   inT = numerictype(1,16,15);
            %   generatehdl(fo, 'InputDataType', inT)
            
            for k = 1:length(varargin)
                if iscell(varargin{k})
                    [varargin{k}{:}] = convertStringsToChars(varargin{k}{:});
                else
                    varargin{k} = convertStringsToChars(varargin{k});
                end
            end
            
            if nargin > 1 && any(strcmpi(varargin, 'InputDataType'))
                inT_Indices = find(strcmpi(varargin, 'InputDataType'));
                inNT = varargin{(inT_Indices(1) + 1)};
            else
                inNT = numerictype('double');
            end
            sysObj = getFilter(obj, inNT);
            fo     = sysobjHdl(sysObj, varargin{:});
            generatehdl(fo, varargin{:}, 'FilterSystemObject', clone(obj));
        end
    end
    %----------------------------------------------------------------------
    methods (Abstract, Access = protected)
        designFilter(obj,u)
    end
    %----------------------------------------------------------------------
    methods (Access = protected)

        function setupImpl(obj,u)
            
            setupImpl@dsp.internal.NormalizedSampleRateEngine(obj,u);
            
            if ~isfloat(u)
                % Always design filters if setup is called with fixed-point
                % input. This is because getFilter method may have designed
                % filter with a default input data type for fixed-point
                % filter analysis.
                needToDesignFilters(obj);
                designFilter(obj,u);
            else
                designFilter(obj,u);
            end
        end

        function y = stepImpl(obj,u)
            % Implement algorithm. Calculate y as a function of
            % input u and discrete states.

            y = step(obj.FilterObj,u);
        end
        
        function resetImpl(obj)
            reset(obj.FilterObj);
        end
        
        function releaseImpl(obj)
            % Release the filter
            release(obj.FilterObj);
            obj.NumChannels = int32(-1);
        end
        
        function validateInputsImpl(obj,u)
            
            validateattributes(u, {'numeric','embedded.fi'}, {},'','Input');
            
            % input cannot be unsigned complex fixed-point
            if isfi(u)
                coder.internal.errorIf(~issigned(u) && ~isreal(u), ...
                    'dsp:system:CICCompensationInterpolator:inputUnsignedComplexFixedPoint');
            end
            
            % Cache input data type for filter analysis
            if isempty(coder.target)
                if ~isempty(u)
                    cacheInputDataType(obj,u)
                end
            end

            % Check channel count consistency. This method is called only
            % on the first step or if the input characteristics (i.e.
            % datatype or dimensions) have changed. 
            
            if obj.NumChannels ~= -1
                coder.internal.errorIf(size(u,2) ~= obj.NumChannels, 'dsp:system:Shared:numChannels');
            else
                % Cache number of channels
                obj.NumChannels = int32(getNumChannels(obj,u));
            end

        end
        
        function s = saveObjectImpl(obj)
            % Default implementation saves all public properties
            s = saveObjectImpl@dsp.internal.NormalizedSampleRateEngine(obj);
            % Private properties
            s.FilterObj = matlab.System.saveObject(obj.FilterObj);
            s.IsFilterDesigned = obj.IsFilterDesigned;
             if isLocked(obj)
                % All the following are set at setup                                 
                s.NumChannels = obj.NumChannels;
            end
            s = saveFA(obj, s);   % Save filter analysis class properties
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            if isfield(s, 'CoefficientsDataType')
                % backwards compatibility for objects saved before R2015b
                if strcmp(s.CoefficientsDataType.Signedness, 'Auto')
                    s.CoefficientsDataType.Signedness = 'Signed';
                end
            end
             if wasLocked
                % All the following were set at setup                
                obj.NumChannels = s.NumChannels;
            end
            % Private properties
            obj.FilterObj = matlab.System.loadObject(s.FilterObj);
            
            obj.IsFilterDesigned = s.IsFilterDesigned;
            
            % Call base class method
            loadObjectImpl@dsp.internal.NormalizedSampleRateEngine(obj, s, wasLocked);
                     
            % Load filter analysis class properties
            loadFA(obj, s, wasLocked); 
        end
        
        function needToDesignFilters(obj)
            obj.IsFilterDesigned = false;
        end
        
        function flag = isInactivePropertyImpl(obj, prop)
            flag = false;
            minord = obj.DesignForMinimumOrder;
            switch prop
                case {'FilterOrder'}
                    if minord
                        flag = true;
                    end
                case {'StopbandFrequency'}
                    if ~minord
                        flag = true;
                    end
                case {'SampleRate'}
                    if obj.getExecPlatformIndex()
                        if ~isSampleRateOnDialog(obj)
                            flag = true;
                        end
                    else
                        flag = obj.NormalizedFrequency;
                    end
            end
        end
        
        function d = convertToDFILT(obj,arith)
            % Convert the System object to a DFILT object for analysis
            sysObj = getFilter(obj);
            
            if strcmp(arith,'fixed') && ~isLocked(sysObj)
                % ==== UNLOCKED SYSTEM OBJECT ====
                if strcmp(obj.FilterType,'FIR')
                    sysObj.CoefficientsDataType = 'Custom';
                    cffT = obj.CoefficientsDataType;
                    if strcmpi(cffT.DataTypeMode, ...
                            'Fixed-point: unspecified scaling')
                        sysObj.CustomCoefficientsDataType = ...
                            numerictype(true,cffT.WordLength);
                    elseif strcmpi(cffT.DataTypeMode, ...
                            'Fixed-point: binary point scaling')
                        sysObj.CustomCoefficientsDataType = ...
                            numerictype(true, cffT.WordLength, ...
                            cffT.FractionLength);
                    end
                    
                else
                    % IIR (dsp.BiquadFilter)
                    
                    % NO WAY TO SPECIFY csvT SEPARATELY in Lowpass/Highpass
                    cffT = obj.CoefficientsDataType;
                    csvT = cffT;
                    
                    % COMPUTE FIXED-POINT BEST PRECISION TYPES EXPLICITLY
                    if strcmpi(cffT.DataTypeMode, ...
                            'Fixed-point: unspecified scaling')
                        cffT.DataTypeMode = ...
                            'Fixed-point: binary point scaling';
                        cffT.FractionLength = cffT.WordLength - 2;

                        tmpT = numerictype( ...
                            fi(sysObj.ScaleValues, 1, cffT.WordLength) );
                        csvT.DataTypeMode = ...
                            'Fixed-point: binary point scaling';
                        csvT.FractionLength = tmpT.FractionLength;
                    end
                    
                    if isfixed(cffT)
                        % BiquadFilter only accepts 'Auto' signedness
                        cffT.Signedness = 'Auto';
                        sysObj.NumeratorCoefficientsDataType = 'Custom';
                        sysObj.DenominatorCoefficientsDataType = 'Custom';
                        sysObj.CustomNumeratorCoefficientsDataType = cffT;
                        sysObj.CustomDenominatorCoefficientsDataType = cffT;
                    end
                    
                    if isfixed(csvT)
                        csvT.Signedness = 'Auto';
                        sysObj.ScaleValuesDataType = 'Custom';
                        sysObj.CustomScaleValuesDataType = csvT;
                    end
                end
                
            end
            
            d = todfilt(sysObj,arith);
        end
        
        function Fs = getSampleRate(obj)
            if ~isInactivePropertyImpl(obj, 'SampleRateMode')
                % Call from simulink object
                if isSampleRateNormalized(obj)
                    Fs = 2;
                elseif isSampleRateInherited(obj)
                    Fs = getInheritedSampleRate(obj);
                else
                    Fs = obj.SampleRate;
                end
            else
                if obj.NormalizedFrequency
                   Fs = 2;
               else
                   Fs = obj.SampleRate;
                end
            end
        end
        
        %%Propagators
        function cp = isOutputComplexImpl(obj)
            cp = propagatedInputComplexity(obj, 1);
        end
        
        function sz = getOutputSizeImpl(obj)
            sz= propagatedInputSize(obj, 1);
        end
        
        function isfixed = isOutputFixedSizeImpl(obj)
            isfixed = propagatedInputFixedSize(obj,1);
        end
        
        function varargout = getOutputDataTypeImpl(obj)
            inputDT = propagatedInputDataType(obj,1);
            if isempty(inputDT)
               return; 
            end
            coder.internal.errorIf(isSampleRateInherited(obj) && ~ischar(inputDT) && strcmp(obj.FilterType,'FIR'), ...
                'dsp:system:Shared:fixedPointWithInheritSampleRate');
            if (ischar(inputDT) && any(strcmp(inputDT,{'double', 'single'})))
                varargout{1} = inputDT;
            else
                if ischar(inputDT)
                    % For integer input
                    inputDT = numerictype(inputDT);
                end
                switch obj.FilterType
                    case 'FIR'
                        b = computeFIRCoefficients(obj);
                        w = fi(b, obj.CoefficientsDataType);  % vector of filter weights of type fi
                        % compute output data type
                        [~,~,outputWL, outputFL] = coder.const(@dsp.internal.LPHPFilterBase.firPrecision, ...
                            w,inputDT);
                        varargout{1} = numerictype(true, outputWL, outputFL);
                    case 'IIR'
                        % Determine DT
                        cTin = obj.CoefficientsDataType;
                        [~,secT] = coder.const(@dsp.internal.LPHPFilterBase.biquadPrecision,cTin,inputDT);
                        varargout{1} = numerictype(true, secT.WordLength, secT.FractionLength);
                end
            end
        end
        
        function val = supportsMultipleInstanceImpl(~)
            val = true;
        end
        
        function name = getInputNamesImpl(~)
            name = '';
        end
        
        function name = getOutputNamesImpl(~)
            name = '';
        end
        
    end
    
    %----------------------------------------------------------------------
    methods (Hidden)
        function flag = isPropertyActive(obj,prop)
            % Need to implement this for dsp.internal.FilterAnalysisMultirate
            flag = ~isInactivePropertyImpl(obj, prop);
        end
        
        function props = getFixedPointProperties(~)
            % Need to implement this for dsp.internal.FilterAnalysisMultirate
            props = dsp.internal.LPHPFilterBase.getDisplayFixedPointPropertiesImpl;
        end
        
        function restrictionsCell = getFixedPointRestrictions(obj,prop)
            % Need to implement this for dsp.internal.FilterAnalysisMultirate
            switch prop
                case {'CoefficientsDataType'}
                    restrictionsCell = {};
                otherwise
                    error(message(...
                        'dsp:dsp:private:FilterSystemObjectBase:InvalidProperty',prop,class(obj)))
            end
        end
        
        function props = getNonFixedPointProperties(~)
            props = dsp.internal.LPHPFilterBase.getDisplayPropertiesImpl;
        end
    end
    %---------------------------------------------------------------------
    methods (Static,Hidden)

        function props = getDisplayFixedPointPropertiesImpl()
            % Need to implement this for dsp.internal.FilterAnalysisMultirate
            props = {...
                'RoundingMethod','CoefficientsDataType'};
        end
        
        function helpFixedPoint
            %helpFixedPoint Display LowpassFilter System
            %               object fixed-point information
            %   dsp.LowpassFilter.helpFixedPoint displays
            %   information about fixed-point properties and operations of
            %   the LowpassFilter System object.
            
            matlab.system.dispFixptHelp('dsp.LowpassFilter', ...
                dsp.LowpassFilter.getDisplayFixedPointPropertiesImpl);
        end
        
        function [accWL,accFL,outputWL, outputFL] = firPrecision(w,u)
            %filterPrecision Determine filter precision settings.
            
            [A,Q] = dsp.internal.FIRFilterPrecision(w,u);
            accWL = A.WordLength;
            if accWL == 1
                % FIR does not support wordlength less than 2
                accWL = 2;
            end
            accFL = A.FractionLength;
            
            outputWL = Q.WordLength;
            outputFL = Q.FractionLength;
            
            
        end
        
        function [cT,secT,prodT,accT] = biquadPrecision(cTin,u)
            
            % Determine coeff DT   
            cT = cTin;
            cT.Signedness = 'Auto';
            if strcmpi(cT.DataTypeMode,'Fixed-point: unspecified scaling')
                cT.DataTypeMode='Fixed-point: binary point scaling';                
                cT.FractionLength = cT.WordLength - 2;
            end
            
            % Determine section input DT
            secWL = u.WordLength;
            secFL = u.FractionLength-1; % Make sure to avoid overflow
            secT  = numerictype([],secWL,secFL);
            
            % Determine Num Product DT
            prodWL = secWL + cT.WordLength;
            prodFL = secFL + cT.FractionLength;
            prodT  = numerictype([],prodWL,prodFL);
            
            % Determine Num Acc DT
            accWL = prodWL + 2;
            accFL = prodFL;
            accT  = numerictype([],accWL,accFL);
                     
        end
    end  
end
