classdef SlidingWindowVarianceCG < matlab.System
% SlidingWindowVarianceCGOverlap This class is internally used by
% dsp.MovingVariance in the sliding window mode

% The algorithm can be found in "Algorithms for computing the sample
% variance: analysis and recommendations" (Chan, Golub and LeVeque). 
% 

%   Copyright 2016-2021 The MathWorks, Inc.

    %#codegen
    %#ok<*EMCLS>
    
    properties (Nontunable)
        % WindowLength Sliding window length
        WindowLength (1, 1) {mustBePositive, mustBeInteger} = int32(4);
        HopSize (1, 1) {mustBePositive, mustBeInteger} = int32(1);
    
       NumChans = 1
    end
    properties (Nontunable, Logical, Hidden)
        isFixedOutput = true
    end
    
    properties(Access = private)
        pReverseSamples
        pReverseT
        pReverseS
        pT
        pS
        pM
        pCounter
        % pModValueRev Counter to keep track of the input sample index 
        % at which next output needs to be generated
        pModValueRev
    end
    
    methods
        function obj = SlidingWindowVarianceCG(varargin)
            setProperties(obj,nargin,varargin{:});
        end
    end
    
    methods(Access = protected)

        function setupImpl(obj,u)
            if isreal(u)
               sz =  obj.NumChans;
            else
               sz =  2 * obj.NumChans; 
            end
            obj.pReverseSamples = zeros(obj.WindowLength,sz,class(u));
            obj.pReverseT       = zeros(obj.WindowLength,sz,class(u));
            obj.pReverseS       = zeros(obj.WindowLength,sz,class(u));
            obj.pT              = zeros(1,sz,class(u));
            obj.pS              = zeros(1,sz,class(u));
            obj.pM              = zeros(1,sz,class(u));
            obj.pCounter        = zeros(1,1,class(u));
            obj.pModValueRev    = cast(obj.HopSize - 1,class(u));
        end
        
        function z = stepImpl(obj,u)
            
            N              = cast(obj.WindowLength,class(u));
            hopSize        = cast(obj.HopSize,class(u));
            if (N==1)
                z = zeros(size(u),class(u));
                return;
            end
            reverseSamples = obj.pReverseSamples;
            reverseT       = obj.pReverseT;
            reverseS       = obj.pReverseS;
            T              = obj.pT;
            S              = obj.pS;
            M              = obj.pM;
            counter        = obj.pCounter;
            modValueRev    = obj.pModValueRev;
            modIndex       = int32(1);            
            
            L = cast(size(u,1),class(u));
            if isreal(u)
                % Pre-allocate output
                % Size of output signal is calculated using size of input,
                % hopSize, modValueRev
                if (hopSize == 1)  
                    y = zeros(size(u),class(u)); 
                elseif coder.const(obj.isFixedOutput)
                    % For codegen to create fixed size outputs when
                    % ForceFixedSize is set to true in simulink block
                    y = zeros([floor((L-1)/hopSize)+1,size(u,2)],class(u));
                else 
                    y = zeros([floor((L-abs(modValueRev)-1)/hopSize)+1,size(u,2)],class(u));
                end
                x = u;
            else
                % Pre-allocate output
                % Size of output signal is calculated using size of input,
                % hopSize, modValueRev
                if (hopSize == 1)  
                    y = zeros([size(u,1),2*size(u,2)],class(u)); 
                elseif coder.const(obj.isFixedOutput)
                    % For codegen to create fixed size outputs 
                    y = zeros([floor((L-1)/hopSize)+1,2*size(u,2)],class(u));
                else 
                    y = zeros([floor((L-abs(modValueRev)-1)/hopSize)+1,2*size(u,2)],class(u));
                end              
                x = zeros(size(u,1),2*size(u,2),class(u));
                for index = 1:size(u,2)
                   x(:,(index-1) *2+1) = real(u(:,index));
                   x(:,(index-1) *2+2) = imag(u(:,index));
                end
            end

            if isreal(u)
               nc =  obj.NumChans;
            else
               nc =  2 * obj.NumChans; 
            end
            
            for index = 1:size(x,1)
                
                xin = x(index,1:nc);
                
                T = T + xin;
                
                Mprev = M;
                
                M = M + (1/counter) * (xin - M); % (1.3a)
                
                S = S + (counter - 1) * (xin-Mprev).*(xin - Mprev)/counter; % (1.3b)
                
                m = counter;
                n = N - counter;
                
                % Combine forward and reverse variance (1.5b)
                % Output is generated at current sample if modValueRev is 0
                if (modValueRev == 0)
                    y(modIndex,:) = (S + reverseS(N-counter,:) + (m/(n*(m+n))) *((n/m)*T - reverseT(N-counter,:)).^2) / (N-1);
                    %Increment the index of output signal
                    modIndex = modIndex + 1;
                end
                
                reverseSamples(N-counter,:) = xin;
                
                if counter < N - 1
                    counter = counter + 1;
                else
                    counter  = cast(1,class(x));
                    reverseT = cumsum(reverseSamples);
                    reverseM = zeros(1,size(reverseS,2),'like',reverseS);
                    reverseSPrev = zeros(1,size(reverseS,2),'like',reverseS);
                    % Compute reverse variance
                    for index2 = 1:N-1
                        reverseMPrev = reverseM;
                        reverseM = reverseM + (1/index2) * (reverseSamples(index2,:) - reverseM); %(1.3a)
                        reverseS(index2,:) = reverseSPrev + (index2-1) * (reverseSamples(index2,:) - reverseMPrev) .* (reverseSamples(index2,:) - reverseMPrev) / index2; % (1.3b)
                        reverseSPrev = reverseS(index2,:);
                    end
                    T = zeros(1,size(T,2),'like',T);
                    S = zeros(1,size(S,2),'like',S);
                    M = zeros(1,size(M,2),'like',M);
                end
               % modValueRev is decremented if it is greater than 0
               % Else it is reset it to hopSize - 1
               if (modValueRev > 0)
                   modValueRev = modValueRev - 1;
               else
                   modValueRev(:) = hopSize - 1;
               end
                
            end
            
            obj.pReverseSamples = reverseSamples;
            obj.pReverseT = reverseT;
            obj.pReverseS = reverseS;
            obj.pT        = T;
            obj.pS        = S;
            obj.pM        = M;
            obj.pCounter  = counter;
            obj.pModValueRev = modValueRev;
            
            if isreal(u)
                z = y;
            else
                % Sum variance of real and imaginary parts
                z = zeros([size(y,1), size(u,2)],class(u));                 
                for index = 1:size(u,2)
                   z(:,index) = y(:,(index-1) *2+1) + y(:,(index-1) *2+2);
                end
            end
            
        end
        
        function resetImpl(obj)
            obj.pReverseSamples(:) = 0; 
            obj.pReverseT(:)       = 0;
            obj.pReverseS(:)       = 0;
            obj.pT(:)              = 0;
            obj.pS(:)              = 0;
            obj.pM(:)              = 0;
            obj.pCounter(:)        = 1;
            obj.pModValueRev(:)    = obj.HopSize - 1;
        end
        
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            if isLocked(obj)
                s.pReverseSamples = obj.pReverseSamples;
                s.pReverseT = obj.pReverseT;
                s.pReverseS = obj.pReverseS;
                s.pT        = obj.pT;
                s.pS        = obj.pS;
                s.pM        = obj.pM;
                s.pCounter  = obj.pCounter;
                s.pModValueRev = obj.pModValueRev;
            end
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                obj.pReverseSamples = s.pReverseSamples;
                obj.pReverseT       = s.pReverseT;
                obj.pReverseS       = s.pReverseS;
                obj.pT              = s.pT;
                obj.pS              = s.pS;
                obj.pM              = s.pM;
                obj.pCounter        = s.pCounter;
                if isfield(s,'pModValueRev')
                    obj.pModValueRev    = s.pModValueRev;
                end
            end
            loadObjectImpl@matlab.System(obj, s, wasLocked);
        end
    end
end
