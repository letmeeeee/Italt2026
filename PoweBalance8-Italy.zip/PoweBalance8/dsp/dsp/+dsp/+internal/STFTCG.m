classdef STFTCG < handle &  matlab.mixin.internal.indexing.Paren
% This class is used for code generation of dsp.STFT    

% Copyright 2018-2020 The MathWorks, Inc.

%#codegen
    
    properties (Dependent)
        % Same interface as dsp.STFT
        Window
        OverlapLength
        FFTLength
        FrequencyRange
    end
    
    properties (Access = private)
        % this is a System object that performs STFT
        pObj
    end

    methods
        
        function obj = STFTCG(varargin)
            obj.pObj = dsp.internal.STFTSysObj(varargin{:});
        end
        
        function f = getFrequencyVector(obj,varargin)
           f = obj.pObj.getFrequencyVector(varargin{:}); 
        end
        
        % Set/get
        function set.Window(obj,val)
           validateattributes(val,{'numeric'}, ...
                {'vector','real','nonnan'}, ...
                'set.Window','Window');
            obj.pObj.Window = val;
        end
        function set.OverlapLength(obj,val)
            validateattributes(val,{'numeric'}, ...
                {'scalar','integer','nonnegative','real','nonnan'}, ...
                'set.OverlapLength','OverlapLength');
            obj.pObj.OverlapLength = val;
        end
        function set.FFTLength(obj,val)
            validateattributes(val,{'numeric'}, ...
                {'scalar','integer','positive','real','nonnan'}, ...
                'set.FFTLength','FFTLength');
            obj.pObj.FFTLength = val;
        end
        function set.FrequencyRange(obj,val)
           obj.pObj.FrequencyRange = val; 
        end
        function val = get.Window(obj)
            val = obj.pObj.Window;
        end
        function val = get.OverlapLength(obj)
            val = obj.pObj.OverlapLength;
        end
        function val = get.FFTLength(obj)
            val = obj.pObj.FFTLength;
        end
        function val = get.FrequencyRange(obj)
           val = obj.pObj.FrequencyRange; 
        end
        
        % Mirror dsp.STFT methods
        function y = setup(obj,u)
            y = setup(obj.pObj,u);
        end
        
        function y = step(obj,u)
            y = step(obj.pObj,u);
        end
        
        function reset(obj)
            reset(obj.pObj);
        end
        
        function release(obj)
             release(obj.pObj);
        end
    end
    
    methods (Static)
        function out = matlabCodegenToRedirected(~)
            out  = dsp.internal.STFTCG;
        end
        
        function out = matlabCodegenFromRedirected(~)
            out = dsp.STFT;
        end
    end
    methods (Hidden, Static)
        function name = matlabCodegenUserReadableName
            name = 'dsp.STFT';
        end
    end
    
    %----------------------------------------------------------------------
    % Hidden, Sealed methods
    %----------------------------------------------------------------------
    methods  (Hidden=true,Sealed=true)
        function Y = parenReference(obj,u)
            % This is used to enable stepping the object with function
            % notation.
            Y = step(obj,u);
        end
    end
    
end