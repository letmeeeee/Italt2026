% This script computes the filter coefficients for the DDC object used in
% the SpectralEstimator object.

%   Copyright 2012-2019 The MathWorks, Inc.


% Overall DDC response should have cutoff frequency at the output Nyquist
% rate and passband frequency at PBW% of the cutoff frequency value.
% Coefficients are computed for various decimation factors starting at M =
% 4. Passband ripple of the filters is Apass dB and stopband attenuation is
% Astop dB. The decimation factors, number of CIC sections and second and
% third stage coefficients are stored in structures withing a
% containers.Map with key names equal to the corresponding decimation
% factor.

PBW   = 0.85;
Apass = 0.1; % dB
Astop = 180; % dB

h = dsp.DigitalDownConverter('SampleRate',1, ...
  'PassbandRipple',Apass,'StopbandAttenuation',Astop,...
  'Oscillator','None');

s = struct;
ddcCoeffs = containers.Map(4,s);

M_vect = [4:2:100 110:10:1000 1050:50:3000];  

for idx = 1: numel(M_vect)
  
  s = struct;
  
  release(h);
  
  M = M_vect(idx);
   
  disp(['Designing filter for decim factor M = ' num2str(M)])
  
  h.Bandwidth = PBW/M;
  h.DecimationFactor = M;
    
  % setup System object so that filters are designed
  setup(h,randn(10*M,1));
  
  filtStruc = getFilters(h);
  
  s.decimFactors = getDecimationFactors(h);
  
  cicDecimFactor = s.decimFactors(1);
  L = length(filtStruc.CICDecimator.Numerator);   
  
  s.numCICSections = ceil((L-1)/(cicDecimFactor-1));
  
  s.secondStageCoeffs = filtStruc.SecondFilterStage.Numerator;
  if isempty(filtStruc.ThirdFilterStage)
    s.thirdStageCoeffs = [];  
  else
    s.thirdStageCoeffs = filtStruc.ThirdFilterStage.Numerator;
  end      
  
  ddcCoeffs(M) = s;
    
end  

save DDCCoefficients.mat ddcCoeffs
  
  

