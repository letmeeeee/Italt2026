function  checkSampleTime(obj)
%  checkSampleTime Check input sample time
%  obj: Object handle

%   Copyright 2018-2019 The MathWorks, Inc.
   
%#codegen
%#ok<*EMCLS>

if obj.getExecPlatformIndex()
    sts = getSampleTime(obj);
    % Never allow continuous time
    coder.internal.errorIf(sts.SampleTime==0,...
        'dsp:system:Shared:ContinuousTimeNotAllowed');
end
