classdef VariableBandwidthFilterBase < dsp.internal.NormalizedSampleRateEngine & ...
        dsp.internal.FilterAnalysis
    %VARIABLEBANDWIDTHFILTERBASE Abstract base class for variable bandwidth
    % objects. dsp.VariableBandwidthIIRFilter and
    % dsp.VariableBandwidthFIRFilter inherit from this base class.
    
    %   Copyright 2013-2021 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCLS>
    
    properties (Nontunable)
        %FilterType Filter type
        %   Specify the type of the filter as one of 'Lowpass' | 'Highpass'
        %   | 'Bandpass' | 'Bandstop'. The default is 'Lowpass'.
        FilterType (1, :) char {matlab.system.mustBeMemberMessageID(FilterType, ...
             {'dsp:system:VariableBandwidthFilter:FilterType_Lowpass'; ...
             'dsp:system:VariableBandwidthFilter:FilterType_Highpass'; ...
             'dsp:system:VariableBandwidthFilter:FilterType_Bandpass'; ...
             'dsp:system:VariableBandwidthFilter:FilterType_Bandstop'})} = 'Lowpass';  
    end
    
    properties
        %CenterFrequency  Filter center frequency 
        %   Specify the filter center frequency as a real, positive scalar
        %   less than SampleRate/2. This property applies when you set the
        %   FilterType property to 'Bandpass' or 'Bandstop'. Specify the
        %   value of center frequency in Hertz when you set
        %   NormalizedFrequency to false, and set the value in normalized
        %   units when you set NormalizedFrequency to true. The default is
        %   11025 Hz. This property is tunable.
        CenterFrequency     = 44100/4;
        % Bandwidth  Filter bandwidth 
        %   Specify the filter bandwidth as a real, positive scalar smaller
        %   than SampleRate/2. This property applies when you set the
        %   FilterType property to 'Bandpass' or 'Bandstop'. Specify the
        %   value of filter bandwidth in Hertz when you set
        %   NormalizedFrequency to false, and set the value in normalized
        %   units when you set NormalizedFrequency to true. The default is
        %   7680 Hz. This property is tunable.
        Bandwidth           = 7680;
    end    
  
    properties (Nontunable)
        % SampleRate Input sample rate (Hz)
        %   Specify the sampling rate of the input in Hertz as a finite
        %   numeric scalar. the default is 44100 Hz.
        SampleRate = 44100;
    end    
  
    properties (Access = protected)
        % filter handle. Children objects instantiate and set this object
        pfilter;
    end
    
    properties (Access = protected, Nontunable)
        % pDatatype Input datatype
        pDatatype;
    end
    
    properties (Access = protected)
        % pNumChannels Number of input channels
        pNumChannels;
    end
    
    properties (Access = protected)
        % pSampleRateDialog Default sample rate
        pSampleRateDialog = 44100;
    end
    
    %--------------------------------------------------------------------------
    % Abstract Protected methods
    %--------------------------------------------------------------------------
    methods (Abstract, Access = protected)
        % Abstract methods.
        
        %TUNECOEFFICIENTS Children objects redefine this method to specify
        % how coefficients are modified when filter characteristic is tuned
        tuneCoefficients(~);
        
        % VALIDATEFREQUENCYRANGE Children objects redefine this method to
        % validate cutoff frequencies versus sample rate.
        validateFrequencyRange(~);
    end
    %--------------------------------------------------------------------------
    % Abstract Static Hidden methods
    %--------------------------------------------------------------------------
    methods (Abstract,  Static, Hidden)
        % Abstract method. Children objects redefine this method so specify
        % equivalent DFILT object (for filter analysis methods)
        d = getdfiltobj(sysObjToAnalyze,arith);
    end
    %--------------------------------------------------------------------------
    % Public methods
    %--------------------------------------------------------------------------
    methods
        function obj = VariableBandwidthFilterBase(varargin)
            % Constructor
            setProperties(obj, nargin, varargin{:});
            % set initial pNumChannels to -1 (will be set to actual value in setup)
            obj.pNumChannels = int8(-1);
        end
        %------------------------------------------------------------------------
        function set.CenterFrequency(obj,value)
            % Validate CenterFrequency. Validation against the sample rate
            % and the bandwidth happens when the object is locked.
            obj.checkVal(value,'CenterFrequency');
            % Set the normalized center frequency
            obj.CenterFrequency = value;
        end
        %------------------------------------------------------------------------
        function set.Bandwidth(obj,value)
            % Validate Bandwidth. Validation against the sample rate and
            % center frequency happens when the object is locked.
            obj.checkVal(value,'Bandwidth');
            % Set the normalized Bandwidth
            obj.Bandwidth = value;
        end
        %------------------------------------------------------------------------
        function set.SampleRate(obj,val)
            validateattributes(val,...
                {'double','single'}, ...
                {'real','scalar','positive','finite'},...
                '','SampleRate');
            obj.SampleRate = val;
        end
        %----------------------------------------------------------------------
        function realizemdl(~,~)
            % realizemdl is not supported
            matlab.system.internal.error(...
                'dsp:system:VariableBandwidthFilter:UnsupportedMethod','realizemdl');
        end
    end
    %--------------------------------------------------------------------------
    % Protected methods
    %--------------------------------------------------------------------------
    methods (Access = protected)
        function Fc=outputDelayDefaultNormalizedFc(obj)
            % Return the (normalized) frequency for which group delay is evaluated in
            % outputDelay.

            switch obj.FilterType
                case {'Lowpass','Bandstop'}
                    Fc = 0;

                case 'Highpass'
                    Fc = 1;

                case 'Bandpass'
                    Fc = 2*obj.CenterFrequency/getSampleRate(obj);
            end
        end

        function resetImpl(obj)
            % Reset the filter object
            reset(obj.pfilter);
        end
        %------------------------------------------------------------------------
        function releaseImpl(obj)
            % Release the filter object
            release(obj.pfilter);
            obj.pNumChannels = int8(-1);
        end
        %------------------------------------------------------------------------
        function y = infoImpl(obj,varargin)
            y = infoFA(obj,varargin{:});
        end
        %------------------------------------------------------------------------
        function setupImpl(obj, x)
            
            setupImpl@dsp.internal.NormalizedSampleRateEngine(obj,x);
            
            % Setup the input datatype and number of channels.
            obj.pDatatype = class(x);
            obj.pNumChannels = int8(getNumChannels(obj,x));
        end
        %------------------------------------------------------------------------
        function flag = isInactivePropertyImpl(obj, prop)
            flag = false;
            switch prop
                case {'CenterFrequency','Bandwidth'}
                    if ~strcmp(obj.FilterType,'Bandpass') && ...
                            ~strcmp(obj.FilterType,'Bandstop')
                        flag = true;
                    end
                case {'SampleRate'}
                    if obj.getExecPlatformIndex()
                        if ~isSampleRateOnDialog(obj)
                            flag = true;
                        end
                    else
                        flag = obj.NormalizedFrequency;
                    end
            end
        end
        %------------------------------------------------------------------------
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@dsp.internal.NormalizedSampleRateEngine(obj);
            if isLocked(obj)
                s.pfilter      = matlab.System.saveObject(obj.pfilter);
                s.pDatatype    = obj.pDatatype;
                s.pNumChannels = obj.pNumChannels;
            end
            s = saveFA(obj, s);   % Save filter analysis class properties
        end
        %------------------------------------------------------------------------
        function loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                if (isfield(s.pfilter,'ClassNameForLoadTimeEval') &&...
                        strcmpi(s.pfilter.ClassNameForLoadTimeEval,'dsp.private.FourthOrderSectionFilter'))
                        % Previous to R2019a,
                        % dsp.private.FourthOrderSectionFilter was used and
                        % this was changed to dsp.FourthOrderSectionFilter in
                        % R2019a. To maintain backward compatibility, we need
                        % to redirect the obj.pfilter to this new class if the
                        % VBIIR object was created in a previous release.
                        s.pfilter.ClassNameForLoadTimeEval = 'dsp.FourthOrderSectionFilter';
                        hFilter = dsp.FourthOrderSectionFilter;
                        hStruct = s.pfilter.ChildClassData;
                        obj.pfilter = hFilter.loadobj(hStruct);
                else
                    if strcmpi(class(s.pfilter),'dsp.FourthOrderSectionFilter')
                        obj.pfilter =  dsp.FourthOrderSectionFilter.loadobj(s.pfilter);
                    else
                        % Struct with private second-order filter
                        obj.pfilter = matlab.System.loadObject(s.pfilter);
                    end
                end
                obj.pDatatype    = s.pDatatype;
                obj.pNumChannels = s.pNumChannels;
            end
            loadObjectImpl@dsp.internal.NormalizedSampleRateEngine(obj, s , wasLocked);
            loadFA(obj, s, wasLocked); % Load filter analysis class properties
        end
        %------------------------------------------------------------------------
        function flag = isInputComplexityMutableImpl(~,~)
            flag = false;
        end
        %------------------------------------------------------------------------
        function processTunedPropertiesImpl(obj)
            % Tune the filter coefficients
            processTunedPropertiesImpl@dsp.internal.NormalizedSampleRateEngine(obj);
            tuneCoefficients(obj);
        end
        %------------------------------------------------------------------------
        function crossValidateProperties(obj)
            Fs = getSampleRate(obj);
            % Cross-validation of filter specifications
            if strcmp(obj.FilterType,'Bandpass') || ...
                    strcmp(obj.FilterType,'Bandstop')
                freqUnits = getFrequencyUnits(obj);
                coder.internal.errorIf(obj.CenterFrequency >= Fs/2, 'dsp:system:VariableBandwidthFilter:CharacteristicTooLarge','CenterFrequency', floor(Fs), round((Fs - floor(Fs)) * 10),freqUnits);
                coder.internal.errorIf(obj.Bandwidth >= Fs/2, 'dsp:system:VariableBandwidthFilter:CharacteristicTooLarge','Bandwidth' , floor(Fs), round((Fs - floor(Fs)) * 10),freqUnits);
                coder.internal.errorIf(obj.CenterFrequency + obj.Bandwidth/2 >= Fs/2, 'dsp:system:VariableBandwidthFilter:CharacteristicTooLarge','CenterFrequency + Bandwidth/2' , floor(Fs), round((Fs - floor(Fs)) * 10),freqUnits);
                coder.internal.errorIf(obj.CenterFrequency - obj.Bandwidth/2 <= 0, 'dsp:system:VariableBandwidthFilter:CFMinusBandwidthNegative');
            else % highpass/lowpass validation
                validateFrequencyRange(obj);
            end
        end
        %------------------------------------------------------------------------
        function validateInputsImpl(obj, varargin)
            u = varargin{1};
            validateattributes(u,{'double','single'}, {'2d',...
                'nonsparse'},'','input');
            % The number of input channel is not allowed to change.
            coder.internal.errorIf(obj.pNumChannels~=-1 && obj.pNumChannels ~= size(u,2), 'dsp:system:varSizeChannelsNotSupported');
            if(~isLocked(obj))
                % (Method of dsp.internal.FilterAnalysis) Stores the data
                % type of input as ['double'|'single'|'fixed'] to use for
                % filter analysis
                cacheInputDataType(obj, u)
            end
        end
        %------------------------------------------------------------------------
        function d = convertToDFILT(obj, arith)
            % Returns equivalent dfilt to current object.
            if(~isLocked(obj))
                sysObjToAnalyze = clone(obj);
                setup(sysObjToAnalyze, 1)
            else
                sysObjToAnalyze = obj;
            end
            % Force tuning to reflect latest properties
            tuneCoefficients(sysObjToAnalyze);
            % Fixed-point analysis is not currently supported
            assert(strcmpi(arith,'single') || strcmpi(arith,'double'));
            % getdfiltobj is defined by children objects.
            d = obj.getdfiltobj(sysObjToAnalyze,arith);
            if ~obj.NormalizedFrequency %for fvtool
                d.SystemObjParams.SampleRate = getSampleRate(obj);
            end
        end
        function Fs = getSampleRate(obj)
            if ~isInactivePropertyImpl(obj, 'SampleRateMode')
                % Call from simulink object
                if isSampleRateNormalized(obj)
                    Fs = 2;
                elseif isSampleRateInherited(obj)
                    Fs = getInheritedSampleRate(obj);
                else
                    Fs = obj.SampleRate;
                end
            else
                if obj.NormalizedFrequency
                   Fs = 2;
               else
                   Fs = obj.SampleRate;
                end
            end
        end
    end
    %--------------------------------------------------------------------------
    % Hidden methods
    %--------------------------------------------------------------------------
    methods (Hidden)
        % Methods required for filter analysis functionality
        function restrictionsCell = getFixedPointRestrictions(~,~)
            restrictionsCell = {};
        end
        %------------------------------------------------------------------------
        function props = getFixedPointProperties(~)
            props = {};
        end
        %------------------------------------------------------------------------
        function props = getNonFixedPointProperties(obj)
            props = obj.getPropertyNames;
            idxtoprune = [];
            for k = 1:length(props)
                if(isInactiveProperty(obj, props{k}))
                    idxtoprune = [idxtoprune, k]; %#ok
                end
            end
            props(idxtoprune) = [];
        end
        %------------------------------------------------------------------------
        function flag = isPropertyActive(obj,prop)
            flag = ~isInactiveProperty(obj, prop);
        end
    end
    
    
    methods (Access = protected)
        
        % Propagators
        function sz_out = getOutputSizeImpl(obj)
            sz_out = propagatedInputSize(obj,1);
        end
        %------------------------------------------------------------------------
        function dt_out = getOutputDataTypeImpl(obj)
            dt_out = propagatedInputDataType(obj,1);
        end
        %------------------------------------------------------------------------
        function cp_out = isOutputComplexImpl(obj)
            cp_out = propagatedInputComplexity(obj, 1);
        end
        %------------------------------------------------------------------------
        function fsz_out = isOutputFixedSizeImpl(obj)
            fsz_out = propagatedInputFixedSize(obj, 1);
        end
        %------------------------------------------------------------------------
        function flag = supportsMultipleInstanceImpl(~)
            flag = false;
        end
        
        % Input/Output port labels
        function name = getOutputNamesImpl(~)
            name = '';
        end
        function name = getInputNamesImpl(~)
            name = '';
        end
        
        function dt = getTunablePropertiesSpecificationImpl(obj,~)
            dt = propagatedInputDataType(obj,1);
        end
        
    end
    
end
