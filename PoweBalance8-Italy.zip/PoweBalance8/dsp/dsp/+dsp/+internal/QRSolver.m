classdef QRSolver < matlab.System
% QRSolver Find minimum-norm-residual solution to AX=B

%   Copyright 2019-2023 The MathWorks, Inc.

    %#codegen
    %#ok<*EMCLS>
    methods
        %------------------------------------------------------------------
        % Constructor
        function obj = QRSolver(varargin)
            % Support name-value pair arguments when constructing object
            setProperties(obj,nargin,varargin{:})
        end
    end

    methods(Access = protected)
        %------------------------------------------------------------------
        function x = stepImpl(~,A,b)
            % Calculate x as a function of inputs A and b
            if coder.target('MATLAB')
                % lsqminnorm always uses qr square and non-square A and
                % produces a min norm solution. For non-square systems,
                % lsqminnorm then uses a second QR on the R factor
                % transpose of the first QR call, resulting in something of
                % the form Qleft * R* Qright’ – and this is then used to
                % compute the minimum-norm solution. mldivide with
                % non-square A will use QR.  That is documented.
                % Underdetermined cases result in a “basic solution", which
                % isn't generally minimum norm, rather has the number of
                % non-zeros in a solution vector capped at the number of
                % rows of A.  If you want minimum norm, use PINV, but PINV
                % will use SVD, not QR.
                x = lsqminnorm(A,b);
            else
                x = dsp.internal.QRSolver.lsqminnorm(A,b);
            end
        end
        %------------------------------------------------------------------
        function validateInputsImpl(~,A,b)
            coder.internal.errorIf(~isfloat(A) || ~ismatrix(A) || issparse(A),'MATLAB:decomposition:InvalidA');
            coder.internal.errorIf(~isfloat(b) || ~ismatrix(b) || issparse(A), 'MATLAB:decomposition:InvalidB');
        end
    end

    methods(Static)
        %------------------------------------------------------------------
        function x = lsqminnorm(A,b)
            if isempty(A)
                % mldivide and lsqminnorm match in this case
                x = A \ b;
                return
            end
            DT = class(A);
            [mA, nA] = size(A);
            % For wide matrices, start with a QR decomposition of A', the
            % below solve the linear system with A' instead of with A.
            transpose = nA > mA;
            if transpose
                AT = A';
                [~, nA] = size(AT);
            else
                AT = A;
            end
            %Q = zeros(mA,nA);
            [Q, R, perm] = qr(AT, 'econ', 'vector');
            szAT = size(AT);
            if isreal(AT)
                tol = min(max(szAT) * eps(DT), sqrt(eps(DT))) * abs(R(1, 1));
            else
                tol = min(10*max(szAT) * eps(DT), sqrt(eps(DT))) * abs(R(1, 1));
            end
            % Determine rank of A based on tolerance
            k = 0;
            while k < nA && ~(abs(R(k+1, k+1)) <= tol)
                k = k+1;
            end
            assert(k<=nA);
            if transpose
                b = b(perm, :);
                if k == nA
                    xi = R'\b;
                else
                    % Low-rank case, need a second QR decomposition of the
                    % R matrix.
                    [Q2, R2] = qr(R(1:k, :)', 'econ');
                    xi = R2\(Q2'*b);
                end
                x = Q(:, 1:k) * xi;
            else
                Qb = Q(:, 1:k)' * b;
                if k == nA
                    xi = R \ Qb;
                else
                    % Low-rank case, need a second QR decomposition of the
                    % R matrix.
                    [Q2, R2] = qr(R(1:k, :)', 'econ');
                    xi = Q2*(R2'\Qb);
                end
                x = cast(zeros(nA,size(xi,2)),'like',xi);
                x(perm,:) = xi;
            end
        end
    end
end
