classdef (StrictDefaults) ISTFTSysObj < matlab.System
    % This class is used for code generation of dsp.ISTFT    

    % Copyright 2018-2022 The MathWorks, Inc.

    %#codegen
    
    properties
        Window  = sqrt(hann(512,'periodic'))
    end
    
    properties
        OverlapLength = 256
    end
    
    properties (Nontunable)
        ConjugateSymmetricInput = true
    end
    
    properties (Nontunable)
        WeightedOverlapAdd = true
        FrequencyRange (1, :) char {matlab.system.mustBeMemberMessageID(FrequencyRange, ...
            {'dsp:system:STFT:FrequencyRange_onesided'; ...
            'dsp:system:STFT:FrequencyRange_twosided'})} = 'twosided';
    end
    
    properties( Access = private)
        pChunk
        pNorm
        pNormWin
        pWindow = hann(512)
        pFFT
        pYout;
    end
    
    properties(Nontunable, Access = private)
        pFFTLength
        pNumFreqSamples
        pIsFFTLengthModTwo
    end
    
    methods
        
        function obj = ISTFTSysObj(varargin)
            setProperties(obj, nargin, varargin{:}, 'Window' , 'OverlapLength',...
                     'ConjugateSymmetricInput','WeightedOverlapAdd');
        end
        
        function set.Window(obj,val)
            validateattributes(val,{'single','double'}, ...
                {'vector','real','nonnan'}, ...
                'set.Window','Window');
            obj.Window = val;
        end
        
        function set.ConjugateSymmetricInput(obj,val)
            
            validateattributes(val,{'numeric','logical'}, ...
                {'scalar','real','nonnan'}, ...
                'set.ConjugateSymmetricInput','ConjugateSymmetricInput');
            obj.ConjugateSymmetricInput = val;
        end
        
        function set.WeightedOverlapAdd(obj,val)
                        
            validateattributes(val,{'numeric','logical'}, ...
                {'scalar','real','nonnan'}, ...
                'set.WeightedOverlapAdd','WeightedOverlapAdd');
            obj.WeightedOverlapAdd = val;
        end

    end
    
    methods(Access = protected)
        
        function setupImpl(obj,u)
            
            obj.pWindow = repmat(reshape(obj.Window,numel(obj.Window),1),1,size(u,2));
            obj.pFFTLength       = calculateFFTLength(obj,u);
            obj.pNumFreqSamples  = calculateNumFrequencySamples(obj,u);
            obj.pIsFFTLengthModTwo = mod(obj.pFFTLength,2) == 0; 
            L = numel(obj.Window);
            if obj.WeightedOverlapAdd
                obj.pNorm      = cast(obj.pWindow.^2,class(u));
            else
                obj.pNorm      = cast(obj.pWindow,class(u));
            end
            obj.pNormWin   = obj.pNorm;
            
            if obj.ConjugateSymmetricInput
                obj.pChunk     = zeros(L - 1,size(u,2),class(u));
            else
                obj.pChunk     = complex(zeros(L - 1,size(u,2),class(u))) ;
            end

            obj.pFFT = dsp.IFFT('ConjugateSymmetricInput',obj.ConjugateSymmetricInput);
            
            coder.internal.errorIf(obj.pFFTLength < numel(obj.Window), ...
                 'dsp:system:STFT:FFTLengthTooShort')  
        end
        
        
        
        function NFFT = calculateFFTLength(obj, u)
            % Calculate FFT length based on the current input and frequency
            % range
            NFFT = size(u,1);
            if(strcmpi(obj.FrequencyRange,'onesided'))
                if(mod(NFFT,2) == 0)
                    % If number of stft transform points is even
                    NFFT = NFFT * 2 - 1;
                else
                    % If the number of stft transform points is odd
                    NFFT = (NFFT - 1) * 2;
                end
            end
        end
        
        function nSamples = calculateNumFrequencySamples(obj,u)
            nSamples = size(u,1);
            NFFT = obj.pFFTLength;
            if(strcmpi(obj.FrequencyRange,'onesided'))
                if(mod(NFFT,2) == 0)
                    % If the number of NFFT points is odd
                    nSamples = NFFT / 2 + 1;
                else
                    % If number of NFFT points is even
                    nSamples = (NFFT + 1) / 2;
                end
            end
        end
        
        function processTunedPropertiesImpl(obj)
            win                = cast(reshape(obj.Window,numel(obj.Window),1),class(obj.pWindow));
            obj.pWindow        = repmat(win,1,size(obj.pWindow,2));
            if obj.WeightedOverlapAdd
                obj.pNormWin = cast(obj.pWindow.^2,class(obj.pNormWin));
            else
                obj.pNormWin = cast(obj.pWindow,class(obj.pNormWin));
            end
        end
        
        function z = stepImpl(obj,u)
            
            if(isOneSided(obj))
               numSamples = obj.pNumFreqSamples;
               uout = zeros(obj.pFFTLength,size(u,2),'like',u);
               uout(1:numSamples,:) = u;
               % Convert the one-sided input transform to two-sided
               if(obj.pIsFFTLengthModTwo)
                  % Duplicate, conjugate and flip the samples with indices
                  % 2 to pNumFreqSamples - 1
                  uout(end:-1:numSamples+1,:) = conj(u(2:numSamples-1,:));
               else
                  % Duplicate, conjugate and flip the samples with indices
                  % 2 to pNumFreqSamples
                  uout(end:-1:numSamples+1,:) = conj(u(2:numSamples,:));
               end
               z = obj.pFFT(uout); 
            else
               z = obj.pFFT(u); 
            end
          
            y = z(1:numel(obj.Window),:);
            
            if obj.WeightedOverlapAdd
                y  = y .* obj.pWindow;
            end
            
            % Overlap-add
            L  = numel(obj.Window) - obj.OverlapLength;
            c  = obj.pChunk(1:obj.OverlapLength,:);

            y(1:end-L,:) = y(1:end-L,:) + c;
            z  = y(1:L,:);
            c = y(L+1:end,:);

            n       =  obj.pNorm;
            
            n0 = n;
            n0(n0==0) = 1; % do not divide by zero
            
            % Normalize
            z = z ./ n0(1:size(z,1),:); 
            
            old                =  n(size(z,1)+1:end,:); 
            n                  =  obj.pNormWin;
            n(1:length(old),:) = n(1:length(old),:) + old;
            obj.pNorm          = n;
            
            % Update state
            obj.pChunk(1:obj.OverlapLength,:) = c;
        end
        
        function resetImpl(obj)
            obj.pChunk = zeros(size(obj.pChunk,1),size(obj.pChunk,2),'like',obj.pChunk);
            obj.pNorm  = obj.pNormWin;
        end
        
        
        function flag = isOneSided(obj)
           flag = strcmpi(obj.FrequencyRange,'onesided'); 
        end
        
    end
    
    % ---------------------------------------------------------------------
    % STATIC, PROTECTED METHODS
    % ---------------------------------------------------------------------
    methods (Static, Access = protected)
        function groups = getPropertyGroupsImpl
            mainProps = { ...
                'Window',...
                'OverlapLength', ...
                'ConjugateSymmetricInput',...
                'WeightedOverlapAdd', ...
                'FrequencyRange'};

            mainGroup = matlab.system.display.SectionGroup( ...
                'Title','Properties', ...
                'PropertyList',mainProps);

            groups = mainGroup;
        end
    end
end
