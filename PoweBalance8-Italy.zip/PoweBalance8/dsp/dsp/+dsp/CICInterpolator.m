classdef (StrictDefaults)CICInterpolator < dsp.internal.CICDecIntBase
%CICInterpolator Interpolate signal using Cascaded Integrator-Comb filter 
%   CICINTERP = dsp.CICInterpolator returns a System object, CICINTERP,
%   that applies a Cascaded Integrator-Comb (CIC) Interpolation filter to
%   the input signal. Inputs and outputs to the object are fixed-point or
%   floating-point data types. A Fixed-Point Designer license is required
%   to use this System object.
%
%   CICINTERP = dsp.CICInterpolator('PropertyName', PropertyValue, ...)
%   returns a CIC interpolation object, CICINTERP, with each specified
%   property set to the specified value.
%
%   CICINTERP = dsp.CICInterpolator(R, M, N, 'PropertyName', PropertyValue,
%   ...) returns a CIC interpolation object, CICINTERP, with the
%   InterpolationFactor property set to R, the DifferentialDelay property
%   set to M, the NumSections property set to N, and other specified
%   properties set to the specified values.
%
%   Step method syntax:
%
%   Y = step(CICINTERP, X) interpolates input X to produce an output Y 
%   using the CIC interpolator object CICINTERP. Input X can be of data
%   type double, single, integer, or fixed point (fi objects).
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   CICInterpolator methods:
%
%   step              - See above description for use of this method
%   release           - Allow property and input characteristics changes
%   clone             - Create object with same property values
%   isLocked          - Locked status (logical)
%   reset             - Reset the internal states to initial conditions
%   generatehdl       - Generate HDL code: Filter Design HDL Coder required
%   getFixedPointInfo - Get fixed-point word lengths and fraction lengths
%                       for integrator sections, comb sections, and output
%
%   CICInterpolator properties:
%
%   InterpolationFactor    - Interpolation factor of filter
%   DifferentialDelay      - Differential delay of filter comb sections
%   NumSections            - Number of integrator and comb sections
%   FixedPointDataType     - Fixed-point property designations
%   SectionWordLengths     - Word lengths for each filter section
%   SectionFractionLengths - Fraction lengths for each filter section
%   OutputWordLength       - Word length for filter output
%   OutputFractionLength   - Fraction length for filter output
%
%   This System object supports several filter analysis methods. For more
%   information, type dsp.CICInterpolator.helpFilterAnalysis.
%
%   % EXAMPLE: Interpolate signal by a factor of 2 (upsample from 22.05 kHz 
%   % to 44.1 kHz) by specifying the 'Full precision' FixedPointDataType
%   % mode. 
%    CICInterp = dsp.CICInterpolator(2);
%    % Uses default NumSections = 2, DifferentialDelay = 1
%    % Create fixed-point sinusoidal input signal 
%    Fs = 22.05e3;                 % Original sampling frequency: 22.05 kHz
%    n = (0:511)';                 % 512 samples, 0.0113 second long signal
%    x = fi(sin(2*pi*1e3/Fs*n),true,16,15);     
%    SigIn = dsp.SignalSource(x, 32);
%    % Process the input signal
%    y = zeros(16,64);
%    for ii=1:16
%      % Interpolated output with 64 samples per frame
%      y(ii,:) = CICInterp( SigIn() );
%    end
%    % Plot the first frame of the original and interpolated signals.
%    % The output latency is 2 samples.
%    gainCIC = ...
%      (CICInterp.InterpolationFactor*CICInterp.DifferentialDelay)...
%      ^CICInterp.NumSections/CICInterp.InterpolationFactor;
%    stem(n(1:31)/Fs, double(x(1:31)),'r','filled'); 
%    hold on;     
%    stem(n(1:61)/(Fs*CICInterp.InterpolationFactor), ...
%          double(y(1,4:end))/gainCIC,'b'); 
%    xlabel('Time (sec)');
%    ylabel('Signal Amplitude');
%    legend('Original signal', 'Interpolated signal', 'location', 'north');
%    hold off;    
%
%   See also dsp.CICDecimator, dsp.FIRInterpolator.

%   Copyright 1995-2021 The MathWorks, Inc.

%#codegen
%#ok<*EMCLS>
%#ok<*EMCA>

  properties (Nontunable)
    %InterpolationFactor Interpolation factor of filter
    %   Specify a positive integer amount by which the input signal will be
    %   interpolated. The default value of this property is 2.
    InterpolationFactor = 2;
    
    %DifferentialDelay Differential delay of filter comb sections
    %   Specify a positive integer delay value to be used in each of the
    %   comb sections of the filter. The default value of this property is
    %   1.
    DifferentialDelay = 1;
    
    %NumSections Number of integrator and comb sections
    %   Specify the number of integrator and comb sections in the filter as
    %   a positive integer value. The default value of this property is 2.
    NumSections = 2;
    
    %FixedPointDataType Fixed-point property designations
    %   Specify the fixed-point data type as one of ['Full precision' |
    %   'Minimum section word lengths' | 'Specify word lengths' | 'Specify
    %   word and fraction lengths']. When this property is set to 'Full
    %   precision', the System object automatically determines the word and
    %   fraction lengths of the filter sections and output. When the
    %   property is set to 'Minimum section word length', the object
    %   automatically determines the word and fraction lengths of the
    %   filter sections and the fraction length of the output. When the
    %   property is set to 'Specify word lengths', the object automatically
    %   determines the fraction lengths of the filter sections and the
    %   output. The default is 'Full precision'.
    FixedPointDataType = 'Full precision';
    
    % SectionWordLengths Word lengths for each filter section
    %   Specify the fixed-point word length to use for each filter section.
    %   There are (2*NumSections) filter sections to be specified. This
    %   property is applicable when the FixedPointDataType property is set
    %   to one of ['Specify word lengths' | 'Specify word and fraction
    %   lengths']. The default value of this property is [16 16 16 16].
    SectionWordLengths = [16 16 16 16];
    
    % SectionFractionLengths Fraction lengths for each filter section
    %   Specify the fixed-point fraction length to use for each filter
    %   section. There are (2*NumSections) filter sections to be specified.
    %   This property is applicable when the FixedPointDataType property is
    %   set to 'Specify word and fraction lengths'. The default value of
    %   this property is 0.
    SectionFractionLengths = 0;
    
    % OutputWordLength Word length for filter output
    %   Specify the fixed-point word length to use for the filter output.
    %   This property is applicable when the FixedPointDataType property is
    %   set to one of ['Minimum section word lengths' | 'Specify word
    %   lengths' | 'Specify word and fraction lengths']. The default value
    %   of this property is 32.
    OutputWordLength = 32;
    
    % OutputFractionLength Fraction length for filter output
    %   Specify the fixed-point fraction length to use for the filter
    %   output. This property is applicable when the FixedPointDataType
    %   property is set to 'Specify word and fraction lengths'. The default
    %   value of this property is 0.
    OutputFractionLength = 0;
  end
  
  properties (Constant, Hidden)
    FixedPointDataTypeSet = matlab.system.StringSet({'Full precision', ...
        'Minimum section word lengths', 'Specify word lengths',...
        'Specify word and fraction lengths'});
  end
    
  methods
    function obj = CICInterpolator(varargin)
      setProperties(obj, nargin, varargin{:}, ...
          'InterpolationFactor', 'DifferentialDelay', 'NumSections');
    end
    
    function set.InterpolationFactor(obj, value)
      validateattributes( value, {'numeric'}, ...
          {'real', 'positive', 'integer', 'scalar' }, '', 'InterpolationFactor');
      clearMetaData(obj)
      obj.InterpolationFactor = value;
    end
    
    function set.DifferentialDelay(obj, value)
        validateattributes(value, {'numeric'}, ...
            {'real', 'positive', 'integer', 'scalar'}, '', 'DifferentialDelay');
        clearMetaData(obj)
        obj.DifferentialDelay = value;
    end
    
    function set.NumSections(obj, value)
        validateattributes(value, {'numeric'}, ...
            {'real', 'positive', 'integer', 'scalar', '<=', 15 }, ...
            '', 'NumSections');
        clearMetaData(obj)
        obj.NumSections = value;
    end
    
    function set.OutputWordLength(obj, value)
        validateattributes(value, {'numeric'}, ...
            {'real', 'positive', 'integer', 'scalar', '<=', 128, '>=', 2 }, ...
            '', 'OutputWordLength');
        obj.OutputWordLength = value;
    end
    
    function set.OutputFractionLength(obj, value)
        validateattributes(value, {'numeric'}, ...
            {'real', 'integer', 'scalar'}, '', 'OutputFractionLength');
        obj.OutputFractionLength = value;
    end
    
    function set.SectionWordLengths(obj, value)
        if strncmp(obj.FixedPointDataType, 'Specify', 7) %#ok
            validateattributes(value, {'numeric'}, ...
                {'real', 'integer', '<=', 128, '>=', 2}, '', 'SectionWordLengths');
        end
        obj.SectionWordLengths = value;
    end
    
    function set.SectionFractionLengths(obj, value)
        if strncmp(obj.FixedPointDataType, 'Specify word and fraction lengths', 30) %#ok
            validateattributes(value, {'numeric'}, ...
                {'real', 'integer'}, '', 'SectionFractionLengths');
        end
        obj.SectionFractionLengths = value;
    end
    
    function g = gain(obj,varargin)
      %GAIN   Gain of the CIC interpolation filter System object
      %   G = gain(Hm,J) is the gain of the Jth stage of a CIC
      %   interpolation filter. If empty or omitted, J is assumed to be
      %   2*N. In this scenario, G corresponds to the gain to the entire
      %   set of filter stages.      
      [d, varargin] = parseArithmetic(obj, varargin);
      g = gain(d,varargin{:});      
    end
  end
  
  %----------------------------------------------------------------------
  % Hidden methods
  %----------------------------------------------------------------------
  
  methods (Hidden)
    function props = getNonFixedPointProperties(~)
        props = {...
          'InterpolationFactor',...
          'DifferentialDelay',...
          'NumSections'};
    end
    
    function a = computeCICWLsFLs(obj, inWL, inFL, modestr, n, sectionWL)
        coder.extrinsic('getcicinterpwlnfl');
        if isempty(coder.target)
            a = getcicinterpwlnfl(inWL, inFL, modestr, n, ...
                obj.InterpolationFactor, obj.DifferentialDelay, ...
                obj.OutputWordLength, sectionWL);
        else
            a = coder.internal.const(double(getcicinterpwlnfl( ...
                inWL, inFL, modestr, n, obj.InterpolationFactor, ...
                obj.DifferentialDelay, obj.OutputWordLength, sectionWL)));
        end
    end

    function [L,M] = rateConversionFactors(obj) 
        nargoutchk(2, 2);
        L = obj.InterpolationFactor;
        M = 1;
    end
  end

  methods (Static, Hidden)   
    function coeffs = getCICFIRCoefficients(N,Fac)
        % Design a FIR filter with a CIC response using a cascade of
        % boxcar filters.
        % N is the number of sections.
        % Fac is the factor (decimation or interpolation)
        x = ones( 1, Fac );
        c = x;
        for idx = 1:(N - 1)
            c = conv( c, x );
        end
        coeffs = c;
    end
  end
  
  methods (Access=protected)
    function setupImpl(obj, in)
      coder.extrinsic('int2str');
      coder.extrinsic('dsp.CICInterpolator.getCICFIRCoefficients')
      
      n = obj.NumSections;
      
      if isfloat(in)
          % double, single, fi double and fi single         
          if isa(in, 'embedded.fi')
              if isdouble(in)
                    obj.pArithmetic = 'double';
                elseif issingle(in)
                    obj.pArithmetic = 'single';
              end
          elseif isa(in, 'double')
              obj.pArithmetic = 'double';
          else
              obj.pArithmetic = 'single';
          end
          
          obj.pInputNT = numerictype(obj.pArithmetic);
          
          % Design FIR Boxcar Filter with direct form structure
          firCoeffs = coder.const(@obj.getCICFIRCoefficients, n,...
                obj.InterpolationFactor * obj.DifferentialDelay);
          obj.pFIRFilter = dsp.FIRFilter('Numerator', firCoeffs);
          % Allocate internal states
          obj.pDelayStates = struct('States', ...
              zeros(n, size(in,2), 'like', in));
      else
          
          obj.pArithmetic = 'fixed';
          
          if isfi(in)
              obj.pInputNT = numerictype(in);        % fi types
          else
              obj.pInputNT = numerictype(class(in)); % int8, etc.
          end
          
          [sectionWL, sectionFL, outWL, outFL] = ...
              getWLsFLsFromInputNT(obj, obj.pInputNT);
          
          for i = coder.unroll(1:n)
              cmbStageName = ...
                  coder.internal.const(['cCmbStage' int2str(i)]);
              obj.(cmbStageName) = dsp.internal.FIRCombFilter( ...
                  'DelayLength', obj.DifferentialDelay, ...
                  'CustomAccumulatorDataType', ...
                  numerictype(true, sectionWL(i), sectionFL(i)));
          end
          
          for i = coder.unroll(1:n)
              intgStageName = ...
                  coder.internal.const(['cIntgStage' int2str(i)]);
              obj.(intgStageName) = dsp.internal.Integrator( ...
                  'CustomAccumulatorDataType', ...
                  numerictype(true, sectionWL(n+i), sectionFL(n+i)));
          end
          
          obj.cOutWL = outWL;
          obj.cOutFL = outFL;
          
      end % if isfloat(in) ... else ... end
      
    end
    
    function out = stepImpl(obj,in)
        coder.extrinsic('int2str', 'warning');
        
        warning('off', 'SimulinkFixedPoint:util:Overflowoccurred');
        
        n = obj.NumSections;
        coder.internal.const(n);
        
        %   When the input data type is double or single the object
        %   implements an N-section CIC interpolator as an FIR filter
        %   with a response that corresponds to a cascade of N boxcar
        %   filters. A true CIC filter with actual comb and integrator
        %   sections is implemented when the input data is of a fixed point
        %   type.
        if  ~isfloat(in) && strcmpi(obj.pArithmetic,'fixed')
            % Comb stages
            for i = coder.unroll(1:n)
                if i == 1
                    if isfi(in)
                        if issigned(in)
                            yCmb = in;
                        else
                            % cast unsigned fixed-point input to signed
                            yCmb = fi(in, true, ...
                                in.WordLength+1, in.FractionLength);
                        end
                    else
                        yCmb1 = fi(in);
                        if issigned(yCmb1)
                            yCmb = yCmb1;
                        else
                            yCmb = fi(in, true, ...
                                yCmb1.WordLength+1, yCmb1.FractionLength);
                        end
                    end
                end
                name = coder.internal.const(['cCmbStage' int2str(i)]);
                yCmb = step(obj.(name),yCmb);
            end
            
            % Upsample
            y = upsample(yCmb, obj.InterpolationFactor);
            
            % Integrator stages
            for i = coder.unroll(1:n)
                if i == 1
                    yIntg = y;
                end
                name = coder.internal.const(['cIntgStage' int2str(i)]);
                yIntg = step(obj.(name),yIntg);
            end
            out = quantizefi(yIntg,1,obj.cOutWL,obj.cOutFL,'floor','wrap');
        else
            % local copies of states
            Z1 = obj.pDelayStates.States;
            % Up Sampling of input
            inUpsamp = upsample(in, obj.InterpolationFactor, 0);
            % filter input with FIR (Boxcar) filter
            yconv = step(obj.pFIRFilter, inUpsamp);
            % CIC output delay Length is obj.NumSections (n)
            n1 = size(in, 1);
            if n <= n1
                out = [Z1; yconv(1:end-n, :)];
                Z1 = yconv(end-n+1:end, :);
            else
                % size(yconv) == size(in),
                % so yconv(1:end-n1,:) must be empty
                out = Z1(1:n1);
                Z1 = [Z1(n1+1:end); yconv(:, :)];
            end
            obj.pDelayStates.States = Z1; % save states
        end
        
        warning('on', 'SimulinkFixedPoint:util:Overflowoccurred');
        
    end
    
    function d = convertToDFILT(obj,arith)      
      d = dsp.internal.mfilt.cicinterp; 
      d.InterpolationFactor = obj.InterpolationFactor;
      d.DifferentialDelay   = obj.DifferentialDelay;
      d.NumberOfSections    = obj.NumSections;
      d.PersistentMemory    = true;
      convertToDFILTCIC(obj,d, arith)
    end
  end
  
end
