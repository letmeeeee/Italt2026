classdef AsyncBuffer < handle & matlab.mixin.SetGet
    %AsyncBuffer FIFO buffer
    %   Q = dsp.AsyncBuffer returns an object, Q, that implements first in
    %   first out (FIFO) buffering.
    %
    %   Q = dsp.AsyncBuffer(Cap) returns an AsyncBuffer object, Q, with
    %   capacity set to Cap.
    %
    %   Q = dsp.AsyncBuffer('Name',Value, ...) returns an AsyncBuffer
    %   object, Q, with each specified property name set to the specified
    %   value. You can specify additional name-value pair arguments in any
    %   order as (Name1,Value1,...,NameN,ValueN).
    %
    %
    %   AsyncBuffer methods:
    %
    %   write    - Write to buffer
    %   read     - Read from buffer
    %   peek     - Peek at buffer
    %   reset    - Reset the internal states to initial conditions
    %   release  - Allow property values and input characteristics 
    %              to change
    %   clone    - Create AsyncBuffer object with same property values
    %   isLocked - Locked status (logical)
    %   info     - Get cumulative overrun and underrun
    %
    %   AsyncBuffer properties:
    %
    %   Capacity           - Number of writable/readable samples in buffer
    %   NumUnreadSamples   - Number of unread samples in buffer (read only)
    %
    %
    %   % EXAMPLE 1: Read variable frame sizes from buffer
    %     % Create AsyncBuffer object
    %     Q = dsp.AsyncBuffer;
    %
    %     % Create input signal for buffer
    %     signal = randn(512,1);
    %
    %     % Write input signal to buffer
    %     write(Q,signal);
    %
    %     outTotal = [];
    %     plot(signal);hold on
    %
    %     % Read from buffer until all samples are read
    %     while Q.NumUnreadSamples ~= 0
    %         % Determine random number of samples to read
    %         numToRead = randi([1,64]);
    %
    %         % Read from buffer
    %         out = read(Q,numToRead);
    %
    %         % Visualize data read from buffer
    %         outTotal = [outTotal;out];
    %         plot(outTotal,'r','LineWidth',2);
    %         pause(0.2) % The pause is for illustrative purposes only
    %     end
    %
    %   % EXAMPLE 2: Write variable frame sizes to buffer
    %   % Create AsyncBuffer object
    %   Q = dsp.AsyncBuffer;
    %
    %   % Create ArrayPlot object
    %   plotter = dsp.ArrayPlot();
    %
    %   start = 1;
    %   tic
    %   while toc < 5
    %       % Determine random number of samples to write
    %       numToWrite = randi([200,800]);
    %       finish = start + numToWrite;
    %
    %       % Create input data
    %       inputData = sin(start:finish)';
    %       start = finish + 1;
    %
    %       % Write data to buffer
    %       write(Q,inputData);
    %
    %       % If enough data is cached, read from buffer and perform FFT
    %       while Q.NumUnreadSamples >= 256
    %           x = read(Q,256);
    %           X = abs(fft(x));
    %           plotter(log(X));
    %       end
    %   end
    %
    % See also dsp.Delay.
    
    % Copyright 2016-2021 The MathWorks, Inc.
    
    %#codegen
    
    properties 
        %Capacity Number of writable/readable samples per channel in buffer
        % The default is 192000.
        Capacity = int32(192000);
    end
    properties (Dependent, SetAccess = private)
        %NumUnreadSamples Number of unread samples per channel in buffer
        % The total number of unread samples in the buffer is
        % NumUnreadSamples*(number of channels). This is a read-only
        % property.
        NumUnreadSamples
    end
    properties (Access = protected)
        Cache
        NumChannels        = int32(-1);
        ReadPointer        = int32(1);
        WritePointer       = int32(2);
        CumulativeOverrun  = int32(0);
        CumulativeUnderrun = int32(0);
        LastReadUnderrun   = int32(0);
        isInitialized      = false;
    end
    properties (Access = protected)
        % Cache number of channels
        pCompiledNumChannels
        % Save internal capacity as int32.
        pCapacity = int32(192000);
    end

    %----------------------------------------------------------------------
    % Public methods for reading and writing and getting unread samples
    %----------------------------------------------------------------------
    methods
        
        function obj = AsyncBuffer(varargin)
            
            parser = inputParser;
            defaultValue = int32(192000);
            addParameter(parser, 'Capacity',defaultValue,@validateCapacity);
            addOptional(parser,  'CapacityValueOnly', defaultValue,@validateCapacity);
            parse(parser,varargin{:});
            
            if parser.Results.Capacity ~= defaultValue
                obj.Capacity = parser.Results.Capacity;
            end
            
            if parser.Results.CapacityValueOnly ~= defaultValue
                obj.Capacity = parser.Results.CapacityValueOnly;
            end
        end

        %-------------------------------------------------------------------
        % Release
        %-------------------------------------------------------------------
        function release(obj)
            %  Allow property value and input characteristics to change
            
            % The public dependent property NumUnreadSamples depends on the
            % read and write pointers, so they are reset during release
            % since they are no longer visible.
            obj.ReadPointer        = int32(1);
            obj.WritePointer       = int32(2);
            obj.CumulativeOverrun  = int32(0);
            obj.CumulativeUnderrun = int32(0);
            obj.LastReadUnderrun   = int32(0);
            obj.isInitialized      = false;
            obj.NumChannels        = int32(-1);
            if isempty(coder.target)
                obj.Cache = [];
            end
        end
        
        %-------------------------------------------------------------------
        % Reset
        %-------------------------------------------------------------------
        function reset(obj)
            % Reset the buffer internal states
            
            obj.ReadPointer        = int32(1);
            obj.WritePointer       = int32(2);
            obj.CumulativeOverrun  = int32(0);
            obj.CumulativeUnderrun = int32(0);
            obj.LastReadUnderrun   = int32(0);
            obj.Cache = zeros(obj.pCapacity+int32(1),obj.pCompiledNumChannels, ...
                'like',obj.Cache);
        end
        
        %-------------------------------------------------------------------
        function s = info(obj)
            %INFO Get cumulative overrun and underrun
            %   CumulativeOverrun - Number of samples overrun per channel since
            %       last call to reset. The number of samples overrun is the
            %       number of unread samples overwritten.
            %
            %   CumulativeUnderrun - Number of samples underrun per channel
            %       since last call to reset. Underrun occurs if you attempt to
            %       read more samples than available.
            %
            s = struct( ...
                'CumulativeOverrun',obj.CumulativeOverrun, ...
                'CumulativeUnderrun',obj.CumulativeUnderrun);
        end

        %-------------------------------------------------------------------
        function set.Capacity(obj,val)
            
            coder.internal.errorIf(obj.isInitialized,'MATLAB:system:propertySetWhenLocked');%#ok
            
            validateCapacity(val);
            
            obj.Capacity  = val;
        end
        
        %-------------------------------------------------------------------
        function overrun = write(obj,in)
            %WRITE Write to buffer
            % nOverrun = write(Q,x) writes the samples, x, to the
            %   buffering object, Q. It also returns the number of samples
            %   overrun in the current call to write. The number of samples
            %   overrun is the number of unread samples overwritten.

            if ~obj.isInitialized
                setup(obj,in);
            end
            
            % Write properties to local variables -------------------------
            oneCast  = int32(1);
            zeroCast = int32(0);
            wPtr     = obj.WritePointer;
            rPtr     = obj.ReadPointer;
            cap      = obj.pCapacity + oneCast;
            overrun  = zeroCast;
            row      = int32(size(in,1));
            %--------------------------------------------------------------

            c = wPtr + row - oneCast;
            
            if c > cap                             %   |---w------| c
                c = c - cap;
                bc = [wPtr:cap,oneCast:c];
                if wPtr <= rPtr                    %   |---c---w-r-|
                    overrun = cap - rPtr + oneCast + c;
                elseif rPtr <= c                   %   |-r-c---w---|
                    overrun = c - rPtr + oneCast;
                end
            else                                   %   |---w---c---|
                bc = wPtr:c;
                if (wPtr<=rPtr) && (rPtr<=c)       %   |---w-r-c---|
                    overrun = c - rPtr + oneCast;
                end
            end
            obj.Cache(bc,:) = in;
            
            if (c+oneCast)>cap
                wPtr = oneCast;
            else
                wPtr = c + oneCast;
            end
            if overrun ~= zeroCast
                rPtr = wPtr;
            end
            
            % Update properties -------------------------------------------
            obj.CumulativeOverrun = obj.CumulativeOverrun + overrun;
            obj.WritePointer      = wPtr;
            obj.ReadPointer       = rPtr;
            % -------------------------------------------------------------
        end
        
        %-------------------------------------------------------------------
        function overrun = step(obj,in)
           overrun = write(obj,in);   
        end
        
        %-------------------------------------------------------------------
        
        function [out,underrun] = peek(obj,numRows,overlap)
            %PEEK Read from buffer without changing the number of unread 
            %     samples
            % out = peek(Q) returns all unread samples in buffer.
            %
            % out = peek(Q,NumRows) returns NumRows samples from each
            %   channel (column) of buffer. If the requested number of
            %   samples is greater than the number of unread samples, the
            %   output is zero-padded.
            %
            % out = peek(Q,NumRows,Overlap) returns NumRows samples from
            %   each channel and overlaps previously read samples by
            %   Overlap. The total number of samples read is NumRows *
            %   (number of channels). The total number of new samples read
            %   is (NumRows - Overlap) * (number of channels). If the
            %   overlap portion read contains samples that are
            %   overwritten, and are therefore not contiguously written,
            %   the output is zero-padded.
            %
            % [out,nUnderrun] = peek(Q,...) additionally returns the
            %   number of rows zero-padded if underrun occurred. Underrun
            %   occurs if you attempt to read more samples than available.
            %   Samples zero-padded in overlapped portions are not counted
            %   as underrun.
            %
            % % Example: Peek at contents of buffer
            % % Create AsyncBuffer object
            %   Q = dsp.AsyncBuffer;
            % 
            % % Create input signal
            % signal = (1:100).';
            % 
            % %% Write Signal to buffer
            % write(Q,signal);
            % 
            % %% Peek at first 3 samples
            % out1  = peek(Q,3); % out1 = [1; 2; 3];
            % 
            % %% Read first 50 samples
            % out2  = read(Q,50); % out2 = (1:50).';
            % 
            % %% Now peek again at first 3 samples
            % out1  = peek(Q,3); % out1 = [51; 52; 53];
            % 
            % %% Read remaining samples
            % out2  = read(Q); % out2 = (51:100).';

            % Write properties to local variables--------------------------
            zeroCast        = int32(0);
            %--------------------------------------------------------------
            % Error check input and cast as necessary ---------------------
            if nargin < 2
                numRows = obj.NumUnreadSamples;
            end
            if nargin < 3
                overlapCast = zeroCast;
                numRowsCast = int32(numRows);
                
            end
            if nargin == 3
                overlapCast = max(zeroCast,int32(overlap)-obj.LastReadUnderrun);
                numRowsCast = int32(numRows);
            end
            [out,underrun,~,~] = obj.ReadSamplesFromBuffer(obj,numRowsCast,overlapCast);
        end
        
        %-------------------------------------------------------------------
        
        function [out,underrun] = read(obj,numRows,overlap)
            %READ Read from buffer
            % out = read(Q) returns all unread samples in buffer.
            %
            % out = read(Q,NumRows) returns NumRows samples from each
            %   channel (column) of buffer. If the requested number of
            %   samples is greater than the number of unread samples, the
            %   output is zero-padded.
            %
            % out = read(Q,NumRows,Overlap) returns NumRows samples from
            %   each channel and overlaps previously read samples by
            %   Overlap. The total number of samples read is NumRows *
            %   (number of channels). The total number of new samples read
            %   is (NumRows - Overlap) * (number of channels). If the
            %   overlap portion read contains samples that are
            %   overwritten, and are therefore not contiguously written,
            %   the output is zero-padded.
            %
            % [out,nUnderrun] = read(Q,...) additionally returns the
            %   number of rows zero-padded if underrun occurred. Underrun
            %   occurs if you attempt to read more samples than available.
            %   Samples zero-padded in overlapped portions are not counted
            %   as underrun.
                        
            % Write properties to local variables--------------------------
            
            wPtr            = obj.WritePointer;
            oneCast         = int32(1);
            zeroCast        = int32(0);
            %--------------------------------------------------------------
            % Error check input and cast as necessary ---------------------
            if nargin < 2
                numRows = obj.NumUnreadSamples;
            end
            if nargin < 3
                overlapCast = zeroCast;
                numRowsCast = int32(numRows);
                
            end
            if nargin == 3
                overlapCast = max(zeroCast,int32(overlap)-obj.LastReadUnderrun);
                numRowsCast = int32(numRows);
            end
            % Error if we attempt to read N samples before we write to
            % buffer
            coder.internal.errorIf(~obj.isInitialized && isempty(obj.Cache) && numRows > 0,'dsp:system:AsyncBuffer:isInitialized');
            % -------------------------------------------------------------
            [out, underrun,overlapUnderrun,c] = obj.ReadSamplesFromBuffer(obj,numRowsCast,overlapCast);
            obj.LastReadUnderrun = underrun;
            % If underrun occurred, adjust pointers ---
            if underrun ~= zeroCast
                rPtr = wPtr - oneCast;
            elseif overlapUnderrun ~= zeroCast
                rPtr = c;
            else
                rPtr = c;
            end
            % Update properties--------------------------------------------
            obj.CumulativeUnderrun = obj.CumulativeUnderrun + underrun;
            obj.ReadPointer        = rPtr;
            %--------------------------------------------------------------
        end
        
        %-------------------------------------------------------------------
        % Setup
        %-------------------------------------------------------------------
        function setup(obj,in)
            
           validateattributes(in,{'numeric','logical'},{'2d'},'validateInputs','input');
            
           coder.internal.errorIf(size(in,1)>int32(obj.Capacity),['dsp:system',...
                ':AsyncBuffer:numRows']);
            
            numChan                  = int32(size(in,2));
            
            % Disallow a first step with zero channels
            coder.internal.errorIf(numChan == int32(0),'dsp:system:Shared:EmptyFirstStep');
            
            obj.NumChannels          = numChan;
            
            obj.pCompiledNumChannels = numChan;
            obj.pCapacity            = int32(obj.Capacity);
            
            obj.isInitialized        = true;
            obj.Cache                = zeros(obj.pCapacity+int32(1),numChan,'like',in);
        end
        
        %-------------------------------------------------------------------
        
        function unreadSamples = get.NumUnreadSamples(obj)
            if obj.ReadPointer < obj.WritePointer
                unreadSamples = obj.WritePointer - obj.ReadPointer - int32(1);
            elseif obj.ReadPointer == obj.WritePointer
                unreadSamples = obj.pCapacity;
            else
                unreadSamples = obj.pCapacity - obj.ReadPointer + obj.WritePointer;
            end
        end
        
        %-------------------------------------------------------------------
        
        function s = clone(obj)
            s          = dsp.AsyncBuffer;
            s.Capacity = obj.Capacity;
            
            % Copy the states:
            s.CumulativeOverrun    = obj.CumulativeOverrun;
            s.CumulativeUnderrun   = obj.CumulativeUnderrun;
            s.Cache                = obj.Cache;
            s.ReadPointer          = obj.ReadPointer;
            s.WritePointer         = obj.WritePointer;
            s.isInitialized        = obj.isInitialized;
            s.NumChannels          = obj.NumChannels;
            s.pCompiledNumChannels = obj.pCompiledNumChannels;
            s.pCapacity            = obj.pCapacity;
        end
    end
    
    %----------------------------------------------------------------------
    % Hidden Static methods
    %----------------------------------------------------------------------
    methods (Hidden, Static)

        function [out,underrun,overlapUnderrun,c] = ReadSamplesFromBuffer(obj,numRowsCast,overlapCast)
            oneCast         = int32(1);
            zeroCast        = int32(0);
            rPtr            = obj.ReadPointer;
            wPtr            = obj.WritePointer;
            underrun        = zeroCast;
            overlapUnderrun = zeroCast;
            capCheck        = obj.pCapacity;
            cap             = capCheck + oneCast;
            

            % -------------------------------------------------------------
            
            % Push read pointer forward one and wrap if necessary ---------
            rPtr = rPtr + oneCast;
            if rPtr > cap
                rPtr = oneCast;
            end
            
            % -------------------------------------------------------------
            
            % Calculate read index and then read from cache ---------------
            if overlapCast == zeroCast
                c = rPtr + numRowsCast - oneCast;
                
                if (c>cap)                                %  |-------r---| c
                    c = c - cap;
                    readIdx = [rPtr:cap,oneCast:c];       %  |---c---r---|
                    
                    if (rPtr <= wPtr)                     %  |---c---r-w-|
                        underrun = cap - wPtr + oneCast + c;
                    elseif (wPtr<=c)                      %  |-w-c---r---|
                        underrun = c - wPtr + oneCast;
                    end
                    
                else                                      %  |---r---c---|
                    readIdx = rPtr:c;
                    
                    if (rPtr<=wPtr)&&(wPtr<=c)            %  |---r-w-c---|
                        underrun = c - wPtr + oneCast;
                    end
                end
            else % case: overlap ~= 0
                a = rPtr - overlapCast;
                c = rPtr - overlapCast + numRowsCast - oneCast;
                if (a<1)                               % a|---r---c-------|
                    a = a + cap;
                    readIdx = [a:cap,oneCast:c];       %  |---r---c---a---|
                    
                    if (rPtr<=wPtr)&&(wPtr<=c)         %  |---r-w-c---a---|
                        underrun = c - wPtr + oneCast;
                    elseif (wPtr<rPtr)                 %  |-w-r---c---a---|
                        overlapUnderrun = (cap - a + oneCast) + wPtr;
                    elseif (wPtr>a)                    %  |---r---c---a-w-|
                        overlapUnderrun = wPtr - a + oneCast;
                    end
                    
                elseif (c>cap)                         %  |------a---r---| c
                    c = c - cap;
                    readIdx = [a:cap,oneCast:c];       %  |---c---a---r---|
                    
                    if (rPtr<=wPtr)                    %  |---c---a---r-w-|
                        underrun = cap - wPtr + oneCast + c;
                    elseif (wPtr<=c)                   %  |-w-c---a---r---|
                        underrun = c - wPtr + oneCast;
                    elseif (a<wPtr)&&(wPtr<rPtr)       %  |---c---a-w-r---|
                        overlapUnderrun = wPtr - a + oneCast;
                    end
                    
                else                                   %  |---a---r---c---|
                    readIdx = a:c;
                    
                    if (rPtr<=wPtr)&&(wPtr<=c)         %  |---a---r-w-c---|
                        underrun = c - wPtr + oneCast;
                    elseif (a<=wPtr)&&(wPtr<rPtr)      %  |---a-w-r---c---|
                        overlapUnderrun = wPtr - a + oneCast;
                    end
                end
            end
            out = obj.Cache(readIdx,:);
            %--------------------------------------------------------------
            
            % If underrun occurred, zero-pad output -----------------------
            if underrun ~= zeroCast
                out(numRowsCast-underrun+oneCast:numRowsCast,oneCast:obj.pCompiledNumChannels) = ...
                    zeros(underrun,obj.pCompiledNumChannels,'like',out);
            elseif overlapUnderrun ~= zeroCast
                if overlapUnderrun == numRowsCast
                    out = zeros(overlapUnderrun,obj.pCompiledNumChannels,'like',out);
                else
                    out(oneCast:overlapUnderrun,:) = zeros(overlapUnderrun,obj.pCompiledNumChannels,'like',out);
                end
            end
        end
    end
    
    methods (Hidden)
        function o = getNumInputs(~)
           o = 1; 
        end
        
        function o = getNumOutputs(~)
           o = 1; 
        end
        
        function o = nargin(~)
            o = 1;
        end
        
        function p = getValueOnlyProps(~)
           p = {'Capacity'}; 
        end
        
        function l = isLocked(obj)
        %Locked Status for input attributes and non-tunable properties
            l = obj.isInitialized;
        end

    end
    
    methods (Access = public, Hidden, Static)
        function name = matlabCodegenRedirect(~)
            name = 'dsp.internal.AsyncBuffercg';
        end
    end
end

function validateCapacity(val)
validateattributes(val,{'numeric'}, ...
                {'finite','real','scalar','integer','positive','>=',2},...
                'set.Capacity','Capacity');
end
