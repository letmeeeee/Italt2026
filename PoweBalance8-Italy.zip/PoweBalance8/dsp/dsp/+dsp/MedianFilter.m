classdef (StrictDefaults)MedianFilter < matlab.System
%   MedianFilter Perform median filtering 
%   MEDFILT = dsp.MedianFilter returns a System object, MEDFILT, that
%   computes the median of the input signal.
%
%   MEDFILT = dsp.MedianFilter('Name', Value, ...) returns a median filter
%   System object, MEDFILT, with each specified property name set to the
%   specified value. You can specify additional name-value pair arguments
%   in any order as (Name1,Value1,...,NameN, ValueN).
%
%   MEDFILT = dsp.MedianFilter(Length) returns a median filter object,
%   MEDFILT, with the WindowLength property set to Length.
%
%   Step method syntax:
%
%   Y = step(MEDFILT, X) computes the median, Y, of the input X. Each
%   column of X is a channel. The System object computes the median of each
%   channel of the input signal independently over time. The input must be
%   real.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   MedianFilter methods:
%
%   step                     - Compute median of input
%   release                  - Allow property value and input 
%                              characteristics changes, and release median
%                              filter resources
%   clone                    - Create median filter object with same
%                              property values
%   isLocked                 - Display locked status (logical)
%   reset                    - Reset the states of the median filter
%
%   MedianFilter properties:
%
%   WindowLength            - Sliding window length
%
%   % EXAMPLE: Pass a sine wave corrupted by high-frequency noise through a
%   % median filter. Compare with a moving average filter. 
%   Fs = 1000;
%   scope  = timescope('SampleRate',Fs,...
%                      'TimeSpanSource','property',...
%                      'TimeSpan',1,...
%                      'YLimits',[-3 3],...
%                      'LayoutDimensions',[3 1]);
%   scope.ActiveDisplay = 1;
%   scope.Title = 'Signal + Noise';
%   scope.ActiveDisplay = 2;
%   scope.Title = 'Moving Average Output (Window Length = 7)';
%   scope.ActiveDisplay = 3;
%   scope.Title = 'Median Filter Output (Window Length = 7)';
% 
%   FrameLength = 256;
%
%   medfilt   = dsp.MedianFilter(7);
%   mavrg     = dsp.MovingAverage(7);
% 
%   sine = dsp.SineWave('SampleRate',Fs,'Frequency',10,...
%                       'SamplesPerFrame',FrameLength);
%   tic;
%   while (toc < 5)
%     hfn = 3 * (rand(FrameLength,1) < 0.02);
%     x = sine() + 1e-2 * randn(FrameLength,1) + hfn;
%     y1 = mavrg(x);
%     y2 = medfilt(x);
%     scope(x,y1,y2);
%   end
%
%   See also dsp.MovingMaximum, dsp.MovingMinimum, dsp.MovingAverage, 
%   dsp.HampelFilter

%   Copyright 2016-2021 The MathWorks, Inc.
   
%#codegen
%#ok<*EMCLS>

    properties (Nontunable)
        %WindowLength Window length
        % Specify the sliding window length as a positive, scalar integer.
        % When WindowLength is odd, the median is equal to the middle value
        % in the sorted window. When WindowLength is even, the median is
        % equal to the average of the two middle values in the sorted
        % window. The default is 5.
        WindowLength (1, 1) {mustBePositive, mustBeInteger} = 5;
    end
    
    properties (Access = protected)
        % NumChannels Cached number of channels (used for error checking)
        NumChannels
        % pMID Internal object used to compute median
        pMID
    end
    
    properties (Access = protected, Nontunable)
        % pNumChannels Cached number of channels (used to allocate state)
        pNumChannels
    end
    
    methods
        function obj = MedianFilter(varargin)
            setProperties(obj,nargin,varargin{:}, 'WindowLength');
            obj.NumChannels = int32(-1);
        end 
    end
    
    methods(Access = protected)
        
        function setupImpl(obj,u)
            
            %  Get the number of input channels
            if obj.getExecPlatformIndex()
                thisSize = propagatedInputSize(obj, 1);
                numchans = thisSize(2);
            else
                numchans = size(u,2);
            end
            
            % Disallow a first step with zero channels
            coder.internal.errorIf(numchans == 0,'dsp:system:Shared:EmptyFirstStep');
            
            obj.NumChannels = int32(numchans);
            obj.pNumChannels = numchans;
            
            % Select internal computing object
            if ~isempty(coder.target)
                obj.pMID  = dsp.internal.MedianFilterCG('WindowLength',cast(obj.WindowLength,class(u)),'NumChans',cast(obj.pNumChannels,'int32'));
            else
                obj.pMID  = dsp.internal.MedianFilterSim('WindowLength',obj.WindowLength,'NumChans',obj.pNumChannels);
            end
            
        end
        
        function m = stepImpl(obj,u)
           m = step(obj.pMID,u);
        end
        
        function resetImpl(obj)
          reset(obj.pMID);
        end
        
        function releaseImpl(obj)
            obj.NumChannels = int32(-1);
            release(obj.pMID);
        end
        
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            if isLocked(obj)
                s.NumChannels = obj.NumChannels;
                s.pNumChannels = obj.pNumChannels;
                s.pMID      = matlab.System.saveObject(obj.pMID);
            end
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                obj.NumChannels = s.NumChannels;
                obj.pNumChannels = s.pNumChannels;
                obj.pMID = matlab.System.loadObject(s.pMID);
            end
            loadObjectImpl@matlab.System(obj, s, wasLocked);
        end
        
        function validateInputsImpl(obj,u)
            validateattributes(u, {'single', 'double'}, {'2d','real'},'','')
            if obj.NumChannels ~= -1 && obj.NumChannels ~= 0
                coder.internal.errorIf(size(u,2) ~= obj.NumChannels, ['dsp:system',...
                    ':Shared:numChannels']);
            end
        end
        

        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end              

    end   

end
