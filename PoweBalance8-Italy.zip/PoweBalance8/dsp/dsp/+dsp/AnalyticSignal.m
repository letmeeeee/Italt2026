classdef (StrictDefaults)AnalyticSignal < matlab.System
%AnalyticSignal Analytic signals of discrete-time inputs
%   AS = dsp.AnalyticSignal returns a System object, AS, that computes the
%   complex analytic signal corresponding to each channel of a real M-by-N
%   input matrix.
%
%   AS = dsp.AnalyticSignal('PropertyName', PropertyValue, ...) returns an
%   analytic signal System object, AS, with each specified property set to
%   the specified value.
%
%   AS = dsp.AnalyticSignal(FILTERORDER,'PropertyName',PropertyValue, ...)
%   returns an analytic signal System object, AS, with FilterOrder property
%   set to FILTERORDER and other specified properties set to the specified
%   values.
%
%   The real part of the analytic signal in each channel is a replica of
%   the real input in that channel, and the imaginary part is the Hilbert
%   transform of the input. In the frequency domain, the analytic signal
%   retains the positive frequency content of the original signal while
%   zeroing-out negative frequencies and doubling the DC component. The
%   object computes the Hilbert transform using an equiripple FIR filter.
%
%   Step method syntax:
%
%   Y = step(AS, X) computes the analytic signal, Y, of the input X. Each
%   column of X is treated as an independent channel of input.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   AnalyticSignal methods:
%
%   step     - See above description for use of this method
%   release  - Allow property value and input characteristics changes
%   clone    - Create analytic signal object with same property values
%   isLocked - Locked status (logical)
%   reset    - Reset filter states
%
%   AnalyticSignal properties:
%
%   FilterOrder          - Filter order used to compute Hilbert transform
%
%   % EXAMPLE: Compute the analytic signal of a sinusoidal input.
%       t = (-1:0.01:1)';
%       x = sin(4*pi*t); 
%       analyticSig = dsp.AnalyticSignal(200);   % Filter order = 200
%       y = analyticSig(x);
%       subplot(2,1,1), plot(t, x); 
%       title('Original Signal');
%       subplot(2,1,2), plot(t, [real(y) imag(y)]); 
%       title('Analytic signal of the input')
%       legend('Real signal', 'Imaginary signal', 'Location', 'best');
%
%   See also dsp.FFT, dsp.IFFT.

%   Copyright 1995-2021 The MathWorks, Inc.

%#codegen
%#ok<*EMCLS>

properties (Nontunable)
  %FilterOrder Filter order used to compute Hilbert transform
  %   Specify the order of the equiripple filter used in computing the
  %   Hilbert transform as an even integer scalar. The default value of
  %   this property is 100.
  FilterOrder = 100;
end

properties(Access = private, Nontunable)
  cDelay;
  cFIRFilter;
end

  methods
    function obj = AnalyticSignal(varargin)
      setProperties(obj, nargin, varargin{:}, 'FilterOrder');
    end

    function set.FilterOrder(obj, value)
    validateattributes(value, { 'numeric' }, { 'positive', 'even', 'integer' }, '', 'FilterOrder');
      obj.FilterOrder = value;
    end

  end

  methods(Access = protected)
    function out = stepImpl(obj, in)
      out = complex(step(obj.cDelay, in), step(obj.cFIRFilter, in));

    end
    
    
    
    
    function validateInputsImpl(~,x)
      % Only floating point inputs are supported
      coder.internal.assert(isfloat(x), 'MATLAB:system:invalidInputDataType','X','floating-point');

      coder.internal.errorIf(~ismatrix(x), 'dsp:system:AnalyticSignal:inDimsGreaterThanTwo');
    end

    function setupImpl(obj, ~)
      N = obj.FilterOrder;
      
      b = dspblkanalytic2('design', false, N);
      obj.cDelay = dsp.Delay( ...
          'Length', N/2);
      
      obj.cFIRFilter = dsp.FIRFilter( ...
          'Structure','Direct form transposed', ...
          'Numerator', b);

    end

    function  resetImpl(obj)
        reset(obj.cDelay);
        reset(obj.cFIRFilter);
    end
    
    function  releaseImpl(obj)
        release(obj.cDelay);
        release(obj.cFIRFilter);
    end
    
    function s = saveObjectImpl(obj)
      s = saveObjectImpl@matlab.System(obj);
      if isLocked(obj)
         s.cDelay     = matlab.System.saveObject(obj.cDelay); 
         s.cFIRFilter = matlab.System.saveObject(obj.cFIRFilter); 
      end
    end
    
    function loadObjectImpl(obj, s, wasLocked)
        if wasLocked
            obj.cDelay     =  matlab.System.loadObject(s.cDelay);
            if strcmp(s.cFIRFilter.ClassNameForLoadTimeEval,'dsp.DigitalFilter')
                obj.cFIRFilter = dsp.FIRFilter( ...
                    'Structure','Direct form transposed', ...
                    'Numerator',  s.cFIRFilter.ChildClassData.Numerator);
            else
                obj.cFIRFilter =  matlab.System.loadObject(s.cFIRFilter);
            end
        end
        % Call the base class method
        loadObjectImpl@matlab.System(obj, s);
    end
  end
  
end
