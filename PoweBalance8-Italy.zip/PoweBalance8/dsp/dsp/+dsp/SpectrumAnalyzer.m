classdef SpectrumAnalyzer < dsp.webscopes.SpectrumAnalyzerBaseWebScope
%spectrumAnalyzer Display frequency-domain signals and the frequency
%spectrum of time-domain signals
%   SPECTANLZR = dsp.SpectrumAnalyzer returns a MATLAB object, SPECTANLZR,
%   that displays the frequency spectrum of real or complex signals.
%
%   SPECTANLZR = dsp.SpectrumAnalyzer(Name=Value, ...) returns a
%   Spectrum Analyzer MATLAB object, SPECTANLZR, with each specified
%   property name set to the specified value. You can specify name-value
%   pair arguments in any order as (Name1=Value1,...,NameN=ValueN).
%
%   SPECTANLZR = dsp.SpectrumAnalyzer(NUMINPUTS, Name=Value, ...) returns a
%   Spectrum Analyzer object, SPECTANLZR, with the NumInputPorts property
%   set to NUMINPUTS, and other specified properties set to the specified
%   values. NUMINPUTS is a value-only argument. You can specify name-value
%   pair arguments in any order.
%
%   Step method syntax:
%
%   step(SPECTANLZR, X) displays the frequency spectrum of double, single
%   or fixed-point precision input X, in the Spectrum Analyzer figure. The
%   columns of X are treated as independent channels.
%
%   step(SPECTANLZR, X1, X2, ..., XN) displays the frequency spectrum of
%   signals X1, X2, ..., XN in the Spectrum Analyzer figure. All of X1, X2,
%   ... XN must have the same number of rows, but they can have different
%   number of columns. The columns of each X1, X2, ..., XN are treated as
%   independent channels.
%
%   Objects may be called directly like a function instead of using the
%   step method. For example, step(obj, x) and obj(x) are equivalent.
%
%   SpectrumAnalyzer methods:
%
%   step                  - Display spectrum of input in figure (see above)
%   release               - Allow property value and input characteristics 
%                           changes, and release Spectrum Analyzer resources
%   clone                 - Create Spectrum Analyzer object with same 
%                           property values
%   isLocked              - Display locked status (logical)
%   reset                 - Clear Spectrum Analyzer figure
%   show                  - Turn on visibility of Spectrum Analyzer figure
%   hide                  - Turn off visibility of Spectrum Analyzer figure
%   isVisible             - Return visibility of Spectrum Analyzer figure 
%                          (logical)
%   getSpectralMaskStatus - Get current results of spectral mask testing
%   getSpectrumData       - Get the current spectrum data displayed on the
%                           Spectrum Analyzer
%   getMeasurementsData   - Get the current measurement data
%   isNewDataReady        - Return whether or not the Spectrum Analyzer is
%                           displaying new spectrum data.
%   generateScript        - Generate MATLAB(R) script
%   printToFigure         - Print scope window to a MATLAB(R) figure
%
%   SpectrumAnalyzer properties:
%
%   NumInputPorts                 - Number of input signals
%   InputDomain                   - Input signal domain
%   SpectrumType                  - Choose to visualize power, power 
%                                   density, or RMS 
%   ViewType                      - Choose to view spectrum, spectrogram,
%                                   or both
%   SampleRate                    - Sample rate of input
%   Method                        - Welch or filter bank
%   PlotAsTwoSidedSpectrum        - Option to plot spectrum as two-sided
%   FrequencyScale                - Frequency scale
%   PlotType                      - Choose the plot type
%   AxesScaling                   - Axes scaling mode
%   AxesScalingNumUpdates         - Number of updates before scaling
%   FrequencyResolutionMethod     - Control resolution using RBW or window
%                                   length
%   RBWSource                     - Source of resolution bandwidth value
%   RBW                           - Resolution bandwidth
%   WindowLength                  - Window length
%   FFTLengthSource               - Source of the FFT length value
%   FFTLength                     - FFT length
%   NumTapsPerBand                - Number of filter taps per frequency
%                                   band
%   FrequencyVectorSource         - Source of frequency vector
%   FrequencyVector               - Frequency vector
%   FrequencySpan                 - Frequency span mode
%   Span                          - Frequency span over which spectrum is 
%                                   computed
%   CenterFrequency               - Frequency over which span is centered
%   StartFrequency                - Start frequency over which spectrum is 
%                                   computed
%   StopFrequency                 - Stop frequency over which spectrum is 
%                                   computed
%   OverlapPercent                - Overlap percentage
%   Window                        - Window function
%   CustomWindow                  - Custom window function name
%   SidelobeAttenuation           - Sidelobe attenuation of window
%   AveragingMethod               - Averaging method
%   SpectralAverages              - Number of spectral averages
%   ForgettingFactor              - Forgetting factor
%   VBWSource                     - Source of video bandwidth
%   VBW                           - Video bandwidth
%   InputUnits                    - Input signal units
%   SpectrumUnits                 - Spectrum units
%   FullScaleSource               - Source of the full scale value
%   FullScale                     - Full scale
%   ReferenceLoad                 - Reference load
%   FrequencyOffset               - Frequency offset
%   SpectrogramChannel            - Channel for which spectrogram is
%                                   plotted
%   TimeResolutionSource          - Source of time resolution value
%   TimeResolution                - Time resolution
%   TimeSpanSource                - Source of time span value
%   TimeSpan                      - Time span
%   MeasurementChannel            - Channel for which measurement is
%                                   computed
%   ChannelMeasurements           - Channel measurements
%   CursorMeasurements            - Cursor measurements
%   DistortionMeasurements        - Distortion measurements
%   PeakFinder                    - Peak finder measurement
%   SpectralMask                  - Spectral mask configuration
%   Name                          - Caption to display on Spectrum Analyzer 
%                                   window
%   Position                      - Spectrum analyzer window position in 
%                                   pixels
%   MaximizeAxes                  - Maximize axes control
%   PlotNormalTrace               - Option to plot Normal trace
%   PlotMaxHoldTrace              - Option to plot Max-hold trace
%   PlotMinHoldTrace              - Option to plot Min-hold trace
%   Title                         - Display title
%   YLabel                        - Y-axis label
%   YLimits                       - Y-axis limits
%   ColorLimits                   - Color Limits
%   Colormap                      - Color look-up table 
%   ShowGrid                      - Show or hide grid
%   ShowLegend                    - Show or hide legend
%   ShowColorbar                  - Show or hide colorbar 
%   ChannelNames                  - Names for the input data channels
%   AxesLayout                    - Option to change the view layout
%
%   % Example: 
%   %   View the power spectrum of a noisy sine wave on Spectrum Analyzer.
%   swv = dsp.SineWave(Frequency=100, SampleRate=1000);
%   swv.SamplesPerFrame = 1000;
%   san = spectrumAnalyzer(SampleRate=swv.SampleRate);
%   for ii = 1:250
%     x = swv() + 0.05*randn(1000,1);
%     san(x);
%   end
%   release(san);
%
%   % Example:
%   %   Get the spectrum data displayed on the spectrum analyzer.
%   swv = dsp.SineWave(Frequency=100, SampleRate=1000);
%   swv.SamplesPerFrame = 1000;
%   san = spectrumAnalyzer(SampleRate=swv.SampleRate);
%   data = [];
%   for ii = 1:250
%     x = swv() + 0.05*randn(1000,1);
%     san(x);
%     if san.isNewDataReady
%       data = [data;getSpectrumData(san)];
%     end
%   end
%   release(san);
%
%   See also dsp.SpectrumEstimator, dsp.ArrayPlot, timescope

%   Copyright 2011-2022 The MathWorks, Inc.

%#function dsp.webscopes.SpectrumAnalyzerBaseWebScope
%#function dsp.webscopes.internal.BaseWebScope
%#function dsp.webscopes.internal.PropertyChangedEventData
%#function matlabshared.scopes.WebWindow
%#function matlabshared.scopes.WebStreamingSource
%#function utils.getDefaultWebWindowPosition
%#function utils.logicalToOnOff

    methods
        function this = SpectrumAnalyzer(varargin)
            % Call super class constructor
            this@dsp.webscopes.SpectrumAnalyzerBaseWebScope('Method','welch', ...
                'AveragingMethod', 'running', ...
                'NumTapsPerBand', 12, ...
                'FilterSharpness', 0.5, ...
                varargin{:});
        end
    end
%--------------------------------------------------------------------------
% Protected methods
%--------------------------------------------------------------------------
    methods (Access = protected)
        %------------------------------------------------------------------
        function groups = getPropertyGroups(this)
            % Return list of property groups for display
            mainProps = getValidDisplayProperties(this, {'NumInputPorts', ...
                'InputDomain', ...
                'SpectrumType', ...
                'ViewType', ...
                'SampleRate',  ...
                'Method', ...
                'PlotAsTwoSidedSpectrum',...
                'FrequencyScale',...
                'PlotType', ...
                'AxesScaling', ...
                'AxesScalingNumUpdates'});
            groups = matlab.mixin.util.PropertyGroup(mainProps, '');

            if(this.ShowAllProperties)
                % Do not show all properties unless requested
                % Advanced properties
                advancedProps = getValidDisplayProperties(this, { 'FrequencyResolutionMethod', ...
                    'RBWSource', ...
                    'RBW', ...
                    'FilterSharpness', ...
                    'NumTapsPerBand', ...
                    'WindowLength', ...
                    'FFTLengthSource', ...
                    'FFTLength', ...
                    'FrequencyVectorSource', ...
                    'FrequencyVector', ...
                    'FrequencySpan', ...
                    'Span', ...
                    'CenterFrequency', ...
                    'StartFrequency', ...
                    'StopFrequency', ...
                    'OverlapPercent', ...
                    'Window', ...
                    'CustomWindow',...
                    'SidelobeAttenuation', ...
                    'AveragingMethod', ...
                    'SpectralAverages', ...
                    'ForgettingFactor', ...
                    'VBWSource', ...
                    'VBW', ...
                    'InputUnits', ...
                    'SpectrumUnits', ...
                    'FullScaleSource', ...
                    'FullScale', ...
                    'ReferenceLoad', ...
                    'FrequencyOffset'});
                % Spectrogram properties
                spectrogramProps = getValidDisplayProperties(this, {'SpectrogramChannel', ...
                    'TimeResolutionSource', ...
                    'TimeResolution', ...
                    'TimeSpanSource', ...
                    'TimeSpan'});
                % Measurements properties
                measurementsProps = getValidDisplayProperties(this, {'MeasurementChannel', ...
                    'ChannelMeasurements', ...
                    'CursorMeasurements', ...
                    'DistortionMeasurements', ...
                    'PeakFinder', ...
                    'SpectralMask'});
                % Visualization properties
                visualizationProps = getValidDisplayProperties(this, {'Name', ...
                    'Position', ...
                    'MaximizeAxes', ...
                    'PlotNormalTrace', ...
                    'PlotMaxHoldTrace', ...
                    'PlotMinHoldTrace', ...
                    'Title', ...
                    'YLabel', ...
                    'YLimits', ...
                    'ColorLimits', ...
                    'Colormap', ...
                    'ShowGrid', ...
                    'ChannelNames', ...
                    'ShowLegend', ...
                    'ShowColorbar', ...
                    'AxesLayout'});
                 % Property groups
                 advancedGroupTitle = getString(message('shared_dspwebscopes:dspwebscopes:advancedProperties'));
                 spectrogramGroupTitle = getString(message('shared_dspwebscopes:dspwebscopes:spectrogramProperties'));
                 measurementsGroupTitle = getString(message('shared_dspwebscopes:dspwebscopes:measurementsProperties'));
                 visualizationGroupTitle = getString(message('shared_dspwebscopes:dspwebscopes:visualizationProperties'));
                 
                 groups = [groups, ...
                     matlab.mixin.util.PropertyGroup(advancedProps, advancedGroupTitle), ...
                     matlab.mixin.util.PropertyGroup(spectrogramProps, spectrogramGroupTitle), ...
                     matlab.mixin.util.PropertyGroup(measurementsProps, measurementsGroupTitle), ...
                     matlab.mixin.util.PropertyGroup(visualizationProps, visualizationGroupTitle)];
            end
        end
    end
end

