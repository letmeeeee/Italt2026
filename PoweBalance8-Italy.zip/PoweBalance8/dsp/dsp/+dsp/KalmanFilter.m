classdef KalmanFilter
%KalmanFilter Estimate measurements and states of a system in presence
%             of white noise using Kalman Filter

%   Copyright 1995-2022 The MathWorks, Inc.

    methods
        function obj = KalmanFilter(varargin)
            % CONSTRUCTOR
            coder.internal.error('dsp:system:KalmanFilter_NotSupported');
        end
    end
end
