classdef (StrictDefaults)SubbandAnalysisFilter < ...
        dsp.internal.SupportArbitraryInputLength
%SubbandAnalysisFilter Decompose signal into high-frequency and low-
%                      frequency subbands
%   SAF = dsp.SubbandAnalysisFilter returns a two-channel subband analysis
%   filter System object, SAF, that decomposes the input signal into a
%   high-frequency subband and a low-frequency subband, each with half the
%   bandwidth of the input.
%
%   SAF = dsp.SubbandAnalysisFilter('PropertyName', PropertyValue, ...)
%   returns a two-channel subband analysis filter System object, SAF, with
%   each specified property set to the specified value.
%
%   SAF = dsp.SubbandAnalysisFilter(LPCOEFFS, HPCOEFFS, 'PropertyName',
%   PropertyValue, ...) returns a two-channel subband analysis filter
%   System object, SAF, with the LowpassCoefficients property set to
%   LPCOEFFS, the HighpassCoefficients property set to HPCOEFFS, and other
%   specified properties set to the specified values.
%
%   Step method syntax:
%
%   [HI, LO] = step(SAF, SIG) decomposes the input signal, SIG, into a
%   high-frequency subband, HI, and a low-frequency subband, LO.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   SubbandAnalysisFilter methods:
%
%   step     - See above description for use of this method
%   release  - Allow property value and input characteristics changes
%   clone    - Create two-channel subband analysis filter object with same
%              property values
%   isLocked - Locked status (logical)
%   reset    - Reset states of filter
%
%   SubbandAnalysisFilter properties:
%
%   LowpassCoefficients  - Lowpass FIR filter coefficients
%   HighpassCoefficients - Highpass FIR filter coefficients
%
%   This System object supports fixed-point operations. For more
%   information, type dsp.SubbandAnalysisFilter.helpFixedPoint.
%
%   % EXAMPLE: Use SubbandAnalysisFilter and SubbandSynthesisFilter System
%   % objects to show perfect reconstruction.
%      load dspwlets; % load the filter coefficients lod, hid, lor and hir
%      SAF = dsp.SubbandAnalysisFilter(lod, hid);
%      SSF = dsp.SubbandSynthesisFilter(lor, hir);
%      u = randn(128,1);
%      [hi, lo] = SAF(u); % Two channel analysis
%      y = SSF(hi, lo);   % Two channel synthesis
%      % Plot difference between original and reconstructed signals with 
%      % filter latency compensated
%      plot(u(1:end-7)-y(8:end));
%
%   See also dsp.SubbandSynthesisFilter,
%            dsp.DyadicAnalysisFilterBank,
%            dsp.SubbandAnalysisFilter.helpFixedPoint.

%   Copyright 1995-2022 The MathWorks, Inc.

%#codegen

%#ok<*EMCLS>
%#ok<*EMCA>

  properties (Nontunable)
    %LowpassCoefficients Lowpass FIR filter coefficients
    %   Specify a vector of lowpass FIR filter coefficients, in descending
    %   powers of z. The lowpass filter should be a halfband filter that
    %   passes the frequency band stopped by the filter specified in the
    %   HighpassCoefficients property. The default values of this property
    %   specify a filter based on a 3rd-order Daubechies wavelet.
    LowpassCoefficients = [0.0352 -0.0854 -0.1350 0.4599 0.8069 0.3327];
    %HighPassFIRCoeffs  Highpass FIR filter coefficients
    %   Specify a vector of highpass FIR filter coefficients, in descending
    %   powers of z. The highpass filter should be a halfband filter that
    %   passes the frequency band stopped by the filter specified in the
    %   LowpassCoefficients property. The default values of this property
    %   specify a filter based on a 3rd-order Daubechies wavelet.
    HighpassCoefficients = [-0.3327 0.8069 -0.4599 -0.1350  0.0854  0.0352];
    
    %RoundingMethod Rounding method for fixed-point operations
    %   Specify the rounding method as one of ['Ceiling' | 'Convergent' |
    %   'Floor' | 'Nearest' | 'Round' | 'Simplest' | 'Zero']. This
    %   property is applicable when the object is not in a full precision
    %   configuration. The default is 'Floor'.
    RoundingMethod = 'Floor';
    %OverflowAction Overflow action for fixed-point operations
    %   Specify the overflow action as one of ['Wrap' | 'Saturate']. This
    %   property is applicable when the object is not in a full precision
    %   configuration. The default is 'Wrap'.
    OverflowAction = 'Wrap';
    
    %CoefficientsDataType Coefficients word- and fraction-length designations
    %   Specify the FIR filter coefficients fixed-point data type as one of
    %   ['Same word length as input' | 'Custom']. The default is 'Same
    %   word length as input'.
    CoefficientsDataType    = 'Same word length as input';
    %CustomCoefficientsDataType Coefficients word and fraction lengths
    %   Specify the FIR filter coefficients fixed-point type as an
    %   auto-signed numerictype object. This property is applicable when
    %   the CoefficientsDataType property is 'Custom'. The default value of
    %   this property is numerictype([],16,15).
    %
    %   See also numerictype.
    CustomCoefficientsDataType = numerictype([], 16, 15);
    
    %ProductDataType Product word- and fraction-length designations
    %   Specify the product fixed-point data type as one of ['Full
    %   precision' | 'Same as input' | 'Custom']. This property is
    %   applicable when the FullPrecisionOverride property is false. The
    %   default is 'Full precision'.
    ProductDataType = 'Full precision';
    %CustomProductDataType Product word and fraction lengths
    %   Specify the product fixed-point type as an auto-signed, scaled
    %   numerictype object. This property is applicable when the
    %   FullPrecisionOverride property is false and when the
    %   ProductDataType property is 'Custom'. The default value of this
    %   property is numerictype([],32,30).
    %
    %   See also numerictype.
    CustomProductDataType = numerictype([], 32, 30);
    
    %AccumulatorDataType Accumulator word- and fraction-length designations
    %   Specify the accumulator fixed-point data type as one of ['Full
    %   precision' | 'Same as product' | 'Same as input' | 'Custom'].
    %   This property is applicable when the  FullPrecisionOverride
    %   property is false. The default is 'Full precision'.
    AccumulatorDataType = 'Full precision';
    %CustomAccumulatorDataType Accumulator word and fraction lengths
    %   Specify the accumulator fixed-point type as an auto-signed, scaled
    %   numerictype object. This property is applicable when the
    %   FullPrecisionOverride property is false and when the
    %   AccumulatorDataType property is 'Custom'. The default value of this
    %   property is numerictype([],32,30).
    %
    %   See also numerictype.
    CustomAccumulatorDataType = numerictype([], 32, 30);
    
    %OutputDataType Output word- and fraction-length designations
    %   Specify the output fixed-point data type as one of ['Same as
    %   accumulator' | 'Same as product' | 'Same as input' | 'Custom'].
    %   This property is applicable when the FullPrecisionOverride
    %   property is false. The default is 'Same as accumulator'.
    OutputDataType = 'Same as accumulator';
    %CustomOutputDataType Output word and fraction lengths
    %   Specify the output fixed-point type as an auto-signed, scaled
    %   numerictype object. This property is applicable when the
    %   FullPrecisionOverride property is false and when the
    %   OutputDataType property is 'Custom'. The default value of this
    %   property is numerictype([],16,14).
    %
    %   See also numerictype.
    CustomOutputDataType   = numerictype([], 16, 14);


    % FIXED-POINT

    %FullPrecisionOverride Full precision override for fixed-point arithmetic
    %   Specify whether to use full precision rules. If you set
    %   FullPrecisionOverride to true the object computes all
    %   internal arithmetic and output data types using full
    %   precision rules. These rules guarantee that no quantization
    %   occurs within the object. Bits are added as needed to ensure
    %   that no round-off or overflow occurs. If you set
    %   FullPrecisionOverride to false, fixed-point data types
    %   are controlled through individual property settings.
    FullPrecisionOverride (1, 1) logical = true;
  end

  properties(Constant, Hidden)
    % fixpt enum props
    RoundingMethodSet       = dsp.CommonSets.getSet('RoundingMethod');
    OverflowActionSet       = dsp.CommonSets.getSet('OverflowAction');
    CoefficientsDataTypeSet = dsp.CommonSets.getSet('FixptModeEitherScale');
    ProductDataTypeSet      = dsp.CommonSets.getSet('FixptModeInherit');
    AccumulatorDataTypeSet  = dsp.CommonSets.getSet('FixptModeInheritProd');
    OutputDataTypeSet       = dsp.CommonSets.getSet('FixptModeAccumProd');
  end

  properties(Access=private)
    % Subsystems
    cHighpassFIR;
    cLowpassFIR;
  end 

  methods
    % CONSTRUCTOR
    function obj = SubbandAnalysisFilter(varargin)
      setProperties(obj, nargin, varargin{:}, 'LowpassCoefficients', 'HighpassCoefficients');
    end

    % PROPERTY VALIDATION
    function set.LowpassCoefficients(obj,val)
      validateattributes( val, { 'numeric' }, { 'finite', 'vector' }, '', 'LowpassCoefficients');      
      obj.LowpassCoefficients = val;
    end

    function set.HighpassCoefficients(obj,val)
       validateattributes( val, { 'numeric' }, { 'finite', 'vector' }, '', 'HighpassCoefficients');      
      obj.HighpassCoefficients = val;
    end
    
    % Fixedpoint restrictions
    function set.CustomCoefficientsDataType(obj,val)
      validateCustomDataType(obj,'CustomCoefficientsDataType',val, ...
        {'AUTOSIGNED'});
      obj.CustomCoefficientsDataType = val;
    end
    function set.CustomProductDataType(obj,val)
      validateCustomDataType(obj,'CustomProductDataType',val, ...
        {'AUTOSIGNED','SCALED'});
      obj.CustomProductDataType = val;
    end
    function set.CustomAccumulatorDataType(obj,val)
      validateCustomDataType(obj,'CustomAccumulatorDataType',val, ...
        {'AUTOSIGNED','SCALED'});
      obj.CustomAccumulatorDataType = val;
    end
    function set.CustomOutputDataType(obj,val)
      validateCustomDataType(obj,'CustomOutputDataType',val, ...
        {'AUTOSIGNED','SCALED'});
      obj.CustomOutputDataType = val;
    end

  end

  methods(Access=protected)

    function [y1 , y2] = stepImpl(obj,in)
      y1 = step(obj.cHighpassFIR, in);
      y2 = step(obj.cLowpassFIR, in);
    end

    function setupImpl(obj,~)
      fixptPropValues = getConstructorFixedPointPVPairs(obj);

      coder.extrinsic('dsp.SubbandAnalysisFilter.suppressWarning');
      coder.extrinsic('dsp.SubbandAnalysisFilter.restoreWarning');
      
      pWarnState = coder.const(@dsp.SubbandAnalysisFilter.suppressWarning,1);

      if isempty(coder.target)
         c = onCleanup(@()dsp.SubbandAnalysisFilter.restoreWarning(pWarnState));
      end
      
      obj.cHighpassFIR = dsp.FIRDecimator( ...
        2,    obj.HighpassCoefficients, ...
        fixptPropValues{:},...
        'AllowArbitraryInputLength',coder.const(isInputArbitraryOrVarSize(obj,2)));
      
      obj.cLowpassFIR  = dsp.FIRDecimator( ...
        2,    obj.LowpassCoefficients, ...
        fixptPropValues{:}, ...
        'AllowArbitraryInputLength',coder.const(isInputArbitraryOrVarSize(obj,2)));
    
      if ~isempty(coder.target)
          coder.const(@dsp.SubbandAnalysisFilter.restoreWarning,pWarnState);
      end

    end
    
    function validateInputsImpl(~, ~)
    end

    function flag = isInputSizeMutableImpl(~,~)
        flag = true;
    end
    
    
    
    
    function  resetImpl(obj)
        reset(obj.cLowpassFIR);
        reset(obj.cHighpassFIR);
    end

    function num = getNumOutputsImpl(~)
      num = 2;
    end

    % INTERFACE QUERY SUPPORT METHODS
    
    function flag = isInactivePropertyImpl(obj, prop)
        flag = false;
        switch prop
            case {'RoundingMethod', 'OverflowAction'}
                if (obj.FullPrecisionOverride || ...
                   (strcmpi(obj.OutputDataType, 'Same as accumulator') && ...
                    strcmpi(obj.ProductDataType, 'Full precision') &&  ...
                    strcmpi(obj.AccumulatorDataType, 'Full precision')))
                   flag = true;
                end
            case {'ProductDataType', 'AccumulatorDataType', 'OutputDataType'}
                if obj.FullPrecisionOverride
                   flag = true;
                end
            case 'CustomProductDataType'
                if (obj.FullPrecisionOverride || ...
                   (strcmpi(obj.OutputDataType, 'Same as accumulator') && ...
                    strcmpi(obj.ProductDataType, 'Full precision') &&  ...
                    strcmpi(obj.AccumulatorDataType, 'Full precision')) || ...
                    ~matlab.system.isSpecifiedTypeMode(obj.ProductDataType))
                   flag = true;
                end
            case 'CustomAccumulatorDataType'
                if (obj.FullPrecisionOverride || ...
                   (strcmpi(obj.OutputDataType, 'Same as accumulator') && ...
                    strcmpi(obj.ProductDataType, 'Full precision') &&  ...
                    strcmpi(obj.AccumulatorDataType, 'Full precision')) || ...
                    ~matlab.system.isSpecifiedTypeMode(obj.AccumulatorDataType))
                     flag = true;
                end
            case 'CustomOutputDataType'
                if (obj.FullPrecisionOverride || ...
                   (strcmpi(obj.OutputDataType, 'Same as accumulator') && ...
                    strcmpi(obj.ProductDataType, 'Full precision') &&  ...
                    strcmpi(obj.AccumulatorDataType, 'Full precision')) || ...
                    ~matlab.system.isSpecifiedTypeMode(obj.OutputDataType))
                      flag = true;
                end
            case 'CustomCoefficientsDataType'
                if ~matlab.system.isSpecifiedTypeMode(obj.CoefficientsDataType)
                    flag = true;
                end
        end
    end  
    
    function s = saveObjectImpl(obj)
      s = saveObjectImpl@matlab.System(obj);
      if isLocked(obj)
         s.cHighpassFIR     = matlab.System.saveObject(obj.cHighpassFIR); 
         s.cLowpassFIR      = matlab.System.saveObject(obj.cLowpassFIR); 
      end
    end

    function loadObjectImpl(obj, s, wasLocked)
      if wasLocked
        obj.cHighpassFIR     =  matlab.System.loadObject(s.cHighpassFIR);
        obj.cLowpassFIR      =  matlab.System.loadObject(s.cLowpassFIR);
      end
      % Old saved versions do not FullPrecisionOverride property
      if ~isfield(s,'FullPrecisionOverride')
          s.FullPrecisionOverride = false;
      end
      % Call the base class method
      loadObjectImpl@matlab.System(obj, s);
    end

    end % methods, protected API

  methods(Static)
    function helpFixedPoint
      %helpFixedPoint Display dsp.SubbandAnalysisFilter System 
      %               object fixed-point information
      %   dsp.SubbandAnalysisFilter.helpFixedPoint displays information
      %   about fixed-point properties and operations of the
      %   dsp.SubbandAnalysisFilter System object.

      matlab.system.dispFixptHelp('dsp.SubbandAnalysisFilter', ...
        dsp.SubbandAnalysisFilter.getDisplayFixedPointProperties);
    end
  end

  methods (Static, Hidden)
    % Needed by helpFixedPoint and getPropertyGroupsImpl
    function props = getDisplayFixedPointProperties()
      props = {...
        'FullPrecisionOverride', ...
        'RoundingMethod','OverflowAction', ...
        'CoefficientsDataType','CustomCoefficientsDataType', ...
        'ProductDataType','CustomProductDataType', ...
        'AccumulatorDataType','CustomAccumulatorDataType', ...
        'OutputDataType','CustomOutputDataType'};
    end
    
    function a = getAlternateBlock
        a = 'dspmlti4/Two-Channel Analysis Subband Filter';
    end
    
    function warnState = suppressWarning(~)
        s = warning('query','MATLAB:system:nonRelevantProperty');
        if strcmp(s.state,'on')
            warnState = true;
        else
            warnState = false;
        end
        warning('off','MATLAB:system:nonRelevantProperty');
    end
    
    function restoreWarning(warnState)
        if warnState
            warning('on','MATLAB:system:nonRelevantProperty');
        else
            warning('off','MATLAB:system:nonRelevantProperty');
        end
    end

  end
    
  methods (Access=private)
    function str = getConstructorFixedPointPVPairs(obj) 
      str = cell(1,22);  
      index = 1;
      str{index} = 'FullPrecisionOverride';        index = index + 1;
      str{index} = obj.FullPrecisionOverride;      index = index + 1;
      str{index} = 'CoefficientsDataType';         index = index + 1;
      str{index} = obj.CoefficientsDataType;       index = index + 1; 
      str{index} = 'CustomCoefficientsDataType';   index = index + 1; 
      str{index} = obj.CustomCoefficientsDataType; index = index + 1; 
      str{index} = 'ProductDataType';              index = index + 1; 
      str{index} = obj.ProductDataType;            index = index + 1; 
      str{index} = 'CustomProductDataType';        index = index + 1; 
      str{index} = obj.CustomProductDataType;      index = index + 1; 
      str{index} = 'AccumulatorDataType';          index = index + 1; 
      str{index} = obj.AccumulatorDataType;        index = index + 1; 
      str{index} = 'CustomAccumulatorDataType';    index = index + 1; 
      str{index} = obj.CustomAccumulatorDataType;  index = index + 1; 
      str{index} = 'OutputDataType';               index = index + 1; 
      str{index} = obj.OutputDataType;             index = index + 1; 
      str{index} = 'CustomOutputDataType';         index = index + 1; 
      str{index} = obj.CustomOutputDataType;       index = index + 1; 
      str{index} = 'RoundingMethod';               index = index + 1; 
      str{index} = obj.RoundingMethod;             index = index + 1; 
      str{index} = 'OverflowAction';               index = index + 1; 
      str{index} = obj.OverflowAction; 
    end    
  end
  
  methods(Static,Hidden,Access=protected)
    function groups = getPropertyGroupsImpl
      props = {'LowpassCoefficients','HighpassCoefficients'};
      mainS = matlab.system.display.Section('Title', getString(message('dsp:system:Shared:Parameters')), ...
                                            'PropertyList', props);
      mainSG = matlab.system.display.SectionGroup('TitleSource', 'Auto', ...
                                                  'Sections', mainS);
      dtSG = matlab.system.display.SectionGroup('Title', 'Data Types', ...
               'PropertyList', ...
               dsp.SubbandAnalysisFilter.getDisplayFixedPointProperties);
      groups = [mainSG, dtSG];
    end    
  end
end
