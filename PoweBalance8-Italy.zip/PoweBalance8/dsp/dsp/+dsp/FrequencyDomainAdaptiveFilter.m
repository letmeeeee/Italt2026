classdef (StrictDefaults)FrequencyDomainAdaptiveFilter < matlab.System
%FrequencyDomainAdaptiveFilter Computes output, error and coefficients using
%                              frequency domain FIR adaptive filter.
%
%   FDAFILT = dsp.FrequencyDomainAdaptiveFilter returns a frequency domain
%   FIR adaptive filter System object(TM), FDAFILT. This System object is
%   used to compute the filtered output and the filter error for a given
%   input and desired signal.
%
%   FDAFILT = dsp.FrequencyDomainAdaptiveFilter('PropertyName',PropertyValue,...)
%   returns a FrequencyDomainAdaptiveFilter System object, FDAFILT, with
%   each specified property set to the specified value.
%
%   FDAFILT = dsp.FrequencyDomainAdaptiveFilter(LEN, 'PropertyName', ...
%       PropertyValue, ...)
%   returns a FrequencyDomainAdaptiveFilter System object, FDAFILT, with
%   the Length property set to LEN, and other specified properties set to
%   the specified values.
%
%   Step method syntax:
%
%   [Y, ERR] = step(FDAFILT, X, D) filters the input X, using D as the
%   desired signal, and returns the filtered output in Y and the filter
%   error in ERR. The System object estimates the filter weights needed to
%   minimize the error between the output signal and the desired signal.
%   The FFT of these filter weights can be obtained by accessing the
%   FFTCoefficients property after calling the step method by
%   FDAFILT.FFTCoefficients.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   FrequencyDomainAdaptiveFilter methods:
%
%   step                - See above description for use of this method.
%   release             - Allow changes in non-tunable property values and
%                         input characteristics.
%   clone               - Create a FrequencyDomainAdaptiveFilter object
%                         with the same property values and internal
%                         states.
%   isLocked            - Locked status of the filter object (logical).
%   reset               - Reset the internal states to their initial
%                         conditions.
%
%   FrequencyDomainAdaptiveFilter properties:
%
%   Method              - Method to calculate the filter
%                         coefficients
%   Length              - Length of filter coefficients vector
%   BlockLength         - Block length for the coefficient updates
%   StepSize            - Adaptation step size
%   LeakageFactor       - Adaptation leakage factor
%   AveragingFactor     - Averaging factor for the signal power
%   Offset              - Offset for the normalization terms
%   InitialPower        - Initial FFT input signal power
%   InitialCoefficients - Initial time-domain coefficients of the filter
%   LockCoefficients    - Locked status of the coefficient updates
%
%
%   % EXAMPLE #1: QPSK adaptive equalization using a 32-coefficient FIR
%   %   filter (1024 iterations).
%
%     D = 16;                       % Number of samples of delay
%     b  = exp(1i*pi/4)*[-0.7 1];   % Numerator coefficients of channel
%     a  = [1 -0.7];                % Denominator coefficients of channel
%     ntr= 1024;                    % Number of iterations
%     s  = sign(randn(1,ntr+D))+1i*sign(randn(1,ntr+D));    % QPSK signal
%     n  = 0.1*(randn(1,ntr+D) + 1i*randn(1,ntr+D));        % Noise signal
%     r  = filter(b,a,s) + n;       % Received signal
%     x  = r(1+D:ntr+D);            % Input signal (received signal)
%     d  = s(1:ntr);                % Desired signal (delayed QPSK signal)
%     mu  = 0.1;                    % Step size
%     fdafilt = dsp.FrequencyDomainAdaptiveFilter('Length',32,'StepSize',mu);
%     [y,e] = fdafilt(x,d);
%     subplot(2,2,1); plot(1:ntr,real([d;y;e]));
%     legend('Desired','Output','Error'); title('In-Phase Components');
%     xlabel('Time Index'); ylabel('signal value');
%     subplot(2,2,2); plot(1:ntr,imag([d;y;e]));
%     legend('Desired','Output','Error'); title('Quadrature Components');
%     xlabel('Time Index'); ylabel('signal value');
%     subplot(2,2,3); plot(x(ntr-100:ntr),'.'); axis([-3 3 -3 3]);
%     title('Received Signal Scatter Plot'); axis('square');
%     xlabel('Real[x]'); ylabel('Imag[x]'); grid on;
%     subplot(2,2,4); plot(y(ntr-100:ntr),'.'); axis([-3 3 -3 3]);
%     title('Equalized Signal Scatter Plot'); axis('square');
%     xlabel('Real[y]'); ylabel('Imag[y]'); grid on;
%
%   % EXAMPLE #2: Use a frequency-domain adaptive filter to estimate the
%   % coefficients of a long FIR filter. The FIR filter models a room 
%   % impulse response. Use partitioned FDAF to reduce filter latency.
%
%     fs = 16e3;
%     M  = 8192; % Impulse response length
% 
%     [B,A] = cheby2(4,20,[0.1 0.7]);
%     impulseResponseGenerator = dsp.IIRFilter(...
%                                 'Numerator', [zeros(1,6) B], ...
%                                 'Denominator', A);
%     roomImpulseResponse = impulseResponseGenerator( ...
%     (log(0.99*rand(1,M)+0.01).*sign(randn(1,M)).*exp(-0.002*(1:M)))');
%     roomImpulseResponse = roomImpulseResponse/norm(roomImpulseResponse);
%     room = dsp.FIRFilter('Numerator', roomImpulseResponse');
% 
%     lmsfilt = dsp.FrequencyDomainAdaptiveFilter(...
%                          'Method','Partitioned constrained FDAF',...
%                          'Length', M/4, ...
%                          'BlockLength', 128,...
%                          'StepSize', 0.025, ...
%                          'InitialPower', 0.01, ...
%                          'AveragingFactor', 0.98,...
%                          'Offset',1,...
%                          'LeakageFactor',1);
% 
%     FrameSize = lmsfilt.BlockLength; NIter = 2000;
%  
%     AP = dsp.ArrayPlot('YLimits',[-0.1 .3],'ShowLegend',true, ...
%                      'Position',[0 0 560 420],'ChannelNames', ...
%                      {'Actual Coefficients', 'Estimated Coefficients'});
% 
%     TS = timescope('SampleRate',fs,...
%                    'TimeSpanSource','property',...
%                    'TimeSpan',FrameSize*NIter/fs,...
%                    'YLimits',[-50 0],'Title','Learning curve',...
%                    'YLabel','dB');
% 
%     signalmean = dsp.MovingAverage('SpecifyWindowLength',false);
% 
%     % Stream
%     for k = 1:NIter
%       x = randn(FrameSize,1);                 % input signal
%       d = room(x) + 0.01*randn(FrameSize,1);  % desired signal
%       [y,e] = lmsfilt(x,d);
%       % Transform the adapting FFT coefficients to the time-domain:
%       FFTCoeffs = lmsfilt.FFTCoefficients;
%       w    = ifft(FFTCoeffs, [] , 2, 'symmetric');
%       w    = w(:,1:FrameSize) + w(:,FrameSize+1:end);
%       w = reshape(w.',1, M/4);
%       AP([roomImpulseResponse(1:M/4),w.']); 
%       TS(10*log10(signalmean(abs(e).^2)));
%     end

%   See also dsp.LMSFilter, dsp.RLSFilter, dsp.AffineProjectionFilter,
%            dsp.AdaptiveLatticeFilter, dsp.FilteredXLMSFilter,
%            dsp.FIRFilter.

%   Copyright 1995-2023 The MathWorks, Inc.

%#codegen
    
    properties (Nontunable)
        %Method Method
        %   Specify the method used to calculate filter coefficients as one
        %   of ['Constrained FDAF' | 'Unconstrained FDAF' | 'Partitioned
        %   constrained FDAF' | 'Partitioned unconstrained FDAF']. The
        %   default is 'Constrained FDAF'.
        Method  (1, :) char {matlab.system.mustBeMemberMessageID(Method, ...
                    {'dsp:system:FrequencyDomainAdaptiveFilter:Method_Constrained',;...
                    'dsp:system:FrequencyDomainAdaptiveFilter:Method_PartitionedConstrained',;...
                    'dsp:system:FrequencyDomainAdaptiveFilter:Method_Unonstrained',;...
                    'dsp:system:FrequencyDomainAdaptiveFilter:Method_PartitionedUnconstrained'})} = 'Constrained FDAF';
    
        %Length Filter length
        %   Specify the length of the FIR filter coefficients vector as a
        %   positive integer value. The default value of this property is
        %   32.
        Length (1, 1) {mustBePositive, mustBeInteger} = 32;
    end
    
    properties (Nontunable, Dependent)
        %BlockLength Block length
        %   Specify the block length of the coefficients updates as a
        %   positive integer value. The length of the input vectors must be
        %   divisible by the BlockLength property value. The default value
        %   of the BlockLength property is set to the Length property
        %   value.
        BlockLength;
    end
    
    properties
        %StepSize Step size
        %   Specify the adaptation step size factor as a positive numeric
        %   scalar less than or equal to 1. Setting the StepSize property
        %   equal to one provides the fastest convergence during
        %   adaptation. The default value of this property is 1. This
        %   property is tunable.
        StepSize = 1;
        
        %LeakageFactor Leakage factor
        %   Specify the leakage factor used in leaky adaptive filter as a
        %   scalar numeric value between 0 and 1, both inclusive. When the
        %   value is less than 1, the System object implements a leaky
        %   adaptive algorithm. The default value of this property is 1,
        %   providing no leakage in the adapting method. This property is
        %   tunable.
        LeakageFactor = 1;
        
        %AveragingFactor Averaging factor
        %   Specify the averaging factor used to compute the exponentially
        %   windowed FFT input signal powers for the coefficient updates as
        %   a scalar positive numeric value less than or equal to 1. The
        %   default value of this property is 0.9. This property is
        %   tunable.
        AveragingFactor = 0.9;
        
        %Offset Offset
        %   Specify the offset for the normalization terms in the
        %   coefficient updates as a scalar non-negative numeric value.
        %   This property value is used to avoid divide by zeros or divide
        %   by very small numbers if any of the FFT input signal powers
        %   become very small. The default value of this property is 0.
        %   This property is tunable.
        Offset = 0;
        
        %InitialPower Initial FFT input signal power
        %   Specify the initial common value of all of the FFT input signal
        %   powers as a scalar positive numeric value. The default value of
        %   this property is 1. This property is tunable.
        InitialPower = 1;
        
        %InitialCoefficients Initial time-domain coefficients
        %   Specify the initial time-domain coefficients of the adaptive
        %   filter as a scalar or a vector of length equal to the Length
        %   property value. The adaptive filter object uses these
        %   coefficients to compute the initial frequency-domain filter
        %   coefficients. The default value of this property is 0. This
        %   property is tunable.
        InitialCoefficients = 0;
    
        %LockCoefficients Locked status of the coefficient updates
        %   Specify whether the filter coefficient values should be locked.
        %   By default, the value of this property is false, and the object
        %   continuously updates the filter coefficients. If this property
        %   is set to true, the filter coefficients do not get updated and
        %   their values remain at the current value. This property is
        %   tunable.
        LockCoefficients (1, 1) logical = false;
    end
    
    properties (DiscreteState)
        %Coefficients Current FFT coefficients of the filter
        %   This property stores the current discrete Fourier transform of
        %   the filter coefficients as a row vector. The length of this
        %   vector is equal to the sum of the Length property value and the
        %   BlockLength property value. This property is initialized to the
        %   FFT values of the InitialCoefficients property.
        FFTCoefficients;
        
        %States Current internal states of the filter
        %   This property stores the current internal states of the filter
        %   as a column vector. The length of this vector is equal to the
        %   Length property value. This property is initialized to a vector
        %   of zeros of appropriate length and data type.
        States;
        
        %Power Current FFT input signal power
        %   This property stores the current values of FFT input signal
        %   powers as a column vector. The length of this vector is equal
        %   to the sum of the Length property value and the BlockLength
        %   property value. This property is initialized to a vector of
        %   appropriate length and data type with each of the elements
        %   equal to the InitialPower property value.
        Power;
    end
    
    properties (Access=protected)
        %FilterParameters Private structure to store the filter parameters
        %   This is a private MATLAB structure that stores all the filter
        %   parameters casted to the data type of the inputs. For
        %   FrequencyDomainAdaptiveFilter System object, StepSize,
        %   LeakageFactor, AveragingFactor, Offset and InitialPower are the
        %   filter parameters. The FilterParameters property is initialized
        %   in setup method.
        FilterParameters;
        
        % pLastChunk Used in partitioned modes
        pLastChunk
    end
    
    properties (Access = protected, Nontunable)
        %privBlockLength A private property to store the value explicitly
        %   set to the BlockLength property.
        privBlockLength (1, 1) {mustBePositive, mustBeInteger} = 32;   % Assigned value needed for cloning
        
        % pMethod Cache method as an integer
        pMethod (1, 1) {mustBePositive, mustBeInteger} = 1
    
        %privBlockLengthDefined A Private logical property to denote
        %   whether the BlockLength property has been explicitly set.
        privBlockLengthDefined (1, 1) logical = false;
    
        %InputDataType Data type of the inputs
        %   This is a private property that stores the data type of the
        %   inputs and it is used to set the data type of all the
        %   DiscreteState properties and the outputs.
        InputDataType;                
    end
    
    methods
        % FrequencyDomainAdaptiveFilter Constructor
        function obj = FrequencyDomainAdaptiveFilter(varargin)
            % Support name-value pair arguments as well as alternatively
            % allow the Length property to be a value-only argument.
            setProperties(obj, nargin, varargin{:}, 'Length');
        end
        
        % Set method for the BlockLength dependent property. The value set
        % explicitly to the BlockLength dependent property is stored in the
        % privBlockLength property and the privBlockLengthDefined logical
        % property is set to true. Validation is taken care by the
        % PositiveInteger attribute of the privBlockLength property.
        function set.BlockLength(obj,val)
            obj.privBlockLength = val;
            obj.privBlockLengthDefined = true;
        end
        
        % Get method for the BlockLength dependent property. If the
        % BlockLength has not been explicitly set, this method returns the
        % Length property value as its default value.
        function val = get.BlockLength(obj)
            if obj.privBlockLengthDefined
                val = obj.privBlockLength;
            else
                val = obj.Length;
            end
        end
        
        % Validating and setting StepSize
        function set.StepSize(obj,val)
            coder.internal.errorIf(obj.checkVal(val), ...
                'dsp:system:AdaptiveFilter:mustBeRealScalar0to1LeftOpen', 'StepSize');
            obj.StepSize = val;
        end
        
        % Validating and setting LeakageFactor
        function set.LeakageFactor(obj,val)
            coder.internal.errorIf(~(isscalar(val) && val >= 0 && val <= 1 && isreal(val)), ...
                'dsp:system:AdaptiveFilter:mustBeRealScalar0to1Closed', 'LeakageFactor');
            obj.LeakageFactor = val;
        end
        
        % Validating and setting AveragingFactor
        function set.AveragingFactor(obj,val)
            coder.internal.errorIf(obj.checkVal(val), ...
                'dsp:system:AdaptiveFilter:mustBeRealScalar0to1LeftOpen', 'AveragingFactor');
            obj.AveragingFactor = val;
        end
        
        % Validating and setting Offset
        function set.Offset(obj,val)
            coder.internal.errorIf(~(isscalar(val) && isnumeric(val) && val >= 0 && isreal(val)), ...
                'dsp:system:AdaptiveFilter:mustBeNonNegativeRealScalar', 'Offset');
            obj.Offset = val;
        end
        
        % Validating and setting InitialPower
        function set.InitialPower(obj,val)
            coder.internal.errorIf(~(isscalar(val) && isnumeric(val) && val > 0 && isreal(val)), ...
                'dsp:system:AdaptiveFilter:mustBePositiveRealScalar', 'InitialPower');
            obj.InitialPower = val;
        end
        
        % Validating and setting InitialCoefficients
        function set.InitialCoefficients(obj,val)
            coder.internal.errorIf(~(isvector(val) && isnumeric(val) && all(isfinite(val))), ...
                'dsp:system:AdaptiveFilter:mustBeNumericVector', 'InitialCoefficients');
            obj.InitialCoefficients = val(:).';
        end
    end
    
    methods(Static, Access=protected)
        function group = getPropertyGroupsImpl
            % Get default parameters group for this System object
            group = matlab.system.display.Section('dsp.FrequencyDomainAdaptiveFilter', ...
                'DependOnPrivatePropertyList', {'BlockLength'});
        end
    end

    methods (Access=protected)
        
        function flag = isPartitioned(obj)
            flag = (strcmp(obj.Method,'Partitioned constrained FDAF') || ...
                   strcmp(obj.Method,'Partitioned unconstrained FDAF')) && ...
                   (obj.Length / obj.BlockLength > 1);
        end

        function validatePropertiesImpl(obj)
            % Validating the dimensions of the InitialCoefficients property
            coder.internal.errorIf(~(any(length(obj.InitialCoefficients)==[1,obj.Length])), ...
                'dsp:system:AdaptiveFilter:invalidVectorOfLengthL', 'InitialCoefficients');
            
            if isPartitioned(obj)
               coder.internal.errorIf( mod(obj.Length,obj.BlockLength)~=0, ...
                'dsp:system:FrequencyDomainAdaptiveFilter:invalidBlockLength');
            end
        end
        
        function validateInputsImpl(obj, x, d)
            % Validating the size of the inputs x and d. Inputs must be
            % vectors.
            coder.internal.errorIf(~isvector(x) || isempty(x), ...
                'MATLAB:system:inputMustBeVector','signal');
            
            coder.internal.errorIf(~isvector(d) || isempty(d), ...
                'MATLAB:system:inputMustBeVector','desired signal');
            
            % Inputs must be of same size
            coder.internal.errorIf(~all(size(x)==size(d)), ...
                'MATLAB:system:inputsNotSameSize');
            
            % Validating the length of the input vectors. The length of the
            % input vectors must be divisible by the BlockLength property
            % value.
            coder.internal.errorIf((mod(length(x),obj.BlockLength)~=0), ...
                'dsp:system:FrequencyDomainAdaptiveFilter:invalidInputVectorLength');
            
            % Validating the data type of the inputs x and d. x and d must
            % both be single or double.
            coder.internal.errorIf(~(isa(x,'float') && strcmp(class(x), ...
                class(d))), 'dsp:system:AdaptiveFilter:inputsNotFloatingPoint');
        end
        
        function setupImpl(obj, x, ~, varargin)
            % Set InputDataType to be the data type of x and initialize the
            % FilterParameters property based on that. The FilterParameters
            % property is a structure with all the filter parameters casted
            % to the data type of the inputs.
            inputDataTypeLocal = class(x);
            obj.InputDataType = inputDataTypeLocal;
            obj.FilterParameters = getFilterParameterStruct(obj);
            
            % Local copy of the required properties
            
            realInputX = isreal(x);
                 
            if ~isPartitioned(obj)
                L = obj.Length;
                LN = L + obj.BlockLength;
                % Initialize the FFTCoefficients property to a vector of zeros.
                obj.FFTCoefficients = complex(zeros(1,LN,inputDataTypeLocal));
            else
                LN = 2 * obj.BlockLength;
                % Initialize the FFTCoefficients property to a vector of zeros.
                obj.FFTCoefficients = complex(zeros(obj.Length / obj.BlockLength,LN,inputDataTypeLocal));
            end
            
            % Initialize the Power property to a vector of zeros.
            obj.Power = zeros(LN,1,inputDataTypeLocal);

            if ~isPartitioned(obj)
                % Initializing the States property to a vector of zeros.
                if realInputX
                    obj.States = zeros(L,1,inputDataTypeLocal);
                else
                    obj.States = complex(zeros(L,1,inputDataTypeLocal));
                end
            else
                obj.States    = complex(zeros(2 * obj.BlockLength,obj.Length / obj.BlockLength - 1,inputDataTypeLocal));
                if realInputX
                    obj.pLastChunk = zeros(2 * obj.BlockLength, 1 ,inputDataTypeLocal);
                else
                    obj.pLastChunk = complex(zeros(2 * obj.BlockLength, 1 ,inputDataTypeLocal));
                end
            end
            
            switch obj.Method
                case 'Constrained FDAF'
                    obj.pMethod = int8(1);
                case 'Partitioned constrained FDAF'
                    if isPartitioned(obj)
                      obj.pMethod = int8(3);  
                    else
                      obj.pMethod = int8(1);    
                    end
                case 'Unconstrained FDAF'
                    obj.pMethod = int8(2);
                case 'Partitioned unconstrained FDAF'
                    if isPartitioned(obj)
                      obj.pMethod = int8(4);  
                    else
                      obj.pMethod = int8(2);    
                    end
            end

        end
        
        function resetImpl(obj)
            % Local copy of the required properties
            inputDataTypeLocal = obj.InputDataType;
            L = obj.Length;

            % Initialize the Power property to the InitialPower property
            % value.
            obj.Power(:) = obj.InitialPower;
            
            % Initialize FFTCoefficients to the FFT of InitialCoefficients.
            % A very small floating-point value is added to the imaginary
            % part of the FFTCoefficients property so as to avoid it
            % turning into real.
            if isreal(obj.InitialCoefficients)
                initialCoefficientsProto = zeros(L,1,inputDataTypeLocal);
            else
                initialCoefficientsProto = complex(zeros(L,1,inputDataTypeLocal));
            end
            initialCoeffsLocal = dsp.internal.copyMatrix(obj.InitialCoefficients, ...
                initialCoefficientsProto);
            
            if ~isPartitioned(obj)
                N = obj.BlockLength;
                obj.FFTCoefficients = fft(initialCoeffsLocal,L+N).' ...
                    + 1i*eps(zeros(1,1,inputDataTypeLocal));
                % Initialize the States property to a vector of zeros.
                if isreal(obj.States)
                    obj.States = zeros(L,1,inputDataTypeLocal);
                else
                    % A very small floating-point value is added to the
                    % imaginary part of the States property so as to avoid it
                    % turning into real.
                    obj.States = complex(zeros(L,1,inputDataTypeLocal), ...
                        eps(zeros(L,1,inputDataTypeLocal)));
                end
            else
                LN = 2 * obj.BlockLength;
                PCoeffs = reshape(initialCoeffsLocal ,obj.BlockLength , obj.Length / obj.BlockLength );
                obj.FFTCoefficients = complex(zeros(obj.Length / obj.BlockLength,LN,inputDataTypeLocal));
                obj.FFTCoefficients(:) = fft(PCoeffs.',LN,2) + 1i*eps(zeros(1,1,inputDataTypeLocal));
                obj.States = complex(zeros(2 *  obj.BlockLength,obj.Length / obj.BlockLength - 1,inputDataTypeLocal),...
                    eps(zeros(2 * obj.BlockLength,obj.Length / obj.BlockLength - 1,inputDataTypeLocal)));
                obj.pLastChunk(:) = 0;
            end

        end

        function updateFilterParameters(obj)
            % If the tunable properties are changed, update the
            % FilterParameters private property that stores their
            % type-casted version in a structure.
            inputDataTypeLocal = obj.InputDataType;
            obj.FilterParameters.StepSize = ...
                cast(obj.StepSize, inputDataTypeLocal);
            obj.FilterParameters.LeakageFactor = ...
                cast(obj.LeakageFactor, inputDataTypeLocal);
            obj.FilterParameters.AveragingFactor = ...
                cast(obj.AveragingFactor, inputDataTypeLocal);
            obj.FilterParameters.Offset = ...
                cast(obj.Offset, inputDataTypeLocal);
            obj.FilterParameters.InitialPower = ...
                cast(obj.InitialPower, inputDataTypeLocal);
        end
        
        function processTunedPropertiesImpl(obj)
            updateFilterParameters(obj)
        end
        
        function [y,e] = stepImpl(obj, x, d, varargin)
            
             coeffsLocked = coefficientsLocked(obj,varargin{:});
             
            switch obj.pMethod
                case 1
                    [y,e] = stepCFDAF(obj, x, d , coeffsLocked);
                case 2
                    [y,e] = stepUFDAF(obj, x, d , coeffsLocked);
                case 3
                    [y,e] = stepPBCFDAF(obj, x, d , coeffsLocked);
                case 4
                    [y,e] = stepPBUCFDAF(obj, x, d , coeffsLocked);
            end
        end
        
        function coeffsLocked = coefficientsLocked(obj,varargin)
            coeffsLocked = obj.LockCoefficients;
        end
        
        %stepCFDAF A helper method to stepImpl that implements the core
        % algorithm of Constrained Frequency Domain Adaptive Filter.
        function [y,e] = stepCFDAF(obj, x, d , lockCoeffs)
            % Load the required properties
            [L,N,params,FFTW,normFFTX,X] = loadFDAFProperties(obj);
            
            % Initialize output and temporary local variables
            [yLocal,eLocal,ntrB,E,ZN] = initializeVariables(obj,size(x));
            
            % Cache the constant properties required in the main loop.
            mu = params.StepSize;           % Step size
            lam = params.LeakageFactor;     % Leakage factor
            beta = params.AveragingFactor;  % Averaging factor
            offset = params.Offset;         % Offset
            
            % Cache the index arrays required in the main loop.
            nnL = 1:L;
            nnLpN = N+1:N+L;
            nnNpL = L+1:L+N;
            
            % Main Loop
            for n=1:ntrB
                nn = ((n-1)*N+1):(n*N);     %  index for current signal blocks
                X(nnL) = X(nnLpN);          %  shift temporary input signal buffer up
                X(nnNpL) = x(nn);           %  assign current input signal vector
                
                FFTX = fft(X);              %  compute FFT of input signal vector

                Y = ifft(FFTW.*FFTX);
                yLocal(nn) = Y(nnNpL);      %  assign current output signal block
                eLocal(nn) = d(nn) - yLocal(nn);    %  assign current error signal block
                E(nnNpL) = mu*eLocal(nn);   %  assign current error signal vector
                FFTE = fft(E);   %  compute FFT of error signal vector
                
                % Update FFT input signal powers
                normFFTX = beta*normFFTX + (1-beta)*real(FFTX.*conj(FFTX));
                
                % Compute gradient vector                
                G = ifft(FFTE.*conj(FFTX)./(normFFTX + offset));
                G(nnNpL) = ZN;              %  impose gradient constraint
                
                % Update frequency domain coefficients
                if ~lockCoeffs                    
                    FFTW = lam*FFTW + fft(G);
                end
            end
            
            % Save States
            obj.FFTCoefficients = FFTW.';   % Save final frequency domain coefficients
            obj.Power = normFFTX;           % Save final FFT input signal powers
            obj.States = X(L+N:-1:N+1);     % Save final filter internal states
            
            % If the input and desired signals are real-valued, make sure
            % that the output and error signals are also real-valued.
            if isreal(x) && isreal(d)
                y = real(yLocal);
                e = real(eLocal);
            else
                y = yLocal;
                e = eLocal;
            end
        end
        
        %stepPBCFDAF A helper method to stepImpl that implements the core
        % algorithm of Constrained Partitioned Frequency Domain Adaptive
        % Filter.
        function [y,e] = stepPBCFDAF(obj, x, d, lockCoeffs)
            
            % Load the required properties
            [N,TN,params,FFTW,normFFTX] = loadPBFDAFProperties(obj);
            
            % Initialize output and temporary local variables
            [yLocal,eLocal,ntrB,E] = initializePartitionVariables(obj,size(x));
            
            % Cache the constant properties required in the main loop.
            mu = params.StepSize;           % Step size
            lam = params.LeakageFactor;     % Leakage factor
            beta = params.AveragingFactor;  % Averaging factor
            ombetta = 1 - beta;
            offset = params.Offset;         % Offset
            
            % Cache the index arrays required in the main loop.
            M = obj.Length / obj.BlockLength;
            nnM = 1:M-1;                %  index variable used for FFT input signal buffer
            nnMp1 = nnM + 1;            %  index variable used for FFT input signal buffer
            nnN = 1:N;                  %  index variable used for input signal buffer
            nnNpN = N+1:TN;             %  index variable used for input signal buffer
            
            ZNM = zeros(N,M);           %  assign (N x M) zero matrix-dimensional zero vector
            OMt = ones(1,M);            %  assign M-dimensional zero vector

            isOutReal = isreal(x) && isreal(d);
            
            FFTX = complex(zeros(2 * obj.BlockLength, M,obj.InputDataType)); 
            FFTX(:,nnM) = obj.States;
            
            X = obj.pLastChunk;

            % Main Loop
            for n=1:ntrB
                nn = ((n-1)*N+1):(n*N); %  index for current signal blocks
                FFTX(:,nnMp1) = FFTX(:,nnM);  %  shift temporary FFT input signal buffers over
                X(nnN) = X(nnNpN);      %  shift temporary input signal buffer up
                X(nnNpN) = x(nn);       %  assign current input signal block
                FFTX(:,1) = fft(X);     %  compute FFT of input signal vector
                Y = ifft(sum(FFTW.*FFTX,2));  %  compute current output signal vector
                yLocal(nn) = Y(nnNpN);       %  assign current output signal block
                %[o,prevsec,sumY,p] = dsp.internal.PartitionOS.computeOutput(x(nn),sumY,1,obj.PartitionLength,1,1,FFTW,2*obj.PartitionLength,obj.Length/obj.PartitionLength,obj.PartitionLength,prevsec,p);
                eLocal(nn) = d(nn) - yLocal(nn);  %  assign current error signal block
                E(nnNpN) = mu*eLocal(nn);        %  assign current error signal vector
                normFFTX = beta*normFFTX + ombetta*real(FFTX(:,1).*conj(FFTX(:,1)));
                %  update FFT input signal powers
                FFTEinvnormFFTX = (fft(E)./(normFFTX + offset))*OMt;
                %  compute power-normalized FFT of error signal matrix
                G = ifft(FFTEinvnormFFTX.*conj(FFTX));
                %  compute gradient matrix
                G(nnNpN,:) = ZNM;       %  impose gradient constraint
                if ~lockCoeffs
                    FFTW = lam*FFTW + fft(G);  %  update frequency domain coefficient matrix
                end
            end
            
            % Save States
            obj.FFTCoefficients = FFTW.';   % Save final frequency domain coefficients
            obj.Power = normFFTX;           % Save final FFT input signal powers
            obj.States = FFTX(:,nnM);       % save final FFT input signal States
            obj.pLastChunk = X;
            
            % If the input and desired signals are real-valued, make sure
            % that the output and error signals are also real-valued.
            if isOutReal
                y = real(yLocal);
                e = real(eLocal);
            else
                y = yLocal;
                e = eLocal;
            end
        end
        
       %stepPBUCFDAF A helper method to stepImpl that implements the core
        % algorithm of Unconstrained Partitioned Frequency Domain Adaptive
        % Filter.
        function [y,e] = stepPBUCFDAF(obj, x, d,lockCoeffs)
            % Load the required properties
            [N,TN,params,FFTW,normFFTX] = loadPBFDAFProperties(obj);
            
            % Initialize output and temporary local variables
            [yLocal,eLocal,ntrB,E] = initializePartitionVariables(obj,size(x));
            
            % Cache the constant properties required in the main loop.
            mu = params.StepSize;           % Step size
            lam = params.LeakageFactor;     % Leakage factor
            beta = params.AveragingFactor;  % Averaging factor
            ombetta = 1 - beta;
            offset = params.Offset;         % Offset
            
            % Cache the index arrays required in the main loop.
            M = obj.Length / obj.BlockLength;
            nnM = 1:M-1;                %  index variable used for FFT input signal buffer
            nnMp1 = nnM + 1;            %  index variable used for FFT input signal buffer
            nnN = 1:N;                  %  index variable used for input signal buffer
            nnNpN = N+1:TN;             %  index variable used for input signal buffer
            
            OMt = ones(1,M);            %  assign M-dimensional zero vector
            
            isOutReal = isreal(x) && isreal(d);
            
            FFTX = complex(zeros(2 * obj.BlockLength, M,obj.InputDataType));
            FFTX(:,nnM) = obj.States;

             X = obj.pLastChunk;
            
            % Main Loop
            for n=1:ntrB
                nn = ((n-1)*N+1):(n*N); %  index for current signal blocks
                FFTX(:,nnMp1) = FFTX(:,nnM);  %  shift temporary FFT input signal buffers over
                X(nnN) = X(nnNpN);      %  shift temporary input signal buffer up
                X(nnNpN) = x(nn);       %  assign current input signal block
                FFTX(:,1) = fft(X);     %  compute FFT of input signal vector
                Y = ifft(sum(FFTW.*FFTX,2));  %  compute current output signal vector
                yLocal(nn) = Y(nnNpN);       %  assign current output signal block
                eLocal(nn) = d(nn) - yLocal(nn);  %  assign current error signal block
                E(nnNpN) = mu*eLocal(nn);        %  assign current error signal vector
                normFFTX = beta*normFFTX + ombetta*real(FFTX(:,1).*conj(FFTX(:,1)));
                %  update FFT input signal powers
                FFTEinvnormFFTX = (fft(E)./(normFFTX + offset))*OMt;
                %  compute power-normalized FFT of error signal matrix 
                if ~lockCoeffs
                    FFTW = lam*FFTW + FFTEinvnormFFTX.*conj(FFTX);  
                end
            end

            % Save States
            obj.FFTCoefficients = FFTW.';   % Save final frequency domain coefficients
            obj.Power = normFFTX;           % Save final FFT input signal powers
            obj.States = FFTX(:,nnM);       %  save final FFT input signal States
            obj.pLastChunk = X;
            % If the input and desired signals are real-valued, make sure
            % that the output and error signals are also real-valued.
            if isOutReal
                y = real(yLocal);
                e = real(eLocal);
            else
                y = yLocal;
                e = eLocal;
            end
        end

        %stepUFDAF A helper method to stepImpl that implements the core
        % algorithm of Unconstrained Frequency Domain Adaptive Filter.
        function [y,e] = stepUFDAF(obj, x, d , lockCoeffs)
            % Load the required properties
            [L,N,params,FFTW,normFFTX,X] = loadFDAFProperties(obj);
            
            % Initialize output and temporary local variables
            [yLocal,eLocal,ntrB,E] = initializeVariables(obj,size(x));
            
            % Cache the constant properties required in the main loop.
            mu = params.StepSize;           % Step size
            lam = params.LeakageFactor;     % Leakage factor
            beta = params.AveragingFactor;  % Averaging factor
            offset = params.Offset;         % Offset
            
            % Cache the index arrays required in the main loop.
            nnL = 1:L;
            nnLpN = N+1:N+L;
            nnNpL = L+1:L+N;
             
            % Main Loop
            for n=1:ntrB
                nn = ((n-1)*N+1):(n*N);     %  index for current signal blocks
                X(nnL) = X(nnLpN);          %  shift temporary input signal buffer up
                X(nnNpL) = x(nn);           %  assign current input signal vector
                 
                FFTX = fft(X);              %  compute FFT of input signal vector
                
                Y = ifft(FFTW.*FFTX);
                yLocal(nn) = Y(nnNpL);      %  assign current output signal block
                
                eLocal(nn) = d(nn) - yLocal(nn);    %  assign current error signal block
                E(nnNpL) = mu*eLocal(nn);   %  assign current error signal vector
                
                FFTE = fft(E);              %  compute FFT of error signal vector
                
                % Update FFT input signal powers
                normFFTX = beta*normFFTX + (1-beta)*real(FFTX.*conj(FFTX));
                
                % Update frequency domain coefficients
                if ~lockCoeffs
                    FFTW = lam*FFTW + (FFTE.*conj(FFTX)./(normFFTX + offset));
                end
            end
            
            % Save States
            obj.FFTCoefficients = FFTW.';   % Save final frequency domain coefficients
            obj.Power = normFFTX;           % Save final FFT input signal powers
            obj.States = X(L+N:-1:N+1);     % Save final filter internal states
            
            % If the input and desired signals are real-valued, make sure
            % that the output and error signals are also real-valued.
            if isreal(x) && isreal(d)
                y = real(yLocal);
                e = real(eLocal);
            else
                y = yLocal;
                e = eLocal;
            end
        end
        
        %getFilterParameterStruct This is a helper method that creates and
        % returns the filter parameters structure. Each of the filter
        % parameters are casted to the InputDataType property value.
        function filterParams = getFilterParameterStruct(obj)
            inputDataTypeLocal = obj.InputDataType;
            filterParams = struct('StepSize', cast(obj.StepSize,inputDataTypeLocal), ...
                'LeakageFactor', cast(obj.LeakageFactor, inputDataTypeLocal), ...
                'AveragingFactor', cast(obj.AveragingFactor, inputDataTypeLocal), ...
                'Offset', cast(obj.Offset, inputDataTypeLocal), ...
                'InitialPower', cast(obj.InitialPower, inputDataTypeLocal));
        end
        
        %initializeVariables This is a helper method to the stepImpl
        % method. This method is used to initialize output variables and
        % temporary variables required in the main loop of the stepImpl
        % method.
        function [y,e,ntrB,E,ZN] = initializeVariables(obj,Sx)
            % Load the required constant properties
            L = obj.Length;                 % Number of coefficients
            N = obj.BlockLength;            % Block length
            inputDataTypeLocal = obj.InputDataType;
            
            % Temporary number of iterations
            ntrB = cast(max(Sx)/obj.BlockLength, inputDataTypeLocal);
            
            % Initialize output and error signal vector
            y = complex(zeros(Sx,inputDataTypeLocal),eps(zeros(Sx,inputDataTypeLocal)));
            e = y;
            
            % Temporary error signal buffer
            E = complex(zeros(L+N,1,inputDataTypeLocal),eps(zeros(L+N,1,inputDataTypeLocal)));
            
            % N-dimensional zero vector
            ZN = zeros(N,1,inputDataTypeLocal);
        end
        
        function [y,e,ntrB,E] = initializePartitionVariables(obj,Sx)
            % Load the required constant properties
            N = obj.BlockLength;        % Partition length
            inputDataTypeLocal = obj.InputDataType;
            
            % Temporary number of iterations
            ntrB = cast(max(Sx)/N, inputDataTypeLocal);
            
            % Initialize output and error signal vector
            y = complex(zeros(Sx,inputDataTypeLocal),eps(zeros(Sx,inputDataTypeLocal)));
            e = y;
            
            % Temporary error signal buffer
            TN = 2 * obj.BlockLength;
            E = complex(zeros(TN,1,inputDataTypeLocal));

        end
        
        %loadCommonDiscreteStates This helper method returns all the
        % properties of the filter object required in the step method.
        function [L,N,params,FFTW,normFFTX,X] = loadFDAFProperties(obj)
            % Load the required constant properties
            L = obj.Length;                 % Number of coefficients
            N = obj.BlockLength;            % Block length
            params = obj.FilterParameters;  % Filter parameters structure
            
            % Load the required DiscreteState properties
            FFTW = obj.FFTCoefficients.';   %  initialize and assign alternative coefficient vector
            normFFTX = obj.Power;           %  initialize and assign FFT input signal powers
            if isreal(obj.States)        % initialize temporary input signal buffer
                X = zeros(L+N,1,obj.InputDataType);
            else
                X = complex(zeros(L+N,1,obj.InputDataType));
            end
            X(L+N:-1:N+1) = obj.States;  %  assign input signal buffer
        end
        
        function [N,TN,params,FFTW,normFFTX] = loadPBFDAFProperties(obj)
            % Load the required constant properties
            N = obj.BlockLength;        % Block length
            TN = 2 * obj.BlockLength; 
            params = obj.FilterParameters;  % Filter parameters structure
            
            % Load the required DiscreteState properties
            FFTW = obj.FFTCoefficients.';   %  initialize and assign alternative coefficient vector
            normFFTX = obj.Power;           %  initialize and assign FFT input signal powers
        end
        
        function N = getNumInputsImpl(~)
            % Specify number of System inputs
            N = 2;
        end
        
        function N = getNumOutputsImpl(~)
            % Specify number of System outputs
            N = 2;
        end
        
        
        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end

        %saveObjectImpl This overloaded method is used to save all the
        % active properties of the object, including the required private
        % and protected ones, when the object is saved.
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            
            % Save the private properties
            s.privBlockLength = obj.privBlockLength;
            s.privBlockLengthDefined = obj.privBlockLengthDefined;
                        
            % Save the InputDataType property if the object is locked.
            if isLocked(obj)
                s.InputDataType = obj.InputDataType;
                s.pLastChunk    = obj.pLastChunk;
                s.pMethod       = obj.pMethod;
            end
        end
        
        %loadObjectImpl This overloaded method is used to load all the
        % active properties of the object, including the private and
        % protected ones, when the object is loaded.
        function loadObjectImpl(obj, s, wasLocked)
            loadObjectImpl@matlab.System(obj, s, wasLocked);
            
            % Load the private properties
            obj.privBlockLength = s.privBlockLength;
            obj.privBlockLengthDefined = s.privBlockLengthDefined;
                        
            % Load the InputDataType property and the FilterParameters
            % property if the object was locked.
            if wasLocked
                obj.InputDataType = s.InputDataType;
                obj.FilterParameters = getFilterParameterStruct(obj);
                if isfield(s,'pLastChunk')
                    obj.pLastChunk    = s.pLastChunk;
                    obj.pMethod       = s.pMethod;
                end
            end
        end
    end
    
    methods (Static, Hidden)
        function flag = checkVal(val)
            flag = ~(isscalar(val) && val > 0 && val <= 1 && isreal(val));
        end 
    end
end
