classdef ParallelFilter < dsp.internal.FilterStructure
%ParallelFilter A parallel sum filter structure.
%   This System object filters its input through several filter branches, 
%   and sum the resulting branch outputs. The parallel filter object can
%   be used for simulation and analysis.
%
%   PF = dsp.ParallelFilter returns a System object, PF, that has a single
%   branch of dsp.FIRFilter.
%
%   PF = dsp.ParallelFilter(FILTER1, FILTER2, ...) returns a parallel stack 
%   System object, PF, with first branch set to FILTER1, second branch set 
%   to FILTER2, and so on.
%
%   PF = dsp.ParallelFilter(..., CloneBranches=val) sets the CloneBranches
%   property to val, which can be true or false.
%
%   Step method syntax:
%
%   Y = PF(X) runs the input X through the parallel filter PF, and
%   returns the filtered output Y.
%
%   ParallelFilter methods:
%
%   step                  - See above description for use of this method
%   release               - Allow property value and input characteristics
%                           to change
%   clone                 - Create dsp.ParallelFilter object with same
%                           property values
%   isLocked              - Locked status (logical)
%   reset                 - Reset the internal states of all branches to
%                           initial conditions
%   addBranch             - Add a new filter branch to the parallel filter
%   removeBranch          - Remove a branch from the parallel filter
%   releaseBranches       - Release the locked state of all branches in the
%                           parallel filter
%   getNumBranches        - Get the number of branches in the parallel 
%                           filter object
%   generateFilteringCode - Generate equivalent MATLAB code that performs 
%                           the filtering operation of the parallel filter
%
%   ParallelFilter properties:
%
%   CloneBranches - Control branch cloning
%   Branch1      - First branch of the parallel filter
%
%   You can grow the number of branches by using the addBranch method of
%   dsp.ParallelFilter. For a list of System objects that can be used as
%   branches of the parallel filter, type
%   dsp.ParallelFilter.helpSupportedSystemObjects
%
%   This System object supports several filter analysis methods. For more
%   information, type dsp.ParallelFilter.helpFilterAnalysis.
%
%   % EXAMPLE 1: Construct a parallel filter in three ways
%   % First, create the branches
%   B1 = dsp.FIRFilter;
%   B2 = dsp.Delay(3);
%
%   % Option 1: Specify branches while constructing the dsp.ParallelFilter 
%   % object
%   pf1 = dsp.ParallelFilter(B1, B2);
%
%   % Option 2: Use the parallel filter function
%   pf2 = parallel(B1, B2);
%
%   % Option 3: Use the addBranch function to add the branches.
%   pf3 = dsp.ParallelFilter(B1);
%   addBranch(pf3, B2);
%
%   % EXAMPLE 2: Construct a polyphase FIR decimator using the parallel() 
%   % function. Visualize its frequency response using fvtool. Pass a
%   % random input through the decimator.
%
%   % Construction
%   M = 3;
%   coeffs = designMultirateFIR(1, M);
%   
%   branches = cell(1,M);
%   for phase=1:M
%       downsample = dsp.FIRDecimator(M,1); % Trivial downsample
%       phaseDelay = dsp.Delay(phase-1);
%       phaseFIR = dsp.FIRFilter(coeffs(phase:3:end));
%       branches{phase} = cascade(phaseDelay, downsample, phaseFIR);
%   end
%   
%   PFdecim = parallel(branches{:});
%   fvtool(PFdecim)
%   
%   % Simulation with random input
%   x = randn(1200,2);
%   for idx = 1:100
%       y = PFdecim(x);
%   end
%
%   % EXAMPLE 3: Branch cloning v.s. branch referencing
%   B1 = dsp.FIRInterpolator(13);
%   B2 = dsp.FIRDecimator(17);
%   pf_clone = dsp.ParallelFilter(B1, B2)
%   pf_ref = dsp.ParallelFilter(B1, B2, CloneBranches = false)
%
%   % Change a property in the user-provided branch
%   B1.InterpolationFactor = 19
%
%   % Check if the change in the interpolation factor of B1 has affected
%   % the interpolation factor of Branch1 stored in the parallel filter
%   pf_clone.Branch1.InterpolationFactor   % no sync (clone)
%   pf_ref.Branch1.InterpolationFactor     % sync (reference)
%
%   See also parallel, dsp.FilterCascade

%   Copyright 2022-2023 The MathWorks, Inc.

properties (Nontunable)
    %Branch1 First branch of parallel filter
    %   Specify the first branch of the parallel filter, as a filter
    %   System object. The default value of this property is
    %   dsp.FIRFilter.
    Branch1;
    %Branch2 Second branch of parallel filter
    Branch2 = 0;
    %Branch3 Third branch of parallel filter
    Branch3 = 0;
    %Branch4 Fourth branch of parallel filter
    Branch4 = 0;
    %Branch5 Fifth branch of parallel filter
    Branch5 = 0;
    %Branch6 Sixth branch of parallel filter
    Branch6 = 0;
    %Branch7 Seventh branch of parallel filter
    Branch7 = 0;
    %Branch8 Eighth branch of parallel filter
    Branch8 = 0;
    %Branch9 Nine branch of parallel filter
    Branch9 = 0;
    %Branch10 Tenth branch of parallel filter
    Branch10 = 0;
    %Branch11 Eleventh branch of parallel filter
    Branch11 = 0;
    %Branch12 Twelfth branch of parallel filter
    Branch12 = 0;
    %Branch13 Thirteenth branch of parallel filter
    Branch13 = 0;
    %Branch14 Fourteenth branch of parallel filter
    Branch14 = 0;
    %Branch15 Fifteenth branch of parallel filter
    Branch15 = 0;
    %Branch16 Sixeenth branch of parallel filter
    Branch16 = 0;
    %Branch17 Seventeenth branch of parallel filter
    Branch17 = 0;
    %Branch18 Eighteenth branch of parallel filter
    Branch18 = 0;
    %Branch19 Nineteenth branch of parallel filter
    Branch19 = 0;
    %Branch20 Twentieth branch of parallel filter
    Branch20 = 0;
    %Branch21 Twenty first branch of parallel filter
    Branch21 = 0;
    %Branch22 Twenty second branch of parallel filter
    Branch22 = 0;
    %Branch23 Twenty thid branch of parallel filter
    Branch23 = 0;
    %Branch24 Twenty fourth branch of parallel filter
    Branch24 = 0;
end

properties (Access=protected, Nontunable)
    pNumBranches = 1;
end

properties(Nontunable, SetAccess = protected)
    %CloneBranches Control branch cloning
    %
    % If CloneBranches is false, the parallel filter branches assigned to the
    % ParallelFilter object occupy the same memory as the branches provided by
    % the user. You can add branches while creating the ParallelFilter object,
    % by direct assignment, or by using the addBranch method.
    %
    % If CloneBranches is set to true, the branches stored in the ParallelFilter
    % object are mere clones of the branches provided by the user, and do not
    % occupy the same memory.
    %
    % The default is true. This parameter can be set on construction only.
    CloneBranches (1, 1) logical = true;
end

properties(Constant, Access = private)
    MaxNumBranches = 24;
end

properties (Constant, Hidden)
   ChildLabel = 'Branch';
end

%----------------------------------------------------------------------
% Public methods
%----------------------------------------------------------------------
methods
    function set.Branch1(obj, val)
        obj.Branch1 = checkFilterAndClearMetadata(obj, val, obj.Branch1);
    end
    %------------------------------------------------------------------
    function set.Branch2(obj, val)
        obj.Branch2 = checkFilterAndClearMetadata(obj,val, obj.Branch2);
    end
    %------------------------------------------------------------------
    function set.Branch3(obj, val)
        obj.Branch3 = checkFilterAndClearMetadata(obj,val, obj.Branch3);
    end
    %------------------------------------------------------------------
    function set.Branch4(obj, val)
        obj.Branch4 = checkFilterAndClearMetadata(obj,val, obj.Branch4);
    end
    %------------------------------------------------------------------
    function set.Branch5(obj, val)
        obj.Branch5 = checkFilterAndClearMetadata(obj,val, obj.Branch5);
    end
    %------------------------------------------------------------------
    function set.Branch6(obj, val)
        obj.Branch6 = checkFilterAndClearMetadata(obj,val, obj.Branch6);
    end
    %------------------------------------------------------------------
    function set.Branch7(obj, val)
        obj.Branch7 = checkFilterAndClearMetadata(obj,val, obj.Branch7);
    end
    %------------------------------------------------------------------
    function set.Branch8(obj, val)
        obj.Branch8 = checkFilterAndClearMetadata(obj,val, obj.Branch8);
    end
    %------------------------------------------------------------------
    function set.Branch9(obj, val)
        obj.Branch9 = checkFilterAndClearMetadata(obj,val, obj.Branch9);
    end
    %------------------------------------------------------------------
    function set.Branch10(obj, val)
        obj.Branch10 = checkFilterAndClearMetadata(obj,val, obj.Branch10);
    end
    %------------------------------------------------------------------
    function set.Branch11(obj, val)
        obj.Branch11 = checkFilterAndClearMetadata(obj,val, obj.Branch11);
    end
    %------------------------------------------------------------------
    function set.Branch12(obj, val)
        obj.Branch12 = checkFilterAndClearMetadata(obj,val, obj.Branch12);
    end
    %------------------------------------------------------------------
    function set.Branch13(obj, val)
        obj.Branch13 = checkFilterAndClearMetadata(obj,val, obj.Branch13);
    end
    %------------------------------------------------------------------
    function set.Branch14(obj, val)
        obj.Branch14 = checkFilterAndClearMetadata(obj,val, obj.Branch14);
    end
    %------------------------------------------------------------------
    function set.Branch15(obj, val)
        obj.Branch15 = checkFilterAndClearMetadata(obj,val, obj.Branch15);
    end
    %------------------------------------------------------------------
    function set.Branch16(obj, val)
        obj.Branch16 = checkFilterAndClearMetadata(obj,val, obj.Branch16);
    end
    %------------------------------------------------------------------
    function set.Branch17(obj, val)
        obj.Branch17 = checkFilterAndClearMetadata(obj,val, obj.Branch17);
    end
    %------------------------------------------------------------------
    function set.Branch18(obj, val)
        obj.Branch18 = checkFilterAndClearMetadata(obj,val, obj.Branch18);
    end
    %------------------------------------------------------------------
    function set.Branch19(obj, val)
        obj.Branch19 = checkFilterAndClearMetadata(obj,val, obj.Branch19);
    end
    %------------------------------------------------------------------
    function set.Branch20(obj, val)
        obj.Branch20 = checkFilterAndClearMetadata(obj,val, obj.Branch20);
    end
    %------------------------------------------------------------------
    function set.Branch21(obj, val)
        obj.Branch21 = checkFilterAndClearMetadata(obj,val, obj.Branch21);
    end
    %------------------------------------------------------------------
    function set.Branch22(obj, val)
        obj.Branch22 = checkFilterAndClearMetadata(obj,val, obj.Branch22);
    end
    %------------------------------------------------------------------
    function set.Branch23(obj, val)
        obj.Branch23 = checkFilterAndClearMetadata(obj,val, obj.Branch23);
    end
    %------------------------------------------------------------------
    function set.Branch24(obj, val)
        obj.Branch24 = checkFilterAndClearMetadata(obj,val, obj.Branch24);
    end

    %------------------------------------------------------------------
    function obj = ParallelFilter(varargin)
        % Constructor
        if isempty(varargin)
            obj.Branch1 = dsp.FIRFilter;
        else
            % Process constructor with branches and optional arguments
            % dsp.ParallelFilter(branch1,branch2,...,branchN,[CloneBranches=val])
            [varargin{:}] = convertStringsToChars(varargin{:});

            % Check if 'CloneBranches' has been specified
            csidx = find(strcmp(varargin,'CloneBranches'),1,'first');
            if ~isempty(csidx)
                % Make sure value is given
                coder.internal.errorIf(csidx+1>numel(varargin),'MATLAB:system:invalidPVPairs')

                % Assign CloneBranches value
                obj.CloneBranches = varargin{csidx+1};
                validateattributes(obj.CloneBranches, {'logical'},{'scalar','binary'}, '','CloneBranches');

                % Omit the P-V pair
                branches = [varargin(1:csidx-1) varargin(csidx+2:end)];

                % Process dsp.ParallelFilter(CloneBranches=val) with no branches
                if numel(branches)==0
                    branches = {dsp.FIRFilter};
                end

                obj.setBranches(branches);
            else
                obj.setBranches(varargin);
            end
        end
    end
    %------------------------------------------------------------------
    function addBranch(obj, branch, varargin)
    %ADDBRANCH Add a branch to parallel filter
    %
    %   addBranch(PF, FILTER) adds FILTER as a branch at the end of the 
    %   parallel stack PF.
    %
    %   addBranch(PF, FILTER, IDX) adds the filter defined in FILTER at 
    %   branch position IDX of the parallel filter in PF. All existing 
    %   branches from IDX to end of the parallel filter are shifted down 
    %   further down the stack.
    %
    %   % Example 1: Add a branch at the end of the parallel filter
    %   pf = dsp.ParallelFilter;
    %   addBranch(pf, dsp.IIRFilter);
    %
    %   % Example 2: Add a filter at the second branch of the filter
    %   % parallel filter consisting of three filters
    %   pf = parallel(dsp.CICDecimator, dsp.FIRDecimator);
    %   addBranch(pf, dsp.FarrowRateConverter(48,24), 2);

        narginchk(2,3);

        coder.internal.errorIf(isLocked(obj),'dsp:system:ParallelFilter:addRemoveOnLocked', 'add');
        coder.internal.errorIf(obj.pNumBranches == obj.MaxNumBranches,'dsp:system:ParallelFilter:maximumBranches',obj.MaxNumBranches);

        %branch = checkFilterAndClearMetadata(obj, branch);
        if ~isempty(varargin)
            addBranchNum = varargin{1};
            validateattributes(addBranchNum, {'numeric'}, ...
                {'positive', 'integer', 'scalar', 'finite', ...
                '<=', obj.pNumBranches+1}, ...
                'addBranch', 'branch position');
        end

        obj.pNumBranches = obj.pNumBranches+1;
        currentBranch = sprintf('Branch%d',obj.pNumBranches);
        if isempty(varargin)
            obj.(currentBranch)=branch;
        else
            % shift branches to the right
            for idx = obj.pNumBranches:-1:addBranchNum+1
                rightBranch = sprintf('Branch%d',idx);
                leftBranch = sprintf('Branch%d',idx-1);
                obj.(rightBranch) = obj.(leftBranch);
            end
            obj.(sprintf('Branch%d',addBranchNum)) = branch;
        end
    end
    %------------------------------------------------------------------
    function removeBranch(obj, varargin)
    %removeBranch Remove a branch from parallel filter
    %
    %   removeBranch(PF) removes a branch from the end of the parallel
    %   filter in PF.
    %
    %   removeBranch(PF, IDX) removes the branch from the branch position 
    %   IDX of the parallel filter in PF. All existing filters from IDX to 
    %   end of the parallel filter are shifted up the stack.
    %
    %   % Example 1: Remove a branch from the end of the parallel filter
    %   PF = dsp.ParallelFilter(dsp.FIRFilter, dsp.IIRFilter);
    %   removeBranch(PF);
    %
    %   % Example 2: Remove a filter from the third branch of a parallel filter
    %   % consisting of four branches
    %   PF = parallel(dsp.FIRFilter, dsp.Delay, dsp.IIRFilter, dsp.Delay);
    %   removeBranch(PF, 3);

        narginchk(1,2);

        if isLocked(obj)
            error(message('dsp:system:ParallelFilter:addRemoveOnLocked', 'remove'));
        end

        if obj.pNumBranches == 1
            error(message('dsp:system:ParallelFilter:minimumBranches'));
        end

        if ~isempty(varargin)
            remBranchNum = varargin{1};
            validateattributes(remBranchNum, {'numeric'}, ...
                {'positive', 'integer', 'scalar', 'finite', ...
                '<=', obj.pNumBranches}, ...
                'removeBranch', 'branch position');

            % move branches up
            for idx = remBranchNum:obj.pNumBranches-1
                leftBranch = sprintf('Branch%d',idx);
                rightBranch = sprintf('Branch%d',idx+1);
                tmp =  obj.(rightBranch);
                obj.(rightBranch) = 0; % remove reference (prevent double reference error)
                obj.(leftBranch) = tmp;
            end
        end

        discardedBranch = sprintf('Branch%d',obj.pNumBranches);
        obj.(discardedBranch) = 1;

        obj.pNumBranches = obj.pNumBranches-1;
        clearMetaData(obj);
    end
    %------------------------------------------------------------------
    function n = getNumBranches(obj)
    %GETNUMBRANCHES Number of filters in parallel filter
    %
    %   N = getNumBranches(PF) returns the number of branches in the 
    %           parallel filter object, PF.
    %   
    %
    %   % Example:
    %   PF = parallel(dsp.FIRFilter, dsp.IIRFilter);
    %   N = getNumBranches(PF);    % This will return 2
        n = obj.pNumBranches;
    end
    %------------------------------------------------------------------
    function generateFilteringCode(obj, functionName)
    %GENERATEFILTERINGCODE Generate MATLAB code to filter using a parallel
    %   structure
    %
    %   generateFilteringCode(PF) creates a new file in the editor that
    %   contains code to create the branches of the parallel filter and 
    %   process the input data through the branches.
    %
    %   generateFilteringCode(PF, FNAME) generates the code and saves
    %   it to the file specified in the string FNAME. If a file named FNAME
    %   already exists, its content is replaced.
    %
    %   % Example:
    %   PF = parallel(dsp.FIRFilter(Numerator = ones(1,5)), dsp.SOSFilter);
    %   fName = 'filterScript.m';  % The code will be saved in this
    %                               % file in the current directory
    %   generateFilteringCode(PF, fName);
    
        arguments
            obj;
            functionName (1,:) char = 'parallelFilter';
        end

        % If a customer name is specified, write to a file
        WriteFile = (nargin>1); 
        generateFilterCodeImpl(obj, functionName, WriteFile);
    end
    %------------------------------------------------------------------
    function flag = isequal(obj, obj2)
    %ISEQUAL Determine if two ParallelFilter objects are equal.
    %
    %   isequal(PF1, PF2) returns logical 1 (TRUE) if all branches of PF1
    %   are exactly the same in value as those of PF2.
    %
    %   % Example:
    %   PF1 = dsp.ParallelFilter(dsp.FIRDecimator, ...
    %                           dsp.FIRFilter(Numerator=ones(1,5)));
    %   PF2 = dsp.ParallelFilter(dsp.FIRDecimator, dsp.FIRFilter);
    %                           
    %   isequal(PF1, PF2);  % This will return false because Branch2 of
    %                       % both objects is not same
    %   PF3 = dsp.ParallelFilter(dsp.FIRDecimator, ...
    %                            dsp.FIRFilter(Numerator=ones(1,5)));
    %   isequal(PF1, PF3);  % This will return true
        flag = isequal@dsp.internal.FilterStructure(obj,obj2);
    end

    %------------------------------------------------------------------
    function releaseBranches(obj)
    %releaseBranches Release the locked state of all branches
    %
    %   releaseBranches(PF) calls RELEASE method on all branches of the
    %   parallel filter PF.
    %
    %   Use this function to ensure branches are released, even if the
    %   containing dsp.ParallelFilter object is not locked (in which case
    %   calling the release(PF) has no effect).
    %
    %   % Example:
    %   FIRFilt = dsp.FIRFilter;
    %   y = FIRFilt(randn);
    %   PF = dsp.ParallelFilter(dsp.SOSFilter, FIRFilt);
    %   isLocked(PF.Branch2)
    %   releaseBranches(PF);
    %   isLocked(PF.Branch2)
        obj.releaseChildren();
    end    
end

%----------------------------------------------------------------------
% Protected methods
%----------------------------------------------------------------------
methods(Access=protected)
    %------------------------------------------------------------------
    function [Ls,Ms] = branchRateConversionFactors(obj)
    
        N = getNumBranches(obj);
        Ls = ones(1,N);
        Ms = ones(1,N);

        for n=1:N
            branch = obj.getBranch(n);
            if ~obj.isNumericScalarFilter(branch)
                [Ls(n), Ms(n)] = branch.rateConversionFactors();
            end
        end

    end

    %------------------------------------------------------------------
    function validateBranchRates(obj)
        % Make sure all branches have the same rate conversion ratio.
        if getNumBranches(obj)==0
            return
        end

        % Obtain rate converion factors of branches
        [Ls, Ms]=obj.branchRateConversionFactors();

        % Make sure all ratios are the same, Ls(1)/Ms(1) == Ls(n)/Ms(n)
        idx = find(Ls*Ms(1)-Ms*Ls(1),1,'first');
        if ~isempty(idx)
            r  = sprintf('%i:%i',Ls(1), Ms(1));
            rb = sprintf('%i:%i',Ls(idx), Ms(idx));
            coder.internal.error('dsp:system:ParallelFilter:BranchRateInconsistent',r,rb,idx);
        end
    end

    %------------------------------------------------------------------
    function validateInputsImpl(obj,u)
        coder.internal.errorIf(isfi(u) || ~isfloat(u),'dsp:system:ParallelFilter:invalidInputDataType',class(u));
        obj.validateBranchRates();
        validateInputsImpl@dsp.internal.FilterStructure(obj,u);
    end
  
    %------------------------------------------------------------------
    function setupImpl(obj,varargin)
        % Verify all branches have a single port, and setup
        for n=1:obj.getNumBranches 
            stg = obj.getBranch(n);
            if ~obj.isNumericScalarFilter(stg)
                ni = stg.getNumInputs;
                if ni>1
                    coder.internal.error('dsp:system:ParallelFilter:multipleInputs',n,ni);
                end
                if ~isLocked(stg)
                    setup(stg, varargin{:});
                end
            end
        end
    end
    %------------------------------------------------------------------
    function y = stepImpl(obj,varargin)
        y=0;
        for idx = 1:obj.pNumBranches
            branch = obj.getBranch(idx);
            if ~obj.isNumericScalarFilter(branch)
                y = y + step(branch, varargin{:});
            else
                y = y + branch*varargin{1};
            end
        end
    end
 
   
    %------------------------------------------------------------------
    function s = saveObjectImpl(obj)
        % Called on saving the object
        s.pNumBranches = obj.pNumBranches;
        s.CloneBranches = obj.CloneBranches;
        for ind = 1:obj.pNumBranches
            branchIdx = sprintf('Branch%d',ind);
            if ~obj.isNumericScalarFilter(obj.(branchIdx))
                s.(branchIdx) = matlab.System.saveObject(obj.(branchIdx));
            else
                s.(branchIdx) = obj.(branchIdx);
            end
        end
        s = saveFA(obj, s);   % Save filter analysis class properties
    end
    %------------------------------------------------------------------
    function loadObjectImpl(obj, s, wasLocked)

        % Setting CloneBranches to false will avoid unnecessary cloning the result of
        % matlab.System.loadBoject()
        obj.CloneBranches = false;

        obj.pNumBranches = 0;
        % Call base class method
        for ind = 1:s.pNumBranches
            branchIdx = sprintf('Branch%d',ind);
            if ~obj.isNumericScalarFilter(s.(branchIdx))
                obj.(branchIdx) = matlab.System.loadObject(s.(branchIdx));
            else
                obj.(branchIdx) = s.(branchIdx);
            end
            obj.pNumBranches=ind;
        end
        obj.pNumBranches = s.pNumBranches;
        obj.CloneBranches = s.CloneBranches;
        
        loadFA(obj, s, wasLocked); % Load filter analysis class properties
    end

    %------------------------------------------------------------------
    function d = convertToDFILT(obj,arith)
        % Convert the System object to a dfilt object for analysis

        obj.validateBranchRates();

        % Suppress MFILT deprecation warning
        w = warning('off', 'dsp:mfilt:mfilt:Obsolete');
        restoreWarn = onCleanup(@() warning(w));

        % Create empty parallel dfilt.
        d = dfilt.parallel; 
        % The default cascade object comes with two dummy sections.
        % First remove them:
        d.removestage(1:2);

        for k = 1:obj.pNumBranches
            branch = obj.getBranch(k);
            if obj.isNumericScalarFilter(branch)
                dfiltBranch = dsp.util.scalarDFILT(branch, arith);
            else
                dfiltBranch = todfilt(branch, arith);
            end

            % Unroll a parallel filter to its individual branches
            if isa(branch, 'dsp.ParallelFilter')
                for ind2 = 1:nstages(dfiltBranch)
                    d.addstage(dfiltBranch.Stage(ind2));
                end
            else
                d.addstage(dfiltBranch);
            end
        end
    end
    %------------------------------------------------------------------
    function infoStr = infoImpl(obj,varargin)
        s = StringWriter;
        s.addcr('Discrete-Time Filter Parallel Filter');
        s.addcr('----------------------------');
        s.addcr('Number of branches: %d', obj.pNumBranches);
        if obj.CloneBranches
            s.addcr('Branch cloning: enabled');
        else
            s.addcr('Branch cloning: disabled');
        end

        for idx = 1:obj.pNumBranches
            branch = obj.getBranch(idx);
            s.craddcr('Branch%d: %s', idx, class(branch));
            s.addcr('-------', idx);
            if ~obj.isNumericScalarFilter(branch)
                branchChar = info(branch, varargin{:});
            else
                branchChar = '';
            end
            if isempty(branchChar)
                s.addcr;
            else
                branchChar = [branchChar, repmat('\n', size(branchChar,1), 1)]; %#ok
                branchChar = branchChar';
                s.addcr(branchChar(:)');
            end
        end
        infoStr = sprintf(char(s));
    end
    %------------------------------------------------------------------
    function ds = getDiscreteStateProperties(~, h)
        mc = metaclass(h);
        mp = mc.PropertyList;
        dsIdx = arrayfun(@(x) isa(x, 'matlab.system.CustomMetaProp') && x.DiscreteState, mp);
        ds = {mp(dsIdx).Name};
    end
end

%----------------------------------------------------------------------
% Hidden methods
%----------------------------------------------------------------------
methods (Hidden)
    function n = numChildren(obj)
        n = getNumBranches(obj);
    end

    function h = child(obj, k)
        h = getBranch(obj, k);
    end

    function b = clonedChildren(obj)
        b = obj.CloneBranches;
    end

    function s = getBranch(obj, n)
        s = obj.(['Branch' num2str(n)]);
    end

    %----------------------------------------------------------------------
    function FsIn = inputSampleRate(obj)
        if obj.getNumBranches>0
            FsIn = obj.Branch1.inputSampleRate;
        else
            FsIn = 1;
        end
    end
    %----------------------------------------------------------------------
    function [L,M] = rateConversionFactors(obj)
        nargoutchk(2, 2);
        validateBranchRates(obj);
        L = 1;
        M = 1;
        if ~obj.isNumericScalarFilter(obj.Branch1)
            [L,M] = rateConversionFactors(obj.Branch1);
        end
    end
    %----------------------------------------------------------------------
    function setBranches(obj,branches)
        % If branches contains a P-V pair list
        if ischar(branches{1}) || isstring(branches{1})
            bprops = branches(1:2:end);
            bvals  = branches(2:2:end);

            coder.internal.errorIf(numel(bprops)~=numel(bvals),'dsp:system:ParallelFilter:invalidPVPair');

            N = numel(bprops);
            for ind = 1:N
                % Parse branch idx
                prop = bprops{ind};
                coder.internal.errorIf(~startsWith(prop,'Branch'),'dsp:system:ParallelFilter:invalidPVPair','Property-values number mismatch');
    
                % Extract the value N from 'BranchN' 
                P = digitsPattern;
                bnum = extract(prop, P);

                coder.internal.errorIf(isempty(bnum),'dsp:system:ParallelFilter:invalidPVPair', 'BranchN has wrong format');
                bidx = str2double(bnum{1});
                coder.internal.errorIf(bidx~=ind,'dsp:system:ParallelFilter:invalidPVPair', 'Branch spec out of order');

                coder.internal.errorIf(bidx>obj.MaxNumBranches,'dsp:system:ParallelFilter:maximumBranches',obj.MaxNumBranches);
                branchIdx = coder.const(@sprintf, 'Branch%d',ind);
                obj.(branchIdx) = bvals{ind};
                obj.pNumBranches = ind;
            end
        else
            coder.internal.errorIf(length(branches)>obj.MaxNumBranches,'dsp:system:ParallelFilter:maximumBranches',obj.MaxNumBranches);
    
            for ind = 1:length(branches)
                branchIdx = coder.const(@sprintf, 'Branch%d',ind);
                obj.(branchIdx) = branches{ind};
                obj.pNumBranches = ind;
            end
            obj.pNumBranches = length(branches);
        end
    end

    %----------------------------------------------------------------------
    function C = asCell(obj, args)
        arguments
            obj
            args.Unroll (1,1) logical = false
            args.Clone  (1,1) logical = true
        end
        C = {};
        for k=1:getNumBranches(obj)
            bk = obj.getBranch(k);
            if isa(bk,'dsp.ParallelFilter') && args.Unroll
                C =[C bk.asCell(Unroll=args.Unroll, Clone=args.Clone)]; %#ok
            else
                if args.Clone && ~obj.isNumericScalarFilter(bk)
                    C{end+1} = clone(bk); %#ok
                else
                    C{end+1} = bk; %#ok
                end
            end
        end
    end
end

%----------------------------------------------------------------------
% Hidden Static methods
%----------------------------------------------------------------------
methods (Hidden, Static)
    function flag = isNumericScalarFilter(branch)
        flag = isnumeric(branch) && isscalar(branch) && isfloat(branch);
    end
end

%----------------------------------------------------------------------
% Static methods
%----------------------------------------------------------------------
methods (Static)
    function supportedObjs = helpSupportedSystemObjects()
    %HELPSUPPORTEDSYSTEMOBJECTS List all System objects supported by
    % dsp.ParallelFilter
    %
    % supportedObjs = dsp.ParallelFilter.helpSupportedSystemObjects
    %                   Display a list of System objects that can be used 
    %                   as branches of a dsp.ParallelFilter object
        str = StringWriter;
        addcr(str,'dsp.ParallelFilter supports these filter System objects as branches:');
        supportedObjects = dsp.internal.FilterAnalysis.listFilterAnalysisObjects(true);
        addStr = @(objName)addcr(str,'%s',objName);
        cellfun(addStr,supportedObjects);
        supportedObjs = string(str);
    end
end

end %classdef
