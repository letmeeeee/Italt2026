classdef (StrictDefaults)SpectrumEstimator < dsp.internal.SpectrumEstimatorBase
    %SpectrumEstimator Estimate power spectrum
    %   SE = dsp.SpectrumEstimator returns a System object, SE, that computes
    %   the frequency power spectrum of real or complex signals via the
    %   periodogram method and Welch's averaged, modified periodogram method.
    %
    %   SE = dsp.SpectrumEstimator(Name=Value, ...) returns a Spectrum
    %   Estimator System object, SE, with each specified property name set
    %   to the specified value. You can specify additional name-value pair
    %   arguments in any order as (Name1=Value1,...,NameN=ValueN).
    %
    %   Step method syntax:
    %
    %   P = step(SE, X) computes the frequency spectrum, P, of input X. The
    %   columns of x are treated as independent channels.
    %
    %   [P, PMAX] = step(SE, X) computes P as well as the max-hold frequency
    %   spectrum, PMAX, of input X. The max-hold spectrum is computed by
    %   keeping, at each frequency bin, the maximum value of all the power
    %   spectrum estimates. For max-hold computations, OutputMaxHoldSpectrum
    %   must be set to true.
    %
    %   [P, PMIN] = step(SE, X) computes P as well as the min-hold frequency
    %   spectrum, PMIN, of input X. The min-hold spectrum is computed by
    %   keeping, at each frequency bin, the minimum value of all the power
    %   spectrum estimates. For min-hold computations, OutputMinHoldSpectrum
    %   must be set to true.
    %
    %   [P, PMAX, PMIN] = step(SE, X) computes the frequency spectrum, P, of
    %   input X, the max-hold spectrum, PMAX, of input X, and the min-hold
    %   spectrum, PMIN, of input X. OutputMaxHoldSpectrum and
    %   OutputMinHoldSpectrum must be set to true.
    %
    %   System objects may be called directly like a function instead of
    %   using the step method. For example, y = step(obj, x) and y = obj(x)
    %   are equivalent.
    %
    %   SpectrumEstimator methods:
    %
    %   step                 - Compute power spectrum of input (see above)
    %   release              - Allow property value and input characteristics
    %                          changes, and release Spectrum Estimator
    %                          resources
    %   clone                - Create Spectrum Estimator object with same
    %                          property values
    %   isLocked             - Display locked status (logical)
    %   reset                - Reset the states of the Spectrum Estimator
    %   getRBW               - Get the resolution bandwidth of the spectrum
    %   getFrequencyVector   - Get the vector of frequencies at which the
    %                          spectrum is estimated
    %
    %   SpectrumEstimator properties:
    %
    %   SpectrumType                 - Spectrum type
    %   FFTLengthSource              - Source of the FFT length value
    %   FFTLength                    - FFT length
    %   Method                       - Welch or filter bank
    %   NumTapsPerBand               - Number of filter taps per frequency band
    %   Window                       - Window function
    %   SidelobeAttenuation          - Sidelobe attenuation of window
    %   FrequencyRange               - Frequency range of the Spectrum estimate
    %   PowerUnits                   - Power units
    %   AveragingMethod              - Averaging method
    %   SpectralAverages             - Number of spectral averages
    %   ForgettingFactor             - Forgetting factor
    %   ReferenceLoad                - Reference load
    %   OutputMaxHoldSpectrum        - Output max-hold spectrum
    %   OutputMinHoldSpectrum        - Output min-hold spectrum
    %   SampleRate                   - Sample rate of input
    %
    %   % Example
    %   %  Compare spectral estimates of sinusoids in noise using a Hann
    %   % window Welch-based approach and filter-bank-based approach
    %   FrameSize = 420;
    %   Fs = 1;
    %   sinegen = dsp.SineWave('SampleRate',Fs,...
    %     'SamplesPerFrame',FrameSize,...
    %     'Frequency',[0.16 0.2 0.205 0.25],...
    %     'Amplitude',[2e-5 1  0.05  0.5]);
    %   NoiseVar = 1e-10;
    %   numAvgs = 8;
    %
    %   hannEstimator = dsp.SpectrumEstimator('PowerUnits', 'dBm',...
    %     'Window','Hann','FrequencyRange', 'onesided',...
    %     'SpectralAverages',numAvgs,'SampleRate',Fs);
    %
    %   filterBankEstimator = dsp.SpectrumEstimator('PowerUnits', 'dBm',...
    %     'Method','Filter bank','FrequencyRange', 'onesided',...
    %     'SpectralAverages',numAvgs,'SampleRate',Fs);
    %
    %   spectrumPlotter = dsp.ArrayPlot(...
    %     'PlotType','Line','SampleIncrement',Fs/FrameSize,...
    %     'YLimits',[-250,50],'YLabel','dBm',...
    %     'ShowLegend',true,'ChannelNames',{'Hann window','Filter bank'});
    %
    %   tic,
    %   while toc < 10
    %     x = sum(sinegen(),2) + sqrt(NoiseVar)*randn(FrameSize,1);
    %     Pse_hann = hannEstimator(x);
    %     Pfb = filterBankEstimator(x);
    %     spectrumPlotter([Pse_hann,Pfb]);
    %   end
    %
    %   See also dsp.CrossSpectrumEstimator, dsp.TransferFunctionEstimator,
    %            spectrumAnalyzer.

    %   Copyright 2013-2022 The MathWorks, Inc.

    %#codegen
    %#ok<*EMCLS>

    properties (Nontunable)
        %SpectrumType Spectrum type
        %   Specify the spectrum type as one of 'Power' | 'Power density'. When
        %   the spectrum type is 'Power', the power spectral density is scaled by
        %   the equivalent noise bandwidth of the window (in Hz). The default is
        %   'Power'.
        SpectrumType (1, :) char {matlab.system.mustBeMemberMessageID(SpectrumType, ...
            {'dsp:system:SpectrumEstimatorBase:SpectrumType_Power'; ...
            'dsp:system:SpectrumEstimatorBase:SpectrumType_Powerdensity'})} = 'Power';
        %PowerUnits Power units
        % Specify the spectrum power units as one of 'Watts' | 'dBW' | 'dBm'. The
        % default is 'Watts'
        PowerUnits (1, :) char {matlab.system.mustBeMemberMessageID(PowerUnits, ...
            {'dsp:system:SpectrumEstimatorBase:PowerUnits_Watts'; ...
            'dsp:system:SpectrumEstimatorBase:PowerUnits_dBW'; ...
            'dsp:system:SpectrumEstimatorBase:PowerUnits_dBm'})} = 'Watts';
        %Method Spectrum estimation method
        % Specify the spectrum estimation method as one of 'Welch' |
        % 'Filter bank'. The filter bank method provides better resolution,
        % lower spectral leakage, a more accurate noise floor and more
        % precise peaks at the expense of increased computation and slower
        % tracking. The default is 'Welch'
        Method (1, :) char {matlab.system.mustBeMemberMessageID(Method, ...
            {'dsp:system:SpectrumEstimatorBase:Method_Welch'; ...
            'dsp:system:SpectrumEstimatorBase:Method_Filterbank'})} = 'Welch';
        %NumTapsPerBand Number of filter taps per frequency band
        %   Specify the number of filter coefficients or taps for each
        %   frequency band. This also corresponds to the number of filter
        %   coefficients per polyphase branch. The total number of filter
        %   coefficients is given by NumTapsPerBand times FFTLength. This
        %   property applies when you set Method to 'Filter bank'. The
        %   default is 12.
        NumTapsPerBand = uint16(12);
        %OutputMaxHoldSpectrum Output max-hold spectrum
        %   Set this property to true so that the Spectrum Estimator computes and
        %   outputs the max-hold spectrum of each input channel. The max-hold
        %   spectrum is computed by keeping, at each frequency bin, the maximum
        %   value of all the power spectrum estimates. The default is false.
        OutputMaxHoldSpectrum (1, 1) logical = false;
        %OutputMinHoldSpectrum Output min-hold spectrum
        %   Set this property to true so that the Spectrum Estimator computes and
        %   outputs the min-hold spectrum of each input channel. The min-hold
        %   spectrum is computed by keeping, at each frequency bin, the minimum
        %   value of all the power spectrum estimates. The default is false.
        OutputMinHoldSpectrum (1, 1) logical = false;
    end

    properties
        %ReferenceLoad Reference Load
        %   Specify the load that the spectrum estimator uses as a reference to
        %   compute power values as a real, positive scalar in Ohms. The default
        %   is 1 Ohm. This property is tunable.
        ReferenceLoad = 1;
    end

    properties (Access = private)
        % pMaxHoldSpectrum holds the max-hold spectrum
        pMaxHoldSpectrum
        % pMinHoldSpectrum holds the min-hold spectrum
        pMinHoldSpectrum
        % Cache cast reference load
        pReferenceLoad
        % Store polyphase matrix and states in the case of filter bank
        PolyphaseMatrix
        States
        vextra
        tmpNFFT = int32(-1);
    end

    properties (Access = private, Nontunable)
        % Avoid log of zero
        peps

        % private properties used to avoid string comparisons in step
        pIsInDB;
        pDBmFactor;
        pUseFilterBank = false;

        % Stopband attenuation used for filter bank
        StopbandAttenuation = 140;
        pHalideFlag
    end

    methods
        function obj = SpectrumEstimator(varargin)
        %SpectrumEstimator   Construct the SpectrumEstimator class.
            obj@dsp.internal.SpectrumEstimatorBase(varargin{:})
        end

        function set.ReferenceLoad(obj, value)
            validateattributes(value,{'single','double'}, {'positive','real','scalar','finite','nonnan'},'','ReferenceLoad');
            obj.ReferenceLoad = value;
        end

        function set.NumTapsPerBand(obj,P)
            validateattributes(P,...
                               {'numeric'},...
                               {'finite','real','scalar','>=',0,'integer','even'},...
                               '','NumTapsPerBand');
            obj.NumTapsPerBand = uint16(P);
        end

        function RBW = getRBW(obj,varargin)
        % getRBW Get the resolution bandwidth of the Spectrum, in Hz.
        %   The resolution bandwidth, RBW, is the smallest positive frequency,
        %   or frequency interval, that can be resolved. It is equal to
        %   ENBW * SampleRate/ L, where L is the input length, and ENBW is the
        %   two-sided equivalent noise bandwidth of the window (in Hz). For
        %   example, if SampleRate = 100, L = 1024, and Window = 'Hann',
        %   RBW =  enbw(hann(1024)) * 100 / 1024

            narginchk(1,2);
            if obj.pUseFilterBank
                % Disallow usage if object was locked and then released
                coder.internal.errorIf(~isLocked(obj),...
                                       'dsp:system:SpectrumEstimatorBase:NotLockedYet','getRBW');
                if (nargin==1)
                    Fs = obj.SampleRate;
                else
                    % Use input sample rate
                    Fs = varargin{1};
                    validateattributes(Fs,{'double','single'},{'real','scalar','positive','finite'},'getRBW','SampleRate',2);
                end
                RBW = Fs/obj.pNFFT;
            else
                RBW = getRBW@dsp.internal.SpectrumEstimatorBase(obj,varargin{:});
            end
        end
    end

    methods(Access = protected)
        function Pxx = computeWindowFFT(obj,x)
        % Window the data and compute FFT
            xout = windowData(obj,x);
            X = computeFFT(obj,xout);
            % Compute power spectrum, use real() to remove type ambiguity in
            % code generation
            Pxx = real(X.*conj(X));
        end

        function  Pout = convertAndScale(obj,P)
            Pout = preConvertAndScale(obj,P);
            if strcmp(obj.SpectrumType,'Power')
                if ~obj.pUseFilterBank
                    Pout = Pout * obj.pENBWFactor;
                end
            else
                % Scale with respect to Fs to convert to PSD
                if obj.pUseFilterBank
                    Pout = Pout./(getSampleRate(obj)./obj.pNFFT);
                else
                    Pout = Pout/getSampleRate(obj);
                end
            end
            if obj.OutputMaxHoldSpectrum
                obj.pMaxHoldSpectrum = max(obj.pMaxHoldSpectrum,Pout);
            end
            if obj.OutputMinHoldSpectrum
                obj.pMinHoldSpectrum = min(obj.pMinHoldSpectrum,Pout);
            end
        end

        function initializeSpectrumCache(obj)
            NFFT = getActualFFTLen(obj);
            numChannels = getNumberOfChannels(obj);
            dtType = getDatatype(obj);
            if isRunningAverage(obj)
                % setup running average matrix
                obj.pPeriodogramMatrix = cast(zeros(NFFT,...
                    obj.SpectralAverages,...
                    numChannels),dtType);
            else
                % setup exponential averaging
                obj.pPreviousAvgSpectrum = cast(zeros(NFFT, ...
                    numChannels),dtType);
                obj.pPreviousWeight = cast(0, dtType);
            end

            if strcmp(obj.FrequencyRange,'onesided')
                if mod(NFFT,2) % odd
                    L = (NFFT+1)/2;
                else % even
                    L = NFFT/2+1;
                end
            else
                L = NFFT;
            end

            obj.pMaxHoldSpectrum   = cast(-Inf * ones(L,numChannels),...
                                          dtType);
            obj.pMinHoldSpectrum   = cast(Inf * ones(L,numChannels),...
                                         dtType);
        end
         
        function num = getNumOutputsImpl(obj)
            num = 1 + obj.OutputMaxHoldSpectrum + obj.OutputMinHoldSpectrum ;
        end

        function setupImpl(obj,x)
            setupImpl@dsp.internal.SpectrumEstimatorBase(obj,x);
            %pNFFT is set by the superclass method
            iDT = getDatatype(obj);
            obj.tmpNFFT = cast(obj.pNFFT,'int32');
            obj.pDBmFactor = cast(30*strcmp(obj.PowerUnits,'dBm'),iDT);
            obj.pIsInDB = ~strcmp(obj.PowerUnits,'Watts');
            obj.pReferenceLoad = cast(obj.ReferenceLoad,iDT);
            if strcmp(getDatatype(obj),'double')
                obj.peps           = eps(0);
            else
                obj.peps           = eps(single(0));
            end
            if strcmp(obj.Method,'Filter bank')
                obj.pUseFilterBank = true;
            end
            if obj.pUseFilterBank
                M = obj.pNFFT;
                N = size(x,2);
                P = obj.NumTapsPerBand;
                Astop = obj.StopbandAttenuation;

                b = cast(designMultirateFIR(1,M,ceil(P/2),Astop),iDT);

                ppm = cast(reshape(b,M,P),'like',real(x));
                [polyMtx, obj.pHalideFlag] = dsp.Channelizer.pmatrixdecider(x,P,M,ppm);
                obj.States = zeros(numel(polyMtx),N,'like',x);
                obj.vextra = zeros(1,M,N,'like',x);
                obj.PolyphaseMatrix = polyMtx;
            end

        end

        function validateInputsImpl(obj,x)
            validateInputsImpl@dsp.internal.SpectrumEstimatorBase(obj,x);
            if strcmp(obj.Method,'Filter bank')

                if strcmp(obj.FFTLengthSource,'Property')
                    M = obj.FFTLength;
                else
                    M = obj.tmpNFFT;
                end
                if M ~= -1
                    coder.internal.errorIf(rem(size(x,1),M)~=0,['dsp:system',...
                                        ':SpectrumEstimatorBase:frameSize'],M);
                end
            end
        end

        function processTunedPropertiesImpl(obj)
            processTunedPropertiesImpl@dsp.internal.SpectrumEstimatorBase(obj);
            obj.pReferenceLoad = cast(obj.ReferenceLoad,getDatatype(obj));
        end

        function flag = isInactivePropertyImpl(obj,prop)
            flag =  isInactivePropertyImpl@dsp.internal.SpectrumEstimatorBase(obj,prop);

            switch prop
              case 'Window'
                if strcmp(obj.Method,'Filter bank')
                    flag = true;
                end
              case 'NumTapsPerBand'
                if strcmp(obj.Method,'Welch')
                    flag = true;
                end 
            end

        end

        function [P,Popt1,Popt2] = stepImpl(obj, x)
            if obj.pUseFilterBank
                % Compute new power spectrum estimate
                z = obj.States;
                v = obj.vextra;
                polyMtx = obj.PolyphaseMatrix;
                [P,z] = dsp.SpectrumEstimator.computePSD(x,v,z,polyMtx,obj.pNFFT,obj.pHalideFlag);
                obj.States = z;
                
                if isRunningAverage(obj)
                    % Update the running average matrix
                    updatePeriodogramMatrix(obj,P);
                    % Get the current average
                    P = getPeriodogramMatrixAverage(obj);
                else
                    % Get the current exponential average
                    P = getExponentialAverage(obj,P);
                end
                % Convert and scale
                P = convertAndScale(obj,P);

            else
                P  = computeOutput(obj, x);
            end

            P = P/obj.pReferenceLoad;
            if obj.pIsInDB
                P = 10*log10(P + obj.peps ) + obj.pDBmFactor;
            end

            if obj.OutputMaxHoldSpectrum
                Popt1 = obj.pMaxHoldSpectrum/obj.ReferenceLoad;
                if obj.pIsInDB
                    Popt1 = 10*log10(Popt1 + obj.peps ) + obj.pDBmFactor;
                end
                if obj.OutputMinHoldSpectrum
                    Popt2 = obj.pMinHoldSpectrum/obj.ReferenceLoad;
                    if obj.pIsInDB
                        Popt2 = 10*log10(Popt2 + obj.peps ) + obj.pDBmFactor;
                    end
                    return;
                end
            elseif obj.OutputMinHoldSpectrum
                Popt1 = obj.pMinHoldSpectrum/obj.ReferenceLoad;
                if obj.pIsInDB
                    Popt1 = 10*log10(Popt1 + eps(0)) + obj.pDBmFactor;
                end
            end
        end

        function s = saveObjectImpl(obj)
            s = saveObjectImpl@dsp.internal.SpectrumEstimatorBase(obj);
            if isLocked(obj)
                s.pMaxHoldSpectrum     = obj.pMaxHoldSpectrum;
                s.pMinHoldSpectrum     = obj.pMinHoldSpectrum;
                s.pIsInDB              = obj.pIsInDB;
                s.pDBmFactor           = obj.pDBmFactor;
                s.peps                 = obj.peps;
                s.pReferenceLoad       = obj.pReferenceLoad;
                s.pUseFilterBank       = obj.pUseFilterBank;
                s.PolyphaseMatrix      = obj.PolyphaseMatrix;
                s.States               = obj.States;
                s.vextra               = obj.vextra;
                s.tmpNFFT              = obj.tmpNFFT;
                s.pHalideFlag          = obj.pHalideFlag;
            end
        end

        function loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                if isfield(s,'pMaxHoldSpectrum')
                    obj.pMaxHoldSpectrum     = s.pMaxHoldSpectrum;
                    obj.pMinHoldSpectrum     = s.pMinHoldSpectrum;
                    obj.pIsInDB              = s.pIsInDB;
                    obj.pDBmFactor           = s.pDBmFactor;
                    obj.peps                 = s.peps;
                    obj.pReferenceLoad       = s.pReferenceLoad;
                    obj.pUseFilterBank       = s.pUseFilterBank;
                    obj.PolyphaseMatrix      = s.PolyphaseMatrix;
                    obj.States               = s.States;
                    obj.vextra               = s.vextra;
                    obj.tmpNFFT              = int32(s.tmpNFFT);
                end
                if s.pUseFilterBank
                    obj.pHalideFlag = s.pHalideFlag;
                end
            end
            loadObjectImpl@dsp.internal.SpectrumEstimatorBase(obj,s,wasLocked);
        end

        function  resetImpl(obj)
            resetImpl@dsp.internal.SpectrumEstimatorBase(obj);
            if obj.pUseFilterBank
                obj.States = zeros(size(obj.States),'like',obj.States);
                obj.vextra = zeros(size(obj.vextra),'like',obj.vextra);
            end
        end

        function  releaseImpl(obj)
            releaseImpl@dsp.internal.SpectrumEstimatorBase(obj);
            obj.tmpNFFT = cast(-1,class(obj.tmpNFFT));
        end

        function RBW = computeRBW(obj,Fs)
            if strcmp(obj.Method,'Welch')
                RBW = computeRBW@dsp.internal.SpectrumEstimatorBase(obj,Fs);
            else
                RBW = Fs/obj.pNFFT;
            end
        end

        function icon = getIconImpl(~)
        % MATLAB system block icon
            icon = getString(message('dsp:system:SpectrumEstimatorBase:SpectrumEstimatorIcon'));
        end

        function varargout = getOutputNamesImpl(obj)

            needToName = false;
            if obj.OutputMaxHoldSpectrum
                needToName = true;
                varargout{2} = 'Pmax';
                if   obj.OutputMinHoldSpectrum
                    varargout{3} = 'Pmin';
                end
            elseif obj.OutputMinHoldSpectrum
                needToName = true;
                varargout{2} = 'Pmin';
            end
            if needToName
                varargout{1} = 'Pxx';
            else
                varargout{1} = '';
            end
        end

        function name = getInputNamesImpl(~)
            name = '';
        end

        % Propagators
        function varargout = isOutputComplexImpl(~)
            varargout{1} = false;
            varargout{2} = false;
            varargout{3} = false;
        end

        function varargout = getOutputSizeImpl(obj)
            sz =  getOutputSizeImpl@dsp.internal.SpectrumEstimatorBase(obj);
            varargout{1} = sz;
            varargout{2} = sz;
            varargout{3} = sz;
        end
        %----------------------------------------------------------------------
        function varargout = getOutputDataTypeImpl(obj)
            varargout{1}  = propagatedInputDataType(obj,1);
            varargout{2}  = propagatedInputDataType(obj,1);
            varargout{3}  = propagatedInputDataType(obj,1);
        end
        %----------------------------------------------------------------------
        function varargout = isOutputFixedSizeImpl(~)
            varargout{1} = true;
            varargout{2} = true;
            varargout{3} = true;
        end
        %----------------------------------------------------------------------
        function dt = getTunablePropertiesSpecificationImpl(obj,~)
            dt = propagatedInputDataType(obj,1);
        end

    end

    methods (Static, Access = protected)
        function groups = getPropertyGroupsImpl
        %             mainProps = {'SpectralAverages', 'Method', 'FrequencyRange', ...
        %                 'PowerUnits', 'SampleRate'};
        %
        %             advancedProps = {'FFTLengthSource', 'FFTLength', 'Window', ...
        %                 'SidelobeAttenuation', 'NumTapsPerBand', 'SpectrumType', 'ReferenceLoad', ...
        %                 'OutputMaxHoldSpectrum', 'OutputMinHoldSpectrum'};
        %
        %             advancedPropsTitle = getString(message('dsp:system:Shared:Parameters'));
        %             mainGroup = matlab.system.display.SectionGroup(...
        %                 'TitleSource', 'Auto', 'PropertyList', mainProps);
        %             visualizationGroup = matlab.system.display.SectionGroup(...
        %                 'Title', advancedPropsTitle, 'PropertyList', advancedProps);
        %
        %             groups = [mainGroup visualizationGroup];

        % Modify order of display
            parameterString = getString(message('dsp:system:Shared:Parameters'));
            groups =  matlab.system.display.Section(...
                'Title', parameterString, ...
                'PropertyList', {'SpectrumType','FFTLengthSource','FFTLength',...
                                'Method','Window','SidelobeAttenuation','NumTapsPerBand',...
                                'FrequencyRange','PowerUnits',...
                                'AveragingMethod','SpectralAverages','ForgettingFactor', ...
                                'ReferenceLoad','OutputMaxHoldSpectrum','OutputMinHoldSpectrum',...
                                'InheritSampleRate','SampleRate'});
        end
        %------------------------------------------------------------------------
        function header = getHeaderImpl
        % MATLAB System block header
            text = getString(message('dsp:system:SpectrumEstimatorBase:SpectrumEstimatorDescription'));
            title = getString(message('dsp:system:SpectrumEstimatorBase:SpectrumEstimatorTitle'));
            header = matlab.system.display.Header('dsp.SpectrumEstimator', ...
                                                  'ShowSourceLink', true, ...
                                                  'Title', title,...
                                                  'Text',  text);
        end

    end
    
    methods (Static, Hidden)
        function [PSD,z] = computePSD(x,v,z,p,M,isUsingHalide)
            % Inputs:
            %   p - MxNp polyphase matrix
            %   x - LxN Multi-channel frame input
            %   z - Np*MxN state vector
            %   v - 1xMxN temporary computation
            % Outputs:
            %   PSD - M*N multichannel power spectrum estimate
            % Where:
            %   M  - Number of frequency bands
            %   Np - Number of taps per band
            %   L  - Input frame size (must be multiple of M)
            %   N  - Number of independent channels
            %
            % Assumptions:
            %   if p is a double, x, z must also be doubles
            %   if p is a single, x, z must also be singles
            %   if x is complex, z must also be complex
            Lx = size(x, 1);
            outputLen = ceil(Lx / M);
            phIdx = int32(1);
            state = int32(1);
            [y,z] = dsp.Channelizer.firpolyphase_channelizer(x,v,z,p,M,1,isUsingHalide,outputLen,phIdx,state);
            % Compute new power spectrum estimate
            if size(x,2) > 1
                PSD =  squeeze(1./size(y,1).*sum(abs(y.^2),1));
            else
                PSD =  1./size(y,1).*sum(abs(y.^2),1)';
            end
        end
    end

end
