classdef (StrictDefaults)CICCompensationInterpolator < dsp.internal.CICCompensationBase
%CICCompensationInterpolator Compensate for CIC filter using an FIR 
%                            interpolator
%   The shortcomings of a CIC interpolator, namely its passband droop and
%   wide transition region, can be compensated by preceding it with a
%   compensation interpolator. This System object provides the ability to
%   design and use such a compensator for the CIC filter.
%   
%   CFIR = dsp.CICCompensationInterpolator returns a System object, CFIR,
%   that applies a FIR interpolator to each channel of the input signal.
%   Using the properties of the object, the interpolation filter can be
%   designed to compensate for a subsequent CIC filter.
%   
%   CFIR = dsp.CICCompensationInterpolator('Name', Value, ...) returns a
%   CIC compensation interpolator System object, CFIR, with each specified
%   property set to the specified value.
%   
%   CFIR = dsp.CICCompensationInterpolator(INTERP,'Name',Value,...) returns
%   a CIC compensation interpolator System object, CFIR, with the
%   InterpolationFactor property set to INTERP, and other specified
%   properties set to the specified values.
%
%   CFIR = dsp.CICCompensationInterpolator(CICINTERP, 'Name', Value, ...)
%   returns a CIC compensation interpolator System object, CFIR, with the
%   CICRateChangeFactor, CICNumSections and CICDifferentialDelay properties
%   set using their corresponding values in the dsp.CICInterpolator System
%   object CICINTERP, and other specified properties set to the specified
%   values.
%
%   CFIR = dsp.CICCompensationInterpolator(CICINTERP, INTERP, 'Name',
%   Value, ...) returns a CIC compensation interpolator System object,
%   CFIR, with the CICRateChangeFactor, CICNumSections and
%   CICDifferentialDelay properties set using their corresponding values in
%   the dsp.CICInterpolator System object CICINTERP, the
%   InterpolationFactor property set to INTERP, and other specified
%   properties set to the specified values.
%
%   Step method syntax:
%
%   Y = step(CFIR, X) outputs the upsampled and filtered values, Y,
%   of the input signal X. A KixN input matrix is treated as N independent
%   channels, and the System object interpolates each channel over the
%   first dimension and generates a KoxN output matrix. Ko = Ki*L where L
%   is the interpolation factor. The object supports real and complex
%   floating-point and fixed-point inputs, except for complex unsigned
%   fixed-point inputs.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   CICCompensationInterpolator methods:
%
%   step      - See above description for use of this method
%   release   - Allow property value and input characteristics changes
%   clone     - Create CIC compensation interpolator object with same 
%               property values
%   isLocked  - Locked status (logical)
%   reset     - Reset the internal states to initial conditions
% generatehdl - Generate HDL code. (Filter Design HDL Coder Required)
%
%   CICCompensationInterpolator properties:
%
%   SampleRate            - Input sample rate
%   InterpolationFactor   - Interpolation factor
%   CICRateChangeFactor   - Rate change factor of the CIC filter to be
%                           compensated
%   CICNumSections        - Number of sections of the CIC filter to be
%                           compensated
%   CICDifferentialDelay  - Differential delay of the CIC filter to be
%                           compensated
%   DesignForMinimumOrder - Option to have a minimum order design for the
%                           filter in compensation interpolator
%   FilterOrder           - Order of the filter in compensation 
%                           interpolator
%   PassbandFrequency     - Passband frequency of compensation filter
%   StopbandFrequency     - Stopband frequency of compensation filter
%   PassbandRipple        - Allowed passband ripple of compensation filter
%   StopbandAttenuation   - Minimum attenuation needed in stopband of
%                           compensation filter
%
%   This System object supports several filter analysis methods. For more
%   information, type dsp.CICCompensationInterpolator.helpFilterAnalysis.
%
%   This System object supports fixed-point operations. For more
%   information, type dsp.CICCompensationInterpolator.helpFixedPoint.
%
%   % EXAMPLE: Design a compensation interpolator for an existing CIC 
%   % interpolator and visualize the frequency response of the cascade. Use
%   % it on a sample input.
%   
%   % CONSTRUCTION
%   cicinterp = dsp.CICInterpolator(InterpolationFactor = 16, ...
%                                   NumSections = 6);
%   fs = 600;      % Sampling frequency of input of compensation
%                  % interpolator
%   fPass = 100;   % Passband frequency
%   fStop = 250;   % Stopband frequency
%   ast = 80;      % Minimum attenuation of alias components in stopband
%   cfir = dsp.CICCompensationInterpolator(cicinterp, ...
%               InterpolationFactor= 2, ...
%               PassbandFrequency= fPass, ...
%               StopbandFrequency= fStop, ...
%               StopbandAttenuation= ast, ...
%               SampleRate= fs);
%   
%   % FREQUENCY RESPONSE
%   % Next, visualize the cascade frequency response.
%
%   filtcasc = dsp.FilterCascade(cfir, cicinterp);
%   f = fvtool(cfir, cicinterp, filtcasc, ...
%             'Fs', [fs*2, fs*16*2, fs*16*2], 'Arithmetic', 'fixed');
%   set(f, 'NormalizeMagnitudeto1', 'on');
%   legend(f,'CIC Compensation Interpolator','CIC Interpolator', ...
%          'Overall Response');
%
%   % STEP
%   sigsource = dsp.SignalSource(fi(rand(1000,1),1,16,15), ...
%                                SamplesPerFrame = 100);
%   y = fi(zeros(0,1), 1, 32, 20);
%   for ind = 1:10
%       x2 = cfir(sigsource() );
%       y = [y; cicinterp(x2)];
%   end    

%   Copyright 2013-2022 The MathWorks, Inc.

    %#codegen
    %#ok<*EMCA>
    properties (Nontunable)
        % SampleRate Input sample rate (Hz)
        %   Specify the sampling rate of the input in Hertz as a finite
        %   numeric scalar. the default is 600 KHz.
        SampleRate = 600000;
        %InterpolationFactor Interpolation factor
        %   Specify a positive integer amount by which the input signal
        %   will be interpolated. The default value of this property is 2.
        InterpolationFactor = 2;
        %PassbandFrequency  Passband edge frequency (Hz)
        %   Specify the passband edge frequency of the compensation filter
        %   in Hertz, as a positive real scalar smaller than half the
        %   output sample rate. The default value of this property is
        %   100000 Hz.
        PassbandFrequency = 100000;
        %StopbandFrequency  Stopband edge frequency (Hz)
        %   Specify the stopband edge frequency of the compensation filter
        %   in Hertz, as a positive real scalar smaller than half the
        %   output sample rate. This property applies when you set the
        %   DesignForMinimumOrder property to true. The default value of
        %   this property is 400000 Hz.
        StopbandFrequency = 400000;
    end
    
    properties (Constant, Hidden)
        % SampleRateSet is used to setup the choices for SampleRate (from
        % dialog or inherit from port)
        SampleRateSet = matlab.system.SourceSet({'PropertyOrMethod', ...
            'SystemBlock', 'InheritSampleRate', 'getInheritedSampleRate',true});
    end

    properties (Nontunable, Access = protected)
        pFIRInterpolator;
        pSR = 600000;
    end
    %----------------------------------------------------------------------
    % Public methods
    %----------------------------------------------------------------------
    methods
        function obj = CICCompensationInterpolator(varargin)
            if ~isempty(varargin) &&  isa(varargin{1}, 'dsp.CICInterpolator')
                % The constructor supports taking in an input of the type
                % dsp.CICInterpolator. In that case, the properties
                % CICRateChangeFactor, CICDifferentialDelay and
                % CICNumSections are copied from the dsp.CICInterpolator
                % object.
                if isempty(coder.target)
                    if any(strcmpi('CICRateChangeFactor',varargin)) 
                        coder.internal.warning(...
                            'dsp:system:CICCompensationInterpolator:irrelevantConstructorInput',...
                            'CICRateChangeFactor');
                    end
                    if any(strcmpi('CICDifferentialDelay', varargin))  
                        coder.internal.warning(...
                            'dsp:system:CICCompensationInterpolator:irrelevantConstructorInput',...
                            'CICDifferentialDelay');
                    end
                    if any(strcmpi('CICNumSections', varargin))  
                        coder.internal.warning(...
                            'dsp:system:CICCompensationInterpolator:irrelevantConstructorInput',...
                            'CICNumSections');
                    end
                end
                % Support name-value pair arguments
                setProperties(obj,nargin-1,varargin{2:end},'InterpolationFactor');
                % Copy some properties from CICInterpolator input to the
                % CICCompensationInterpolator object
                obj.CICRateChangeFactor = varargin{1}.InterpolationFactor;
                obj.CICDifferentialDelay = varargin{1}.DifferentialDelay;
                obj.CICNumSections = varargin{1}.NumSections;
            else
                % Support name-value pair arguments
                setProperties(obj,nargin,varargin{:},'InterpolationFactor');
            end
        end
        %------------------------------------------------------------------      
        function set.SampleRate(obj,val)
            validateattributes(val,...
                {'double','single'}, ...
                {'real','scalar','positive','finite'},...
                '','SampleRate');
            obj.SampleRate = val;
            postProcessSampleRate(obj,val);
        end
        %------------------------------------------------------------------
        function set.InterpolationFactor(obj, value)
            validateattributes(value,  {'numeric'}, ...
                {'real', 'positive', 'integer', 'scalar'}, '', 'InterpolationFactor');
            obj.InterpolationFactor = value;
            needToDesignFilters(obj)
        end
        %------------------------------------------------------------------
        function set.PassbandFrequency(obj, value)
            validateattributes(value, {'numeric'}, ...
                {'real', 'positive', 'real', 'scalar', 'finite'},...
                '', 'PassbandFrequency');
            obj.PassbandFrequency = value;
            needToDesignFilters(obj)
        end
        %------------------------------------------------------------------
        function set.StopbandFrequency(obj, value)
            validateattributes(value, {'numeric'}, ...
                {'real', 'positive', 'real', 'scalar', 'finite'},...
                '', 'PassbandFrequency');
            obj.StopbandFrequency = value;
            needToDesignFilters(obj)
        end
    end
    %----------------------------------------------------------------------
    methods (Hidden)
        function flag = ishdlable(~)
            flag = true;
        end

        function [L,M] = rateConversionFactors(obj)
            nargoutchk(2, 2);
            L = obj.InterpolationFactor;
            M = 1;
        end
    end
    %----------------------------------------------------------------------
    % Protected methods
    %----------------------------------------------------------------------
    methods (Access=protected)
        
        function validatePropertiesImpl(obj)
            % Verify the values of properties before designing filter
             coder.internal.errorIf(obj.StopbandFrequency < obj.PassbandFrequency, ...
                'dsp:system:CICCompensationInterpolator:invalidPassbandStopband');
        end
        
        function crossValidateProperties(obj)
            
            Fs = obj.SampleRate;
            
            outputSampleRate = Fs*obj.InterpolationFactor;
            
            coder.internal.errorIf(obj.PassbandFrequency >= outputSampleRate/2, ...
                'dsp:system:CICCompensationInterpolator:invalidPassband');
            
            coder.internal.errorIf(obj.DesignForMinimumOrder && ...
                (obj.StopbandFrequency >= outputSampleRate/2), ...
                'dsp:system:CICCompensationInterpolator:invalidStopband');
        end
        %------------------------------------------------------------------
        function validateInputsImpl(obj, u)
            % Verify input to the step function
            
            % input must be numeric
            coder.internal.errorIf(~isnumeric(u), ...
                    'dspshared:system:inDataTypeNotFloatIntFixpt', '');
            
            % input cannot be unsigned complex fixed-point
            if isfi(u)
                coder.internal.errorIf(~issigned(u) && ~isreal(u), ...
                    'dsp:system:CICCompensationInterpolator:inputUnsignedComplexFixedPoint');
            end

            % Cache input data type for filter analysis
            if isempty(coder.target)
                if ~isempty(u)
                    cacheInputDataType(obj,u)
                end
            end
        end
        %------------------------------------------------------------------
        function resetImpl(obj)
            % Reset the states of interpolator object
            reset(obj.pFIRInterpolator);
        end
        %------------------------------------------------------------------
        function releaseImpl(obj)
            % Release the interpolator object. This allows users to
            % subsequently modify non-tunable properties and call the step
            % method with a different input datatype, different frame size,
            % or a different number of channels.
            release(obj.pFIRInterpolator);
            if isempty(coder.target)
                % Set fdesign and fmethod on the object to empty
                setMetaData(obj, [], []);
            end
            needToDesignFilters(obj);
        end
        %------------------------------------------------------------------
        function setupImpl(obj,u)
            setupImpl@dsp.internal.SampleRateEngine(obj,u);
            if ~isfloat(u)
                % Always design filters if setup is called with fixed-point
                % input. This is because getFilter method may have designed
                % filter with a default input data type for fixed-point
                % filter analysis.
                needToDesignFilters(obj);
                designFilter(obj,u);
            else
                designFilter(obj);
            end
            setup(obj.pFIRInterpolator,u);
        end
        %------------------------------------------------------------------
        function y = stepImpl(obj, u)
            % Interpolate the input by the specified interpolation factor
            y = step(obj.pFIRInterpolator, u);
        end
        %------------------------------------------------------------------
        function designFilter(obj,u)
            % Create interpolator System object
            
            if obj.pIsFilterDesigned
                % This helps avoid duplicate construction of filters when
                % setup() is called after getFilter().
                % For codegen, this property is always false.
                return
            end
            
            % Get numerator coefficients using fdesign
            coder.extrinsic('dsp.CICCompensationInterpolator.designCompensator');
            if isempty(coder.target)
                [num, InterpObj] = dsp.CICCompensationInterpolator.designCompensator(...
                    obj.InterpolationFactor, obj.DesignForMinimumOrder, ...
                    obj.CICNumSections, obj.CICDifferentialDelay, ...
                    obj.CICRateChangeFactor, obj.FilterOrder, ...
                    obj.PassbandFrequency, obj.StopbandFrequency, ...
                    obj.PassbandRipple, obj.StopbandAttenuation, obj.pSR);
            else
                num = coder.const(@dsp.CICCompensationInterpolator.designCompensator, ...
                    obj.InterpolationFactor, obj.DesignForMinimumOrder, ...
                    obj.CICNumSections, obj.CICDifferentialDelay, ...
                    obj.CICRateChangeFactor, obj.FilterOrder, ...
                    obj.PassbandFrequency, obj.StopbandFrequency, ...
                    obj.PassbandRipple, obj.StopbandAttenuation, obj.pSR);
            end
            
            % For codegen, all the nontunable properties of
            % dsp.FIRInterpolator need to be set in its constructor itself.

            coder.extrinsic('dsp.CICCompensationInterpolator.filterPrecision');
            if nargin<2
                % floating-point input
                obj.pFIRInterpolator = dsp.FIRInterpolator(obj.InterpolationFactor, num);
            else
                % fixed-point input

                % compute output data type
                w = fi(num, obj.CoefficientsDataType);  % vector of filter weights of type fi
                if ~isfi(u)
                    x = numerictype(class(u));
                else
                    x = numerictype(u);
                end
                [outputWL, outputFL] = coder.const(@dsp.CICCompensationInterpolator.filterPrecision, ...
                    w, x, obj.InterpolationFactor);
                outputDType = numerictype([], outputWL, outputFL);
 
                obj.pFIRInterpolator = dsp.FIRInterpolator(obj.InterpolationFactor, num,...
                        'CoefficientsDataType', 'Custom', ...
                        'CustomCoefficientsDataType', numerictype([], w.WordLength, w.FractionLength), ...
                        'FullPrecisionOverride', false, ...
                        'OutputDataType', 'Custom', ...
                        'CustomOutputDataType', outputDType, ...
                        'RoundingMethod', obj.RoundingMethod);
            end
            
            if isempty(coder.target)
                % Set fdesign and fmethod on the object
                setMetaData(obj, getfdesign(InterpObj), getfmethod(InterpObj));
                % Set pIsFilterDesigned to true to indicate the filter has
                % been designed
                obj.pIsFilterDesigned = true;
            end
        end
        %------------------------------------------------------------------
        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end
        %------------------------------------------------------------------
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@dsp.internal.CICCompensationBase(obj);
            if isLocked(obj)
                if isempty(obj.pFIRInterpolator)
                    s.pFIRInterpolator = obj.pFIRInterpolator;
                else
                    s.pFIRInterpolator = matlab.System.saveObject(obj.pFIRInterpolator);
                end
            end
            s.pIsFilterDesigned = obj.pIsFilterDesigned;
        end
        %------------------------------------------------------------------
        function loadObjectImpl(obj, s, wasLocked)
            loadObjectImpl@dsp.internal.CICCompensationBase(obj,s,wasLocked);
            if wasLocked
                if isempty(s.pFIRInterpolator)
                    obj.pFIRInterpolator = s.pFIRInterpolator;
                else
                    obj.pFIRInterpolator = matlab.System.loadObject(s.pFIRInterpolator);
                end
            end
        end
        %------------------------------------------------------------------ 
        function postProcessSampleRate(obj,val)
            needToDesignFilters(obj);
            obj.pSR = val;
        end
    end
    %----------------------------------------------------------------------
    % Hidden methods
    %----------------------------------------------------------------------
    methods (Hidden)
        function props = getNonFixedPointProperties(~)
            props = dsp.CICCompensationInterpolator.getDisplayPropertiesImpl;
        end
        %------------------------------------------------------------------
        function FIRInterp = getFilter(obj, varargin)
            %GETFILTER Obtain a clone of the designed filter
            %   FIRInterp = getFilter(obj) returns the underlying filter
            %   'FIRInterp' used to perform the CIC Compensation.
            %
            %   FIRInterp = getFilter(obj, inNT) returns the underlying
            %   filter 'FIRInterp' used to perform the CIC Compensation for
            %   the input numerictype inNT.
            %
            %   Note: This function is not supported to work with code
            %   generation using MATLAB Coder (TM)
            %
            %   % Example: Analysis of filter used as compensator
            %   CICComp = dsp.CICCompensationInterpolator;
            %   FIRInterp = getFilter(CICComp)
            %   fvtool(FIRInterp)
            if nargin > 1
                inNT = varargin{1};
                if isfixed(inNT)
                    designFilter(obj, fi(0, inNT));
                else
                    designFilter(obj);
                end
            else
                designFilter(obj);
            end
            FIRInterp = clone(obj.pFIRInterpolator);
        end
    end
    %----------------------------------------------------------------------
    % Static methods
    %----------------------------------------------------------------------
    methods(Static)
        function helpFixedPoint
            %helpFixedPoint Display CICCompensationInterpolator System
            %               object fixed-point information
            %   dsp.CICCompensationInterpolator.helpFixedPoint displays
            %   information about fixed-point properties and operations of
            %   the CICCompensationInterpolator System object.
            
            matlab.system.dispFixptHelp('dsp.CICCompensationInterpolator', ...
                dsp.CICCompensationInterpolator.getDisplayFixedPointPropertiesImpl);
        end
    end
    %----------------------------------------------------------------------
    % Static hidden methods
    %----------------------------------------------------------------------
    methods (Static, Hidden)
        function [num, InterpObj] = designCompensator(...
                InterpolationFactor, DesignForMinimumOrder, ...
                NumberOfSections, DifferentialDelay, ...
                CICRateChangeFactor, FilterOrder, ...
                Fpass, Fstop, Apass, Astop, SampleRate)
            %designCompensator Design an interpolator using specifications
            %                  and return its numerator coefficients
            
            if DesignForMinimumOrder
                Specification = 'Fp,Fst,Ap,Ast';
                f = fdesign.interpolator(...
                    InterpolationFactor, 'ciccomp', DifferentialDelay, ...
                    NumberOfSections, CICRateChangeFactor, ...
                    Specification, Fpass, Fstop, Apass, Astop, ...
                    SampleRate*InterpolationFactor);
                % Sample rate is multiplied by rate change factor
                % because fdesign.interpolator uses it as Fs_out and
                % not Fs_in
            else
                Specification = 'N,Fp,Ap,Ast';
                f = fdesign.interpolator(...
                    InterpolationFactor, 'ciccomp', DifferentialDelay, ...
                    NumberOfSections, CICRateChangeFactor, ...
                    Specification, FilterOrder, Fpass, Apass, Astop, ...
                    SampleRate*InterpolationFactor);
            end
            
            if DesignForMinimumOrder
                s = warning('off', 'dsp:fdfmethod:eqriplpminisinc:designargs:InvalidFreqFactor');
                try  %#ok
                    if strcmp(s.state, 'on')
                        Fpass_norm = 2*Fpass/(SampleRate*InterpolationFactor);
                        Fstop_norm = 2*Fstop/(SampleRate*InterpolationFactor);
                        fo = Fpass_norm + (Fstop_norm-Fpass_norm)/2;
                        FreqFactor = DifferentialDelay/2;
                        if FreqFactor > 1/fo
                            coder.internal.warning('dsp:system:CICCompensationInterpolator:DifferentialDelayTooLarge');
                        end
                    end
                    InterpObj = design(f, 'SystemObject', true);
                    warning(s);
                catch e
                    warning(s);
                    throw(e);
                end
            else
                InterpObj = design(f, 'SystemObject', true);
            end
            
            num = InterpObj.Numerator;
            
        end
        %------------------------------------------------------------------
        function [outputWL, outputFL] = filterPrecision(w,x,rateChangeFactor)
            %filterPrecision Determine filter precision settings.

            w = dsp.util.padArrayToMultipleOf(w,rateChangeFactor,2);
            wp = reshape(w,rateChangeFactor,length(w)/rateChangeFactor);

            [~,Q] = dsp.internal.FIRFilterPrecision(wp,x);
            outputWL = Q.WordLength;
            outputFL = Q.FractionLength;
        end
    end
    %----------------------------------------------------------------------
    % Static protected methods
    %----------------------------------------------------------------------
    methods(Static,Access=protected)
        function groups = getPropertyGroupsImpl
            CICprops = dsp.internal.CICCompensationBase.getCICProperties;
            FilterProps = dsp.internal.CICCompensationBase.getFilterProperties;
            
            CICSection = matlab.system.display.Section(...
                'Title', getString(message('dsp:system:CICCompensationBase:CICTitleString')), ...
                'PropertyList', CICprops);
            
            filterSection = matlab.system.display.Section(...
                'Title', getString(message('dsp:system:CICCompensationBase:FilterTitleString')), ...
                'PropertyList', [{'InterpolationFactor'}, FilterProps]);
            
            filterVis = dsp.internal.FilterVisualizationButton;
            filterSection.Actions = filterVis.fvtoolAction;
            
            mainSG = matlab.system.display.SectionGroup(...
                'TitleSource', 'Auto', ...
                'Sections', [CICSection filterSection]);
            dtSG = matlab.system.display.internal.DataTypesGroup(...
                'dsp.CICCompensationInterpolator');
            dtSG.PropertyList{2} = matlab.system.display.internal.DataTypeProperty('CoefficientsDataType', ...
                'Prefix', 'coeffs', ...
                'Description', 'Coefficients');
            groups = [mainSG, dtSG];
        end
        %------------------------------------------------------------------
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.CICCompensationInterpolator', ...
                'ShowSourceLink', true, ...
                'Title', getString(message('dsp:system:CICCompensationInterpolator:titleString')),...
                'Text',  getString(message('dsp:system:CICCompensationInterpolator:descriptionString')));
        end
    end
end
