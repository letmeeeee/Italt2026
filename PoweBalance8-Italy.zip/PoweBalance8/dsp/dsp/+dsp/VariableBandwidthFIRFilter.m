classdef (StrictDefaults)VariableBandwidthFIRFilter < dsp.internal.VariableBandwidthFilterBase
%VariableBandwidthFIRFilter Variable bandwidth FIR filter
%   VBFIR = dsp.VariableBandwidthFIRFilter returns a System object, VBFIR, 
%   which independently filters each channel of the input over time using
%   specified FIR filter specifications. The FIR filter's cutoff frequency
%   may be tuned during the filtering operation. The FIR filter is designed
%   using the window method. 
%
%   VBFIR = dsp.VariableBandwidthFIRFilter('Name', Value, ...) returns a 
%   Variable Bandwidth FIR Filter System object, VBFIR, with each specified 
%   property name set to the specified value. You can specify additional 
%   name-value pair arguments in any order as (Name1,Value1,...,NameN,
%   ValueN).
%
%   Step method syntax:
%
%   Y = step(VBFIR, X) filters the real or complex input signal X using the
%   specified filter to produce the output Y. The System object filters
%   each channel of the input signal independently over time.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   VariableBandwidthFIRFilter methods:
%
%   step          - See above description for use of this method
%   release       - Allow property value and input characteristics changes                      
%   clone         - Create Variable Bandwidth FIR Filter object with 
%                   same property values                      
%   isLocked      - Locked status (logical)
%   reset         - Reset the internal states to initial conditions
%
%   VariableBandwidthFIRFilter properties:
%
%   SampleRate                   - Input sample rate
%   FilterType                   - FIR filter type
%   FilterOrder                  - FIR filter order
%   NormalizedFrequency          - Provide normalized frequencies for filter specifications
%   Window                       - Window function
%   KaiserWindowParameter        - Kaiser window parameter
%   SidelobeAttenuation          - Chebyshev window sidelobe attenuation
%   CutoffFrequency              - Filter cutoff frequency
%   CenterFrequency              - Filter center frequency
%   Bandwidth                    - Filter bandwidth            
%
%   This System object supports several filter analysis methods. For more
%   information, type dsp.VariableBandwidthFIRFilter.helpFilterAnalysis
%
%   % Example: Filter a signal through a variable bandwidth bandpass FIR
%   % filter. Tune the center frequency and the bandwidth of the FIR 
%   % filter. 
%   Fs = 44100; % Input sample rate
%   FrameLength = 1024;
%   % Define a bandpass variable bandwidth FIR filter:
%   VBFIR = dsp.VariableBandwidthFIRFilter(FilterType='Bandpass',...
%                                          FilterOrder=100,...
%                                          NormalizedFrequency=false,...
%                                          SampleRate=Fs,...
%                                          CenterFrequency=1e4,...
%                                          Bandwidth=4e3);
%   TFE     = dsp.TransferFunctionEstimator('FrequencyRange','onesided');
%   PLOTTER = dsp.ArrayPlot(PlotType='Line',...
%                           XOffset=0,...
%                           YLimits=[-120 5], ...
%                           SampleIncrement=Fs/FrameLength,...
%                           YLabel='Frequency Response (dB)',...
%                           XLabel='Frequency (Hz)',...
%                           Title='System Transfer Function');
%   SINE = dsp.SineWave(SamplesPerFrame=FrameLength);
%   for index=1:500
%      % Generate input
%      x = SINE() + randn(FrameLength,1);
%      % Pass input through the filter
%      y = VBFIR(x);
%      % Transfer function estimation
%      H = TFE(x,y);
%      % Plot transfer function
%      PLOTTER(20*log10(abs(H)))   
%      % Tune bandwidth and center frequency of the FIR filter
%      if (index==250)
%         VBFIR.CenterFrequency = 5000;
%         VBFIR.Bandwidth = 2000;
%      end
%   end
%
%   See also dsp.VariableBandwidthIIRFilter, dsp.FIRFilter, dsp.IIRFilter, 
%            dsp.BiquadFilter, dsp.AllpoleFilter

%   Copyright 2013-2020 The MathWorks, Inc.

%   References:
%
%   [1] P.Jarske, Y. Neuvo, and S. K. Mitra, "A simple approach to the 
%       design of linear phase FIR digital filters with variable 
%       characteristics", Signal Process. (Elsevier), vol. 14, pp. 313-326,
%       1988.
%

%#codegen
%#ok<*EMCLS>

properties (Nontunable)
  % FilterOrder FIR filter order
  %   Specify the order of the FIR filter as a positive integer scalar. The 
  %   default is 30.
  FilterOrder = 30;
  % Window Window function
  %   Specify the window function used to design the FIR filter as one of 
  %   'Hann' | 'Hamming' | 'Chebyshev' | 'Kaiser'. The default is 'Hann'.
  Window (1, :) char {matlab.system.mustBeMemberMessageID(Window, ...
     {'dsp:system:VariableBandwidthFilter:Window_Hann'; ...
     'dsp:system:VariableBandwidthFilter:Window_Hamming'; ...
     'dsp:system:VariableBandwidthFilter:Window_Chebyshev'; ...
     'dsp:system:VariableBandwidthFilter:Window_Kaiser'})} = 'Hann';  
  % KaiserWindowParameter Kaiser window parameter
  %   Specify the Kaiser window parameter as a real scalar. This property 
  %   applies when you set the  Window property to 'Kaiser'. The default is 
  %   0.5;
  KaiserWindowParameter = .5;
  % SidelobeAttenuation  Chebyshev window sidelobe attenuation (dB)
  %   Specify the Chebyshev window sidelobe attenuation as a real, positive 
  %   scalar in decibels (dB). This property applies when you set the 
  %   Window property to 'Chebyshev'. The default is 60 dB.
  SidelobeAttenuation = 60;
end
properties
  % CutoffFrequency Filter Cutoff frequency 
  %   Specify the filter cutoff frequency as a real, positive scalar
  %   less than SampleRate/2. This property applies when you set the
  %   FilterType property to 'Lowpass' or 'Highpass'. Specify the value of
  %   filter cutoff frequency in Hertz when NormalizedFrequency is set to
  %   false and in normalized units when NormalizedFrequency is set to
  %   true. The default is 512 Hz. This property is tunable.
  CutoffFrequency   = 512;
end
    
properties (Access = private, Nontunable)
  % pPrototypeWindow Window vector
  pPrototypeWindow;
  % pNumTaps Number of filter taps
  pNumTaps;
end

%--------------------------------------------------------------------------
% Public methods
%--------------------------------------------------------------------------
methods
  function obj = VariableBandwidthFIRFilter(varargin)
    % Constructor
    obj@dsp.internal.VariableBandwidthFilterBase(varargin{:})
    if obj.NormalizedFrequency                
        isCutoffFrequencySpecified = false;
        isCenterFrequencySpecified = false;
        isBandwidthSpecified = false;
        for i = 1:2:numel(varargin)
            if strcmp(varargin{i}, 'CutoffFrequency')
                isCutoffFrequencySpecified = true;
            elseif strcmp(varargin{i}, 'CenterFrequency')
                isCenterFrequencySpecified = true;
            elseif strcmp(varargin{i}, 'Bandwidth')
                isBandwidthSpecified = true;
            end
        end
        if ~isCutoffFrequencySpecified
            obj.CutoffFrequency = 512/(44100/2);
        end
        if ~isCenterFrequencySpecified
            obj.CenterFrequency = 11025/(44100/2);
        end
        if ~isBandwidthSpecified
            obj.Bandwidth = 7680/(44100/2);
        end
    end
  end
  %------------------------------------------------------------------------   
  function set.CutoffFrequency(obj,value)
    obj.checkVal(value,'CutoffFrequency');
    obj.CutoffFrequency = value;
  end
  %------------------------------------------------------------------------   
  function set.FilterOrder(obj,value)
    validateattributes(value,{'double','single'}, ...
    {'real','scalar','positive',...
    'integer'},'','FilterOrder');
    coder.internal.errorIf(mod(value,2)~=0,...
           'dsp:system:VariableBandwidthFilter:FIROrderOdd');
    obj.FilterOrder = value;
  end  
  %------------------------------------------------------------------------   
  function set.KaiserWindowParameter(obj,value)
    validateattributes(value,{'double','single'},...
                             {'real','scalar','finite'},...
                             '','KaiserWindowParameter');
    obj.KaiserWindowParameter = value;
  end
  %------------------------------------------------------------------------   
  function set.SidelobeAttenuation(obj,value)
    validateattributes(value,{'double','single'},...
                             {'real','scalar','positive','finite'},...
                             '','SidelobeAttenuation');
    obj.SidelobeAttenuation = value;
  end
  %------------------------------------------------------------------------
  function s = coeffs(obj, varargin)
     if isempty(coder.target)
        % Sim 
        s = coeffs@dsp.internal.VariableBandwidthFilterBase(obj, varargin{:}); 
     else
        % Codegen
        s.Numerator = obj.pfilter.Numerator;
     end
  end
end  
%--------------------------------------------------------------------------
% Protected methods
%--------------------------------------------------------------------------
methods (Access = protected)
  function setupImpl(obj, x)
    % Invoke setupImpl method of base class
    setupImpl@dsp.internal.VariableBandwidthFilterBase(obj,x);
    % Cache the number of filter taps
    obj.pNumTaps =   obj.FilterOrder+1;
    % extrinsic functions for window vector design
    coder.extrinsic('dsp.VariableBandwidthFIRFilter.designWindow');
    coder.extrinsic('dsp.VariableBandwidthFIRFilter.designParametrizedWindow');
    switch obj.Window
        case {'Hamming','Hann'}
            obj.pPrototypeWindow = coder.const(@obj.designWindow,obj.Window,obj.pNumTaps,obj.pDatatype);
        case {'Chebyshev'}
            obj.pPrototypeWindow = coder.const(@obj.designParametrizedWindow,obj.Window,obj.SidelobeAttenuation,obj.pNumTaps,obj.pDatatype);
        case {'Kaiser'}
            obj.pPrototypeWindow = coder.const(@obj.designParametrizedWindow,obj.Window,obj.KaiserWindowParameter,obj.pNumTaps,obj.pDatatype);
    end
    % Instantiate FIR filter with initial dummy numerator (the coefficients
    % will be recomputed in tuneCoefficients
    obj.pfilter = dsp.FIRFilter('Numerator',obj.pPrototypeWindow);
    setup(obj.pfilter,x);
    % Compute coefficients based on cutoff frequency
    tuneCoefficients(obj);
  end
  %------------------------------------------------------------------------
  function processTunedPropertiesImpl(obj)
      % Tune the filter coefficients
      processTunedPropertiesImpl@dsp.internal.VariableBandwidthFilterBase(obj);
  end
  %------------------------------------------------------------------------
  function crossValidateProperties(obj)
    crossValidateProperties@dsp.internal.VariableBandwidthFilterBase(obj);
  end
  %------------------------------------------------------------------------   
  function  tuneCoefficients(obj)
    switch obj.FilterType
        case {'Lowpass','Highpass'}
           % Compute normalized cutoff frequency
           newCutoff =  cast(obj.CutoffFrequency,obj.pDatatype) * 2 / cast(getSampleRate(obj),obj.pDatatype); 
           % Update lowpass filter coefficients
           updateLowpassCoefficients(obj,newCutoff);
           if strcmp(obj.FilterType,'Highpass')
               % update highpass filter coefficients
               updateHighpassCoefficients(obj); 
           end
        case {'Bandpass','Bandstop'}
           % Compute normalized cutoff frequency
           newCutoff =  cast(obj.Bandwidth,obj.pDatatype)  / cast(getSampleRate(obj),obj.pDatatype);
           % Update lowpass filter coefficients
           updateLowpassCoefficients(obj,newCutoff);
           if strcmp(obj.FilterType,'Bandpass')
               % update bandpass filter coefficients
               updateBandpassCoefficients(obj);
           else
               % update bandstop filter coefficients
               updateBandstopCoefficients(obj);
           end
    end
  end
  %------------------------------------------------------------------------     
  function updateLowpassCoefficients(obj,wc2)
    % Tune filter coefficients to new cutoff frequency
    % Compute coefficients of truncated ideal lowpass impulse response
    L = obj.pNumTaps;
    pCoefficients = zeros(1, L, 'like', obj.pPrototypeWindow);
    ind = (L-1)/2 + 1;
    for i= -(L-1)/2:(L-1)/2
    if (i==0)
        pCoefficients(ind + i) = wc2;
    else
        pCoefficients(ind + i) =  sin(wc2*cast(i,obj.pDatatype) *cast(pi,obj.pDatatype)) / (cast(i,obj.pDatatype) *cast(pi,obj.pDatatype));
    end
    end
    % Multiply coefficients by window vector and scale to ensure 0 dB gain
    % at 0 Hz. 
    obj.pfilter.Numerator = obj.pPrototypeWindow .* pCoefficients;
    if sum(obj.pfilter.Numerator) > 0
        obj.pfilter.Numerator = obj.pfilter.Numerator / (sum(obj.pfilter.Numerator));
    end
    
  end
  %------------------------------------------------------------------------   
  function updateBandpassCoefficients(obj)
    % Modulate the lowpass coefficients by 2 * cos(wc.n)
    L = cast(obj.pNumTaps,obj.pDatatype);
    wc = cast(obj.CenterFrequency, obj.pDatatype) * 2 / cast(getSampleRate(obj) , obj.pDatatype);
    obj.pfilter.Numerator = 2 * cos(cast(pi,obj.pDatatype)*wc*(-(L-1)/2 : (L-1)/2)) .* obj.pfilter.Numerator;
  end
  %------------------------------------------------------------------------   
  function updateHighpassCoefficients(obj)
    % Get highpass coefficients from lowpass coefficients (Hhp(w) = 1 -
    % Hlp(w))
    L = cast(obj.pNumTaps,obj.pDatatype);
    b = - obj.pfilter.Numerator;
    % DC
    N = (L - 1) / 2 + 1;
    b(N) = 1 - obj.pfilter.Numerator(N);
    obj.pfilter.Numerator = b;
  end
  %------------------------------------------------------------------------   
  function updateBandstopCoefficients(obj)
    % Modulate the lowpass coefficients by 2 * cos(wc.n) and then flip
    % the frequency response
    L =  cast(obj.pNumTaps,obj.pDatatype);
    wc = cast(obj.CenterFrequency, obj.pDatatype) * 2 / cast(getSampleRate(obj) , obj.pDatatype);
    b = 2 * cos(cast(pi,obj.pDatatype)*wc*(-(L-1)/2 : (L-1)/2)) .* obj.pfilter.Numerator;
    N = (obj.pNumTaps - 1) / 2 + 1;
    b2 = - b;
    b2(N) = 1 - b(N);
    obj.pfilter.Numerator = b2;
  end
  %------------------------------------------------------------------------   
  function y = stepImpl(obj, x)
    % step the FIR filter
    y = step(obj.pfilter,x);
  end
  %------------------------------------------------------------------------          
  function validateFrequencyRange(obj)
    % CutoffFrequency must be less than SampleRate/2
    % This method is invoked in validatePropertiesImpl of the base class
    freqUnits = getFrequencyUnits(obj);
    coder.internal.errorIf(obj.CutoffFrequency > getSampleRate(obj)/2, ...
                          'dsp:system:VariableBandwidthFilter:CharacteristicTooLarge',...
                          'CutoffFrequency',...
                          floor(getSampleRate(obj)),...
                          round((getSampleRate(obj) - floor(getSampleRate(obj))) * 10),...
                          freqUnits);
  end
  %------------------------------------------------------------------------         
  function s = saveObjectImpl(obj)
    s = saveObjectImpl@dsp.internal.VariableBandwidthFilterBase(obj);
    if isLocked(obj)
        s.pPrototypeWindow = obj.pPrototypeWindow;
        s.pNumTaps = obj.pNumTaps;
    end
  end
  %------------------------------------------------------------------------            
  function loadObjectImpl(obj, s, wasLocked)
    if wasLocked
        obj.pPrototypeWindow = s.pPrototypeWindow;
        obj.pNumTaps = s.pNumTaps;
    end
    loadObjectImpl@dsp.internal.VariableBandwidthFilterBase(obj,s,wasLocked);
  end
  %------------------------------------------------------------------------             
  function flag = isInactivePropertyImpl(obj, prop)
    flag = false;
    switch prop
        case {'CutoffFrequency'}
            if ~strcmp(obj.FilterType,'Lowpass') && ...
                ~strcmp(obj.FilterType,'Highpass')
                flag = true;
            end
        case 'SidelobeAttenuation'
            if ~strcmp(obj.Window,'Chebyshev')
                flag = true;
            end
        case 'KaiserWindowParameter'
            if ~strcmp(obj.Window,'Kaiser')
                flag = true;
            end
        case {'SampleRateMode'}
                flag = true;
        otherwise
            flag = isInactivePropertyImpl@dsp.internal.VariableBandwidthFilterBase(obj,prop);
    end
  end
end
%--------------------------------------------------------------------------
% Static, hidden methods
%--------------------------------------------------------------------------
methods (Static, Hidden)
  function d = getdfiltobj(sysObjToAnalyze,arith)
    % Equivalent DFILT object for filter analysis methods
    d = sysObjToAnalyze.pfilter.convertToDFILT(arith);
  end
  %------------------------------------------------------------------------
  function w = designWindow(winType,L,datatype)
    % Design Hamming and Hann windows
    if strcmp(winType,'Hann')
        w = cast(hann(L),datatype).';
    else % hamming
        w = cast(hamming(L),datatype).';
    end
  end
  %------------------------------------------------------------------------
  function w = designParametrizedWindow(winType,winParam,L,datatype)
    % Design Kaiser and Chebyshev 
    if strcmp(winType,'Kaiser')
        w = cast(kaiser(L,winParam),datatype).';
    else % Chebyshev
        w = cast(chebwin(L,winParam),datatype).';
    end
  end
  %------------------------------------------------------------------------
  function checkVal(value,prop)
      validateattributes(value,{'double','single'},...
          {'real','scalar','positive','finite'},...
          '',prop);
  end
end
%--------------------------------------------------------------------------
% Static, Protected methods
%--------------------------------------------------------------------------   
methods(Static, Access=protected)
  function mainS = getPropertyGroupsImpl
    % Modify order of display
    mainS =  matlab.system.display.Section(...
    'Title', getString(message('dsp:system:Shared:Parameters')), ...
    'PropertyList', {'FilterOrder','FilterType','CutoffFrequency',...
    'CenterFrequency','Bandwidth','Window','KaiserWindowParameter','SidelobeAttenuation','NormalizedFrequency','SampleRate'});
  end
end
end
