classdef DynamicFilterVisualizer < dsp.webscopes.FilterVisualizerBaseWebScope
    %DynamicFilterVisualizer Display magnitude response of digital filters
    %   DFV = dsp.DynamicFilterVisualizer returns an object, DFV, that
    %   displays the magnitude response of digital filters or filter
    %   coefficients.
    %
    %   DFV = dsp.DynamicFilterVisualizer(Name=Value, ...) returns a
    %   Dynamic Filter Visualizer object, DFV, with each specified property
    %   name set to the specified value. You can specify name-value pair
    %   arguments in any order as (Name1=Value1, ..., NameN=ValueN).
    %
    %   DFV = dsp.DynamicFilterVisualizer(NFFT, PropertyName=PropertyValue,
    %   ...) returns a Dynamic Filter Visualizer object, DFV, with the
    %   FFTLength property set to NFFT and other specified properties set
    %   to the specified values. NFFT is a value-only argument. You can
    %   specify name-value pair arguments in any order.
    %
    %   DFV = dsp.DynamicFilterVisualizer(NFFT, FS,
    %   PropertyName=PropertyValue, ...) returns a Dynamic Filter
    %   Visualizer object, DFV, with the FFTLength property set to NFFT,
    %   the SampleRate property set to FS and other specified properties
    %   set to the specified values. FS is a value-only argument. You can
    %   specify name-value pair arguments in any order.
    %
    %   DFV = dsp.DynamicFilterVisualizer(NFFT, FS, RANGE,
    %   PropertyName=PropertyValue, ...) returns a Dynamic Filter
    %   Visualizer object, DFV, with the FFTLength property set to NFFT,
    %   the SampleRate property set to FS, the FrequencyRange property set
    %   to RANGE and other specified properties set to the specified
    %   values. RANGE is a value-only argument. You can specify name-value
    %   pair arguments in any order.
    %
    %   Step method syntax:
    %
    %   step(DFV, FILT) displays the magnitude response of the object
    %   filter FILT in the Dynamic Filter Visualizer figure, as long as
    %   FILT has a valid freqz() implementation.
    %
    %   step(DFV, B1, A1, B2, A2, ..., BN, AN) displays the magnitude
    %   response for the digital filters with numerator and denominator
    %   polynomial coefficients stored in B1 and A1, B2  and A2, ..., BN
    %   and AN respectively.
    %
    %   Object may be called directly like a function instead of using the
    %   step method. For example, step(obj, B, A) and obj(B, A) are
    %   equivalent.
    %
    %   DynamicFilterVisualizer methods:
    %
    %   step             - Display magnitude response of input filters
    %   show             - Turn on visibility of Dynamic Filter Visualizer
    %                      figure
    %   hide             - Turn off visibility of Dynamic Filter Visualizer
    %                      figure
    %   isVisible        - Return visibility of Dynamic Filter Visualizer
    %                      figure (logical)
    %   generateScript   - Generate MATLAB(R) script
    %   printToFigure    - Print scope window to a MATLAB(R) figure
    %
    %  DynamicFilterVisualizer properties:
    %
    %   FFTLength             - Number of FFT points
    %   NormalizedFrequency   - Normalized frequency
    %   SampleRate            - Sample rate of input
    %   FrequencyRange        - Range of the frequency axis
    %   XScale                - X-axis scale
    %   MagnitudeDisplay      - Y-axis units
    %   PlotAsMagnitudePhase  - Plot filter response as Magnitude-and-Phase
    %   PlotType              - Option to control the type of plot
    %   AxesScaling           - Axes scaling mode
    %   AxesScalingNumUpdates - Number of updates before scaling
    %   MeasurementChannel    - Channel for which measurement is computed
    %   CursorMeasurements    - Cursor measurements
    %   PeakFinder            - Peak finder measurements
    %   Name                  - Caption to display on Dynamic Filter
    %                           Visualizer window
    %   Position              - Scope window position in pixels
    %   MaximizeAxes          - Maximize axes control
    %   Title                 - Display title
    %   YLimits               - Y-axis limits
    %   ShowLegend            - Show or hide legend
    %   FilterNames           - Names of the input filters
    %   ShowGrid              - Show or hide grid
    %   UpperMask             - Upper limit mask
    %   LowerMask             - Lower limit mask
    %
    %   % Example #1: Plot FIR filter magnitude response
    %       % Create a dsp.DynamicFilterVisualizer object.
    %       dfv = dsp.DynamicFilterVisualizer(YLimits=[-120 10]);
    %
    %       for k = 0.1:0.001:0.5
    %           % Design FIR filter with cutoff frequency equals to k
    %           b = fir1(90, k);
    %           % Plot the magnitude response
    %           dfv(b, 1);
    %       end
    %
    %   % Example #2: Plot dsp.VariableBandwidthFIRFilter magnitude response
    %       % Create a dsp.DynamicFilterVisualizer object.
    %       dfv = dsp.DynamicFilterVisualizer(YLimits=[-120 10]);
    %
    %       % Define a bandpass variable bandwidth FIR filter:
    %       Fs = 44100;
    %       vbw = dsp.VariableBandwidthFIRFilter(FilterType="Bandpass",...
    %       FilterOrder=100,...
    %       SampleRate=Fs,...
    %       CenterFrequency=5e3,...
    %       Bandwidth=4e3);
    %
    %       % Visualize the filter response as the CenterFrequency property
    %       % changes
    %
    %       for idx  = 1:100
    %           dfv(vbw);
    %           vbw.CenterFrequency = vbw.CenterFrequency + 20;
    %       end
    %
    %   See also dsp.ArrayPlot, spectrumAnalyzer, timescope

    %   Copyright 2018-2022 The MathWorks, Inc.

%#function dsp.webscopes.FilterVisualizerBaseWebScope
%#function dsp.webscopes.internal.BaseWebScope
%#function matlabshared.scopes.WebWindow
%#function matlabshared.scopes.WebStreamingSource
%#function utils.getDefaultWebWindowPosition
%#function utils.logicalToOnOff

    methods
        function this = DynamicFilterVisualizer(varargin)
            this@dsp.webscopes.FilterVisualizerBaseWebScope(varargin{:});
        end
    end
end