classdef (StrictDefaults)FIRHalfbandInterpolator < dsp.internal.FIRHalfbandBase
%FIRHalfbandInterpolator Interpolate by a factor of two using polyphase FIR
%   This System object interpolates an input signal using a two branch
%   polyphase structure optimized for halfband filters. All the even
%   indexed samples of halfband filters are zero except the sample at the
%   origin. This System object takes advantage of the zero coefficients,
%   thereby making the second branch of the polyphase structure a delay.
%   With very minimal extra work, this System object can be converted to a
%   Synthesis Filter bank. Filter design is done using optimum equiripple
%   filter design method.
%
%   FIRHALFBANDINTERP = dsp.FIRHalfbandInterpolator returns a FIR halfband
%   interpolator System object, FIRHALFBANDINTERP, that interpolates a
%   signal by a factor 2 using polyphase structure optimized for halfband
%   filters. The filter design parameters are 'TransitionWidth' and
%   'StopbandAttenuation' and the design ensures a minimum order optimum
%   equiripple filter.
%
%   FIRHALFBANDINTERP = dsp.FIRHalfbandInterpolator(Name=Value, ...)
%   returns a FIR Halfband interpolator System object, FIRHALFBANDINTERP,
%   with each specified property set to the specified value.
%
%   Step method syntax:
%
%   Y = step(FIRHALFBANDINTERP,X) outputs the interpolated values, Y, of
%   the input signal, X. A KixN input matrix is treated as N independent
%   channels, and the System object interpolates each channel over time and
%   generates a KoxN output matrix. Ko = 2*Ki, where 2 is the interpolation
%   factor. The object supports real and complex floating-point and
%   fixed-point inputs.
%
%   Y = step(FIRHALFBANDINTERP,X1,X2) computes the output, Y of the
%   Synthesis Filter bank, FIRHALFBANDINTERP. FIRHALFBANDINTERP acts as a
%   Synthesis Filter bank when 'FilterBankInputPort' property of the System
%   object is true. X1 and X2 are two input matrices of same data type and
%   size KixN. N is the number of independent channels in each input
%   signal. System object generates a high pass signal and a low pass
%   signal by subtracting and adding the two baseband input signals
%   respectively, and sends the generated signals through the two branches
%   of the polyphase structure. The output signals from the two branches
%   are commuted to form the resultant signal, Y, a KoxN matrix. Ko = 2*Ki,
%   where 2 is the interpolation factor.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   FIRHalfbandInterpolator methods:
%   step     - See above description for use of this method
%   release  - Allow property value and input characteristics changes
%   clone    - Create FIR Halfband interpolator object with same
%              property values
%   isLocked - Locked status (logical)
%   reset    - Reset the internal states to initial conditions
%
%   FIRHalfbandInterpolator properties:
%
%   SampleRate            - Input sample rate.
%   Specification         - Filter design parameter specification.
%   FilterBankInputPort   - Specify System object to be a Filter bank.
%   FilterOrder           - Order of the filter.
%   StopbandAttenuation   - Minimum attenuation needed in stopband of
%                           the FIR halfband filter.
%   TransitionWidth       - Transition width of the filter in FIR
%                           halfband interpolator.
%   Numerator             - Specified FIR Halfband Coefficients,
%                           when Specification is 'Coefficients'.
%   DesignMethod          - Filter design method, specified as 'Auto',
%                           'Equiripple' or 'Kaiser'.  
%   NormalizedFrequency   - Provide normalized frequencies for filter
%                           specifications
%
%   This System object supports several filter analysis methods. For more
%   information, type dsp.FIRHalfbandInterpolator.helpFilterAnalysis.
%
%   This System object supports fixed-point operations. For more
%   information, type dsp.FIRHalfbandInterpolator.helpFixedPoint.
%
%   % Example 1: Interpolate an input signal by 2
%   Fs1 = 8000;     % Units = Hz
%   TW = 4.1e2;     % Units = Hz
%   order = 52;
%
%   % Construct FIR Half band Interpolator
%   firinterp = dsp.FIRHalfbandInterpolator(...
%       Specification="Filter order and transition width",...
%       FilterOrder=order,...
%       TransitionWidth=TW,...
%       SampleRate=Fs1,...
%       DesignMethod="Equiripple");
%
%   % Visualize its Impulse response
%   fvtool(firinterp,Analysis="Impulse");
%   % Plot the Magnitude and Phase response
%   fvtool(firinterp,Analysis="freq")
%
%   % Interpolated output of a white noise signal
%   x = randn(1024,2);
%   y = firinterp(x);
%   release(firinterp);
%
%   % Example 2: Implement a Quadrature Mirror Filter
%   Fs1 = 8000;     % Units = Hz
%   TW = 4.1e2;     % Units = Hz
%   order = 52;
%
%   % Construct FIR Halfband Interpolator
%   firinterp = dsp.FIRHalfbandInterpolator(...
%       Specification="Filter order and transition width",...
%       FilterOrder=order,...
%       TransitionWidth=TW,...
%       SampleRate=Fs1,...
%       FilterBankInputPort=true);
%
%   % Construct FIR Halfband Decimator
%   firdecim = dsp.FIRHalfbandDecimator(...
%       Specification="Filter order and transition width",...
%       FilterOrder=order,...
%       TransitionWidth=TW,...
%       SampleRate=Fs1);
%
%   % Input
%   f1 = 1000;
%   f2 = 3000;
%   sine = dsp.SineWave(Frequency=[f1,f2],SampleRate=Fs1,...
%   	SamplesPerFrame=1024);
%
%   % Construct Spectrum Analyzer object to view the input and output
%   scope = spectrumAnalyzer(SampleRate=Fs1,...
%       PlotAsTwoSidedSpectrum=false,ShowLegend=true,...
%       YLimits=[-120 30],...
%       Title="Input Signal and Output Signal of Quadrature Mirror Filter", ...
%       ChannelNames=["Input","Output"]);
%
%   % Stream processing loop
%   for k = 1:100
%       input = sum(sine(),2);
%       noisyInput = input + (10^-5)*randn(1024,1);
%       [lowpass, highpass] = firdecim(noisyInput);
%       output = firinterp(lowpass,highpass);
%       scope([noisyInput,output]);
%   end
%
%   See also dsp.FIRHalfbandDecimator, dsp.FIRInterpolator,
%            designHalfbandFIR, 
%            dsp.FIRHalfbandInterpolator.helpFilterAnalysis.

%   Copyright 2014-2023 The MathWorks, Inc.

%#codegen
%#ok<*EMCA>
    
    properties (Nontunable)
        %TransitionWidth Transition width
        %   Specify the transition width for the designed FIR halfband
        %   filter as a finite positive scalar which is less than half the
        %   input sample rate. Specify the value of transition width in
        %   Hertz when NormalizedFrequency is set to false and in
        %   normalized units when NormalizedFrequency is set to true.This
        %   property applies when the Specification is either 'Filter order
        %   and transition width' | 'Transition width and stopband
        %   attenuation'. The default value of this property is 4100Hz.
        TransitionWidth = 4.1e3;
        
        % Numerator Numerator
        %   Specify the FIR Halfband Coefficients. The default value of
        %   this property is designHalfbandFIR(TransitionWidth=0.186, ...
        %   StopbandAttenuation=80, Structure='interp'). This property 
        %   applies when you set Specification to 'Coefficients'.
        Numerator = designHalfbandFIR(TransitionWidth=0.186, StopbandAttenuation=80, Structure='interp');
        
        %FilterBankInputPort Input highpass subband
        %   Specify if the filter should be a Synthesis Filter bank, as a
        %   logical scalar. When this property is set to false, the object
        %   acts as an interpolator. If the property is set to true,
        %   the object acts as a Synthesis Filter bank.
        %   The default of this property is false.
        FilterBankInputPort (1, 1) logical = false;
    end
    
    methods % Set method for non fixed point properties
        
        function obj = FIRHalfbandInterpolator(varargin)
            % Support name-value pair arguments
            obj@dsp.internal.FIRHalfbandBase(varargin{:});
            if obj.NormalizedFrequency  
                isTransitionWidthSpecified = false;
                for i = 1:2:numel(varargin)
                    if strcmp(varargin{i}, 'TransitionWidth')
                        isTransitionWidthSpecified = true;
                    end
                end
                if ~isTransitionWidthSpecified
                    obj.TransitionWidth = 4.1e3/(44100);
                end
            end
        end
        
        %------------------------------------------------------------------
        
        function set.FilterBankInputPort(obj,val)
            obj.FilterBankInputPort = val;
        end
        
        %------------------------------------------------------------------
        
        function set.Numerator(obj,NUMVAL)
            coder.extrinsic('dsp.internal.FIRHalfbandBase.checkNumeratorFormat');
            
            validateattributes(NUMVAL,{'numeric'},{'finite','nonnan',...
                'nonempty','nonsparse','2d','row','vector','real'},'',...
                'Numerator');
            
            % Enforce double precision for stored Numerator values
            % (as well as for checking the formatting assumptions).
            dblNumVals = double(NUMVAL);
            coder.const(@obj.checkNumeratorFormat, dblNumVals, true);
            obj.Numerator = dblNumVals;
            
            needToDesignFilters(obj);
        end
        
        %------------------------------------------------------------------
        
        function set.TransitionWidth(obj,TW)
            validateattributes(TW,{'numeric'},{'finite','scalar',...
                'real','>',0},'','TransitionWidth');
            %cast to enforce double precision on Order
            obj.TransitionWidth = double(TW);
            needToDesignFilters(obj);
        end
        
        %------------------------------------------------------------------
       
        function realizemdl(obj,varargin)
            if obj.FilterBankInputPort
                warning(message('dsp:system:FIRHalfbandInterpolator:realizemdlFilterBank'));
            end
            realizemdl@dsp.internal.FilterAnalysis(obj, varargin{:});
        end
    end
    
    methods (Access=protected)
        
        function validateInputsImpl(obj,varargin)
            Input1 = varargin{1};
            % Check if the input is either numeric or embedded.fi with
            % finite values
            validateInputsImpl@dsp.internal.FIRHalfbandBase(obj, Input1);
            % The user provides two inputs when implementing filter bank
            if nargin == 3
                Input2 = varargin{2};
                % Check if the input is either numeric or embedded.fi with
                % finite values
                validateInputsImpl@dsp.internal.FIRHalfbandBase(obj, Input2);
                
                % Dimensions of both inputs must be the same
                coder.internal.assert(isequal(size(Input1),size(Input2)), ...
                    'dsp:system:SubbandSynthesisFilter:inputsSizeMismatch');
                
                % u1, u2 must both be embedded.fi or both (u)int* or etc.
                u1DType = class(Input1);
                u2DType = class(Input2);
                coder.internal.assert(strcmp(u1DType,u2DType), ...
                    'dsp:system:SubbandSynthesisFilter:inputsDataTypeMismatch2');
                
                if isfi(Input1)
                    % u1, u2 must both be FI with same numerictype
                    coder.internal.assert(isfi(Input2) && ...
                        isequal(numerictype(Input1),numerictype(Input2)), ...
                        'dsp:system:SubbandSynthesisFilter:inputsDataTypeMismatch2');
                end
            end
        end
        
        function validatePropertiesImpl(obj)
            crossValidateProperties(obj);
        end
        
        %------------------------------------------------------------------
        
        function crossValidateProperties(obj)
            if ~(strcmp(obj.Specification, 'Coefficients') || strcmp(obj.Specification, 'Filter order and stopband attenuation'))
                inputFs = getSampleRate(obj);
                if inputFs == -1
                    return;
                end
                outputFs = inputFs*2;
                TW = obj.TransitionWidth;
                coder.internal.errorIf(TW >= outputFs/2, ...
                    'dsp:system:FIRHalfbandInterpolator:TransitionWidth', ...
                    floor(outputFs/2),...
                    round((outputFs/2 - floor(outputFs/2)) * 10));
            end
        end
        
        %------------------------------------------------------------------
        
        function num = getNumInputsImpl(obj)
            num = 1 + obj.FilterBankInputPort;
        end
        
        %------------------------------------------------------------------
        
        function setupImpl(obj,varargin)
            %Defining the System objects
            
            setupImpl@dsp.internal.NormalizedSampleRateEngine(obj,varargin{1});
            
            needToDesignFilters(obj);
            
            % Obtaining the number of channels
            N = getNumChannels(obj,varargin{1});
            obj.NumChannels = int32(N);
            
            if isfloat(varargin{1})
                % Floating-point input
                designFilter(obj,true,varargin{:});
            else
                % Fixed-point input
                obj.pfimath = fimath( ...
                    'SumMode',    'FullPrecision', ...
                    'ProductMode','FullPrecision');

                if (nargin==2)
                    Input = setfimath(varargin{1},obj.pfimath);
                    designFilter(obj,true,Input);
                elseif (nargin==3)
                    Input1 = setfimath(varargin{1},obj.pfimath);
                    Input2 = setfimath(varargin{2},obj.pfimath);
                    designFilter(obj,true,Input1,Input2);
                end
            end
        end
        
        %------------------------------------------------------------------
        
        function outputDType = designObjects(obj,varargin)
            % Remove the zero coefficients
            Coeff1 = obj.Coefficients;
            Coeff2 = Coeff1(Coeff1~=0);
            
            if strcmp(obj.Specification, 'Coefficients')
                % Remove the 1.0 magnitude coefficient;
                % scaling factor is already included:
                Coeff3  = Coeff2(Coeff2~=1.0);
                CoeffHB = Coeff3;
                
                lenObjNum = length(obj.Numerator);
                if isempty(coder.target)
                    % Simulation only (for Filter Analysis functionality)
                    obj.Coefficients(:) = 0;
                    obj.Coefficients(1:lenObjNum) = obj.Numerator;
                end
            else
                % Remove the 0.5 magnitude coefficient, then
                % apply the interpolate-by-two scaling factor:
                Coeff3  = Coeff2(Coeff2~=0.5); 
                CoeffHB = 2*Coeff3;
            end
            
            if nargin < 2
                u1 = [];
                u2 = [];
            elseif nargin < 3
                u1 = varargin{1};
                u2 = [];
            else
                u1 = varargin{1};
                u2 = varargin{2};
            end
            
            if isfloat(u1)
                outputDType = constructFltptHFilter(obj, true, u1, CoeffHB);
            else
                % Fixed-point (includes built-in integer)
                if isempty(coder.target)
                    % MATLAB interpreted mode
                    if isinteger(u1)
                        uNT = numerictype(class(u1));
                    elseif nargin < 3
                        % Only u1 specified (FI)
                        uNT = numerictype(u1);
                    else
                        % Both u1 and u2 specified (FI)
                        uNT = numerictype(u1 + u2);
                    end
                    outputDType = ...
                        mlConstructFixptHFilter(obj, true, ...
                        fi(CoeffHB, obj.CoefficientsDataType), ...
                        CoeffHB, u1, uNT);
                else
                    % CODE GENERATION
                    if nargin < 3
                        outputDType = ...
                            cgConstructFixptHFilter(obj,true,CoeffHB,u1);
                    else
                        outputDType = ...
                            cgConstructFixptHFilter(obj,true,CoeffHB,u1,u2);
                    end
                end
            end
            filterOrder = 2*ceil((length(obj.Coefficients)-1)/2);
            obj.HDelay = dsp.Delay('Length',floor(filterOrder/4));
        end
        
        %------------------------------------------------------------------
        
        function InterpOutput = stepImpl(obj,varargin)
            u1 = varargin{1};
            pisfloat = isfloat(u1);
            isComplexityPropRunning = ...
                ~isempty(coder.target) && eml_ambiguous_complexity;
            
            if ~isComplexityPropRunning
                if (nargin > 1)
                    coder.internal.errorIf( isempty(varargin{1}), ...
                        'dsp:system:Shared:EmptyFirstStep');
                    if (nargin > 2)
                        coder.internal.errorIf( isempty(varargin{2}), ...
                            'dsp:system:Shared:EmptyFirstStep');
                    end
                end
            end
            
            if (nargin == 2)  % Interpolator only
                
                piscomplex = ~isreal(u1);
                
                if pisfloat %Float
                    Input1 = u1;
                else % Fixed
                    if isinteger(u1)
                        Input1 = fi(u1,obj.pfimath,numerictype(class(u1)));
                    else
                        Input1 = setfimath(u1,obj.pfimath);
                    end
                end
                
                if ~isComplexityPropRunning
                    FilterOut = step(obj.HFilter,Input1);
                    DelayOut  = step(obj.HDelay, Input1);
                else
                    % MATLAB Function block complexity propagation
                    FilterOut = Input1;
                    DelayOut  = Input1;
                end
                
                if pisfloat %Float
                    if ~isComplexityPropRunning
                        InterpOutput = ...
                            zeros(2*size(Input1,1), size(Input1,2), ...
                            'like', FilterOut);
                    else
                        % MATLAB Function block type propagation
                        InterpOutput = [Input1; Input1];
                    end
                    FOut = FilterOut;
                    DOut = DelayOut;
                    
                else % Fixed
                    
                    WLIn1        = Input1.WordLength;
                    DelayFL      = DelayOut.FractionLength;
                    InterpOutput = zeros(2*size(Input1,1), size(Input1,2));
                    
                    if piscomplex
                        InterpOutput = fi(complex(InterpOutput), ...
                            numerictype(1,WLIn1,DelayFL));
                    else
                        InterpOutput = fi(InterpOutput, ...
                            numerictype(1,WLIn1,DelayFL));
                    end
                    
                    FOut = quantize(FilterOut, ...
                        numerictype(1,WLIn1,DelayFL), obj.RoundingMethod);
                    
                    DOut = quantize(DelayOut, ...
                        numerictype(1,WLIn1,DelayFL), obj.RoundingMethod);
                                        
                    InterpOutput = removefimath(InterpOutput);
                end
                
                if(obj.IsHalfOrderOdd)
                    InterpOutput(1:2:end,:) = FOut(:,1:size(InterpOutput,2));
                    InterpOutput(2:2:end,:) = DOut(:,1:size(InterpOutput,2));
                else
                    InterpOutput(2:2:end,:) = FOut(:,1:size(InterpOutput,2));
                    InterpOutput(1:2:end,:) = DOut(:,1:size(InterpOutput,2));
                end
                
                if ((piscomplex) && (pisfloat))
                    InterpOutput = complex(InterpOutput);
                end
                
            elseif (nargin == 3) % Synthesis Bank
                u2 = varargin{2};
                piscomplex = ~isreal(u1) || ~isreal(u2);
                if ~isComplexityPropRunning
                    if pisfloat
                        Input1 = u1;
                        Input2 = u2;
                    else % Fixed
                        if isinteger(u1)
                            Input1 = fi(u1, obj.pfimath, ...
                                numerictype(class(u1)));
                            Input2 = fi(u2, obj.pfimath, ...
                                numerictype(class(u2)));
                        else
                            Input1 = setfimath(u1, obj.pfimath);
                            Input2 = setfimath(u2, obj.pfimath);
                        end
                    end
                    
                    if (piscomplex) && (pisfloat)
                        % Complex and Float
                        LPOutput = step(obj.HFilter,complex(Input1+Input2));
                        HPOutput = step(obj.HDelay, complex(Input1-Input2));
                    elseif ~(piscomplex) && (pisfloat)
                        % Real and Float
                        LPOutput = step(obj.HFilter,Input1+Input2);
                        HPOutput = step(obj.HDelay, Input1-Input2);
                    else
                        % Real or Complex and fixed
                        LPOutput = step(obj.HFilter,Input1+Input2);
                        HPOutput = step(obj.HDelay, Input1-Input2);
                    end
                else
                    % Complexity propagation in MATLAB Function block
                    Input1   = u1;
                    Input2   = u2;
                    LPOutput = Input1+Input2;
                    HPOutput = Input1-Input2;
                end
                
                if pisfloat % float
                    InterpOutput = ...
                        zeros(2*size(Input1,1), size(Input1,2), ...
                        'like', LPOutput);
                    LOut = LPOutput;
                    HOut = HPOutput;
                else % fixed
                    WLIn1        = Input1.WordLength;
                    DelayFL      = HPOutput.FractionLength;
                    InterpOutput = zeros(2*size(Input1,1),size(Input1,2));
                    if (piscomplex)
                        InterpOutput = fi(complex(InterpOutput), ...
                            numerictype(1,WLIn1,DelayFL));
                    else
                        InterpOutput = fi(InterpOutput, ...
                            numerictype(1,WLIn1,DelayFL));
                    end
                    
                    LOut = quantize(LPOutput, ...
                        numerictype(1,WLIn1,DelayFL), obj.RoundingMethod);
                    
                    HOut = quantize(HPOutput, ...
                        numerictype(1,WLIn1,DelayFL), obj.RoundingMethod);
                    
                    InterpOutput = removefimath(InterpOutput);
                end
                
                if(obj.IsHalfOrderOdd)
                    InterpOutput(1:2:end,:) = LOut;
                    InterpOutput(2:2:end,:) = HOut;
                else
                    InterpOutput(2:2:end,:) = LOut;
                    InterpOutput(1:2:end,:) = HOut;
                end
                if ((piscomplex) && (pisfloat))
                    InterpOutput = complex(InterpOutput);
                end
            end
        end
        
        %------------------------------------------------------------------
        
        function resetImpl(obj)
            resetImpl@dsp.internal.FIRHalfbandBase(obj);
        end
        
        %------------------------------------------------------------------
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@dsp.internal.FIRHalfbandBase(obj);
        end
        
        %------------------------------------------------------------------
        function loadObjectImpl(obj, s, wasLocked)
            loadObjectImpl@dsp.internal.FIRHalfbandBase(obj,s,wasLocked);
        end   
        function flag = isInactivePropertyImpl(obj, prop)            
            switch prop
                case {'SampleRateMode'}
                    flag = true;
                otherwise
                    flag = isInactivePropertyImpl@dsp.internal.FIRHalfbandBase(obj,prop);
            end
        end
    end
    
    %----------------------------------------------------------------------
    % Hidden methods
    %----------------------------------------------------------------------
    
    methods(Hidden)
        
        function props = getNonFixedPointProperties(~)
            props = dsp.FIRHalfbandInterpolator.getDisplayPropertiesImpl;
        end
        
        function FIRInterp = getFilter(obj)
            %GETFILTER Obtain an mfilt version of interpolator for analysis
            %   FIRInterp = getFilter(obj) returns an dsp.internal.mfilt.firinterp
            %   object that is used in filter analysis
            
            designFilter(obj,true);
            if strcmp(obj.Specification, 'Coefficients')
                % Coefficients are already pre-scaled in this mode
                FIRInterp = dsp.internal.mfilt.firinterp(2,   obj.Coefficients);
            else
                FIRInterp = dsp.internal.mfilt.firinterp(2, 2*obj.Coefficients);
            end
        end

        function [L,M] = rateConversionFactors(obj) %#ok
            nargoutchk(2,2);
            L = 2;
            M = 1;
        end
    end
    
    %----------------------------------------------------------------------
    % Static methods
    %----------------------------------------------------------------------
    methods(Static)
        function helpFixedPoint
            %helpFixedPoint Display FIRHalfbandInterpolator System object
            %               fixed-point information
            %   dsp.FIRHalfbandInterpolator.helpFixedPoint displays
            %   information about fixed-point properties and operations of
            %   the FIRHalfbandInterpolator System object.
            
            matlab.system.dispFixptHelp('dsp.FIRHalfbandInterpolator', ...
                dsp.internal.FIRHalfbandBase.getDisplayFixedPointPropertiesImpl);
        end
    end
    
    
    %----------------------------------------------------------------------
    % Static hidden methods
    %----------------------------------------------------------------------
    
    methods (Static,Hidden)
        function [outputWL, outputFL] = filterPrecision(w,x)
            %filterPrecision Determine filter precision settings.
            coder.extrinsic('dsp.internal.FIRFilterPrecision');
            % No need to take worst-case WL and FL out of each polyphase
            % branch in decimator case because the branch outputs are added
            [A] = dsp.internal.FIRFilterPrecision(w,x);
            
            outputWL = A.WordLength;
            outputFL = A.FractionLength;
        end
        
        function props = getDisplayPropertiesImpl()
            props = {...
                'Specification',...
                'FilterOrder',...
                'TransitionWidth',...
                'StopbandAttenuation',...
                'DesignMethod',...
                'Numerator', ...
                'FilterBankInputPort', ...
                'NormalizedFrequency', ...
                'SampleRate'};
        end
    end
    
    %----------------------------------------------------------------------
    % Static protected methods
    %----------------------------------------------------------------------
    methods(Static,Access=protected)
        function groups = getPropertyGroupsImpl
            props = dsp.FIRHalfbandInterpolator.getDisplayPropertiesImpl;
            
            mainS = matlab.system.display.Section(...
                'Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', props);
            
            filterVis = dsp.internal.FilterVisualizationButton;
            mainS.Actions = filterVis.fvtoolAction;
            
            mainSG = matlab.system.display.SectionGroup(...
                'TitleSource', 'Auto', ...
                'Sections', mainS);
            dtSG = matlab.system.display.internal.DataTypesGroup(...
                'dsp.FIRHalfbandInterpolator');
            dtSG.PropertyList{2} = ...
                matlab.system.display.internal.DataTypeProperty( ...
                'CoefficientsDataType', ...
                'Prefix', 'coeffs', ...
                'Description', 'Coefficients');
            groups = [mainSG, dtSG];
        end
    end
end
