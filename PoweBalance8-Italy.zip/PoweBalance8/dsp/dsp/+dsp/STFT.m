classdef STFT < handle &  matlab.mixin.internal.indexing.Paren ...
                       & matlab.mixin.SetGet
% STFT Short-time FFT
%   STFT = dsp.STFT returns an object, STFT, that implements short-time
%   FFT. The object processes the data independently across each input
%   channel over time.
%
%   STFT = dsp.STFT(WINDOW) returns a short-time FFT object, STFT, with
%   the Window property set to WINDOW.
%
%   STFT = dsp.STFT(WINDOW,OVERLAPLENGTH) returns a short-time FFT object,
%   STFT, with the Window property set to WINDOW, and the OverlapLength
%   property set to OVERLAPLENGTH, respectively.
%
%   STFT = dsp.STFT(WINDOW,OVERLAPLENGTH,NFFT) returns  a short-time FFT
%   object, STFT, with the Window property set to WINDOW, the OverlapLength
%   property set to  OVERLAPLENGTH, and the FFTLength property set to NFFT,
%   respectively.
%
%   STFT = dsp.STFT('Name', Value, ...) returns a short-time FFT object,
%   STFT, with each specified property name set to the specified value.
%   You can specify additional name-value pair arguments in any order as
%   (Name1,Value1,...,NameN, ValueN).
%
%   Step method syntax:
%
%   Y = step(STFT,X) applies short-time FFT on the input X, and returns the
%   frequency-domain output Y. X must be a double-precision or
%   single-precision matrix. The object treats each column as an
%   independent channel. The frame length (number of rows in x) must be
%   equal to or less than the hop length (window length - overlap length).
%   If there are enough samples to form an STFT output, Y is a
%   FFTLength-by-N matrix, where N is the number of input channels. If
%   there are not enough samples to form an STFT output, Y is empty.
%
%   This object may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
% STFT methods:
%
%   step                  - See above description for use of this method
%   release               - Allow property value and input characteristics
%                           to change
%   clone                 - Create STFT object with same property values
%   isLocked              - Locked status (logical)
%   reset                 - Reset the internal states to initial conditions
%   getFrequencyVector    - Get the vector of frequencies at which the
%                           short-time FFT is computed
%
%   STFT properties:
%
%   Window                - Analysis window
%   OverlapLength         - Overlap length
%   FFTLength             - FFT length
%   FrequencyRange        - Frequency range
%
%   % EXAMPLE: Short-time spectral attenuation
%   % Use dsp.STFT and dsp.ISTFT to denoise a signal with wideband
%   % background noise.
%
%   % First, listen to audio signal corrupted by white gaussian noise:
%   FrameLength     = 512;
%   afr = dsp.AudioFileReader('speech_dft.wav',...
%                             'SamplesPerFrame',FrameLength);
%   adw = audioDeviceWriter('SampleRate',22050);
%
%   noiseStd = 0.05;
%   while ~isDone(afr)
%      cleanAudio =  afr();
%      noisyAudio = cleanAudio + noiseStd * randn(FrameLength,1);
%      adw(noisyAudio);
%   end
%
%   reset(afr);
%
%   % Now use stft and istft combined with a gain estimator to remove noise.
%
%   % Define stft parameters:
%   WindowLength    = FrameLength;
%   HopLength       = 16;
%   numHopsPerFrame = FrameLength / 16;
%   FFTLength       = 1024;
%
%   % Define stft and istft objects:
%   win             = hamming(WindowLength,'periodic');
%   stf             = dsp.STFT(win,WindowLength-HopLength,FFTLength);
%   istf            = dsp.ISTFT(win,WindowLength-HopLength,1,0);
%
%   % Define gain estimation parameters:
%   dec      = 16;
%   alpha    = 15;
%   stftNorm = (sum(win.*win) / dec).^2;
%
%   % Perform spectral attenuation
%   while ~isDone(afr)
%     cleanAudio =  afr();
%     noisyAudio = cleanAudio + noiseStd * randn(FrameLength,1);
%
%     y = zeros(FrameLength , 1); % y holds the denoised audio frame
%
%     % Feed audio to stft one hop-length at a time
%     for index = 1:numHopsPerFrame
%
%         X = stf(noisyAudio((index-1)*HopLength+1:index*HopLength));
%
%         % Gain estimator
%         Z = abs(X).^2 / (noiseStd^2 * alpha) / stftNorm;
%         Z(Z<=1) = 1;
%         Z = 1 - 1./Z;
%         Z = sign(Z) .* sqrt(abs(Z));
%         X = X .* Z;
%
%         % Convert back to time-domain
%         y((index-1)*HopLength+1:index*HopLength) = istf(X);
%
%     end
%
%     % Listen to denoised audio:
%     adw(y);
%   end
%
%   See also dsp.ISTFT, dsp.FFT, dsp.IFFT

% Copyright 2018-2020 The MathWorks, Inc.

%#codegen

    properties
        % Window Analysis window
        % Specify the analysis window as a vector of real elements. The
        % object buffers the input to overlapping window segments using the
        % specified window length and overlap length, and then multiplies
        % each overlapped segment by the window. The default is
        % sqrt(hann(512,'periodic')). This property is tunable.
        Window         = sqrt(hann(512,'periodic'))
        % OverlapLength Overlap length
        % Specify the number of samples by which consecutive windows
        % overlap by as a scalar, positive integer. The default is 256.
        OverlapLength  = 256
        % FFTLength FFT length
        % Specify the FFT length as a scalar, positive integer. The default
        % is 512.
        FFTLength      = 512
        %FrequencyRange Frequency range
        % Specify the frequency range as 'onesided' or 'twosided'. If you
        % set the FrequencyRange to 'onesided', the one-sided short-time
        % FFT is computed for real input signals. When the FFT length,
        % NFFT, is even, the short-time FFT length is NFFT/2+1 . If NFFT is
        % odd, the length of the short-time FFT is equal to (NFFT+1)/2. If
        % you set the FrequencyRange to 'twosided', the short-time FFT is
        % computed for complex or real inputs signals. The length of the
        % short-time FFT is equal to NFFT. The default is 'twosided'.
        FrequencyRange{mustBeMember(FrequencyRange,{'onesided','twosided'})}  = 'twosided'
    end

    properties(Access = private)
        % pBuff Buffer holding samples from previous inputs
        pBuff
        % pWindow Private window cast to input datatype
        pWindow = sqrt(hann(512,'periodic'))
        % pIsInitialized Flag is true if step has not been called yet
        pIsInitialized = false
        % pWindowChanged Flag is true if window needs a refresh
        pWindowChanged = false
        % pWindowLength numel(Window)
        pWindowLength = 512
        % pHopLength  WindowLength - OverlapLength
        pHopLength    = 256
        % pNumFrequencySamples Num frequency samples
        pNumFrequencySamples
    end

    properties (Constant, Hidden)
        % FrequencyRange ENUM set used for tab completion
        FrequencyRangeSet = {'onesided', 'twosided'};
    end

    methods

        % Constructor
        function obj = STFT(varargin)

            p = inputParser;

            addOptional(p,'Window', sqrt(hann(512,'periodic')), @isnumeric);
            addOptional(p,'OverlapLength', 256, @isnumeric);
            addOptional(p,'FFTLength', 512, @isnumeric);
            addParameter(p,'FrequencyRange', 'twosided', @isCharOrString);
            % Parse Inputs
            parse(p, varargin{:});
            results = p.Results;

            % Set property values
            obj.Window         = results.Window;
            obj.OverlapLength  = results.OverlapLength;
            obj.FFTLength      = results.FFTLength;
            obj.FrequencyRange = results.FrequencyRange;
        end

        % Set methods
        function set.Window(obj,val)
            validateattributes(val,{'numeric'}, ...
                {'vector','real','nonnan'}, ...
                'set.Window','Window');
            obj.Window = val;

            obj.pWindowChanged = true; %#ok
        end

        function set.OverlapLength(obj,val)

            coder.internal.errorIf(obj.pIsInitialized,'MATLAB:system:propertySetWhenLocked'); %#ok

            validateattributes(val,{'numeric'}, ...
                {'scalar','integer','nonnegative','real','nonnan'}, ...
                'set.OverlapLength','OverlapLength');
            obj.OverlapLength = val;
        end

        function set.FFTLength(obj,val)

            coder.internal.errorIf(obj.pIsInitialized,'MATLAB:system:propertySetWhenLocked'); %#ok

            validateattributes(val,{'numeric'}, ...
                {'scalar','integer','positive','real','nonnan'}, ...
                'set.FFTLength','FFTLength');
            obj.FFTLength = val;
        end

        function set.FrequencyRange(obj,val)
            coder.internal.errorIf(obj.pIsInitialized,'MATLAB:system:propertySetWhenLocked'); %#ok
             % Add String Support
            val = convertStringsToChars(val);
            obj.FrequencyRange = val;
        end

        function F = getFrequencyVector(obj,varargin)
        % getFrequencyVector Get the vector of frequencies at which the
        % short-time FFT is computed.
        %
        % f = getFrequencyVector(OBJ) returns the frequency vector at which
        %   the short-time FFT is computed. The sampling frequency used is
        %   2 * pi.
        %
        % f = getFrequencyVector(OBJ,FS) returns the frequency vector at
        %   which the short-time FFT is computed. The sampling frequency
        %   used is FS.
        %
        %   If you set the FrequencyRange to 'onesided' and the FFT length,
        %   NFFT, is even, the frequency vector is of length NFFT/2+1 and.
        %   If you set the FrequencyRange to 'onesided' and NFFT is odd,
        %   the frequency vector is of length (NFFT+1)/2. If you set the
        %   FrequencyRange to 'twosided', the frequency vector is of length
        %   NFFT.
        %
        % % Example: Get the frequency vector at which the short-time FFT
        % % is computed
        %
        % Fs = 44100;
        % stf = dsp.STFT;
        % f = getFrequencyVector(stf,Fs);

            pCenterDC = false;
            Npts      = obj.FFTLength;

            if nargin == 1
                Fs = 2 * pi;
            else
                Fs = varargin{1};
                validateattributes(Fs,{'single','double'}, {'positive','real','scalar','finite','nonnan'},'','sampling frequency');
            end

            F = dsp.internal.SpectrumEstimatorBase.frequencygrid...
                (isOneSided(obj),Npts,Fs,pCenterDC);
        end

    end

    methods(Access = protected)

        function setupImpl(obj,u)
            obj.pWindowLength = numel(obj.Window);
            validatePropertiesImpl(obj);
            obj.pBuff         = dsp.AsyncBuffer('Capacity',obj.pWindowLength);
            obj.pHopLength    = obj.pWindowLength - obj.OverlapLength;
            win               = cast(reshape(obj.Window,numel(obj.Window),1),class(u));
            obj.pWindow       = repmat(win,1,size(u,2));
            obj.pWindowChanged = false;
            obj.pNumFrequencySamples = getNumFrequencySamples(obj);
        end

        function validatePropertiesImpl(obj)
           coder.internal.errorIf(obj.FFTLength < obj.pWindowLength, ...
                'dsp:system:STFT:FFTLengthTooShort')

           coder.internal.errorIf(obj.OverlapLength >= obj.pWindowLength, ...
                'dsp:system:STFT:OverlapTooLong')
        end

        function validateInputsImpl(obj,u)
            coder.internal.errorIf(size(u,1) > numel(obj.Window) - obj.OverlapLength, ...
                'dsp:system:STFT:InputLengthTooLong')
            coder.internal.errorIf(~isreal(u) && obj.isOneSided(), ...
                'dsp:system:STFT:InvalidInputDataTypeWithOnesided')
        end

        function flag = isOneSided(obj)
            flag = strcmpi(obj.FrequencyRange,'onesided');
         end

         function nSamples = getNumFrequencySamples(obj)
             % Return the number of frequency samples based on the
             % FrequencyRange and FFTLength
             nSamples = obj.FFTLength;
             if isOneSided(obj)
                 if mod(nSamples,2) == 0
                     % For even NFFT choose samples from 1 to NFFT/2  + 1
                     nSamples = nSamples/2 + 1;
                 else
                     % For odd NFFT choose samples from 1 to (NFFT + 1)/2
                     nSamples = (nSamples + 1)/2;
                 end
             end
         end

    end

    methods

        function Y = step(obj,u)
        %     Y = step(OBJ,x) processes the input data, x, to produce the
        %     output, Y, for object, OBJ.

             % Validate inputs to the step method at initialization.
            if ~obj.pIsInitialized
                validateattributes(u,{'double','single'}, {'2d',...
                    'nonsparse'},'','input');
                setupImpl(obj,u);
                obj.pIsInitialized = true;
            end

            if obj.pWindowChanged
                win                = cast(reshape(obj.Window,numel(obj.Window),1),class(u));
                obj.pWindow        = repmat(win,1,size(u,2));
                obj.pWindowChanged = false;
            end
            % validate input
            validateInputsImpl(obj,u);
            % Write data to buffer
            write(obj.pBuff,u);
            NFFT = obj.FFTLength;
            if obj.pBuff.NumUnreadSamples >= obj.pHopLength
                % If data in buffer is greater than or equal to hop length
                % read data in buffer
                y = read(obj.pBuff ,obj.pWindowLength , obj.OverlapLength);
                y = y .* obj.pWindow;
                yTwoSided = fft(y,NFFT);
                Y = yTwoSided(1:obj.pNumFrequencySamples,:);
            else
                Y = complex(zeros(obj.pNumFrequencySamples,0,class(u)));
            end
        end

        function reset(obj)
            % reset Reset the internal states of the object
            reset(obj.pBuff);
        end

        function release(obj)
            % release Allow property value and input characteristics
            % changes
            release(obj.pBuff);
            obj.pIsInitialized = false;
        end

        function newSTFT = clone(obj)
            % clone Create object with same property values
            %  C = clone(OBJ) creates another instance of the object, OBJ,
            %  with the same property values. If OBJ is locked, the clone
            %  method creates a copy that is also locked and has states
            %  initialized to the same values as the original. If OBJ is not
            %  locked, the clone method creates a new unlocked object with
            %  uninitialized states.
            newSTFT = dsp.STFT(obj.Window,obj.OverlapLength,obj.FFTLength, ...
                  'FrequencyRange',obj.FrequencyRange);
            newSTFT.pIsInitialized = obj.pIsInitialized;
            if isLocked(newSTFT)
                newSTFT.pBuff = clone(obj.pBuff);
            end
            newSTFT.pWindow = obj.pWindow;
            newSTFT.pHopLength = obj.pHopLength;
            newSTFT.pWindowLength = obj.pWindowLength;
            newSTFT.pWindowChanged = obj.pWindowChanged;
            newSTFT.pNumFrequencySamples = obj.pNumFrequencySamples;
        end

        function l = isLocked(obj)
            % isLocked Locked status for input attributes and non-tunable
            % properties
            l = obj.pIsInitialized;
        end

        function varargout = set(obj, varargin)
            % Overload set() to enable tab completion of string property
            % values
            if nargin == 2 && ischar(varargin{1})
                switch varargin{1}
                    case {'FrequencyRange'}
                        varargout{1} = obj.([varargin{1} 'Set']);
                    otherwise
                        varargout{1} = [];
                end
            else
                if nargout
                    varargout{1} = set@matlab.mixin.SetGet(obj, varargin{:});
                else
                    set@matlab.mixin.SetGet(obj, varargin{:});
                end
            end
        end
    end

    methods (Hidden)
        function n = getNumInputs(~)
           n = 1;
        end

        function n = getNumOutputs(~)
           n = 1;
        end

        function n = nargin(~)
           n = 1;
        end

        function flag = isInactiveProperty(~,~)
            flag = false;
        end

        function props = getValueOnlyProps(~)
           props = {'Window','OverlapLength','FFTLength'};
        end
    end

    %----------------------------------------------------------------------
    % Hidden, Sealed methods
    %----------------------------------------------------------------------
    methods  (Hidden=true,Sealed=true)
        function Y = parenReference(obj,u)
            % This is used to enable stepping the object with function
            % notation.
            Y = step(obj,u);
        end
    end

    methods (Access = public, Hidden, Static)
        function name = matlabCodegenRedirect(~)
            name = 'dsp.internal.STFTCG';
        end
    end
end
%--------------------------------------------------------------------------
% Helper methods
%--------------------------------------------------------------------------
function flag = isCharOrString(value)
flag = ischar(value) || isstring(value);
end
%--------------------------------------------------------------------------