classdef (StrictDefaults)ColoredNoise < matlab.System & ...
                        matlab.system.mixin.FiniteSource
%ColoredNoise Generate a colored noise signal
%  CN = dsp.ColoredNoise returns a colored noise object, CN, that outputs a
%  noise signal one sample or frame at a time, with a 1/f^alpha spectral
%  characteristic over its entire frequency range. Typical values for alpha
%  are: alpha = 1 (pink noise), alpha = 2 (Brownian noise).
%
%  CN = dsp.ColoredNoise(Name=Value, ...) returns a colored noise object,
%  CN, with each specified property set to a specified value.
%
%  CN = dsp.ColoredNoise(POW,SAMP,CHAN,Name=Value) returns a colored noise
%  object, CN, with InverseFrequencyPower property set to POW,
%  SamplesPerFrame property set to SAMP, NumChannels property set to CHAN
%  and other specified properties set to specified values. Alternatively,
%  POW can be set to a color by name, such as "pink".
%
%  The ColoredNoise object uses the default MATLAB random stream. Reset
%  the default stream for repeatable simulations. Type 'help RandStream'
%  for more information.
%
%  Step method syntax:
%
%  Y = step(CN) outputs one sample or frame of data, Y.
%
%  Y = step(CN,L) outputs one frame of data, Y, of length L. This syntax
%  applies when SamplesPerFrameSource is 'Input port'.
%
%  System objects may be called directly like a function instead of using
%  the step method. For example, y = step(obj) and y = obj() are
%  equivalent.
%
%  ColoredNoise methods:
%
%  step     - Generate colored noise signal
%  release  - Allow property value and input characteristics changes
%  clone    - Create colored noise object with same property values
%  isLocked - Locked status (logical)
%  reset    - Reset the generator internal states and the random number
%             stream if the RandomStream property is set to
%             'mt19937ar with seed'
%
%  ColoredNoise properties:
%
%  Color                 - Noise Color
%  InverseFrequencyPower - Define alpha, inverse frequency power in
%                          spectral characteristic 1/f^alpha.
%  BoundedOutput         - Guarantee the output is bounded (+/-1)
%  NumChannels           - Number of output channels
%  SamplesPerFrameSource - Source of number of samples per frame
%  SamplesPerFrame       - Number of samples per output channel
%  MaxSamplesPerFrame    - Maximum number of samples per output channel
%  OutputDataType        - Output data type
%  RandomStream          - Source of random number stream
%  Seed                  - Initial seed of mt19937ar random number stream
%
%  % EXAMPLE: Define a pink noise generator to output 2 channels of 1024
%  % noise samples and compute the power spectrum of the averaged signal 
%  % using a spectrum analyzer:
%
%  pn = dsp.ColoredNoise("pink",1024,2);
%  scope = spectrumAnalyzer(SpectrumType="power-density", ...
%      Method="welch", ....
%      PlotAsTwoSidedSpectrum=false, ...
%      FrequencyScale="log", ...
%      OverlapPercent=50, ...
%      Window="hamming", ...
%      YLimits=[-20,25]);
%  tic
%  while toc < 30    % Run for 30 seconds
%      pink = pn();  % pink is a 1024-by-2 frame of samples
%      scope(pink);
%  end

%  Copyright 2013-2022 The MathWorks, Inc.

%#codegen
%#ok<*EMCA>
   
    properties (Nontunable)
        % Color Noise color
        %   Specify the noise color as one of 'pink'|'white'|'brown'|'blue'
        %   |'purple'|'custom'. Each color is associated with an inverse 
        %   frequency power of the generated noise sequence.
        %   For pink noise, set Color to 'pink'. The inverse frequency 
        %   power of pink noise is equal to 1. 
        %   For white noise, set Color to 'white'. The inverse frequency 
        %   power of white noise is equal to 0.
        %   For brown noise (also called red or Brownian noise), set 
        %   Color to 'brown'. The inverse frequency power of brown noise
        %   is equal to 2.
        %   For blue noise (also called azure noise), set Color to 
        %   'blue'.  The inverse frequency power of blue noise is equal to 
        %   -1.
        %   For purple noise (also called violet noise), set Color to 
        %   'purple'. The inverse frequency power of purple noise is equal 
        %   to -2.
        %   For noise with a custom inverse frequency power, set Color to 
        %   'custom'. In this case, the inverse frequency power is equal
        %   to the value specified in InverseFrequencyPower. 
        %   InverseFrequencyPower can be any value in the interval [-2,2].
        %   InverseFrequencyPower is relevant only when Color is set to
        %   'custom'.
        %   The default of this property is 'custom'
        Color = 'custom'
        %InverseFrequencyPower  Power of inverse frequency
        %   Specify alpha in the 1/f^alpha spectral characteristic of the
        %   generated noise sequence over its entire frequency range.
        %   InverseFrequencyPower can be any value in the interval [-2,2].
        %   This property is relevant when the Color property is 'custom'. 
        %   The default value is 1 (pink noise).
        InverseFrequencyPower  = 1
        %SamplesPerFrameSource Samples per frame source
        %   Specify the source of the number of samples per frame as one of
        %   'Property' or 'Input port'. The default is 'Property'.
        SamplesPerFrameSource (1,:) char {mustBeMember(SamplesPerFrameSource,{'Property' 'Input port' })} = 'Property'
        %SamplesPerFrame Number of samples per output channel
        %   Specify the number of samples to buffer into each output
        %   channel. This property applies when you set
        %   SamplesPerFrameSource to 'Property'. The default value is 1024.
        SamplesPerFrame = 1024
        % MaxSamplesPerFrame Maximum samples per frame 
        %   Specify the maximum number of samples per frame. This property
        %   applies when SamplesPerFrameSource is set to 'Input port'. The
        %   default value is 192000.
        MaxSamplesPerFrame = 192000
        %NumChannels Number of output channels
        %   Specify the number of output channels as an integer.
        %   The default value is 1.
        NumChannels = 1
        %RandomStream Random number source
        %   Specify the source of random number stream as one of
        %   'Global stream' | 'mt19937ar with seed'. If RandomStream is set
        %   to 'Global stream', the current global random number stream is
        %   used for normally distributed random number generation. If
        %   RandomStream is set to 'mt19937ar with seed', the mt19937ar
        %   algorithm is used for normally distributed random number
        %   generation, in which case the reset method re-initializes the
        %   random number stream to the value of the Seed property.
        %   The default value is 'Global stream'.
        RandomStream = 'Global stream'
        %Seed Initial seed
        %   Specify the initial seed of a mt19937ar random number generator
        %   algorithm as a double precision, real, nonnegative integer
        %   scalar. This property applies when you set the RandomStream
        %   property to 'mt19937ar with seed'. The Seed is to re-initialize
        %   the mt19937ar random number stream in the reset method.
        %   The default value is 67.
        Seed = 67
        %OutputDataType Output data type
        %   Specify the output data type as one of 'double' | 'single'.
        %   The default value is 'double'.
        OutputDataType = 'double'
    
        %BoundedOutput Guarantee the output is bounded (+/-1)
        %   Specify if the output is bounded inside +1 and -1 as true or
        %   false. If true, the internal random source is uniform instead
        %   of Gaussian, and a gain is applied so that the absolute maximum
        %   output never exceeds 1. For example, if COLOR is set to
        %   'white', there is no color filter and the output is uniform
        %   noise of amplitude +1 to -1. The output distribution of
        %   filtered noise (ex. pink noise) is quasi- Gaussian. The bounded
        %   output option is useful for applications such as digital audio,
        %   where the signal must be guaranteed to never exceed a certain
        %   value. The default value is 'false'.
        BoundedOutput (1, 1) logical = false
    end
    
    properties (Access = private, Constant)
       % All-zero filter length
       pMAFilterLength = 256
       % All-pole filter length
       pARFilterLength = 64
    end
    
    properties (Constant, Hidden)
        OutputDataTypeSet = matlab.system.StringSet({...
            'double', ...
            'single'});
        RandomStreamSet = matlab.system.StringSet({...
            'Global stream', ...
            'mt19937ar with seed'});
        ColorSet = matlab.system.StringSet( { ...
            'white',...
            'pink', ...
            'brown',...
            'blue',...
            'purple',...
            'custom'} );
    end

    properties (SetAccess=private, GetAccess = protected, Nontunable)
        %Filter coefficients, impulse response length and gain
        pNumFilterCoef
        pDenFilterCoef
        pOutputGain
    end
    
    properties (SetAccess=private, GetAccess = protected)
        %pFilterStates Holds internal filter states
        pFilterStates
        % Random number generator state
        pWNState
        % Random stream object (used in 'mt19937ar with seed' mode)
        pStream
    end

    methods
        % Constructor
        function obj = ColoredNoise(varargin)
            firstparams = {'InverseFrequencyPower','Color'};
            isIfp = nargin >= 1 && isnumeric(varargin{1});
            setProperties(obj, nargin, varargin{:}, ...
                          firstparams{[isIfp ~isIfp]}, ...
                          'SamplesPerFrame', ...
                          'NumChannels');
        end
        
        function set.SamplesPerFrame(obj, val)
            validateSamplesPerFrame(obj,val);
            obj.SamplesPerFrame = val;
        end

        function set.MaxSamplesPerFrame(obj, val)
            validateattributes(val, ...
                {'numeric'}, ...
                {'nonnegative', 'integer', 'scalar'}, ...
                'set.MaxSamplesPerFrame', ...
                'MaxSamplesPerFrame');
            obj.MaxSamplesPerFrame = val;
        end
        
        function set.NumChannels(obj, val)
            validateattributes(val, ...
                {'numeric'}, ...
                {'positive', 'integer', 'scalar'}, ...
                'set.NumChannels', ...
                'NumChannels');
            obj.NumChannels = val;
        end        

        function set.InverseFrequencyPower(obj, val)
            validateattributes(val, ...
                {'numeric'}, ...
                {'real', 'scalar', 'finite', '>=', -2, '<=', 2}, ...
                'set.InverseFrequencyPower ', ...
                'InverseFrequencyPower ');
            obj.InverseFrequencyPower = val;
        end
        
        function set.Seed(obj, val)
            validateattributes(val, ...
                {'double'}, ...
                {'real', 'scalar', 'integer', 'nonnegative', 'finite'}, ...
                'set.Seed', ...
                'Seed');
            obj.Seed = val;
        end
    end

    methods (Access=protected)

        function flag = isInactivePropertyImpl(obj, prop)
            % Seed is unused when RandomStream is set to 'Global stream'
            flag = false;
            if strcmp(prop, 'Seed')
                flag = strcmp(obj.RandomStream, 'Global stream');
            elseif strcmp(prop, 'InverseFrequencyPower')
                flag = ~strcmp(obj.Color, 'custom');
            elseif strcmp(prop, 'SamplesPerFrame')
                flag = strcmp(obj.SamplesPerFrameSource, 'Input port');
            elseif strcmp(prop, 'MaxSamplesPerFrame')
                flag = strcmp(obj.SamplesPerFrameSource, 'Property');
            end
        end
      
        function s = saveObjectImpl(obj)

            % Default implementation saves all public properties
            s = saveObjectImpl@matlab.System(obj);

            % Save private properties
            if isLocked(obj)
                s.pOutputGain = obj.pOutputGain;
                s.pFilterStates = obj.pFilterStates;
                s.pNumFilterCoef = obj.pNumFilterCoef;
                s.pDenFilterCoef = obj.pDenFilterCoef;
                % Save state of the local random stream
                if strcmp(obj.RandomStream, 'mt19937ar with seed')
                    if ~isempty(obj.pStream)
                        s.pWNState = obj.pStream.State;
                    else
                        s.pWNState = [];
                    end
                end
            end
            
        end
        
        function loadObjectImpl(obj, s, wasLocked)
            
            % Call base class method
            % Load this first so "getInverseFrequencyPower" has the data it needs
            loadObjectImpl@matlab.System(obj, s, wasLocked);       
            
            % Re-load private properties
            if wasLocked
                obj.pFilterStates = s.pFilterStates;
                if isfield(s,'pOutputGain') % if loading an older object, this was not there
                    obj.pOutputGain = s.pOutputGain;
                else % set default for gain property that did not exist before
                    obj.pOutputGain = cast(1,obj.OutputDataType);
                end
                obj.pNumFilterCoef = s.pNumFilterCoef;
                obj.pDenFilterCoef = s.pDenFilterCoef;
                % Restore random stream object to the saved state
                if strcmp(s.RandomStream, 'mt19937ar with seed')
                    obj.pStream = RandStream('mt19937ar', 'seed', obj.Seed);
                    if ~isempty(s.pWNState)
                        obj.pStream.State = s.pWNState;
                    end
                end
            end
            
        end

        function invPowerFreq = getInverseFrequencyPower(obj)
            % Return inverse frequency power based on selected noise color
            DT = obj.OutputDataType;
            switch obj.Color
                case 'pink'
                    invPowerFreq = cast(1, DT);
                case 'brown'
                    invPowerFreq = cast(2, DT);
                case 'white'
                    invPowerFreq = cast(0, DT);
                case 'blue'
                    invPowerFreq = cast(-1, DT);
                case 'purple'
                    invPowerFreq = cast(-2, DT);
                case 'custom'
                    invPowerFreq = cast(obj.InverseFrequencyPower, DT);
            end
        end
        
        % Setup function (needs to be outside setupImpl to help codegen)
        function [num,den] = getFilt(obj)
            % Filter design function for 1/f^alpha power law

            % Reference for design of 1/f^alpha power law with any alpha
            % N. Jeremy Kasdin, Discrete Simulation of Colored Noise and
            % Stochastic Processes and 1/f^alpha Power Law Noise
            % Generation. IEEE, 1995.
            %
            % Use all-zero model for negative alpha
            % Use all-pole model for positive alpha
            %
            % The MA filter numerator is given by the following formula:
            % num(0)=1, num(k)= (alpha/2 + k - 1)*num(k-1)/k, where alpha is
            % the inverse frequency power.
            %
            % The AR filter denominator is given by the following formula:
            % den(0)=1, den(k)= (k-1-alpha/2)*den(k-1)/k, where alpha is
            % the inverse frequency power.
            
            DT = obj.OutputDataType;
            ifp = getInverseFrequencyPower(obj);
            
            if ifp < cast(0,DT)
                L = obj.pMAFilterLength;
                den = cast(1,DT);
                if ifp == cast(-2, DT) % purple noise special case
                    num = [cast(1,DT), cast(-1,DT)];
                else
                    num = zeros(1,L,DT);
                    num(1) = cast(1,DT);
                    for idx = 2:L
                        num(idx) = (ifp/cast(2,DT) + cast(idx,DT) - cast(2,DT)) * num(idx-1)/cast(idx-1,DT);
                    end
                end
            elseif ifp > cast(0,DT)
                num = cast(1,DT);
                L = obj.pARFilterLength;
                den = ones(1,L,DT);
                for idx = 2:L
                    den(idx) = (cast(idx-2,DT) - ifp/cast(2,DT)) * den(idx-1) / cast(idx-1,DT);
                end
            else % white noise
                num = cast(1,DT);
                den = cast(1,DT);
            end
            
        end
        
        function setupImpl(obj)
            
            DT = obj.OutputDataType;
            ifp = getInverseFrequencyPower(obj);
            
            coder.extrinsic('dsp.internal.getColoredFilter');
            
            if ifp == cast(1,DT) % pink
                [obj.pNumFilterCoef,gb] = coder.const(@dsp.internal.getColoredFilter,'pink',DT);
                if obj.BoundedOutput
                    obj.pOutputGain = gb;
                else
                    obj.pOutputGain = cast(1,DT);
                end
            elseif ifp == cast(2,DT) % brown
                [obj.pNumFilterCoef,gb] = coder.const(@dsp.internal.getColoredFilter,'brown',DT);
                if obj.BoundedOutput
                    obj.pOutputGain = gb;
                else
                    obj.pOutputGain = cast(1,DT);
                end
            else % another color (including white)
                [obj.pNumFilterCoef,obj.pDenFilterCoef] = getFilt(obj);
                if obj.BoundedOutput
                    % Gain equivalent to 1 over the l1 norm of filter
                    if ifp >= cast(0,DT) 
                        obj.pOutputGain = sum(obj.pDenFilterCoef);
                    else
                        obj.pOutputGain = cast(1,DT) / sum(abs(obj.pNumFilterCoef));
                    end
                else
                    obj.pOutputGain = cast(1,DT);
                end
            end
            
        end
        
        function resetImpl(obj)

            % Reset Random Stream
            if strcmp(obj.RandomStream, 'mt19937ar with seed') && isempty(coder.target)
                obj.pStream = RandStream('mt19937ar', 'seed', obj.Seed);
            end
            if ~isempty(coder.target)
                obj.pWNState = eml_rand_mt19937ar('preallocate_state');
                if strcmp(obj.RandomStream, 'mt19937ar with seed')
                    obj.pWNState = eml_rand_mt19937ar('seed_to_state', obj.pWNState, obj.Seed);
                end
            elseif strcmp(obj.RandomStream, 'mt19937ar with seed')
                obj.pStream.reset();
            end
            
            % Reset filter states
            DT = obj.OutputDataType;
            ns = size(obj.pNumFilterCoef);
            if ns(1) > 1 % sos filter
                obj.pFilterStates = zeros(2,obj.NumChannels,ns(1),DT);
            else
                stsize = ns(2) + size(obj.pDenFilterCoef,2) - 2;
                obj.pFilterStates = zeros(stsize, obj.NumChannels, obj.OutputDataType);
            end
            
        end
        
        function x = getExcitationNoise(obj,varargin)

            DT = obj.OutputDataType;
            nch = obj.NumChannels;
            if nargin==1
                spf = obj.SamplesPerFrame;
            else
                val = varargin{1};
                validateSamplesPerFrame(obj,val);
                spf = min(val,obj.MaxSamplesPerFrame);
            end
            % Noise (random number) generation
            if strcmp(obj.RandomStream, 'Global stream')
                if obj.BoundedOutput
                    x = rand(spf, nch, DT) * 2 - 1;
                else
                    x = randn(spf, nch, DT);
                end
            elseif isempty(coder.target)
                if obj.BoundedOutput
                    x = rand(obj.pStream, spf, nch, DT) * 2 - 1;
                else
                    x = randn(obj.pStream, spf, nch, DT);
                end
            else % code generation version
                % Noise is generated column-wisely
                x = coder.nullcopy(zeros(spf, nch, DT));
                state = obj.pWNState;
                dists = {'generate_uniform','generate_normal'};
                bo = obj.BoundedOutput;
                rdist = dists{[bo ~bo]};
                for c = 1:nch
                    for r = 1:spf
                        [state, x(r,c)] = eml_rand_mt19937ar(rdist,state,DT);
                    end
                end
                if bo
                    x = x * 2 - 1;
                end
                obj.pWNState = state;
            end
        end

        function n = getNumInputsImpl(obj)
            n = double(strcmp(obj.SamplesPerFrameSource,'Input port'));
        end

        function out = stepImpl(obj,varargin)
            
            % Create random vector
            out = getExcitationNoise(obj,varargin{:});
            
            % Create colored noise from excitation
            num = obj.pNumFilterCoef;
            ns = size(num);
            if ns(1) > 1 % sos filter
                for jj = 1:size(num,1)
                    [out, obj.pFilterStates(:,:,jj)] = filter(num(jj,1:3), num(jj,4:6),...
                                                       out, obj.pFilterStates(:,:,jj), 1);
                end
            else
                [out, obj.pFilterStates] = filter(num, obj.pDenFilterCoef, out, obj.pFilterStates, 1);
            end
            
            out = out * obj.pOutputGain;
            
        end

        function validateInputsImpl(obj,varargin)

            if strcmp(obj.SamplesPerFrameSource,'Input port')
                spf = varargin{1};
                validateSamplesPerFrame(obj,spf);
            end
        end

        function validateSamplesPerFrame(~,val)
            validateattributes(val, ...
                {'numeric'}, ...
                {'nonnegative', 'integer', 'scalar'}, ...
                '', ...
                'SamplesPerFrame');
        end

    end
    
    methods (Hidden)
        function [n,d] = coeffs(obj)
            % Hidden method used for testing
            if isLocked(obj) && getInverseFrequencyPower(obj)
                n = obj.pNumFilterCoef;
                d = obj.pDenFilterCoef;
            else
                n = [];
                d = [];
            end
        end
    end
    
    methods(Static, Access = protected)
        function groups = getPropertyGroupsImpl
            param = matlab.system.display.Section( ...
                'Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', {'Color','InverseFrequencyPower','BoundedOutput', ...
                'NumChannels','SamplesPerFrameSource','SamplesPerFrame','MaxSamplesPerFrame', ...
                'OutputDataType'});
            
            pRandStream = matlab.system.display.internal.Property( ...
                'RandomStream', ...
                'IsGraphical', false, ...
                'UseClassDefault', false, ...
                'Default', 'mt19937ar with seed');
            
            randomization = matlab.system.display.Section( ...
                'Title', getString(message('dsp:system:ColoredNoise:randomizationSection')), ...
                'PropertyList', {pRandStream, 'Seed'});
            
            groups = [param randomization];
        end
    end
end
