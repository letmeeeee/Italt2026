classdef (StrictDefaults)IIRHalfbandDecimator < dsp.internal.IIRHalfbandBase
%IIRHalfbandDecimator Decimate by a factor of two using polyphase IIR
%   This System object lets you design and use decimators that implement
%   IIR halfband structures. Allpass filters are used in the polyphase
%   branches. Filters can be designed either using elliptic or quasi-linear
%   phase design methods. You can convert this System object to an analysis
%   filter bank.
%
%   IIRHALFBANDDECIM = dsp.IIRHalfbandDecimator returns a System object,
%   IIRHALFBANDDECIM, that decimates each channel of the input signal
%   by a factor of 2 using IIR halfband filters.
%
%   IIRHALFBANDDECIM = dsp.IIRHalfbandDecimator(Name=Value, ...) returns
%   a IIR halfband decimator System object, IIRHALFBANDDECIM, with each
%   specified property set to the specified value.
%
%   Step method syntax:
%
%   Y = step(IIRHALFBANDDECIM,X) outputs the decimated values, Y, of the
%   input signal, X. A Ki-by-N input matrix is treated as N independent
%   channels, and the System object decimates each channel over time and
%   generates a Ko-by-N output matrix. Ko = Ki/2, where 2 is the decimation
%   factor. The object supports real and complex floating-point inputs.
%
%   [YLP, YHP] = step(IIRHALFBANDDECIM,X) computes the power-complimentary
%   outputs, YLP and YHP, of the analysis filter bank, IIRHALFBANDDECIM for
%   input X. A Ki-by-N input matrix is treated as N independent channels.
%   The System object generates two power-complementary output signals by
%   adding and subtracting the two polyphase branch outputs respectively.
%   YLP and YHP are of the same data type and size, Ko-by-N. Ko = Ki/2,
%   where 2 is the decimation factor.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   IIRHalfbandDecimator methods:
%   step     - See above description for use of this method
%   release  - Allow property value and input characteristics changes
%   clone    - Create IIR halfband decimator object with same property 
%              values
%   isLocked - Locked status (logical)
%   reset    - Reset the internal states to initial conditions
%
%   IIRHalfbandDecimator properties:
%
%   SampleRate           - Input sample rate (Hz)
%   Specification        - Filter design parameter specification
%   FilterOrder          - Order of the filter
%   TransitionWidth      - Transition width of the IIR halfband filter
%   StopbandAttenuation  - Minimum attenuation needed in stopband of
%                          the IIR halfband filter (dB)
%   DesignMethod         - Design method for the IIR halfband filter
%   NormalizedFrequency  - Provide normalized frequencies for filter
%                          specifications
%   Structure            - Filter structure used in coefficient mode
%   AllpassCoefficients1 - Branch 1 coefficients, minimum multiplier
%   AllpassCoefficients2 - Branch 2 coefficients, minimum multiplier
%   WDFCoefficients1     - Branch 1 coefficients, wave digital  
%   WDFCoefficients2     - Branch 2 coefficients, wave digital
%   HasPureDelayBranch   - Branch 1 is a delay
%   Delay                - Value of branch 1 delay, in samples
%   HasTrailingFirstOrderSection - Branch 2, last section is 1st order 
%   AllowArbitraryInputLength    - Allow arbitrary input length for fixed-size
%                                  signals in code generation
%
%   This System object supports several filter analysis methods. For
%   more information, type
%   dsp.IIRHalfbandDecimator.helpFilterAnalysis.
%
%   % Example 1: Decimate a signal and plot the spectra
%   
%   Fs = 5000; % Units: Hz
%   frameSize = 2000;
%   
%   SW = dsp.SineWave(Frequency=400, SampleRate=Fs, ...
%                     SamplesPerFrame=frameSize);
%   InputSA = spectrumAnalyzer(PlotAsTwoSidedSpectrum=false, ...
%                     SampleRate=Fs, ShowLegend=true, ...
%                     ChannelNames="Input");
%   OutputSA = spectrumAnalyzer(PlotAsTwoSidedSpectrum=false, ...
%                     SampleRate=Fs/2, ShowLegend=true, ...
%                     ChannelNames="Output");
%   
%   % Construct IIR Half band decimator
%   IIRHALFBANDDECIM = dsp.IIRHalfbandDecimator(...
%       Specification="Filter order and transition width",...
%       FilterOrder=15, TransitionWidth=400, ...
%       SampleRate=Fs);
%   
%   for idx=1:2000
%       Input = SW()+randn(frameSize,1);
%       Output = IIRHALFBANDDECIM(Input);
%       % Plot on scopes
%       InputSA(Input);
%       OutputSA(Output);
%   end
%   
%   % Example 2: Design a quasi-linear phase IIR halfband decimator and
%   % display its frequency response
%   
%   IIRHALFBANDDECIM = dsp.IIRHalfbandDecimator(...
%                       DesignMethod="Quasi-linear phase");
%   
%   % Obtain filter coefficients
%   c = coeffs(IIRHALFBANDDECIM);
%   
%   % Plot the Magnitude and Phase response
%   fvtool(IIRHALFBANDDECIM,Analysis="freq")
%
%   See also dsp.IIRHalfbandInterpolator, dsp.FIRHalfbandDecimator,
%            designHalfbandIIR, dsp.CoupledAllpassFilter

%   Copyright 2015-2023 The MathWorks, Inc.

%#codegen
%#ok<*EMCA>
    properties (Nontunable)
        % SampleRate Input sample rate (Hz)
        %   Specify the sampling rate of the input in Hertz as a finite
        %   numeric scalar. the default is 44100 Hz.
        SampleRate = 44.1e3;
        %TransitionWidth Transition width
        %   Specify the transition width for the designed IIR halfband
        %   filter as a finite positive scalar. Specify the value of
        %   transition width in Hertz when NormalizedFrequency is set to
        %   false and in normalized units when NormalizedFrequency is set
        %   to true. The transition width must be less than half the input
        %   sample rate. This property applies when the Specification is
        %   either 'Filter order and transition width' or 'Transition width
        %   and stopband attenuation'. The default value of this property
        %   is 4100 Hz.
        TransitionWidth = 4.1e3;

        %AllowArbitraryInputLength Allow arbitrary frame length for fixed-size input signals
        %   When this flag is set to true, the fixed-size input signal can
        %   have a frame size that is not a multiple of the 2. This
        %   property applies only when the input is a fixed-size signal. If
        %   the size of the input signal varies during simulation
        %   (variable-size signal), this property does not apply. The
        %   default value is 'false' and has to be set to 'true' to process
        %   inputs with arbitrary frame lengths.
        AllowArbitraryInputLength (1, 1) logical = false;        
    end

    properties (Access = protected, Nontunable)
        % pSR Default sample rate
        pSR = 44.1e3;
    end
    properties (Access=protected)
        isBranch2CarryEmpty (1, 1) logical = false;
    end    
    
    %----------------------------------------------------------------------
    % Public methods
    %----------------------------------------------------------------------
    methods
        % Constructor
        function obj = IIRHalfbandDecimator(varargin)
            % Support name-value pair arguments
            setProperties(obj, nargin, varargin{:});
            if obj.NormalizedFrequency  
                isTransitionWidthSpecified = false;
                for i = 1:2:numel(varargin)
                    if strcmp(varargin{i}, 'TransitionWidth')
                        isTransitionWidthSpecified = true;
                    end
                end
                if ~isTransitionWidthSpecified
                    obj.TransitionWidth = 4.1e3/(44100/2);
                end
            end
        end
        %------------------------------------------------------------------
        function set.TransitionWidth(obj,TW)
            validateattributes(TW,{'single','double'},{'real','positive',...
                'finite','scalar'},'','TransitionWidth');
            obj.TransitionWidth = TW;
            needToDesignFilters(obj);
        end
        %------------------------------------------------------------------      
        function set.SampleRate(obj,val)
            validateattributes(val,...
                {'double','single'}, ...
                {'real','scalar','positive','finite'},...
                '','SampleRate');
            obj.SampleRate = val;
            postProcessSampleRate(obj,val);
        end
        %------------------------------------------------------------------
        function realizemdl(obj,varargin)
            warning(message('dsp:system:FIRHalfbandDecimator:realizemdlFilterBank'));
            realizemdl@dsp.internal.FilterAnalysis(obj, varargin{:});
        end
    end
    %----------------------------------------------------------------------
    % Protected methods
    %----------------------------------------------------------------------
    methods (Access = protected)
        function validateInputsImpl(obj,varargin)
            
            % Number of input rows must be a multiple of 2 (the decimation
            % factor)
            u = varargin{1};
            if ~isempty(coder.target)
                isArbSize = obj.AllowArbitraryInputLength;
                isFixedInput = propagatedInputFixedSize(obj, 1);
                % Number of input rows must be even (decimation by 2) for
                % fixed size input if AllowArbitraryInputLength is set to
                % false in codegen mode.
                coder.internal.errorIf(isFixedInput && ~isArbSize && size(u,1)>0 && rem(size(u,1), 2)~=0,...
                    'dsp:system:FIRHalfbandDecimator:invalidInputDimsForHalfbandDecim');
            end
            
            validateInputsImpl@dsp.internal.IIRHalfbandBase(obj, u);
            
        end
        %------------------------------------------------------------------
        function validatePropertiesImpl(obj)
            validatePropertiesImpl@dsp.internal.IIRHalfbandBase(obj);
        end
        %------------------------------------------------------------------
        function crossValidateProperties(obj)
            inputFs = getSampleRate(obj);
            if ~strcmp(obj.Specification, 'Filter order and stopband attenuation')
                % Transition width must be less than half the input sample rate
                coder.internal.errorIf(obj.TransitionWidth >= inputFs/2, ...
                    'dsp:system:FIRHalfbandDecimator:TransitionWidth', ...
                    floor(inputFs/2),...
                    round((inputFs/2 - floor(inputFs/2)) * 10));
            end
        end
        %------------------------------------------------------------------
        function setupImpl(obj, varargin)
            setupImpl@dsp.internal.IIRHalfbandBase(obj,varargin{:});
        end
        %------------------------------------------------------------------
        function isFixedOutput = isFixedSizeOutput(obj)
            isFixedOutput = ~isempty(coder.target) && propagatedInputFixedSize(obj,1) && ~obj.AllowArbitraryInputLength;
        end
        %------------------------------------------------------------------
        function [yLP, yHP] = stepImpl(obj, u)         
          
            
            [inputFrameSize, inputChannelSize] = size(u);
            In1 = u(1 + obj.isBranch2CarryEmpty:2:inputFrameSize,:);
            In2 = u(1 + ~obj.isBranch2CarryEmpty:2:inputFrameSize,:);
            
            if obj.pCachedNoDelay
                
                % Local copies of states
                Z1 = obj.pStates.Branch1;
                Z2 = obj.pStates.Branch2;
                
                
                if obj.pCachedUsesMinMult 
                    %Minimum multiplier
                    [y1,Z1] = dsp.internal.AllpassMinMult.stepMinMultCascade(...
                        In1, Z1, obj.pBranchInfo1, ...
                        obj.pBranchCoef1);
                        
                    [y2,Z2] = dsp.internal.AllpassMinMult.stepMinMultCascade(...
                       In2, Z2, obj.pBranchInfo2, ...
                        obj.pBranchCoef2);
                else
                    %wave digital
                    [y1,Z1] = dsp.internal.WaveDigitalFilter.stepWDFCascade(...
                        In1, Z1, obj.pBranchInfo1, ...
                        obj.pBranchCoef1,inputChannelSize);

                    [y2,Z2] = dsp.internal.WaveDigitalFilter.stepWDFCascade(...
                       In2, Z2, obj.pBranchInfo2, ...
                        obj.pBranchCoef2,inputChannelSize);
                end
                % ----- End of Minimum multiplier allpass
                
                % Save states
                obj.pStates.Branch1 = Z1;
                obj.pStates.Branch2 = Z2;
                
            else
                
                % Local copies of delay
                delayObj = obj.pDelay;

                % Local copies of states
                Z2 = obj.pStates.Branch2;
                
                % ----- Delay: First branch
                y1 = step(delayObj, In1);
                
                if obj.pCachedUsesMinMult 
                    %Minimum multiplier
                    [y2,Z2] = dsp.internal.AllpassMinMult.stepMinMultCascade(...
                       In2, Z2, obj.pBranchInfo2, ...
                        obj.pBranchCoef2);
                else
                    %wave digital
                    [y2,Z2] = dsp.internal.WaveDigitalFilter.stepWDFCascade(...
                       In2, Z2, obj.pBranchInfo2, ...
                        obj.pBranchCoef2,inputChannelSize);
                end
                % Save states
                obj.pStates.Branch2 = Z2;
            end

            % Compute output
            
            fixedOutputSize = coder.const(obj.isFixedSizeOutput()); 
            if fixedOutputSize
                len_y1 = coder.const(inputFrameSize)/2;
                b2out =  zeros(len_y1,inputChannelSize,'like',y2);
                b2out(:) = [obj.pBranch2Carry; y2(1:end-1,:)];
            else
                if ~obj.isBranch2CarryEmpty
                    b2outAppended = [obj.pBranch2Carry; y2]; 
                else
                    b2outAppended = y2;
                end
                len_b2out = size(b2outAppended,1);
                len_y1 = size(y1,1);
                obj.isBranch2CarryEmpty = len_b2out == len_y1;
                b2out = b2outAppended(1:end- ~obj.isBranch2CarryEmpty,1:inputChannelSize);
            end

            yLP = 0.5 * (y1(1:len_y1,1:inputChannelSize) + b2out);
            yHP = 0.5 * (y1(1:len_y1,1:inputChannelSize) - b2out);
       
            % Last output of second branch will be used in the next step
            % call, so preserve it.
            if ~obj.isBranch2CarryEmpty
                obj.pBranch2Carry(1,1:inputChannelSize) = y2(end,1:inputChannelSize);
            end
        end
        %------------------------------------------------------------------
        function val = isDecimator(~)
            val = true;
        end
        %------------------------------------------------------------------
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@dsp.internal.IIRHalfbandBase(obj);
            s.AllowArbitraryInputLength = obj.AllowArbitraryInputLength;
            s.isBranch2CarryEmpty = obj.isBranch2CarryEmpty;
        end
        %------------------------------------------------------------------
        function loadObjectImpl(obj, s, wasLocked)
            loadObjectImpl@dsp.internal.IIRHalfbandBase(obj, s, wasLocked);
            if isfield(s, 'AllowArbitraryInputLength')
                obj.AllowArbitraryInputLength = s.AllowArbitraryInputLength;
            end
            if isfield(s, 'isBranch2CarryEmpty')
                obj.isBranch2CarryEmpty = s.isBranch2CarryEmpty;
            end
        end
        function out = supportsScalarVarsizeImpl(~)
            coder.allowpcode('plain');
            out = true;
        end
        %------------------------------------------------------------------
        function val = getNumOutputsImpl(~)
            val = 2;
        end
        %------------------------------------------------------------------ 
        function postProcessSampleRate(obj,val)
            needToDesignFilters(obj);
            obj.pSR = val;
        end
        %------------------------------------------------------------------ 
        function [sz1,sz2] = getOutputSizeImpl(obj)
            inputSize = propagatedInputSize(obj,1);
            coder.internal.errorIf(mod(inputSize(1),2)~=0, ...
                'dsp:system:FIRHalfbandDecimator:invalidInputDimsForHalfbandDecim');
            sz1 = inputSize;
            sz1(1) = inputSize(1)/2;
            sz2    = sz1;
        end
        %------------------------------------------------------------------ 
        function [f1,f2] = isOutputFixedSizeImpl(obj)
           f1 = propagatedInputFixedSize(obj,1);
           f2 = f1;
        end
        %------------------------------------------------------------------ 
        function [d1,d2] = getOutputDataTypeImpl(obj)
            d1 = propagatedInputDataType(obj,1);
            d2 = d1;
        end
        %------------------------------------------------------------------ 
        function [c1,c2] = isOutputComplexImpl(obj)
            c1 = propagatedInputComplexity(obj,1);
            c2 = c1;
        end
        %------------------------------------------------------------------
        function dt = getTunablePropertiesSpecificationImpl(obj,~)
            dt = propagatedInputDataType(obj,1);
        end
        function flag = isInactivePropertyImpl(obj, prop)            
            switch prop
                case {'SampleRateMode'}
                    flag = true;
                otherwise
                    flag = isInactivePropertyImpl@dsp.internal.IIRHalfbandBase(obj,prop);
            end
        end
        function resetImpl(obj)
            resetImpl@dsp.internal.IIRHalfbandBase(obj);
             obj.isBranch2CarryEmpty = false;

        end
    end
    %----------------------------------------------------------------------
    % Static hidden methods
    %----------------------------------------------------------------------
    methods (Static, Hidden)
        function props = getDisplayPropertiesImpl()
            props = {...
                'Specification',...
                'FilterOrder', ...
                'TransitionWidth', ...
                'StopbandAttenuation', ...
                'DesignMethod', ...
                'NormalizedFrequency', ...
                'SampleRate', ...
                'Structure', ...
                'HasPureDelayBranch', ...
                'Delay', ...
                'AllpassCoefficients1', ...
                'AllpassCoefficients2', ...
                'WDFCoefficients1', ...
                'WDFCoefficients2', ...
                'HasTrailingFirstOrderSection'};
        end
    end
    %----------------------------------------------------------------------
    % Static protected methods
    %----------------------------------------------------------------------
    methods (Static, Access=protected)
        function groups = getPropertyGroupsImpl
            props = dsp.IIRHalfbandDecimator.getDisplayPropertiesImpl;
            mainS = matlab.system.display.Section('Title', ...
                getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', props);
            mainSG = matlab.system.display.SectionGroup(...
                Title = getString(message('dsp:system:Shared:Main')),...
                Sections= mainS);
            CGs = matlab.system.display.Section(...
	            Title='Parameters', ...
	            PropertyList={'AllowArbitraryInputLength'});
            cgSG = matlab.system.display.SectionGroup(...
	            Title=getString(message('dsp:system:Shared:CodegenProperties')),...
	            Sections=CGs);
            
            groups = [mainSG, cgSG];
        end
    end
    %----------------------------------------------------------------------
    % Hidden methods
    %----------------------------------------------------------------------
    methods (Hidden)
        function props = getNonFixedPointProperties(~)
            props = dsp.IIRHalfbandDecimator.getDisplayPropertiesImpl;
        end

        function [L,M] = rateConversionFactors(obj) %#ok
            nargoutchk(2, 2);
            L = 1;
            M = 2;
        end
    end
end
