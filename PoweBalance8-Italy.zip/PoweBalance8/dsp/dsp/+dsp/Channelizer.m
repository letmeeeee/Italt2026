classdef (StrictDefaults)Channelizer < dsp.internal.PolyphaseFFTBase ...
        & dsp.enhancedsim.UpdateSysObjBuildInfo
    %Channelizer Polyphase FFT analysis filter bank.
    %   channelizer = dsp.Channelizer returns a polyphase FFT analysis
    %   filter bank System object, channelizer, which separates a broadband
    %   input signal into multiple narrowband output signals. This object
    %   implements the inverse operation of dsp.ChannelSynthesizer.
    %
    %   channelizer = dsp.Channelizer(M) returns an M-band polyphase FFT
    %   analysis filter bank. The number of frequency bands M can be any
    %   positive integer greater than one. M also corresponds to the number
    %   of polyphase branches and the FFT length used in the filter bank. M
    %   defaults to 8.
    %
    %   channelizer = dsp.Channelizer(M, D) returns an M-band polyphase FFT
    %   analysis filter bank with Decimation factor D. The decimation
    %   factor D can be any positive integer less than or equal to M. D
    %   defaults to 8.
    %
    %   channelizer = dsp.Channelizer(Name=Value, ...) returns a
    %   channelizer with each specified property name set to the specified
    %   value. You can specify additional name-value pair arguments in any
    %   order as (Name1=Value1,...,NameN=ValueN).
    %
    %   The specification defaults to number of taps per band and stopband
    %   attenuation. These values are used to design a prototype lowpass
    %   filter that is implemented in polyphase form. The stopband
    %   attenuation determines the minimum level of interference (aliasing)
    %   from one frequency band to another. The number of taps corresponds
    %   to the number of filter coefficients used for each polyphase
    %   branch. The number of polyphase branches matches the number of
    %   frequency bands. The total number of filter coefficients for the
    %   prototype lowpass filter is given by the number of frequency bands
    %   times the number of taps per band. For a given stopband
    %   attenuation, increasing the number of taps per band will narrow the
    %   transition width of the filter resulting in more usable bandwidth
    %   for each frequency band at the expense of increased computation.
    %
    %   Step method syntax:
    %
    %   y = step(channelizer,x) separates the broadband input signal x into
    %   a number of narrow band signals contained in the columns of y. The
    %   number of rows in x must be a multiple of the number of frequency
    %   bands. Each column of x corresponds to a separate channel. If M is
    %   the number of frequency bands and x is a Lx1 matrix, y will have
    %   dimensions L/MxM. If x has more than one channel, i.e. x is LxN, y
    %   will be 3 dimensional with dimensions L/MxMxN.
    %
    %   System objects may be called directly like a function instead of
    %   using the step method. For example, y = step(obj,x) and y = obj(x)
    %   are equivalent.
    %
    %   Channelizer methods:
    %
    %   step                 - See above description for use of this method
    %   release              - Allow property value and input
    %                          characteristics changes
    %   clone                - Create a new object with same property
    %                          values
    %   isLocked             - Locked status (logical)
    %   reset                - Reset the internal states to initial
    %                          conditions
    %   coeffs               - Returns a structure containing the prototype
    %                          lowpass filter coefficients
    %   polyphase            - Returns the polyphase coefficient matrix
    %   tf                   - Returns the transfer function of the
    %                          prototype lowpass filter
    %   fvtool               - Visualize channelizer using FVTool
    %   freqz                - Compute frequency response
    %   bandedgeFrequencies  - Compute bandedge frequencies between
    %                          adjacent filters in the channelizer
    %   centerFrequencies    - Compute center frequencies for all filters
    %                          in the channelizer
    %   getFilters           - Return matrix of channelizer FIR filters
    %
    %   Channelizer properties:
    %
    %   NumFrequencyBands         - Number of frequency bands
    %   DecimationFactor               - Decimation factor
    %   AllowArbitraryInputLength - Allow arbitrary frame length for fixed-size input signals
    %   Specification                       - Design parameters or Coefficients
    %   NumTapsPerBand               - Number of filter coefficients per frequency band
    %   StopbandAttenuation         - Stopband attenuation for lowpass filter in dB
    %   LowpassCoefficients           - Coefficients for prototype lowpass filter
    %
    %   % EXAMPLE: Separate a signal containing sine waves of different
    %   % frequencies into 8 separate signals, each one containing one sine
    %   % wave.
    %   channelizer = dsp.Channelizer;
    %   offsets = [-40,-30,-20,10,15,25,35,-15];
    %   sinewave = dsp.SineWave(ComplexOutput=true, ...
    %       Frequency=offsets+(-375:125:500),SamplesPerFrame=800);
    %   scope = spectrumAnalyzer(ShowLegend=true,...
    %       SampleRate=sinewave.SampleRate/8);
    %   for i=1:5000
    %       x = sum(sinewave(),2);
    %       y = channelizer(x);
    %       scope(y);
    %   end
    %
    %   See also dsp.ChannelSynthesizer, dsp.FIRHalfbandDecimator,
    %   dsp.FIRHalfbandInterpolator, dsp.IIRHalfbandDecimator,
    %   dsp.DyadicAnalysisFilterBank, firpr2chfb.


    % Copyright 2016-2022 The MathWorks, Inc.

    %#codegen

    properties (Nontunable)
        %NumFrequencyBands Number of frequency bands
        %   Specify the number of frequency bands to separate the input
        %   signal into as a scalar positive integer greater than 1.
        %   The default is 8.
        NumFrequencyBands = 8;
    end

    properties (Nontunable,Dependent)
        %DecimationFactor Decimation factor
        %   Specify the decimation factor as a scalar positive less than or
        %   equal to the number of frequency bands. The default is equal to
        %   the number of frequency bands specified.
        DecimationFactor;
    end

    properties (Nontunable,Dependent,Hidden)
        %OversamplingRatio Oversampling ratio
        %   Specify the oversampling ratio as a scalar positive divisor of
        %   the number of frequency bands. The default is 1.
        OversamplingRatio;
    end

    properties (Access = private)
        %vextra Matrix to hold temporary computation before performing FFT
        vextra
        %NTPB Number of taps per band
        NTPB
        %numStates number of states in the state machine that corresponds to
        %the number of possible circular shift values
        numStates = 1;
        actpmatrixHalide;
        %phaseIdx Phase Index to store the input index for non-multiple
        %frame length
        phaseIdx;
        %currentState to keep track of circular rotation
        currentState;
    end

    properties(Access = protected)
        %ModuloIdx to compute the output length in case of non-mulitple
        %frame length
        ModuloIdx;
        %StartIdx and StopIdx are used for output size calculation
        StartIdx;
        StopIdx;
    end

    properties (Nontunable,Access = private)
        %pDecimationFactorSource Decimation factor source
        pDecimationFactorSource = 'auto';
        %pAutoDecimationFactor Auto decimation factor value
        pAutoDecimationFactor = 8;
        %pUserDefinedDecimationFactor User-defined decimation factor
        pUserDefinedDecimationFactor = 8;
        %pCompiledDecimationFactor Decimation factor to be used at compile
        %time
        pCompiledDecimationFactor;
        %pHalideFlagInterpretMode refers to the algorithm used for polyphase analysis
        %false refers to C and true refers to Halide
        pHalideFlagInterpretMode;
    end

    properties(Nontunable)
        %AllowArbitraryInputLength Allow arbitrary frame length for fixed-size input signals
        %   When this flag is set to true, the fixed-size input signal can have a frame size 
        %   that is not a multiple of the decimation factor. This property applies only when 
        %   the input is a fixed-size signal. If the size of the input signal varies during 
        %   simulation (varible-size signal), this property does not apply. The default value 
        %   is 'false' and has to be set to 'true' to process inputs with arbitrary frame lengths.
        AllowArbitraryInputLength (1, 1) logical = false;
    end

    %----------------------------------------------------------------------
    % Public methods
    %----------------------------------------------------------------------
    methods
        %------------------------------------------------------------------
        function obj = Channelizer(varargin)
            %Channelizer Construct the Channelizer class.
            % Support name-value pair arguments
            setProperties(obj,nargin,varargin{:},'NumFrequencyBands','DecimationFactor');
        end
        %------------------------------------------------------------------
        function set.NumFrequencyBands(obj,M)
            validateattributes(M,...
                {'numeric'},...
                {'real','scalar','integer','finite','>=',2},...
                '','NumFrequencyBands');
            obj.NumFrequencyBands = M;
            setAutoDecimationFactor(obj);
        end
        %------------------------------------------------------------------
        function set.DecimationFactor(obj, D)
            validateattributes(D,...
                {'numeric'},...
                {'real','scalar','positive','integer','finite'},...
                '','DecimationFactor');
            setUserDefinedDecimationFactor(obj,D);
        end
        function D = get.DecimationFactor(obj)
            if strcmpi(obj.pDecimationFactorSource,'property')
                D = obj.pUserDefinedDecimationFactor;
            else
                D = obj.pAutoDecimationFactor;
            end
        end
        %------------------------------------------------------------------
        function set.OversamplingRatio(obj, R)
            if isempty(coder.target)
                coder.internal.warning('dsp:system:Channelizer:OversamplingRatio_NotSupported');
            end
            validateattributes(R,...
                {'numeric'},...
                {'real','scalar','integer','finite','>=',1},...
                '','OversamplingRatio');
            setUserDefinedDecimationFactor(obj,obj.NumFrequencyBands/R);
        end
        function R = get.OversamplingRatio(obj)
            R = obj.NumFrequencyBands / obj.DecimationFactor;
        end
        %------------------------------------------------------------------
        function set.AllowArbitraryInputLength(obj,val)
            validateattributes(val, {'logical'}, {'scalar'}, '','AllowArbitraryInputLength');
            obj.AllowArbitraryInputLength = val;
        end
    end
    %----------------------------------------------------------------------
    % Public user visible methods
    %----------------------------------------------------------------------
    methods
        %------------------------------------------------------------------
        function B = getFilters(obj,varargin)
            %B = getFilters(obj) Return matrix of channelizer FIR filters
            %   B = getFilters(obj) returns a matrix B of filter
            %   coefficients corresponding to each filter in the
            %   channelizer filter bank. Each row contains the coefficients
            %   for one the bandpass filters.
            %
            %   B = getFilters(obj,IND) returns the filters with indices
            %   corresponding to the elements in the vector IND. IND is a
            %   row vector of indices between 1 and obj.NumFrequencyBands.
            %   If not specified, IND defaults to 1:N where N is the number
            %   of frequency bands.
            %
            %   NOTE: the channelizer does not actually use all these
            %   filters in the implementation. It only uses the prototype
            %   lowpass filter (the first row of matrix B) and an FFT to
            %   implement the filter bank. The combination of polyphase
            %   implementation of the prototype lowpass and the FFT
            %   effectively implements all the filters in B, but does so in
            %   a very efficient manner. The getFilters method is provided
            %   as an analysis aid when evaluating the performance of the
            %   channelizer.

            p = inputParser;
            Nbands = obj.NumFrequencyBands;
            p.addOptional("indices",1:Nbands);

            p.parse(varargin{:});
            r = p.Results;

            validateattributes(r.indices,{'numeric'},...
                {'row','finite','integer','positive','real','<=',Nbands},...
                'getFilters','indices');

            id = double(r.indices);

            b = tf(obj);
            n = 0:length(b)-1;

            k = id - 1;

            m = exp(2.*pi.*1j.*k'*n./Nbands);

            % Modulate impulse response
            B = m.*b;
        end
        %------------------------------------------------------------------
        function p = polyphase(obj)
            %p = polyphase(obj) Return polyphase matrix
            %   p = polyphase(obj) returns the polyphase matrix used by the
            %   filter bank. Each row in the matrix corresponds to a
            %   polyphase branch. The number of columns of p corresponds to
            %   the number of filter taps per branch.
            if ~isLocked(obj)
                if ~strcmpi(obj.Specification,'Coefficients')
                    designPrototypeLowpass(obj);
                else
                    M = obj.NumFrequencyBands;
                    setPolyphaseMatrixFromCustomCoeffs(obj,M);
                end
            end
            p = obj.PolyphaseMatrix;
        end
        %------------------------------------------------------------------
        function c = coeffs(obj)
            %c = coeffs(obj) Return structure with filter coefficients
            %   c = coeffs(obj) returns the overall prototype lowpass
            %   filter coefficients in a structure.
            c.Numerator = poly2coeffs(obj);
        end
        %------------------------------------------------------------------
        function [b,a] = tf(obj)
            %[b,a] = tf(obj) Return transfer function
            %   [b,a] = tf(obj) returns the vector of numerator
            %   coefficients b and the vector of denominator coefficients a
            %   for the overall prototype lowpass filter used for the
            %   filter bank.
            b = poly2coeffs(obj);
            a = 1;
        end
        %------------------------------------------------------------------
        function varargout = freqz(obj,varargin)
            %[H,f] = freqz(obj) Frequency response
            %   [H,w] = freqz(obj) returns a matrix of complex frequency
            %   responses for each filter in the channelizer. Each column
            %   of H corresponds to the frequency response for one of the
            %   filters in the channelizer. w is a vector of normalized
            %   frequencies at which the rows of H are computed.
            %
            %   [H,w] = freqz(obj,IND) returns the frequency response of
            %   the filters with indices corresponding to the elements in
            %   the vector IND. IND is a row vector of indices between 1
            %   and obj.NumFrequencyBands. If not specified, IND defaults
            %   to 1:N where N is the number of frequency bands.
            %
            %   [H,f] = freqz(...,'Fs',Fs) specifies a sampling rate Fs in
            %   Hz. f is a vector of frequencies in Hz at which the
            %   frequency response is computed.
            %
            %   [H,f] = freqz(...,'NFFT',NFFT) specifies the number of
            %   NFFT points used to compute the frequency response.
            %
            %   [H,f] = freqz(...,'overall',FLAG) specifies whether to
            %   return individual filter responses when FLAG is set to
            %   false, or the sum of the filter responses when FLAG is set
            %   to true. If not specified, FLAG defaults to false.
            %
            %   freqz(...) with no output arguments plots the magnitude
            %   response.

            nargoutchk(0, 2);

            Nbands = obj.NumFrequencyBands;
            [h,r] = freqzHelper(obj,Nbands,varargin{:});

            if r.Fs < 0
                Fs = 2*pi;
            else
                Fs = r.Fs;
            end
            Fsd = double(Fs);

            f = linspace(0,Fsd-Fsd/r.NFFT,r.NFFT)';

            H = fft(h.',r.NFFT);
            if r.overall
                H = sum(H,2);
            end

            if nargout == 0
                if r.Fs < 0
                    plot(f/pi,20*log10(abs(H)));
                    xlabel([getString(message('signal:sigtools:getfrequnitstrs:NormalizedFrequency')) '  (\times\pi rad/sample)']);
                else
                    plot(f,20*log10(abs(H)));
                    xlabel([getString(message('signal:sigtools:getfrequnitstrs:Frequency')) ' (Hz)']);
                end
                ylabel(getString(message('signal:sigtools:MagnitudedB')));
                grid on
            elseif nargout == 1
                varargout = {H};
            elseif nargout == 2
                varargout = {H,f};
            end
        end
        %------------------------------------------------------------------
        function varargout = fvtool(obj,varargin)
            %fvtool(obj) View channelizer in FVTool
            %   fvtool(obj) visualizes the filters in the channelizer using
            %   the Filter Visualization Tool (FVTool).
            %
            %   fvtool(obj,IND) visualizes the filters corresponding to the
            %   elements in the vector IND. IND is a row vector of indices
            %   between 1 and obj.NumFrequencyBands. If not specified, IND
            %   defaults to 1:N where N is the smallest of
            %   obj.NumFrequencyBands and 64.
            %
            %   fvtool(...,'Fs',Fs) specifies a sampling rate Fs in Hz.
            %
            %   fvtool(...,'NFFT',NFFT) specifies the number of NFFT points
            %   used to compute the frequency response.
            %
            %   fvtool(...,'overall',FLAG) specifies whether to return
            %   individual filter responses when FLAG is set to false, or
            %   the sum of the filter responses when FLAG is set to true.
            %   If not specified, FLAG defaults to false.
            %
            %   H = fvtool(...) returns the handle to FVTool.

            [h,r] = freqzHelper(obj,64,varargin{:});

            if r.Fs > 0
                args = {'Fs',r.Fs,'NumberofPoints',r.NFFT};
            else
                args = {'NumberofPoints',r.NFFT};
            end

            if r.overall
                count = 1;
                ht = cell(length(r.indices),1);
                for k = r.indices - 1
                    % Modulate impulse response
                    ht{count} = dfilt.dffir(h(count,:));
                    count = count + 1;
                end

                h = dfilt.parallel(ht{:});
                hfvt = fvtool(h,args{:});
            else
                count = 1;
                filts = cell(2*length(r.indices),1);
                for k = r.indices-1
                    filts{count} = h(ceil(count./2),:);
                    filts{count+1} = 1;
                    count = count + 2;
                end
                hfvt = fvtool(filts{:},args{:});
            end
            if nargout > 0
                varargout{1} = hfvt;
            end
        end
        %------------------------------------------------------------------
        function f = bandedgeFrequencies(obj,Fs)
            %f = bandedgeFrequencies(obj) Bandedge frequencies
            %   f = bandedgeFrequencies(obj) returns a vector of
            %   normalized frequencies f containing the band-edge
            %   frequencies between adjacent bandpass filters in the
            %   channelizer.
            %
            %   f = bandedgeFrequencies(obj,Fs) returns a vector of
            %   band-edge frequencies in Hz, using the sample rate Fs.

            if nargin < 2
                Fs = 2*pi;
            end

            validateattributes(Fs,{'numeric'},...
                {'scalar','finite','real','positive'},...
                'bandedgeFrequencies','Fs');

            Fsd = double(Fs);

            Nbands = obj.NumFrequencyBands;

            if rem(Nbands,2)
                tmp = linspace(0,Fsd,Nbands+1)-Fsd/2;
            else
                tmp = Fsd/(2*Nbands)+linspace(0,Fsd,Nbands+1)-Fsd/2;
            end
            f = tmp(1:end-1);
        end
        %------------------------------------------------------------------
        function f = centerFrequencies(obj,Fs)
            %f = centerFrequencies(obj) Center frequencies
            %   f = centerFrequencies(obj) returns a vector of
            %   normalized frequencies f containing the center frequencies
            %   of all the bandpass filters in the channelizer.
            %
            %   f = centerFrequencies(obj,Fs) returns a vector of
            %   center frequencies in Hz, using the sample rate Fs.

            if nargin < 2
                Fs = 2*pi;
            end

            validateattributes(Fs,{'numeric'},...
                {'scalar','finite','real','positive'},...
                'centerFrequencies','Fs');

            Fsd = double(Fs);

            Nbands = double(obj.NumFrequencyBands);

            k = 0:Nbands-1;

            if rem(Nbands,2)
                f = k*Fsd/Nbands-Fsd/2+Fsd/(2*Nbands);
            else
                f = k*Fsd/Nbands-Fsd/2;
            end
        end
    end
    methods (Static, Access=protected)
    function groups = getPropertyGroupsImpl
        %Get default parameters group for this System object
        propertyList = {'NumFrequencyBands','DecimationFactor',...
            'Specification','NumTapsPerBand',...
            'StopbandAttenuation','LowpassCoefficients'};

        parameterString = message('dsp:system:Shared:Parameters');
        mainS = matlab.system.display.Section(...
            Title=parameterString.getString, ...
            PropertyList=propertyList);
        mainSG = matlab.system.display.SectionGroup(...
            Title=getString(message('dsp:system:Shared:Main')), ...
            Sections=mainS);

        CGs = matlab.system.display.Section(...
            Title=parameterString.getString, ...
            PropertyList={'AllowArbitraryInputLength'});
        cgSG = matlab.system.display.SectionGroup(...
            Title=getString(message('dsp:system:Shared:CodegenProperties')),...
            Sections=CGs);

        groups = [mainSG, cgSG];
    end
    
end
    %----------------------------------------------------------------------
    % Protected methods
    %----------------------------------------------------------------------
    methods (Access=protected)
        %------------------------------------------------------------------
        function setupImpl(obj, u)
            setupImpl@dsp.internal.PolyphaseFFTBase(obj);
            N = getNumChannels(obj,u);
            M = obj.NumFrequencyBands;
            D = obj.DecimationFactor;
            % Set the compiled decimation factor value
            obj.pCompiledDecimationFactor = coder.const(@getDecimationFactor,...
                obj.pUserDefinedDecimationFactor,obj.pAutoDecimationFactor,...
                obj.pDecimationFactorSource);
            % Cache number of channels and input data type
            obj.InputDataType  = class(u);
            obj.numChannels = int16(N);
            obj.privNumFrequencyBands = uint16(M);
            if ~strcmpi(obj.Specification,'Coefficients')
                designPrototypeLowpass(obj);
                obj.NTPB = cast(obj.NumTapsPerBand,class(u));
            else
                setPolyphaseMatrixFromCustomCoeffs(obj,M);
                obj.NTPB = cast(ceil(length(obj.LowpassCoefficients))./M,class(u));
            end
            p = obj.PolyphaseMatrix;
            obj.actpmatrix = p;
            obj.actpmatrixHalide = transpose(p);
            if isempty(coder.target)
                % mex file handles the cases where adding 0 imaginary part
                % is needed to enable complex operations
                obj.States = zeros(numel(p),N,'like',u);
                obj.vextra = zeros(1,M,N,'like',u);
            else
                % For code generation matrices should be of same complexity
                % and data types
                % If the specification is not set to 'Coefficients', cast
                % the states complexity and datatype to be like the input.
                % Or  If the specification is set to 'Coefficients', cast
                % the states complexity and datatype to be like the input
                % if the coefficients are not complex
                obj.States = zeros(numel(p),N,'like',u);
                obj.vextra = zeros(1,M,N,'like',u);
                if(strcmp(obj.Specification,'Coefficients'))
                    if(isreal(u) && ~isreal(p))
                        obj.States = zeros(numel(p),N,'like',p);
                        obj.States = cast(obj.States,class(u));
                        obj.vextra = zeros(1,M,N,'like',p);
                        obj.vextra = cast(obj.vextra,class(u));
                    end
                end
            end
            % Calibration to use Halide or C
            obj.pHalideFlagInterpretMode = dsp.Channelizer.HalideEnabled(u,obj.NTPB,M);
            obj.phaseIdx = int32(1);
            obj.currentState = int32(1);
            obj.ModuloIdx = int32(0);

            obj.numStates = cast(lcm(M,D)/(D),class(u));

            obj.StartIdx = zeros(D, 1, 'int32');
            obj.StopIdx = zeros(D, 1, 'int32');

            % StartIdx and StopIdx are used to compute the number of
            % outputs for each sample of input
            for i = 0:D-1
                % t and t1 are used to compute the number of outputs that
                % can be produced from D inputs
                t = mod(i, D);
                obj.StartIdx(i + 1) = int32(ceil(t / D));
                if t == (D-1)
                    obj.StopIdx(i + 1) = int32(1);
                else
                    t1 = mod(i + 1, D);
                    obj.StopIdx(i + 1) = int32(ceil(t1 / D));
                end
            end
        end
        %------------------------------------------------------------------
        function y = stepImpl(obj, x)
            % Inputs:
            %   p - M x Np polyphase matrix
            %   x - L x N Multi-channel frame input
            %   z - Np x M x N state vector
            %   vextra - 1 x M x N temporary computation
            %   D -  scalar
            % Outputs:
            %   y - L/M x M x N multichannel frame output
            % Where:
            %   M  - Number of frequency bands
            %   Np - Number of taps per band
            %   L  - Input frame size
            %   N  - Number of independent channels
            %   D  -  Decimation factor
            %   K  - number of the states in the state machine
            %
            % Assumptions:
            %   if p is a double, x, z must also be double
            %   if p is a single, x, z must also be single
            %   if x is complex, z must also be complex;
            vExtra = obj.vextra;
            z = obj.States;
            D = obj.pCompiledDecimationFactor;
            K = obj.numStates;
            phIdx = obj.phaseIdx;
            Lx = size(x, 1);
            if mod(Lx,D) == 0
                currOutputLen = int32(ceil(Lx/D));
            else
                currOutputLen = getOutputFrameSize(obj, Lx);
            end
            state = obj.currentState;
            
            if isempty(coder.target)
                if obj.pHalideFlagInterpretMode
                    apm = obj.actpmatrixHalide;
                else
                    apm = obj.actpmatrix;
                end
                [y,z,phIdx,state] = dsp.Channelizer.firpolyphase_channelizer(...
                    x,vExtra,z,apm,D,K,obj.pHalideFlagInterpretMode,currOutputLen,phIdx,state);
            else
                libFlagForCodegen = ...
                    coder.const(feval('dsp.enhancedsim.IsSysObjSimInCodeGen',coder.target)) && ...
                    coder.const(~strcmp(feval('dsp.internal.feature','dsp_simulations','halide'),'off'));
                if libFlagForCodegen
                    apm = obj.actpmatrixHalide;
                else
                    apm = obj.actpmatrix;
                end
                [y,z,phIdx,state] = dsp.Channelizer.firpolyphase_channelizer( ...
                    x,vExtra,z,apm,D,K,libFlagForCodegen,currOutputLen,phIdx,state);
            end
            obj.phaseIdx = phIdx;
            obj.currentState = state;
            obj.States = z;
        end
        %------------------------------------------------------------------
        function processTunedPropertiesImpl(obj)
            processTunedPropertiesImpl@dsp.internal.PolyphaseFFTBase(obj);
            obj.actpmatrixHalide = transpose(obj.PolyphaseMatrix);
            obj.actpmatrix = obj.PolyphaseMatrix;
        end
        %------------------------------------------------------------------
        function resetImpl(obj)
            % Specify initial values for DiscreteState properties
            resetImpl@dsp.internal.PolyphaseFFTBase(obj);
            obj.vextra = zeros(size(obj.vextra),'like',obj.vextra);
            obj.currentState = int32(1);
        end
        %------------------------------------------------------------------
        function s = saveObjectImpl(obj)
            % Default implementation saves all public properties
            s = saveObjectImpl@dsp.internal.PolyphaseFFTBase(obj);
            s.pDecimationFactorSource = obj.pDecimationFactorSource;
            s.pUserDefinedDecimationFactor = obj.pUserDefinedDecimationFactor;
            s.pAutoDecimationFactor = obj.pAutoDecimationFactor;
            if isLocked(obj)
                % All the following are set at setup
                s.vextra  = obj.vextra;
                s.NTPB    = obj.NTPB;
                s.numStates = obj.numStates;
                s.pCompiledDecimationFactor = obj.pCompiledDecimationFactor;
                s.StartIdx = obj.StartIdx;
                s.StopIdx = obj.StopIdx;
                s.pHalideFlagInterpretMode = obj.pHalideFlagInterpretMode;
                s.phaseIdx = obj.phaseIdx;
                s.currentState = obj.currentState;
                s.ModuloIdx = obj.ModuloIdx;
                s.actpmatrixHalide = obj.actpmatrixHalide;
                s.AllowArbitraryInputLength = obj.AllowArbitraryInputLength;
            end
        end
        %------------------------------------------------------------------
        function s = loadObjectImpl(obj, s, wasLocked)
            % Re-load state if saved version was locked
            if wasLocked
                % All the following were set at setup
                obj.vextra = s.vextra;
                if isfield(s,'NTPB')
                    obj.NTPB = s.NTPB;
                else
                    obj.NTPB = obj.NumTapsPerBand;
                end
                if(isfield(s,'numStates'))
                    obj.numStates = s.numStates;
                end
                if(isfield(s,'pCompiledDecimationFactor'))
                    obj.pCompiledDecimationFactor = s.pCompiledDecimationFactor;
                end
                if isfield(s,'StartIdx')
                    obj.StartIdx = s.StartIdx;
                end
                if isfield(s,'StopIdx')
                    obj.StopIdx = s.StopIdx;
                end
                if isfield(s,'phaseIdx')
                    obj.phaseIdx = s.phaseIdx;
                end
                if isfield(s,'currentState')
                    obj.currentState = s.currentState;
                end
                if isfield(s,'ModuloIdx')
                    obj.ModuloIdx = s.ModuloIdx;
                end
                if isfield(s,'actpmatrixHalide')
                    obj.actpmatrixHalide = s.actpmatrixHalide;
                    obj.pHalideFlagInterpretMode = s.pHalideFlagInterpretMode;
                else
                    obj.actpmatrixHalide = transpose(s.PolyphaseMatrix);
                    obj.pHalideFlagInterpretMode = false;
                end
                if isfield(s, 'AllowArbitraryInputLength')
                    obj.AllowArbitraryInputLength = s.AllowArbitraryInputLength;
                end
            end
            if(isfield(s,'pUserDefinedDecimationFactor'))
                obj.pUserDefinedDecimationFactor = s.pUserDefinedDecimationFactor;
            end
            if(isfield(s,'pDecimationFactorSource'))
                obj.pDecimationFactorSource = s.pDecimationFactorSource;
            end
            if(isfield(s,'pAutoDecimationFactor'))
                obj.pAutoDecimationFactor = s.pAutoDecimationFactor;
            end
            % Call base class method
            loadObjectImpl@dsp.internal.PolyphaseFFTBase(obj,s,wasLocked);
        end
        %------------------------------------------------------------------
        function validateInputsImpl(obj,u)
            validateattributes(u, {'single', 'double'}, {'2d'},'','');
            D = obj.DecimationFactor;
            if ~isempty(coder.target)
                isArbSize = obj.AllowArbitraryInputLength;
                isFixedInput = propagatedInputFixedSize(obj, 1);
                % Verify frame size
                coder.internal.errorIf(isFixedInput && ~isArbSize && size(u,1)>0 && rem(size(u,1), D)~=0,['dsp:system',...
                    ':Channelizer:frameSize'], size(u, 1), D);
            end
            % Verify number of channels
            if obj.numChannels == -1 || obj.numChannels ==  0 || size(u,2) == 0
                return;
            end
            coder.internal.errorIf(size(u,2) ~= obj.numChannels, ['dsp:system',...
                ':Shared:numChannels']);
        end
        %------------------------------------------------------------------
        function validatePropertiesImpl(obj)
            % validate properties
            D = obj.DecimationFactor;
            M = obj.NumFrequencyBands;
            % Throw an error if the specified Decimation factor is not a
            % less than or equal to the number of frequency bands
            coder.internal.errorIf(D > M,['dsp:system',...
                ':Channelizer:decimationFactor'],M);
        end
        %------------------------------------------------------------------
        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end
        %------------------------------------------------------------------
        function designPrototypeLowpass(obj)
            M = obj.NumFrequencyBands;
            P = obj.NumTapsPerBand;
            Astop = obj.StopbandAttenuation;
            b = cast(designMultirateFIR(1,M,ceil(P/2),Astop),obj.InputDataType);
            obj.PolyphaseMatrix  = reshape(b,M,P);
        end
        %------------------------------------------------------------------
        function [H,r] = freqzHelper(obj,Nfilts,varargin)
            p = inputParser;
            Nbands = obj.NumFrequencyBands;
            p.addOptional("indices",1:min(Nbands,Nfilts));
            p.addParameter("Fs",-12345);
            p.addParameter("overall",false);
            p.addParameter("NFFT",8192);
            p.parse(varargin{:});
            r = p.Results;

            validateattributes(r.indices,{'numeric'},...
                {'row','finite','integer','positive','real','<=',Nbands},...
                'freqz','indices');

            if r.Fs ~= -12345
                validateattributes(r.Fs,{'numeric'},...
                    {'scalar','finite','real','positive'},...
                    'freqz','Fs');
            end

            validateattributes(r.NFFT,{'numeric'},...
                {'scalar','finite','integer','positive','real'},...
                'freqz','NFFT');

            validateattributes(r.overall,{'logical'},{'scalar'},...
                'freqz','overall');

            H = getFilters(obj,r.indices);
        end
        %------------------------------------------------------------------
        function nc = getNumChannels(~,u)
            nc = size(u,2);
        end
        %------------------------------------------------------------------
        function setUserDefinedDecimationFactor(obj,D)
            % If the user set the decimation factor, set the decimation
            % factor source to 'property'
            obj.pDecimationFactorSource = 'property';
            obj.pUserDefinedDecimationFactor = D;
        end
        %------------------------------------------------------------------
        function setAutoDecimationFactor(obj)
            % If the user did not set the decimation factor, it should
            % be equal to the number of frequency bands
            obj.pAutoDecimationFactor = obj.NumFrequencyBands;
        end
        function ol = getOutputFrameSize(obj, il)
            ol = int32(0);
            maxol = int32(ceil(il/obj.DecimationFactor));
            for ii = 1:il
                st1 = obj.StartIdx(obj.ModuloIdx + 1);
                st2 = obj.StopIdx(obj.ModuloIdx + 1);
                ol = ol + st2 - st1;
                obj.ModuloIdx = int32(mod(obj.ModuloIdx + 1, obj.pCompiledDecimationFactor));
            end
            assert(ol <= maxol);
        end
    end
    %----------------------------------------------------------------------
    % Static Hidden methods
    %----------------------------------------------------------------------
    methods (Static, Hidden)
        %------------------------------------------------------------------
        function useHalide = HalideEnabled(x,NTPB,M)
            useHalide = false;
            featureMode = coder.const(feval('dsp.internal.feature','dsp_simulations','halide'));
            if coder.const(strcmp(featureMode,'auto')) && isempty(coder.target)
                N = size(x, 2);
                useHalide = coder.const((N==1 && NTPB>=12 && M>=64) || ...
                    (N>1 && NTPB>=8 && M>=48));
            elseif coder.const(strcmp(featureMode,'on'))
                useHalide = true;
            end
        end
        %------------------------------------------------------------------
        function [polyMtx, useHalide] = pmatrixdecider(x,NTPB,M,p)
            
            % Helper function for SpectrumEstimator to choose the correct
            % orientation of the polyphase matrix for Halide
            useHalide = coder.const(dsp.Channelizer.HalideEnabled(x,NTPB,M));
            isSimCG = ~coder.target('MATLAB') && ...
                coder.const(feval('dsp.enhancedsim.IsSysObjSimInCodeGen',coder.target));

            if isSimCG || (isempty(coder.target) && useHalide)
                polyMtx = transpose(p);
            else
                polyMtx = p;
            end
        end
        %------------------------------------------------------------------
        function [y,z,phIdx,state] = firpolyphase_channelizer(x,vExtra,z,p,D,K,libFlagInterpretMode,currOutputLen,phIdx,state)
            % Lx = length of input
            % N  = Number of Channels
            % v  = temporary computation Lx/D x M x N
            % D  = decimation factor
            % K  =  number of states in the state machine
            Lx = size(x,1);
            N  = size(x,2);
            if isempty(coder.target)
                if libFlagInterpretMode 
                    %halide
                    Np = size(p,1);
                    M  = size(p,2);
                    if isempty(x)
                        v = vExtra;
                    else
                        v = [vExtra;zeros(currOutputLen - 1,M,N,'like',x)];
                    end
                    vBuff = zeros(1, M, "like", v);
                    [v,z,phIdx,state] = dsp.internal.builtins.firPolyphaseFFTAnalysisHalide( ...
                        complex(x),p,z,vBuff,v,Lx,Np,N,M,D,K,phIdx,state,currOutputLen);
                else
                    %C
                    M  = size(p,1);
                    if isempty(x)
                        v = vExtra;
                    else
                        v = [vExtra;zeros(currOutputLen - 1,M,N,'like',x)];
                    end
                    [v,z,phIdx,state] = dsp.internal.builtins.firPolyphaseFFTAnalysisC( ...
                        complex(x),v,z,p,Lx,M,N,D,K,phIdx,state,currOutputLen);
                end
            else
                libFlagForCodegen = ...
                    coder.const(feval('dsp.enhancedsim.IsSysObjSimInCodeGen',coder.target)) && ...
                    coder.const(~strcmp(feval('dsp.internal.feature','dsp_simulations','halide'),'off'));
                if coder.const(libFlagForCodegen)
                    M  = size(p,2);
                    Np = size(p,1);
                    if currOutputLen > 0
                        v = [vExtra;zeros(currOutputLen - 1,M,N,'like',x)];
                    else
                        v = vExtra;
                    end
                    vBuff = zeros(1, M, "like", v);
                    [v,z,phIdx,state] = dsp.Channelizer.firpolyphase_channelizer_cg_halide( ...
                        x,v,vBuff,z,p,Lx,M,D,Np,N,K,currOutputLen,phIdx,state);
                else
                    M  = size(p,1);
                    if currOutputLen > 0
                        v = [vExtra;zeros(currOutputLen - 1,M,N,'like',x)];
                    else
                        v = vExtra;
                    end
                    [v,z,phIdx,state] = dsp.Channelizer.firpolyphase_channelizer_cg( ...
                        x,v,z,p,M,D,K,currOutputLen,phIdx,state);
                end
            end
            y= fft(v(1:currOutputLen,1:M,:),[],2);
        end
        %------------------------------------------------------------------
        function [v,z,phaseIdx,state] = firpolyphase_channelizer_cg(x,v,z,p,M,D,K,outLen,phaseIdx,state)
            % M - Number of frequency bands
            % D - Decimation factor
            % K - number of states in the state machine
            Lx = int32(size(x,1));
            OL = int32(M - D);
            K = int32(K);
            D = int32(D);
            oneCast = int32(1);
            vidx = oneCast;
            if outLen == int32(0)
                z(phaseIdx - Lx + 1:phaseIdx,:) = x(Lx:-oneCast:oneCast,:);
                phaseIdx = phaseIdx - Lx;
                return
            end
            assert(phaseIdx <= Lx)
            % Load initial samples
            z(oneCast:phaseIdx,:) = x(phaseIdx:-oneCast:oneCast,:);
            % form inner products
            for mm = oneCast:M
                cidx = dsp.Channelizer.getFrequencyBandOutputIndex(mm,M);
                woa = p(mm,:) * z(mm:M:end,:);
                v(vidx,cidx,:) = woa(oneCast,:);
            end
            % circular shift output array
            [shift,state] = dsp.Channelizer.getCircBufferShiftValue(K,M,OL,state);
            v(vidx,:,:) = circshift(v(vidx,:,:), shift);

            if outLen == oneCast
                phaseIdx = phaseIdx + D - Lx;
                % Shift the old data in the register
                z(D + oneCast:end,:) = z(oneCast:end - D,:);
                % Load last D - phaseIndex samples into the shift register from the left
                z(phaseIdx + oneCast:D,:) = x(Lx:-oneCast:Lx - D + phaseIdx + oneCast,:);
                return
            end

            vidx = vidx + oneCast;
            oc = int32(0); 
            for nn = phaseIdx + oneCast:D:Lx - D + oneCast
                % Update the delay line
                z(D + oneCast:end,:) = z(oneCast:end - D,:);
                % Load D-Input samples
                for j = oneCast:D
                    z(j,:) = x(nn+D-j,:);
                end
                % form inner products
                for mm = oneCast:M
                    cidx = dsp.Channelizer.getFrequencyBandOutputIndex(mm,M);
                    woa = p(mm,:) * z(mm:M:end,:);
                    v(vidx,cidx,:) = woa(oneCast,:);
                end
                % circular shift output array
                [shift,state] = dsp.Channelizer.getCircBufferShiftValue(K,M,OL,state);
                v(vidx,:,:) = circshift(v(vidx,:,:), shift);
                vidx = vidx + oneCast;
                oc = int32(nn);
            end
            % Update the phase index
            consumedInputLength = oc + D - oneCast;
            phaseIdx = consumedInputLength - Lx + D;
            % Shift the old data in the register
            z(D + oneCast:end,:) = z(oneCast:end - D,:);
            % Load last D - phaseIndex samples into the shift register from the left
            z(phaseIdx + oneCast:D, :) = x(Lx:-oneCast:Lx - D + phaseIdx + oneCast,:);
        end
        function [v,z,phIdx,state] = firpolyphase_channelizer_cg_halide(x,v,vBuff,z,p,Lx,M,D,Np,N,K,ol,phIdx,state)
            coder.cinclude('iHalideFIRPolyphaseFFTAnalysis.hpp');
            if isa(x,'single') && ~isreal(x)
                if isreal(p)
                    func = 'processHalide_PolyphaseAnalysisCRS';
                else
                    func = 'processHalide_PolyphaseAnalysisCCS';
                end
            elseif isa(x,'double') && ~isreal(x)
                if isreal(p)
                    func = 'processHalide_PolyphaseAnalysisCRD';
                else
                    func = 'processHalide_PolyphaseAnalysisCCD';
                end
            elseif isa(x,'single') && isreal(x)
                if isreal(p)
                    func = 'processHalide_PolyphaseAnalysisRRS';
                else
                    func = 'processHalide_PolyphaseAnalysisRCS';
                end
            elseif isa(x,'double') && isreal(x)
                if isreal(p)
                    func = 'processHalide_PolyphaseAnalysisRRD';
                else
                    func = 'processHalide_PolyphaseAnalysisRCD';
                end
            end
            coder.ceval(func, ...
                x,p,coder.ref(z),vBuff,coder.ref(v),uint32(Lx),uint32(Np),uint32(N),uint32(M),uint32(D),uint32(K),coder.ref(phIdx),coder.ref(state),uint32(ol));
        end
        %------------------------------------------------------------------
        function [shift,state] = getCircBufferShiftValue(K,M,OL,state)
            % Get the circular buffer shift value to baseband the
            % channelizer frequency bands
            oneCast = int32(1);
            shift = M - mod(OL * (state - oneCast),M);
            state = mod(state + oneCast,K);
            if state == int32(0)
                state = K;
            end
        end
        %------------------------------------------------------------------
        function cidx = getFrequencyBandOutputIndex(mm,M)
            % Get the frequency band output index in the temporary
            % computation matrix v
            if(mm == 1)
                cidx = mm;
            else
                cidx = M - mm + 2;
            end
        end
    end
end
%--------------------------------------------------------------------------
function decimationFactor = getDecimationFactor(D,M,source)
    if strcmpi(source,'property')
        decimationFactor = D;
    else
        decimationFactor = M;
    end
end
