classdef (StrictDefaults)DCBlocker < matlab.System
%DCBlocker Block DC component from input signal
%   DCB = dsp.DCBlocker returns a System object, DCB, that blocks the DC
%   component from each channel (i.e. column) of an input signal. Operation
%   runs over time to continually estimate and remove the DC offset.
%
%   DCB = dsp.DCBlocker('PropertyName', PropertyValue, ...) returns a DC
%   blocker System object, DCB, with each specified property set to the
%   specified value.  You can specify additional name-value pair arguments
%   in any order as (Name1,Value1,...,NameN,ValueN).
%
%   Step method syntax:
%
%   Y = step(DCB, X) removes the DC component of the input X, returning the
%   result in Y. X is a numeric, signed matrix, with time samples recorded
%   in rows and independent channels of data recorded in columns.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   DCBlocker methods:
%
%   step     - See above description for use of this method
%   reset    - Reset internal states stored for mean computation
%   release  - Allow property value and input characteristics changes
%   clone    - Create DCBlocker object with same property values
%   isLocked - Locked status (logical)
%   fvtool   - Visualize the DC blocker's frequency response
%
%   DCBlocker properties:
%
%   Algorithm           - Algorithm for estimating DC offset
%   NormalizedBandwidth - Normalized bandwidth of lowpass IIR or CIC filter 
%   Order               - Order of lowpass IIR elliptic filter
%   Length              - Number of past input samples for FIR algorithm
%
%   % EXAMPLE: Remove a DC offset from a signal using 'FIR', 'IIR', and 
%   % 'Subtract mean' techniques. Loop to allow the IIR algorithm to 
%   % converge.
%   t = (0:0.001:100)';
%   x = sin(30*pi*t) + 1;
%   dcblock1 = dsp.DCBlocker('Order', 6);   % IIR is the default algorithm
%   dcblock2 = dsp.DCBlocker('Algorithm', 'FIR', 'Length', 100);
%   dcblock3 = dsp.DCBlocker('Algorithm', 'Subtract mean');
%   for index = 1:100
%       range = (1:1000) + 1000*(index-1);
%       y1 = dcblock1(x(range));
%       y2 = dcblock2(x(range));
%       y3 = dcblock3(x(range));
%   end
%   plot(t(1:1000),x(1:1000),...
%       t(1:1000),y1, ...
%       t(1:1000),y2, ...
%       t(1:1000),y3);
%   legend(sprintf('Input DC: %.3f', mean(x)), ...
%       sprintf('IIR DC: %.3f', mean(y1)), ...
%       sprintf('FIR DC: %.3f', mean(y2)), ...
%       sprintf('Subtract mean DC: %.3f', mean(y3)));
%
%   See also dsp.FIRFilter, dsp.BiquadFilter, dsp.CICDecimator.
  
%   Copyright 2013-2023 The MathWorks, Inc.
    
%#codegen
%#ok<*EMCA>
    
properties (Nontunable)
  %Algorithm Algorithm for estimating DC offset
  %  Specify the DC offset estimating algorithm as one of 'IIR' | 'FIR' |
  %  'CIC' | 'Subtract mean'.  The default is 'IIR'. You can visualize the
  %  IIR, FIR. and CIC responses with the fvtool method.
  %
  %  'IIR' uses a recursive estimate based on a narrow, lowpass elliptic
  %  filter whose order is set using the Order property and whose bandwidth
  %  is set using the NormalizedBandwidth property. This algorithm may use
  %  less memory than FIR and be more efficient.
  %
  %  'FIR' uses a non-recursive, moving average estimate based on a finite
  %  number of past input samples that is set using the Length property.
  %  This algorithm may use more memory than IIR and be less efficient.
  %
  %  'CIC' uses a CIC decimator, with a decimation factor of 1, whose
  %  differential delay is calculated using the NormalizedBandwidth
  %  property.  It uses two sections to ensure that the first sidelobe
  %  attenuation is at least 25 dB below the filter's main lobe.  This
  %  algorithm requires fixed-point inputs, and can be used for HDL code
  %  generation.
  %  
  %  'Subtract mean' computes the means of the columns of the input matrix,
  %  and subtracts the means from the input.  This method does not retain
  %  state between inputs.
  Algorithm (1,:) char {matlab.system.mustBeMemberMessageID(Algorithm, ...
                     {'dsp:system:DCBlocker:IIR_MP',;...
                     'dsp:system:DCBlocker:FIR_MP',;...
                     'dsp:system:DCBlocker:CIC_MP',;...
                     'dsp:system:DCBlocker:SubtractMean_MP'})} = 'IIR';
  %NormalizedBandwidth  Normalized bandwidth of lowpass IIR or CIC filter
  %  Specify the normalized bandwidth of the IIR or CIC filter used to
  %  estimate the DC component of the input signal. This property applies
  %  when you set the Algorithm property to 'IIR' or 'CIC'. It must be a
  %  real scalar greater than 0 and less than 1. The default value is
  %  0.001.
  NormalizedBandwidth = 0.001
  % Length  Number of past input samples for FIR algorithm
  % Specify the number of past inputs used to estimate the running mean.
  % This property applies when you set the Algorithm property to 'FIR'.
  % It must be a positive integer. The default value is 50.
  Length (1, 1) {mustBePositive, mustBeInteger} = 50
  % Order   Order of lowpass IIR elliptic filter
  % Used when Algorithm is 'IIR'.  Specify the order of a lowpass elliptic
  % filter that estimates the DC level.  This property applies when you set
  % the Algorithm property to 'IIR'.  It must be an integer greater than 3.
  % The default value is 6.
  Order (1, 1) {mustBePositive, mustBeInteger} = 6  
end

properties (Access=private, Nontunable)
  pFilter            % holds a System object
  pUseFilter = true  % set this property in setupImpl to save time in stepImpl
  pDiffDelay         % computed CIC differential delay
  pCICGainComp       % CIC filter gain compensation value
end

properties (Access = protected)
  % pNumChannels Number of input channels
  pNumChannels
end
    
methods
  function obj = DCBlocker(varargin)
    setProperties(obj, nargin, varargin{:});
    
    % Set initial pNumChannels to -1 (will be set to actual value in setup)
    obj.pNumChannels = int32(-1);    
  end
  
  function set.Order(obj, value)
    validateattributes (value, {'numeric'}, ...
      {'real', 'scalar', 'positive', 'integer', 'nonnan', 'nonempty', ...
      'finite', '>=', 3}, ...
      '', 'Order'); 
    obj.Order = value;
  end
  
  function set.NormalizedBandwidth(obj, value)
    validateattributes (value, {'numeric'}, ...
      {'real', 'scalar', 'nonnan', 'nonempty', 'finite', '>', 0, '<', 1}, ...
      '', 'NormalizedBandwidth'); 
    obj.NormalizedBandwidth = value;
  end
  
  function set.Length(obj, value)
    validateattributes (value, {'numeric'}, ...
      {'real', 'positive', 'scalar', 'integer', 'nonnan', 'nonempty', ...
      'finite'}, ...
      '', 'Length'); 
    obj.Length = value;
  end
  
  function varargout = fvtool(obj, varargin)
    % With fvtool, visualize the DC blocker's response. Visualize the
    % magnitude response, phase response, group delay, impulse response, or
    % pole-zero plot, and view the coefficients.
    
    usingSubtractMean = strcmpi(obj.Algorithm, 'Subtract mean');
    coder.internal.errorIf(usingSubtractMean, ...
      'dsp:system:DCBlocker:DCBlocker_novisualization');
        
    % The fvtool method does not participate in code generation
    if ~isempty(coder.target)
      coder.internal.errorIf(true, 'dsp:system:DCBlocker:DCBlocker_codegen');
    end
    
    fvtool_filt = getFVTOOLFilter(obj);

    hFVT = fvtool(fvtool_filt, varargin{:});
    if nargout > 0
        varargout{1} = hFVT;
    end
    
    if strcmpi(obj.Algorithm, 'CIC')
      Mcic = dsp.DCBlocker.computeDiffDelayForCIC(obj.NormalizedBandwidth);
      msg = sprintf(['Number of sections = 2\nDifferential delay = ' ...
                     num2str(Mcic) ' samples']);
      hFVTFigure = findall(hFVT,'type','figure');
      annotation(hFVTFigure,'textbox', [0.65, 0.7, 0.1, 0.1], ...
        'String', msg);
    end
  end 
    
end
    
methods (Access=protected)
  function validateInputsImpl(obj, x)    
    % Input must be numeric or fi.  Must be signed.
    coder.internal.errorIf(~isnumeric(x), ...
      'MATLAB:system:invalidInputDataType','X','numeric');
    
    inputIsUint = ~isempty(strfind(class(x), 'uint')); %#ok
    coder.internal.errorIf(inputIsUint, 'dsp:system:DCBlocker:DCBlocker_unsigned');
    
    if isfi(x)
      inputIsUnsigned = strcmp(x.Signedness, 'Unsigned');
      coder.internal.errorIf(inputIsUnsigned, 'dsp:system:DCBlocker:DCBlocker_unsigned');
    end

    isSizePropRunning = ~isempty(coder.target) && eml_ambiguous_types;
    isCIC = strcmpi(obj.Algorithm, 'CIC');
    if ~isSizePropRunning && isCIC
      isFixedPt = isfi(x) || strcmpi(class(x), 'int8') || ...
        strcmpi(class(x), 'int16') || strcmpi(class(x), 'int32') || ...
        strcmpi(class(x), 'int64');
      coder.internal.errorIf(~isFixedPt, 'dsp:system:DCBlocker:DCBlocker_CICNeedsFixPt');
    end
  
    % Warn if the input is a row vector
    if ( isrow(x) && ~isscalar(x) )
      coder.internal.warning('dsp:system:RowVectorScalarOps'); 
    end
    
    % The number of input channels is not allowed to change
    coder.internal.errorIf(...
        obj.pNumChannels~=-1 && obj.pNumChannels ~= size(x,2), ...
        'dsp:system:varSizeChannelsNotSupported');
    
  end
  
  function flag = isInputSizeMutableImpl(~,~)
    flag = true;
  end
  
  function numchans = getNumChannels(obj,u)
      % GETNUMCHANNELS Return the number of input channels
      if obj.getExecPlatformIndex()
          thisSize = propagatedInputSize(obj, 1);
          numchans = thisSize(2);
      else
          numchans = size(u,2);
      end
  end
       
  function setupImpl(obj, u) 
    % Initialize internal values on first use.

    numchans = getNumChannels(obj,u);
    obj.pNumChannels = int32(numchans);
    
    if ~strcmpi(obj.Algorithm, 'Subtract mean') && obj.getExecPlatformIndex()
        sts = getSampleTime(obj);
        % Never allow continuous time
        coder.internal.errorIf(sts.SampleTime==0,...
            'dsp:system:Shared:ContinuousTimeNotAllowed');
    end
        
    % For integer inputs, the BiquadFilter and FIRFilter will convert
    % coefficient datatypes as needed.
    coder.extrinsic('zp2sos');
    coder.extrinsic('dsp.DCBlocker.computeDiffDelayForCIC');
    if strcmpi(obj.Algorithm, 'IIR')
      pbRipple  = 0.1;    % passband ripple, in dB
      sbAtten   = 60;     % stopband attenuation, in dB
      [z, p, k] = ellip(obj.Order, pbRipple, sbAtten, ...
          obj.NormalizedBandwidth);
      if isempty(coder.target)
        sos = zp2sos(z, p, k);
      else
        sos = coder.const(zp2sos(z, p, k));
      end
      obj.pFilter = dsp.BiquadFilter( ...
        'Structure', 'Direct form II transposed', ...
        'SOSMatrix', sos, ...
        'RoundingMethod', 'Convergent', ...
        'OverflowAction', 'Saturate');
      obj.pUseFilter = true;
    elseif strcmpi(obj.Algorithm, 'FIR')
      % Design a boxcar, lowpass filter
      obj.pFilter = dsp.FIRFilter( ...
        'Structure', 'Direct form transposed', ...
        'Numerator', ones(1,obj.Length)./obj.Length);
      obj.pUseFilter = true;
    elseif strcmpi(obj.Algorithm, 'CIC')
      % Calculate the CIC gain compensation
      numSections = 2;      
      if isempty(coder.target)
        Mcic = dsp.DCBlocker.computeDiffDelayForCIC(obj.NormalizedBandwidth);
        CICGain = Mcic ^ numSections;
        CICGainComp = 1 / CICGain;
      else
        Mcic = coder.const(...
          dsp.DCBlocker.computeDiffDelayForCIC(obj.NormalizedBandwidth));
        CICGain = coder.const(Mcic ^ numSections);
        CICGainComp = coder.const(1 / CICGain);
      end
      
      obj.pFilter = dsp.CICDecimator( ...
        'DecimationFactor', 1, ...
        'NumSections', 2, ...
        'DifferentialDelay', Mcic);
      obj.pDiffDelay = Mcic;
      obj.pCICGainComp = fi(CICGainComp);
      
      obj.pUseFilter = true;      
    else  % Subtract mean
      obj.pUseFilter = false;
    end
  end
   
  function resetImpl(obj)
    if obj.pUseFilter
      reset(obj.pFilter);
    end
  end
  
  function releaseImpl(obj)
    if obj.pUseFilter
      release(obj.pFilter);
    end
    obj.pNumChannels = int32(-1);
  end
        
  function y = stepImpl(obj, u)
    % Block DC component of input signals
    if obj.pUseFilter
      if ( strcmpi(obj.Algorithm, 'IIR') || strcmpi(obj.Algorithm, 'FIR') )
        y = u - step(obj.pFilter, u);
      elseif strcmpi(obj.Algorithm, 'CIC')
        filtOut = step(obj.pFilter, u) * obj.pCICGainComp;        
        y = u - filtOut;
      end
    else
      nChan = size(u, 2);
      y = u;  % for initialization in complexity and data type
      for iChan = 1 : nChan
        y(:,iChan) = u(:,iChan) - mean(u(:,iChan));
      end
    end
    y = cast(y, 'like', u);
  end
        
  function flag = isInactivePropertyImpl(obj,prop)
    % True if property should not be displayed
    if strcmpi(obj.Algorithm, 'IIR')
      flag = strcmpi(prop, 'Length');  % Suppress for 'IIR'    
    elseif strcmpi(obj.Algorithm, 'FIR')
      flag = strcmpi(prop, 'Order') || ...
             strcmpi(prop, 'NormalizedBandwidth');  % Suppress for 'FIR'
    elseif strcmpi(obj.Algorithm, 'CIC')
      flag = strcmpi(prop, 'Length') || ...
             strcmpi(prop, 'Order');  % Suppress for 'CIC'
    elseif strcmpi(obj.Algorithm, 'Subtract mean')
      flag = strcmpi(prop, 'Order') || ...
             strcmpi(prop, 'NormalizedBandwidth') || ...
             strcmpi(prop, 'Length');  % Suppress for 'Subtract mean'
    end
  end
  
  function s = saveObjectImpl(obj)
    s = saveObjectImpl@matlab.System(obj);
    if isLocked(obj)
      % Public properties handled automatically
      s.pFilter      = matlab.System.saveObject(obj.pFilter);
      s.pUseFilter   = matlab.System.saveObject(obj.pUseFilter);
      s.pNumChannels = obj.pNumChannels;
      s.pDiffDelay   = obj.pDiffDelay;
      s.pCICGainComp = obj.pCICGainComp;
    end
  end

  function loadObjectImpl(obj, s, wasLocked)
    if wasLocked
      % Public properties handled automatically
      obj.pFilter      = matlab.System.loadObject(s.pFilter);
      obj.pUseFilter   = matlab.System.loadObject(s.pUseFilter);
      obj.pNumChannels = s.pNumChannels;
      obj.pDiffDelay   = s.pDiffDelay;
      obj.pCICGainComp = s.pCICGainComp;      
    end
    % Call the base class method
    loadObjectImpl@matlab.System(obj, s);
  end
  
  function prepareFilter(obj)
    if ~isLocked(obj)
      % We need to create the underlying filter first. Call setup to create
      % pFilter and then release.
      if ~strcmpi(obj.Algorithm, 'CIC')
        setup(obj, 1);
      else
        setup(obj, fi(1));
      end
      release(obj)
    end
  end 
  
  function fvtool_filt = getFVTOOLFilter(obj)
      filt = getFilter(obj);
      % filt is the lowpass filter that estimates the DC component
      % Construct equivalent DC Blocker filter
      if  strcmpi(obj.Algorithm, 'IIR') || strcmpi(obj.Algorithm, 'FIR')
          fvtool_filt = dfilt.parallel(1,dfilt.cascade(-1,todfilt(filt)));
      elseif strcmpi(obj.Algorithm, 'CIC')
          fvtool_filt = dfilt.parallel(1,dfilt.cascade(-1,filt));
      end
  end
end

methods (Hidden)
  function filt = getFilter(obj)
    % Return the filter used for blocking
    
    % Suppress MFILT deprecation warnings
    w = warning('off', 'dsp:mfilt:mfilt:Obsolete');
    restoreWarn = onCleanup(@() warning(w)); 
        
    prepareFilter(obj)
    % For CIC, create a composite filter that includes CIC gain
    % compensation
    if strcmpi(obj.Algorithm, 'CIC')
      hCIC = mfilt.cicdecim(1, obj.pDiffDelay, 2); %#ok
      hGainComp = dfilt.scalar(obj.pCICGainComp);
      filt = mfilt.cascade(hCIC, hGainComp);%#ok
    else
        filt = obj.pFilter;
    end
  end    
end

methods(Static, Hidden)
  function Mout = computeDiffDelayForCIC(BWnorm)
    % computeDiffDelayForCIC
    
    % Calculate the differential delay M required to satisfy the
    % normalized bandwidth requirement
    M = 1;  % init value
    foundM = false;
    while ~foundM
      num = sin(pi*BWnorm*M/2);
      den = M * sin(pi*BWnorm/2);
      gain = (num/den)^2;  % numSections is 2
      if gain > 1/sqrt(2)
        M = M+1;
      else
        foundM = true;
      end
    end
    Mout = M;
  end
end

end

% EOF
