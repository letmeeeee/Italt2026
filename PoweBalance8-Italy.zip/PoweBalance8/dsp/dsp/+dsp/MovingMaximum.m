classdef (StrictDefaults)MovingMaximum < dsp.internal.AbstractMovingMinMax
    %   MovingMaximum Compute moving maximum MMAX = dsp.MovingMaximum
    %   returns a System object, MMAX, that computes the moving maximum of
    %   the input signal.
    %
    %   MMAX = dsp.MovingMaximum('Name', Value, ...) returns a moving
    %   maximum System object, MMAX, with each specified property name set
    %   to the specified value. You can specify additional name-value pair
    %   arguments in any order as (Name1,Value1,...,NameN, ValueN).
    %
    %   MMAX = dsp.MovingMaximum(Length,'PropertyName', PropertyValue, ...)
    %   returns a moving maximum object, MMAX, with the WindowLength
    %   property set to Length, and other properties set to the specified
    %   values.
    %
    %   Step method syntax:
    %
    %   Y = step(MMAX, X) computes the moving maximum, Y, of the input X.
    %   Each column of X is a channel. The System object computes the
    %   moving maximum of each channel of the input signal independently
    %   over time. X must be real.
    %
    %   System objects may be called directly like a function instead of
    %   using the step method. For example, y = step(obj, x) and y = obj(x)
    %   are equivalent.
    %
    %   MovingMaximum methods:
    %
    %   step                     - Compute moving maximum of input 
    %   release                  - Allow property value and input
    %                              characteristics changes, and release
    %                              moving maximum resources
    %   clone                    - Create moving maximum object with same
    %                              property values
    %   isLocked                 - Display locked status (logical) 
    %   reset                    - Reset the states of the moving maximum
    %
    %   MovingMaximum properties:
    %
    %   SpecifyWindowLength     - Choose to specify sliding window length
    %   WindowLength            - Sliding window length
    %
    %   % EXAMPLE: Compute the moving maximum of the sum of three sine
    %   % waves with varying amplitude. Use a sliding window of length 30.
    %   sine = dsp.SineWave('SampleRate',100,'Frequency',[2 5 10],...
    %                       'SamplesPerFrame',100);
    %   mmax   = dsp.MovingMaximum(30);
    %   scope  = timescope('SampleRate',100,...
    %                      'TimeSpanSource','property',...
    %                      'YLimits',[-4.5 4.5]);
    %   for index = 1:100
    %     sine.Amplitude = rand(1,3);
    %     x = sum(sine(),2);
    %     xmax = mmax(x);
    %     scope([x,xmax])
    %   end
    %
    %   See also dsp.MovingMinimum, dsp.MovingAverage, dsp.MovingRMS, 
    %   dsp.MovingVariance, dsp.MovingStandardDeviation
    
    %   Copyright 2016-2021 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCLS>
    
   methods
        function obj = MovingMaximum(varargin)
            obj@dsp.internal.AbstractMovingMinMax(varargin{:});
        end
    end
    
    methods(Access = protected)
        
        function statObj = setupStatisticObject(obj)
 
            if obj.SpecifyWindowLength
                if ~isempty(coder.target)
                    statObj  = dsp.internal.SlidingWindowMaximumCG('WindowLength',obj.WindowLength,'NumChans',obj.pNumChannels);
                else
                    statObj  = dsp.internal.SlidingWindowMaximumSim('WindowLength',obj.WindowLength,'NumChans',obj.pNumChannels);
                end
            else
                statObj = dsp.internal.RunningMaximum('NumChans',obj.pNumChannels);
            end
            
        end

        %% Support mutable input size
        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end  
    end   
    
end
