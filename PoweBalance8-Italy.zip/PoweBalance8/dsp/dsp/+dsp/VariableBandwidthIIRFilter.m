classdef (StrictDefaults)VariableBandwidthIIRFilter  < dsp.internal.VariableBandwidthFilterBase
%VariableBandwidthIIRFilter Variable bandwidth IIR filter
%   VBIIR = dsp.VariableBandwidthIIRFilter returns a System object, VBIIR, 
%   which independently filters each channel of the input over time using
%   specified IIR filter specifications. The IIR filter's passband 
%   frequency may be tuned during the filtering operation. The IIR filter 
%   is designed using the elliptical method. The IIR filter is tuned using 
%   IIR spectral transformations based on allpass filters [1]. 
%
%   VBIIR = dsp.VariableBandwidthIIRFilter('Name', Value, ...) returns a 
%   Variable Bandwidth IIR Filter System object, VBIIR, with each specified 
%   property name set to the specified value. You can specify additional 
%   name-value pair arguments in any order as (Name1,Value1,...,NameN,
%   ValueN).
%
%   Step method syntax:
%
%   Y = step(VBIIR, X) filters the real or complex input signal X using the
%   specified filter to produce the output Y. The System object filters
%   each channel of the input signal independently over time.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   VariableBandwidthIIRFilter methods:
%
%   step          - See above description for use of this method
%   release       - Allow property value and input characteristics changes                      
%   clone         - Create Variable Bandwidth IIR Filter object with 
%                   same property values                      
%   isLocked      - Locked status (logical)
%   reset         - Reset the internal states to initial conditions
%
%   VariableBandwidthIIRFilter properties:
%
%   SampleRate                   - Input sample rate
%   FilterType                   - IIR filter type
%   FilterOrder                  - IIR filter order
%   NormalizedFrequency          - Provide normalized frequencies for filter specifications
%   PassbandFrequency            - Filter passband frequency
%   CenterFrequency              - Filter center frequency
%   Bandwidth                    - Filter bandwidth
%   PassbandRipple               - Filter passband ripple
%   StopbandAttenuation          - Filter stopband attenuation
%
%   This System object supports several filter analysis methods. For more
%   information, type dsp.VariableBandwidthIIRFilter.helpFilterAnalysis
%
%   % Example: Filter a signal through a variable bandwidth bandpass IIR
%   % filter. Tune the center frequency and the bandwidth of the IIR filter. 
%   Fs = 44100; % Input sample rate
%   FrameLength = 1024;
%   % Define a bandpass variable bandwidth IIR filter:
%   VBIIR = dsp.VariableBandwidthIIRFilter(FilterType='Bandpass',...
%                                          FilterOrder=8,...
%                                          NormalizedFrequency=false,...
%                                          SampleRate=Fs,...
%                                          CenterFrequency=1e4,...
%                                          Bandwidth=4e3);
%   TFE = dsp.TransferFunctionEstimator('FrequencyRange','onesided');
%   PLOTTER = dsp.ArrayPlot(PlotType='Line',...
%                           XOffset=0,...
%                           YLimits=[-120 5], ...
%                           SampleIncrement=Fs/FrameLength,...
%                           YLabel='Frequency Response (dB)',...
%                           XLabel='Frequency (Hz)',...
%                           Title='System Transfer Function');
%   SINE = dsp.SineWave(SamplesPerFrame=FrameLength);
%   for index=1:500
%      % Generate input
%      x = SINE() + randn(FrameLength,1);
%      % Pass input through the filter
%      y = VBIIR(x);
%      % Transfer function estimation
%      H = TFE(x,y);
%      % plot transfer function
%      PLOTTER(20*log10(abs(H)))   
%      % Tune bandwidth and center frequency of the IIR filter
%      if (index==250)
%        VBIIR.CenterFrequency = 5000;
%        VBIIR.Bandwidth = 2000;
%      end
%   end
%
%   See also dsp.VariableBandwidthFIRFilter, dsp.FIRFilter, dsp.IIRFilter, 
%            dsp.BiquadFilter, dsp.SOSFilter, dsp.AllpoleFilter

%   Copyright 2013-2022 The MathWorks, Inc.
    
%   References:
%
%   [1] A. G. Constantinides, "Spectral transformations for digital 
%       filters",  Proc. Inst. Elect. Eng.,  vol. 117,  no. 8,  pp.1585 -
%       1590, 1970. 

%#codegen
%#ok<*EMCLS>

properties (Nontunable)
  % FilterOrder IIR filter order
  %   Specify the order of the IIR filter as a positive integer scalar. The 
  %   default is 8.
  FilterOrder = 8;
  % PassbandRipple Filter passband ripple (dB)
  %   Specify the filter passband ripple as a real, positive scalar in 
  %   decibels (dB). The default is 1 dB.
  PassbandRipple = 1;
  % StopbandAttenuation Filter Stopband attenuation (dB)
  %   Specify the filter stopband attenuation as a real, positive scalar in 
  %   decibels (dB). The default is 60 dB.
  StopbandAttenuation = 60;
end
    
properties
  % PassbandFrequency Filter passband frequency
  %   Specify the filter passband frequency as a real, positive scalar less
  %   than SampleRate/2. This property applies when you set the FilterType
  %   property to 'Lowpass' or 'Highpass'. Specify the value of passband
  %   frequency in Hertz when you set NormalizedFrequency to false, and set
  %   the value in normalized units when you set NormalizedFrequency to
  %   true. The default is 512 Hz. This property is tunable.
  PassbandFrequency   = 512;
end

properties (Access = private, Nontunable)
  % pPrototypeSOS Lowpass prototype SOS matrix
  pPrototypeSOS;
  % pPrototypePassbandFrequency Lowpass prototype passband frequency
  pPrototypePassbandFrequency;
  % pSectionLen Section length ( 3 for lowpass/highpass, 5 for
  % bandpass/bandstop)
  pSectionLen;
  % pNumSections Number of sections
  pNumSections;
end

properties (Access = private)
  % pTransformedNum Numerator coefficients of transformed filter
  pTransformedNum;
  % pTransformedDen Denominator coefficients of transformed filter
  pTransformedDen;
end
%--------------------------------------------------------------------------
% Public methods
%--------------------------------------------------------------------------
methods
  function obj = VariableBandwidthIIRFilter(varargin)
    % Constructor
    obj@dsp.internal.VariableBandwidthFilterBase(varargin{:});  
    if obj.NormalizedFrequency                
        isPassbandFrequencySpecified = false;
        isCenterFrequencySpecified = false;
        isBandwidthSpecified = false;
        for i = 1:2:numel(varargin)
            if strcmp(varargin{i}, 'PassbandFrequency')
                isPassbandFrequencySpecified = true;
            elseif strcmp(varargin{i}, 'CenterFrequency')
                isCenterFrequencySpecified = true;
            elseif strcmp(varargin{i}, 'Bandwidth')
                isBandwidthSpecified = true;
            end
        end
        if ~isPassbandFrequencySpecified
            obj.PassbandFrequency = 512/(44100/2);
        end
        if ~isCenterFrequencySpecified
            obj.CenterFrequency = 11025/(44100/2);
        end
        if ~isBandwidthSpecified
            obj.Bandwidth = 7680/(44100/2);
        end
    end
  end
  %------------------------------------------------------------------------   
  function set.PassbandFrequency(obj,value)
    obj.checkVal(value,'PassbandFrequency');
    obj.PassbandFrequency = value;
  end
  %------------------------------------------------------------------------          
  function set.FilterOrder(obj,value)
    validateattributes(value,{'double','single'}, {'real','scalar','positive',...
    'integer'},'','FilterOrder');
    obj.FilterOrder = value;
  end
  %------------------------------------------------------------------------
  function set.PassbandRipple(obj,value)
    validateattributes(value,{'double','single'}, {'real','scalar','positive','finite'},...
    '','PassbandRipple');
    obj.PassbandRipple = value;
  end
  %------------------------------------------------------------------------
  function set.StopbandAttenuation(obj,value)
    validateattributes(value,{'double','single'}, {'real','scalar','positive','finite'},...
                              '','StopbandAttenuation');
    obj.StopbandAttenuation = value;
  end
end
%--------------------------------------------------------------------------
% Protected methods
%--------------------------------------------------------------------------
methods (Access = protected)  
  function setupImpl(obj, x) 
    % Invoke setupImpl method of base class
    setupImpl@dsp.internal.VariableBandwidthFilterBase(obj,x);
     % extrinsic functions for lowpass prototype design
     coder.extrinsic('dsp.VariableBandwidthIIRFilter.designCustomOrderPrototype');
        
    if strcmp(obj.FilterType,'Bandpass') ||  strcmp(obj.FilterType,'Bandstop')
       % the spectral transformation doubles the filter order for the
       % bandpass and bandstop cases. Therefore, the target filter order
       % must be even in that case
       coder.internal.errorIf( all(mod(obj.FilterOrder,2)), ...
          'dsp:system:VariableBandwidthFilter:IIRBandpassBandstopOrder');
       pFilterOrder =  obj.FilterOrder / 2;
    else
       pFilterOrder =  obj.FilterOrder;
    end
     
    % Set the arbitrary lowpass prototype passband frequency
    obj.pPrototypePassbandFrequency = cast(.5,obj.pDatatype);
    % Design the lowpass prototype
    obj.pPrototypeSOS = coder.const(@obj.designCustomOrderPrototype,...
                                                          pFilterOrder,...
                                                          obj.pPrototypePassbandFrequency,...
                                                          obj.PassbandRipple,...
                                                          obj.StopbandAttenuation,...
                                                          obj.pDatatype);
    % Setup the transformed filter 
    % For lowpass and highpass filters, the transformed filter consists of
    % second-order sections. 
    % For bandpass and bandstop filters, the transformed filter consists of
    % fourth-order sections. 
    obj.pNumSections = size(obj.pPrototypeSOS,1);
    if strcmp(obj.FilterType,'Highpass') ||  strcmp(obj.FilterType,'Lowpass')
        obj.pSectionLen = 3; % SOS
    else
        obj.pSectionLen = 5; % Fourth-order section
    end 
    obj.pTransformedNum = zeros(obj.pNumSections, obj.pSectionLen, 'like', obj.pPrototypeSOS);
    obj.pTransformedDen = zeros(obj.pNumSections, obj.pSectionLen, 'like', obj.pPrototypeSOS);
    % Numerator and denominator properties are set to zero matrices
    % with the correct dimensions. The actual values are computed in the
    % call to tuneCoefficients
    if strcmp(obj.FilterType,'Highpass') ||  strcmp(obj.FilterType,'Lowpass')
        obj.pfilter = dsp.internal.SecondOrderSectionFilter('Numerator',obj.pTransformedNum,...
                                                           'Denominator',obj.pTransformedDen);
    else
        obj.pfilter = dsp.FourthOrderSectionFilter('Numerator',obj.pTransformedNum,...
                                                           'Denominator', obj.pTransformedDen);
        setNumChans(obj.pfilter,getNumChannels(obj,x));
    end 
    % Compute coefficients based on passband frequency
    tuneCoefficients(obj);
  end
  %------------------------------------------------------------------------
  function processTunedPropertiesImpl(obj)
      % Tune the filter coefficients
      processTunedPropertiesImpl@dsp.internal.VariableBandwidthFilterBase(obj);
  end
  %------------------------------------------------------------------------
  function crossValidateProperties(obj)
    crossValidateProperties@dsp.internal.VariableBandwidthFilterBase(obj);
  end
  %--------------------------------------------------------------------------
  function tuneCoefficients(obj)
      wo = cast(obj.pPrototypePassbandFrequency,obj.pDatatype);
      
      Fs = cast(getSampleRate(obj),obj.pDatatype);
      % Calculate the mapping allpass filter coefficients
      switch obj.FilterType
          case {'Lowpass','Highpass'}
              F = cast(obj.PassbandFrequency,obj.pDatatype);
              if (F > 0)
                  wt = F * 2 / Fs;
                  if wt > 0
                      if strcmp(obj.FilterType,'Lowpass')
                          [allpassnum, allpassden] = allpasslp2lp(wo, wt);
                      else % highpass
                          [allpassnum, allpassden] = allpasslp2hp(wo, wt);
                      end
                      transformSOSSection(obj,allpassnum,allpassden);
                  end
              end
          case {'Bandpass','Bandstop'}
              Fc = cast(obj.CenterFrequency,obj.pDatatype);
              BW = cast(obj.Bandwidth,obj.pDatatype);
              if (Fc > 0 && BW > 0)
                  wt1 = Fc * 2 / Fs - BW/Fs;
                  wt2 = Fc * 2 / Fs + BW/Fs;
                  if wt1 > 0 || wt2 > 0
                      if strcmp(obj.FilterType,'Bandpass')
                          [allpassnum, allpassden] = allpasslp2bp(wo, [wt1 wt2]);
                      else % bandstop
                          [allpassnum, allpassden] = allpasslp2bs(wo, [wt1 wt2]);
                      end
                      transformSOSSection(obj,allpassnum,allpassden);
                  end
              end
      end
  end
  %--------------------------------------------------------------------------
  function transformSOSSection(obj, allpassnum, allpassden)
      % Transform each SOS section
      for i=1:obj.pNumSections
          % polyallpasssub replaces each delay by the allpass filter
          [num,den] = obj.polyallpasssub(obj.pPrototypeSOS(i,1:3), obj.pPrototypeSOS(i,4:6), allpassnum, allpassden);
          % The leading coefficient of the denominator must equal to 1
          a0 = den(1);
          if a0 ~= 1
              den =    den / a0;
              num =    num / a0;
          end
          % polyallpasssub will sometimes return a length-2 vector instead of
          % a length-3 vector if the last element was zero
          num0 = zeros(1, obj.pSectionLen, obj.pDatatype);
          num0(1:length(num)) = num;
          obj.pTransformedNum(i,:) = num0;
          den0 = zeros(1, obj.pSectionLen, obj.pDatatype);
          den0(1:length(den)) = den;
          obj.pTransformedDen(i,:) = den0;
      end
      % Tune the IIR filter
      obj.pfilter.Numerator = obj.pTransformedNum;
      obj.pfilter.Denominator = obj.pTransformedDen;
  end

%--------------------------------------------------------------------------
  function validateFrequencyRange(obj)
    % PassbandFrequency must be less than SampleRate/2
    % This method is invoked in validatePropertiesImpl of the base class
    freqUnits = getFrequencyUnits(obj);
    coder.internal.errorIf(obj.PassbandFrequency >= getSampleRate(obj)/2,...
        'dsp:system:VariableBandwidthFilter:CharacteristicTooLarge',...
        'PassbandFrequency',...
        floor(getSampleRate(obj)),...
        round((getSampleRate(obj) - floor(getSampleRate(obj))) * 10),...
        freqUnits);
  end
%--------------------------------------------------------------------------
  function y = stepImpl(obj, x)
    % step the IIR filter
    y = step(obj.pfilter,x);
  end   
%--------------------------------------------------------------------------
  function s = saveObjectImpl(obj)
    s = saveObjectImpl@dsp.internal.VariableBandwidthFilterBase(obj);
    if isLocked(obj)
        s.pTransformedNum = obj.pTransformedNum;
        s.pTransformedDen = obj.pTransformedDen;
        s.pPrototypeSOS = obj.pPrototypeSOS;
        s.pSectionLen = obj.pSectionLen;
        s.pNumSections = obj.pNumSections;
        s.pPrototypePassbandFrequency = obj.pPrototypePassbandFrequency;
    end
  end
%--------------------------------------------------------------------------
  function loadObjectImpl(obj, s, wasLocked)
    if wasLocked 
        obj.pTransformedDen = s.pTransformedDen;
        if isfield(s,'pTransformedGain')
            if strcmp(s.FilterType,'Lowpass') || strcmp(s.FilterType,'Highpass')
                filterLen = 3;
            else
                filterLen = 5;
            end
            s.pTransformedNum =  s.pTransformedNum .* repmat(s.pTransformedGain(1:end-1),1,filterLen);
        end
        obj.pTransformedNum = s.pTransformedNum;
        if isfield(s,'pPrototypeGain')
             s.pPrototypeSOS(:,1:3) =  s.pPrototypeSOS(:,1:3) .* repmat(s.pPrototypeGain(1:end-1),1,3);
        end
        obj.pPrototypeSOS = s.pPrototypeSOS;
        obj.pSectionLen = s.pSectionLen;
        obj.pNumSections = s.pNumSections;
        obj.pPrototypePassbandFrequency = s.pPrototypePassbandFrequency;
    end
    loadObjectImpl@dsp.internal.VariableBandwidthFilterBase(obj,s,wasLocked);
  end
%--------------------------------------------------------------------------
  function flag = isInactivePropertyImpl(obj, prop)
    flag = false;
    switch prop
        case {'PassbandFrequency'}
            if ~strcmp(obj.FilterType,'Lowpass') && ...
                    ~strcmp(obj.FilterType,'Highpass')
                flag = true;
            end
        case {'SampleRateMode'}
            flag = true;
        otherwise
            flag = isInactivePropertyImpl@dsp.internal.VariableBandwidthFilterBase(obj,prop);
    end
  end
% %--------------------------------------------------------------------------
%   function flag = isInputSizeMutableImpl(~,~)
%     % Support mutable input size
%     flag = true;
%   end  
end
%--------------------------------------------------------------------------
% Static, hidden methods
%--------------------------------------------------------------------------
methods (Static, Hidden)
  function d = getdfiltobj(sysObjToAnalyze,arith)
    %  Equivalent DFILT object for filter analysis methods
    d = convertToDFILT(sysObjToAnalyze.pfilter, arith);
  end
  %------------------------------------------------------------------------  
  function sos = designCustomOrderPrototype(N,Fpass,Apass,Astop,datatype)
    % Design prototype lowpass filter using elliptic method
    Fs = 2; % sample rate is 2, normalized frequency [0,1]
    fdes = fdesign.lowpass('N,Fp,Ap,Ast',N,Fpass,Apass,Astop,Fs);
    fdo = fdopts.sosscaling;
    fdo.NumeratorConstraint='none';
    fdo.ScaleValueConstraint='unit';
    FilterObj = design( fdes,'ellip',SystemObject=true,...
                FilterStructure='df2tsos',SOSScaleNorm='Linf',...
                SOSScaleOpts=fdo);
    sos =  cast(FilterObj.SOSMatrix, datatype);
  end  
  %------------------------------------------------------------------------
  function checkVal(value,prop)
      validateattributes(value,{'double','single'},...
          {'real','scalar','positive','finite'},...
          '',prop);
  end
end
%--------------------------------------------------------------------------
% Static, Protected methods
%--------------------------------------------------------------------------   
methods(Static, Access=protected)
    %------------------------------------------------------------------------
  function [num,den] = polyallpasssub(b0,a0,allpassnum,allpassden)
    %POLYALLPASSSUB   Substitute delays in polynomials with allpass filters. 
    % Remove possible trailing zeros and get polynomial lengths
    b = b0(b0~=0); M = int8(length(b));
    a = a0(a0~=0); N = int8(length(a));
    % Compute temporary numerator
    tempnum = dsp.VariableBandwidthIIRFilter.newpoly(b,allpassnum,allpassden,M);       
    % Compute temporary denominator
    tempden = dsp.VariableBandwidthIIRFilter.newpoly(a,allpassnum,allpassden,N);       
    % Now include common denominators
    num = conv(tempnum,dsp.VariableBandwidthIIRFilter.polypow(allpassden,N-M));
    den = conv(tempden,dsp.VariableBandwidthIIRFilter.polypow(allpassden,M-N));       
    num = num/den(1);
    den = den/den(1);
  end
  %-----------------------------------------------------------------------
  function temppoly = newpoly(b,allpassnum,allpassden,M)
    % Compute new polynomial after substitution
    % For each coefficient, we will have a resulting polynomial after we
    % substitute, form each polynomial and then add them all up to compute
    % the new numerator or denominator.
    temp = zeros(M, (M-1)*length(allpassden)-M + 2, 'like', allpassden);
    for n = 1:M
        temp(n,:) = b(n).*conv(dsp.VariableBandwidthIIRFilter.polypow(allpassden,M-n),...
        dsp.VariableBandwidthIIRFilter.polypow(allpassnum,n-1));
    end
    temppoly = sum(temp);     
  end
  %------------------------------------------------------------------------
  function p = polypow(q,N)
    %POLYPOW   Evaluate polynomial to power of N. 
    % Initialize recursion
    p = zeros(1, N*length(q) - N + 1, 'like', q);
    p(1) = 1; 
    % Multiply polynomial by q, N times
    for n = 1:N
        p(1:n*length(q)-n+1) = conv(p(1:(n-1)*length(q)-(n-2)),q);
    end
  end
  %------------------------------------------------------------------------
  function mainS = getPropertyGroupsImpl
    % Modify order of display
     mainS =  matlab.system.display.Section(...
    'Title', getString(message('dsp:system:Shared:Parameters')), ...
    'PropertyList', {'FilterType','FilterOrder','PassbandFrequency',...
                     'CenterFrequency', 'Bandwidth','PassbandRipple',...
                     'StopbandAttenuation','NormalizedFrequency','SampleRate'});
  end
end
end
