classdef FourthOrderSectionFilter < handle & dsp.internal.FourthOrderSectionFilterAnalysis &...
        matlab.mixin.internal.indexing.Paren & matlab.mixin.SetGet
    %FOURTHORDERSECTIONFILTER Implement cascade of fourth-order section
    %filter.
    %
    %   FOS = dsp.FourthOrderSectionFilter returns a
    %   FourthOrderSectionFilter object, FOS, that implements filter formed
    %   of cascade of fourth order sections.
    %
    %   FOS = dsp.FourthOrderSectionFilter(Name=Value, ...) returns a
    %   FourthOrderSectionFilter object, FOS, with each specified property
    %   name set to the specified value. You can specify name-value pair
    %   arguments in any order as (Name1=Value1,...,NameN=ValueN).
    %
    %   FOS = dsp.FourthOrderSectionFilter(NUM,DEN) returns a
    %   FourthOrderSectionFilter object, FOS, with the Numerator property
    %   set to NUM and Denominator property set to DEN.
    %
    %   Step method syntax:
    %
    %   Y = step(FOS, X) filters the real or complex input signal X using
    %   the specified filter to produce the filtered output, Y. The filter
    %   processes each channel of the input signal (each column of X)
    %   independently over time.
    %
    %   dsp.FourthOrderSectionFilter object may be called directly like a
    %   function instead of using the step method. For example, y =
    %   step(obj, x) and y = obj(x) are equivalent.
    %
    %   FourthOrderSectionFilter methods:
    %
    %   step                          - See above description for use of
    %                                   this method
    %   release                       - Allow property value and input
    %                                   characteristics changes
    %   clone                         - Create FourthOrderSectionFilter
    %                                   object with same property values
    %   isLocked                      - Locked status (logical)
    %   reset                         - Reset the internal states to
    %                                   initial conditions
    %
    %   This object supports several filter analysis methods. For
    %   more information, type
    %   dsp.FourthOrderSectionFilter.helpFilterAnalysis.
    %
    %   FourthOrderSectionFilter properties:
    %
    %   Numerator   - Numerator coefficients of filter
    %   Denominator - Denominator coefficients of filter
    %
    %   % EXAMPLE 1: Design a fourth-order section (FOS) filter and filter a
    %   % sinusoid input signal
    %   frameSize = 1024;
    %   fs = 1000;
    %   SINE1 = dsp.SineWave(5,100,SamplesPerFrame=1024,SampleRate=fs);
    %   SINE2 = dsp.SineWave(2,350,pi/2,SamplesPerFrame=1024,...
    %       SampleRate=fs);
    %
    %   % Create an input signal which is the sum of sinusoids
    %   x = SINE1() + SINE2();
    %
    %   % FOS Numerator and Denominator coefficients are obtained using
    %   % designParamEq which is part of Audio Toolbox:
    %   %N = [2,4];
    %   %gain = [5,10];
    %   %centerFreq = [0.025,0.75];
    %   %bandwidth = [0.025,0.35];
    %   %mode = 'fos';
    %   %[num,den] = designParamEQ(N,gain,centerFreq,bandwidth,mode);
    %
    %   num = [1.0223   -1.9368    0.9205         0         0
    %          1.5171    2.3980    1.4317    0.6416    0.2752];
    %
    %   den = [-1.9368    0.9428         0         0
    %           2.0136    1.9224    1.0260    0.3016];
    %
    %   % Construct FOS IIR filter
    %   fos = dsp.FourthOrderSectionFilter(Numerator=num,...
    %   Denominator=den);
    %
    %   % Construct a spectrum analyzer to visualize the original
    %   % sinusoid signal and the filtered signal
    %   scope = spectrumAnalyzer(...
    %     SampleRate=fs,...
    %     PlotAsTwoSidedSpectrum=false,...
    %     Title="Original and Filtered Signals",...
    %     ShowLegend=true,...
    %     ChannelNames=["Original Signal","Filtered Signal"]);
    %
    %   % Filter the input signal, and visualize the original spectrum and
    %   % filtered spectrum.
    %   for idx = 1:10
    %       y = fos(x);
    %       scope([x,y]);
    %   end
    %
    %   % Release the system object
    %   release(scope);
    %
    %   % EXAMPLE 2: Design a lowpass fourth-order section (FOS) filter
    %   % using fdesign and filter a sinusoid input signal
    %
    %   % Filter design parameters
    %   N = 6; Fp = 0.5; Ap = 1; Ast = 60;
    %
    %   % Input Parameters
    %   Fs = 44100;
    %   FrameLength = 1024;
    %
    %   % Design a lowpass filter using fdesign
    %   fdo = fdopts.sosscaling;
    %   fdo.NumeratorConstraint='none';
    %   fdo.ScaleValueConstraint='unit';
    %
    %   f = fdesign.lowpass("N,Fp,Ap,Ast",N,Fp,Ap,Ast,2);
    %   hFilter = design(f,"ellip",SystemObject=true,...
    %     FilterStructure="df2tsos",SOSScaleNorm="Linf",...
    %      SOSScaleOpts=fdo);
    %   sosV =  hFilter.SOSMatrix;
    %
    %   % Extract the Numerator and Denominator from SOS Matrix
    %   num = zeros(size(sosV,1),5);
    %   den = zeros(size(sosV,1),5);
    %
    %   for i = 1:size(sosV,1)
    %      [num0,den0] = iirlp2bp(sosV(i,1:3),sosV(i,4:6),Fp,[0.25,0.75]);
    %      num(i,1:length(num0)) = num0;
    %      den(i,1:length(num0)) = den0;
    %   end
    %
    %   % Create a fourth-order section filter
    %   fos = dsp.FourthOrderSectionFilter(num,den);
    %
    %   TFE = dsp.TransferFunctionEstimator(FrequencyRange="onesided");
    %   PLOTTER = dsp.ArrayPlot(PlotType="Line",...
    %       XOffset=0,...
    %       YLimits=[-120 5], ...
    %       SampleIncrement=Fs/FrameLength,...
    %       YLabel="Frequency Response (dB)",...
    %       XLabel="Frequency (Hz)",...
    %       Title="System Transfer Function");
    %
    %   SINE = dsp.SineWave(SamplesPerFrame=FrameLength);
    %   for index=1:500
    %       % Generate input
    %       x = SINE() + randn(FrameLength,1);
    %       % Pass input through the filter
    %       y = fos(x);
    %       % Transfer function estimation
    %       H = TFE(x,y);
    %       % plot transfer function
    %       PLOTTER(20*log10(abs(H)))
    %   end
    %
    %   % Release the system object
    %   release(TFE);
    %   release(PLOTTER);
    %   release(SINE);
    %
    %   See also dsp.BiquadFilter
    
    % Copyright 2018-2021 The MathWorks, Inc.
    
    %#codegen
    
    properties
        %Numerator Numerator coefficients of filter
        % Specify the numerator coefficients of size Lx5, where L is the
        % number of sections. The size of this property cannot be modified
        % once STEP method is called. However, the values can be modified.
        % The default value is [1 0.1 0.2 0.3 0.4].
        Numerator = [1 .1 .2 .3 .4];
        %Denominator Denominator coefficients of filter
        % Specify the denominator coefficients of size Lx4, or Lx5, where L
        % is the number of sections. The leading denominator coefficients
        % are assumed to be 1 always - if denominator is of size Lx4,
        % one(s) are appended to make the size Lx5. If the denominator is
        % of size Lx5, the first column values are ignored and appended
        % with one(s). The size of this property cannot be modified once
        % STEP method is called. However, the values can be modified. The
        % default value is [1 0.1 0.2 0.3 0.4].
        Denominator = [1 .1 .2 .3 .4];
    end
    
    properties (Access = private)
        % pStates Filter states. 4 states per section.
        pStates
        
        %pIsInitialized Flag to check if the inputs are initialized and
        % validated
        pIsInitialized = false;
        
        %pType Store the data type and complexity of the input
        pType = 0;
        
        %pNum Store the value of the numerator casted to the data type and
        % complexity of the input
        pNum
        
        %pDen Store the value of the denominator casted to the data type and
        % complexity of the input
        pDen
        
        %pNumChans Store the number of input channels
        pNumChans
        
    end
    
    %----------------------------------------------------------------------
    % Public methods
    %----------------------------------------------------------------------
    
    methods
        function obj = FourthOrderSectionFilter(varargin)
            % Accept as Name-Value or Value only arguments
            matlabshared.fusionutils.internal.setProperties(obj,length(varargin), ...
                varargin{:},'Numerator','Denominator');
        end
        %------------------------------------------------------------------
        function set.Numerator(obj,val)
            % Size of Numerator cannot be changed after constructing but
            % values can be changed
            nSections = size(obj.Numerator,1);
            expr = obj.pIsInitialized && (nSections ~= size(val,1));%#ok<*MCSUP>
            coder.internal.errorIf(expr,...
                'dsp:system:FourthOrderSectionFilter:incorrectNumSections',nSections,size(val,1));
            
            validateattributes(val,{'numeric'},{'2d','finite','nonnan',...
                'ncols',5},'FourthOrderSectionFilter','Numerator');
            
            obj.Numerator = val;
            set(obj,'pNum',val);
        end
        %------------------------------------------------------------------
        function set.Denominator(obj,val)
            % Size of Denominator cannot be changed after constructing but
            % values can be changed
            nSections = size(obj.Denominator,1);
            expr = obj.pIsInitialized && (nSections ~= size(val,1));
            coder.internal.errorIf(expr,...
                'dsp:system:FourthOrderSectionFilter:incorrectNumSections',nSections,size(val,1));
            
            validateattributes(val,{'numeric'},{'2d','finite','nonnan',...
                },'FourthOrderSectionFilter','Denominator');
            
            % The Denominator property can be of size Lx4 or Lx5. Depending
            % on the size, append one(s) accordingly
            if size(val,2) == 4
                newval = [ones(size(val,1),1) val(:,1:4)];
            elseif size(val,2) == 5
                newval = [ones(size(val,1),1) val(:,2:5)];
            else
                % Denominator should be at least of size Lx4.
                coder.internal.error('dsp:system:FourthOrderSectionFilter:incorrectNumCols',size(val,2));
            end
            obj.Denominator = newval;
            set(obj,'pDen',newval);
        end
        %------------------------------------------------------------------
        function set.pNum(obj,val)
            obj.pNum = cast(val.','like',obj.pType);
        end
        %------------------------------------------------------------------
        function set.pDen(obj,val)
            obj.pDen = cast(val(:,2:end).','like',obj.pType);
        end
        %------------------------------------------------------------------
    end
    
    methods (Hidden, Access = public)
        function y = step(obj,x)
            
            narginchk(2,2);
            
            if  ~obj.pIsInitialized
                % Setup the properties
                setup(obj,x);
            end
            
            % Error if number of input channels changes after setup()
            nNumChans = size(obj.pStates,2);
            coder.internal.errorIf((size(x,2)~= nNumChans),...
                'dsp:system:FourthOrderSectionFilter:incorrectNumChannel');
            
            if (isreal(obj.pType))
                % Error if input complexity changes from real to complex after
                % setup()
                coder.internal.errorIf(~(isreal(x)),...
                    'dsp:system:FourthOrderSectionFilter:incorrectComplexity');
            end
            
            % Pre-allocate variables for performance
            pnum = obj.pNum;
            pden = obj.pDen;
            pstate = obj.pStates;
            
            % pType is used to cast num, den, state. To ensure, all the
            % variables are of same type, use pType to cast input
            in = cast(x,'like',obj.pType);
            
            % Call MEX
            if ~isreal(pnum) || ~isreal(pden)
                % Make both num and den complex
                pnum = complex(pnum);
                pden = complex(pden);
                % Force input to be complex so that output is complex
                in = complex(in);
            end
            if ~isreal(in)
                % Force input states to be complex so that output states are complex
                pstate = complex(pstate);
            end
            [y,pstate] = dsp.internal.builtins.fourthOrderMultiSectionFilt(pnum,pden,in,pstate);
            
            obj.pStates = pstate;
            
        end
        
        function reset(obj)
            % If reset is called before setup, state will be empty. So,
            % have a bypass where if the state is unset, don't reset for
            % state
            
            if obj.pIsInitialized
                % State is 4xMxL where M is the number of channels, and of
                % the same type as Input
                
                state = obj.pStates;
                numChan = size(state,2);
                numSect = size(state,3);
                obj.pStates = zeros(4,numChan,numSect,'like',state);
            end
        end
        
        function tf= isLocked(obj)
            %Locked Status for input attributes and non-tunable properties
            tf = obj.pIsInitialized;
        end
        
        function s = clone(obj)
            %Save the object properties
            t = saveobj(obj);
            
            % Load the object properties
            s = obj.loadobj(t);
        end
        
        function release(obj)
            %  Allow property value and input characteristics to change
            obj.pIsInitialized = false;
        end
        
        function y = info(obj,varargin)
            y = infoFA(obj,varargin{:});
        end
        
        function setup(obj,x)
            % Get the number of channels, number of sections, pType and
            % pLockedArithmetic
            nNumChans = size(x,2);
            nSections = size(obj.Numerator,1);
            if isempty(x)
                obj.pType = x; % In case it is an empty matrix                
            else
                if isreal(x)
                    % Only save a single element
                    obj.pType = x(1);
                else
                    obj.pType = complex(x(1));
                end
            end
            obj.pLockedArithmetic = class(x);
            
            setNumChans(obj,size(x,2));
            
            % Validate if Denominator has the same number of rows as
            % Numerator.
            validateattributes(obj.Denominator,{'numeric'},{'nrows',nSections...
                },'FourthOrderSectionFilter','Denominator');
            
            % Input x is a column vector
            validateattributes(x,{'single', 'double'},{'2d','finite','nonnan'},'step','Input');
            
            % Set the filter states
            obj.pStates = zeros(4,nNumChans,nSections,'like',x);
            
            % Set the Validated flag
            obj.pIsInitialized = true;
            
            % Cast the Num and Den to the input type and complexity
            obj.pNum = cast(obj.Numerator,'like',obj.pType);
            obj.pDen = cast(obj.Denominator,'like',obj.pType);
        end
        
        function o = getNumInputs(~)
            o = 1;
        end
        
        function o = getNumOutputs(~)
            o = 1;
        end
        
        function p = getValueOnlyProps(~)
           p = {'Numerator', 'Denominator'}; 
        end
        
        function o = nargin(~)
            o = 1;
        end
        
        function setNumChans(obj,val)
            obj.pNumChans = val;
        end
        
        function s = saveobj(obj)
            % Create an instance of the class
            s = dsp.FourthOrderSectionFilter;
            
            % Copy the states:
            s.Numerator = obj.Numerator;
            s.Denominator = obj.Denominator;
            s.pStates = obj.pStates;
            s.pType = obj.pType;
%             s.pNum = obj.pNum;
%             s.pDen = obj.pDen;
            s.pIsInitialized = obj.pIsInitialized;
            
            s = saveFA(obj, s);   % Save filter analysis class properties
        end
        
    end
    methods(Static)
        function obj = loadobj(s)            
            % Create an instance of the class
            obj = dsp.FourthOrderSectionFilter;
            
            % Assume the object is not locked. 
            wasLocked = 0;
            
            if isstruct(s)
                % Copy the states:
                obj.Numerator = s.Numerator;
                obj.Denominator = s.Denominator;
                obj.pStates = s.pStates;
                
                % These properties were added in R2019a, and were not
                % present in old dsp.internal.FourthOrderSectionFilter
                % object
                if (isfield(s,'pType'))
                    obj.pType = s.pType;
                end

                if (isfield(s,'pIsInitialized'))
                    obj.pIsInitialized = s.pIsInitialized;
                    wasLocked = s.pIsInitialized;
                end
                
                if(isfield(s,'pNumChans'))
                    obj.pNumChans = s.pNumChans;
                end
            else
                obj = s;
                obj.Numerator = s.Numerator; % Make sure to set this so pNum is correct
                obj.Denominator = s.Denominator; % Make sure to set this so pDen is correct
                if (isprop(s,'pIsInitialized'))
                    wasLocked = s.pIsInitialized;
                end
                
            end
            loadFA(obj, s, wasLocked); % Load filter analysis class properties
        end
    end
    %----------------------------------------------------------------------
    % Hidden, Sealed methods
    %----------------------------------------------------------------------
    methods  (Hidden=true,Sealed=true)
        function y = parenReference(obj,x)
            % This is used to enable stepping the object with function
            % notation.
            y = step(obj,x);
        end     
    end
    %----------------------------------------------------------------------
    % Redirect codegen to the dsp.internal.FourthOrderSectionFiltercg
    methods (Access = public, Hidden, Static)
        function name = matlabCodegenRedirect(~)
            name = 'dsp.internal.FourthOrderSectionFiltercg';
        end
    end
end