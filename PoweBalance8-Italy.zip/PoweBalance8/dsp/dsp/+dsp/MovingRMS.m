classdef (StrictDefaults)MovingRMS < dsp.internal.AbstractMovingStatistic
%   MovingRMS Compute moving RMS
%   MRMS = dsp.MovingRMS returns a System object, MRMS, that computes the
%   moving RMS of the input signal.
%
%   MRMS = dsp.MovingRMS(Name=Value, ...) returns a moving RMS System
%   object, MRMS, with each specified property name set to the specified
%   value. You can specify additional name-value pair arguments in any
%   order as (Name1=Value1,...,NameN=ValueN).
%
%   MRMS = dsp.MovingRMS(Length, Overlap, PropertyName=PropertyValue, ...)
%   returns a moving RMS object, MRMS, with the WindowLength property set
%   to Length, OverlapLength property set to Overlap, and other properties
%   set to the specified values.
%
%   Step method syntax:
%
%   Y = step(MRMS, X) computes the moving RMS, Y, of the real or complex
%   input X. Each column of X is a channel. The System object computes the
%   moving RMS of each channel of the input signal independently over time.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   MovingRMS methods:
%
%   step                     - Compute moving RMS of the input
%   release                  - Allow property value and input
%                              characteristics changes, and release moving
%                              average resources
%   clone                    - Create moving RMS object with same
%                              property values
%   isLocked                 - Display locked status (logical)
%   reset                    - Reset the states of the moving RMS
%
%   MovingRMS properties:
%
%   Method                  - Moving RMS method
%   SpecifyWindowLength     - Choose to specify sliding window length
%   OverlapLength           - Overlap length between windows
%   WindowLength            - Sliding window length
%   ForgettingFactor        - Exponential weighting forgetting factor
%
%  % EXAMPLE: Compute the moving RMS of a noisy sine wave signal with
%  %          varying amplitude. Use a sliding window RMS of length 50,
%  %          an exponentially weighted RMS with forgetting factor of
%  %          0.995, and a sliding window RMS of length 50 with an overlap
%  %          of 40 samples.
    %  FrameLength = 10;
    %  Fs = 100;
    %  mrms_slide    = dsp.MovingRMS(50);
    %  mrms_forget   = dsp.MovingRMS('Method','Exponential weighting',...
    %                                'ForgettingFactor',0.995);
    %  mrms_overlap  = dsp.MovingRMS(50,40);
    %  sin    = dsp.SineWave(SampleRate=Fs,...
    %                        SamplesPerFrame=FrameLength,...
    %                        Frequency=1);
    %  scope  = timescope(SampleRate=[Fs,Fs,Fs,Fs/(50-40)],...
    %                     TimeSpanSource='property',...
    %                     TimeSpan=100,...
    %                     YLimits=[-4.5 4.5]);
    %  title = 'Moving RMS';
    %  scope.Title = title;
    %  scope.ChannelNames = {'Original Signal',...
    %      'Sliding window of 50 samples with default overlap',...
    %      'Exponential weighting with forgetting factor of 0.995',...
    %      'Sliding window of 50 samples with overlap of 40 samples'};
    %  count = 1;
    %  AVect = [1/8 1/4 1/2 1 2 3 4];
    %  index = 1;
    %  for index = 1:length(AVect)
    %    A = AVect(index);
    %    for frameIdx = 1:150
    %      x = A * sin() + 0.1 * randn(FrameLength,1);
    %      y1 = mrms_slide(x);
    %      y2 = mrms_forget(x);
    %      y3 = mrms_overlap(x);
    %      scope(x,y1,y2,y3);
    %    end
    %  end
    %
    %   See also dsp.MovingAverage, dsp.MovingVariance,
    %   dsp.MovingStandardDeviation, dsp.MovingMinimum, dsp.MovingMaximum

%   Copyright 2016-2023 The MathWorks, Inc.

%#codegen
%#ok<*EMCLS>

    properties (Nontunable)
        % Method Averaging method
        % Specify the averaging method as 'Sliding window' or 'Exponential
        % weighting'. In the sliding window method, the object computes the
        % moving average by sliding a window along the input. When
        % 'SpecifyWindowLength' is true, the sliding window length is equal
        % to the value of the 'WindowLength' property. When
        % 'SpecifyWindowLength' is false, the sliding window is of infinite
        % length. In this mode, the statistic is computed for the current
        % sample and all past samples).
        % In the exponential weighting method, the object computes
        % the RMS over samples weighted by an exponentially decaying
        % forgetting factor. The RMS of the Nth output samples is equal to
        % RMSN = sqrt((1/wN) * sum(lambda.^(N-1:-1:0) .*
        % [x1 x2 x3 ... xN].^2)), where lambda is the forgetting factor,
        % wN = sum(lambda.^(N-1:-1:0)), and [[x1 x2 x3 ... xN] is the
        % vector holding the current input sample xN and the N-1 previous
        % samples.
        % The default is 'Sliding window'.
        Method (1, :) char {matlab.system.mustBeMemberMessageID(Method, ...
                    {'dsp:system:MovingStatistic:Method_SlidingWindow',;...
                     'dsp:system:MovingStatistic:Method_ExponentialWeighting'})} = 'Sliding window';
    end

    methods
        function obj = MovingRMS(varargin)
            obj@dsp.internal.AbstractMovingStatistic(varargin{:});
        end
    end

    methods(Access = protected)

        function statObj = getStatisticObject(obj,u)
            if strcmp(obj.Method,'Sliding window')
                if obj.SpecifyWindowLength
                    avrgObj =  dsp.MovingAverage('Method','Sliding window','WindowLength',obj.WindowLength,'OverlapLength',obj.OverlapLength);
                else
                    avrgObj =  dsp.MovingAverage('Method','Sliding window','SpecifyWindowLength',false);
                end
            else
                avrgObj = dsp.MovingAverage('Method','Exponential weighting','ForgettingFactor',obj.ForgettingFactor);
            end
            statObj = getStatisticObject(avrgObj,u);
        end

        function y = stepImpl(obj,u)
            y = sqrt(step(obj.pStatistic,abs(u).^2));
        end

         %% Block Icon
        function icon = getIconImpl(~)
           icon = getString(message('dsp:StatisticsBlockDialog:MovingRMSIcon'));
        end

        %% Support mutable input size
        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end
    end

    %% Block header - widget grouping
    methods(Static, Access=protected)
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.MovingRMS', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:StatisticsBlockDialog:MovingRMSTitle',...
                'Text',  'dsp:StatisticsBlockDialog:MovingRMSHeader');
        end
    end
end
