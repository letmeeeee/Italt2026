classdef (StrictDefaults)SampleRateConverter < dsp.internal.SupportArbitraryInputLength & dsp.internal.FilterAnalysis 
%SampleRateConverter Multistage sample rate converter.
%   SRC = dsp.SampleRateConverter returns a multistage FIR sample
%   rate converter which converts the rate of each channel of the input
%   signal from the input sampling rate to the output sampling rate
%   specified.
%
%   SRC = dsp.SampleRateConverter('Name', Value, ...) returns a
%   multistage SRC with each specified property name set to the
%   specified value. You can specify additional name-value pair
%   arguments in any order as (Name1,Value1,...,NameN,ValueN).
%
%   Step method syntax:
%
%   Y = step(SRC, X) designs one or more multirate FIR filters and then
%   uses the filters to convert the rate of each channel (column) of
%   the real or complex input signal X to the output sampling rate
%   specified in SRC.
%
%   System objects may be called directly like a function instead of
%   using the step method. For example, step(obj, x) and obj(x) are
%   equivalent.
%
%   SampleRateConverter methods:
%
%   step                  - See above description for use of this
%                           method
%   release               - Allow property value and input 
%                           characteristics changes
%   clone                 - Create SampleRateConverter object with same
%                           property values
%   isLocked              - Locked status (logical)
%   reset                 - Reset the internal states to initial
%                           conditions
%   getFilters            - Return filters used for rate conversion
%   getRateChangeFactors  - Get overall interpolation/decimation rates
%   getActualOutputRate   - Get adjusted output sample rate
%   cost                  - Compute implementation cost
%   visualizeFilterStages - Visualize filter stages
%   freqz                 - Frequency response
%   outputDelay           - Return the overall delay of the sample rate
%                           converter
%
%   SampleRateConverter properties:
%
%   Bandwidth           - Two-sided bandwidth of interest
%   InputSampleRate     - Input signal sampling rate
%   OutputSampleRate    - Output signal sampling rate
%   OutputRateTolerance - Allowable tolerance for output signal rate 
%   StopbandAttenuation - Minimum dB attenuation for aliased components 
%
%   % EXAMPLE 1: Convert an audio signal from 44.1 kHz to 96 kHz
%   SRC = dsp.SampleRateConverter('Bandwidth',40e3,...
%       'InputSampleRate',44.1e3,'OutputSampleRate',96e3);
%   [L,M] = getRateChangeFactors(SRC);
%   FrameSize = 10*M;
%   AR = dsp.AudioFileReader('guitar10min.ogg','SamplesPerFrame',...
%       FrameSize);
%   AW = dsp.AudioFileWriter('guitar10min_96k.wav','SampleRate',96e3);
%   tic;
%   while toc < 15
%       % Run for 15 seconds
%       x = AR();
%       y = SRC(x);
%       AW(y);
%   end
%   release(AR); release(AW); release(SRC)
%
%   % EXAMPLE 2: Compare cost of using 0% tolerance to that of using
%   % 1% tolerance when converting a signal from 98.304 MHZ (A/D)
%   % output to 22 MHz (802.11 channel bandwidth)
%   SRC1 = dsp.SampleRateConverter('Bandwidth',20e6,...
%        'InputSampleRate',98.304e6,'OutputSampleRate',22e6,...
%        'OutputRateTolerance',0); % 0% tolerance
%   
%   SRC2 = dsp.SampleRateConverter('Bandwidth',20e6,...
%        'InputSampleRate',98.304e6,'OutputSampleRate',22e6,...
%        'OutputRateTolerance',0.01); % 1% tolerance
%   
%   c1 = cost(SRC1) % No tolerance: 84779 coefficients
%   c2 = cost(SRC2) % 1% tolerance:   150 coefficients
%   [L1,M1] = getRateChangeFactors(SRC1); % L1 = 1375; M1 = 6144
%   [L2,M2] = getRateChangeFactors(SRC2); % L2 =    2; M2 =    9
%   getActualOutputRate(SRC2) % 21.84533333e+06
%
%   See also dsp.FarrowRateConverter, dsp.FIRRateConverter, 
%   dsp.FIRDecimator, dsp.FIRInterpolator, designMultistageDecimator,
%   designMultistageInterpolator, designMultirateFIR

% Copyright 2014-2023 The MathWorks, Inc.

%#codegen

properties (Nontunable)
    %InputSampleRate Sample rate of input signal (Hz)
    %   Specify the sampling rate of the input signal in Hertz, as a
    %   finite numeric scalar. The default value of this property is
    %   192 kHz.
    InputSampleRate = 192e3;
    %OutputSampleRate Sample rate of output signal (Hz)
    %   Specify the sampling rate desired for the output signal in
    %   Hertz, as a finite numeric scalar. The default value of this
    %   property is 44.1 kHz.
    OutputSampleRate = 44.1e3
    %OutputRateTolerance Tolerance for output sample rate
    %   Specify the tolerance for the rate desired for the output
    %   signal as a finite numeric scalar percentage. The output rate
    %   tolerance allows for a simpler design in many cases. However,
    %   the actual output sample rate will vary for the output sample
    %   rate specified within the given tolerance percentage. For
    %   example, if OutputRateTolerance is specified as 0.01, the
    %   actual output sample rate will be in the range given by
    %   OutputSampleRate +/- 1%. The default tolerance is 0.
    OutputRateTolerance = 0;
    %Bandwidth Two-sided bandwidth of interest (Hz)
    %   Specify the two-sided bandwidth of interest for the signal
    %   after rate conversion on Hertz, as a finite numeric scalar. The
    %   default bandwidth is 40 kHz.
    Bandwidth =  40e3;
    %StopbandAttenuation Stopband attenuation (dB)
    %   Specify the minimum amount of attenuation in dB, as a finite
    %   numeric scalar. The stopband attenuation specifies the minimum
    %   amount of aliasing/imaging that will occur. The default
    %   stopband attenuation is 80 dB.
    StopbandAttenuation = 80;
end

properties (Access=private)
    NumChannels = int32(-1)
end

properties (Nontunable, Access=private)              
    Nstages = 0;
    filt1
    filt2
    filt3
    filt4
    filt5
    filt6
    filt7
    filt8
    filt9
    filt10
    filt11
    filt12
    filt13
    filt14
    filt15
    AreFiltersDesigned = false;
    AdjustedOutputRate = 44.1e3;
end
properties(Constant, Access = private)
    FilterNumber = {'1';'2';'3';'4';'5';'6';'7';'8';'9';'10';'11';'12';'13';'14';'15'};
    MaxFilters = 15;
end  

properties (Access = protected)
    % Handle to freqz plot
    freqzHandle = -1;
end
    
methods
    function obj = SampleRateConverter(varargin)
        %Constructor
        
        % Support name-value pair arguments
        setProperties(obj,nargin,varargin{:});
        obj.NumChannels = int32(-1);
    end
    
    function set.InputSampleRate(obj,Fs)
        validateattributes(Fs,{'numeric'},{'finite','scalar','real',...
            '>',0},'','InputSampleRate');
        obj.InputSampleRate = double(Fs);
        needToDesignFilters(obj);
    end

    function set.OutputSampleRate(obj,Fs)
        validateattributes(Fs,{'numeric'},{'finite','scalar','real',...
            '>',0},'','OutputSampleRate');
        obj.OutputSampleRate = double(Fs);
        needToDesignFilters(obj);
    end

    function set.OutputRateTolerance(obj,tol)
         validateattributes(tol,{'numeric'},{'finite','scalar','real',...
            '>=',0,'<=',.5},'','OutputRateTolerance');
        obj.OutputRateTolerance = double(tol);
        needToDesignFilters(obj);
    end

    function set.Bandwidth(obj,bw)
        validateattributes(bw,{'numeric'},{'finite','scalar','real',...
            '>',0},'','Bandwidth');
        obj.Bandwidth = bw;
        needToDesignFilters(obj);
    end

    function set.StopbandAttenuation(obj,Astop)
        validateattributes(Astop,{'numeric'},{'finite','scalar','real',...
            '>',0,'<=',180},'','StopbandAttenuation');        
        obj.StopbandAttenuation = Astop;
        needToDesignFilters(obj);
    end

    function FsOut = get.AdjustedOutputRate(obj)
        [~,~,FsOut] = dsp.SampleRateConverter.myrat(obj.InputSampleRate,...
            obj.OutputSampleRate,obj.OutputRateTolerance);
    end      

    function [varargout] = outputDelay(obj,varargin)
        % Calculate the overall delay of the sample rate converter.
        % See also outputDelay

        p = inputParser;
        p.KeepUnmatched=true; % Pass through unused parameters
        addParameter(p,'FsIn', obj.inputSampleRate());
        
        parse(p, varargin{:});
        FsIn = p.Results.FsIn;
        
        % If user-specified frequency
        defaultFsIn = any(strcmpi(p.UsingDefaults,'FsIn'));

        if defaultFsIn
            varargin{end+1}='FsIn';
            varargin{end+1}=FsIn;
        end

        [varargout{1:nargout}] = obj.getFilters.outputDelay(varargin{:});
    end

end

methods (Access=protected)
    function flag = isInputSizeMutableImpl(~,~)
        flag = true;
    end
    
    function setupImpl(obj, u)
        setfilters(obj);
        obj.NumChannels = int32(size(u,2));
    end
    
    function setfilters(obj)
        % Create filter System objects
        
        if obj.AreFiltersDesigned
            % This helps avoid duplicate construction of filters when
            % setup() is called after getFilters().
            % For codegen, this property is always false.
            return
        end
        
        coder.extrinsic('dsp.SampleRateConverter.designfilters');
        if ~isempty(coder.target)
            [s, numStages, ~] = coder.const(@obj.designfilters, ...
                obj.InputSampleRate, obj.OutputSampleRate, obj.OutputRateTolerance,...
                obj.Bandwidth, obj.StopbandAttenuation);
        else
            [s, numStages, filtObjs] = coder.const(@obj.designfilters, ...
                obj.InputSampleRate, obj.OutputSampleRate, obj.OutputRateTolerance,...
                obj.Bandwidth, obj.StopbandAttenuation);
        end
        obj.Nstages = numStages;
        for k = coder.unroll(1:obj.MaxFilters, true)
            
            if k<=numStages
                if s.(['rcf',obj.FilterNumber{k}])(1) == 1 && s.(['rcf',obj.FilterNumber{k}])(2) == 1
                    % Special case: wire
                    obj.(['filt',obj.FilterNumber{k}]) = dsp.FIRFilter(...                            
                        'Numerator',s.(['coeffs',obj.FilterNumber{k}]));
               
                elseif s.(['rcf',obj.FilterNumber{k}])(1) == 1
                    % Decimator
                    obj.(['filt',obj.FilterNumber{k}]) = dsp.FIRDecimator(...
                        'DecimationFactor',s.(['rcf',obj.FilterNumber{k}])(2),...
                        'Numerator',s.(['coeffs',obj.FilterNumber{k}]),...
                        'AllowArbitraryInputLength',coder.const(isInputArbitraryOrVarSize(obj,s.(['rcf',obj.FilterNumber{k}])(2))));
                elseif s.(['rcf',obj.FilterNumber{k}])(2) == 1
                    % Interpolator
                    obj.(['filt',obj.FilterNumber{k}]) = dsp.FIRInterpolator(...
                        'InterpolationFactor',s.(['rcf',obj.FilterNumber{k}])(1),...
                        'Numerator',s.(['coeffs',obj.FilterNumber{k}]));
                else
                    % SRC
                    %   Due to dependency of dsp.Decimator's variable input framesize,
                    %   it is always set to 'false' till g2668840 is addressed.
                    %   As of now this is needed for compatabilty.
                    obj.(['filt',obj.FilterNumber{k}]) = dsp.FIRRateConverter(...
                        'InterpolationFactor',s.(['rcf',obj.FilterNumber{k}])(1),...
                        'DecimationFactor',s.(['rcf',obj.FilterNumber{k}])(2),...
                        'Numerator',s.(['coeffs',obj.FilterNumber{k}]),...
                        'AllowArbitraryInputLength',coder.const(isInputArbitraryOrVarSize(obj,s.(['rcf',obj.FilterNumber{k}])(2))));
                end
            end
        end
        
        if isempty(coder.target)
            if ~isempty(filtObjs)
                for k = 1:obj.Nstages
                    % Set fdesign and fmethod on the stages
                    setMetaData(obj.(['filt',obj.FilterNumber{k}]), ...
                        getfdesign(filtObjs{k}), getfmethod(filtObjs{k}), ...
                        [], getdesignmethod(filtObjs{k}));
                end
            end
            obj.AreFiltersDesigned = true;
        end
    end
    
    function resetImpl(obj)
        % Reset the filters
        
        for k = coder.unroll(1:obj.MaxFilters, true)
            if k<=obj.Nstages           
                reset(obj.(['filt',obj.FilterNumber{k}]));
            end
        end
    end
    
    function releaseImpl(obj)
        % Release the filters 
        
        for k = coder.unroll(1:obj.MaxFilters, true)
            if k<=obj.Nstages           
                release(obj.(['filt',obj.FilterNumber{k}]));
            end
        end
        obj.NumChannels = int32(-1);
    end
    
    function y = stepImpl(obj, u)
        % Stage:1 filtering
        y1 = step(obj.filt1,u);
        % Stage:2 filtering
        if obj.Nstages > 1
            y2 = step(obj.filt2,y1);
        else
            y = y1;
            return;
        end
        % Stage:3 filtering
        if obj.Nstages > 2
            y3 = step(obj.filt3,y2);
        else
            y = y2;
            return;
        end
        % Stage:4 filtering
        if obj.Nstages > 3
            y4 = step(obj.filt4,y3);
        else
            y = y3;
            return;
        end
        % Stage:5 filtering
        if obj.Nstages > 4
            y5 = step(obj.filt5,y4);
        else
            y = y4;
            return;
        end
        % Stage:6 filtering
        if obj.Nstages > 5
            y6 = step(obj.filt6,y5);
        else
            y = y5;
            return;
        end
        % Stage:7 filtering
        if obj.Nstages > 6
            y7 = step(obj.filt7,y6);
        else
            y = y6;
            return;
        end
        % Stage:8 filtering
        if obj.Nstages > 7
            y8 = step(obj.filt8,y7);
        else
            y = y7;
            return;
        end
        % Stage:9 filtering
        if obj.Nstages > 8
            y9 = step(obj.filt9,y8);
        else
            y = y8;
            return;
        end      
        % Stage:10 filtering
        if obj.Nstages > 9
            y10 = step(obj.filt10,y9);
        else
            y = y9;
            return;
        end
        % Stage:11 filtering
        if obj.Nstages > 10
            y11 = step(obj.filt11,y10);
        else
            y = y10;
            return;
        end
        % Stage:12 filtering
        if obj.Nstages > 11
            y12 = step(obj.filt12,y11);
        else
            y = y11;
            return;
        end
        % Stage:13 filtering
        if obj.Nstages > 12
            y13 = step(obj.filt13,y12);
        else
            y = y12;
            return;
        end
        % Stage:14 filtering
        if obj.Nstages > 13
            y14 = step(obj.filt14,y13);
        else
            y = y13;
            return;
        end
        % Stage:15 filtering
        if obj.Nstages > 14
            y = step(obj.filt15,y14);
        else
            y = y14;
            return;
        end
    end
    
    function validateInputsImpl(obj,u)
        validateattributes(u, {'single', 'double'}, {'2d'},'','')
        if obj.NumChannels ~= int32(-1) && obj.NumChannels ~= 0
            coder.internal.errorIf(...
                (int32(size(u,2)) ~= obj.NumChannels), ...
                'dsp:system:Shared:numChannels');
        end
    end       

    function s = saveObjectImpl(obj)
        % Default implementation saves all public properties
        s = saveObjectImpl@matlab.System(obj);

        % Private properties                        
        s.Nstages = obj.Nstages;
        for k = coder.unroll(1:obj.MaxFilters, true)
            if k<=obj.Nstages     
                s.(['filt',obj.FilterNumber{k}]) = matlab.System.saveObject(obj.(['filt',obj.FilterNumber{k}]));                    
            end
        end            
        s.AreFiltersDesigned = obj.AreFiltersDesigned;
        s.AdjustedOutputRate = obj.AdjustedOutputRate;

        s = saveFA(obj, s);   % Save filter analysis class properties
    end
    
    function s = loadObjectImpl(obj, s, wasLocked)
        % Private properties                        
        obj.Nstages = s.Nstages;
         for k = coder.unroll(1:obj.MaxFilters, true)
            if k<=obj.Nstages     
                obj.(['filt',obj.FilterNumber{k}]) = matlab.System.loadObject(s.(['filt',obj.FilterNumber{k}]));                    
            end
        end       
        obj.AreFiltersDesigned = s.AreFiltersDesigned;
        obj.AdjustedOutputRate = s.AdjustedOutputRate;

        loadFA(obj, s, wasLocked); % Load filter analysis class properties

        % Call base class method
        loadObjectImpl@matlab.System(obj,s,wasLocked);       
    end
    
    function needToDesignFilters(obj)
        obj.AreFiltersDesigned = false;
    end
    
    function s = infoImpl(obj)
        [L,M] = getRateChangeFactors(obj);
        c = cost(obj);
        g = getFilters(obj);
        
        NStages = obj.Nstages;
        s = '';
        if obj.OutputRateTolerance ~= 0
            s = [s,sprintf('Output Sample Rate Tolerance    : %f %%\n',100*obj.OutputRateTolerance)];            
            s = [s,sprintf('Adjusted Output Sample Rate     : %f\n',obj.AdjustedOutputRate)];            
        end
        BW = obj.Bandwidth;
        minFs = min(obj.InputSampleRate,obj.AdjustedOutputRate);
        if  BW > minFs || abs((BW - minFs)/minFs) < .01
            s = [s,sprintf('Specified two-sided bandwidth   : %f\n',BW)];
            s = [s,sprintf('Adjusted two-sided bandwidth    : %f\n',minFs - .01*minFs)]; 
        end
        s = [s,sprintf('Overall Interpolation Factor    : %d\n',L)];
        s = [s,sprintf('Overall Decimation Factor       : %d\n',M)];
        s = [s,sprintf('Number of Filters               : %d\n',NStages)];
        s = [s,sprintf('Multiplications per Input Sample: %f\n',c.MultiplicationsPerInputSample)];
        s = [s,sprintf('Number of Coefficients          : %d\n',c.NumCoefficients)];
        s = [s,sprintf('Filters:                         \n')];
        for k = 1:NStages
            s = [s,sprintf('   Filter %d:\n',k)]; %#ok
            h = g.(['Stage',num2str(k)]);
            if isa(h,'dsp.FIRDecimator')
                s = [s,sprintf('   dsp.FIRDecimator     - Decimation Factor   : %d \n',h.DecimationFactor)]; %#ok                  
            elseif isa(h,'dsp.FIRRateConverter')
                s = [s,sprintf('   dsp.FIRRateConverter - Interpolation Factor: %d\n',h.InterpolationFactor)];%#ok
                s = [s,sprintf('                        - Decimation Factor   : %d \n',h.DecimationFactor)];   %#ok                
            elseif isa(h,'dsp.FIRInterpolator')
                s = [s,sprintf('   dsp.FIRInterpolator  - Interpolation Factor: %d \n',h.InterpolationFactor)]; %#ok
            elseif isa(h,'dsp.FIRFilter')
                s = [s,sprintf('   dsp.FIRFilter  - Decimation Factor: 1 \n')]; %#ok
            end
        end            
    end
    
    function [FsIn,rcf,g] = FsPerStage(obj)
        
        g = getFilters(obj);
        
        NStages = obj.Nstages;
        InFs = obj.InputSampleRate;
        
        % Store input rate of each filter in chain
        FsIn = zeros(NStages,1);
        FsIn(1) = InFs;
        
        % Store rate change of each filter
        rcf = zeros(NStages,2);
                               
        for k = 1:NStages
            h = g.(['Stage',num2str(k)]);
            if isa(h,'dsp.FIRDecimator')
                rcf(k,:) = [1 h.DecimationFactor];
            elseif isa(h,'dsp.FIRRateConverter')
                rcf(k,:) = [h.InterpolationFactor h.DecimationFactor];
            elseif isa(h,'dsp.FIRInterpolator')
                rcf(k,:) = [h.InterpolationFactor 1];
            end
            if k < NStages
                FsIn(k+1) = FsIn(k)*rcf(k,1)/rcf(k,2);
            end                
        end
    end  
    
    function d = convertToDFILT(obj,arith)
        if (nargin>1 || isempty(arith))
            coder.internal.errorIf(strcmpi(arith,'fixed'), 'dsp:system:SampleRateConverter:NoFixedArith');
        end

        % id = obj.validateratechangefactors();
        % reducible = isempty(id);
        % 
        % % If a single stage equivalent does not exists
        % if ~reducible
        %     reasonstr = string(message(id));
        %     coder.internal.error('dsp:system:SampleRateConverter:IrreducibleCascadeUnsupported',reasonstr);
        % end

        d = todfilt(getFilters(obj),arith);
    end    

    function f = effectiveFilterRate(obj)
        % Return the rate at which the reduced single-stage FIRRC filter 
        % operates (assuming it exists) 
        [L,~] = obj.rateConversionFactors();
        f =  L*obj.InputSampleRate;
    end
end

methods
    function C = getFilters(obj)
         %C = getFilters(obj) get filters
         %   C = getFilters(obj) returns the multirate filters used to
         %   perform the sampling rate conversion in a FilterCascade C.
         %   Each field of the structure holds the filter used at a
         %   given stage. The stages are cascaded together in order to
         %   perform the overall rate conversion.
         %   % Example: Get filters used for sample rate conversion
         %   % between 192 kHz and 44.1 kHz
         %   SRC = dsp.SampleRateConverter;
         %   C = getFilters(SRC);
         
         if ~obj.AreFiltersDesigned
             setfilters(obj);
             obj.AreFiltersDesigned = true;
         end
            
         C = dsp.FilterCascade(obj.filt1);
         for idx = 2:obj.Nstages
             addStage(C,obj.(['filt', num2str(idx)]));
         end
    end                    
    
    function [L,M] = getRateChangeFactors(obj)
         %[L,M] = getRateChangeFactors(obj) get rate change factors
         %   [L,M] = getRateChangeFactors(obj) returns overall
         %   interpolation factor L and the overall decimation factor M
         %   corresponding to the Input/Output sample rates. The
         %   factors are computed taking into account the
         %   OutputRateTolerance.
         %   % Example: Get overall interpolation/decimation factors
         %   % for conversion between 192 kHz and 44.1 kHz
         %   SRC = dsp.SampleRateConverter;
         %   [L,M] = getRateChangeFactors(SRC);       
        coder.extrinsic('dsp.SampleRateConverter.myrat');
        [L,M] = coder.const(@dsp.SampleRateConverter.myrat,obj.InputSampleRate,...
            obj.OutputSampleRate,obj.OutputRateTolerance);                        
    end
         
    function FsOut = getActualOutputRate(obj)
         %FsOut = getActualOutputRate(obj) get actual output rate
         %   FsOut = getActualOutputRate(obj) returns the actual output
         %   sample rate computed taking into account the
         %   OutputRateTolerance.
         %   % Example: Get actual output sample rate for conversion 
         %   % between 192 kHz and 44.1 kHz with a 1% tolerance
         %   SRC = dsp.SampleRateConverter;
         %   SRC.OutputRateTolerance = 0.01;
         %   FsOut = getActualOutputRate(SRC);            
        [L,M] = getRateChangeFactors(obj); 
        FsOut = obj.InputSampleRate*L/M;
    end
    
    function c = cost(obj)
        %C = cost(obj) compute implementation cost
        %   C = cost(obj) returns a structure C whose fields contain
        %   information about the computation cost of implementing the
        %   sample rate converter. The cost estimate contains the
        %   following fields:
        %   NumCoefficients               : Number of filter 
        %                                   coefficients (excluding 
        %                                   coefficients with values 0,
        %                                   1 or -1)
        %   NumStates                     : Number of states
        %   MultiplicationsPerInputSample : Number of multiplications 
        %                                   per input sample
        %   AdditionsPerInputSample       : Number of additions per
        %                                   input sample
        %   % Example: Compute cost for conversion between 192 kHz
        %   % and 44.1 kHz with a 0% tolerance and compare to the cost
        %   % of the same conversion with 10% tolerance
        %   SRC = dsp.SampleRateConverter;
        %   cost(SRC)
        %   SRC.OutputRateTolerance = 0.1;
        %   cost(SRC)
        
        g = getFilters(obj);
        c = cost(g);
    end
    
    function  visualizeFilterStages(obj)
        %visualizeFilterStages(obj) visualize filter stages
        %   visualizeFilterStages(obj) shows the response of each
        %   individual filter stage using FVTool.
        %   % Example: Visualize the 3 stages used for conversion 
        %   % between 192 kHz and 44.1 kHz 
        %   SRC = dsp.SampleRateConverter;
        %   visualizeFilterStages(SRC)
        [FsIn,rcf,g] = FsPerStage(obj);
        for idx = 1:obj.Nstages
            s{idx} = g.(['Stage', num2str(idx)]); %#ok<*EMCA>
        end            
        fvtool(s{:},'Fs',FsIn.*rcf(:,1),'NormalizeMagnitudeto1','on','Legend','on');
    end
    
    function varargout = freqz(obj,f,range)
        %[H,f] = freqz(obj,N,range) frequency response
        %   [H,f] = freqz(obj,N,range) returns the complex frequency
        %   response H and the frequency vector f at which H is
        %   computed. N is the number of frequency points. If not
        %   specified, it defaults to 8192. range is the frequency
        %   range over which the response is computed; range can be
        %   either 'half' or 'whole'. If not specified, it defaults to
        %   'half'.
        %
        %   [H,f] = freqz(obj, f) returns the complex frequency response
        %   H computed at the frequency points specified by vector f.
        %   The vector f is assumed to be in Hz.
        %
        %   freqz(obj) with no output argument launches FVTool and shows 
        %   the magnitude and phase responses of the filter System object.
        %
        %   % Example 1: Compute the frequency response corresponding 
        %   % to the combined 3 filter stages used to convert from 192
        %   % kHz to 44.1 kHz
        %   SRC = dsp.SampleRateConverter(InputSampleRate=20e3, ...
        %                                 OutputSampleRate=0.5e3, ...
        %                                 Bandwidth=400);
        %   [H,f] = freqz(SRC);
        %   plot(f, 20*log10(abs(H)))
        %
        %   % Example 2: Compute the frequency response corresponding 
        %   % to the combined 3 filter stages used to convert from 192
        %   % kHz to 44.1 kHz over the range [20 Hz, 44.1 kHz]
        %   SRC = dsp.SampleRateConverter(InputSampleRate=192e3, ...
        %                                 OutputSampleRate=32e3, ...
        %                                 Bandwidth=30e3)
        %   f = 20:10:44.1e3;
        %   H = freqz(SRC, f, 192e3);
        %   plot(f, 20*log10(abs(H)))

        arguments
            obj;
            f (:,:) double = 8192;
            range (1,1) string {mustBeMember(range,{'whole','half'})} = "half";
        end

        [FsIn,rcf,g] = FsPerStage(obj);

        NStages = obj.Nstages;

        if length(f) == 1
            %NFFT specified
            MaxFreq = max(obj.InputSampleRate,obj.OutputSampleRate);
            if strcmpi(range,'half')
                f = linspace(0,MaxFreq/2-MaxFreq/(2*f),f)';
            else
                f = linspace(-MaxFreq/2,MaxFreq/2-MaxFreq/f,f)';
            end
        end

        [H,f] = freqz(g.Stage1,f,FsIn(1)*rcf(1,1));

        for k = 2:NStages
            H = H.*freqz(g.getStage(k),f,FsIn(k)*rcf(k,1));
        end

        if nargout == 0
            % Plot frequency response
            if ishandle(obj.freqzHandle)
               figure(obj.freqzHandle);
            else
               obj.freqzHandle = figure;
            end

            subplot(2,1,1),plot(f,20*log10(abs(H)));
            grid on
            xlabel('Frequency (Hz)')
            ylabel('Magnitude (dB)')
            xlim([0 f(end)]) 
            subplot(2,1,2),plot(f,unwrap(angle(H)));
            grid on
            xlabel('Frequency (Hz)')
            ylabel('Phase (degrees)')
            xlim([0 f(end)])

        else
            if nargout > 0
                varargout{1} = H;
            end
            if nargout > 1
                varargout{2} = f;
            end
        end
        
    end
end

methods (Static, Hidden)
    function [s, Nstages, filtObjs] = designfilters(InputSampleRate, ...
                                OutputSampleRate, OutputRateTolerance,...
                                BW, Astop)                                               
                    
        % Overall interpolation,decimation
        [L,M] = dsp.SampleRateConverter.myrat(InputSampleRate,OutputSampleRate,OutputRateTolerance);
        
        % Recompute OutputSampleRate for given tolerance
        OutputSampleRate = InputSampleRate*L/M;
        
        filtObjs = {};
        if L == 1 && M == 1
            % No rate change
            s.coeffs1 = 1;
            s.rcf1 = [1 1];
            Nstages = 1;
            return
        end            
        
        minFs = min(InputSampleRate,OutputSampleRate);
        if  BW > minFs || abs((BW - minFs)/minFs) < .01
            % Bandwidth of interest is too close to sampling rates, no
            % room for filter transition bands. Adjust bandwidth to be
            % 1% smaller than sampling rate
            BW = minFs - .01*minFs;
            m = message('dsp:system:SampleRateConverter:BW',num2str(BW));                
            warning(m);
        end
        
        FM = sort([cumprod(fliplr(factor(M))) cumprod(factor(M))]);
        FL = sort([cumprod(fliplr(factor(L))) cumprod(factor(L))]);
        
        TW = min(InputSampleRate,OutputSampleRate) - BW; % Overall transition width
        
        
        % Decimate first if at all possible; Determine Optimal decimation
        M1max = floor(InputSampleRate/OutputSampleRate);
        if any(M1max>=FM)
            M1 = FM(find(FM <= M1max,1,'last'));
        else
            M1 = 1;
        end
        TW1 = (InputSampleRate/M1 - BW);
        
        % Suppress MFILT deprecation warning on calling design method
        % without "SystemObject" flag set to true.
        w = warning('off', 'dsp:fdesign:basecatalog:UseSystemObjectForMultirateDesigns');
        restoreWarn = onCleanup(@() warning(w));
        
        if M1 > 1
            useMultistageDecim = true;
            % Design multistage decimator
            hmd = designMultistageDecimator(M1,InputSampleRate,TW1,Astop);
        else
            useMultistageDecim = false;
        end
        
        if L == 1
            needMoreFilts = false;
        else
            needMoreFilts = true;
        end
        
        if needMoreFilts
            if M/M1 > 1
                useSRC = true;
                % SRC needed, design it 
                SampleRateAfterDecim = InputSampleRate/M1;
                % Design an SRC that doesn't reduce the rate if possible
                L1 = FL(find(FL > M/M1,1,'first'));
                if isempty(L1)
                    % If have to reduce the rate, just interpolate by full
                    % factor
                    L1 = L;
                    TW1 = InputSampleRate*L1/M - BW; % Sample rate after SRC
                end
                fsrc = fdesign.rsrc(L1,M/M1,'Nyquist',max(L1,M/M1),...
                    TW1,Astop,SampleRateAfterDecim*L1);
                hsrc = kaiserwin(fsrc,'SystemObject',true);
            else
                useSRC = false;
                L1 = 1;
            end
            
            if L1 < L
                SampleRateAfterSRC = InputSampleRate*L1/M;
                useMultistageInterp = true;
                % Try multistage interpolation but never interpolate beyond
                % final sampleRateOut  
                hmi = designMultistageInterpolator(L/L1,SampleRateAfterSRC*L/L1,...
                    TW,Astop);
            else
                useMultistageInterp = false;                  
            end
        end
        
        finalIdx = 0;
        if useMultistageDecim
            for k = 1:getNumStages(hmd)
                finalIdx = finalIdx + 1;
                s.(['coeffs',num2str(finalIdx)]) = ...
                    hmd.(['Stage',num2str(k)]).Numerator;
                s.(['rcf',num2str(finalIdx)]) = ...
                    [1, hmd.(['Stage',num2str(k)]).DecimationFactor];
                filtObjs{finalIdx} = hmd.(['Stage',num2str(k)]);
            end
        end
        
        if needMoreFilts
            if useSRC
                finalIdx = finalIdx + 1;
                s.(['coeffs',num2str(finalIdx)]) = ...
                    hsrc.Numerator;
                s.(['rcf',num2str(finalIdx)]) = ...
                    [hsrc.InterpolationFactor hsrc.DecimationFactor];                        
                filtObjs{finalIdx} = hsrc;
            end
            
            if useMultistageInterp
                for k = 1:getNumStages(hmi)
                    finalIdx = finalIdx + 1;
                    s.(['coeffs',num2str(finalIdx)]) = ...
                        hmi.(['Stage',num2str(k)]).Numerator;
                    s.(['rcf',num2str(finalIdx)]) = ...
                        [hmi.(['Stage',num2str(k)]).InterpolationFactor, 1];
                    filtObjs{finalIdx} = hmi.(['Stage',num2str(k)]);
                end
            end
        end
        
        Nstages = finalIdx;
    end
    function [L,M,FsOutNew] = myrat(FsIn,FsOut,FsTol)                        
                    
        [Le,Me] = rat(FsOut/FsIn,0); % Exact factors
        tol = abs(Le/Me-(FsOut + FsOut*FsTol)/FsIn);
        
        [L,M] = rat(FsOut/FsIn,tol);
        
        FsOutNew = FsIn*L/M;
    end
end

methods(Static, Access=protected)
    function group = getPropertyGroupsImpl
        %Get default parameters group for this System object
        propertyList = {'InputSampleRate','OutputSampleRate',...
                        'OutputRateTolerance','Bandwidth',...
                        'StopbandAttenuation'};
        group = matlab.system.display.Section(Title='dsp:system:Shared:Parameters',...
                                   PropertyList=propertyList);
    end
    
end

methods (Hidden)
    function f = callFvtool(obj)
        % Used to bring up fvtool plot when object is used in Simulink
        f = callFvtool@dsp.internal.FilterAnalysis(obj);
        set(f, Fs = effectiveFilterRate(obj));
    end

    function f = updateFvtoolFigure(obj, f)
        % Used to update fvtool plot when object is used in Simulink
        f = updateFvtoolFigure@dsp.internal.FilterAnalysis(obj, f);
        set(f, Fs = effectiveFilterRate(obj));
    end
    
    function id = validateratechangefactors(obj,varargin)
        id = obj.getFilters.validateratechangefactors;
    end

    function id = islinphase(obj,varargin)
        id = obj.getFilters.islinphase;
    end

    function FsIn = inputSampleRate(obj) 
        FsIn = obj.InputSampleRate;
    end

    function [L,M] = rateConversionFactors(obj)
        nargoutchk(2, 2);
        [L,M] = obj.getFilters().rateConversionFactors();
    end

    function flag = isPropertyActive(obj,prop)
        flag = ~isInactivePropertyImpl(obj, prop);
    end

    function props = getNonFixedPointProperties(~)
        props = dsp.SampleRateConverter.getDisplayPropertiesImpl;
    end

    function props = getFixedPointProperties(~)
        props = {};
    end

    function restrictionsCell = getFixedPointRestrictions(~)
        restrictionsCell = {};
    end
end
end %classdef
