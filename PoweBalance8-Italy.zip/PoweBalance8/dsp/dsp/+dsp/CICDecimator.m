classdef (StrictDefaults)CICDecimator < dsp.internal.CICDecIntBase
%CICDecimator Decimate signal using Cascaded Integrator-Comb filter
%   CICDECIM = dsp.CICDecimator returns a System object, CICDECIM, that
%   applies a Cascaded Integrator-Comb (CIC) Decimation filter to the input
%   signal. Inputs and outputs to the object are fixed-point or
%   floating-point data types. A Fixed-Point Designer license is required
%   to use this System object.
%
%   CICDECIM = dsp.CICDecimator('PropertyName', PropertyValue, ...) returns
%   a CIC decimation object, CICDECIM, with each specified property set to
%   the specified value.
%
%   CICDECIM = dsp.CICDecimator(R, M, N, 'PropertyName', PropertyValue,
%   ...) returns a CIC decimation object, CICDECIM, with the
%   DecimationFactor property set to R, the DifferentialDelay property set
%   to M, the NumSections property set to N, and other specified properties
%   set to the specified values.
%
%   Step method syntax:
%
%   Y = step(CICDECIM, X) decimates input X to produce an output Y using
%   the CIC decimator object CICDECIM. Input X can be of data type double,
%   single, integer, or fixed point (fi objects).
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   CICDecimator methods:
%
%   step              - See above description for use of this method
%   release           - Allow property and input characteristics changes
%   clone             - Create object with same property values
%   isLocked          - Locked status (logical)
%   reset             - Reset the internal states to initial conditions
%   generatehdl       - Generate HDL code: Filter Design HDL Coder required
%   getFixedPointInfo - Get fixed-point word lengths and fraction lengths
%                       for integrator sections, comb sections, and output
%
%   CICDecimator properties:
%
%   DecimationFactor       - Decimation factor of filter
%   DifferentialDelay      - Differential delay of filter comb sections
%   NumSections            - Number of integrator and comb sections
%   FixedPointDataType     - Fixed-point property designations
%   SectionWordLengths     - Word lengths for each filter section
%   SectionFractionLengths - Fraction lengths for each filter section
%   OutputWordLength       - Word length for filter output
%   OutputFractionLength   - Fraction length for filter output
%
%   This System object supports several filter analysis methods. For more
%   information, type dsp.CICDecimator.helpFilterAnalysis.
%
%   % EXAMPLE: Decimate signal by a factor of 4 (downsample from 44.1 kHz 
%   % to 11.025 kHz) by specifying the 'Minimum section word lengths' 
%   % FixedPointDataType mode.
%       CICDecim = dsp.CICDecimator(4);  
%       % Specify DecimationFactor = 4, use default NumSections = 2, 
%       % DifferentialDelay = 1
%       CICDecim.FixedPointDataType = 'Minimum section word lengths'; 
%       CICDecim.OutputWordLength = 16;  % Specify the output word length
%       % Create fixed-point sinusoidal input signal 
%       Fs = 44.1e3;              % Original sampling frequency: 44.1 kHz
%       n = (0:1023)';            % 1024 samples, 0.0232 second long signal
%       x = fi(sin(2*pi*1e3/Fs*n),true,16,15);     
%       SigIn = dsp.SignalSource(x, 64);
%       % Process the input signal
%       y = zeros(16,16);
%       for ii=1:16
%         % Decimated output with 16 samples per frame
%         y(ii,:) = CICDecim( SigIn() );
%       end
%       % Plot the first frame of the original and decimated signals.
%       % The output latency is 2 samples.
%       gainCIC = (CICDecim.DecimationFactor*CICDecim.DifferentialDelay)...
%                  ^CICDecim.NumSections;
%       stem(n(1:56)/Fs, double(x(4:59))); 
%       hold on;     
%       stem(n(1:14)/(Fs/CICDecim.DecimationFactor), ...
%                  double(y(1,3:end))/gainCIC,'r','filled'); 
%       xlabel('Time (sec)');
%       ylabel('Signal Amplitude');
%       legend('Original signal', 'Decimated signal', 'location', 'north');
%       hold off;    
%
%   See also dsp.CICInterpolator, dsp.FIRDecimator.

%   Copyright 1995-2021 The MathWorks, Inc.

%#codegen
%#ok<*EMCLS>
%#ok<*EMCA>

  properties (Nontunable)
    %DecimationFactor Decimation factor of filter
    %   Specify a positive integer amount by which the input signal will be
    %   decimated. The default value of this property is 2.
    DecimationFactor = 2;
    
    %DifferentialDelay Differential delay of filter comb sections
    %   Specify a positive integer delay value to be used in each of the
    %   comb sections of the filter. The default value of this property is
    %   1.
    DifferentialDelay = 1;
    
    %NumSections Number of integrator and comb sections
    %   Specify the number of integrator and comb sections in the filter as
    %   a positive integer value. The default value of this property is 2.
    NumSections = 2;
    
    %FixedPointDataType Fixed-point property designations
    %   Specify the fixed-point data type as one of ['Full precision' |
    %   'Minimum section word lengths' | 'Specify word lengths' | 'Specify
    %   word and fraction lengths']. When this property is set to 'Full
    %   precision', the System object automatically determines the word and
    %   fraction lengths of the filter sections and output. When the
    %   property is set to 'Minimum section word length', the object
    %   automatically determines the word and fraction lengths of the
    %   filter sections and the fraction length of the output. When the
    %   property is set to 'Specify word lengths', the object automatically
    %   determines the fraction lengths of the filter sections and the
    %   output. The default is 'Full precision'.
    FixedPointDataType = 'Full precision';
    
    % SectionWordLengths Word lengths for each filter section
    %   Specify the fixed-point word length to use for each filter section.
    %   There are (2*NumSections) filter sections to be specified. This
    %   property is applicable when the FixedPointDataType property is set
    %   to one of ['Specify word lengths' | 'Specify word and fraction
    %   lengths']. The default value of this property is [16 16 16 16].
    SectionWordLengths = [16 16 16 16];
    
    % SectionFractionLengths Fraction lengths for each filter section
    %   Specify the fixed-point fraction length to use for each filter
    %   section. There are (2*NumSections) filter sections to be specified.
    %   This property is applicable when the FixedPointDataType property is
    %   set to 'Specify word and fraction lengths'. The default value of
    %   this property is 0.
    SectionFractionLengths = 0;
    
    % OutputWordLength Word length for filter output
    %   Specify the fixed-point word length to use for the filter output.
    %   This property is applicable when the FixedPointDataType property is
    %   set to one of ['Minimum section word lengths' | 'Specify word
    %   lengths' | 'Specify word and fraction lengths']. The default value
    %   of this property is 32.
    OutputWordLength = 32;
    
    % OutputFractionLength Fraction length for filter output
    %   Specify the fixed-point fraction length to use for the filter
    %   output. This property is applicable when the FixedPointDataType
    %   property is set to 'Specify word and fraction lengths'. The default
    %   value of this property is 0.
    OutputFractionLength = 0;
  end
  
  properties (Constant, Hidden)
    FixedPointDataTypeSet = matlab.system.StringSet({'Full precision', ...
        'Minimum section word lengths', 'Specify word lengths',...
        'Specify word and fraction lengths'});
  end
  
  methods
    function obj = CICDecimator(varargin)
      setProperties(obj, nargin, varargin{:}, ...
          'DecimationFactor', 'DifferentialDelay', 'NumSections');
    end
    
    function set.DecimationFactor(obj, value)
        validateattributes( value, {'numeric'}, ...
            {'real', 'positive', 'integer', 'scalar'}, '', 'DecimationFactor');
        clearMetaData(obj)
        obj.DecimationFactor = value;
    end
    
    function set.DifferentialDelay(obj, value)
        validateattributes(value, {'numeric'}, ...
            {'real', 'positive', 'integer', 'scalar'}, '', 'DifferentialDelay');
        clearMetaData(obj)
        obj.DifferentialDelay = value;
    end
    
    function set.NumSections(obj, value)
        validateattributes(value, {'numeric'}, ...
            {'real', 'positive', 'integer', 'scalar', '<=', 15 }, ...
            '', 'NumSections');
        clearMetaData(obj)
        obj.NumSections = value;
    end
    
    function set.OutputWordLength(obj, value)
        validateattributes(value, {'numeric'}, ...
            {'real', 'positive', 'integer', 'scalar', '<=', 128, '>=', 2 }, ...
            '', 'OutputWordLength');
        obj.OutputWordLength = value;
    end
    
    function set.OutputFractionLength(obj, value)
        validateattributes(value, {'numeric'}, ...
            {'real', 'integer', 'scalar'}, '', 'OutputFractionLength');
        obj.OutputFractionLength = value;
    end
    
    function set.SectionWordLengths(obj, value)
        if strncmp(obj.FixedPointDataType, 'Specify', 7) %#ok
            validateattributes(value, {'numeric'}, ...
                {'real', 'integer', '<=', 128, '>=', 2}, '', 'SectionWordLengths');
        end
        obj.SectionWordLengths = value;
    end
    
    function set.SectionFractionLengths(obj, value)
        if strncmp(obj.FixedPointDataType, 'Specify word and fraction lengths', 30) %#ok
            validateattributes(value, {'numeric'}, ...
                {'real', 'integer'}, '', 'SectionFractionLengths');
        end
        obj.SectionFractionLengths = value;
    end
    
    function g = gain(obj,varargin)
      %GAIN   Gain of the CIC decimation filter System object
      %   G  = gain(Hd) returns the gain, G, of the first stage up to and
      %   including the last stage of the CIC decimation filter System
      %   object, Hd.      
      g = (obj.DecimationFactor)^(obj.NumSections);      
    end
  end
  
  %----------------------------------------------------------------------
  % Hidden methods
  %----------------------------------------------------------------------
  
  methods (Hidden)
    function props = getNonFixedPointProperties(~)
        props = {...
          'DecimationFactor',...
          'DifferentialDelay',...
          'NumSections'};
    end
  
    function a = computeCICWLsFLs(obj, inWL, inFL, modestr, n, sectionWL)
        coder.extrinsic('getcicdecimwlnfl');
        if isempty(coder.target)
            a = getcicdecimwlnfl(inWL, inFL, modestr, n, ...
                obj.DecimationFactor, obj.DifferentialDelay, ...
                obj.OutputWordLength, sectionWL);
        else
            a = coder.internal.const(double(getcicdecimwlnfl( ...
                inWL, inFL, modestr, n, obj.DecimationFactor, ...
                obj.DifferentialDelay, obj.OutputWordLength, sectionWL)));
        end
    end

    function [L,M] = rateConversionFactors(obj) 
        nargoutchk(2, 2);
        M = obj.DecimationFactor;
        L = 1;
    end
  end
  
  methods (Static, Hidden)
    function coeffs = getCICFIRCoefficients(N,Fac)
        % Design a FIR filter with a CIC response using a cascade of
        % boxcar filters.
        % N is the number of sections.
        % Fac is the factor (decimation or interpolation)
        x = ones( 1, Fac );
        c = x;
        for idx = 1:(N - 1)
            c = conv( c, x );
        end
        coeffs = c;
    end
  end
  
  methods (Access=protected)
    function validateInputsImpl(obj,varargin)
      % Call base class validate inputs
      validateInputsImpl@dsp.internal.CICDecIntBase(obj,varargin{:});
      
      % CICDecimator special case check:
      %   Number of input rows must be a multiple of DecimationFactor
      coder.internal.errorIf( ...
          mod(size(varargin{1},1),obj.DecimationFactor)~=0, ...
          'dsp:system:inputNotMultDecFac');
    end
    
    function setupImpl(obj, in)
      coder.extrinsic('int2str');
      coder.extrinsic('dsp.CICDecimator.getCICFIRCoefficients')
      
      n = obj.NumSections;
      
      if isfloat(in)
          % double, single, fi double and fi single         
          if isa(in, 'embedded.fi')
              if isdouble(in)
                    obj.pArithmetic = 'double';
                elseif issingle(in)
                    obj.pArithmetic = 'single';
              end
          elseif isa(in, 'double')
              obj.pArithmetic = 'double';
          else
              obj.pArithmetic = 'single';
          end
          
          obj.pInputNT = numerictype(obj.pArithmetic);
          
          % Design FIR Boxcar Filter with direct form structure
          firCoeffs = coder.const(@obj.getCICFIRCoefficients, n,...
                obj.DecimationFactor * obj.DifferentialDelay);
          obj.pFIRFilter = dsp.FIRFilter('Numerator', firCoeffs);
          % Allocate internal states
          obj.pDelayStates = struct('States', ...
              zeros(n, size(in,2), 'like', in));
      else
          
          obj.pArithmetic = 'fixed';
          
          if isfi(in)
              obj.pInputNT = numerictype(in);        % fi types
          else
              obj.pInputNT = numerictype(class(in)); % int8, etc.
          end
          
          [sectionWL, sectionFL, outWL, outFL] = ...
              getWLsFLsFromInputNT(obj, obj.pInputNT);
          
          for i = coder.unroll(1:n)
              intgStageName = ...
                  coder.internal.const(['cIntgStage' int2str(i)]);
              obj.(intgStageName) = ...
                  dsp.internal.Integrator('CustomAccumulatorDataType', ...
                  numerictype(true, sectionWL(i), sectionFL(i)));
          end
          
          for i = coder.unroll(1:n)
              cmbStageName = ...
                  coder.internal.const(['cCmbStage' int2str(i)]);
              obj.(cmbStageName) = dsp.internal.FIRCombFilter( ...
                  'DelayLength', obj.DifferentialDelay, ...
                  'CustomAccumulatorDataType', ...
                  numerictype(true,sectionWL(n+i),sectionFL(n+i)));
          end
          
          obj.cOutWL = outWL;
          obj.cOutFL = outFL;
          
      end % if isfloat(in) ... else ... end
      
    end
    
    function out = stepImpl(obj,in)
        coder.extrinsic('int2str', 'warning');
        
        warning('off', 'SimulinkFixedPoint:util:Overflowoccurred');
        
        n = obj.NumSections;
        coder.internal.const(n);
        
        %   When the input data type is double or single the object
        %   implements an N-section CIC decimation filter as an FIR filter
        %   with a response that corresponds to a cascade of N boxcar
        %   filters. A true CIC filter with actual comb and integrator
        %   sections is implemented when the input data is of a fixed point
        %   type.
        if  ~isfloat(in) && strcmpi(obj.pArithmetic,'fixed')
            % Integrator stages
            for i = coder.unroll(1:n)
                if i == 1
                    if isfi(in)
                        if issigned(in)
                            y = in;
                        else
                            % cast unsigned fixed-point input to signed
                            y = fi(in, true, ...
                                in.WordLength+1, in.FractionLength);
                        end
                    else
                        y1 = fi(in);
                        if issigned(y1)
                            y = y1;
                        else
                            y = fi(in, true, ...
                                y1.WordLength+1, y1.FractionLength);
                        end
                    end
                end
                name = coder.internal.const(['cIntgStage' int2str(i)]);
                y = step(obj.(name),y);
            end
            
            % Down sample
            y = y(1:obj.DecimationFactor:end, :);
            
            % Comb stages
            for i = coder.unroll(1:n)
                if i == 1
                    y2 = y;
                end
                name = coder.internal.const(['cCmbStage' int2str(i)]);
                y2 = step(obj.(name),y2);
            end
            out = quantizefi(y2,1,obj.cOutWL,obj.cOutFL,'floor','wrap');
        else
            % local copies of states
            Z1 = obj.pDelayStates.States;
            % filter input with FIR (Boxcar) filter           
            yconv = step(obj.pFIRFilter, in);            
            % CIC output delay Length is obj.NumSections (n)
            n1 = size(in, 1);
            if n <= n1
                out = downsample([Z1; yconv(1:end-n, :)], ...
                    obj.DecimationFactor, 0);  
                Z1 = yconv(end-n+1:end, :);
            else
                % size(yconv) == size(in),
                % so yconv(1:end-n1,:) must be empty
                out = downsample(Z1(1:n1),obj.DecimationFactor, 0); 
                Z1 = [Z1(n1+1:end); yconv(:, :)];
            end
            obj.pDelayStates.States = Z1; % save states
        end
        
        warning('on', 'SimulinkFixedPoint:util:Overflowoccurred');
        
    end
    
    function d = convertToDFILT(obj,arith)
      coder.extrinsic('warning');
      
      % Suppress MFILT deprecation warning
      w = warning('off', 'dsp:mfilt:mfilt:Obsolete');
      restoreWarn = onCleanup(@() warning(w));
      
      d = mfilt.cicdecim; %#ok
      % default d.FilterInternals = 'FullPrecision';
      d.DecimationFactor  = obj.DecimationFactor;
      d.DifferentialDelay = obj.DifferentialDelay;
      d.NumberOfSections  = obj.NumSections;
      % ensure 'full precision' if obj.pArithmetic == 'double' or 'single'
      if isfield(obj, 'pArithmetic')
         if  ~strcmpi(obj.pArithmetic,'fixed')
             obj.FixedPointDataType = 'Full precision';
         end
      end
      d.PersistentMemory = true;
      convertToDFILTCIC(obj,d,arith)
    end
    
  end % methods, protected API

end
