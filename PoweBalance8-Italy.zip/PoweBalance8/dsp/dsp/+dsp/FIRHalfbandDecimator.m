classdef (StrictDefaults)FIRHalfbandDecimator < dsp.internal.FIRHalfbandBase
%FIRHalfbandDecimator Decimate by a factor of two using polyphase FIR
%   This System object decimates an input signal using a two branch
%   polyphase structure optimized for halfband filters. All the even
%   indexed samples of halfband filters are zero except the sample at
%   the origin. This System object takes advantage of the zero
%   coefficients, thereby making the second branch of the polyphase
%   structure a delay. It can also act as an Analysis Filter bank.
%   Filter design is done using optimum equiripple filter design
%   method.
%
%   FIRHALFBANDDECIM = dsp.FIRHalfbandDecimator returns a FIR halfband
%   decimator System object, FIRHALFBANDDECIM, that decimates a signal by a
%   factor 2 using polyphase structure optimized for halfband filters. The
%   filter design parameters are 'TransitionWidth' and
%   'StopbandAttenuation' and the design ensures a minimum order equiripple
%   filter.
%
%   FIRHALFBANDDECIM = dsp.FIRHalfbandDecimator(Name=Value, ...) returns
%   a FIR Halfband decimator System object, FIRHALFBANDDECIM, with each
%   specified property set to the specified value.
%
%   Step method syntax:
%
%   Y1 = step(FIRHALFBANDDECIM,X) outputs the decimated values, Y1, of the
%   input signal X. A KixN input matrix is treated as N independent
%   channels, and the System object decimates each channel over time and
%   generates a KoxN output matrix. Ko = Ki/2, where 2 is the decimation
%   factor. The object supports real and complex floating- point and
%   fixed-point inputs.
%
%   [Y1,Y2] = step(FIRHALFBANDDECIM,X) outputs two baseband signals: Y1 and
%   Y2. X, a KixN input matrix is treated as N independent channels. System
%   object decomposes X into two baseband signals and sends the two signals
%   through the two branches of the polyphase structure. The output signals
%   from the two branches are added to generate Y1, low pass output of the
%   Analysis Filter bank and subtracted to generate Y2, high pass output of
%   the Analysis Filter bank. Each output signal is a KoxN matrix. Ko =
%   Ki/2, where 2 is the decimation factor.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   FIRHalfbandDecimator methods:
%
%   step        - See above description for use of this method
%   release     - Allow property value and input characteristics changes
%   clone       - Create FIR Halfband decimator object with same property
%                 values
%   isLocked    - Locked status (logical)
%   reset       - Reset the internal states to initial conditions
%
%   FIRHalfbandDecimator properties:
%
%   SampleRate               - Input sample rate
%   Specification            - Filter design parameter specification.
%   FilterOrder              - Order of the filter.
%   StopbandAttenuation      - Minimum attenuation needed in stopband of
%                              FIR halfband filter.
%   TransitionWidth          - Transition width of the filter in FIR
%                              halfband decimator.
%   Numerator                - Specified FIR Halfband Coefficients,
%                              when Specification is 'Coefficients'.
%   DesignMethod             - Filter design method, specified as 'Auto',
%                              'Equiripple' or 'Kaiser'.     
%   NormalizedFrequency      - Provide normalized frequencies for filter
%                              specifications
%   AllowArbitraryInputLength - Allow arbitrary input length for fixed-size
%                              signals in code generation
%   This System object supports several filter analysis methods. For
%   more information, type dsp.FIRHalfbandDecimator.helpFilterAnalysis.
%
%   This System object supports fixed-point operations. For more
%   information, type dsp.FIRHalfbandDecimator.helpFixedPoint.
%
%   % EXAMPLE 1: Decimate an input signal by 2
%   Fs1 = 8000;     % Units = Hz
%   TW = 4.1e2;     % Units = Hz
%   order = 52;
%
%   % Construct FIR Halfband Decimator
%   firhb = dsp.FIRHalfbandDecimator(SampleRate=Fs1,...
%       Specification="Filter order and transition width",...
%       FilterOrder=order,...
%       TransitionWidth=TW,...
%       DesignMethod="Equiripple");
%
%   % Visualize its impulse response
%   fvtool(firhb,Analysis="Impulse");
%   % Plot the magnitude and phase response
%   fvtool(firhb,Analysis="freq")
%
%   % Decimated output of a white noise signal
%   x = randn(1024,2);
%   y = firhb(x);
%   release(firhb);
%
%   % Example 2: Analyze the low pass and high pass bands of an input
%   % signal
%   Fs1 = 8000;     % Units = Hz
%   TW = 4.1e2;     % Units = Hz
%   order = 52;
%
%   % Construct FIR Halfband Decimator
%   firhb = dsp.FIRHalfbandDecimator(SampleRate=Fs1,...
%       Specification="Filter order and transition width",...
%       FilterOrder=order,...
%       TransitionWidth=TW);
%
%   % Input
%   f1 = 1000;
%   f2 = 3000;
%   sine = dsp.SineWave(Frequency=[f1,f2],SampleRate=Fs1,...
%       SamplesPerFrame=1024);
%
%   % Construct Spectrum Analyzer object to view the noisy input spectrum
%   scopeInput = spectrumAnalyzer(SampleRate=Fs1,...
%       Method="welch", ...
%       PlotAsTwoSidedSpectrum=false,...
%       ShowLegend=true,YLimits=[-120 30],...
%       Title="Input Signal with noise",...
%       ChannelNames="Noisy input");
%
%   % Construct Spectrum Analyzer object to view lowpass band
%   scopeLP = spectrumAnalyzer(SampleRate=Fs1/2,...
%       Method="welch", ...
%       PlotAsTwoSidedSpectrum=false,...
%       ShowLegend=true,YLimits=[-120 30],...
%       Title="Lowpass band output",...
%       ChannelNames="Lowpass band");
%
%   % Construct Spectrum Analyzer object to view highpass band
%   scopeHP = spectrumAnalyzer(SampleRate=Fs1/2,...
%       Method="welch", ...
%       PlotAsTwoSidedSpectrum=false,...
%       ShowLegend=true,YLimits=[-120 30],...
%       Title="Highpass band moved to Baseband",...
%       ChannelNames="Highpass band");
%
%   % Stream processing loop
%   for k = 1:100
%       input = sum(sine(),2);
%       noisyInput = input + (10^-5)*randn(1024,1);
%       [lowpass, highpass] = firhb(noisyInput);
%       scopeInput(noisyInput);
%       scopeLP(lowpass);
%       scopeHP(highpass);
%   end
%
%   See also dsp.FIRHalfbandInterpolator, dsp.FIRDecimator,
%            designHalfbandFIR, 
%            dsp.FIRHalfbandDecimator.helpFilterAnalysis.

%   Copyright 2014-2023 The MathWorks, Inc.
    
%#codegen
%#ok<*EMCA>
    
    properties (Nontunable)
        %TransitionWidth Transition width
        %   Specify the transition width for the designed FIR halfband
        %   filter as a finite positive scalar which is less than half the
        %   input sample rate. Specify the value of transition width in
        %   Hertz when NormalizedFrequency is set to false and in
        %   normalized units when NormalizedFrequency is set to true.This
        %   property applies when the Specification is either 'Filter order
        %   and transition width' | 'Transition width and stopband
        %   attenuation'. The default value of this property is 4100Hz.
        TransitionWidth = 4.1e3;
        
        %Numerator Numerator
        %   Specify the FIR Halfband Coefficients. The default value of
        %   this property is designHalfbandFIR(TransitionWidth=0.186, ...
        %   StopbandAttenuation=80, Structure='decim'). This property 
        %   applies when you set Specification to 'Coefficients'.
        Numerator = designHalfbandFIR(TransitionWidth=0.186, StopbandAttenuation=80, Structure='decim');

        %AllowArbitraryInputLength Allow arbitrary frame length for fixed-size input signals
        %   When this flag is set to true, the fixed-size input signal can
        %   have a frame size that is not a multiple of the 2. This
        %   property applies only when the input is a fixed-size signal. If
        %   the size of the input signal varies during simulation
        %   (variable-size signal), this property does not apply. The
        %   default value is 'false' and has to be set to 'true' to process
        %   inputs with arbitrary frame lengths.
        AllowArbitraryInputLength (1, 1) logical = false;
    end
    
    properties (Access=private)
        partialAcc;
    end
    properties (Access=protected)
        isPartialAccEmpty (1, 1) logical = false;
    end

    properties (Access=protected, Nontunable)
        EmptyOutputFixPt;
    end
    
    methods
        function obj = FIRHalfbandDecimator(varargin)
            % Support name-value pair arguments
            obj@dsp.internal.FIRHalfbandBase(varargin{:});
            if obj.NormalizedFrequency  
                isTransitionWidthSpecified = false;
                for i = 1:2:numel(varargin)
                    if strcmp(varargin{i}, 'TransitionWidth')
                        isTransitionWidthSpecified = true;
                    end
                end
                if ~isTransitionWidthSpecified
                    obj.TransitionWidth = 4.1e3/(44100/2);
                end
            end
        end
        
        function set.Numerator(obj,NUMVAL)
            coder.extrinsic('dsp.internal.FIRHalfbandBase.checkNumeratorFormat');
            
            validateattributes(NUMVAL,{'numeric'},{'finite','nonnan',...
                'nonempty','nonsparse','2d','row','vector','real'},'',...
                'Numerator');
            
            % Enforce double precision for stored Numerator values
            % (as well as for checking the formatting assumptions).
            dblNumVals = double(NUMVAL);
            coder.const(@obj.checkNumeratorFormat, dblNumVals, false);
            obj.Numerator = dblNumVals;
            
            needToDesignFilters(obj);
        end
        
        %------------------------------------------------------------------
        
        function set.TransitionWidth(obj,TW)
            validateattributes(TW,{'numeric'},{'finite','scalar',...
                'real','>',0},'','TransitionWidth');
            %cast to enforce double precision
            obj.TransitionWidth = double(TW);
            needToDesignFilters(obj);
        end
        
        %------------------------------------------------------------------
       
        function realizemdl(obj,varargin)
            warning(message('dsp:system:FIRHalfbandDecimator:realizemdlFilterBank'));
            realizemdl@dsp.internal.FilterAnalysis(obj, varargin{:});
        end
    end
    
    
	methods (Access=protected)
        
        function validateInputsImpl(obj,Input)
            validateInputsImpl@dsp.internal.FIRHalfbandBase(obj, Input);
            if ~isempty(coder.target)
                isArbSize = obj.AllowArbitraryInputLength;
                isFixedInput = propagatedInputFixedSize(obj, 1);
                % Number of input rows must be even (decimation by 2) for
                % fixed size input if AllowArbitraryInputLength is set to
                % false in codegen mode.
                coder.internal.errorIf(isFixedInput && ~isArbSize && size(Input,1)>0 && rem(size(Input,1), 2)~=0,...
                    'dsp:system:FIRHalfbandDecimator:invalidInputDimsForHalfbandDecim');
            end
        end
        
        function validatePropertiesImpl(obj)
            crossValidateProperties(obj);
        end
            
        %------------------------------------------------------------------
        
        function crossValidateProperties(obj)
            if ~(strcmp(obj.Specification, 'Coefficients') || strcmp(obj.Specification, 'Filter order and stopband attenuation'))
                inputFs = getSampleRate(obj);
                if inputFs == -1
                    return;
                end
                outputFs = inputFs/2;
                TW = obj.TransitionWidth;
                coder.internal.errorIf(TW >= outputFs, ...
                    'dsp:system:FIRHalfbandDecimator:TransitionWidth', ...
                    floor(outputFs),...
                    round((outputFs - floor(outputFs)) * 10));
            end
        end

        %------------------------------------------------------------------
        
        function num = getNumOutputsImpl(~)
            num = 2;
        end
        
        %------------------------------------------------------------------
        
        function setupImpl(obj,Input)
            %Defining the System objects
            
            setupImpl@dsp.internal.NormalizedSampleRateEngine(obj,Input);
            
            needToDesignFilters(obj);
            
            % Obtaining the number of channels
            N = getNumChannels(obj,Input);
            obj.NumChannels = int32(N);
            
            if isfloat(Input)
                % Floating-point input
                obj.partialAcc = zeros(1,N,'like',Input);
                designFilter(obj,false,Input);
            else
                % Fixed-point input
                obj.pfimath = fimath( ...
                    'SumMode',    'FullPrecision', ...
                    'ProductMode','FullPrecision');
                
                Input       = setfimath(Input, obj.pfimath);
                FIRoutputDType = designFilter(obj,false,Input);
                FIRoutputWL    = FIRoutputDType.WordLength;
                FIRoutputFL    = FIRoutputDType.FractionLength;
                ptlAccDType = numerictype(1,FIRoutputWL,FIRoutputFL);

                if obj.IsHalfOrderOdd 
                    % odd branch is delay
                    obj.partialAcc = zeros(1,N,'like',Input);
                else
                    % odd branch is FIR Filter
                    if isreal(Input)
                        obj.partialAcc = fi(zeros(1,N), ptlAccDType);
                    else
                        obj.partialAcc = fi(complex(zeros(1,N)), ptlAccDType);
                    end
                end
                

                inputDType = numerictype(Input);

                if strcmp(inputDType.Signedness, 'Signed')
                    WLGrowth = 1;
                else
                    % Coeff is always signed. So when input is unsigned,
                    % the addition is signed + unsigned. Word length grows
                    % by 2 in such full precision additions.
                    WLGrowth = 2;
                end
                outputWL = inputDType.WordLength;                
                outputFL = inputDType.WordLength-(FIRoutputWL+WLGrowth-FIRoutputFL);  
                outputDType = numerictype(true,outputWL, outputFL);    

                % Empty array of size 0 x NumChannels
                obj.EmptyOutputFixPt = fi(zeros(0,N), outputDType);
            end
        end
        
        %------------------------------------------------------------------
        
        function outputDType = designObjects(obj,u)
            % Remove the 0.5 coefficient and 0 coefficients
            % (from constant, private Coefficients values):
            Coeff1  = obj.Coefficients;
            Coeff2  = Coeff1(Coeff1~=0.5); 
            CoeffHB = Coeff2(Coeff2~=0);
            
            if strcmp(obj.Specification, 'Coefficients')
                lenObjNum = length(obj.Numerator);
                if isempty(coder.target)
                    % Simulation only (for Filter Analysis functionality)
                    obj.Coefficients(:) = 0;
                    obj.Coefficients(1:lenObjNum) = obj.Numerator;
                end
            end
            
            if nargin < 2
                u = [];
            end
            
            if isfloat(u)
                outputDType = constructFltptHFilter(obj,false,u,CoeffHB);
            else
                % Fixed-point (includes built-in integer)
                if isempty(coder.target)
                    % MATLAB interpreted mode
                    wFI = fi(CoeffHB, ...
                        obj.CoefficientsDataType);

                    % Check for excessive quantization-to-zero (all values)
                    coder.internal.errorIf(nnz(wFI==0) == length(wFI), ...
                        'dsp:system:FIRHalfbandDecimator:zeroFractionLength');
                    if isinteger(u)
                        uNT = numerictype(class(u));
                    else
                        uNT = numerictype(u);
                    end

                    outputDType = mlConstructFixptHFilter(obj, false, ...
                        wFI, CoeffHB, u, uNT);
                else
                    % CODE GENERATION
                    outputDType = cgConstructFixptHFilter(obj, false, ...
                        CoeffHB, u);
                end
            end
            filterOrder = 2*ceil((length(obj.Coefficients)-1)/2);
            obj.HDelay = dsp.Delay('Length',floor(filterOrder/4));
        end
        
        %------------------------------------------------------------------
        function isFixedOutput = isFixedSizeOutput(obj)
            isFixedOutput = ~isempty(coder.target) && propagatedInputFixedSize(obj,1) && ~obj.AllowArbitraryInputLength;
        end        

        function [LPOutputFinal,HPOutputFinal] = stepImpl(obj,Input)
                    
            isComplexityPropRunning = ...
                ~isempty(coder.target) && eml_ambiguous_complexity;
            
            if ~isComplexityPropRunning
                coder.internal.errorIf( isempty(Input), ...
                    'dsp:system:Shared:EmptyFirstStep');
            end  
            [inputFrameSize, inputChannelSize] = size(Input);
            
            isSizePropRunning = ...
                ~isempty(coder.target) && eml_ambiguous_types;
            piscomplex = ~isreal(Input);   

            if isfloat(Input)
                fixedOutputSize = coder.const(obj.isFixedSizeOutput()); 
                if fixedOutputSize % to ensure fixed size inputs for CRL for dsp.FIRFilter
                    In1 = Input(1:2:end,:);
                    In2 = Input(2:2:end,:);
                else
                    In1 = Input(1 + obj.isPartialAccEmpty:2:end,:);
                    In2 = Input(1 + ~obj.isPartialAccEmpty:2:end,:);
                end
                if piscomplex
                    In1 = complex(In1);
                    In2 = complex(In2);
                end                             
                if(obj.IsHalfOrderOdd)
                    if ~isComplexityPropRunning
                        if isempty(In1)
                            FilterOut = In1;
                        else
                            FilterOut = step(obj.HFilter,In1);
                        end
                        DelayOut  = step(obj.HDelay,In2)/2;
                    else
                        % Complexity propagation in MATLAB Function block
                        FilterOut = In1;
                        DelayOut  = In2/2;
                    end

                    if fixedOutputSize
                        lenFilterOut = coder.const(inputFrameSize)/2;
                        DelayOutputTemp = zeros(lenFilterOut,inputChannelSize,'like',DelayOut);
                        DelayOutputTemp(:) = [obj.partialAcc;DelayOut(1:inputFrameSize/2-1,:)];
                    else                    
                        lenFilterOut = size(In1,1);
                        if ~obj.isPartialAccEmpty
                            DelayOutAppended = [obj.partialAcc;DelayOut];
                        else
                            DelayOutAppended = DelayOut;
                        end
                        lenDelayOut = size(DelayOutAppended,1);                    
                        obj.isPartialAccEmpty = lenFilterOut == lenDelayOut; 
    
                        DelayOutputTemp = DelayOutAppended(1:end- ~obj.isPartialAccEmpty,:); 
                    end
                    LPOutputFinal = FilterOut(1:lenFilterOut,1:inputChannelSize) + DelayOutputTemp;

                    if piscomplex
                        LPOutputFinal = complex(LPOutputFinal);
                    end
                    
                    if nargout == 2
                        HPOutputFinal = DelayOutputTemp - FilterOut(1:lenFilterOut,1:inputChannelSize);
                        if piscomplex
                            HPOutputFinal = complex(HPOutputFinal);
                        end
                    end
                if ~obj.isPartialAccEmpty
                    obj.partialAcc(:) = DelayOut(end,:);     
                end
                   
                else % Even order
                    if ~isComplexityPropRunning
                        if isempty(In2)
                            FilterOut = In2;
                        else
                            FilterOut = step(obj.HFilter,In2);
                        end
                        DelayOut  = step(obj.HDelay,In1)/2;
                    else
                        % Complexity propagation in MATLAB Function block
                        FilterOut = In2;
                        DelayOut  = In1/2;
                    end
                    if fixedOutputSize
                        lenDelayOut = coder.const(inputFrameSize)/2;
                        FilterOutTemp = zeros(lenDelayOut,inputChannelSize,'like',FilterOut);
                        FilterOutTemp(:) = [obj.partialAcc;FilterOut(1:inputFrameSize/2-1,:)];
                    else                           
                        lenDelayOut = size(In1,1);
                        if ~obj.isPartialAccEmpty
                            FilterOutAppended = [obj.partialAcc;FilterOut];
                        else
                            FilterOutAppended = FilterOut;
                        end
                        lenFilterOut = size(FilterOutAppended,1);                    
                        obj.isPartialAccEmpty = lenFilterOut == lenDelayOut; 
    
                        FilterOutTemp = FilterOutAppended(1:end- ~obj.isPartialAccEmpty,:);
                    end

                    LPOutputFinal = FilterOutTemp + DelayOut(1:lenDelayOut,1:inputChannelSize);
                    if piscomplex
                        LPOutputFinal = complex(LPOutputFinal);
                    end
                    
                    if nargout == 2
                        HPOutputFinal = DelayOut(1:lenDelayOut,1:inputChannelSize) - FilterOutTemp;
                        if piscomplex
                            HPOutputFinal = complex(HPOutputFinal);
                        end
                    end
                    if ~obj.isPartialAccEmpty
                        obj.partialAcc(:) = FilterOut(end,:);
                    end
                end
            else
                % Fixed-point
                if isinteger(Input)
                    u = fi(Input, obj.pfimath, numerictype(class(Input)));
                else
                    u = setfimath(Input, obj.pfimath);
                end
                fixedOutputSize = coder.const(obj.isFixedSizeOutput());
                if fixedOutputSize % to ensure fixed size inputs for CRL for dsp.FIRFilter
                    In1 = u(1 :2:end,1:inputChannelSize);
                    In2 = u(2:2:end,1:inputChannelSize);
                else
                    In1 = u(1 + obj.isPartialAccEmpty:2:end,1:inputChannelSize);
                    In2 = u(1 + ~obj.isPartialAccEmpty:2:end,1:inputChannelSize);
                end

                if (obj.IsHalfOrderOdd)
                    if ~(isComplexityPropRunning || isSizePropRunning)
                        if ~isempty(In1)
                            FilterOut = step(obj.HFilter,In1);
                        else
                            FilterOut = fi(In1, obj.HFilter.CustomOutputDataType);
                        end
                        D         = step(obj.HDelay, In2);
                    else
                        % MATLAB Function block complexity and type prop
                        FilterOut = fi(In1, obj.HFilter.CustomOutputDataType);
                        D         = In2;
                    end
                    if isempty(D)
                        DelayOut = D;
                    else
                        DelayOut = bitsra(D,1);
                    end
                    
                    if fixedOutputSize
                        lenFilterOut = coder.const(inputFrameSize)/2;
                        DelayOutputTemp = zeros(lenFilterOut,inputChannelSize,'like',DelayOut);
                        DelayOutputTemp(:) = [obj.partialAcc;DelayOut(1:inputFrameSize/2-1,:)];
                    else                    
                        lenFilterOut = size(In1,1);
                        if obj.isPartialAccEmpty
                            DelayOutAppended = DelayOut;
                        else
                            DelayOutAppended = [obj.partialAcc;DelayOut];
                        end
                        lenDelayOut = size(DelayOutAppended,1);                    
                        obj.isPartialAccEmpty = lenFilterOut == lenDelayOut; 
    
                        DelayOutputTemp = DelayOutAppended(1:end- ~obj.isPartialAccEmpty,:); 
                    end

                    LPOutput = FilterOut(1:lenFilterOut,1:inputChannelSize) + DelayOutputTemp;
                    if nargout == 2
                        HPOutput = DelayOutputTemp - FilterOut(1:lenFilterOut,1:inputChannelSize);
                    end
                    if ~obj.isPartialAccEmpty
                        obj.partialAcc(:) = DelayOut(end,:);
                    end
                else
                    if ~(isComplexityPropRunning || isSizePropRunning)
                        if ~isempty(In2)
                            FilterOut = step(obj.HFilter,In2);
                        else
                            FilterOut = fi(In2, obj.HFilter.CustomOutputDataType);
                        end
                        D         = step(obj.HDelay, In1);
                    else
                        % MATLAB Function block complexity and type prop
                        FilterOut = fi(In2, obj.HFilter.CustomOutputDataType);
                        D         = In1;
                    end
                    if isempty(D)
                        DelayOut = D;
                    else
                        DelayOut = bitsra(D,1);
                    end
                    fixedOutputSize = coder.const(obj.isFixedSizeOutput());
                    if fixedOutputSize
                        lenDelayOut = coder.const(inputFrameSize)/2;
                        FilterOutTemp = zeros(lenDelayOut,inputChannelSize,'like',FilterOut);
                        FilterOutTemp(:) = [obj.partialAcc;FilterOut(1:inputFrameSize/2-1,:)];
                    else 
                        lenDelayOut = size(In1,1);
                        if obj.isPartialAccEmpty
                            FilterOutAppended = FilterOut;
                        else
                            FilterOutAppended = [obj.partialAcc;FilterOut];
                        end
                        lenFilterOut = size(FilterOutAppended,1);                    
                        obj.isPartialAccEmpty = lenFilterOut == lenDelayOut; 
    
                        FilterOutTemp = FilterOutAppended(1:end- ~obj.isPartialAccEmpty,:);
                    end
                    LPOutput = FilterOutTemp + DelayOut(1:lenDelayOut,1:inputChannelSize);
                    if nargout == 2
                        HPOutput = DelayOut(1:lenDelayOut,1:inputChannelSize) - FilterOutTemp;
                    end
                    if ~obj.isPartialAccEmpty
                        obj.partialAcc(:) = FilterOut(end,:);
                    end
                end
                
                % Quantization
                NTInput = numerictype(u);
                NTLPOutput = numerictype(LPOutput);
                FL = NTInput.WordLength-(NTLPOutput.WordLength-NTLPOutput.FractionLength);
                LPOutputFinal = quantize(LPOutput,1,NTInput.WordLength,FL,obj.RoundingMethod);
                if nargout == 2
                    HPOutputFinal = quantize(HPOutput,1,NTInput.WordLength,FL,obj.RoundingMethod);
                end
                LPOutputFinal = removefimath(LPOutputFinal);
                if nargout == 2
                    HPOutputFinal = removefimath(HPOutputFinal);
                end
            end

        end
        
        %------------------------------------------------------------------
        
        function resetImpl(obj)
            resetImpl@dsp.internal.FIRHalfbandBase(obj);
            obj.partialAcc = zeros(size(obj.partialAcc),'like',obj.partialAcc);
            obj.isPartialAccEmpty = false;

        end
        
        %------------------------------------------------------------------
        
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@dsp.internal.FIRHalfbandBase(obj);
            s.AllowArbitraryInputLength = obj.AllowArbitraryInputLength;
            s.isPartialAccEmpty = obj.isPartialAccEmpty;
            s.EmptyOutputFixPt = obj.EmptyOutputFixPt;
            if isLocked(obj)
                s.partialAcc = obj.partialAcc;
            end
        end
        
        %------------------------------------------------------------------
        
        function loadObjectImpl(obj, s, wasLocked)
            loadObjectImpl@dsp.internal.FIRHalfbandBase(obj,s,wasLocked);
            if wasLocked
                obj.partialAcc = s.partialAcc;
            end
            if isfield(s, 'AllowArbitraryInputLength')
                obj.AllowArbitraryInputLength = s.AllowArbitraryInputLength;
            end
            if isfield(s, 'isPartialAccEmpty')
                obj.isPartialAccEmpty = s.isPartialAccEmpty;
            end
            if isfield(s,'EmptyOutputFixPt')
                obj.EmptyOutputFixPt = s.EmptyOutputFixPt;
            end
        end
        function flag = isInactivePropertyImpl(obj, prop)            
            switch prop
                case {'SampleRateMode'}
                    flag = true;
                otherwise
                    flag = isInactivePropertyImpl@dsp.internal.FIRHalfbandBase(obj,prop);
            end
        end
        function out = supportsScalarVarsizeImpl(~)
            coder.allowpcode('plain');
            out = true;
        end
    end
    
    %----------------------------------------------------------------------
    % Hidden methods
    %----------------------------------------------------------------------
    
    methods(Hidden)
        
        function props = getNonFixedPointProperties(~)
            props = dsp.FIRHalfbandDecimator.getDisplayPropertiesImpl;
        end
        function FIRDecim = getFilter(obj)
            %GETFILTER Obtain an mfilt version of decimator for analysis
            %   FIRDecim = getFilter(obj) returns an mfilt.firdecim object
            %   that is used in filter analysis
            
            % Suppress MFILT deprecation warnings
            w = warning('off', 'dsp:mfilt:mfilt:Obsolete');
            restoreWarn = onCleanup(@() warning(w));
    
            designFilter(obj,false);
            FIRDecim = mfilt.firdecim(2,obj.Coefficients); %#ok
        end

        function [L,M] = rateConversionFactors(obj) %#ok
            nargoutchk(2,2);
            L = 1;
            M = 2;
        end
    end
    
    %----------------------------------------------------------------------
    % Static methods
    %----------------------------------------------------------------------
    methods(Static)
        function helpFixedPoint
            %helpFixedPoint Display FIRHalfbandDecimator System object
            %               fixed-point information
            %   dsp.FIRHalfbandDecimator.helpFixedPoint displays
            %   information about fixed-point properties and operations of
            %   the FIRHalfbandDecimator System object.
            
            matlab.system.dispFixptHelp('dsp.FIRHalfbandDecimator', ...
                dsp.internal.FIRHalfbandBase.getDisplayFixedPointPropertiesImpl);
        end
    end
    
    %----------------------------------------------------------------------
    % Static hidden methods
    %----------------------------------------------------------------------
    methods (Static, Hidden)
        
        function [outputWL, outputFL] = filterPrecision(w,x)
            %filterPrecision Determine filter precision settings.
            coder.extrinsic('dsp.internal.FIRFilterPrecision');
            
            % No need to take worst-case WL and FL out of each polyphase
            % branch in decimator case because the branch outputs are added
            [A] = dsp.internal.FIRFilterPrecision(w,x);
            outputWL = A.WordLength;
            outputFL = A.FractionLength;
        end
        
        function props = getDisplayPropertiesImpl()
            props = {...
                'Specification',...
                'FilterOrder', ...
                'TransitionWidth', ...
                'StopbandAttenuation', ...
                'DesignMethod',...
                'Numerator', ... 
                'NormalizedFrequency',...
                'SampleRate'};
        end
    end
    
    %----------------------------------------------------------------------
    % Static hidden protected methods
    %----------------------------------------------------------------------
    methods(Static,Hidden,Access=protected)
        function groups = getPropertyGroupsImpl
            props = dsp.FIRHalfbandDecimator.getDisplayPropertiesImpl;
            
            mainS = matlab.system.display.Section(...
                'Title', 'Parameters', ...
                'PropertyList', props);
            mainSG = matlab.system.display.SectionGroup(...
                Title = getString(message('dsp:system:Shared:Main')),...
                Sections= mainS);
            CGs = matlab.system.display.Section(...
	            Title='Parameters', ...
	            PropertyList={'AllowArbitraryInputLength'});
            cgSG = matlab.system.display.SectionGroup(...
	            Title=getString(message('dsp:system:Shared:CodegenProperties')),...
	            Sections=CGs);
            dtSG = matlab.system.display.internal.DataTypesGroup(...
                'dsp.FIRHalfbandDecimator');
            
            groups = [mainSG, cgSG, dtSG];
        end         
    end
    
end
