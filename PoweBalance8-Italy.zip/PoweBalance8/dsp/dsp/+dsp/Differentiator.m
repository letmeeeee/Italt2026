classdef (StrictDefaults)Differentiator < dsp.internal.FilterAnalysis & ...
        matlab.System
    %Differentiator Direct form FIR full band differentiator filter
    %   DF = dsp.Differentiator returns a differentiator filter, DF,
    %   which independently filters each channel of the input over time
    %   using the given design specifications.
    %
    %   DF = dsp.Differentiator('PropertyName', PropertyValue, ...)
    %   returns a differentiator filter, DF, with each specified property
    %   set to the specified value.
    %
    %   Step method syntax:
    %
    %   Y = step(DF, X) filters the real or complex input signal X using
    %   the specified filter to produce the output Y. Each column of the
    %   input signal is filtered independently over time.
    %
    %   System objects may be called directly like a function instead of
    %   using the step method. For example, y = step(obj, x) and y = obj(x)
    %   are equivalent.
    %
    %   Differentiator methods:
    %
    %   step      - See above description for use of this method
    %   getFilter - Return underlying FIR filter
    %   release   - Allow property values and input characteristics changes
    %   clone     - Create differentiator filter object with same property 
    %               values
    %   isLocked  - Locked status (logical)
    %   reset     - Reset the internal states to initial conditions
    %
    %   Differentiator properties:
    %
    %   DesignForMinimumOrder  - Option for minimum/specify order design
    %   FilterOrder            - Order of the filter
    %   PassbandRipple         - Allowed passband ripple of differentiator
    %                            filter
    %   ScaleCoefficients      - Option to scale the filter coefficients
    %
    %   This System object supports several filter analysis methods. For
    %   more information, type dsp.FIRHalfbandDecimator.helpFilterAnalysis.
    %
    %   This System object supports fixed-point operations. For more
    %   information, type dsp.Differentiator.helpFixedPoint.
    %
    %   % EXAMPLE: Convert a 50 Hz signal frequency-modulated (FM) on a 
    %   % 50 kHz carrier signal sampled at 1 MHz to an amplitude-modulated 
    %   % signal
    %
    %   % Create an FM wave
    %   Fc = 1e2; % 100 Hz carrier
    %   Fs = 1.5e3; % 1.5 kHz sample rate
    %   
    %   sinewave = dsp.SineWave('Frequency',10,...
    %                           'SamplesPerFrame',1e3,...
    %                           'SampleRate',Fs);
    %   
    %   % Convert it to AM
    %   scope = timescope('TimeSpanSource','property', ...
    %                     'TimeSpan',0.3,...
    %                     'SampleRate',Fs,...
    %                     'YLimits',[-1.5 1.5],...
    %                     'LayoutDimensions',[2 1]);
    %                 
    %   dif = dsp.Differentiator;
    %   
    %   tic
    %   while toc<5
    %       x = step(sinewave);
    %       fm_y = modulate(x,Fc,Fs,'fm');
    %       am_y = dif(fm_y);
    %       scope(fm_y,am_y);
    %   end
    %   
    %   release(dif);
    %   release(scope);
    %
    %   See also dsp.HighpassFilter, dsp.VariableBandwidthFIRFilter,
    %   dsp.VariableBandwidthIIRFilter, dsp.FIRFilter, dsp.BiquadFilter.
    
    % Copyright 2015-2020 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCA>
    
    properties (Nontunable)
        %DesignForMinimumOrder Design minimum order filter
        %   When you set this property to true, the object designs filters
        %   with the minimum order that meets the specified passband
        %   ripple. When you set this property to false, the object designs
        %   filters with order that you specify in the FilterOrder
        %   property. Specify it as a logical scalar. The default value of
        %   this property is true.
        DesignForMinimumOrder (1, 1) logical = true;
        %ScaleCoefficients Scale filter coefficients
        %   When you set this property to true, the filter coefficients
        %   will be scaled to preserve the input dynamic range. Specify it
        %   as a logical scalar. The default value of this property is
        %   false.
        ScaleCoefficients (1, 1) logical = false;
    
        %FilterOrder Filter order
        %   Specify the order for the designed filter, as a positive
        %   integer scalar. This property applies when you set the
        %   DesignForMinimumOrder property to false. The default value of
        %   this property is 31.
        FilterOrder = 31;
        %PassbandRipple Maximum passband ripple (dB)
        %   Specify the maximum allowed ripple in the passband of the
        %   filter's response, as a positive real scalar in decibels (dB).
        %   The default value of this property is 0.1 dB.
        PassbandRipple = 0.1;
        %RoundingMethod Rounding method for fixed-point operations 
        %   Specify the rounding method for output as one of ['Ceiling' |
        %   'Convergent' | 'Floor' | 'Nearest' | 'Round' | 'Simplest' |
        %   'Zero']. The default value of this property is 'Floor'.
        RoundingMethod = 'Floor';
        %CoefficientsDataType Coefficients word and fraction lengths
        %   Specify the coefficients fixed-point type as a signed
        %   numerictype object. The default value of this property is
        %   numerictype(1,16).
        %
        %   See also numerictype.
        CoefficientsDataType = numerictype(1, 16);
    end
    
    properties (Constant, Hidden)
        RoundingMethodSet = matlab.system.internal.RoundingMethodSet;
        CoefficientsDataTypeSet = matlab.system.internal.DataTypeSet(...
            { matlab.system.internal.CustomDataType( ...
            'Signedness', {'Signed'}, 'Scaling', {'Unspecified', 'BinaryPoint'})});
    end
    
    properties (Access = protected)
        NumChannels = int32(1)
        FilterObj
        IsFilterDesigned = false;
    end
    
    methods
        function obj = Differentiator(varargin)
            % Support name-value pair arguments
            setProperties(obj,nargin,varargin{:});
            obj.NumChannels = int32(-1);
        end
        
        function set.DesignForMinimumOrder(obj,flag)
            validateattributes(flag,{'logical'},{'scalar'},'');
            obj.DesignForMinimumOrder = flag;
            needToDesignFilters(obj);
        end
        
        function set.ScaleCoefficients(obj,flag)
            validateattributes(flag,{'logical'},{'scalar'},'');
            obj.ScaleCoefficients = flag;
            needToDesignFilters(obj);
        end
        
        function set.FilterOrder(obj,N)
            validateattributes(N,{'numeric'},{'finite','scalar','real',...
                'integer','positive','odd'},'');
            obj.FilterOrder = N;
            needToDesignFilters(obj);
        end              
        
        function set.PassbandRipple(obj,Apass)
            validateattributes(Apass,{'numeric'},{'finite','scalar','real',...
                'positive','<=',10},'');
            obj.PassbandRipple = Apass;
            needToDesignFilters(obj);
        end
        
        function set.RoundingMethod(obj,val)
            obj.RoundingMethod = val;
            needToDesignFilters(obj)
        end
        
        function set.CoefficientsDataType(obj, val)
            obj.CoefficientsDataType = val;
            needToDesignFilters(obj)
        end
        
        function F = getFilter(obj)
            %F = getFilter(obj) get underlying FIR filter
            %   F = getFilter(obj) returns the underlying filter F
            %   used to implement the filter designed for the given
            %   specifications.
            if ~obj.IsFilterDesigned
                designFilter(obj);
                obj.IsFilterDesigned = true;
            end
            F = clone(obj.FilterObj);
        end
    end
    
    %----------------------------------------------------------------------
    methods (Access = protected)
        
        function setupImpl(obj,u)
            if ~isfloat(u)
                % Always design filters if setup is called with fixed-point
                % input. This is because getFilter method may have designed
                % filter with a default input data type for fixed-point
                % filter analysis.
                needToDesignFilters(obj);
            end
            
            designFilter(obj,u);
            
            if obj.getExecPlatformIndex()
                thisSize = propagatedInputSize(obj, 1);
                obj.NumChannels = int32(thisSize(2));
            else
                obj.NumChannels = int32(size(u,2));
            end
            
        end
        
        function y = stepImpl(obj,u)
            % Implement algorithm. Calculate y as a function of
            % input u and discrete states.
            y = step(obj.FilterObj,u);
        end
        
        function resetImpl(obj)
            reset(obj.FilterObj);
        end
        
        function releaseImpl(obj)
            % Release the filter
            release(obj.FilterObj);
            obj.NumChannels = int32(-1);
        end
        
        function flag = isInputSizeMutableImpl(~,~)
            % Support mutable input size
            flag = true;
        end  

        function validateInputsImpl(obj,u)
            % input cannot be unsigned complex fixed-point
            validateattributes(u, {'numeric','embedded.fi'},...
                {},'','Input');
            
            if isfi(u)
                coder.internal.errorIf(~issigned(u) && ~isreal(u), ...
                    'dsp:system:CICCompensationInterpolator:inputUnsignedComplexFixedPoint');
            end
            
            % Cache input data type for filter analysis
            if isempty(coder.target)
                if ~isempty(u)
                    cacheInputDataType(obj,u)
                end
            end
            
            if obj.NumChannels ~= int32(-1)
                coder.internal.errorIf(...
                    (int32(size(u,2)) ~= obj.NumChannels), ...
                    'dsp:system:Shared:numChannels');
            end
        end
        
        function s = saveObjectImpl(obj)
            % Save public properties
            s = saveObjectImpl@matlab.System(obj);
            % Private properties
            s.FilterObj = matlab.System.saveObject(obj.FilterObj);
            s.IsFilterDesigned = obj.IsFilterDesigned;
             if isLocked(obj)
                % All the following are set at setup                                 
                s.NumChannels = obj.NumChannels;
            end
            s = saveFA(obj, s);   % Save filter analysis class properties
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            if isfield(s, 'CoefficientsDataType')
                % backwards compatibility for objects saved before R2015b
                if strcmp(s.CoefficientsDataType.Signedness, 'Auto')
                    s.CoefficientsDataType.Signedness = 'Signed';
                end
            end
             if wasLocked
                % All the following were set at setup                
                obj.NumChannels = s.NumChannels;
            end
            % Private properties
            obj.FilterObj = matlab.System.loadObject(s.FilterObj);
            
            obj.IsFilterDesigned = s.IsFilterDesigned;
            
            % Call base class method
            loadObjectImpl@matlab.System(obj, s, wasLocked);
            
            % Load filter analysis class properties
            loadFA(obj, s, wasLocked); 
        end
        
        function needToDesignFilters(obj)
            obj.IsFilterDesigned = false;
        end
        
        function flag = isInactivePropertyImpl(obj, prop)
            minord = obj.DesignForMinimumOrder;
            flag = false;
            
            switch prop
                case {'FilterOrder'}
                    if minord
                        flag = true;
                    end                
                case {'PassbandRipple'}
                    if ~minord
                        flag = true;
                    end            
            end
        end
        
        function d = convertToDFILT(obj,arith)
            % Convert the System object to a dfilt object for analysis
            sysObj = getFilter(obj);
            if strcmp(arith,'fixed') && ~isLocked(sysObj)
                
                sysObj.CoefficientsDataType = 'custom';
                cT = obj.CoefficientsDataType;
                if strcmpi(cT.DataTypeMode,'Fixed-point: unspecified scaling')
                    sysObj.CustomCoefficientsDataType = numerictype(true,cT.WordLength);
                elseif strcmpi(cT.DataTypeMode,'Fixed-point: binary point scaling')
                    sysObj.CustomCoefficientsDataType = numerictype(true,cT.WordLength,cT.FractionLength);
                end
                
            end
            d = todfilt(sysObj,arith);
        end
        
        function [w, scaleVal] = computeFIRCoefficients(obj,varargin)
            % For strict single precision code generation, etc.
            if (nargin > 1) && isa(varargin{1}, 'single')
                u = single(0);
            else
                u = double(0);
            end
            
            if obj.DesignForMinimumOrder
                Ap = coder.const(obj.PassbandRipple);
                Rp = coder.const((10.^(Ap./20) - 1) ./ (10.^(Ap./20) + 1));
                bd = coder.const(firgr({'minodd',51},[0 1],[0 pi],Rp,'differentiator'));
            else
                N  = coder.const(obj.FilterOrder);
                bd = coder.const(firpm(N,[0 1],[0 pi],'differentiator'));
            end
            
            % Scale the coefficients if ScaleCoefficients is set to true
            if obj.ScaleCoefficients
                scaleVal = sum(abs(cast(bd, 'like', u)));
                w = cast( (bd ./ scaleVal), 'like', u );
            else
                scaleVal = cast( 1, 'like', u);
                w        = cast(bd, 'like', u);
            end
        end
        
        function designFilter(obj,u)
            % Design and construct the filter System object
            
            if isempty(coder.target)
                if obj.IsFilterDesigned
                    % This helps avoid duplicate construction of filters when
                    % setup() is called after getFilters().
                    % For codegen, this property is always false.
                    return
                end
            end
            
            coder.extrinsic('dsp.Differentiator.firPrecision');
            
            if isempty(coder.target)
                [b, scaleVal] = computeFIRCoefficients(obj);
            elseif (nargin > 1) && isa(u,'single')
                b = computeFIRCoefficients(obj, u);
            else
                b = computeFIRCoefficients(obj);
            end
            
            if (nargin > 1) && ~isfloat(u)
                % Fixed-point (or integer) input
                w = fi(b, obj.CoefficientsDataType); % fi filter weights
                    
                % compute output data type
                if isinteger(u)
                    x = numerictype(class(u));
                else
                    x = numerictype(u);
                end
                
                [~,~,outputWL, outputFL] = ...
                    coder.const(@dsp.Differentiator.firPrecision, w, x);
                
                FIR = dsp.FIRFilter('Numerator', b, ...
                            'CoefficientsDataType', 'Custom', ...
                            'CustomCoefficientsDataType', ...
                            numerictype(true, w.WordLength, w.FractionLength), ...
                            'FullPrecisionOverride', false, ...
                            'OutputDataType', 'Custom', ...
                            'CustomOutputDataType', ...
                            numerictype(true, outputWL, outputFL), ...
                            'RoundingMethod', obj.RoundingMethod);
            else
                FIR = dsp.FIRFilter('Numerator', b);
            end
            
            obj.FilterObj = FIR;
            
            if isempty(coder.target)
                % Set metadata for FVTool
                if obj.DesignForMinimumOrder
                    Ap   = obj.PassbandRipple;
                    fdes = fdesign.differentiator('Ap',Ap);                    
                    fmet = fdfmethod.eqripdiffmin;
                else
                    N    = obj.FilterOrder;
                    fdes = fdesign.differentiator('N',N);
                    fmet = fdfmethod.eqripdiffminmb;
                end
                
                if obj.ScaleCoefficients
                    fdes.MaskScalingFactor = scaleVal;
                end
                
                setMetaData(obj, ...
                    fdes, fmet, ...
                    [], 'equiripple');
                
                obj.IsFilterDesigned = true;
            end            
        end        
    end
    
    %---------------------------------------------------------------------
    methods (Static)
         function helpFixedPoint
            %helpFixedPoint Display Differentiator System
            %               object fixed-point information
            %   dsp.Differentiator.helpFixedPoint displays
            %   information about fixed-point properties and operations of
            %   the Differentiator System object.
            
            matlab.system.dispFixptHelp('dsp.Differentiator', ...
                dsp.Differentiator.getDisplayFixedPointPropertiesImpl);
         end
    end
    
    %---------------------------------------------------------------------
    methods (Hidden)
        function flag = isPropertyActive(obj,prop)
            % Need to implement this for dsp.internal.FilterAnalysisMultirate
            flag = ~isInactivePropertyImpl(obj, prop);
        end
        
        function props = getFixedPointProperties(~)
            % Need to implement this for dsp.internal.FilterAnalysisMultirate
            props = dsp.Differentiator.getDisplayFixedPointPropertiesImpl;
        end
        
        function restrictionsCell = getFixedPointRestrictions(obj,prop)
            % Need to implement this for dsp.internal.FilterAnalysisMultirate
            switch prop
                case {'CoefficientsDataType'}
                    restrictionsCell = {};
                otherwise
                    error(message(...
                        'dsp:dsp:private:FilterSystemObjectBase:InvalidProperty',prop,class(obj)))
            end
        end
        
        function props = getNonFixedPointProperties(~)
            props = dsp.Differentiator.getDisplayPropertiesImpl;
        end

    end
    
    %---------------------------------------------------------------------
    methods (Static,Hidden)
        
        function props = getDisplayPropertiesImpl()
             props = {...
                'DesignForMinimumOrder', ...
                'FilterOrder', ...
                'PassbandRipple',...
                'ScaleCoefficients'};
        end
        
        function props = getDisplayFixedPointPropertiesImpl()
            % Need to implement this for dsp.internal.FilterAnalysisMultirate
            props = {...
                'RoundingMethod','CoefficientsDataType'};
        end
        
        function [accWL,accFL,outputWL, outputFL] = firPrecision(w,u)
            %filterPrecision Determine filter precision settings.
            
            [A,Q] = dsp.internal.FIRFilterPrecision(w,u);
            accWL = A.WordLength;
            if accWL == 1
                % FIR does not support wordlength less than 2
                accWL = 2;
            end
            accFL = A.FractionLength;
            
            outputWL = Q.WordLength;
            outputFL = Q.FractionLength;
        end
  
    end
    
    %----------------------------------------------------------------------
    methods(Static,Access=protected)
        function groups = getPropertyGroupsImpl
            props = dsp.Differentiator.getDisplayPropertiesImpl;
            
            mainS = matlab.system.display.Section('Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', props);
            mainSG = matlab.system.display.SectionGroup('TitleSource', 'Auto', ...
                'Sections', mainS);

            dtSG = matlab.system.display.internal.DataTypesGroup(...
                'dsp.Differentiator');
            dtSG.PropertyList{2} = matlab.system.display.internal.DataTypeProperty('CoefficientsDataType', ...
                'Prefix', 'coeffs', ...
                'Description', getString(message('dsp:system:Shared:Coefficients')));
            groups = [mainSG, dtSG];
        end       
        
    end

end
