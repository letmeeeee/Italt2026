classdef FIRHalfbandInterpolator< dsp.internal.FIRHalfbandBase
%FIRHalfbandInterpolator Interpolate by a factor of two using polyphase FIR
%   This System object interpolates an input signal using a two branch
%   polyphase structure optimized for halfband filters. All the even
%   indexed samples of halfband filters are zero except the sample at the
%   origin. This System object takes advantage of the zero coefficients,
%   thereby making the second branch of the polyphase structure a delay.
%   With very minimal extra work, this System object can be converted to a
%   Synthesis Filter bank. Filter design is done using optimum equiripple
%   filter design method.
%
%   FIRHALFBANDINTERP = dsp.FIRHalfbandInterpolator returns a FIR halfband
%   interpolator System object, FIRHALFBANDINTERP, that interpolates a
%   signal by a factor 2 using polyphase structure optimized for halfband
%   filters. The filter design parameters are 'TransitionWidth' and
%   'StopbandAttenuation' and the design ensures a minimum order optimum
%   equiripple filter.
%
%   FIRHALFBANDINTERP = dsp.FIRHalfbandInterpolator(Name=Value, ...)
%   returns a FIR Halfband interpolator System object, FIRHALFBANDINTERP,
%   with each specified property set to the specified value.
%
%   Step method syntax:
%
%   Y = step(FIRHALFBANDINTERP,X) outputs the interpolated values, Y, of
%   the input signal, X. A KixN input matrix is treated as N independent
%   channels, and the System object interpolates each channel over time and
%   generates a KoxN output matrix. Ko = 2*Ki, where 2 is the interpolation
%   factor. The object supports real and complex floating-point and
%   fixed-point inputs.
%
%   Y = step(FIRHALFBANDINTERP,X1,X2) computes the output, Y of the
%   Synthesis Filter bank, FIRHALFBANDINTERP. FIRHALFBANDINTERP acts as a
%   Synthesis Filter bank when 'FilterBankInputPort' property of the System
%   object is true. X1 and X2 are two input matrices of same data type and
%   size KixN. N is the number of independent channels in each input
%   signal. System object generates a high pass signal and a low pass
%   signal by subtracting and adding the two baseband input signals
%   respectively, and sends the generated signals through the two branches
%   of the polyphase structure. The output signals from the two branches
%   are commuted to form the resultant signal, Y, a KoxN matrix. Ko = 2*Ki,
%   where 2 is the interpolation factor.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   FIRHalfbandInterpolator methods:
%   step     - See above description for use of this method
%   release  - Allow property value and input characteristics changes
%   clone    - Create FIR Halfband interpolator object with same
%              property values
%   isLocked - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>    - Reset the internal states to initial conditions
%
%   FIRHalfbandInterpolator properties:
%
%   SampleRate            - Input sample rate.
%   Specification         - Filter design parameter specification.
%   FilterBankInputPort   - Specify System object to be a Filter bank.
%   FilterOrder           - Order of the filter.
%   StopbandAttenuation   - Minimum attenuation needed in stopband of
%                           the FIR halfband filter.
%   TransitionWidth       - Transition width of the filter in FIR
%                           halfband interpolator.
%   Numerator             - Specified FIR Halfband Coefficients,
%                           when Specification is 'Coefficients'.
%   DesignMethod          - Filter design method, specified as 'Auto',
%                           'Equiripple' or 'Kaiser'.  
%   NormalizedFrequency   - Provide normalized frequencies for filter
%                           specifications
%
%   This System object supports several filter analysis methods. For more
%   information, type dsp.FIRHalfbandInterpolator.helpFilterAnalysis.
%
%   This System object supports fixed-point operations. For more
%   information, type dsp.FIRHalfbandInterpolator.helpFixedPoint.
%
%   % Example 1: Interpolate an input signal by 2
%   Fs1 = 8000;     % Units = Hz
%   TW = 4.1e2;     % Units = Hz
%   order = 52;
%
%   % Construct FIR Half band Interpolator
%   firinterp = dsp.FIRHalfbandInterpolator(...
%       Specification="Filter order and transition width",...
%       FilterOrder=order,...
%       TransitionWidth=TW,...
%       SampleRate=Fs1,...
%       DesignMethod="Equiripple");
%
%   % Visualize its Impulse response
%   fvtool(firinterp,Analysis="Impulse");
%   % Plot the Magnitude and Phase response
%   fvtool(firinterp,Analysis="freq")
%
%   % Interpolated output of a white noise signal
%   x = randn(1024,2);
%   y = firinterp(x);
%   release(firinterp);
%
%   % Example 2: Implement a Quadrature Mirror Filter
%   Fs1 = 8000;     % Units = Hz
%   TW = 4.1e2;     % Units = Hz
%   order = 52;
%
%   % Construct FIR Halfband Interpolator
%   firinterp = dsp.FIRHalfbandInterpolator(...
%       Specification="Filter order and transition width",...
%       FilterOrder=order,...
%       TransitionWidth=TW,...
%       SampleRate=Fs1,...
%       FilterBankInputPort=true);
%
%   % Construct FIR Halfband Decimator
%   firdecim = dsp.FIRHalfbandDecimator(...
%       Specification="Filter order and transition width",...
%       FilterOrder=order,...
%       TransitionWidth=TW,...
%       SampleRate=Fs1);
%
%   % Input
%   f1 = 1000;
%   f2 = 3000;
%   sine = dsp.SineWave(Frequency=[f1,f2],SampleRate=Fs1,...
%   	SamplesPerFrame=1024);
%
%   % Construct Spectrum Analyzer object to view the input and output
%   scope = spectrumAnalyzer(SampleRate=Fs1,...
%       PlotAsTwoSidedSpectrum=false,ShowLegend=true,...
%       YLimits=[-120 30],...
%       Title="Input Signal and Output Signal of Quadrature Mirror Filter", ...
%       ChannelNames=["Input","Output"]);
%
%   % Stream processing loop
%   for k = 1:100
%       input = sum(sine(),2);
%       noisyInput = input + (10^-5)*randn(1024,1);
%       [lowpass, highpass] = firdecim(noisyInput);
%       output = firinterp(lowpass,highpass);
%       scope([noisyInput,output]);
%   end
%
%   See also dsp.FIRHalfbandDecimator, dsp.FIRInterpolator,
%            designHalfbandFIR, 
%            dsp.FIRHalfbandInterpolator.helpFilterAnalysis.

 
%   Copyright 2014-2023 The MathWorks, Inc.

    methods
        function out=FIRHalfbandInterpolator
            % Support name-value pair arguments
        end

        function out=crossValidateProperties(~) %#ok<STOUT>
        end

        function out=designObjects(~) %#ok<STOUT>
            % Remove the zero coefficients
        end

        function out=getNumInputsImpl(~) %#ok<STOUT>
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
        end

        function out=helpFixedPoint(~) %#ok<STOUT>
            %helpFixedPoint Display FIRHalfbandInterpolator System object
            %               fixed-point information
            %   dsp.FIRHalfbandInterpolator.helpFixedPoint displays
            %   information about fixed-point properties and operations of
            %   the FIRHalfbandInterpolator System object.
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=realizemdl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
            %Defining the System objects
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

        function out=validatePropertiesImpl(~) %#ok<STOUT>
        end

    end
    properties
        %FilterBankInputPort Input highpass subband
        %   Specify if the filter should be a Synthesis Filter bank, as a
        %   logical scalar. When this property is set to false, the object
        %   acts as an interpolator. If the property is set to true,
        %   the object acts as a Synthesis Filter bank.
        %   The default of this property is false.
        FilterBankInputPort;

        % Numerator Numerator
        %   Specify the FIR Halfband Coefficients. The default value of
        %   this property is designHalfbandFIR(TransitionWidth=0.186, ...
        %   StopbandAttenuation=80, Structure='interp'). This property 
        %   applies when you set Specification to 'Coefficients'.
        Numerator;

        %TransitionWidth Transition width
        %   Specify the transition width for the designed FIR halfband
        %   filter as a finite positive scalar which is less than half the
        %   input sample rate. Specify the value of transition width in
        %   Hertz when NormalizedFrequency is set to false and in
        %   normalized units when NormalizedFrequency is set to true.This
        %   property applies when the Specification is either 'Filter order
        %   and transition width' | 'Transition width and stopband
        %   attenuation'. The default value of this property is 4100Hz.
        TransitionWidth;

    end
end
