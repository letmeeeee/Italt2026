classdef CoupledAllpassFilter< matlab.System & dsp.internal.FilterAnalysis
%CoupledAllpassFilter Coupled allpass IIR filter
%    
%   CAF = dsp.CoupledAllpassFilter returns a coupled allpass filter System
%   object(TM), CAF, that filters each channel of the input signal
%   independently. This filtering process uses a coupled allpass filter
%   with the default inner structures and coefficients.
%
%   CAF = dsp.CoupledAllpassFilter('PropertyName', PropertyValue, ...)
%   returns a coupled allpass filter System object, CAF, with each
%   specified property set to the specified value.
%
%   CAF = dsp.CoupledAllpassFilter(AllpassCoefficients1,
%   AllpassCoefficient2) returns a coupled allpass filter System object,
%   CAF, with 'Structure' set to 'Minimum multiplier'. The allpass
%   coefficients for each of the two branches are set to each of the two
%   specified values, respectively.
%
%   CAF = dsp.CoupledAllpassFilter(Structure, Coefficients1, Coefficient2) 
%   returns a coupled allpass filter System object, CAF, with
%   'Structure' set to the specified value (choice of 'Minimum multiplier',
%   'Wave Digital Filter' or 'Lattice'). The coefficients relevant to the
%   specified structure are set to the values provided.
%
%   Step method syntax:
%
%   Y = step(CAF, X) filters the real or complex input signal X using the
%   specified filter to produce the output Y. Each column of X is treated 
%   and filtered independently as a separate channel over time.
%
%   [Y, YPC] = step(CAF, X) Also returns YPC, the power-complementary
%   signal to primary output Y.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   CoupledAllpassFilter methods:
%
%   step                - See preceding description for use of this method
%   release             - Allow changes to non-tunable properties' values
%                         and input characteristics
%   clone               - Create a coupled allpass filter object
%                         with the same property values and internal
%                         states
%   isLocked            - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>               - Reset the internal states to zero
%   getBranches         - Return a structure with a copy of the two
%                         internal allpass filter branches
%
%   CoupledAllpassFilter properties:
%
%   Structure               - Structural realization of both internal
%                             allpass filter branches
%   AllpassCoefficients1    - Coefficients used for first branch when
%                             Structure is set to 'Minimum multiplier'
%   WDFCoefficients1        - Coefficients used for first branch when
%                             Structure is set to 'Wave Digital Filter'
%   LatticeCoefficients1    - Coefficients used for first branch when
%                             Structure is set to 'Lattice'
%   Delay                   - Delay length for first branch when
%                             PureDelayBranch is set to true
%   Gain1                   - Phase gain for first branch
%   AllpassCoefficients2    - Coefficients used for second branch when
%                             Structure is set to 'Minimum multiplier'
%   WDFCoefficients2        - Coefficients used for second branch when                          
%                             Structure is set to 'Wave Digital Filter'
%   LatticeCoefficients2    - Coefficients used for second branch when
%                             Structure is set to 'Lattice'
%   Gain2                   - Phase gain for second branch
%   Beta                    - Coupled phase gain
%   PureDelayBranch         - Replaces allpass filter in first branch with
%                             pure delay
%   ComplexConjugateCoefficients    - Enables providing complex
%                             coefficients for only the first branch. The
%                             coefficients for the second branch are
%                             automatically inferred as complex conjugate 
%                             values of the first branch coefficients
%
%   This System object supports several filter analysis methods. For more
%   information, type dsp.CoupledAllpassFilter.helpFilterAnalysis.
%
%   % EXAMPLE: Realize a Butterworth lowpass filter of order 3 using
%   % a coupled allpass structure with inner minimum multiplier structure
%   
%   Fs = 48000;    % in Hz
%   Fc = 12000;    % in Hz
%   frameLength = 1024;
%   [b, a] = butter(3,2*Fc/Fs);
%   expected = [freqz(b,a,frameLength/2); NaN];
%   [c1, c2] = tf2ca(b,a);
%   cafilt = dsp.CoupledAllpassFilter(c1(2:end),c2(2:end));
%   tfestim = dsp.TransferFunctionEstimator('FrequencyRange', 'onesided',...
%       'SpectralAverages', 2);
%   scope = dsp.ArrayPlot('PlotType', 'Line',...
%       'YLimits', [-40 5],...
%       'YLabel', 'Magnitude (dB)',...
%       'SampleIncrement', Fs/frameLength,...
%       'XLabel', 'Frequency (Hz)',...
%       'Title', 'Magnitude Response, Actual (1) and Expected (2)',...
%       'ShowLegend', true);
%   Niter = 200;
%   for k = 1:Niter
%       in = randn(frameLength,1);
%       out = cafilt(in);
%       actual = tfestim(in,out);
%       scope(db([actual,expected]));
%   end
%
%   See also dsp.AllpassFilter, dsp.BiquadFilter, dsp.IIRFilter,
%            dsp.ArrayPlot, dsp.TransferFunctionEstimator,
%            designHalfbandIIR

 
%   Copyright 2012-2023 The MathWorks, Inc.

    methods
        function out=CoupledAllpassFilter
            % Accepts name-value pair arguments, as well as two different
            % syntaxes for value-only arguments.
        end

        function out=convertToDFILT(~) %#ok<STOUT>
            % Returns equivalent dfilt to current object.
        end

        function out=getActiveCoeffsInBranch(~) %#ok<STOUT>
        end

        function out=getBranches(~) %#ok<STOUT>
            %getBranches Return internal allpass branches
            %   Return copies of the internal allpass branches, as a
            %   two-field structure. Each branch is an instance of
            %   dsp.AllpassFilter
        end

        function out=getDiscreteStateImpl(~) %#ok<STOUT>
        end

        function out=getNumOutputsImpl(~) %#ok<STOUT>
        end

        function out=infoImpl(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=isSecondBranchInferred(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Re-load state if saved version was locked
        end

        function out=parseArithmetic(~) %#ok<STOUT>
            % This overrides the same method of dsp.internal.FilterAnalysis
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
            % Propagate coefficients changes to child objects
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Default implementation saves all public properties
        end

        function out=setActiveCoefficientsForBranch(~) %#ok<STOUT>
        end

        function out=setDiscreteStateImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Enables structural optimization if coefficients are complex
            % conjugate of each other and input signal is real
            % ... And setup relevant branches accordingly
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=supportsComplexCoefficients(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            % Invoked at first call to setup/step, and then every time the
            % input dimensions change
        end

    end
    properties
        %AllpassCoefficients1 Allpass polynomial coefficients of branch 1
        %   Specify the polynomial filter coefficients for the first
        %   allpass branch. 
        %   This property is only applicable when the Structure property is
        %   set to 'Minimum multiplier'. The value of this property can 
        %   be either a row vector (single-section configuration) or a cell
        %   array with as many cells as filter sections. The default value 
        %   for this property is {[0 0.5]}. This property is tunable.
        AllpassCoefficients1;

        %AllpassCoefficients2 Allpass polynomial coefficients of branch 2
        %   Specify the polynomial filter coefficients for the second
        %   allpass branch. 
        %   This property is only applicable when the Structure property is
        %   set to 'Minimum multiplier'. The value of this property can 
        %   be either a row vector (single-section configuration) or a cell
        %   array with as many cells as filter sections. The default value 
        %   for this property is {[]}. This property is tunable.
        AllpassCoefficients2;

        %Beta Coupled phase gain
        %   Specify the value of the phasor gain used in complex conjugate
        %   forms in each of the two branches, respectively, in complex 
        %   coefficient configurations.
        %   This property is only applicable when the selected Structure 
        %   property supports complex coefficients.
        %   The absolute value of this property should be 1 and its
        %   default value is 1. This property is tunable.
        Beta;

        % ComplexConjugateCoefficients Allows inferring the coefficients
        %   of the second allpass branch as complex conjugate of the first.
        %   When the input signal is real this triggers the use of an
        %   optimized structural realization. This property is only enabled
        %   if the currently selected structure supports complex
        %   coefficients, and it should only be used the filter
        %   coefficients are actually complex.
        ComplexConjugateCoefficients;

        %Delay Delay length in samples for branch 1
        %   Specify the delay length in number of samples for branch 1,
        %   when the latter operates as a pure delay.
        %   This property is only applicable when the PureDelayBranch
        %   property is set to true. This property is tunable.
        Delay;

        %Gain1 Independent Branch 1 Phase Gain
        %   Specify the value of the independent phase gain applied to
        %   branch 1. This property can only accept values equal to '1' |
        %   '-1' | '0+1i' | '0-1i'. The default value for this property is
        %   '1'. This property is nontunable.
        Gain1;

        %Gain2 Independent Branch 2 Phase Gain
        %   Specify the value of the independent phase gain applied to
        %   branch 2. 
        %   This property can only accept values equal to '1' | '-1' |
        %   '0+1i' | '0-1i'. The default value for this property is '1'.
        %   This property is nontunable.
        Gain2;

        %LatticeCoefficients1 Lattice coefficients of branch 1
        %   Specify the allpass lattice coefficients for the first
        %   allpass branch. 
        %   This property is only applicable when the Structure property is
        %   set to 'Lattice'. The value of this property can 
        %   be either a row vector (single-section configuration) or a cell
        %   array with as many cells as filter sections. The default value 
        %   for this property is {[0.5 0]}. This property is tunable.
        LatticeCoefficients1;

        %LatticeCoefficients2 Lattice coefficients of branch 2
        %   Specify the allpass lattice coefficients for the second
        %   allpass branch. 
        %   This property is only applicable when the Structure property is
        %   set to 'Lattice'. The value of this property can 
        %   be either a row vector (single-section configuration) or a cell
        %   array with as many cells as filter sections. The default value 
        %   for this property is {[]}. This property is tunable.
        LatticeCoefficients2;

        % PureDelayBranch Replaces the allpass filter in the first branch
        %   with a pure delay. When PureDelayBranch is set to true, the
        %   property holding the coefficients for the first allpass branch
        %   is disabled and Delay becomes enabled.
        %   This property should be used for better performance, when one
        %   of the two allpass branches is known to be a pure delay (e.g.
        %   for halfband filter designs)
        PureDelayBranch;

        %Structure Internal structure of allpass branches
        %   Specify the internal structure of allpass branches as
        %   one of 'Minimum multiplier' | 'Wave Digital Filter' |
        %   'Lattice'. Each structure uses a different pair of 
        %   coefficient values, independently stored in the relevant 
        %   object property. The default is 'Minimum multiplier'.
        Structure;

        %WDFCoefficients1 Wave Digital Filter coefficients of branch 1
        %   Specify the Wave Digital Filter coefficients for the first
        %   allpass branch. 
        %   This property is only applicable when the Structure property is
        %   set to 'Wave Digital Filter'. The value of this property can 
        %   be either a row vector (single-section configuration) or a cell
        %   array with as many cells as filter sections. The default value 
        %   for this property is {[0.5 0]}. This property is tunable.
        WDFCoefficients1;

        %WDFCoefficients2 Wave Digital Filter coefficients of branch 2
        %   Specify the Wave Digital Filter coefficients for the second
        %   allpass branch. 
        %   This property is only applicable when the Structure property is
        %   set to 'Wave Digital Filter'. The value of this property can 
        %   be either a row vector (single-section configuration) or a cell
        %   array with as many cells as filter sections. The default value 
        %   for this property is {[]}. This property is tunable.
        WDFCoefficients2;

    end
end
