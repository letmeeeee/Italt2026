classdef HighpassFilter< dsp.internal.LPHPFilterBase
%HighpassFilter FIR or IIR highpass filter
%   HPF = dsp.HighpassFilter returns a highpass filter, HPF, which
%   independently filters each channel of the input over time using the
%   given design specifications.
%
%   HPF = dsp.HighpassFilter('PropertyName', PropertyValue, ...)
%   returns a highpass filter, HPF, with each specified property set to
%   the specified value.
%
%   Step method syntax:
%
%   Y = step(HPF, X) filters the real or complex input signal X using
%   the specified filter to produce the output Y. Each column of the
%   input signal is filtered independently over time.
%
%   System objects may be called directly like a function instead of
%   using the step method. For example, y = step(obj, x) and y = obj(x)
%   are equivalent.
%
%   HighpassFilter methods:
%
%   step      - See above description for use of this method
%   getFilter - Return underlying FIR or Biquad filter
%   release   - Allow property value and input characteristics changes
%   clone     - Create highpass filter object with same property values
%   isLocked  - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>     - Reset the internal states to initial conditions
% generatehdl - Generate HDL code. (Filter Design HDL Coder Required)
%
%   HighpassFilter properties:
%
%   SampleRate             - Sample rate of input in Hz
%   FilterType             - FIR or IIR (Biquad)
%   DesignForMinimumOrder  - Option for minimum/specify order design
%   FilterOrder            - Order of the filter
%   NormalizedFrequency    - Provide normalized frequencies for filter specifications
%   PassbandFrequency      - Passband frequency of highpass filter
%   StopbandFrequency      - Stopband frequency of highpass filter
%   PassbandRipple         - Allowed passband ripple of highpass filter
%   StopbandAttenuation    - Minimum stopband attenuation of the filter
%
%   This System object supports several filter analysis methods. For
%   more information, type dsp.HighpassFilter.helpFilterAnalysis.
%
%   This System object supports fixed-point operations. For more
%   information, type dsp.HighpassFilter.helpFixedPoint.
%
%   % EXAMPLE: Design an equiripple highpass FIR filter. Filter white
%   % Gaussian noise with the resulting filter and estimate the
%   % transfer function.
%   % Initialize
%   Fs = 96e3;
%   HPF = dsp.HighpassFilter(SampleRate=Fs,PassbandFrequency=12e3);
%   TFE = dsp.TransferFunctionEstimator(FrequencyRange='onesided',...
%           SpectralAverages=50);
%   AP = dsp.ArrayPlot(PlotType='Line',YLimits=[-100 5],...
%           YLabel='Magnitude (dB)',XLabel='Frequency (Hz)',...
%           SampleIncrement=Fs/1024,ShowLegend=true,...
%           Title='Magnitude Response; Exact (Ch 1), Estimate (Ch 2)');
%   Htrue = freqz(HPF,513); % Compute exact transfer function
%   % Stream processing loop
%   Niter = 1000;
%   for k = 1:Niter
%       x = randn(1024,1);  % Input signal = white Gaussian noise
%       y = HPF(x);   % Filter noise with FIR filter
%       H = TFE(x,y); % Compute transfer function estimate
%       AP(20*log10(abs([Htrue,H]))); % Plot estimate
%   end
%  % EXAMPLE 2: Design an equiripple highpass FIR filter with passband
%  % and stopband edges at 0.65 and 0.5 rad/sample respectively. Filter
%  % white Gaussian noise with the resulting filter and estimate the
%  % transfer function.
%   HPF = dsp.HighpassFilter(NormalizedFrequency=true,PassbandFrequency=0.65, StopbandFrequency=0.5);
%   TFE = dsp.TransferFunctionEstimator(FrequencyRange='onesided',...
%           SpectralAverages=50);
%   AP = dsp.ArrayPlot(PlotType='Line',YLimits=[-100 5],...
%           YLabel='Magnitude (dB)',XLabel='Normalized Frequency (\times\pi rad/sample)',...
%           SampleIncrement=2/1024,ShowLegend=true,...
%           Title='Magnitude Response; Exact (Ch 1), Estimate (Ch 2)');
%   Htrue = freqz(HPF,513); % Compute exact transfer function
%   % Stream processing loop
%   Niter = 1000;
%   for k = 1:Niter
%       x = randn(1024,1);  % Input signal = white Gaussian noise
%       y = HPF(x);   % Filter noise with FIR filter
%       H = TFE(x,y); % Compute transfer function estimate
%       AP(20*log10(abs([Htrue,H]))); % Plot estimate
%   end
%
%   See also dsp.HighpassFilter, dsp.VariableBandwidthFIRFilter,
%   dsp.VariableBandwidthIIRFilter, dsp.FIRFilter, dsp.BiquadFilter.

     
    % Copyright 2014-2022 The MathWorks, Inc.

    methods
        function out=HighpassFilter
            % Support name-value pair arguments
        end

        function out=computeFIRCoefficients(~) %#ok<STOUT>
        end

        function out=crossValidateProperties(~) %#ok<STOUT>
        end

        function out=designFilter(~) %#ok<STOUT>
            % Create filter System objects
        end

        function out=helpFixedPoint(~) %#ok<STOUT>
            %helpFixedPoint Display HighpassFilter System
            %               object fixed-point information
            %   dsp.HighpassFilter.helpFixedPoint displays
            %   information about fixed-point properties and operations of
            %   the HighpassFilter System object.
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=outputDelayDefaultNormalizedFc(~) %#ok<STOUT>
            % Return the (normalized) frequency for which group delay is evaluated in
            % outputDelay.
        end

        function out=validatePropertiesImpl(~) %#ok<STOUT>
        end

    end
    properties
        %PassbandFrequency  Passband edge frequency
        %   Specify the passband edge frequency of the filter as a positive
        %   real scalar smaller than half the sample rate. Specify the
        %   value of passband edge frequency in Hertz when
        %   NormalizedFrequency is set to false and in normalized units
        %   when NormalizedFrequency is set to true. The default value of
        %   this property is 12 kHz.
        PassbandFrequency;

        %StopbandFrequency  Stopband edge frequency
        %   Specify the stopband edge frequency of the filter as a positive
        %   real scalar smaller than half the sample rate. This property
        %   applies when you set the DesignForMinimumOrder property to
        %   true. Specify the value of stopband edge frequency in Hertz
        %   when NormalizedFrequency is set to false and in normalized
        %   units when NormalizedFrequency is set to true. The default
        %   value of this property is 8 kHz.
        StopbandFrequency;

    end
end
