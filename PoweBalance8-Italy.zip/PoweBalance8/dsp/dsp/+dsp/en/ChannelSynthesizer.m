classdef ChannelSynthesizer< dsp.internal.PolyphaseFFTBase & dsp.enhancedsim.UpdateSysObjBuildInfo
%ChannelSynthesizer Polyphase FFT synthesis filter bank.
%   synthesizer = dsp.ChannelSynthesizer returns a polyphase FFT synthesis
%   filter bank System object, synthesizer, which takes multiple narrowband
%   input signals and merges them into a single broadband output signal.
%   This object implements the inverse operation of dsp.Channelizer.
%
%   synthesizer = dsp.ChannelSynthesizer(Name=Value, ...) returns a
%   synthesizer with each specified property name set to the specified
%   value. You can specify additional name-value pair arguments in any
%   order as (Name1=Value1, ...,NameN=ValueN).
%
%   The number of frequency bands (which corresponds to the number of
%   narrowband input signals) is given by the number of columns of the
%   input signal.
%
%   The specification defaults to number of taps per band and stopband
%   attenuation. These values are used to design a prototype lowpass filter
%   that is implemented in polyphase form. The stopband attenuation
%   determines the minimum level of interference (aliasing) from one
%   frequency band to another. The number of taps corresponds to the number
%   of filter coefficients used for each polyphase branch. The number of
%   polyphase branches matches the number of frequency bands. The total
%   number of filter coefficients for the prototype lowpass filter is given
%   by the number of frequency bands times the number of taps per band.
%   For a given stopband attenuation, increasing the number of taps per
%   band will narrow the transition width of the filter resulting in more
%   usable bandwidth for each frequency band at the expense of increased
%   computation.
%
%   Step method syntax:
%
%   y = step(synthesizer,x) merges the narrowband input signals contained
%   in the columns of x into a broadband signal y. The number of columns in
%   x corresponds to the number of frequency bands. If x is three
%   dimensional, each matrix corresponds to a separate channel. If M is the
%   number of frequency bands and x is a LxM matrix, y will have dimensions
%   L*Mx1. If x has more than one channel, i.e. x is LxMxN, y will have
%   dimensions L*MxN.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj,x) and y = obj(x) are
%   equivalent.
%
%   ChannelSynthesizer methods:
%
%   step      - See above description for use of this method
%   release   - Allow property value and input characteristics changes
%   clone     - Create a new object with same property values
%   isLocked  - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>     - Reset the internal states to initial conditions
%   coeffs    - Returns a structure containing the prototype lowpass filter
%               coefficients
%   polyphase - Returns the polyphase coefficient matrix
%   tf        - Returns the transfer function of the prototype lowpass
%               filter
%
%   ChannelSynthesizer properties:
%
%   Specification       - Design parameters or Coefficients
%   NumTapsPerBand      - Number of filter coefficients per frequency band
%   StopbandAttenuation - Stopband attenuation for lowpass filter in dB
%   LowpassCoefficients - Coefficients for prototype lowpass filter
%
%   % EXAMPLE: Merge 8 separate narrowband signals, each one containing one
%   % sine wave into one broadband signal with the sine waves modulated to
%   % each band frequency.
%   synthesizer = dsp.ChannelSynthesizer;
%   offsets = [-400,-300,-200,-100,150,250,350,450];
%   sinewave = dsp.SineWave(ComplexOutput=true,Frequency=offsets+...
%       (-375:125:500),SamplesPerFrame=100);
%   scope = spectrumAnalyzer(ShowLegend=true, ...
%               SampleRate=sinewave.SampleRate*8);
%   for i=1:5000
%       x = sinewave();
%       y = synthesizer(x);
%       scope(y);
%   end
%
%   See also dsp.Channelizer, dsp.FIRHalfbandDecimator,
%   dsp.FIRHalfbandInterpolator, dsp.IIRHalfbandInterpolator,
%   dsp.DyadicSynthesisFilterBank, firpr2chfb.

 
% Copyright 2016-2021 The MathWorks, Inc.

    methods
        function out=ChannelSynthesizer
            %ChannelSynthesizer Construct the ChannelSynthesizer class.
        end

        function out=coeffs(~) %#ok<STOUT>
            %c = coeffs(obj) Return structure with filter coefficients
            %   c = coeffs(obj) returns the overall prototype lowpass
            %   filter coefficients in a structure.
        end

        function out=designPrototypeLowpass(~) %#ok<STOUT>
        end

        function out=getNumBands(~) %#ok<STOUT>
            % Return the number of bands
        end

        function out=getNumChs(~) %#ok<STOUT>
            % getNumChs Return the number of input channels
        end

        function out=isInputComplexityMutableImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=polyphase(~) %#ok<STOUT>
            %p = polyphase(obj) Return polyphase matrix
            %   p = polyphase(obj) returns the polyphase matrix used by the
            %   filter bank. Each row in the matrix corresponds to a
            %   polyphase branch. The number of columns of p corresponds to
            %   the number of filter taps per branch.
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Implement any tasks that need to be performed only once, such
            % as computation of constants or creation of child System objects
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=tf(~) %#ok<STOUT>
            %[b,a] = tf(obj) Return transfer function
            %   [b,a] = tf(obj) returns the vector of numerator
            %   coefficients b and the vector of denominator coefficients a
            %   for the overall prototype lowpass filter used for the
            %   filter bank.
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

    end
end
