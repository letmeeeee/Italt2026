classdef FIRHalfbandDecimator< dsp.internal.FIRHalfbandBase
%FIRHalfbandDecimator Decimate by a factor of two using polyphase FIR
%   This System object decimates an input signal using a two branch
%   polyphase structure optimized for halfband filters. All the even
%   indexed samples of halfband filters are zero except the sample at
%   the origin. This System object takes advantage of the zero
%   coefficients, thereby making the second branch of the polyphase
%   structure a delay. It can also act as an Analysis Filter bank.
%   Filter design is done using optimum equiripple filter design
%   method.
%
%   FIRHALFBANDDECIM = dsp.FIRHalfbandDecimator returns a FIR halfband
%   decimator System object, FIRHALFBANDDECIM, that decimates a signal by a
%   factor 2 using polyphase structure optimized for halfband filters. The
%   filter design parameters are 'TransitionWidth' and
%   'StopbandAttenuation' and the design ensures a minimum order equiripple
%   filter.
%
%   FIRHALFBANDDECIM = dsp.FIRHalfbandDecimator(Name=Value, ...) returns
%   a FIR Halfband decimator System object, FIRHALFBANDDECIM, with each
%   specified property set to the specified value.
%
%   Step method syntax:
%
%   Y1 = step(FIRHALFBANDDECIM,X) outputs the decimated values, Y1, of the
%   input signal X. A KixN input matrix is treated as N independent
%   channels, and the System object decimates each channel over time and
%   generates a KoxN output matrix. Ko = Ki/2, where 2 is the decimation
%   factor. The object supports real and complex floating- point and
%   fixed-point inputs.
%
%   [Y1,Y2] = step(FIRHALFBANDDECIM,X) outputs two baseband signals: Y1 and
%   Y2. X, a KixN input matrix is treated as N independent channels. System
%   object decomposes X into two baseband signals and sends the two signals
%   through the two branches of the polyphase structure. The output signals
%   from the two branches are added to generate Y1, low pass output of the
%   Analysis Filter bank and subtracted to generate Y2, high pass output of
%   the Analysis Filter bank. Each output signal is a KoxN matrix. Ko =
%   Ki/2, where 2 is the decimation factor.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   FIRHalfbandDecimator methods:
%
%   step        - See above description for use of this method
%   release     - Allow property value and input characteristics changes
%   clone       - Create FIR Halfband decimator object with same property
%                 values
%   isLocked    - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>       - Reset the internal states to initial conditions
%
%   FIRHalfbandDecimator properties:
%
%   SampleRate               - Input sample rate
%   Specification            - Filter design parameter specification.
%   FilterOrder              - Order of the filter.
%   StopbandAttenuation      - Minimum attenuation needed in stopband of
%                              FIR halfband filter.
%   TransitionWidth          - Transition width of the filter in FIR
%                              halfband decimator.
%   Numerator                - Specified FIR Halfband Coefficients,
%                              when Specification is 'Coefficients'.
%   DesignMethod             - Filter design method, specified as 'Auto',
%                              'Equiripple' or 'Kaiser'.     
%   NormalizedFrequency      - Provide normalized frequencies for filter
%                              specifications
%   AllowArbitraryInputLength - Allow arbitrary input length for fixed-size
%                              signals in code generation
%   This System object supports several filter analysis methods. For
%   more information, type dsp.FIRHalfbandDecimator.helpFilterAnalysis.
%
%   This System object supports fixed-point operations. For more
%   information, type dsp.FIRHalfbandDecimator.helpFixedPoint.
%
%   % EXAMPLE 1: Decimate an input signal by 2
%   Fs1 = 8000;     % Units = Hz
%   TW = 4.1e2;     % Units = Hz
%   order = 52;
%
%   % Construct FIR Halfband Decimator
%   firhb = dsp.FIRHalfbandDecimator(SampleRate=Fs1,...
%       Specification="Filter order and transition width",...
%       FilterOrder=order,...
%       TransitionWidth=TW,...
%       DesignMethod="Equiripple");
%
%   % Visualize its impulse response
%   fvtool(firhb,Analysis="Impulse");
%   % Plot the magnitude and phase response
%   fvtool(firhb,Analysis="freq")
%
%   % Decimated output of a white noise signal
%   x = randn(1024,2);
%   y = firhb(x);
%   release(firhb);
%
%   % Example 2: Analyze the low pass and high pass bands of an input
%   % signal
%   Fs1 = 8000;     % Units = Hz
%   TW = 4.1e2;     % Units = Hz
%   order = 52;
%
%   % Construct FIR Halfband Decimator
%   firhb = dsp.FIRHalfbandDecimator(SampleRate=Fs1,...
%       Specification="Filter order and transition width",...
%       FilterOrder=order,...
%       TransitionWidth=TW);
%
%   % Input
%   f1 = 1000;
%   f2 = 3000;
%   sine = dsp.SineWave(Frequency=[f1,f2],SampleRate=Fs1,...
%       SamplesPerFrame=1024);
%
%   % Construct Spectrum Analyzer object to view the noisy input spectrum
%   scopeInput = spectrumAnalyzer(SampleRate=Fs1,...
%       Method="welch", ...
%       PlotAsTwoSidedSpectrum=false,...
%       ShowLegend=true,YLimits=[-120 30],...
%       Title="Input Signal with noise",...
%       ChannelNames="Noisy input");
%
%   % Construct Spectrum Analyzer object to view lowpass band
%   scopeLP = spectrumAnalyzer(SampleRate=Fs1/2,...
%       Method="welch", ...
%       PlotAsTwoSidedSpectrum=false,...
%       ShowLegend=true,YLimits=[-120 30],...
%       Title="Lowpass band output",...
%       ChannelNames="Lowpass band");
%
%   % Construct Spectrum Analyzer object to view highpass band
%   scopeHP = spectrumAnalyzer(SampleRate=Fs1/2,...
%       Method="welch", ...
%       PlotAsTwoSidedSpectrum=false,...
%       ShowLegend=true,YLimits=[-120 30],...
%       Title="Highpass band moved to Baseband",...
%       ChannelNames="Highpass band");
%
%   % Stream processing loop
%   for k = 1:100
%       input = sum(sine(),2);
%       noisyInput = input + (10^-5)*randn(1024,1);
%       [lowpass, highpass] = firhb(noisyInput);
%       scopeInput(noisyInput);
%       scopeLP(lowpass);
%       scopeHP(highpass);
%   end
%
%   See also dsp.FIRHalfbandInterpolator, dsp.FIRDecimator,
%            designHalfbandFIR, 
%            dsp.FIRHalfbandDecimator.helpFilterAnalysis.

 
%   Copyright 2014-2023 The MathWorks, Inc.

    methods
        function out=FIRHalfbandDecimator
            % Support name-value pair arguments
        end

        function out=crossValidateProperties(~) %#ok<STOUT>
        end

        function out=designObjects(~) %#ok<STOUT>
            % Remove the 0.5 coefficient and 0 coefficients
            % (from constant, private Coefficients values):
        end

        function out=getNumOutputsImpl(~) %#ok<STOUT>
        end

        function out=helpFixedPoint(~) %#ok<STOUT>
            %helpFixedPoint Display FIRHalfbandDecimator System object
            %               fixed-point information
            %   dsp.FIRHalfbandDecimator.helpFixedPoint displays
            %   information about fixed-point properties and operations of
            %   the FIRHalfbandDecimator System object.
        end

        function out=isFixedSizeOutput(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=realizemdl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
            %Defining the System objects
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=supportsScalarVarsizeImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

        function out=validatePropertiesImpl(~) %#ok<STOUT>
        end

    end
    properties
        %AllowArbitraryInputLength Allow arbitrary frame length for fixed-size input signals
        %   When this flag is set to true, the fixed-size input signal can
        %   have a frame size that is not a multiple of the 2. This
        %   property applies only when the input is a fixed-size signal. If
        %   the size of the input signal varies during simulation
        %   (variable-size signal), this property does not apply. The
        %   default value is 'false' and has to be set to 'true' to process
        %   inputs with arbitrary frame lengths.
        AllowArbitraryInputLength;

        EmptyOutputFixPt;

        %Numerator Numerator
        %   Specify the FIR Halfband Coefficients. The default value of
        %   this property is designHalfbandFIR(TransitionWidth=0.186, ...
        %   StopbandAttenuation=80, Structure='decim'). This property 
        %   applies when you set Specification to 'Coefficients'.
        Numerator;

        %TransitionWidth Transition width
        %   Specify the transition width for the designed FIR halfband
        %   filter as a finite positive scalar which is less than half the
        %   input sample rate. Specify the value of transition width in
        %   Hertz when NormalizedFrequency is set to false and in
        %   normalized units when NormalizedFrequency is set to true.This
        %   property applies when the Specification is either 'Filter order
        %   and transition width' | 'Transition width and stopband
        %   attenuation'. The default value of this property is 4100Hz.
        TransitionWidth;

        isPartialAccEmpty;

    end
end
