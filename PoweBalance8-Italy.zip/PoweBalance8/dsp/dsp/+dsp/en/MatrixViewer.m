classdef MatrixViewer< matlabshared.scopes.MatrixViewer
% MatrixViewer displays image from a matrix
%   MATRIXVIEWER = dsp.MatrixViewer returns a System object, MATRIXVIEWER,
%   that can display an M-by-N matrix by mapping the matrix element values
%   to specified range of colors.
%
%   MATRIXVIEWER = dsp.MatrixViewer('Name', Value, ...) returns a Matrix Viewer
%   System object, MATRIXVIEWER, with each specified property name set to the
%   specified value. You can specify name-value pair arguments in any
%   order.
%
%   Step method syntax:
%
%   step(MATRIXVIEWER, X) displays the matrix, X, in the MatrixViewer
%   Scope.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, step(obj, x) and obj(x) are equivalent.
%
%   MatrixViewer methods:
%
%   step                - Display input matrix in the Matrix Viewer
%   show                - Turn on visibility of Matrix Viewer
%   release             - Allow property value and input characteristics changes,
%                         and release Matrix Viewer resources
%   clone               - Create Matrix Viewer object with the same property values
%   isLocked            - Display locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>               - Clear the Matrix Viewer Scope
%   hide                - Turn off visibility of Matrix Viewer
%   isVisible           - Return visibility of Matrix Viewer (logical)
%   setCursorDataLabels - set Cursor Labels to display in Cursor Text
%                         on scope window.
%
%
%   MatrixViewer properties:
%
%   Name              - Caption to display on the Scope Window
%   Position          - Scope window position in pixels
%   ShowGrid          - Show grid
%   ShowColorBar      - Show color bar
%   XDataMode         - Choose how to specify X-axis data
%   XResolution       - X-axis sample spacing
%   XOffset           - X-axis display offset
%   CustomXData       - Custom X-axis data values
%   YDataMode         - Choose how to specify Y- axis data
%   YOffset           - Y-axis display offset
%   YSpan             - Y-axis span
%   YResolution       - Y-axis Resolution
%   CustomYData       - Custom Y-axis data values
%   ShowTicks         - Show ticks on the X-axis and Y-axis
%   Colormap          - Color values to map on color bar
%   ColorLimits       - Color bar limits
%   Title             - Display title
%   XLabel            - X-axis label
%   YLabel            - Y-axis label
%   ColorBarLabel     - Color bar label
%   ColorBarLocation  - Color bar location
%   AxisOrigin        - Specify position from where first element is plotted
%
%    % Example 1: View chirp signal on a MatrixViewer Scope
%    ChirpSignal = dsp.Chirp('SampleRate',100);
%    x = ChirpSignal() + 0.005*randn(100,30);
%    Scope = dsp.MatrixViewer;
%    Scope(x);
%   
%    % Example 2: View spectrum data with different sample rates on 
%    % MatrixViewer Scope during cascading 
%
%    ChirpSignal = dsp.Chirp('InitialFrequency',100,'TargetFrequency',1000,'SampleRate',10000, ...
%                  'SamplesPerFrame',400,'SweepDirection','Bidirectional');
%    % Spectrum Estimator to compute the power spectrum and the max-hold spectrum of the sine wave
%    SE = dsp.SpectrumEstimator('SampleRate',ChirpSignal.SampleRate, ...
%         'SpectrumType','Power','PowerUnits','dBm','FrequencyRange','centered');
%
%    % Stream in the data amd plot spectrum in MatrixViewer
%    MVScope = dsp.MatrixViewer('YDataMode','Span and resolution','AxisOrigin','Lower left corner');
%
%    % Set YSpan and YResolution to calculate number of rows in Matrix during
%    % cascading case
%    MVScope.YSpan=100000;
%    MVScope.YResolution=100;
%    % Set XOffset and XResolution to display frequency values
%    MVScope.XOffset= -ChirpSignal.SampleRate/2;
%    MVScope.XResolution = 25;
%    for ii = 1:1001
%       x = ChirpSignal() + 0.05*randn(400,1);    
%       MVScope(SE(x).') 
%    end 
%
%    % Example 3: View Spectrogram  quadratic chirp signal with frequency on 
%    % MatrixViewer Scope
%    t = 0:0.001:2;                        % 2 secs @ 1kHz sample rate
%    % Generate chirp signal, Start @ 100Hz, cross 200Hz at t=1sec
%    x = chirp(t,100,1,200,'quadratic');
%    [~,f ,t,Ps] = spectrogram(x,128,120,128,1e3); % Compute spectrogram
%
%    % Compute magnitude in dB to display Spectrogram.
%    val = 10*log10(abs(Ps)'+eps);
%
%    % Create a MatrixViewer Scope object
%    M = dsp.MatrixViewer('AxisOrigin','Lower left corner',...
%         'YLabel','Time (secs)','XLabel','Frequency (Hz)',...
%         'XDataMode','Custom','YDataMode','Custom',...
%         'CustomXData',f,'CustomYData',t,...
%        'ColorBarLabel','Power/Frequency (dB/Hz)');
%    M(val);                                   % Display Spectrogram
%
%   See also image, imagesc, imshow.

     
    %   Copyright 2018 The MathWorks, Inc.

    methods
        function out=MatrixViewer
            % Call the Abstract class constructor
        end

    end
end
