classdef FrequencyDomainFIRFilter< matlab.System & dsp.enhancedsim.UpdateSysObjBuildInfo
%   FrequencyDomainFIRFilter Filter input signal in the frequency
%   domain. fdf = dsp.FrequencyDomainFIRFilter returns a System object,
%   fdf, which independently filters each channel of the input over
%   time using the overlap-save or overlap-add method.
%
%   fdf = dsp.FrequencyDomainFIRFilter(Name=Value, ...) returns a
%   frequency domain filter System object, fdf, with each specified
%   property name set to the specified value. You can specify
%   additional name-value pair arguments in any order as
%   (Name1=Value1,...,NameN=ValueN).
%
%   fdf = dsp.FrequencyDomainFIRFilter(num) returns a frequency domain
%   filter object, fdf, with the Numerator property set to num.
%
%   Step method syntax:
%  
%   Y = step(fdf, X) computes the filtered output, Y, of the input X.
%   Each column of X is a channel. The System object filters each
%   channel of the input signal independently over time.
%
%   System objects may be called directly like a function instead of
%   using the step method. For example, y = step(obj, x) and y = obj(x)
%   are equivalent.
%
%   FrequencyDomainFIRFilter methods:
%
%   step                     - Filter the input signal in the frequency
%                              domain
%   release                  - Allow property value and input
%                              characteristics changes, and release
%                              filter resources
%   clone                    - Create filter object with same
%                              property values
%   isLocked                 - Display locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>                    - Reset the states of the filter
%   fvtool                   - Visualize the numerator's frequency
%                              response
%
%   FrequencyDomainFIRFilter properties:
%
%   Method                     - Frequency-domain filter method
%   NumeratorDomain            - Numerator domain (Time or Frequency)
%   Numerator                  - Filter coefficients
%   FrequencyResponse          - Filter frequency response
%   FFTLength                  - FFT length
%   NumeratorLength            - Time-domain numerator length
%   FilterIsReal               - Filter is real
%   PartitionForReducedLatency - Partition numerator to reduce latency
%   PartitionLength            - Numerator partition length
%   Latency                    - Filter latency (read-only)
%   NumPaths                   - Number of Paths between each
%                                transmitter and receiver pair
%   SumFilteredOutputs         - Sum filtered output contributions from
%                                all input channels
%
%   % Example: Filter input signal using overlap-add, and compare to
%   % the output of a time-domain FIR filter.
%
%   % Design FIR lowpass filter coefficients:
%   impL    = 400;
%   Fs      = 8000;
%   Fcutoff = 2000;
%   imp     = designLowpassFIR(FilterOrder=impL,...
%               CutoffFrequency=2*Fcutoff/Fs);
%
%   oa  = dsp.FrequencyDomainFIRFilter(imp, Method='overlap-add');
%   fprintf('Frequency domain filter latency is %dsamples\n',...
%   oa.Latency);
%   fir = dsp.FIRFilter(Numerator=imp);
%   % Delay the FIR output by the frequency-domain filter's latency.
%   dly = dsp.Delay(Length=oa.Latency);
%
%   numFrames = 1e4;
%   frameLen  = 256;
%
%   sin_100Hz = dsp.SineWave(Frequency=100, SampleRate=Fs,...
%                            SamplesPerFrame=frameLen);
%   sin_3KHz  = dsp.SineWave(Frequency=3e3, SampleRate=Fs,...
%                            SamplesPerFrame=frameLen);
%
%   ts = timescope(TimeSpanSource='property',...
%                  TimeSpan=5 * frameLen/Fs,...
%                  YLimits=[-1.1 1.1],...
%                  ShowLegend=true,...
%                  SampleRate=Fs,...
%                  ChannelNames={'Overlap-add','Direct-form FIR'});
%
%   for idx = 1:numFrames
%     x = sin_100Hz() + sin_3KHz() + 0.01 * randn(frameLen,1);
%     y1 = oa(x);
%     y2 = fir(dly(x));
%     ts([y1,y2]);
%   end
%
%   % Example: Use overlap-save to pass an input signal through an
%   % FIR filter of length 3000. Partition numerator to reduce latency.
%   % Compare to the output of a time-domain FIR filter.
%
%   % Design FIR lowpass filter coefficients:
%   impL    = 3000;
%   Fs      = 8000;
%   Fcutoff = 2000;
%   imp     = designLowpassFIR(FilterOrder=impL,...
%   CutoffFrequency=2*Fcutoff/Fs);
%
%   os  = dsp.FrequencyDomainFIRFilter(imp, Method='overlap-save',...
%                                    PartitionForReducedLatency=true,...
%                                    PartitionLength=256);
%   fprintf('Frequency domain filter latency is %d samples\n',...
%   os.Latency);
%   fir = dsp.FIRFilter(Numerator=imp);
%   dly = dsp.Delay(Length=os.Latency);
%
%   numFrames = 1e4;
%   frameLen  = 256;
%
%   sin_100Hz = dsp.SineWave(Frequency=100,SampleRate=Fs,...
%                            SamplesPerFrame=frameLen);
%   sin_3KHz  = dsp.SineWave(Frequency=3e3,SampleRate=Fs,...
%                            SamplesPerFrame=frameLen);
%
%   ts = timescope(TimeSpanSource='property',...
%                  TimeSpan=5 * frameLen/Fs,...
%                  YLimits=[-1.1 1.1],...
%                  ShowLegend=true,...
%                  SampleRate=Fs,...
%                  ChannelNames={'Overlap-save','Direct-form FIR'});
%
%   for idx = 1:numFrames
%       x = sin_100Hz() + sin_3KHz() + .1 * randn(frameLen,1);
%       y1 = os(x);
%       y2 = fir(dly(x));
%       ts([y1,y2]);
%   end
%
%   % Example: Specify the filter's frequency response. Filter input
%   % signal using overlap-add, and compare to the output of a
%   % time-domain FIR filter.
%
%   % Design FIR lowpass filter coefficients:
%   impL    = 400;
%   Fs      = 8000;
%   Fcutoff = 2000;
%   imp     = designLowpassFIR(FilterOrder=impL,...
%   CutoffFrequency=2*Fcutoff/Fs);
%
%   H   = fft(imp, 2 * numel(imp));
%   oa  = dsp.FrequencyDomainFIRFilter(NumeratorDomain='Frequency',...
%                                      FrequencyResponse=H,...
%                                      NumeratorLength=numel(imp),...
%                                      Method='overlap-add');
%   fprintf('Frequency domain filter latency is %d samples\n',...
%   oa.Latency);
%   fir = dsp.FIRFilter(Numerator=imp);
%   % Delay the FIR output by the frequency-domain filter's latency.
%   dly = dsp.Delay(Length=oa.Latency);
%
%   numFrames = 1e4;
%   frameLen  = 256;
%
%   sin_100Hz = dsp.SineWave(Frequency=100,SampleRate=Fs,...
%                            SamplesPerFrame=frameLen);
%   sin_3KHz  = dsp.SineWave(Frequency=3e3,SampleRate=Fs,...
%                            SamplesPerFrame=frameLen);
%
%   ts = timescope(TimeSpanSource='property',...
%                  TimeSpan=5 * frameLen/Fs,...
%                  YLimits=[-1.1 1.1],...
%                  SampleRate=Fs,...
%                  ChannelNames={'Overlap-add','Direct-form FIR'});
%
%   for idx = 1:numFrames
%     x = sin_100Hz() + sin_3KHz() + 0.01 * randn(frameLen,1);
%     y1 = oa(x);
%     y2 = fir(dly(x));
%     ts([y1,y2]);
%   end
%
%   % Example: Filter an input signal using a 3-by-2 MIMO system that
%   % is modeled using multiple filters.
% 
%   % Design FIR lowpass filter coefficients:
%   impL    = 400;
%   Fs      = 8000;
%
%   % Number of filters is six for three transmitters (input channels),
%   % two receivers and one path between each transmitter-receiver
%   % pair.
%   
%   num  = [ % Transmitter 1, Receiver 1
%           designLowpassFIR(FilterOrder=impL,CutoffFrequency=0.1);...
%            % Transmitter 1, Receiver 2
%           designLowpassFIR(FilterOrder=impL,CutoffFrequency=0.15);...
%            % Transmitter 2, Receiver 1
%           designLowpassFIR(FilterOrder=impL,CutoffFrequency=0.2);...
%            % Transmitter 2, Receiver 2
%           designLowpassFIR(FilterOrder=impL,CutoffFrequency=0.25);...
%            % Transmitter 3, Receiver 1
%           designLowpassFIR(FilterOrder=impL,CutoffFrequency=0.3);...
%            % Transmitter 3, Receiver 2
%           designLowpassFIR(FilterOrder=impL,CutoffFrequency=0.35)];
%  
%   % Compute output using overlap-save method
%   filt  = dsp.FrequencyDomainFIRFilter(Numerator=num,...
%   Method='overlap-save');
%   numFrames = 1e4;
%   frameLen  = 256;
%
%   sin_Hz = dsp.SineWave(Frequency=[100 200 300],SampleRate=Fs,...
%                        SamplesPerFrame=frameLen);
%   sin_KHz  = dsp.SineWave(Frequency=[2e3 2.5e3 3e3],SampleRate=Fs,...
%                        SamplesPerFrame=frameLen);
%
%   specScope = spectrumAnalyzer(SampleRate=Fs,PlotAsTwoSidedSpectrum=false, ...
%           ChannelNames={'Transmitter 1','Transmitter 2','Transmitter 3', ...
%           'Receiver 1','Receiver 2'},ShowLegend=true);
%
%   for idx = 1:numFrames
%       x = sin_Hz() + sin_KHz() + 0.01 * randn(frameLen, 3);
%       y = filt(x);
%
%       specScope([x, y]);
%   end
%
%   % Example: Filter an input signal through three distinct paths
%   % between the input and the output by specifying three filters to
%   % model the frequency responses across each path.
%
%   % Design FIR lowpass filter coefficients:
%   impL    = 400;
%   Fs      = 8000;
%
%   num = [ 
%   designFracDelayFIR(0.1,impL); % Path 1
%   designFracDelayFIR(0.2,impL); % Path 2
%   designFracDelayFIR(0.3,impL); % Path 3
%   ];
% 
%   % Compute SISO output using overlap-add method
%   filt  = dsp.FrequencyDomainFIRFilter(Numerator=num,...
%                        Method='overlap-add',NumPaths=3);
%   numFrames = 1e3;
%   frameLen  = 1024;
%
%   sin_200Hz = dsp.SineWave(Frequency=200,SampleRate=Fs,...
%                        SamplesPerFrame=frameLen);
%   sin_4KHz  = dsp.SineWave(Frequency=4e3,SampleRate=Fs,...
%                        SamplesPerFrame=frameLen);
%
%   specScope = spectrumAnalyzer(SampleRate=Fs,PlotAsTwoSidedSpectrum=false, ...
%                ChannelNames={'Transmitter','Receiver'},ShowLegend=true);
%
%   for idx = 1:numFrames
%       x = sin_200Hz() + sin_4KHz() + 0.01 * randn(frameLen, 1);
%       y = filt(x);
%
%       specScope([x, y])
%   end
%
%   See also dsp.FIRFilter

     
% Copyright 2017-2023 The MathWorks, Inc.

    methods
        function out=FrequencyDomainFIRFilter
        end

        function out=coeffs(~) %#ok<STOUT>
            % c = coeffs(obj) Return structure with filter coefficients
            %   c = coeffs(obj) returns the overall time domain filter
            %   coefficients in a structure.
        end

        function out=fvtool(~) %#ok<STOUT>
            % Visualize the filter's frequency response. Visualize the
            % magnitude response, phase response, group delay, impulse
            % response, or pole-zero plot.
            %
            % Example
            % h    = firpm(25,[0 .4 .5 1],[0 0 1 1],'h');
            % filt = dsp.FrequencyDomainFIRFilter(h);
            % fvtool(filt)
        end

        function out=getNumChannels(~) %#ok<STOUT>
            % GETNUMCHANNELS Return the number of input channels
        end

        function out=getNumeratorPrototype(~) %#ok<STOUT>
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
            % Modify order of display
        end

        function out=inheritFFT(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=isPartitioned(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=partitionNumerator(~) %#ok<STOUT>
            % partitionNumerator Partition numerator.
            % H = partitionNumerator(NUM,P) partitions the numerator, NUM,
            % using a partition length P. H is a 2*P-by-N matrix, where N
            % is the number of partitions. NUM must be a row vector.
            %
            % % Example:
            % h = fir1(299,.3);
            % H = dsp.FrequencyDomainFIRFilter.partitionNumerator(h,30);
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
            %  Get the number of input channels
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

        function out=validateNumerator(~) %#ok<STOUT>
        end

        function out=validatePropertiesImpl(~) %#ok<STOUT>
        end

        function out=validateProps(~) %#ok<STOUT>
        end

    end
    properties
        % FFTLength FFT length
        %  Specify the FFT length as a positive scalar integer. The default
        %  value of this property is [], which means that the FFT length is
        %  equal to twice the numerator length. This property applies when
        %  PartitionForReducedLatency is false and NumeratorDomain is
        %  'Time'.
        FFTLength;

        % FilterIsReal Filter is real
        % Specify if the filter coefficients are all real. This property
        % applies when NumeratorDomain is 'Frequency'. The default is true.
        FilterIsReal;

        % FrequencyResponse Frequency response
        % Specify the filter frequency response. When
        % PartitionForReducedLatency is false, FrequencyResponse can be a
        % row vector or matrix of size NumFilt-by-FFTLength, where NumFilt
        % is the number of filters. When PartitionForReducedLatency is
        % true, more than one filter can not be specified and it must be a
        % 2*P-by-N matrix, where P is the partition size, and N is the
        % number partitions. This property is applicable when
        % NumeratorDomain is 'Frequency'. The default value of this
        % property is fft(fir1(100,0.3), 202). This property is tunable.
        FrequencyResponse;

        % Latency Filter latency
        %   Use this read-only property to access the filter latency, in
        %   samples. When PartitionForReducedLatency is false, the latency
        %   is equal to FFTLength - length(Numerator) + 1. When
        %   PartitionForReducedLatency is true, the latency is equal to
        %   the partition length.
        Latency;

        % Method Frequency-domain filter method
        %  Specify the frequency-domain filter method as 'Overlap-save' or
        %  'Overlap-add'. The default is 'Overlap-save'.
        Method;

        % NumPaths Number of propagation paths between each transmitter and
        % receiver pair
        %  Specify the number of paths between each transmitter (input
        %  channel) and receiver (output channel) as a positive integer.
        %  Each path is represented by a unique filter. Specifying number
        %  of paths greater than one can be used to model multipath
        %  propagation. The default value of this property is 1. This
        %  property is applicable when the number of filters is greater
        %  than 1 and PartitionForReducedLatency is false.
        NumPaths;

        % Numerator Filter coefficients
        % Specify the filter coefficients as a real or complex numeric row
        % vector or matrix. When PartitionForReducedLatency is true, more
        % than one filter can not be specified thus, Numerator must be a row
        % vector. When PartitionForReducedLatency is false, multiple
        % filters can be specified. Numerator can be a row vector or matrix
        % of size NumFilt-by-FiltLen, where NumFilt is the number of
        % filters, and FiltLen is the filter length. NumFilt =
        % size(input,2)*NumPaths*NumRx where NumRx is the number of
        % receivers i.e. size(y,2). The filters must be given in
        % the same order as input channels. The first NumRx*NumPaths
        % filters correspond to the first input channel within which
        % (i-1)*NumPaths + 1 to i*NumPaths filters compute the output for
        % the ith receiver. Similarly, the next NumRx*NumPaths filters
        % correspond to the second channel and so forth. This property is
        % tunable but the size must remain the same. This property is
        % applicable when NumeratorDomain is 'Time'. The default value of
        % this property is fir1(100,0.3).
        Numerator;

        % NumeratorDomain Numerator domain
        % Specify the numerator domain as 'Time' or 'Frequency'. When
        % NumeratorDomain is 'Time', you specify the time-domain filter
        % numerator in the Numerator property. When NumeratorDomain is
        % 'Frequency', you specify the filter's frequency response in the
        % FrequencyResponse property. The default is 'Time'.
        NumeratorDomain;

        % NumeratorLength Time-domain numerator length
        % Specify the time-domain numerator length as a positive scalar.
        % This property is applicable when NumeratorDomain is 'Frequency'.
        % The default value of this property is 101.
        NumeratorLength;

        % PartitionForReducedLatency Partition numerator to reduce latency
        %   When PartitionForReducedLatency is false, the filter uses the
        %   traditional overlap-save or overlap-add method. The latency in
        %   that case is FFTLength - length(Numerator) + 1. To reduce the
        %   latency, set PartitionForReducedLatency to true. In this mode,
        %   the numerator is partitioned into segments with length
        %   specified by the PartitionLength property. The filter performs
        %   overlap-save or overlap-add on each partition, and combines the
        %   partial results to form the overall output. The latency is now
        %   reduced to the partition length.
        PartitionForReducedLatency;

        % PartitionLength Numerator partition length
        %  Specify the numerator partition length as a positive scalar
        %  integer less than or equal to the length of the numerator. The
        %  default is 32. This property applies when
        %  PartitionForReducedLatency is true and NumeratorDomain is
        %  'Time'.
        PartitionLength;

        % SumFilteredOutputs Sum filtered output contributions from all
        % input channels
        %   When SumFilteredOutputs is true, the filtered output from each
        %   input channel for a given receiver is added to generate a
        %   L-by-R matrix output where L is the input frame size and R is
        %   the number of receivers. The number of receivers is
        %   NumFilt/(size(input, 2)*NumPaths, where NumFilt is the number
        %   of filters. When SumFilteredOutputs is false, no summation
        %   across input channels takes place. The output will be an
        %   L-by-R-by-size(input, 2) 3D matrix. This property is applicable
        %   when the number of filters is greater than 1 and
        %   PartitionForReducedLatency is false.
        SumFilteredOutputs;

        % pFilter Frequency-domain Filter
        pFilter;

        % pNumFilters Number of Filters
        pNumFilters;

        % pNumeratorLength Numerator length
        pNumeratorLength;

    end
end
