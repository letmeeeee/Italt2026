classdef HampelFilter< matlab.System
%   HampelFilter Perform outlier filtering 
%   hampfilt = dsp.HampelFilter returns a System object, hampfilt, that
%   removes the outliers of the input signal based on the Hampel 
%   identifier.
%
%   hampfilt = dsp.HampelFilter('Name', Value, ...) returns a Hampel filter
%   System object, hampfilt, with each specified property name set to the
%   specified value. You can specify additional name-value pair arguments
%   in any order as (Name1,Value1,...,NameN, ValueN).
%
%   hampfilt = dsp.HampelFilter(Length) returns a Hampel filter object,
%   hampfilt, with the WindowLength property set to Length.
%
%   hampfilt = dsp.HampelFilter(Length, Limit) returns a Hampel filter 
%   object, hampfilt, with the WindowLength property set to Length and the
%   Threshold property set to Limit.
%
%   Step method syntax:
%
%   Y = step(hampfilt, X) computes Y by removing the outliers of the input 
%   X. Each column of X is a channel. The System object removes the 
%   outliers of each channel of the input signal independently over time. 
%   The input must be real.
% 
%   [Y,IsOutlier] = step(hampfilt, X) returns a logical array, IsOutlier, 
%   of the same size as the input X, which is true when the corresponding 
%   element in the input was identified as an outlier. 
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   HampelFilter methods:
%
%   step                     - Remove outliers from input
%   release                  - Allow property value and input 
%                              characteristics changes, and release Hampel
%                              filter resources
%   clone                    - Create Hampel filter object with same
%                              property values
%   isLocked                 - Display locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>                    - Reset the states of the Hampel filter
%
%   HampelFilter properties:
%
%   WindowLength             - Sliding window length
%   Threshold                - Threshold for outlier detection (standard 
%                              deviations)
%
%   % EXAMPLE 1: Pass a sine wave corrupted by high-frequency noise through
%   % a Hampel filter. Compare with a median filter. 
%   Fs = 1000;
%   scope  = timescope('SampleRate',Fs,...
%       'TimeSpanSource','property',...
%       'TimeSpan',1, ...
%       'YLimits',[-3 3],...
%       'LayoutDimensions',[3 1]);
%   scope.ActiveDisplay = 1;
%   scope.Title = 'Signal + Noise';
%   scope.ActiveDisplay = 2;
%   scope.Title = 'Median Filter Output (Window Length = 31)';
%   scope.ActiveDisplay = 3;
%   scope.Title = 'Hampel Filter Output (Window Length = 31)';
%   
%   FrameLength  = 256;
%   WindowLength = 31;
%   
%   hampfilt   = dsp.HampelFilter(WindowLength);
%   medfilt    = dsp.MedianFilter(WindowLength);
%   
%   sine = dsp.SineWave('SampleRate',Fs,'Frequency',10,...
%       'SamplesPerFrame',FrameLength);
%   tic;
%   while (toc < 5)
%       hfn = 3 * (rand(FrameLength,1) < 0.02);
%       x = sine() + 1e-2 * randn(FrameLength,1) + hfn;
%       y1 = medfilt(x);
%       y2 = hampfilt(x);
%       scope(x,y1,y2);
%   end
%
%   % EXAMPLE 2: Plot the input and out signals while marking the outliers. 
%
%   Fs = 1000;
%   scope  = timescope('SampleRate',Fs,...
%       'TimeSpanSource','property',...
%       'TimeSpan',1,...
%       'YLimits',[-3 3],...
%       'LayoutDimensions',[3 1]);
%   scope.ActiveDisplay = 1;
%   scope.Title = 'Signal + Noise';
%   scope.ActiveDisplay = 2;
%   scope.Title = 'Hampel Filter Output (Window Length = 7)';
%   scope.ActiveDisplay = 3;
%   scope.Title = 'Outlier Status';
%   
%   FrameLength  = 256;
%   WindowLength = 7;
%   
%   hampfilt   = dsp.HampelFilter(WindowLength);
%   
%   sine = dsp.SineWave('SampleRate',Fs,'Frequency',10,...
%       'SamplesPerFrame',FrameLength);
%   tic;
%   while (toc < 5)
%       hfn = 3 * (rand(FrameLength,1) < 0.02);
%       x = sine() + 1e-2 * randn(FrameLength,1) + hfn;
%       [y,isOutlier] = hampfilt(x);
%       scope(x,y,isOutlier);
%   end
%
%   See also hampel, dsp.MedianFilter, dsp.MovingAverage

 
%   Copyright 2016-2021 The MathWorks, Inc.

    methods
        function out=HampelFilter
        end

        function out=getNumChans(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
            % Support mutable input size
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
            %  Get the number of input channels
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

    end
    properties
        % NumChannels Cached number of channels (used for error checking)
        NumChannels;

        % Threshold Outlier detection threshold (standard deviations)
        % Specify the outlier threshold as a nonnegative, scalar number. 
        % This property is tunable.
        Threshold;

        % WindowLength Window length 
        % Specify the sliding window length as a positive, odd, scalar 
        % integer. The default is 11.
        WindowLength;

        % pMID Internal object used to Hampel filter
        pMID;

        % pNumChannels Cached number of channels (used to allocate state)
        pNumChannels;

    end
end
