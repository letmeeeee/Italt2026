classdef DCBlocker< matlab.System
%DCBlocker Block DC component from input signal
%   DCB = dsp.DCBlocker returns a System object, DCB, that blocks the DC
%   component from each channel (i.e. column) of an input signal. Operation
%   runs over time to continually estimate and remove the DC offset.
%
%   DCB = dsp.DCBlocker('PropertyName', PropertyValue, ...) returns a DC
%   blocker System object, DCB, with each specified property set to the
%   specified value.  You can specify additional name-value pair arguments
%   in any order as (Name1,Value1,...,NameN,ValueN).
%
%   Step method syntax:
%
%   Y = step(DCB, X) removes the DC component of the input X, returning the
%   result in Y. X is a numeric, signed matrix, with time samples recorded
%   in rows and independent channels of data recorded in columns.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   DCBlocker methods:
%
%   step     - See above description for use of this method
%   <a href="matlab:help matlab.System/reset   ">reset</a>    - Reset internal states stored for mean computation
%   release  - Allow property value and input characteristics changes
%   clone    - Create DCBlocker object with same property values
%   isLocked - Locked status (logical)
%   fvtool   - Visualize the DC blocker's frequency response
%
%   DCBlocker properties:
%
%   Algorithm           - Algorithm for estimating DC offset
%   NormalizedBandwidth - Normalized bandwidth of lowpass IIR or CIC filter 
%   Order               - Order of lowpass IIR elliptic filter
%   Length              - Number of past input samples for FIR algorithm
%
%   % EXAMPLE: Remove a DC offset from a signal using 'FIR', 'IIR', and 
%   % 'Subtract mean' techniques. Loop to allow the IIR algorithm to 
%   % converge.
%   t = (0:0.001:100)';
%   x = sin(30*pi*t) + 1;
%   dcblock1 = dsp.DCBlocker('Order', 6);   % IIR is the default algorithm
%   dcblock2 = dsp.DCBlocker('Algorithm', 'FIR', 'Length', 100);
%   dcblock3 = dsp.DCBlocker('Algorithm', 'Subtract mean');
%   for index = 1:100
%       range = (1:1000) + 1000*(index-1);
%       y1 = dcblock1(x(range));
%       y2 = dcblock2(x(range));
%       y3 = dcblock3(x(range));
%   end
%   plot(t(1:1000),x(1:1000),...
%       t(1:1000),y1, ...
%       t(1:1000),y2, ...
%       t(1:1000),y3);
%   legend(sprintf('Input DC: %.3f', mean(x)), ...
%       sprintf('IIR DC: %.3f', mean(y1)), ...
%       sprintf('FIR DC: %.3f', mean(y2)), ...
%       sprintf('Subtract mean DC: %.3f', mean(y3)));
%
%   See also dsp.FIRFilter, dsp.BiquadFilter, dsp.CICDecimator.

   
%   Copyright 2013-2023 The MathWorks, Inc.

    methods
        function out=DCBlocker
        end

        function out=fvtool(~) %#ok<STOUT>
            % With fvtool, visualize the DC blocker's response. Visualize the
            % magnitude response, phase response, group delay, impulse response, or
            % pole-zero plot, and view the coefficients.
        end

        function out=getFVTOOLFilter(~) %#ok<STOUT>
        end

        function out=getNumChannels(~) %#ok<STOUT>
            % GETNUMCHANNELS Return the number of input channels
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
            % True if property should not be displayed
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=prepareFilter(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Initialize internal values on first use.
        end

        function out=stepImpl(~) %#ok<STOUT>
            % Block DC component of input signals
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            % Input must be numeric or fi.  Must be signed.
        end

    end
    properties
        %Algorithm Algorithm for estimating DC offset
        %  Specify the DC offset estimating algorithm as one of 'IIR' | 'FIR' |
        %  'CIC' | 'Subtract mean'.  The default is 'IIR'. You can visualize the
        %  IIR, FIR. and CIC responses with the fvtool method.
        %
        %  'IIR' uses a recursive estimate based on a narrow, lowpass elliptic
        %  filter whose order is set using the Order property and whose bandwidth
        %  is set using the NormalizedBandwidth property. This algorithm may use
        %  less memory than FIR and be more efficient.
        %
        %  'FIR' uses a non-recursive, moving average estimate based on a finite
        %  number of past input samples that is set using the Length property.
        %  This algorithm may use more memory than IIR and be less efficient.
        %
        %  'CIC' uses a CIC decimator, with a decimation factor of 1, whose
        %  differential delay is calculated using the NormalizedBandwidth
        %  property.  It uses two sections to ensure that the first sidelobe
        %  attenuation is at least 25 dB below the filter's main lobe.  This
        %  algorithm requires fixed-point inputs, and can be used for HDL code
        %  generation.
        %  
        %  'Subtract mean' computes the means of the columns of the input matrix,
        %  and subtracts the means from the input.  This method does not retain
        %  state between inputs.
        Algorithm;

        % Length  Number of past input samples for FIR algorithm
        % Specify the number of past inputs used to estimate the running mean.
        % This property applies when you set the Algorithm property to 'FIR'.
        % It must be a positive integer. The default value is 50.
        Length;

        %NormalizedBandwidth  Normalized bandwidth of lowpass IIR or CIC filter
        %  Specify the normalized bandwidth of the IIR or CIC filter used to
        %  estimate the DC component of the input signal. This property applies
        %  when you set the Algorithm property to 'IIR' or 'CIC'. It must be a
        %  real scalar greater than 0 and less than 1. The default value is
        %  0.001.
        NormalizedBandwidth;

        % Order   Order of lowpass IIR elliptic filter
        % Used when Algorithm is 'IIR'.  Specify the order of a lowpass elliptic
        % filter that estimates the DC level.  This property applies when you set
        % the Algorithm property to 'IIR'.  It must be an integer greater than 3.
        % The default value is 6.
        Order;

        % pNumChannels Number of input channels
        pNumChannels;

    end
end
