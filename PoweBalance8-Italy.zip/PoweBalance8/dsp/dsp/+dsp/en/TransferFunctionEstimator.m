classdef TransferFunctionEstimator< matlab.System
%TransferFunctionEstimator Estimate frequency-domain transfer function
%   TFE = dsp.TransferFunctionEstimator returns a System object, TFE, that 
%   computes the transfer function of real or complex input and output 
%   signals via the periodogram method and Welch's averaged, modified 
%   periodogram method.
%
%   TFE = dsp.TransferFunctionEstimator(Name=Value, ...) returns a Transfer
%   Function Estimator System object, TFE, with each specified property
%   name set to the specified value. You can specify additional name-value
%   pair arguments in any order as (Name1=Value1,...,NameN=ValueN).
%
%   Step method syntax:
%
%   Hxy = step(TFE, X, Y) computes the transfer function, Hxy, of the
%   system with input X and output Y using Welch's averaged periodogram
%   method. Hxy is equal to Pyx./Pxx, where Pyx is the cross power spectral
%   density of X and Y, and Pxx is the power spectral density of X. X and Y
%   must be of the same size. The columns of X and Y are treated as
%   independent channels.
%
%   [Hxy,Cxy] = step(TFE, X, Y) also computes the magnitude squared
%   coherence estimate, Cxy, of the system using Welch's averaged
%   periodogram method. Cxy is equal to (abs(Pxy).^2)./(Pxx.*Pyy), where
%   Pxy is the cross power spectral density of Y and X, Pxx is the power
%   spectral density of X, and Pyy is the power spectral density of Y. For
%   coherence to be estimated, OutputCoherence must be set to true.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   TransferFunctionEstimator methods:
%
%   step                 - Compute Transfer Function of inputs (see above)
%   release              - Allow property value and input characteristics 
%                          changes, and release Transfer Function resources
%   clone                - Create Transfer Function object with same 
%                          property values
%   isLocked             - Display locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>                - Reset the states of the Transfer Function
%                          Estimator
%   getRBW               - Get the resolution bandwidth of the spectrum
%   getFrequencyVector   - Get the vector of frequencies at which the
%                          spectrum is estimated
%
%   TransferFunctionEstimator properties:
%
%   
%   FFTLengthSource           - Source of the FFT length value
%   FFTLength                 - FFT length
%   Window                    - Window function
%   SidelobeAttenuation       - Sidelobe attenuation of window
%   FrequencyRange            - Frequency range of the Spectrum estimate
%   AveragingMethod           - Averaging method
%   SpectralAverages          - Number of spectral averages
%   ForgettingFactor          - Forgetting factor
%   OutputCoherence           - Output magnitude squared coherence estimate
%
%   % EXAMPLE: Estimate transfer function of system represented by order-31
%   % FIR filter
%   SINE = dsp.SineWave(Frequency=100, SampleRate=1000,...
%                       SamplesPerFrame=1000);
%   TFE  = dsp.TransferFunctionEstimator(FrequencyRange="centered",...
%                                        OutputCoherence=true);
%   TFEPlotter = dsp.ArrayPlot(PlotType="Line",...
%                              XOffset=-500,...
%                              YLimits=[-120 5],...
%                              YLabel="Frequency Response (dB)",...
%                              XLabel="Frequency (Hz)",...
%                              Title="System Transfer Function");
% 
%   CoherencePlotter = dsp.ArrayPlot(PlotType="Line",...
%                                    XOffset=-500,...
%                                    YLimits=[0 1],...
%                                    YLabel="Coherence",...
%                                    XLabel="Frequency (Hz)",...
%                                    Title="System Coherence");
%     
%   LP = dsp.FIRFilter(Numerator=firceqrip(30,1/4,[0.05 0.03]));
%     
%   tic;
%   while toc < 5
%      % generate input
%      x = SINE() + .1*randn(1000,1);
%      % pass through FIR filter
%      y = LP(x);
%      % estimate transfer function
%      [Txy,Cxy] = TFE(x,y);
%      % plot transfer function
%      TFEPlotter(20*log10(abs(Txy)))
%      CoherencePlotter(Cxy)
%   end
%
%   See also dsp.SpectrumEstimator, dsp.CrossSpectrumEstimator, 
%            spectrumAnalyzer.

 
%   Copyright 2013-2021 The MathWorks, Inc.

    methods
        function out=TransferFunctionEstimator
            %TransferFunctionEstimator Construct the TransferFunctionEstimator 
            % class.
        end

        function out=getFrequencyVector(~) %#ok<STOUT>
            % getFrequencyVector Get the vector of frequencies at which the 
            % transfer function is estimated, in Hz. 
            %
            %   F = getFrequencyVector(obj,Fs) returns the vector of frequencies, F,
            %   at which the transfer function is estimated, in Hz. Fs is the input
            %   sample rate, in Hz. Fs is the input sample rate, in Hz. If you set
            %   the FrequencyRange to 'onesided' and the FFT length, NFFT, is even,
            %   the frequency vector is of length NFFT/2+1 and it covers the
            %   interval [0,SampleRate/2]. If you set the FrequencyRange to
            %   'onesided' and NFFT is odd, the frequency vector is of length
            %   (NFFT+1)/2 and it covers the interval [0,SampleRate/2). If you set
            %   the FrequencyRange to 'twosided', the frequency vector is of length
            %   NFFT and it covers the interval [0, SampleRate). If you set the
            %   FrequencyRange to 'centered', the frequency vector is of length NFFT
            %   and it covers the range (-SampleRate/2, SampleRate/2] for even
            %   length NFFT, and (-SampleRate/2, SampleRate/2) for odd length NFFT.
            %
            %   F = getFrequencyVector(obj) returns the frequency vector assuming an
            %   input sample rate (Fs) of 1 Hz.
        end

        function out=getNumInputsImpl(~) %#ok<STOUT>
            % Two inputs: x (input system data) and y (output system data)
        end

        function out=getNumOutputsImpl(~) %#ok<STOUT>
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
            %Get default parameters group for this System object
        end

        function out=getRBW(~) %#ok<STOUT>
            % getRBW Get the resolution bandwidth of the transfer function 
            %   estimate, in Hz. 
            %
            %   RBW = getRBW(obj,Fs) returns the resolution bandwidth, RBW, of the
            %   transfer function estimate, in Hz. Fs is the input sample rate, in
            %   Hz. The resolution bandwidth is the smallest positive frequency, or
            %   frequency interval, that can be resolved. It is equal to ENBW * Fs/
            %   L, where L is the input length, and ENBW is the two-sided
            %   equivalent noise bandwidth of the window (in Hz). For example, if
            %   Fs = 100, L = 1024, and Window = 'Hann', RBW = enbw(hann(1024)) *
            %   100 / 1024
            %
            %  RBW = getRBW(obj) returns the resolution bandwidth assuming an input
            %  sample rate (Fs) of 1 Hz.
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
            % Release the Spectrum and cross-spectrum objects
        end

        function out=resetImpl(~) %#ok<STOUT>
            % Reset the Spectrum and cross-spectrum objects
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=setupPyyEstimator(~) %#ok<STOUT>
            % Setup Pyy estimator for coherence output
        end

        function out=stepImpl(~) %#ok<STOUT>
            % Compute the spectrum estimate of x
        end

        function out=validateForgettingFactor(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

    end
    properties
        % AveragingMethod Averaging method 
        %   Specify the averaging method as 'Running' or 'Exponential'. In the
        %   running averaging method, the object computes an equally weighted
        %   average of specified number of spectrum estimates defined by
        %   'SpectralAverages' property. In the exponential method, the object
        %   computes the average over samples weighted by an exponentially
        %   decaying forgetting factor. The default is 'Running'.
        AveragingMethod;

        %FFTLength FFT length
        %   Specify the length of the FFT that the Transfer Function Estimator 
        %   uses to compute spectral estimates as a positive, integer scalar. 
        %   This property applies when you set the FFTLengthSource property to
        %   'Property'. The default is 128.
        FFTLength;

        %FFTLengthSource Source of the FFT length value
        %   Specify the source of the FFT length value as one of 'Auto' |
        %   'Property'. The default is 'Auto'. When you set this property to
        %   'Auto' the Transfer function Estimator sets the FFT length to the 
        %   input frame size. When you set this property to 'Property' then you 
        %   specify the number of FFT points using the FFTLength property.
        FFTLengthSource;

        %ForgettingFactor Forgetting factor
        %   Specify the exponential weighting forgetting factor as a scalar value
        %   greater than zero and smaller than or equal to one. This property
        %   applies when 'AveragingMethod' is equal to 'Exponential'. The default
        %   is 0.9. This property is tunable.
        ForgettingFactor;

        % FrequencyRange Frequency range
        %   Specify the frequency range of the transfer function estimator as one 
        %   of 'twosided' | 'onesided' | 'centered'. 
        %   If you set the FrequencyRange to 'onesided', the transfer function 
        %   estimator computes the one-sided transfer function of real input 
        %   signals X and Y. When the FFT length, NFFT, is even, the transfer
        %   function estimate length is NFFT/2+1 and is computed over the 
        %   interval [0,SampleRate/2]. If NFFT is odd, the length of the transfer 
        %   function estimate is equal to (NFFT+1)/2 and the interval is 
        %   [0,SampleRate/2).
        %   If you set the FrequencyRange to 'twosided', the transfer function 
        %   estimator computes the two-sided transfer function of complex or real 
        %   inputs signals X and Y. The length of the transfer function estimate
        %   is equal to NFFT and is computed over [0, SampleRate). 
        %   If you set the FrequencyRange to 'centered', the transfer function 
        %   estimator computes the centered two-sided transfer function of 
        %   complex or real inputs signals X and Y. The length of the transfer 
        %   function estimate is equal to NFFT and is computed over 
        %   (-SampleRate/2, SampleRate/2] and (-SampleRate/2, SampleRate/2) for 
        %   even and odd length NFFT, respectively. 
        %   The default is 'twosided'
        FrequencyRange;

        % Output magnitude squared coherence estimate
        %   Set this property to true to output the magnitude squared coherence
        %   estimate. The default value of this property is false.
        OutputCoherence;

        %SidelobeAttenuation Sidelobe attenuation of window (dB)
        %   Specify the sidelobe attenuation of the window as a real, positive
        %   scalar in decibels (dB). This property applies when you set the 
        %   Window property to 'Chebyshev' or 'Kaiser'. The default is 60 dB.
        SidelobeAttenuation;

        %SpectralAverages Number of spectral averages
        %   Specify the number of spectral averages as a positive, integer
        %   scalar. The Transfer Function Estimator computes the current estimate
        %   by averaging the last N estimates, where N is the number of spectral
        %   averages defined in the SpectralAverages property. This property
        %   applies when 'AveragingMethod' is equal to 'Running'. The default
        %   is 8.
        SpectralAverages;

        %Window Window function
        %   Specify a window function for the Transfer Function estimator as one 
        %   of 'Rectangular' | 'Chebyshev' | 'Flat Top' | 'Hamming' | 'Hann' |
        %   'Kaiser'. The default is 'Hann'.
        Window;

    end
end
