classdef Differentiator< dsp.internal.FilterAnalysis & matlab.System
%Differentiator Direct form FIR full band differentiator filter
%   DF = dsp.Differentiator returns a differentiator filter, DF,
%   which independently filters each channel of the input over time
%   using the given design specifications.
%
%   DF = dsp.Differentiator('PropertyName', PropertyValue, ...)
%   returns a differentiator filter, DF, with each specified property
%   set to the specified value.
%
%   Step method syntax:
%
%   Y = step(DF, X) filters the real or complex input signal X using
%   the specified filter to produce the output Y. Each column of the
%   input signal is filtered independently over time.
%
%   System objects may be called directly like a function instead of
%   using the step method. For example, y = step(obj, x) and y = obj(x)
%   are equivalent.
%
%   Differentiator methods:
%
%   step      - See above description for use of this method
%   getFilter - Return underlying FIR filter
%   release   - Allow property values and input characteristics changes
%   clone     - Create differentiator filter object with same property 
%               values
%   isLocked  - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>     - Reset the internal states to initial conditions
%
%   Differentiator properties:
%
%   DesignForMinimumOrder  - Option for minimum/specify order design
%   FilterOrder            - Order of the filter
%   PassbandRipple         - Allowed passband ripple of differentiator
%                            filter
%   ScaleCoefficients      - Option to scale the filter coefficients
%
%   This System object supports several filter analysis methods. For
%   more information, type dsp.FIRHalfbandDecimator.helpFilterAnalysis.
%
%   This System object supports fixed-point operations. For more
%   information, type dsp.Differentiator.helpFixedPoint.
%
%   % EXAMPLE: Convert a 50 Hz signal frequency-modulated (FM) on a 
%   % 50 kHz carrier signal sampled at 1 MHz to an amplitude-modulated 
%   % signal
%
%   % Create an FM wave
%   Fc = 1e2; % 100 Hz carrier
%   Fs = 1.5e3; % 1.5 kHz sample rate
%   
%   sinewave = dsp.SineWave('Frequency',10,...
%                           'SamplesPerFrame',1e3,...
%                           'SampleRate',Fs);
%   
%   % Convert it to AM
%   scope = timescope('TimeSpanSource','property', ...
%                     'TimeSpan',0.3,...
%                     'SampleRate',Fs,...
%                     'YLimits',[-1.5 1.5],...
%                     'LayoutDimensions',[2 1]);
%                 
%   dif = dsp.Differentiator;
%   
%   tic
%   while toc<5
%       x = step(sinewave);
%       fm_y = modulate(x,Fc,Fs,'fm');
%       am_y = dif(fm_y);
%       scope(fm_y,am_y);
%   end
%   
%   release(dif);
%   release(scope);
%
%   See also dsp.HighpassFilter, dsp.VariableBandwidthFIRFilter,
%   dsp.VariableBandwidthIIRFilter, dsp.FIRFilter, dsp.BiquadFilter.

     
    % Copyright 2015-2020 The MathWorks, Inc.

    methods
        function out=Differentiator
            % Support name-value pair arguments
        end

        function out=computeFIRCoefficients(~) %#ok<STOUT>
            % For strict single precision code generation, etc.
        end

        function out=convertToDFILT(~) %#ok<STOUT>
            % Convert the System object to a dfilt object for analysis
        end

        function out=designFilter(~) %#ok<STOUT>
            % Design and construct the filter System object
        end

        function out=getFilter(~) %#ok<STOUT>
            %F = getFilter(obj) get underlying FIR filter
            %   F = getFilter(obj) returns the underlying filter F
            %   used to implement the filter designed for the given
            %   specifications.
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
        end

        function out=helpFixedPoint(~) %#ok<STOUT>
            %helpFixedPoint Display Differentiator System
            %               object fixed-point information
            %   dsp.Differentiator.helpFixedPoint displays
            %   information about fixed-point properties and operations of
            %   the Differentiator System object.
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
            % Support mutable input size
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=needToDesignFilters(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
            % Release the filter
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Save public properties
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
            % Implement algorithm. Calculate y as a function of
            % input u and discrete states.
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            % input cannot be unsigned complex fixed-point
        end

    end
    properties
        %CoefficientsDataType Coefficients word and fraction lengths
        %   Specify the coefficients fixed-point type as a signed
        %   numerictype object. The default value of this property is
        %   numerictype(1,16).
        %
        %   See also numerictype.
        CoefficientsDataType;

        %DesignForMinimumOrder Design minimum order filter
        %   When you set this property to true, the object designs filters
        %   with the minimum order that meets the specified passband
        %   ripple. When you set this property to false, the object designs
        %   filters with order that you specify in the FilterOrder
        %   property. Specify it as a logical scalar. The default value of
        %   this property is true.
        DesignForMinimumOrder;

        FilterObj;

        %FilterOrder Filter order
        %   Specify the order for the designed filter, as a positive
        %   integer scalar. This property applies when you set the
        %   DesignForMinimumOrder property to false. The default value of
        %   this property is 31.
        FilterOrder;

        IsFilterDesigned;

        NumChannels;

        %PassbandRipple Maximum passband ripple (dB)
        %   Specify the maximum allowed ripple in the passband of the
        %   filter's response, as a positive real scalar in decibels (dB).
        %   The default value of this property is 0.1 dB.
        PassbandRipple;

        %RoundingMethod Rounding method for fixed-point operations 
        %   Specify the rounding method for output as one of ['Ceiling' |
        %   'Convergent' | 'Floor' | 'Nearest' | 'Round' | 'Simplest' |
        %   'Zero']. The default value of this property is 'Floor'.
        RoundingMethod;

        %ScaleCoefficients Scale filter coefficients
        %   When you set this property to true, the filter coefficients
        %   will be scaled to preserve the input dynamic range. Specify it
        %   as a logical scalar. The default value of this property is
        %   false.
        ScaleCoefficients;

    end
end
