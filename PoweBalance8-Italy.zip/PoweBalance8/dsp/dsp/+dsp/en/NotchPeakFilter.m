classdef NotchPeakFilter< dsp.internal.SampleRateEngine & dsp.internal.FilterAnalysis
%NotchPeakFilter Second-order tunable notching and peaking IIR filter.
%   NF = dsp.NotchPeakFilter returns a second-order notching and
%   peaking IIR filter which independently filters each channel of the
%   input over time using a specified center frequency and 3 dB
%   bandwidth. Both of these properties are specified in Hz and are
%   tunable. Both of these values must be scalars between 0 and half
%   the sample rate.
%
%   NF = dsp.NotchPeakFilter(Name=Value, ...) returns a notch filter
%   with each specified property name set to the specified value. You
%   can specify additional name-value pair arguments in any order as
%   (Name1=Value1,...,NameN=ValueN).
%
%   NF = dsp.NotchPeakFilter('Specification', 'Quality factor and
%   center frequency') specifies the quality factor (Q factor) of the
%   notch/peak filter instead of the 3 dB bandwidth. The Q factor is
%   defined as the center frequency/bandwidth. A higher Q factor
%   corresponds to a narrower notch/peak. The Q factor should be a
%   scalar value greater than 0. The Q factor is tunable.
%
%   NF = dsp.NotchPeakFilter('Specification', 'Coefficients') specifies
%   the coefficient values that affect bandwidth and center frequency
%   directly rather than specifying the design parameters in Hz. This
%   removes the trigonometry calculations involved when the properties
%   are tuned. The CenterFrequencyCoefficient should be a scalar
%   between -1 and 1, with -1 corresponding to 0 Hz and 1 corresponding
%   to the Nyquist frequency. The BandwidthCoefficient should be a
%   scalar between -1 and 1, with -1 corresponding to the largest 3 dB
%   bandwidth and 1 corresponding to the smallest 3 dB bandwidth. Both
%   coefficient values are tunable.
%
%   Step method syntax:
%
%   [Yn,Yp] = step(NF, X) filters the real or complex input signal X
%   using the specified filter to produce the notch filter output, Yn,
%   and the peak filter output Yp. The filter processes each channel of
%   the input signal (each column of X) independently over time. The
%   peak filter output is optional and is computed efficiently using
%   most of the same computation used to compute the notch filter.
%
%   System objects may be called directly like a function instead of
%   using the step method. For example, y = step(obj, x) and y = obj(x)
%   are equivalent.
%
%   NotchPeakFilter methods:
%
%   step                          - See above description for use of
%                                  this method
%   release                       - Allow property value and input
%                                   characteristics changes
%   clone                         - Create NotchPeakFilter object with
%                                   same property values
%   isLocked                      - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>                         - Reset the internal states to
%                                   initial conditions
%   getBandwidth                  - Convert quality factor or bandwidth
%                                   coefficient to bandwidth in Hertz
%   getBandwidthCoefficient       - Convert quality factor or bandwidth
%                                   to bandwidth coefficient value
%   getOctaveBandwidth            - Bandwidth measured in number of
%                                   octaves
%   getCenterFrequency            - Convert center frequency 
%                                   coefficient to Hertz
%   getCenterFrequencyCoefficient - Convert center frequency to
%                                   coefficient
%   getQualityFactor              - Convert bandwidth to quality factor 
%   tf                            - Transfer function for
%                                   notch/peak filter
%
%   NotchPeakFilter properties:
%
%   Specification              - Design parameters or Coefficients
%   Bandwidth                  - 3 dB bandwidth in Hz
%   CenterFrequency            - Center frequency of the notch filter
%                                in Hz
%   QualityFactor              - Quality (Q) factor
%   SampleRate                 - Sample rate of input in Hz
%   BandwidthCoefficient       - Bandwidth coefficient value (-1 to 1)
%   CenterFrequencyCoefficient - Center frequency coefficient (-1 to 1)
%
%   This System object supports several filter analysis methods. For
%   more information, type dsp.NotchPeakFilter.helpFilterAnalysis.
%
%   % EXAMPLE: Notch/Peak filter with center frequency of 5000 Hz and 3 
%   % dB bandwidth of 500 Hz.
%   NF = dsp.NotchPeakFilter(CenterFrequency=5000,Bandwidth=500);
%   SA =  spectrumAnalyzer(SampleRate=44100,...
%       PlotAsTwoSidedSpectrum=false, ...
%       AveragingMethod="exponential", ...
%       ForgettingFactor = 0.7);
%   for i=1:5000
%       y = NF(randn(1024,1));
%       SA(y);
%       if (i==2500)
%           % Tune center frequency to 10000
%           NF.CenterFrequency = 10000;
%       end
%   end
%
%   See also dsp.BiquadFilter, iirnotch, iirpeak.

     
    % Copyright 2013-2023 The MathWorks, Inc.

    methods
        function out=NotchPeakFilter
            %NotchPeakFilter Construct the NotchPeakFilter class.
        end

        function out=convertToDFILT(~) %#ok<STOUT>
        end

        function out=cost(~) %#ok<STOUT>
        end

        function out=crossValidateProperties(~) %#ok<STOUT>
        end

        function out=getBandwidth(~) %#ok<STOUT>
            %BW = getBandwidth(obj) get 3 dB bandwidth
            %   BW = getBandwidth(obj) returns the 3 dB bandwidth for the
            %   notch/peak filter. If the Specification is set to 'Quality
            %   factor and center frequency', the 3 dB bandwidth is
            %   determined from the quality factor value. If the 
            %   Specification property is set to 'Coefficients', the 3 dB
            %   bandwidth is determined from the BandwidthCoefficient value
            %   and the sample rate.
        end

        function out=getBandwidthCoefficient(~) %#ok<STOUT>
            %BWC = getBandwidthCoefficient(obj) get bandwidth coefficient
            %   BWC = getBandwidthCoefficient(obj) returns lattice allpass
            %   filter coefficient corresponding to the 3 dB bandwidth for
            %   the notch/peak filter. If the Specification is set to
            %   'Quality factor and center frequency', the 3 dB bandwidth
            %   is determined from the quality factor value.
        end

        function out=getCenterFrequency(~) %#ok<STOUT>
            %CF = getCenterFrequency(obj) get center frequency
            %   CF = getCenterFrequency(obj) returns the center frequency
            %   for the notch/peak filter. If the Specification property is
            %   set to 'Coefficients', the center frequency is determined
            %   from the CenterFrequencyCoefficient value and the sample
            %   rate.
        end

        function out=getCenterFrequencyCoefficient(~) %#ok<STOUT>
            %CFC = getCenterFrequencyCoefficient(obj) get center freq coeff
            %   CFC = getCenterFrequencyCoefficient(obj) returns the
            %   lattice allpass coefficient corresponding to the center
            %   frequency for the notch/peak filter.
        end

        function out=getHeaderImpl(~) %#ok<STOUT>
            % MATLAB System block header
        end

        function out=getNumInputsImpl(~) %#ok<STOUT>
            % Specify number of System inputs
        end

        function out=getNumOutputsImpl(~) %#ok<STOUT>
            % Specify number of System outputs
        end

        function out=getOctaveBandwidth(~) %#ok<STOUT>
            %N = getOctaveBandwidth(obj) bandwidth in number of octaves
            %   N = getOctaveBandwidth(obj) returns the bandwidth of the
            %   notch/peak filter measured in number of octaves rather than
            %   Hz.
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
            % Modify order of display
        end

        function out=getQualityFactor(~) %#ok<STOUT>
            %Q = getQualityFactor(obj) get quality (Q) factor
            %   Q = getQualityFactor(obj) returns the quality factor (Q
            %   factor) for both the notch and peak filter. The Q factor is
            %   defined as the center frequency divided by the bandwidth.
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Re-load state if saved version was locked
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
            % Specify initial values for DiscreteState properties
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Default implementation saves all public properties
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Implement any tasks that need to be performed only once, such
            % as computation of constants or creation of child System objects
        end

        function out=stepImpl(~) %#ok<STOUT>
            % Implement System algorithm. Calculate y as a function of
            % input u and state.
        end

        function out=tf(~) %#ok<STOUT>
            %[B,A,B2,A2] = tf(obj) Transfer function
            %   [B,A] = TF(obj) returns the vector of numerator
            %   coefficients B and the vector of denominator coefficients A
            %   for the equivalent transfer function corresponding to the
            %   notch filter.
            %
            %   [B,A,B2,A2] = TF(obj) returns the vector of numerator
            %   coefficients B2 and the vector of denominator coefficients
            %   A2 for the equivalent transfer function corresponding to
            %   the peak filter.
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

    end
    properties
        %Bandwidth 3 dB bandwidth (Hz)
        %   Specify the filter's 3 dB bandwidth as a finite positive
        %   numeric scalar in Hertz. The default is 2205 Hz. This property
        %   applies when you set Specification to 'Bandwidth and center
        %   frequency'. This property is tunable.
        Bandwidth;

        %BandwidthCoefficient Bandwidth coefficient
        %   Specify the value that determines the filter's 3 dB bandwidth
        %   as a finite numeric scalar between -1 and 1. -1 corresponds to
        %   the maximum 3 dB bandwidth (SampleRate/4). 1 corresponds to the
        %   minimum 3 dB bandwidth (0 Hz; i.e. an allpass filter). The
        %   default is 0.72654. This property applies when you set
        %   Specification to 'Coefficients'. This property is tunable.
        BandwidthCoefficient;

        %CenterFrequency Notch/Peak center frequency (Hz)
        %   Specify the filter's center frequency (for both the notch and
        %   the peak) as a finite positive numeric scalar in Hertz. The
        %   default is 11025 Hz. This property applies when you set
        %   Specification to 'Bandwidth and center frequency' or 'Quality
        %   factor and center frequency'. This property is tunable.
        CenterFrequency;

        %CenterFrequencyCoefficient Center frequency coefficient
        %   Specify the value that determines the filter's center frequency
        %   as a finite numeric scalar between -1 and 1. -1 corresponds to
        %   the minimum center frequency (0 Hz). 1 corresponds to the
        %   maximum center frequency (SampleRate/2 Hz). The default is 0
        %   which corresponds to SampleRate/4 Hz. This property applies
        %   when you set Specification to 'Coefficients'. This property is
        %   tunable.
        CenterFrequencyCoefficient;

        %InputDataType Data type of the inputs
        %   This is a private property that stores the data type of the
        %   inputs and it is used to set the data type of all the
        %   DiscreteState properties and the outputs.
        InputDataType;

        %QualityFactor Quality factor
        %   Specify the quality factor (Q factor) for both the notch and
        %   peak filter. The Q factor is defined as the center frequency
        %   divided by the bandwidth. The default value is 5. This property
        %   applies when you set Specification to 'Quality factor and
        %   center frequency'. This property is tunable.
        QualityFactor;

        % SampleRate Input sample rate (Hz)
        %   Specify the sampling rate of the input in Hertz as a finite
        %   numeric scalar. The default is 44100 Hz.
        SampleRate;

        %Specification Filter specification
        %   Set the specification as one of 'Bandwidth and center
        %   frequency' | 'Quality factor and center frequency' | 
        %   'Coefficients'. The default is 'Bandwidth and center
        %   frequency'.
        Specification;

        pNumChannels;

    end
end
