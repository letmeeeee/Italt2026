classdef SignalSink< matlab.System
%SignalSink Log simulation data in MATLAB
%   SIGLOG = dsp.SignalSink returns a signal logger System object, SIGLOG,
%   that logs 2-D input data in the object. This object accepts any numeric
%   data type.
%
%   SIGLOG = dsp.SignalSink('PropertyName', PropertyValue, ...) returns a
%   signal logger System object, SIGLOG, with each specified property set to
%   the specified value.
%
%   Step method syntax:
%
%   step(SIGLOG, Y) buffers the signal Y. The buffer may be accessed at any
%   time from the Buffer property of SIGLOG.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, step(obj, x) and obj(x) are equivalent.
%
%   SignalSink methods:
%
%   step     - See above description for use of this method
%   release  - Allow property value and input characteristics changes
%   clone    - Create signal logger object with same property values
%   isLocked - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>    - Clear the logged data
%
%   SignalSink properties:
%
%   BufferLength         - Maximum number of input samples or frames to log
%   Decimation           - Decimation factor
%   FrameHandlingMode    - Dimensionality of output for frame-based inputs
%   Buffer               - Logged data (read only)
%
%   % EXAMPLE: Log input data.
%       siglog = dsp.SignalSink;
%       for i = 1:10
%         y = sin(i);
%         siglog(y);
%       end
%       log = siglog.Buffer;  % log = sin([1;2;3;4;5;6;7;8;9;10]);
%
%   See also dsp.SignalSource.

 
%   Copyright 2009-2021 The MathWorks, Inc.

    methods
        function out=SignalSink
        end

        function out=getNumOutputsImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Save the public properties
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
            % Need to set this to false for the case when step is called after
            % reset.
        end

    end
    properties
        %Buffer Logged Data (read only)
        Buffer;

        %BufferLength Maximum number of input samples or frames to log
        %   Specify maximum number of most recent frames of data to log. To
        %   capture all data, set BufferLength to inf. The default value of this
        %   property is inf.
        BufferLength;

        %Decimation Decimation factor
        %   This property can be set to any positive integer d, and indicates
        %   that the System object writes data at every dth sample. The default
        %   value of this property is 1.
        Decimation;

        %FrameHandlingMode Output dimensionality
        %   Set the dimension of the output array as one of ['2-D array
        %   (concatenate)' | '3-D array (separate)']. Concatenation occurs along
        %   the first dimension for '2-D array (concatenate)'. The default is
        %   '2-D array (concatenate)'.
        FrameHandlingMode;

    end
end
