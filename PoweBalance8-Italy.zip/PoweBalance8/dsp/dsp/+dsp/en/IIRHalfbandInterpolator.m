classdef IIRHalfbandInterpolator< dsp.internal.IIRHalfbandBase
%IIRHalfbandInterpolator Interpolate by a factor of two using polyphase IIR
%   This System object lets you design and use interpolator that implements
%   IIR halfband structures. Allpass filters are used in the polyphase
%   branches. Filters can be designed either using elliptic or quasi-linear
%   phase design methods. You can convert this System object to a synthesis
%   filter bank.
%
%   IIRHALFBANDINTERP = dsp.IIRHalfbandInterpolator returns a System
%   object, IIRHALFBANDINTERP, that interpolates each channel of the input
%   signal by a factor of 2 using IIR halfband filters.
%
%   IIRHALFBANDINTERP = dsp.IIRHalfbandInterpolator(Name=Value, ...)
%   returns an IIR halfband interpolator System object, IIRHALFBANDINTERP,
%   with each specified property set to the specified value.
%
%   Step method syntax:
%
%   Y = step(IIRHALFBANDINTERP,X) outputs the interpolated values, Y, of
%   the input signal, X. A Ki-by-N input matrix is treated as N independent
%   channels, and the System object interpolates each channel over time and
%   generates a Ko-by-N output matrix. Ko = 2*Ki, where 2 is the
%   interpolation factor. The object supports real and complex
%   floating-point inputs.
%
%   Y = step(IIRHALFBANDINTERP,X1,X2) computes the output, Y of the
%   synthesis filter bank, IIRHALFBANDINTERP. IIRHALFBANDINTERP acts as a
%   synthesis filter bank when 'FilterBankInputPort' property of the System
%   object is true. X1 and X2 are two power-complementary input matrices of
%   the same data type and size Ki-by-N. N is the number of independent
%   channels in each input signal. The System object generates two
%   polyphase branch signals by subtracting and adding the two inputs
%   respectively. The output signals from the two branches are commuted to
%   form the resultant signal, Y, a Ko-by-N matrix. Ko = 2*Ki, where 2 is
%   the interpolation factor.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   IIRHalfbandInterpolator methods:
%   step     - See above description for use of this method
%   release  - Allow property value and input characteristics changes
%   clone    - Create IIR halfband interpolator object with same 
%              property values
%   isLocked - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>    - Reset the internal states to initial conditions
%
%   IIRHalfbandInterpolator properties:
%
%   SampleRate           - Input sample rate (Hz)
%   Specification        - Filter design parameter specification
%   FilterOrder          - Order of the filter
%   TransitionWidth      - Transition width of the IIR halfband filter
%   StopbandAttenuation  - Minimum attenuation needed in stopband of
%                          the IIR halfband filter (dB)
%   DesignMethod         - Design method for the IIR halfband filter
%   NormalizedFrequency  - Provide normalized frequencies for filter
%                          specifications
%   FilterBankInputPort  - Option to use object as synthesis filter bank
%   Structure            - Filter structure used in coefficient mode
%   AllpassCoefficients1 - Branch 1 coefficients, minimum multiplier
%   AllpassCoefficients2 - Branch 2 coefficients, minimum multiplier
%   WDFCoefficients1     - Branch 1 coefficients, wave digital  
%   WDFCoefficients2     - Branch 2 coefficients, wave digital
%   HasPureDelayBranch   - Branch 1 is a delay
%   Delay                - Value of branch 1 delay, in samples
%   HasTrailingFirstOrderSection - Branch 2, last section is 1st order 
%
%   This System object supports several filter analysis methods. For
%   more information, type
%   dsp.IIRHalfbandInterpolator.helpFilterAnalysis.
%
%   % Example 1: Interpolate a signal and plot the spectra 
%   
%   Fs = 5000; % Units: Hz
%   frameSize = 2000;
%   
%   SW = dsp.SineWave(Frequency=400, SampleRate=Fs, ...
%                     SamplesPerFrame=frameSize);
%   InputSA = spectrumAnalyzer(PlotAsTwoSidedSpectrum=false, ...
%                     SampleRate=Fs, ShowLegend=true, ...
%                     ChannelNames="Input");
%   OutputSA = spectrumAnalyzer(PlotAsTwoSidedSpectrum=false, ...
%                     SampleRate=Fs*2, ShowLegend=true, ...
%                     ChannelNames="Output");
%   
%   % Construct IIR Half band Interpolator
%   IIRHALFBANDINTERP = dsp.IIRHalfbandInterpolator(...
%       Specification="Filter order and transition width",...
%       FilterOrder=15, TransitionWidth=400, ...
%       SampleRate=Fs);
%   
%   for idx = 1:2000
%       Input = SW()+randn(frameSize,1);
%       Output = IIRHALFBANDINTERP(Input);
%       % Plot on scopes
%       InputSA(Input);
%       OutputSA(Output);
%   end
%   
%   % Example 2: Design a quasi-linear phase IIR halfband interpolator and
%   % display its frequency response
%   
%   IIRHALFBANDINTERP = dsp.IIRHalfbandInterpolator(...
%                       DesignMethod="Quasi-linear phase");
%   
%   % Obtain filter coefficients
%   c = coeffs(IIRHALFBANDINTERP);
%   
%   % Plot the Magnitude and Phase response
%   fvtool(IIRHALFBANDINTERP,Analysis="freq")
%
%   See also dsp.IIRHalfbandDecimator, dsp.FIRHalfbandInterpolator,
%            designHalfbandIIR, dsp.CoupledAllpassFilter

 
%   Copyright 2015-2023 The MathWorks, Inc.

    methods
        function out=IIRHalfbandInterpolator
            % Constructor
            % Support name-value pair arguments
        end

        function out=crossValidateProperties(~) %#ok<STOUT>
        end

        function out=getHeaderImpl(~) %#ok<STOUT>
            % MATLAB System block header
        end

        function out=getIconImpl(~) %#ok<STOUT>
            % MATLAB system block icon
        end

        function out=getInputNamesImpl(~) %#ok<STOUT>
            % Name of input ports (shows on block icon)
        end

        function out=getNumInputsImpl(~) %#ok<STOUT>
        end

        function out=getOutputDataTypeImpl(~) %#ok<STOUT>
        end

        function out=getOutputNamesImpl(~) %#ok<STOUT>
            % Name of output port (shows on block icon)
        end

        function out=getOutputSizeImpl(~) %#ok<STOUT>
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
        end

        function out=getTunablePropertiesSpecificationImpl(~) %#ok<STOUT>
        end

        function out=isDecimator(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isOutputComplexImpl(~) %#ok<STOUT>
        end

        function out=isOutputFixedSizeImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=postProcessSampleRate(~) %#ok<STOUT>
        end

        function out=realizemdl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=supportsMultipleInstanceImpl(~) %#ok<STOUT>
            % Support in for-each subsystem
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            % Checks on first input
        end

        function out=validatePropertiesImpl(~) %#ok<STOUT>
        end

    end
    properties
        %FilterBankInputPort Input highpass subband
        %   Specify if the interpolator should be a synthesis filter bank,
        %   as a logical scalar. When this property is set to false, the
        %   object acts as an interpolator. If the property is set to true,
        %   the object takes two inputs to the step method and acts as a
        %   synthesis filter bank. The default of this property is false.
        FilterBankInputPort;

        % SampleRate Input sample rate (Hz)
        %   Specify the sampling rate of the input in Hertz as a finite
        %   numeric scalar. the default is 22.0 MHz.
        SampleRate;

        %TransitionWidth Transition width 
        %   Specify the transition width for the designed IIR halfband
        %   filter as a finite positive scalar. Specify the value of
        %   transition width in Hertz when NormalizedFrequency is set to
        %   false and in normalized units when NormalizedFrequency is set
        %   to true. The transition width must be less than half the input
        %   sample rate. This property applies when the Specification is
        %   either 'Filter order and transition width' or 'Transition width
        %   and stopband attenuation'. The default value of this property
        %   is 4100 Hz.
        TransitionWidth;

        % pSR Default sample rate
        pSR;

    end
end
