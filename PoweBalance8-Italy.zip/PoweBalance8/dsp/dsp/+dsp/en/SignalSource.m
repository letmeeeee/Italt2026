classdef SignalSource< matlab.System & matlab.system.mixin.FiniteSource
%SignalSource Import variable from MATLAB workspace
%   SIGSRC = dsp.SignalSource returns a MATLAB variable reader System object
%   SIGSRC, that outputs the variable one sample or frame at a time.
%
%   SIGSRC = dsp.SignalSource('PropertyName', PropertyValue, ...) returns a
%   MATLAB variable reader System object, SIGSRC, with each specified
%   property set to the specified value.
%
%   SIGSRC = dsp.SignalSource(SIGNAL, SAMPLESPERFRAME, 'PropertyName',
%   PropertyValue, ...) returns a MATLAB variable reader System object,
%   SIGSRC, with the Signal property set to SIGNAL, the SamplesPerFrame
%   property set to SAMPLESPERFRAME, and other specified properties set to
%   the specified values.
%
%   Step method syntax:
%
%   Y = step(SIGSRC) outputs one sample or frame of data, Y, from each
%   column of the specified signal.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj) and y = obj() are
%   equivalent.
%
%   SignalSource methods:
%
%   step     - See above description for use of this method
%   release  - Allow property value and input characteristics changes
%   clone    - Create signal reader object with same property values
%   isLocked - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>    - Reset to the beginning of the signal
%   isDone   - True if last sample or frame of signal has been output
%
%   SignalSource properties:
%
%   Signal          - Value of, or variable containing the signal
%   SamplesPerFrame - Number of samples per output frame
%   SignalEndAction - Action after final signal values are generated
%
%   % EXAMPLE #1: Create a SignalSource System object to output one
%   % sample at a time.
%       sigsrc1 = dsp.SignalSource;
%       sigsrc1.Signal = randn(1024, 1);
%       y1 = zeros(1024,1);
%       idx = 1;
%       while ~isDone(sigsrc1)
%         y1(idx) = sigsrc1();  
%         idx = idx+1;
%       end
%
%   % EXAMPLE #2: Create a SignalSource System object to output vectors.
%       sigsrc2 = dsp.SignalSource(randn(1024, 1), 128);
%       y2 = sigsrc2();  % y2 is a 128-by-1 frame of samples
%
%   See also dsp.SignalSink.

 
%   Copyright 2007-2023 The MathWorks, Inc.

    methods
        function out=SignalSource
        end

        function out=getDiscreteStateImpl(~) %#ok<STOUT>
        end

        function out=getNumInputsImpl(~) %#ok<STOUT>
        end

        function out=isDoneImpl(~) %#ok<STOUT>
            %isDone True if last sample or frame of signal has been output
            %   isDone(OBJ) returns true if the SignalSource object, OBJ, has
            %   output the last sample or frame of the signal. If the
            %   SignalEndAction property is set to 'Cyclic repetition', this method
            %   returns true every time the last signal sample or frame is output,
            %   and false otherwise. If the SignalEndAction property is set to 'Set
            %   to zero' or 'Hold final value', this method always returns true
            %   once the object has output the last signal sample or frame.
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Save the public properties
        end

        function out=setDiscreteStateImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
            % reset the pDoneStatus if cycling
        end

        function out=validatePropertiesImpl(~) %#ok<STOUT>
        end

    end
    properties
        %SamplesPerFrame Number of samples per output frame
        %   Specify the number of samples to buffer into each output frame.
        %   This property must be 1 when you specify a 3-D array in the Signal
        %   property. The default value of this property is 1.
        SamplesPerFrame;

        %Signal Value of, or variable containing the signal
        %   Specify the name of the MATLAB workspace variable from which to
        %   import the signal, or a valid MATLAB expression specifying the
        %   signal. The default value of this property is (1:10)'.
        Signal;

        %SignalEndAction Action after final signal values are generated
        %   Specify the output after all of the specified signal samples have
        %   been generated as one of ['Set to zero' | 'Hold final value' |
        %   'Cyclic repetition']. The default is 'Set to zero'.
        SignalEndAction;

    end
end
