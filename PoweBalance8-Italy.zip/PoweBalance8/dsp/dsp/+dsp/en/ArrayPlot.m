classdef ArrayPlot< dsp.webscopes.ArrayPlotBaseWebScope
%ArrayPlot Display vectors or arrays
%   AP = dsp.ArrayPlot returns an object, AP, that can show real and
%   complex valued floating and fixed-point data on a two dimensional
%   display.
%
%   AP = dsp.ArrayPlot('Name', Value, ...) returns a ArrayPlot object, AP,
%   with each specified property name set to the specified value. You can
%   specify name-value pair arguments in any order as (Name1,Value1,
%   ..., NameN, ValueN).
%
%   AP = dsp.ArrayPlot(NUMINPUTS, 'PropertyName', PropertyValue, ...)
%   returns an ArrayPlot object, AP, with the NumInputPorts property set to
%   NUMINPUTS and other specified properties set to the specified values.
%   NUMINPUTS is a value-only argument. Specify NUMINPUTS first. You can
%   specify name-value pair arguments in any order.
%
%   Step method syntax:
%
%   step(AP, X) displays the signal, X, in the ArrayPlot figure.
%
%   step(AP, X1, X2, ..., XN) displays the signals X1, X2, ..., XN in the
%   ArrayPlot figure when the NumInputPorts property is set to N.
%   X1, X2, ... XN can have different data types and dimensions.
%
%   Objects may be called directly like a function instead of using
%   the step method. For example, step(obj, x) and obj(x) are equivalent.
%
%   ArrayPlot methods:
%
%   step            - Display signal in the ArrayPlot figure (see above)
%   release         - Allow property value and input characteristics
%                     changes, and release ArrayPlot resources
%   clone           - Create ArrayPlot object with same property values
%   isLocked        - Display locked status (logical)
%   reset           - Clear ArrayPlot figure
%   show            - Turn on visibility of ArrayPlot figure
%   hide            - Turn off visibility of ArrayPlot figure
%   isVisible       - Return visibility of ArrayPlot figure (logical)
%   generateScript  - Generate MATLAB(R) script
%   printToFigure   - Print scope window to a MATLAB(R) figure
%
%   ArrayPlot properties:
%
%   NumInputPorts         - Number of input signals
%   XDataMode             - Choose how to specify X-axis data
%   SampleIncrement       - X-axis sample spacing
%   XOffset               - X-axis display offset
%   CustomXData           - Custom X-axis data values
%   XScale                - X-axis scale
%   YScale                - Y-axis scale
%   PlotType              - Option to control the type of plot
%   AxesScaling           - Axes scaling mode
%   AxesScalingNumUpdates - Number of updates before scaling
%   MeasurementChannel    - Channel for which measurement is computed
%   CursorMeasurements    - Cursor measurements
%   PeakFinder            - Peak finder measurements
%   SignalStatistics      - Signal statistics measurements
%   Name                  - Caption to display on Array Plot window
%   Position              - Scope window position in pixels
%   MaximizeAxes          - Maximize axes control
%   PlotAsMagnitudePhase  - Plot signal as Magnitude-and-Phase
%   Title                 - Display title
%   XLabel                - X-axis label
%   YLabel                - Y-axis label
%   YLimits               - Y-axis limits
%   ShowLegend            - Show or hide legend
%   ChannelNames          - Names for the input data channels
%   ShowGrid              - Show or hide grid
%
%   % Example #1: Plot a Gaussian distribution
%       % Create a dsp.ArrayPlot object.
%       scope=dsp.ArrayPlot;
%
%       % Set ArrayPlot properties to display a Gaussian distribution.
%       scope.YLimits = [-0.1 1.1];
%       scope.XOffset = -2.5;
%       scope.SampleIncrement = 0.1;
%       scope.Title = 'Gaussian distribution';
%       scope.XLabel = 'X';
%       scope.YLabel = 'f(X)';
%
%       % Plot a Gaussian distribution
%       scope(exp(-(-2.5:.1:2.5) .* (-2.5:.1:2.5))');
%
%   % EXAMPLE #2: View LMS adaptive filter weights
%
%       % In this example the weights of an adaptive LMS filter are plotted
%       % as they adapt to filter a noisy input signal.
%
%       % Create an LMS adaptive filter System object.
%       lmsfilt = dsp.LMSFilter(40,'Method', 'Normalized LMS', ...
%               'StepSize', .002);
%
%       % Create and configure an audio file reader System object to read
%       % the input signal from the specified audio file.
%       audioReader = dsp.AudioFileReader('dspafxf_8000.wav',  ...
%             'SamplesPerFrame', 40, ...
%             'PlayCount', Inf,...
%             'OutputDataType', 'double');
%
%       % Create and configure a fixed-point FIR digital filter System
%       % object to filter random white noise to create colored noise.
%       firfilt = dsp.FIRFilter('Numerator', fir1(39, .25));
%
%       % Create and configure an ArrayPlot object to display the
%       % adaptive filter weights.
%       scope = dsp.ArrayPlot('XLabel', 'Filter Tap', ...
%             'YLabel', 'Filter Weight', ...
%             'YLimits', [-.05 .2]);
%
%       % Plot the LMS filter weights as they adapt to a desired signal.
%
%       numplays = 0;
%       while numplays < 3
%           [y, eof]    = audioReader();   % Read from audio file
%           noise       = rand(40,1);         % Produce random data
%           noisefilt   = firfilt(noise); % Filter the random data
%
%           % For this example, a 'desired' signal is a noisy version
%           % of the input signal
%           desired     = y + noisefilt;
%
%           % Stepping the LMS filter updates the filter weights
%           [~, ~, wts] = lmsfilt(noise, desired);
%
%           % Plot the filter weights after each time step
%           scope(wts);
%
%           numplays = numplays + eof;        % Update number of plays
%       end
%
%   See also timescope, dsp.LMSFilter, dsp.AudioFileReader, dsp.FIRFilter

 
%   Copyright 2012-2021 The MathWorks, Inc.

    methods
        function out=ArrayPlot
        end

    end
end
