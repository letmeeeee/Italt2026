classdef FilterCascade< dsp.internal.FilterStructure
%FilterCascade Construct a cascade of filter System objects, delays, and
%scalar gains
%   This is a multistage System object that allows cascading of filter
%   System objects, delays, and scalar gains. The cascade can then be used
%   for analysis, for generating filtering code, or for simulation.
%
%   FC = dsp.FilterCascade returns a System object, FC, that has a single
%   stage of dsp.FIRFilter.
%
%   FC = dsp.FilterCascade(FILTER1, FILTER2, ...) returns a multistage
%   System object, FC, with first stage set to FILTER1, second stage set to
%   FILTER2, and so on.
%
%   FC = dsp.FilterCascade(..., CloneStages=val) sets the CloneStages
%   property to val, which can be true or false.
%
%   Step method syntax:
%
%   Y = step(FC,X) runs the input X through the filter cascade FC, and
%   returns the filtered output Y.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   FilterCascade methods:
%
%   step                  - See above description for use of this method
%   release               - Allow property value and input characteristics
%                           to change
%   clone                 - Create dsp.FilterCascade object with same
%                           property values
%   isLocked              - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>                 - Reset the internal states of all stages to
%                           initial conditions
%   addStage              - Add a new filter stage to the cascade
%   removeStage           - Remove a stage from the cascade
%   releaseStages         - Release the locked state of all stages in the
%                           cascade
%   getNumStages          - Get the number of stages in the cascade object
%   generateFilteringCode - Generate MATLAB code that can perform the
%                           filtering operation of the whole cascade
%   generatehdl           - Generate HDL code.
%                           (Filter Design HDL Coder Required)
%
%   FilterCascade properties:
%
%   CloneStages - Control stage cloning
%   Stage1      - First stage of the filter cascade
%
%   You can grow the number of stages by using the addStage method of
%   dsp.FilterCascade. For a list of System objects that can be used as
%   stages of the filter cascade, type
%   dsp.FilterCascade.helpSupportedSystemObjects
%
%   This System object supports several filter analysis methods. For more
%   information, type dsp.FilterCascade.helpFilterAnalysis.
%
%   % EXAMPLE 1: Construct a cascade in three ways
%   % First, create the stages
%   s1 = dsp.FIRInterpolator(13);
%   s2 = dsp.FIRDecimator(17);
%
%   % Option 1: Specify stages while constructing the dsp.FilterCascade 
%   % object
%   fc1 = dsp.FilterCascade(s1,s2);
%
%   % Option 2: Use the cascade function
%   fc2 = cascade(s1, s2);
%
%   % Option 3: Construct an empty cascade, then use the addStage function 
%   % to add the stages.
%   fc3 = dsp.FilterCascade;
%   addStage(fc3, s1);
%   addStage(fc3, s2);
%
%   % EXAMPLE 2: Design a compensation decimator for a CIC decimator and
%   % visualize the frequency response of the cascade through
%   % dsp.FilterCascade. Step through the filter cascade. 
%
%   % Construction
%   cicdecim = dsp.CICDecimator(DecimationFactor = 6, ...
%                               NumSections = 6);
%   decimcasc = cascade(cicdecim, 1/gain(cicdecim));
%   fs = 16e3;     % Sample rate at the input of compensation decimator
%   fPass = 4e3;   % Passband frequency
%   fStop = 4.5e3; % Stopband frequency
%   ciccomp = dsp.CICCompensationDecimator(cicdecim, ...
%                             DecimationFactor  = 2, ...
%                             PassbandFrequency = fPass, ...
%                             StopbandFrequency = fStop, ...
%                             SampleRate = fs);
%
%   % Frequency response
%   % Next, visualize the cascade frequency response using FilterCascade
%   filtchain = dsp.FilterCascade(decimcasc, ciccomp);
%
%   f = fvtool(decimcasc, ciccomp, filtchain, Fs = [fs*6,fs,fs*6],...
%       Arithmetic = 'fixed');
%   legend(f,'CIC Decimator','CIC Compensation Decimator', ...
%            'Overall Response');
%
%   % Simulation with random input
%   x = randn(1200,2);
%   for idx = 1:100
%       y = filtchain(x);
%   end
%
%   % EXAMPLE 3: Multistage decimator design. Design a two-stage decimator
%   % with a downsampling rate of 4, transition width of 100 Hz, sample 
%   % rate of 2kHz, and a 60 dB attenuation in the stopband. The System 
%   % object returned from designMultistageDecimator is a filter cascade.
%
%   % Use multistage design function to construct a decimator
%   decim = designMultistageDecimator(4, 2000, 100, 60);
%
%   % Verify the design
%   info(decim)
%   fvtool(decim)
%
%   % Generate code to filter data using this design
%   % This saves the code in a file called 'processDecimator.m' in the
%   % current directory, along with any associated classes.
%   generateFilteringCode(decim, 'processDecimator');
%
%   % EXAMPLE 4: Stage cloning v.s. stage referencing
%   s1 = dsp.FIRInterpolator(13);
%   s2 = dsp.FIRDecimator(17);
%   fc_clone = dsp.FilterCascade(s1, s2)
%   fc_ref = dsp.FilterCascade(s1, s2, CloneStages = false)
%
%   % Change a property in the user-provided stage
%   s1.InterpolationFactor = 19
%
%   % Check if the change in the interpolation factor of s1 has affected
%   % the interpolation factor of Stage1 stored in the cascade
%   fc_clone.Stage1.InterpolationFactor   % no sync (clone)
%   fc_ref.Stage1.InterpolationFactor     % sync (reference)
%
%   See also cascade, dsp.ParallelFilter, designMultistageDecimator, 
%   designMultistageInterpolator

 
%   Copyright 2014-2023 The MathWorks, Inc.

    methods
        function out=FilterCascade
            % Constructor
        end

        function out=addStage(~) %#ok<STOUT>
            %ADDSTAGE Add a stage to filter cascade
            %
            %   addStage(FC, FILTERSYSOBJ) adds FILTERSYSOBJ as a stage at the
            %   end of the filter cascade in FC.
            %
            %   addStage(FC, FILTERSYSOBJ, STAGEIDX) adds the filter defined in
            %   FILTERSYSOBJ at stage position STAGEIDX of the filter cascade
            %   in FC. All existing filters from STAGEIDX to end of the cascade
            %   are shifted down further in the cascade.
            %
            %   % Example 1: Add a stage at the end of the filter cascade
            %   filtcasc = dsp.FilterCascade;
            %   addStage(filtcasc, dsp.IIRFilter);
            %
            %   % Example 2: Add a filter at the second stage of the filter
            %   % cascade consisting of three filters
            %   filtcasc = cascade(dsp.CICDecimator,dsp.FIRDecimator,dsp.FIRFilter);
            %   addStage(filtcasc, dsp.IIRFilter, 2);
        end

        function out=convertToDFILT(~) %#ok<STOUT>
            % Convert the System object to a dfilt object for analysis
        end

        function out=fdhdltool(~) %#ok<STOUT>
            %   FDHDLTOOL(Hb, nt) launches the Generate HDL dialog that lets you
            %   customize and generate Verilog or VHDL code and test benches for
            %   the quantized System object filter, Hb. You have to call FDHDLTOOL
            %   again if you make changes in the filter, Hb, in the command line.
            %
            %   The main dialog and two subordinate dialogs provide access to many
            %   options for customizing the generated filter and test bench code.
            %
            %   The Generate HDL main dialog categorizes options in two frames:
            %
            %   * HDL Filter - Options you are most likely to customize at least once:
            %   language selection, name and location of generated files, reset
            %   specifications, and optimizations.
            %
            %   * Test bench types - Options for naming and specifying the type of test
            %   bench files to generate, and specific types of stimuli the test benches
            %   are to apply.
            %
            %   EXAMPLE:
            %   cascadeFilter = dsp.FilterCascade(dsp.FIRFilter,dsp.FIRDecimator);
            %   T = numerictype(1,16,15);
            %   fdhdltool(cascadeFilter, T)
        end

        function out=generateFilteringCode(~) %#ok<STOUT>
            %GENERATEFILTERINGCODE Generate MATLAB code to filter using a cascade
            %
            %   generateFilteringCode(FC) creates a new file in the editor that
            %   contains code to create stages of the cascade and use the
            %   stages to process input data in sequence.
            %
            %   generateFilteringCode(FC, FNAME) generates the code and saves
            %   it to the file specified in the string FNAME. If a file named FNAME
            %   already exists, its content is replaced.
            %
            %   % Example:
            %   FC = dsp.FilterCascade(dsp.FIRFilter(Numerator=ones(1,5)),...
            %                          dsp.FIRDecimator);
            %   fName = 'filterCascade.m';  % The code will be saved in this
            %                               % file in the current directory
            %   generateFilteringCode(FC, fName);
        end

        function out=generatehdl(~) %#ok<STOUT>
            %   GENERATEHDL(Hb, 'InputDataType', nt) automatically generates VHDL
            %   or Verilog code for the quantized filter, Hb. The default
            %   language is VHDL; to generate Verilog, supply the
            %   property/value pair 'TargetLanguage','Verilog'. The file is written to
            %   the HDL source directory which defaults to 'hdlsrc' under the
            %   current directory. This directory will be created if necessary.
            %
            %   GENERATEHDL(Hb, PARAMETER1, VALUE1, PARAMETER2, VALUE2, ...)
            %   generates the HDL code with parameter/value pairs. Valid properties
            %   and values for GENERATEHDL are listed in the Filter Design HDL
            %   Coder documentation section "Property Reference."
            %
            %   EXAMPLE:
            %   cascadeFilter = dsp.FilterCascade(dsp.FIRFilter,dsp.FIRDecimator);
            %   T = numerictype(1,16,15);
            %   generatehdl(cascadeFilter, 'InputDataType', T)
        end

        function out=getNumStages(~) %#ok<STOUT>
            %GETNUMSTAGES Number of filters in cascade
            %
            %   N = getNumStages(FC) returns the number of stages in the filter
            %   cascade object, FC.
            %
            %   % Example:
            %   FC = cascade(dsp.FIRFilter, dsp.IIRFilter);
            %   N = getNumStages(FC);    % This will return 2
        end

        function out=helpSupportedSystemObjects(~) %#ok<STOUT>
            %HELPSUPPORTEDSYSTEMOBJECTS List all System objects supported by
            % dsp.FilterCascade
            %
            % supportedObjs = dsp.FilterCascade.helpSupportedSystemObjects
            %                   Display a list of System objects that can be used 
            %                   as stages of a dsp.FilterCascade object
        end

        function out=infoImpl(~) %#ok<STOUT>
        end

        function out=isFilterCascade(~) %#ok<STOUT>
        end

        function out=isequal(~) %#ok<STOUT>
            %ISEQUAL Determine if two FilterCascade objects are equal.
            %
            %   isequal(FC1, FC2) returns logical 1 (TRUE) if all stages of FC1
            %   are exactly the same in value as those of FC2.
            %
            %   % Example:
            %   FC1 = dsp.FilterCascade(dsp.FIRDecimator, ...
            %                           dsp.FIRFilter('Numerator',ones(1,5)));
            %   FC2 = dsp.FilterCascade(dsp.FIRDecimator, ...
            %                           dsp.FIRFilter);
            %   isequal(FC1, FC2);  % This will return false because Stage2 of
            %                       % both objects is not same
            %   FC3 = dsp.FilterCascade(dsp.FIRDecimator, ...
            %                           dsp.FIRFilter('Numerator',ones(1,5)));
            %   isequal(FC1, FC3);  % This will return true
        end

        function out=islinphase(~) %#ok<STOUT>
            % First, check sufficient confition: all stages have a linear phase
            % ⟹ a cascade has a linear phase.
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Setting CloneStages to false will avoid unnecessary cloning the result of
            % matlab.System.loadBoject()
        end

        function out=outputDelay(~) %#ok<STOUT>
        end

        function out=releaseStages(~) %#ok<STOUT>
            %RELEASESTAGE Release the locked state of all stages in the cascade
            %
            %   releaseStages(FC) calls RELEASE method on all stages of the
            %   filter cascade in FC.
            %
            %   % Example:
            %   FIRFilt = dsp.FIRFilter;
            %   y = FIRFilt(randn);
            %   FC = dsp.FilterCascade(dsp.FIRInterpolator, FIRFilt);
            %   isLocked(FC.Stage2)
            %   releaseStages(FC);
            %   isLocked(FC.Stage2)
        end

        function out=removeStage(~) %#ok<STOUT>
            %REMOVESTAGE Remove a stage from filter cascade
            %
            %   removeStage(FC) removes a stage from the end of the filter
            %   cascade in FC.
            %
            %   removeStage(FC, STAGEIDX) removes the stage from the stage
            %   position STAGEIDX of the filter cascade in FC. All existing
            %   filters from STAGEIDX to end of the cascade are shifted up in
            %   the cascade.
            %
            %   % Example 1: Remove a stage from the end of the filter cascade
            %   FC = dsp.FilterCascade(dsp.FIRFilter, dsp.IIRFilter);
            %   removeStage(FC);
            %
            %   % Example 2: Remove a filter from the third stage of a cascade
            %   % consisting of four stages
            %   FC = cascade(dsp.FIRInterpolator, dsp.FIRInterpolator, ...
            %                dsp.FIRDecimator, dsp.FIRDecimator);
            %   removeStage(FC, 3);
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Called on saving the object
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Verify all stages have a single port
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=toMultirateChain(~) %#ok<STOUT>
            % Convert the cascade into a MultirateChain object. 
            % The MultirateChain is an internal structure that allows multirate
            % cascades manipulation and analysis.
        end

    end
    properties
        %CloneStages Control stage cloning
        %
        % If CloneStages is false, the cascade stages assigned to the
        % FilterCascade object occupy the same memory as the stages provided by
        % the user. You can add stages while creating the FilterCascade object,
        % by direct assignment, or by using the addStage method.
        %
        % If CloneStages is set to true, the stages stored in the FilterCascade
        % object are mere clones of the stages provided by the user, and do not
        % occupy the same memory.
        %
        % The default is true. This parameter can be set on construction only.
        CloneStages;

        %Stage1 First stage of filter cascade
        %   Specify the first stage of the filter cascade, as a filter
        %   System object. The default value of this property is
        %   dsp.FIRFilter.
        Stage1;

        %Stage10 Tenth stage of filter cascade
        Stage10;

        %Stage11 Eleventh stage of filter cascade
        Stage11;

        %Stage12 Twelfth stage of filter cascade
        Stage12;

        %Stage13 Thirteenth stage of filter cascade
        Stage13;

        %Stage14 Fourteenth stage of filter cascade
        Stage14;

        %Stage15 Fifteenth stage of filter cascade
        Stage15;

        %Stage2 Second stage of filter cascade
        Stage2;

        %Stage3 Third stage of filter cascade
        Stage3;

        %Stage4 Fourth stage of filter cascade
        Stage4;

        %Stage5 Fifth stage of filter cascade
        Stage5;

        %Stage6 Sixth stage of filter cascade
        Stage6;

        %Stage7 Seventh stage of filter cascade
        Stage7;

        %Stage8 Eighth stage of filter cascade
        Stage8;

        %Stage9 Nine stage of filter cascade
        Stage9;

        pNumStages;

    end
end
