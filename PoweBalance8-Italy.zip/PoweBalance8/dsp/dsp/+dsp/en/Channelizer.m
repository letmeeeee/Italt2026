classdef Channelizer< dsp.internal.PolyphaseFFTBase & dsp.enhancedsim.UpdateSysObjBuildInfo
%Channelizer Polyphase FFT analysis filter bank.
%   channelizer = dsp.Channelizer returns a polyphase FFT analysis
%   filter bank System object, channelizer, which separates a broadband
%   input signal into multiple narrowband output signals. This object
%   implements the inverse operation of dsp.ChannelSynthesizer.
%
%   channelizer = dsp.Channelizer(M) returns an M-band polyphase FFT
%   analysis filter bank. The number of frequency bands M can be any
%   positive integer greater than one. M also corresponds to the number
%   of polyphase branches and the FFT length used in the filter bank. M
%   defaults to 8.
%
%   channelizer = dsp.Channelizer(M, D) returns an M-band polyphase FFT
%   analysis filter bank with Decimation factor D. The decimation
%   factor D can be any positive integer less than or equal to M. D
%   defaults to 8.
%
%   channelizer = dsp.Channelizer(Name=Value, ...) returns a
%   channelizer with each specified property name set to the specified
%   value. You can specify additional name-value pair arguments in any
%   order as (Name1=Value1,...,NameN=ValueN).
%
%   The specification defaults to number of taps per band and stopband
%   attenuation. These values are used to design a prototype lowpass
%   filter that is implemented in polyphase form. The stopband
%   attenuation determines the minimum level of interference (aliasing)
%   from one frequency band to another. The number of taps corresponds
%   to the number of filter coefficients used for each polyphase
%   branch. The number of polyphase branches matches the number of
%   frequency bands. The total number of filter coefficients for the
%   prototype lowpass filter is given by the number of frequency bands
%   times the number of taps per band. For a given stopband
%   attenuation, increasing the number of taps per band will narrow the
%   transition width of the filter resulting in more usable bandwidth
%   for each frequency band at the expense of increased computation.
%
%   Step method syntax:
%
%   y = step(channelizer,x) separates the broadband input signal x into
%   a number of narrow band signals contained in the columns of y. The
%   number of rows in x must be a multiple of the number of frequency
%   bands. Each column of x corresponds to a separate channel. If M is
%   the number of frequency bands and x is a Lx1 matrix, y will have
%   dimensions L/MxM. If x has more than one channel, i.e. x is LxN, y
%   will be 3 dimensional with dimensions L/MxMxN.
%
%   System objects may be called directly like a function instead of
%   using the step method. For example, y = step(obj,x) and y = obj(x)
%   are equivalent.
%
%   Channelizer methods:
%
%   step                 - See above description for use of this method
%   release              - Allow property value and input
%                          characteristics changes
%   clone                - Create a new object with same property
%                          values
%   isLocked             - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>                - Reset the internal states to initial
%                          conditions
%   coeffs               - Returns a structure containing the prototype
%                          lowpass filter coefficients
%   polyphase            - Returns the polyphase coefficient matrix
%   tf                   - Returns the transfer function of the
%                          prototype lowpass filter
%   fvtool               - Visualize channelizer using FVTool
%   freqz                - Compute frequency response
%   bandedgeFrequencies  - Compute bandedge frequencies between
%                          adjacent filters in the channelizer
%   centerFrequencies    - Compute center frequencies for all filters
%                          in the channelizer
%   getFilters           - Return matrix of channelizer FIR filters
%
%   Channelizer properties:
%
%   NumFrequencyBands         - Number of frequency bands
%   DecimationFactor               - Decimation factor
%   AllowArbitraryInputLength - Allow arbitrary frame length for fixed-size input signals
%   Specification                       - Design parameters or Coefficients
%   NumTapsPerBand               - Number of filter coefficients per frequency band
%   StopbandAttenuation         - Stopband attenuation for lowpass filter in dB
%   LowpassCoefficients           - Coefficients for prototype lowpass filter
%
%   % EXAMPLE: Separate a signal containing sine waves of different
%   % frequencies into 8 separate signals, each one containing one sine
%   % wave.
%   channelizer = dsp.Channelizer;
%   offsets = [-40,-30,-20,10,15,25,35,-15];
%   sinewave = dsp.SineWave(ComplexOutput=true, ...
%       Frequency=offsets+(-375:125:500),SamplesPerFrame=800);
%   scope = spectrumAnalyzer(ShowLegend=true,...
%       SampleRate=sinewave.SampleRate/8);
%   for i=1:5000
%       x = sum(sinewave(),2);
%       y = channelizer(x);
%       scope(y);
%   end
%
%   See also dsp.ChannelSynthesizer, dsp.FIRHalfbandDecimator,
%   dsp.FIRHalfbandInterpolator, dsp.IIRHalfbandDecimator,
%   dsp.DyadicAnalysisFilterBank, firpr2chfb.

 

    % Copyright 2016-2022 The MathWorks, Inc.

    methods
        function out=Channelizer
            %Channelizer Construct the Channelizer class.
            % Support name-value pair arguments
        end

        function out=bandedgeFrequencies(~) %#ok<STOUT>
            %f = bandedgeFrequencies(obj) Bandedge frequencies
            %   f = bandedgeFrequencies(obj) returns a vector of
            %   normalized frequencies f containing the band-edge
            %   frequencies between adjacent bandpass filters in the
            %   channelizer.
            %
            %   f = bandedgeFrequencies(obj,Fs) returns a vector of
            %   band-edge frequencies in Hz, using the sample rate Fs.
        end

        function out=centerFrequencies(~) %#ok<STOUT>
            %f = centerFrequencies(obj) Center frequencies
            %   f = centerFrequencies(obj) returns a vector of
            %   normalized frequencies f containing the center frequencies
            %   of all the bandpass filters in the channelizer.
            %
            %   f = centerFrequencies(obj,Fs) returns a vector of
            %   center frequencies in Hz, using the sample rate Fs.
        end

        function out=coeffs(~) %#ok<STOUT>
            %c = coeffs(obj) Return structure with filter coefficients
            %   c = coeffs(obj) returns the overall prototype lowpass
            %   filter coefficients in a structure.
        end

        function out=designPrototypeLowpass(~) %#ok<STOUT>
        end

        function out=freqz(~) %#ok<STOUT>
            %[H,f] = freqz(obj) Frequency response
            %   [H,w] = freqz(obj) returns a matrix of complex frequency
            %   responses for each filter in the channelizer. Each column
            %   of H corresponds to the frequency response for one of the
            %   filters in the channelizer. w is a vector of normalized
            %   frequencies at which the rows of H are computed.
            %
            %   [H,w] = freqz(obj,IND) returns the frequency response of
            %   the filters with indices corresponding to the elements in
            %   the vector IND. IND is a row vector of indices between 1
            %   and obj.NumFrequencyBands. If not specified, IND defaults
            %   to 1:N where N is the number of frequency bands.
            %
            %   [H,f] = freqz(...,'Fs',Fs) specifies a sampling rate Fs in
            %   Hz. f is a vector of frequencies in Hz at which the
            %   frequency response is computed.
            %
            %   [H,f] = freqz(...,'NFFT',NFFT) specifies the number of
            %   NFFT points used to compute the frequency response.
            %
            %   [H,f] = freqz(...,'overall',FLAG) specifies whether to
            %   return individual filter responses when FLAG is set to
            %   false, or the sum of the filter responses when FLAG is set
            %   to true. If not specified, FLAG defaults to false.
            %
            %   freqz(...) with no output arguments plots the magnitude
            %   response.
        end

        function out=freqzHelper(~) %#ok<STOUT>
        end

        function out=fvtool(~) %#ok<STOUT>
            %fvtool(obj) View channelizer in FVTool
            %   fvtool(obj) visualizes the filters in the channelizer using
            %   the Filter Visualization Tool (FVTool).
            %
            %   fvtool(obj,IND) visualizes the filters corresponding to the
            %   elements in the vector IND. IND is a row vector of indices
            %   between 1 and obj.NumFrequencyBands. If not specified, IND
            %   defaults to 1:N where N is the smallest of
            %   obj.NumFrequencyBands and 64.
            %
            %   fvtool(...,'Fs',Fs) specifies a sampling rate Fs in Hz.
            %
            %   fvtool(...,'NFFT',NFFT) specifies the number of NFFT points
            %   used to compute the frequency response.
            %
            %   fvtool(...,'overall',FLAG) specifies whether to return
            %   individual filter responses when FLAG is set to false, or
            %   the sum of the filter responses when FLAG is set to true.
            %   If not specified, FLAG defaults to false.
            %
            %   H = fvtool(...) returns the handle to FVTool.
        end

        function out=getFilters(~) %#ok<STOUT>
            %B = getFilters(obj) Return matrix of channelizer FIR filters
            %   B = getFilters(obj) returns a matrix B of filter
            %   coefficients corresponding to each filter in the
            %   channelizer filter bank. Each row contains the coefficients
            %   for one the bandpass filters.
            %
            %   B = getFilters(obj,IND) returns the filters with indices
            %   corresponding to the elements in the vector IND. IND is a
            %   row vector of indices between 1 and obj.NumFrequencyBands.
            %   If not specified, IND defaults to 1:N where N is the number
            %   of frequency bands.
            %
            %   NOTE: the channelizer does not actually use all these
            %   filters in the implementation. It only uses the prototype
            %   lowpass filter (the first row of matrix B) and an FFT to
            %   implement the filter bank. The combination of polyphase
            %   implementation of the prototype lowpass and the FFT
            %   effectively implements all the filters in B, but does so in
            %   a very efficient manner. The getFilters method is provided
            %   as an analysis aid when evaluating the performance of the
            %   channelizer.
        end

        function out=getNumChannels(~) %#ok<STOUT>
        end

        function out=getOutputFrameSize(~) %#ok<STOUT>
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
            %Get default parameters group for this System object
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Re-load state if saved version was locked
        end

        function out=polyphase(~) %#ok<STOUT>
            %p = polyphase(obj) Return polyphase matrix
            %   p = polyphase(obj) returns the polyphase matrix used by the
            %   filter bank. Each row in the matrix corresponds to a
            %   polyphase branch. The number of columns of p corresponds to
            %   the number of filter taps per branch.
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
            % Specify initial values for DiscreteState properties
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Default implementation saves all public properties
        end

        function out=setAutoDecimationFactor(~) %#ok<STOUT>
            % If the user did not set the decimation factor, it should
            % be equal to the number of frequency bands
        end

        function out=setUserDefinedDecimationFactor(~) %#ok<STOUT>
            % If the user set the decimation factor, set the decimation
            % factor source to 'property'
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
            % Inputs:
            %   p - M x Np polyphase matrix
            %   x - L x N Multi-channel frame input
            %   z - Np x M x N state vector
            %   vextra - 1 x M x N temporary computation
            %   D -  scalar
            % Outputs:
            %   y - L/M x M x N multichannel frame output
            % Where:
            %   M  - Number of frequency bands
            %   Np - Number of taps per band
            %   L  - Input frame size
            %   N  - Number of independent channels
            %   D  -  Decimation factor
            %   K  - number of the states in the state machine
            %
            % Assumptions:
            %   if p is a double, x, z must also be double
            %   if p is a single, x, z must also be single
            %   if x is complex, z must also be complex;
        end

        function out=tf(~) %#ok<STOUT>
            %[b,a] = tf(obj) Return transfer function
            %   [b,a] = tf(obj) returns the vector of numerator
            %   coefficients b and the vector of denominator coefficients a
            %   for the overall prototype lowpass filter used for the
            %   filter bank.
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

        function out=validatePropertiesImpl(~) %#ok<STOUT>
            % validate properties
        end

    end
    properties
        %AllowArbitraryInputLength Allow arbitrary frame length for fixed-size input signals
        %   When this flag is set to true, the fixed-size input signal can have a frame size 
        %   that is not a multiple of the decimation factor. This property applies only when 
        %   the input is a fixed-size signal. If the size of the input signal varies during 
        %   simulation (varible-size signal), this property does not apply. The default value 
        %   is 'false' and has to be set to 'true' to process inputs with arbitrary frame lengths.
        AllowArbitraryInputLength;

        %DecimationFactor Decimation factor
        %   Specify the decimation factor as a scalar positive less than or
        %   equal to the number of frequency bands. The default is equal to
        %   the number of frequency bands specified.
        DecimationFactor;

        %ModuloIdx to compute the output length in case of non-mulitple
        %frame length
        ModuloIdx;

        %NumFrequencyBands Number of frequency bands
        %   Specify the number of frequency bands to separate the input
        %   signal into as a scalar positive integer greater than 1.
        %   The default is 8.
        NumFrequencyBands;

        %StartIdx and StopIdx are used for output size calculation
        StartIdx;

        StopIdx;

    end
end
