classdef MatFileWriter< matlab.System
%MatFileWriter File writer
%   Writer = dsp.MatFileWriter returns a System object, Writer, that writes
%   MAT files.
%
%   Writer = dsp.MatFileWriter('PropertyName', PropertyValue, ...) returns
%   a file writer object, Writer, with each specified property set to the
%   specified value.
%
%   Writer = dsp.MatFileWriter(FILENAME, VARIABLENAME, 'PropertyName',
%   PropertyValue, ...) returns a file writer object, Writer, with the
%   Filename property set to FILENAME, the VariableName property set
%   to VARIABLENAME, and other properties set to the specified values.
%
%   Step method syntax:
%
%   step(Writer, X) writes data, X, to a variable stored in a MAT-file. The
%   variable is assumed to be N-dimensional and a MATLAB built-in datatype.
%   The data is written to the file by concatenating along the first
%   dimension.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, step(obj, x) and obj(x) are equivalent.
%
%   MatFileWriter methods:
%
%   step     - See above description for use of this method
%   release  - Closes the MAT file.
%   clone    - Create file writer object with same property values
%   <a href="matlab:help matlab.System/reset   ">reset</a>    - Reset the writing to the start of the variable
%   isLocked - Locked status (logical)
%
%   MatFileWriter properties:
%
%   Filename             - Name of MAT file to write
%   VariableName         - Name of variable to write
%
%   % EXAMPLE: Use MatFileReader and MatFileWriter to stream data
%      % First, create a variable name
%      filename = [tempname '.mat'];
%
%      % Next, write that variable to a MAT-file.
%      Writer = dsp.MatFileWriter(filename,'VariableName','originalData');
%      for i=1:10
%          originalData = rand(4,2);
%          Writer(originalData);
%      end
%      release(Writer); % This will close the MAT file
%
%      % Finally, load the variable back into MATLAB.
%      data = load(filename, 'originalData');
%
%   See also dsp.MatFileReader.

 
%   Copyright 2011-2022 The MathWorks, Inc.

    methods
        function out=MatFileWriter
        end

        function out=extend(~) %#ok<STOUT>
        end

        function out=getNumInputsImpl(~) %#ok<STOUT>
        end

        function out=getNumOutputsImpl(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Call the base class method
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=setupObject(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=writeAttributes(~) %#ok<STOUT>
            % Write the class attribute
        end

    end
    properties
        %Filename Name of MAT file to write
        % The Filename property is a value-only property which indicates the
        % name of the file to be written.  The default value of this property
        % is 'Untitled.mat'
        Filename;

        %VariableName Name of variable to write
        % The VariableName property corresponds to the name of the variable in
        % the MAT-file which is being written.  The default value of this
        % property is 'x'.
        VariableName;

    end
end
