classdef KalmanFilter
%KalmanFilter Estimate measurements and states of a system in presence
%             of white noise using Kalman Filter

 
%   Copyright 1995-2022 The MathWorks, Inc.

    methods
        function out=KalmanFilter
            % CONSTRUCTOR
        end

    end
end
