classdef MatFileReader< matlab.System & matlab.system.mixin.FiniteSource
%MatFileReader File reader
%   Reader = dsp.MatFileReader returns a System object, Reader, that
%   reads MAT files.
%
%   Reader = dsp.MatFileReader('PropertyName', PropertyValue, ...)
%   returns a file reader object, Reader, with each specified property
%   set to the specified value.
%
%   Reader = dsp.MatFileReader(FILENAME, VARIABLENAME, SAMPLESPERFRAME,
%   'PropertyName', PropertyValue, ...) returns a file reader object,
%   Reader, with the Filename property set to FILENAME, the
%   VariableName property set to VARIABLENAME, the SamplesPerFrame
%   property set to SAMPLESPERFRAME, and other properties set to the
%   specified values.
%
%   Step method syntax:
%
%   X = step(Reader) reads data, X, from a variable stored in a
%   MAT-file. The variable is assumed to be N-dimensional and a MATLAB
%   built-in datatype. The data is read into MATLAB by reading along
%   the first dimension.
%
%   System objects may be called directly like a function instead of
%   using the step method. For example, y = step(obj) and y = obj()
%   are equivalent.
%
%   MatFileReader methods:
%
%   step     - See above description for use of this method
%   release  - Closes the MAT file
%   clone    - Create file reader object with same property values
%   <a href="matlab:help matlab.System/reset   ">reset</a>    - Reset the reading to the start of the variable
%   isDone   - Returns true if object has reached end-of-file
%   isLocked - Locked status (logical)
%
%   MatFileReader properties:
%
%   Filename             - Name of MAT file to read
%   VariableName         - Name of variable to read
%   SamplesPerFrame      - Number of samples per output frame
%
%   % EXAMPLE: Use MatFileReader and MatFileWriter to stream data
%      % First, create a variable name
%      filename = [tempname '.mat'];
%
%      % Next, write that variable to a MAT-file.
%      originalData = rand(40,2);
%      save(filename, 'originalData', '-v7.3');
%
%      % Finally, stream the variable back into MATLAB.
%      Reader = dsp.MatFileReader(filename, 'originalData', 4);
%      while ~isDone(Reader)
%          finalData = Reader();
%      end
%
%   See also dsp.MatFileWriter.

     
    %   Copyright 2011-2021 The MathWorks, Inc.

    methods
        function out=MatFileReader
        end

        function out=assertValidClass(~) %#ok<STOUT>
        end

        function out=getNumInputsImpl(~) %#ok<STOUT>
        end

        function out=getNumOutputsImpl(~) %#ok<STOUT>
        end

        function out=isDoneImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Call the base class method
        end

        function out=readAttributes(~) %#ok<STOUT>
            % Read the attribute
        end

        function out=readData(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=setupObject(~) %#ok<STOUT>
            % If the filename is empty and we are writing,
            % create a temporary file
            % Open the file
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

    end
    properties
        %Filename The name of the MAT file
        % The Filename property is a value-only property which indicates the
        % name of the file to be read.  The default value of this property is
        % 'Untitled.mat'
        Filename;

        %SamplesPerFrame Number of samples per output frame
        % Every time the step method is called, the number of elements
        % specified by this property are read from the MAT-file. The
        % default value of this property is 1.
        SamplesPerFrame;

        %VariableName The name of the variable stored in the MAT file
        % The VariableName property corresponds to the name of the variable in
        % the MAT-file which is being read.  The default value of this property
        % is 'x'.
        VariableName;

        % pBuffer Buffer holding samples read from last file access
        pBuffer;

        % pBufferIdx Location to read from buffer
        pBufferIdx;

        % pDims   Buffer dimensions
        pDims;

        % pIdxVector Vector used to index into buffer for N-D data
        pIdxVector;

        % pIs2D   True if the data is two-dimensional
        pIs2D;

        % pIsChar True if the class of the data is char
        pIsChar;

        pIsComplex;

        % pIsDone Flag is set to true when there are no more new samples to
        % output
        pIsDone;

        % pLastSegmentRead Flag is set to true right after the last
        % available samples are read from the file
        pLastSegmentRead;

        % pMLClass Actual class used to initialize buffers
        pMLClass;

        % pReadFactor Every time the file is accessed, we read
        % SamplesPerFrame-by-pReadFactor samples
        pNumFrames;

        % pRemainingSegments When there are no more new samples in the
        % file, isDone returns true after pRemainingSegments segments are
        % read from the buffer
        pRemainingSegments;

        % pSamplesPerRead Number of read samples every time file is
        % accessed. this value is equal to SamplesPerFrame-by-pNumFrames
        pSamplesPerRead;

    end
end
