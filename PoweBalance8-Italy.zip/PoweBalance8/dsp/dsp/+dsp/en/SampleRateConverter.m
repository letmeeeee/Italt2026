classdef SampleRateConverter< dsp.internal.SupportArbitraryInputLength & dsp.internal.FilterAnalysis
%SampleRateConverter Multistage sample rate converter.
%   SRC = dsp.SampleRateConverter returns a multistage FIR sample
%   rate converter which converts the rate of each channel of the input
%   signal from the input sampling rate to the output sampling rate
%   specified.
%
%   SRC = dsp.SampleRateConverter('Name', Value, ...) returns a
%   multistage SRC with each specified property name set to the
%   specified value. You can specify additional name-value pair
%   arguments in any order as (Name1,Value1,...,NameN,ValueN).
%
%   Step method syntax:
%
%   Y = step(SRC, X) designs one or more multirate FIR filters and then
%   uses the filters to convert the rate of each channel (column) of
%   the real or complex input signal X to the output sampling rate
%   specified in SRC.
%
%   System objects may be called directly like a function instead of
%   using the step method. For example, step(obj, x) and obj(x) are
%   equivalent.
%
%   SampleRateConverter methods:
%
%   step                  - See above description for use of this
%                           method
%   release               - Allow property value and input 
%                           characteristics changes
%   clone                 - Create SampleRateConverter object with same
%                           property values
%   isLocked              - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>                 - Reset the internal states to initial
%                           conditions
%   getFilters            - Return filters used for rate conversion
%   getRateChangeFactors  - Get overall interpolation/decimation rates
%   getActualOutputRate   - Get adjusted output sample rate
%   cost                  - Compute implementation cost
%   visualizeFilterStages - Visualize filter stages
%   freqz                 - Frequency response
%   outputDelay           - Return the overall delay of the sample rate
%                           converter
%
%   SampleRateConverter properties:
%
%   Bandwidth           - Two-sided bandwidth of interest
%   InputSampleRate     - Input signal sampling rate
%   OutputSampleRate    - Output signal sampling rate
%   OutputRateTolerance - Allowable tolerance for output signal rate 
%   StopbandAttenuation - Minimum dB attenuation for aliased components 
%
%   % EXAMPLE 1: Convert an audio signal from 44.1 kHz to 96 kHz
%   SRC = dsp.SampleRateConverter('Bandwidth',40e3,...
%       'InputSampleRate',44.1e3,'OutputSampleRate',96e3);
%   [L,M] = getRateChangeFactors(SRC);
%   FrameSize = 10*M;
%   AR = dsp.AudioFileReader('guitar10min.ogg','SamplesPerFrame',...
%       FrameSize);
%   AW = dsp.AudioFileWriter('guitar10min_96k.wav','SampleRate',96e3);
%   tic;
%   while toc < 15
%       % Run for 15 seconds
%       x = AR();
%       y = SRC(x);
%       AW(y);
%   end
%   release(AR); release(AW); release(SRC)
%
%   % EXAMPLE 2: Compare cost of using 0% tolerance to that of using
%   % 1% tolerance when converting a signal from 98.304 MHZ (A/D)
%   % output to 22 MHz (802.11 channel bandwidth)
%   SRC1 = dsp.SampleRateConverter('Bandwidth',20e6,...
%        'InputSampleRate',98.304e6,'OutputSampleRate',22e6,...
%        'OutputRateTolerance',0); % 0% tolerance
%   
%   SRC2 = dsp.SampleRateConverter('Bandwidth',20e6,...
%        'InputSampleRate',98.304e6,'OutputSampleRate',22e6,...
%        'OutputRateTolerance',0.01); % 1% tolerance
%   
%   c1 = cost(SRC1) % No tolerance: 84779 coefficients
%   c2 = cost(SRC2) % 1% tolerance:   150 coefficients
%   [L1,M1] = getRateChangeFactors(SRC1); % L1 = 1375; M1 = 6144
%   [L2,M2] = getRateChangeFactors(SRC2); % L2 =    2; M2 =    9
%   getActualOutputRate(SRC2) % 21.84533333e+06
%
%   See also dsp.FarrowRateConverter, dsp.FIRRateConverter, 
%   dsp.FIRDecimator, dsp.FIRInterpolator, designMultistageDecimator,
%   designMultistageInterpolator, designMultirateFIR

 
% Copyright 2014-2023 The MathWorks, Inc.

    methods
        function out=SampleRateConverter
            %Constructor
        end

        function out=FsPerStage(~) %#ok<STOUT>
        end

        function out=convertToDFILT(~) %#ok<STOUT>
        end

        function out=cost(~) %#ok<STOUT>
            %C = cost(obj) compute implementation cost
            %   C = cost(obj) returns a structure C whose fields contain
            %   information about the computation cost of implementing the
            %   sample rate converter. The cost estimate contains the
            %   following fields:
            %   NumCoefficients               : Number of filter 
            %                                   coefficients (excluding 
            %                                   coefficients with values 0,
            %                                   1 or -1)
            %   NumStates                     : Number of states
            %   MultiplicationsPerInputSample : Number of multiplications 
            %                                   per input sample
            %   AdditionsPerInputSample       : Number of additions per
            %                                   input sample
            %   % Example: Compute cost for conversion between 192 kHz
            %   % and 44.1 kHz with a 0% tolerance and compare to the cost
            %   % of the same conversion with 10% tolerance
            %   SRC = dsp.SampleRateConverter;
            %   cost(SRC)
            %   SRC.OutputRateTolerance = 0.1;
            %   cost(SRC)
        end

        function out=effectiveFilterRate(~) %#ok<STOUT>
            % Return the rate at which the reduced single-stage FIRRC filter 
            % operates (assuming it exists)
        end

        function out=freqz(~) %#ok<STOUT>
            %[H,f] = freqz(obj,N,range) frequency response
            %   [H,f] = freqz(obj,N,range) returns the complex frequency
            %   response H and the frequency vector f at which H is
            %   computed. N is the number of frequency points. If not
            %   specified, it defaults to 8192. range is the frequency
            %   range over which the response is computed; range can be
            %   either 'half' or 'whole'. If not specified, it defaults to
            %   'half'.
            %
            %   [H,f] = freqz(obj, f) returns the complex frequency response
            %   H computed at the frequency points specified by vector f.
            %   The vector f is assumed to be in Hz.
            %
            %   freqz(obj) with no output argument launches FVTool and shows 
            %   the magnitude and phase responses of the filter System object.
            %
            %   % Example 1: Compute the frequency response corresponding 
            %   % to the combined 3 filter stages used to convert from 192
            %   % kHz to 44.1 kHz
            %   SRC = dsp.SampleRateConverter(InputSampleRate=20e3, ...
            %                                 OutputSampleRate=0.5e3, ...
            %                                 Bandwidth=400);
            %   [H,f] = freqz(SRC);
            %   plot(f, 20*log10(abs(H)))
            %
            %   % Example 2: Compute the frequency response corresponding 
            %   % to the combined 3 filter stages used to convert from 192
            %   % kHz to 44.1 kHz over the range [20 Hz, 44.1 kHz]
            %   SRC = dsp.SampleRateConverter(InputSampleRate=192e3, ...
            %                                 OutputSampleRate=32e3, ...
            %                                 Bandwidth=30e3)
            %   f = 20:10:44.1e3;
            %   H = freqz(SRC, f, 192e3);
            %   plot(f, 20*log10(abs(H)))
        end

        function out=getActualOutputRate(~) %#ok<STOUT>
            %FsOut = getActualOutputRate(obj) get actual output rate
            %   FsOut = getActualOutputRate(obj) returns the actual output
            %   sample rate computed taking into account the
            %   OutputRateTolerance.
            %   % Example: Get actual output sample rate for conversion 
            %   % between 192 kHz and 44.1 kHz with a 1% tolerance
            %   SRC = dsp.SampleRateConverter;
            %   SRC.OutputRateTolerance = 0.01;
            %   FsOut = getActualOutputRate(SRC);
        end

        function out=getFilters(~) %#ok<STOUT>
            %C = getFilters(obj) get filters
            %   C = getFilters(obj) returns the multirate filters used to
            %   perform the sampling rate conversion in a FilterCascade C.
            %   Each field of the structure holds the filter used at a
            %   given stage. The stages are cascaded together in order to
            %   perform the overall rate conversion.
            %   % Example: Get filters used for sample rate conversion
            %   % between 192 kHz and 44.1 kHz
            %   SRC = dsp.SampleRateConverter;
            %   C = getFilters(SRC);
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
            %Get default parameters group for this System object
        end

        function out=getRateChangeFactors(~) %#ok<STOUT>
            %[L,M] = getRateChangeFactors(obj) get rate change factors
            %   [L,M] = getRateChangeFactors(obj) returns overall
            %   interpolation factor L and the overall decimation factor M
            %   corresponding to the Input/Output sample rates. The
            %   factors are computed taking into account the
            %   OutputRateTolerance.
            %   % Example: Get overall interpolation/decimation factors
            %   % for conversion between 192 kHz and 44.1 kHz
            %   SRC = dsp.SampleRateConverter;
            %   [L,M] = getRateChangeFactors(SRC);
        end

        function out=infoImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Private properties
        end

        function out=needToDesignFilters(~) %#ok<STOUT>
        end

        function out=outputDelay(~) %#ok<STOUT>
            % Calculate the overall delay of the sample rate converter.
            % See also outputDelay
        end

        function out=releaseImpl(~) %#ok<STOUT>
            % Release the filters
        end

        function out=resetImpl(~) %#ok<STOUT>
            % Reset the filters
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Default implementation saves all public properties
        end

        function out=setfilters(~) %#ok<STOUT>
            % Create filter System objects
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
            % Stage:1 filtering
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

        function out=visualizeFilterStages(~) %#ok<STOUT>
            %visualizeFilterStages(obj) visualize filter stages
            %   visualizeFilterStages(obj) shows the response of each
            %   individual filter stage using FVTool.
            %   % Example: Visualize the 3 stages used for conversion 
            %   % between 192 kHz and 44.1 kHz 
            %   SRC = dsp.SampleRateConverter;
            %   visualizeFilterStages(SRC)
        end

    end
    properties
        %Bandwidth Two-sided bandwidth of interest (Hz)
        %   Specify the two-sided bandwidth of interest for the signal
        %   after rate conversion on Hertz, as a finite numeric scalar. The
        %   default bandwidth is 40 kHz.
        Bandwidth;

        %InputSampleRate Sample rate of input signal (Hz)
        %   Specify the sampling rate of the input signal in Hertz, as a
        %   finite numeric scalar. The default value of this property is
        %   192 kHz.
        InputSampleRate;

        %OutputRateTolerance Tolerance for output sample rate
        %   Specify the tolerance for the rate desired for the output
        %   signal as a finite numeric scalar percentage. The output rate
        %   tolerance allows for a simpler design in many cases. However,
        %   the actual output sample rate will vary for the output sample
        %   rate specified within the given tolerance percentage. For
        %   example, if OutputRateTolerance is specified as 0.01, the
        %   actual output sample rate will be in the range given by
        %   OutputSampleRate +/- 1%. The default tolerance is 0.
        OutputRateTolerance;

        %OutputSampleRate Sample rate of output signal (Hz)
        %   Specify the sampling rate desired for the output signal in
        %   Hertz, as a finite numeric scalar. The default value of this
        %   property is 44.1 kHz.
        OutputSampleRate;

        %StopbandAttenuation Stopband attenuation (dB)
        %   Specify the minimum amount of attenuation in dB, as a finite
        %   numeric scalar. The stopband attenuation specifies the minimum
        %   amount of aliasing/imaging that will occur. The default
        %   stopband attenuation is 80 dB.
        StopbandAttenuation;

        % Handle to freqz plot
        freqzHandle;

    end
end
