classdef SpectrumEstimator< dsp.internal.SpectrumEstimatorBase
%SpectrumEstimator Estimate power spectrum
%   SE = dsp.SpectrumEstimator returns a System object, SE, that computes
%   the frequency power spectrum of real or complex signals via the
%   periodogram method and Welch's averaged, modified periodogram method.
%
%   SE = dsp.SpectrumEstimator(Name=Value, ...) returns a Spectrum
%   Estimator System object, SE, with each specified property name set
%   to the specified value. You can specify additional name-value pair
%   arguments in any order as (Name1=Value1,...,NameN=ValueN).
%
%   Step method syntax:
%
%   P = step(SE, X) computes the frequency spectrum, P, of input X. The
%   columns of x are treated as independent channels.
%
%   [P, PMAX] = step(SE, X) computes P as well as the max-hold frequency
%   spectrum, PMAX, of input X. The max-hold spectrum is computed by
%   keeping, at each frequency bin, the maximum value of all the power
%   spectrum estimates. For max-hold computations, OutputMaxHoldSpectrum
%   must be set to true.
%
%   [P, PMIN] = step(SE, X) computes P as well as the min-hold frequency
%   spectrum, PMIN, of input X. The min-hold spectrum is computed by
%   keeping, at each frequency bin, the minimum value of all the power
%   spectrum estimates. For min-hold computations, OutputMinHoldSpectrum
%   must be set to true.
%
%   [P, PMAX, PMIN] = step(SE, X) computes the frequency spectrum, P, of
%   input X, the max-hold spectrum, PMAX, of input X, and the min-hold
%   spectrum, PMIN, of input X. OutputMaxHoldSpectrum and
%   OutputMinHoldSpectrum must be set to true.
%
%   System objects may be called directly like a function instead of
%   using the step method. For example, y = step(obj, x) and y = obj(x)
%   are equivalent.
%
%   SpectrumEstimator methods:
%
%   step                 - Compute power spectrum of input (see above)
%   release              - Allow property value and input characteristics
%                          changes, and release Spectrum Estimator
%                          resources
%   clone                - Create Spectrum Estimator object with same
%                          property values
%   isLocked             - Display locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>                - Reset the states of the Spectrum Estimator
%   getRBW               - Get the resolution bandwidth of the spectrum
%   getFrequencyVector   - Get the vector of frequencies at which the
%                          spectrum is estimated
%
%   SpectrumEstimator properties:
%
%   SpectrumType                 - Spectrum type
%   FFTLengthSource              - Source of the FFT length value
%   FFTLength                    - FFT length
%   Method                       - Welch or filter bank
%   NumTapsPerBand               - Number of filter taps per frequency band
%   Window                       - Window function
%   SidelobeAttenuation          - Sidelobe attenuation of window
%   FrequencyRange               - Frequency range of the Spectrum estimate
%   PowerUnits                   - Power units
%   AveragingMethod              - Averaging method
%   SpectralAverages             - Number of spectral averages
%   ForgettingFactor             - Forgetting factor
%   ReferenceLoad                - Reference load
%   OutputMaxHoldSpectrum        - Output max-hold spectrum
%   OutputMinHoldSpectrum        - Output min-hold spectrum
%   SampleRate                   - Sample rate of input
%
%   % Example
%   %  Compare spectral estimates of sinusoids in noise using a Hann
%   % window Welch-based approach and filter-bank-based approach
%   FrameSize = 420;
%   Fs = 1;
%   sinegen = dsp.SineWave('SampleRate',Fs,...
%     'SamplesPerFrame',FrameSize,...
%     'Frequency',[0.16 0.2 0.205 0.25],...
%     'Amplitude',[2e-5 1  0.05  0.5]);
%   NoiseVar = 1e-10;
%   numAvgs = 8;
%
%   hannEstimator = dsp.SpectrumEstimator('PowerUnits', 'dBm',...
%     'Window','Hann','FrequencyRange', 'onesided',...
%     'SpectralAverages',numAvgs,'SampleRate',Fs);
%
%   filterBankEstimator = dsp.SpectrumEstimator('PowerUnits', 'dBm',...
%     'Method','Filter bank','FrequencyRange', 'onesided',...
%     'SpectralAverages',numAvgs,'SampleRate',Fs);
%
%   spectrumPlotter = dsp.ArrayPlot(...
%     'PlotType','Line','SampleIncrement',Fs/FrameSize,...
%     'YLimits',[-250,50],'YLabel','dBm',...
%     'ShowLegend',true,'ChannelNames',{'Hann window','Filter bank'});
%
%   tic,
%   while toc < 10
%     x = sum(sinegen(),2) + sqrt(NoiseVar)*randn(FrameSize,1);
%     Pse_hann = hannEstimator(x);
%     Pfb = filterBankEstimator(x);
%     spectrumPlotter([Pse_hann,Pfb]);
%   end
%
%   See also dsp.CrossSpectrumEstimator, dsp.TransferFunctionEstimator,
%            spectrumAnalyzer.

 
    %   Copyright 2013-2022 The MathWorks, Inc.

    methods
        function out=SpectrumEstimator
            %SpectrumEstimator   Construct the SpectrumEstimator class.
        end

        function out=computeRBW(~) %#ok<STOUT>
        end

        function out=computeWindowFFT(~) %#ok<STOUT>
            % Window the data and compute FFT
        end

        function out=convertAndScale(~) %#ok<STOUT>
        end

        function out=getHeaderImpl(~) %#ok<STOUT>
            % MATLAB System block header
        end

        function out=getIconImpl(~) %#ok<STOUT>
            % MATLAB system block icon
        end

        function out=getInputNamesImpl(~) %#ok<STOUT>
        end

        function out=getNumOutputsImpl(~) %#ok<STOUT>
        end

        function out=getOutputDataTypeImpl(~) %#ok<STOUT>
        end

        function out=getOutputNamesImpl(~) %#ok<STOUT>
        end

        function out=getOutputSizeImpl(~) %#ok<STOUT>
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
            %             mainProps = {'SpectralAverages', 'Method', 'FrequencyRange', ...
            %                 'PowerUnits', 'SampleRate'};
            %
            %             advancedProps = {'FFTLengthSource', 'FFTLength', 'Window', ...
            %                 'SidelobeAttenuation', 'NumTapsPerBand', 'SpectrumType', 'ReferenceLoad', ...
            %                 'OutputMaxHoldSpectrum', 'OutputMinHoldSpectrum'};
            %
            %             advancedPropsTitle = getString(message('dsp:system:Shared:Parameters'));
            %             mainGroup = matlab.system.display.SectionGroup(...
            %                 'TitleSource', 'Auto', 'PropertyList', mainProps);
            %             visualizationGroup = matlab.system.display.SectionGroup(...
            %                 'Title', advancedPropsTitle, 'PropertyList', advancedProps);
            %
            %             groups = [mainGroup visualizationGroup];
        end

        function out=getRBW(~) %#ok<STOUT>
            % getRBW Get the resolution bandwidth of the Spectrum, in Hz.
            %   The resolution bandwidth, RBW, is the smallest positive frequency,
            %   or frequency interval, that can be resolved. It is equal to
            %   ENBW * SampleRate/ L, where L is the input length, and ENBW is the
            %   two-sided equivalent noise bandwidth of the window (in Hz). For
            %   example, if SampleRate = 100, L = 1024, and Window = 'Hann',
            %   RBW =  enbw(hann(1024)) * 100 / 1024
        end

        function out=getTunablePropertiesSpecificationImpl(~) %#ok<STOUT>
        end

        function out=initializeSpectrumCache(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isOutputComplexImpl(~) %#ok<STOUT>
        end

        function out=isOutputFixedSizeImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

    end
    properties
        %Method Spectrum estimation method
        % Specify the spectrum estimation method as one of 'Welch' |
        % 'Filter bank'. The filter bank method provides better resolution,
        % lower spectral leakage, a more accurate noise floor and more
        % precise peaks at the expense of increased computation and slower
        % tracking. The default is 'Welch'
        Method;

        %NumTapsPerBand Number of filter taps per frequency band
        %   Specify the number of filter coefficients or taps for each
        %   frequency band. This also corresponds to the number of filter
        %   coefficients per polyphase branch. The total number of filter
        %   coefficients is given by NumTapsPerBand times FFTLength. This
        %   property applies when you set Method to 'Filter bank'. The
        %   default is 12.
        NumTapsPerBand;

        %OutputMaxHoldSpectrum Output max-hold spectrum
        %   Set this property to true so that the Spectrum Estimator computes and
        %   outputs the max-hold spectrum of each input channel. The max-hold
        %   spectrum is computed by keeping, at each frequency bin, the maximum
        %   value of all the power spectrum estimates. The default is false.
        OutputMaxHoldSpectrum;

        %OutputMinHoldSpectrum Output min-hold spectrum
        %   Set this property to true so that the Spectrum Estimator computes and
        %   outputs the min-hold spectrum of each input channel. The min-hold
        %   spectrum is computed by keeping, at each frequency bin, the minimum
        %   value of all the power spectrum estimates. The default is false.
        OutputMinHoldSpectrum;

        %PowerUnits Power units
        % Specify the spectrum power units as one of 'Watts' | 'dBW' | 'dBm'. The
        % default is 'Watts'
        PowerUnits;

        %ReferenceLoad Reference Load
        %   Specify the load that the spectrum estimator uses as a reference to
        %   compute power values as a real, positive scalar in Ohms. The default
        %   is 1 Ohm. This property is tunable.
        ReferenceLoad;

        %SpectrumType Spectrum type
        %   Specify the spectrum type as one of 'Power' | 'Power density'. When
        %   the spectrum type is 'Power', the power spectral density is scaled by
        %   the equivalent noise bandwidth of the window (in Hz). The default is
        %   'Power'.
        SpectrumType;

    end
end
