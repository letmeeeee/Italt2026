classdef MedianFilter< matlab.System
%   MedianFilter Perform median filtering 
%   MEDFILT = dsp.MedianFilter returns a System object, MEDFILT, that
%   computes the median of the input signal.
%
%   MEDFILT = dsp.MedianFilter('Name', Value, ...) returns a median filter
%   System object, MEDFILT, with each specified property name set to the
%   specified value. You can specify additional name-value pair arguments
%   in any order as (Name1,Value1,...,NameN, ValueN).
%
%   MEDFILT = dsp.MedianFilter(Length) returns a median filter object,
%   MEDFILT, with the WindowLength property set to Length.
%
%   Step method syntax:
%
%   Y = step(MEDFILT, X) computes the median, Y, of the input X. Each
%   column of X is a channel. The System object computes the median of each
%   channel of the input signal independently over time. The input must be
%   real.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   MedianFilter methods:
%
%   step                     - Compute median of input
%   release                  - Allow property value and input 
%                              characteristics changes, and release median
%                              filter resources
%   clone                    - Create median filter object with same
%                              property values
%   isLocked                 - Display locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>                    - Reset the states of the median filter
%
%   MedianFilter properties:
%
%   WindowLength            - Sliding window length
%
%   % EXAMPLE: Pass a sine wave corrupted by high-frequency noise through a
%   % median filter. Compare with a moving average filter. 
%   Fs = 1000;
%   scope  = timescope('SampleRate',Fs,...
%                      'TimeSpanSource','property',...
%                      'TimeSpan',1,...
%                      'YLimits',[-3 3],...
%                      'LayoutDimensions',[3 1]);
%   scope.ActiveDisplay = 1;
%   scope.Title = 'Signal + Noise';
%   scope.ActiveDisplay = 2;
%   scope.Title = 'Moving Average Output (Window Length = 7)';
%   scope.ActiveDisplay = 3;
%   scope.Title = 'Median Filter Output (Window Length = 7)';
% 
%   FrameLength = 256;
%
%   medfilt   = dsp.MedianFilter(7);
%   mavrg     = dsp.MovingAverage(7);
% 
%   sine = dsp.SineWave('SampleRate',Fs,'Frequency',10,...
%                       'SamplesPerFrame',FrameLength);
%   tic;
%   while (toc < 5)
%     hfn = 3 * (rand(FrameLength,1) < 0.02);
%     x = sine() + 1e-2 * randn(FrameLength,1) + hfn;
%     y1 = mavrg(x);
%     y2 = medfilt(x);
%     scope(x,y1,y2);
%   end
%
%   See also dsp.MovingMaximum, dsp.MovingMinimum, dsp.MovingAverage, 
%   dsp.HampelFilter

 
%   Copyright 2016-2021 The MathWorks, Inc.

    methods
        function out=MedianFilter
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
            %  Get the number of input channels
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

    end
    properties
        % NumChannels Cached number of channels (used for error checking)
        NumChannels;

        %WindowLength Window length
        % Specify the sliding window length as a positive, scalar integer.
        % When WindowLength is odd, the median is equal to the middle value
        % in the sorted window. When WindowLength is even, the median is
        % equal to the average of the two middle values in the sorted
        % window. The default is 5.
        WindowLength;

        % pMID Internal object used to compute median
        pMID;

        % pNumChannels Cached number of channels (used to allocate state)
        pNumChannels;

    end
end
