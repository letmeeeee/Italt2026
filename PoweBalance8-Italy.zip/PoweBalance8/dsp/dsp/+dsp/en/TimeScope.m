classdef TimeScope< dsp.webscopes.TimePlotBaseWebScope
%TimeScope Display time-domain signals
%   SCOPE = dsp.TimeScope returns a System object, SCOPE, that can display
%   real and complex valued floating and fixed-point signals in the time
%   domain.
%
%   SCOPE = dsp.TimeScope(Name=Value, ...) returns a Time Scope System
%   object, SCOPE, with each specified property name set to the specified
%   value. You can specify name-value pair arguments in any order as
%   (Name1=Value1, ..., NameN=ValueN).
%
%   SCOPE = dsp.TimeScope(NUMINPUTS, SAMPLERATE, Name=Value, ...) returns a
%   Time Scope System object, SCOPE, with the NumInputPorts property set to
%   NUMINPUTS, the SampleRate property set to SAMPLERATE, and other
%   specified properties set to the specified values. NUMINPUTS and
%   SAMPLERATE are value-only arguments. To specify a value-only argument,
%   you must also specify all preceding value-only arguments. You can
%   specify name-value pair arguments in any order.
%
%   Step method syntax:
%
%   step(SCOPE, X) displays the signal, X, in the Time Scope figure.
%
%   step(SCOPE, X1, X2, ..., XN) displays the signals X1, X2, ..., XN in
%   the Time Scope figure when the NumInputPorts property is set to N. X1,
%   X2, ... XN can have different data types and dimensions.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, step(obj, x) and obj(x) are equivalent.
%
%   TimeScope methods:
%
%   step      - Display signal in the Time Scope figure (see above)
%   release   - Allow property value and input characteristics changes, and
%               release Time Scope resources
%   clone     - Create Time Scope object with same property values
%   isLocked  - Display locked status (logical)
%   reset     - Clear Time Scope figure
%   show      - Turn on visibility of Time Scope figure
%   hide      - Turn off visibility of Time Scope figure
%   isVisible - Return visibility of Time Scope figure (logical)
%
%   TimeScope properties:
%
%   NumInputPorts         - Number of input signals
%   SampleRate            - Sample rate of inputs
%   TimeSpanSource        - Source of time span
%   TimeSpan              - Time span
%   TimeSpanOverrunAction - Wrap or scroll when the TimeSpan is overrun
%   PlotType              - Option to control the type of plot
%   AxesScaling           - Axes scaling mode
%   AxesScalingNumUpdates - Number of updates before scaling
%   LayoutDimensions      - Layout grid dimensions
%   TimeUnits             - Units of the time axis
%   TimeDisplayOffset     - Time display offset
%   TimeAxisLabels        - Time-axis labels
%   MaximizeAxes          - Maximize axes control
%   BufferLength          - Length of the buffer used for each input signal
%   FrameBasedProcessing  - Process input in frames or as samples
%   MeasurementChannel    - Channel for which measurement is computed
%   BilevelMeasurements   - Bilevel measurements
%   CursorMeasurements    - Cursor measurements
%   PeakFinder            - Peak finder measurements
%   SignalStatistics      - Signal statistics measurements
%   Trigger               - Trigger measurements
%   Name                  - Caption to display on Time Scope window
%   Position              - Scope window position in pixels
%   ChannelNames          - Names for the input data channels
%   ActiveDisplay         - Active display for display-specific properties
%   PlotAsMagnitudePhase  - Plot signal as Magnitude and Phase
%   Title                 - Display title
%   YLabel                - Y-axis label
%   YLimits               - Y-axis limits
%   ShowLegend            - Option to turn on legend
%   ShowGrid              - Option to turn on grid
%
%   % EXAMPLE #1: View a sine wave on the Time Scope.
%     SINE = dsp.SineWave(Frequency=100, SampleRate=1000);
%     SINE.SamplesPerFrame = 10;
%     SCOPE = dsp.TimeScope(SampleRate=SINE.SampleRate,TimeSpan=0.1);
%     for index = 1:10
%        x = SINE();
%        SCOPE(x);
%     end
%     release(SCOPE);
%
%   % EXAMPLE #2: View two sine waves with different sample rates and
%   %             time offsets.
%     Fs = 1000;  % Sampling frequency
%     SINE = dsp.SineWave(Frequency=50,...
%                         SampleRate=Fs, ...
%                         SamplesPerFrame=100);
%
%     % Use an FIRDecimator System object to decimate the signal by 2.
%     FIRDECIM = dsp.FIRDecimator;
%
%     % Create and configure a TimeScope System object with 2 input ports
%     % (channels).
%     SCOPE2 = dsp.TimeScope(2, [Fs Fs/2], ...
%                            TimeDisplayOffset=[0 38/Fs], ...
%                            TimeSpan=0.25, ...
%                            YLimits=[-1 1], ...
%                            ShowLegend=true);
%     for index = 1:2
%       xsine = SINE();
%       xdec = FIRDECIM(xsine);
%       SCOPE2(xsine, xdec);
%     end
%     release(SCOPE2);
%
%   See also dsp.ArrayPlot, spectrumAnalyzer

 
%   Copyright 2009-2022 The MathWorks, Inc.

    methods
        function out=TimeScope
        end

        function out=getPropertyGroups(~) %#ok<STOUT>
            % Return list of property groups for display
        end

        function out=validatePropertiesOnSet(~) %#ok<STOUT>
        end

    end
    properties
        %FrameBasedProcessing Process input in frames or as samples
        %   Set this property to true to enable frame-based processing</a>.
        %   Set this property to false to enable sample-based processing.
        %   The default value of this property is true.
        FrameBasedProcessing;

    end
end
