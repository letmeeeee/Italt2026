classdef AnalyticSignal< matlab.System
%AnalyticSignal Analytic signals of discrete-time inputs
%   AS = dsp.AnalyticSignal returns a System object, AS, that computes the
%   complex analytic signal corresponding to each channel of a real M-by-N
%   input matrix.
%
%   AS = dsp.AnalyticSignal('PropertyName', PropertyValue, ...) returns an
%   analytic signal System object, AS, with each specified property set to
%   the specified value.
%
%   AS = dsp.AnalyticSignal(FILTERORDER,'PropertyName',PropertyValue, ...)
%   returns an analytic signal System object, AS, with FilterOrder property
%   set to FILTERORDER and other specified properties set to the specified
%   values.
%
%   The real part of the analytic signal in each channel is a replica of
%   the real input in that channel, and the imaginary part is the Hilbert
%   transform of the input. In the frequency domain, the analytic signal
%   retains the positive frequency content of the original signal while
%   zeroing-out negative frequencies and doubling the DC component. The
%   object computes the Hilbert transform using an equiripple FIR filter.
%
%   Step method syntax:
%
%   Y = step(AS, X) computes the analytic signal, Y, of the input X. Each
%   column of X is treated as an independent channel of input.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   AnalyticSignal methods:
%
%   step     - See above description for use of this method
%   release  - Allow property value and input characteristics changes
%   clone    - Create analytic signal object with same property values
%   isLocked - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>    - Reset filter states
%
%   AnalyticSignal properties:
%
%   FilterOrder          - Filter order used to compute Hilbert transform
%
%   % EXAMPLE: Compute the analytic signal of a sinusoidal input.
%       t = (-1:0.01:1)';
%       x = sin(4*pi*t); 
%       analyticSig = dsp.AnalyticSignal(200);   % Filter order = 200
%       y = analyticSig(x);
%       subplot(2,1,1), plot(t, x); 
%       title('Original Signal');
%       subplot(2,1,2), plot(t, [real(y) imag(y)]); 
%       title('Analytic signal of the input')
%       legend('Real signal', 'Imaginary signal', 'Location', 'best');
%
%   See also dsp.FFT, dsp.IFFT.

 
%   Copyright 1995-2021 The MathWorks, Inc.

    methods
        function out=AnalyticSignal
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            % Only floating point inputs are supported
        end

    end
    properties
        %FilterOrder Filter order used to compute Hilbert transform
        %   Specify the order of the equiripple filter used in computing the
        %   Hilbert transform as an even integer scalar. The default value of
        %   this property is 100.
        FilterOrder;

    end
end
