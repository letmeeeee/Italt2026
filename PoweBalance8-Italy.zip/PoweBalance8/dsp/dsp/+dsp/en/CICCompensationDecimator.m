classdef CICCompensationDecimator< dsp.internal.CICCompensationBase
%CICCompensationDecimator Compensate for CIC filter using an FIR decimator
%   The shortcomings of a CIC decimator, namely its passband droop and wide
%   transition region, can be compensated by following it with a
%   compensation decimator. This System object provides the ability to
%   design and use such a compensator for the CIC filter.
%   
%   CFIR = dsp.CICCompensationDecimator returns a System object, CFIR, that
%   applies a FIR decimator to each channel of the input signal. Using the
%   properties of the object, the decimation filter can be designed to
%   compensate for a preceding CIC filter.
%   
%   CFIR = dsp.CICCompensationDecimator('Name', Value, ...) returns a CIC
%   compensation decimator System object, CFIR, with each specified
%   property set to the specified value.
%   
%   CFIR = dsp.CICCompensationDecimator(DECIM, 'Name', Value, ...) returns
%   a CIC compensation decimator System object, CFIR, with the
%   DecimationFactor property set to DECIM, and other specified properties
%   set to the specified values.
%
%   CFIR = dsp.CICCompensationDecimator(CICDECIM, 'Name', Value, ...)
%   returns a CIC compensation decimator System object, CFIR, with the
%   CICRateChangeFactor, CICNumSections and CICDifferentialDelay properties
%   set using their corresponding values in the dsp.CICDecimator System
%   object CICDECIM, and other specified properties set to the specified
%   values.
%
%   CFIR = dsp.CICCompensationDecimator(CICDECIM, DECIM, 'Name', Value,
%   ...) returns a CIC compensation decimator System object, CFIR, with the
%   CICRateChangeFactor, CICNumSections and CICDifferentialDelay properties
%   set using their corresponding values in the dsp.CICDecimator System
%   object CICDECIM, the DecimationFactor property set to DECIM, and other
%   specified properties set to the specified values.
%
%   Step method syntax:
%
%   Y = step(CFIR, X) outputs the filtered and downsampled values, Y, of
%   the input signal X. A KixN input matrix is treated as N independent
%   channels, and the System object decimates each channel over time and
%   generates a KoxN output matrix. Ko = Ki/M where M is the decimation
%   factor. The object supports real and complex floating-point and
%   fixed-point inputs, except for complex unsigned fixed-point inputs.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   CICCompensationDecimator methods:
%
%   step      - See above description for use of this method
%   release   - Allow property value and input characteristics changes
%   clone     - Create CIC compensation decimator object with same property 
%               values
%   isLocked  - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>     - Reset the internal states to initial conditions
% generatehdl - Generate HDL code. (Filter Design HDL Coder Required)
%
%   CICCompensationDecimator properties:
%
%   SampleRate            - Input sample rate
%   DecimationFactor      - Decimation factor
%   CICRateChangeFactor   - Rate change factor of the CIC filter to be
%                           compensated
%   CICNumSections        - Number of sections of the CIC filter to be
%                           compensated
%   CICDifferentialDelay  - Differential delay of the CIC filter to be
%                           compensated
%   DesignForMinimumOrder - Option to have a minimum order design for the
%                           filter in compensation decimator
%   FilterOrder           - Order of the filter in compensation decimator
%   PassbandFrequency     - Passband frequency of compensation filter
%   StopbandFrequency     - Stopband frequency of compensation filter
%   PassbandRipple        - Allowed passband ripple of compensation filter
%   StopbandAttenuation   - Minimum attenuation needed in stopband of
%                           compensation filter
%
%   This System object supports several filter analysis methods. For more
%   information, type dsp.CICCompensationDecimator.helpFilterAnalysis.
%
%   This System object supports fixed-point operations. For more
%   information, type dsp.CICCompensationDecimator.helpFixedPoint.
%
%   % EXAMPLE: Design a compensation decimator for an existing CIC
%   % decimator and visualize the frequency response of the cascade. Use it
%   % on a sample input.
%   
%   % CONSTRUCTION
%   cicdecim = dsp.CICDecimator(DecimationFactor = 6, ...
%                           NumSections = 6);
%   fs = 16e3;     % Sampling frequency of input of compensation decimator
%   fPass = 4e3;   % Passband frequency
%   fStop = 4.5e3; % Stopband frequency
%   cfir = dsp.CICCompensationDecimator(cicdecim, ...
%               DecimationFactor = 2, ...
%               PassbandFrequency = fPass, ...
%               StopbandFrequency = fStop, ...
%               SampleRate = fs);
%   
%   % FREQUENCY RESPONSE
%   % Next, visualize the cascade frequency response
% 
%   filtcasc = dsp.FilterCascade(cicdecim, cfir);
%   f = fvtool(cicdecim, cfir, filtcasc, 'Fs', [fs*6, fs, fs*6], ...
%              'Arithmetic', 'fixed');
%   set(f, 'NormalizeMagnitudeto1', 'on');
%   legend(f,'CIC Decimator','CIC Compensation Decimator', ...
%            'Overall Response');
% 
%   % STEP
%   sigsource = dsp.SignalSource(fi(rand(1200,1),1,16,15), ...
%                                SamplesPerFrame = 120);
%   y = fi(zeros(0,1), 1, 32, 20);
%   for ind = 1:10
%       x2 = cicdecim( sigsource() );
%       y = [y; cfir(x2)];
%   end

 
%   Copyright 2013-2022 The MathWorks, Inc.

    methods
        function out=CICCompensationDecimator
        end

        function out=crossValidateProperties(~) %#ok<STOUT>
            % Verify the values of properties before designing filter
        end

        function out=designFilter(~) %#ok<STOUT>
            % Create decimator System object
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
        end

        function out=helpFixedPoint(~) %#ok<STOUT>
            %helpFixedPoint Display CICCompensationDecimator System object
            %               fixed-point information
            %   dsp.CICCompensationDecimator.helpFixedPoint displays 
            %   information about fixed-point properties and operations of 
            %   the CICCompensationDecimator System object.
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=postProcessSampleRate(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
            % Release the decimator object. This allows users to
            % subsequently modify non-tunable properties and call the step
            % method with a different input datatype, different frame size,
            % or a different number of channels.
        end

        function out=resetImpl(~) %#ok<STOUT>
            % Reset the states of decimator object
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
            % Decimate the input by the specified decimation factor
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            % Verify input to the step function
        end

        function out=validatePropertiesImpl(~) %#ok<STOUT>
        end

    end
    properties
        %DecimationFactor Decimation factor
        %   Specify a positive integer amount by which the input signal
        %   will be decimated. The default value of this property is 2.
        DecimationFactor;

        % NumChannels Cached number of channels (used for error checking)
        NumChannels;

        %PassbandFrequency  Passband edge frequency (Hz)
        %   Specify the passband edge frequency of the compensation filter
        %   in Hertz, as a positive real scalar smaller than half the
        %   input sample rate. The default value of this property is
        %   100000 Hz.
        PassbandFrequency;

        % SampleRate Input sample rate (Hz)
        %   Specify the sampling rate of the input in Hertz as a finite
        %   numeric scalar. the default is 1.2 MHz.
        SampleRate;

        %StopbandFrequency  Stopband edge frequency (Hz)
        %   Specify the stopband edge frequency of the compensation filter
        %   in Hertz, as a positive real scalar smaller than half the
        %   input sample rate. This property applies when you set the
        %   DesignForMinimumOrder property to true. The default value of
        %   this property is 400000 Hz.
        StopbandFrequency;

        pSR;

        pStructure;

    end
end
