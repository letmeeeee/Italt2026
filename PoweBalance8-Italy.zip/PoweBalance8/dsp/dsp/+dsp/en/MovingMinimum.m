classdef MovingMinimum< dsp.internal.AbstractMovingMinMax
%   MovingMinimum Compute moving minimum 
%   MMIN = dsp.MovingMinimum returns a System object, MMIN, that computes
%   the moving minimum of the input signal.
%
%   MMIN = dsp.MovingMinimum('Name', Value, ...) returns a moving minimum
%   System object, MMIN, with each specified property name set to the
%   specified value. You can specify additional name-value pair arguments
%   in any order as (Name1,Value1,...,NameN, ValueN).
%
%   MMIN = dsp.MovingMinimum(Length,'PropertyName', PropertyValue,
%   ...) returns a moving minimum object, MMIN, with the WindowLength
%   property set to Length, and other properties set to the specified
%   values.
%
%   Step method syntax:
%
%   Y = step(MMIN, X) computes the moving minimum, Y, of the input X. Each
%   column of X is a channel. The System object computes the moving minimum
%   of each channel of the input signal independently over time. X must be
%   real.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   MovingMinimum methods:
%
%   step                     - Compute moving minimum of input
%   release                  - Allow property value and input 
%                              characteristics changes, and release moving 
%                              minimum resources
%   clone                    - Create moving minimum object with same
%                              property values
%   isLocked                 - Display locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>                    - Reset the states of the moving minimum
%
%   MovingMinimum properties:
%
%   SpecifyWindowLength     - Choose to specify sliding window length
%   WindowLength            - Sliding window length
%
%   % EXAMPLE: Compute the moving minimum of the sum of three sine waves 
%   % with varying amplitude. Use a sliding window of length 30.
%   sine = dsp.SineWave('SampleRate',100,...
%                       'Frequency',[2 5 10],...
%                       'SamplesPerFrame',100);
%   mmin = dsp.MovingMinimum(30);
%   scope  = timescope('SampleRate',100,...
%                      'TimeSpanOverrunAction','wrap', ...
%                      'TimeSpanSource','property',...
%                      'TimeSpan',10, ...
%                      'YLimits',[-4.5 4.5]);
%   for index = 1:100
%     sine.Amplitude = rand(1,3);
%     x = sum(sine(),2);
%     xmin = mmin(x);
%     scope([x,xmin])
%   end
%
%   See also dsp.MovingMaximum, dsp.MovingAverage, dsp.MovingRMS, 
%   dsp.MovingVariance, dsp.MovingStandardDeviation

 
%   Copyright 2016-2020 The MathWorks, Inc.

    methods
        function out=MovingMinimum
        end

        function out=setupStatisticObject(~) %#ok<STOUT>
        end

    end
end
