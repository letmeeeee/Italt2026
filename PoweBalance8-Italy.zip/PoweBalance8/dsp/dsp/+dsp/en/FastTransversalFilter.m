classdef FastTransversalFilter< matlab.System
%FastTransversalFilter Computes output, error and coefficients using fast
%transversal least-squares FIR adaptive filter.
%
%   FTFILTER = dsp.FastTransversalFilter returns a fast transversal
%   least-squares FIR adaptive filter System object(TM), FTFILTER. This
%   System object is used to compute the filtered output and the filter
%   error for a given input and desired signal.
%
%   FTFILTER = dsp.FastTransversalFilter('PropertyName',PropertyValue, ...)
%   returns a FastTransversalFilter System object, H, with each specified
%   property set to the specified value.
%
%   FTFILTER = dsp.FastTransversalFilter(LEN, 'PropertyName',
%   PropertyValue, ...) returns a FastTransversalFilter System object,
%   FTFILTER, with the Length property set to LEN, and other specified
%   properties set to the specified values.
%
%   Step method syntax:
%
%   [Y, ERR] = step(FTFILTER, X, D) filters the input X, using D as the
%   desired signal, and returns the filtered output in Y and the filter
%   error in ERR. The System object estimates the filter weights needed to
%   minimize the error between the output signal and the desired signal.
%   These filter weights can be obtained by accessing the Coefficients
%   property after calling the step method by H.Coefficients
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   FastTransversalFilter methods:
%
%   step        - See above description for use of this method
%   release     - Allow changes in non-tunable property values and input
%                 characteristics
%   clone       - Create Fast Transversal filter object with the same
%                 property values and internal states
%   isLocked    - Locked status of the filter object (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>       - Reset the internal states to their initial conditions
%   msesim      - Mean-square error for Fast Transversal filter
%
%   FastTransversalFilter properties:
%
%   Method                      - Method to calculate the filter
%                                 coefficients
%   Length                      - Length of filter coefficients vector
%   SlidingWindowBlockLength    - Width of the sliding window
%   ForgettingFactor            - Fast transversal filter forgetting factor
%   InitialPredictionErrorPower - Initial prediction error power
%   InitialConversionFactor     - Initial conversion factor (gamma)
%   InitialCoefficients         - Initial coefficients of the filter
%   LockCoefficients            - Locked status of the coefficient updates
%
%
%   % EXAMPLE #1: System identification of an FIR filter
%   % Initialize
%   ftfilt = dsp.FastTransversalFilter(11,ForgettingFactor = 0.99);
%   firfilt = dsp.FIRFilter;                    % System to be identified
%   firfilt.Numerator = fir1(10,.25);
%   x = randn(1000,1);                      % input signal
%   d = firfilt(x) + 0.01*randn(1000,1);  % desired signal
%   
%   % Step with input and desired signals
%   [y,e] = ftfilt(x,d);
%   w = ftfilt.Coefficients;
% 
%   % Plot desired signal, output signal, and error signal
%   figure, subplot(2,1,1), plot(1:1000,[d,y,e]);
%   title('System Identification of an FIR filter');
%   legend('Desired', 'Output', 'Error');
%   xlabel('Time index'); ylabel('Signal value');
%   
%   % Plot actual and estimated filter coefficient values
%   subplot(2,1,2); stem([firfilt.Numerator; w].');
%   legend('Actual','Estimated');
%   xlabel('Coefficient #'); ylabel('Coefficient value');
%
%   See also dsp.LMSFilter, dsp.RLSFilter, dsp.AffineProjectionFilter,
%            dsp.AdaptiveLatticeFilter, dsp.FrequencyDomainAdaptiveFilter,
%            dsp.FilteredXLMSFilter, dsp.FIRFilter.

 
%   Copyright 1995-2023 The MathWorks, Inc.

    methods
        function out=FastTransversalFilter
            % Supports name-value pair arguments as well as alternatively
            % allows the Length property to be a value-only argument.
        end

        function out=backwardPredictionUpdate(~) %#ok<STOUT>
        end

        function out=forwardPredictionUpdate(~) %#ok<STOUT>
        end

        function out=getDiscreteStateImpl(~) %#ok<STOUT>
        end

        function out=getFilterParameterStruct(~) %#ok<STOUT>
        end

        function out=getNumInputsImpl(~) %#ok<STOUT>
            % Specify number of System inputs
        end

        function out=getNumOutputsImpl(~) %#ok<STOUT>
            % Specify number of System outputs
        end

        function out=initializeVariables(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=loadFTFDiscreteStates(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=msesim(~) %#ok<STOUT>
            %MSESIM Mean-squared error for Fast Transversal filter.
            %   [MSE,MEANW,W,TRACEK] = MSESIM(FTF,X,D,M) calculates the
            %   sequence of mean-square errors and three other parameters
            %   corresponding to the simulated behavior of the Fast
            %   Transversal adaptive filter defined by FTF.
            % 
            %   Inputs: 
            %   X and D are matrices of input signal sequences and desired
            %   response signal sequences respectively. M specifies an
            %   optional decimation factor for computing outputs MSE,
            %   MEANW, and TRACEK. If M > 1, every Mth predicted value of
            %   each of these sequences is saved. If omitted, the value of
            %   M defaults to one.
            %
            %   Outputs:
            %   MSE     - Sequence of mean-square errors. This column
            %             vector contains estimates of the mean-square
            %             error of the adaptive filter at each time
            %             instant. The length of MSE is equal to SIZE(X,1).
            %             The columns of the matrix X contain individual
            %             input signal sequences, and the columns of the
            %             matrix D contain corresponding desired response
            %             signal sequences.
            %   MEANW   - Sequence of coefficient vector means. The columns
            %             of this matrix contain estimates of the mean
            %             values of the LMS adaptive filter coefficients at
            %             each time instant. The dimensions of MEANW are
            %             (SIZE(X,1)) x (FTF.length).
            %   W       - Estimate of the final values of the adaptive
            %             filter coefficients for the algorithm
            %             corresponding to FTF.
            %   TRACEK  - Sequence of total coefficient error powers. This
            %             column vector contains estimates of the total
            %             coefficient error power of the LMS adaptive
            %             filter at each time instant. The length of TRACEK
            %             is equal to SIZE(X,1).
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
            % Whenever the tunable properties are changed, update the
            % FilterParameters private property that stores their type
            % casted version in a structure.
        end

        function out=resetImpl(~) %#ok<STOUT>
            % Local copy of the required properties
        end

        function out=saveFTFDiscreteStates(~) %#ok<STOUT>
            % Save final conversion factor
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Set InputDataType to be the data type of x and initialize the
            % FilterParameters property based on that. The FilterParameters
            % property is a structure with all the filter parameters casted
            % to the data type of the inputs.
        end

        function out=stepFTF(~) %#ok<STOUT>
            % Load the required DiscreteState properties
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=stepSWFTF(~) %#ok<STOUT>
            % Load the required DiscreteState properties
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            % Validating the size of the inputs x and d. Inputs must be
            % vectors.
        end

        function out=validatePropertiesImpl(~) %#ok<STOUT>
        end

    end
    properties
        %BackwardPredictionCoefficients Backward prediction coefficients
        %   This property stores the current backward prediction
        %   coefficients as a row vector. Its length is equal to the Length
        %   property value. This property is initialized to a vector of
        %   zeros of appropriate length and data type.
        BackwardPredictionCoefficients;

        %BackwardPredictionErrorPower Backward prediction error power
        %   This property stores the current backward prediction
        %   least-squares error power as a scalar value. This property is
        %   initialized to the InitialPredictionErrorPower property value.
        BackwardPredictionErrorPower;

        %Coefficients Current coefficients of the filter
        %   This property stores the current coefficients of the filter as
        %   a row vector of length equal to the Length property value. This
        %   property is initialized to the values of InitialCoefficients
        %   property.
        Coefficients;

        %ConversionFactor Current conversion factor (gamma) value
        %   This property stores the value of the current conversion factor
        %   value corresponding to the fast transversal filter. If the
        %   Method property is set to 'Fast transversal least-squares',
        %   this property is a numeric scalar. If the Method property is
        %   set to 'Sliding-window fast transversal least-squares', this
        %   property is a numeric two-element row vector. This property is
        %   initialized to the values of the InitialConversionFactor
        %   property.
        ConversionFactor;

        %DesiredStates Current desired states of the filter
        %   This property stores the current desired signal states of the
        %   adaptive filter as a column vector. Its length is equal to the
        %   SlidingWindowBlockLength property value. This property is
        %   applicable only if the Method property is set to
        %   'Sliding-window fast transversal least-squares'. This property
        %   is initialized to a vector of zeros of appropriate length.
        DesiredStates;

        %FilterParameters Private structure to store the filter parameters
        %   This is a private MATLAB structure that stores all the filter
        %   parameters casted to the data type of the inputs. For
        %   FastTransversalFilter System object, the ForgettingFactor
        %   property, the InitialPredictionErrorPower property and the
        %   LockCoefficients property are the filter parameters. The
        %   FilterParameters property is initialized in the setup method.
        FilterParameters;

        %ForgettingFactor Fast transversal filter forgetting factor
        %   Specify the fast transversal filter forgetting factor as a
        %   positive numeric value. Setting this property value to 1
        %   denotes infinite memory while adapting to find the new filter.
        %   It is recommended that the value set to this property should
        %   lie in the range (1-0.5/L, 1], where L is the Length property
        %   value. This property is applicable only if the Method property
        %   is set to 'Fast transversal least-squares'. The default value
        %   of this property is 1. This property is tunable.
        ForgettingFactor;

        %ForwardPredictionCoefficients Forward prediction coefficients
        %   This property stores the current forward prediction
        %   coefficients as a row vector. Its length is equal to the Length
        %   property value. This property is initialized to a vector of
        %   zeros of appropriate length and data type.
        ForwardPredictionCoefficients;

        %ForwardPredictionErrorPower Forward prediction error power
        %   This property stores the current forward prediction
        %   least-squares error power as a scalar value. If the Method
        %   property is set to 'Fast transversal least-squares', This
        %   property is initialized to the value of ((ForgettingFactor ^
        %   Length) * InitialPredictionErrorPower). If the Method property
        %   is set to 'Sliding-window fast transversal least-squares', this
        %   property is initialized to the InitialPredictionErrorPower
        %   property value.
        ForwardPredictionErrorPower;

        %InitialCoefficients Initial coefficients of the filter
        %   Specify the initial value of the FIR adaptive filter
        %   coefficients as a scalar or a vector of length equal to the
        %   Length property value. The default value of this property is 0.
        %   This property is tunable.
        InitialCoefficients;

        %InitialConversionFactor Initial conversion factor (gamma)
        %   Specify the initial value of the conversion factor of the fast
        %   transversal filter.
        %
        %   If the Method property is set to 'Fast transversal
        %   least-squares', this property must be a positive numeric value
        %   less than or equal to 1. In this case, the default value of
        %   this property is 1.
        %
        %   If the Method property is set to 'Sliding-window fast
        %   transversal least-squares', this property must be a two-element
        %   numeric vector. The first element of this vector must lie
        %   within the range (0,1] and the second element must be less than
        %   or equal to -1. In this case, the default value of this
        %   property is [1, -1]. This property is tunable.
        InitialConversionFactor;

        %InitialPredictionErrorPower Initial prediction error power
        %   Specify the initial value of the forward and backward
        %   prediction error vectors as a positive numeric scalar. This
        %   scalar should be sufficiently large to maintain stability and
        %   prevent an excessive number of Kalman gain rescues. The default
        %   value of this property is 10. This property is tunable.
        InitialPredictionErrorPower;

        %InputDataType Data type of the input
        %   This is a private property that stores the data type of the
        %   input. It is used to set the data type of all the
        %   DiscreteState properties and the outputs.
        InputDataType;

        %KalmanGain Current Kalman gain vector
        %   This property stores the current Kalman gain vector. If the
        %   Method property is set to 'Fast transversal least-squares',
        %   this property is a column vector of length equal to the Length
        %   property value. If the Method property is set to
        %   'Sliding-window fast transversal least-squares', this property
        %   is a matrix with the number of rows equal to the Length
        %   property value and the number of columns equal to 2. This
        %   property is initialized to a zero matrix of appropriate
        %   dimension.
        KalmanGain;

        %KalmanGainStates Current Kalman gain states
        %   This property stores the current Kalman gain states of the
        %   filter as a column vector. If the Method property is set to
        %   'Fast transversal least-squares', the length of this vector is
        %   equal to the Length property value. If the Method property is
        %   set to 'Sliding-window fast transversal least-squares', the
        %   length of this vector is equal to the sum of the Length
        %   property value and the SlidingWindowBlockLength property value.
        %   This property is initialized to a zero matrix of appropriate
        %   dimension.
        KalmanGainStates;

        %Length Length of the filter coefficients vector
        %   Specify the length of the FIR filter coefficients vector as a
        %   positive integer value. The default value of this property is
        %   32.
        Length;

        %LockCoefficients Locked status of the coefficient updates
        %   Specify whether the filter coefficient values should be locked.
        %   By default, the value of this property is false, and the object
        %   continuously updates the filter coefficients. If this property
        %   is set to true, the filter coefficients do not get updated and
        %   their values remain at the current value. This property is
        %   tunable.
        LockCoefficients;

        %Method Method to calculate the filter coefficients
        %   Specify the method used to calculate filter coefficients as one
        %   of ['Fast transversal least-squares' | 'Sliding-window fast
        %   transversal least-squares']. The default is 'Fast transversal
        %   least-squares'.
        Method;

        %SlidingWindowBlockLength Width of the sliding window
        %   Specify the width of the sliding window as a positive integer
        %   value greater than or equal to the Length property value. This
        %   property is applicable only if the Method property is set to
        %   'Sliding-window fast transversal least-squares'. The default
        %   value of this property is set to the Length property value.
        SlidingWindowBlockLength;

        %States Current internal states of the filter
        %   This property stores the current internal states of the filter
        %   as a column vector. If the Method property is set to 'Fast
        %   transversal least-squares', the length of this vector is equal
        %   to the Length property value.  If the Method property is set to
        %   'Sliding-window fast transversal least-squares', the length of
        %   this vector is equal to the sum of the Length property value
        %   and the SlidingWindowBlockLength property value. This property
        %   is initialized to a vector of zeros of appropriate length and
        %   data type.
        States;

        %privInitialConversionFactorFTF A private property to store
        %   the default value of the InitialConversionFactor property
        %   if the Method property is set to 'Fast transversal
        %   least-squares'. If the InitialConversionFactor property is
        %   explicitly set, this property must be updated.
        privInitialConversionFactorFTF;

        %privInitialConversionFactorSWFTF A private property to store
        %   the default value of the InitialConversionFactor property if
        %   the Method property is set to 'Sliding-window fast transversal
        %   least-squares'. If the InitialConversionFactor property is
        %   explicitly set, this property must be updated.
        privInitialConversionFactorSWFTF;

        %privSlidingWindowBlockLength A private property to store
        %   the value explicitly set to the SlidingWindowBlockLength
        %   property. This private property is used only if the Method
        %   property is set to 'Sliding-window Fast transversal
        %   least-squares'.
        privSlidingWindowBlockLength;

        %privSlidingWindowBlockLengthDefined A Private logical property to
        % denote whether the SlidingWindowBlockLength property has been
        % explicitly set.
        privSlidingWindowBlockLengthDefined;

    end
end
