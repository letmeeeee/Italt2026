classdef ComplexBandpassDecimator< dsp.internal.SampleRateEngine
%   ComplexBandpassDecimator One-sided bandpass decimator
%   bpdecim = dsp.ComplexBandpassDecimator returns a System object,
%   bpdecim, which independently filters each channel of the input over
%   time using a one-sided, multistage complex bandpass decimation
%   filter. The object determines the bandwidth of interest using the
%   specified center frequency, decimation factor and bandwidth values.
%
%   bpdecim = dsp.ComplexBandpassDecimator(Name=Value, ...) returns a
%   complex bandpass decimator System object, bpdecim, with each
%   specified property name set to the specified value. You can specify
%   additional name-value pair arguments in any order as
%   (Name1=Value1,...,NameN=ValueN).
%
%   bpdecim = dsp.ComplexBandpassDecimator(D) returns a complex
%   bandpass decimator object, bpdecim, with the DecimationFactor
%   property set to D.
%
%   bpdecim = dsp.ComplexBandpassDecimator(D,Fc) returns a complex
%   bandpass decimator object, bpdecim, with the DecimationFactor
%   property set to D, and the CenterFrequency property set to Fc.
%
%   bpdecim = dsp.ComplexBandpassDecimator(D,Fc,Fs) returns a complex
%   bandpass decimator object, bpdecim, with the DecimationFactor
%   property set to D, the CenterFrequency property set to Fc, and the
%   SampleRate property set to Fs.
%
%   Step method syntax:
%
%   Y = step(bpdecim, X) filters the real or complex input signal X to
%   produce the output Y. The System object filters each channel of the
%   input signal independently over time. The frame size (first
%   dimension) of X must be a multiple of the decimation factor.
%
%   System objects may be called directly like a function instead of
%   using the step method. For example, y = step(obj, x) and y = obj(x)
%   are equivalent.
%
%   ComplexBandpassDecimator methods:
%
%   step                     - See above description for use of this 
%                              method
%   release                  - Allow property value and input
%                              characteristics changes, and release
%                              filter resources
%   clone                    - Create complex bandpass decimator with
%                              same property values
%   isLocked                 - Display locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>                    - Reset the states of the filter
%   cost                     - Compute implementation cost
%   freqz                    - Compute/plot frequency response
%   visualizeFilterStages    - Visualize filter stages
%
%   ComplexBandpassDecimator properties:
%
%   Specification               - Filter specification
%   DecimationFactor            - Decimation factor
%   CenterFrequency             - Center frequency (Hz)
%   MinimizeComplexCoefficients - Minimize complex coefficients
%   Bandwidth                   - Bandwidth (Hz)
%   StopbandAttenuation         - Stopband attenuation (dB)
%   PassbandRipple              - Passband ripple (dB)
%   TransitionWidth             - Transition width (Hz)
%   MixToBaseband               - Mix signal to baseband
%   SampleRate                  - Input sample rate (Hz)
%
% % Example: Filter input signal through a complex bandpass decimator.
% % Visualize filtered spectrum.
%   Fs = 48e3;        % Input sample rate
%   CF = 2000;        % Desired center frequency
%   BW = 1000;        % Bandwidth of interest (centered at CF)
%   D  =  Fs/BW;      % Decimation factor
%   FrameLength = 1200;
%
%   bpdecim = dsp.ComplexBandpassDecimator(D,CF,Fs);
%
% % Visualize the stages of the filter:
%   visualizeFilterStages(bpdecim)
%
% % Display filter info
%   fprintf('%s',info(bpdecim));
%
% % Spectrum visualization scope
%   sa = spectrumAnalyzer(SampleRate=Fs/D,...
%                         Method="welch", ...
%                         YLimits=[-120 40],...
%                         FrequencyOffset=CF);
%
% % Sine wave generator
%   tones = [1625 2000 2125];
%   sin = dsp.SineWave(SampleRate=Fs,Frequency=tones,...
%                      SamplesPerFrame=FrameLength);
%
%   for index = 1:1000
%       x = sum(sin(),2) +  1e-4 * randn(FrameLength,1);
%       z = bpdecim(x);
%       sa(z);
%   end
%
%   See also dsp.DigitalDownConverter,  dsp.DigitalUpConverter, 
%            dsp.ZoomFFT

     
    % Copyright 2016-2022 The MathWorks, Inc.

    methods
        function out=ComplexBandpassDecimator
        end

        function out=FsPerStage(~) %#ok<STOUT>
        end

        function out=cost(~) %#ok<STOUT>
            %C = cost(obj) Compute implementation cost
            %   C = cost(obj) returns a structure C whose fields contain
            %   information about the computation cost of implementing the
            %   complex bandpass decimator. The cost estimate contains the
            %   following fields:
            %   NumCoefficients                   : Number of filter 
            %                                       coefficients (excluding 
            %                                       coefficients with 
            %                                       values 0, 1 or -1)
            %   NumStates                         : Number of states
            %   RealMultiplicationsPerInputSample : Number of real 
            %                                       multiplications per 
            %                                       input sample
            %   RealAdditionsPerInputSample       : Number of real 
            %                                       additions per input 
            %                                       sample
            %
            %   A complex-by-complex multiplication is assumed to require 3
            %   real multiplications and 5 real additions.
            %
            %   % Example: Compute cost for a decimate-by-12
            %   % filter. 
            %   bp = dsp.ComplexBandpassDecimator(12,5000,44100);
            %   cost(bp)
        end

        function out=costAllComplex(~) %#ok<STOUT>
        end

        function out=costMinimizeComplex(~) %#ok<STOUT>
        end

        function out=crossValidateProperties(~) %#ok<STOUT>
        end

        function out=freqz(~) %#ok<STOUT>
            %[H,f] = freqz(obj,N,range) Frequency response
            %   [H,f] = freqz(obj,N,range) returns the complex frequency
            %   response H and the frequency vector f at which H is
            %   computed. N is the number of frequency points. If not
            %   specified, it defaults to 8192. range is the frequency
            %   range over which the response is computed; range can be
            %   either 'half' or 'whole'. If not specified, it defaults to
            %   'half'.
            %
            %   [H,f] = freqz(obj,f) returns the complex frequency response
            %   H computed at the frequency points specified by vector f.
            %   The vector f is assumed to be in Hz.
            %
            %   % Example: Compute the frequency response of a
            %   % decimate-by-12 filter:
            %   bp = dsp.ComplexBandpassDecimator(12,5000,44100); 
            %   [H,f] = freqz(bp); 
            %   plot(f,20*log10(abs(H))); grid on;
            %   xlabel('Frequency (Hz)'); ylabel('H (dB)');
        end

        function out=getFilters(~) %#ok<STOUT>
            %C = getFilters(obj) get filters
        end

        function out=getFrequencyOffset(~) %#ok<STOUT>
            %offset = getFrequencyOffset(obj) get frequency offset
            %   offset = getFrequencyOffset(obj) returns the frequency at
            %   which the decimated, filtered output is centered. If the
            %   MixToBaseband property is true, the filter heterodynes the
            %   output to DC.
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
        end

        function out=infoImpl(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=mix(~) %#ok<STOUT>
        end

        function out=needToDesignFilters(~) %#ok<STOUT>
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
            % Release the filters
        end

        function out=resetImpl(~) %#ok<STOUT>
            % Reset the filters
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setDecimationFactor(~) %#ok<STOUT>
        end

        function out=setfilters(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=tuneCoefficients(~) %#ok<STOUT>
            % Perform frequency shift on coefficients to get bandpass filter
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

        function out=visualizeFilterStages(~) %#ok<STOUT>
            %visualizeFilterStages(obj) Visualize filter stages
            %   visualizeFilterStages(obj) shows the response of each
            %   individual filter stage using FVTool.
            %   % Example: Visualize the stages for a decimate-by-12
            %   % filter:
            %   bp = dsp.ComplexBandpassDecimator(12,5000,44100);
            %   visualizeFilterStages(bp)
        end

    end
    properties
        % Bandwidth Frequency Bandwidth (Hz)
        %  Specify the width of the frequency band of interest as a
        %  positive scalar value, in Hertz. This property applies when
        %  Specification is either 'Bandwidth' or 'Decimation factor and
        %  bandwidth'. The default is 5000 Hz.
        Bandwidth;

        % CenterFrequency Center frequency (Hz)
        %  Specify the center frequency of the desired band in Hz as a
        %  real, finite numeric scalar in the range
        %  (-SampleRate/2,SampleRate/2). The default is 0 Hz. This property
        %  is tunable.
        CenterFrequency;

        % DecimationFactor Decimation factor
        %  Specify the factor by which to reduce the bandwidth of the input
        %  signal as a positive integer scalar value. The number of rows of
        %  the input must be a multiple of the decimation factor. This
        %  property applies when Specification is either 'Decimation
        %  factor' or 'Decimation factor and bandwidth'. The default is 2.
        DecimationFactor;

        % MinimizeComplexCoefficients Reduce number of complex coefficients
        % Set this property to true to minimize the number of complex
        % filter coefficients. When this property is set to true, the first
        % stage of the multistage filter is bandpass (complex
        % coefficients), centered at the specified center frequency. The
        % first stage is followed by a mixing stage that heterodynes the
        % signal to DC, and then by the remaining filter stages, all with
        % real coefficients. When this property is set to false, the input
        % signal is first passed through the different stages of the
        % multistage filter. All stages are bandpass (complex
        % coefficients). The signal is then heterodyned to DC if
        % MixToBaseband is true and the frequency offset resulting from the
        % decimation is non-zero. The default is true.
        MinimizeComplexCoefficients;

        % MixToBaseband Mix signal to baseband
        %  Set this property to true to heterodyne the filtered, decimated
        %  signal to DC. This mixing stage runs at the output sample rate
        %  of the filter. Set this property to false to skip this stage.
        %  This property applies when MinimizeComplexCoefficients is false.
        %  The default is true.
        MixToBaseband;

        % NumChannels Cached number of channels (used for error checking)
        NumChannels;

        % PassbandRipple Passband ripple (dB)
        %  Specify the passband ripple of the filter in dB, as a positive
        %  scalar. This property applies when Specification is either
        %  'Bandwidth' or 'Decimation factor and bandwidth'. The default is
        %  1 dB.
        PassbandRipple;

        % SampleRate Input sample rate (Hz)
        %  Specify the sampling rate of the input in Hz, as a real, numeric
        %  scalar. The default is 44100 Hz.
        SampleRate;

        % Specification Filter specification
        %   Set the specification as one of 'Decimation factor' |
        %   'Bandwidth' | 'Decimation factor and bandwidth'. The default of
        %   this property is 'Decimation factor'.
        Specification;

        %StopbandAttenuation Stopband attenuation (dB)
        %  Specify the stopband attenuation of the filter in dB, as a
        %  finite positive scalar. The default is 80 dB.
        StopbandAttenuation;

        % TransitionWidth Transition width (Hz)
        %  Specify the transition width of the filter in Hz, as a positive
        %  scalar. The default is 100 Hz.
        TransitionWidth;

        % Handle to freqz plot
        freqzHandle;

    end
end
