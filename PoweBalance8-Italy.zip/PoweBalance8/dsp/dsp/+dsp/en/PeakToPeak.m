classdef PeakToPeak
%PeakToPeak Compute peak-to-peak values in an input or sequence of inputs

 
%   Copyright 2008-2022 The MathWorks, Inc.

    methods
        function out=PeakToPeak
        end

    end
end
