classdef ZoomFFT< dsp.internal.SampleRateEngine
%   ZoomFFT Compute the FFT of a portion of the spectrum at high resolution
%   ZFFT = dsp.ZoomFFT returns a System object, ZFFT, that performs an FFT
%   on a portion of the input signal's frequency range. The object
%   determines the frequency range over which to perform the FFT using the
%   specified center frequency and decimation factor values. 
%
%   ZFFT = dsp.ZoomFFT('Name', Value, ...) returns a zoom FFT System
%   object, ZFFT, with each specified property name set to the specified
%   value. You can specify additional name-value pair arguments in any
%   order as (Name1,Value1,...,NameN, ValueN).
%
%   ZFFT = dsp.ZoomFFT(D) returns a zoom FFT object, ZFFT, with the
%   DecimationFactor property set to D.
%  
%   ZFFT = dsp.ZoomFFT(D,Fc) returns a zoom FFT object, ZFFT, with the
%   DecimationFactor property set to D, and the CenterFrequency property
%   set to Fc.
%
%   ZFFT = dsp.ZoomFFT(D,Fc,Fs) returns a zoom FFT object, ZFFT, with the
%   DecimationFactor property set to D, the CenterFrequency property
%   set to Fc, and the SampleRate property set to Fs.
%    
%   Step method syntax:
%
%   Y = step(ZFFT, X) computes the zoom FFT, Y, of the input X. Each
%   column of X is a channel. The System object computes the FFT of each
%   channel of the input signal independently over time. The frame size
%   (first dimension) of x must be a multiple of the decimation factor.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   ZoomFFT methods:
%
%   step                     - Compute zoom FFT of input
%   release                  - Allow property value and input 
%                              characteristics changes, and release zoom
%                              FFT resources
%   clone                    - Create zoom FFT object with same
%                              property values
%   isLocked                 - Display locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>                    - Reset the states of the zoom FFT
%
%   ZoomFFT properties:
%
%   DecimationFactor         - Decimation factor as an integer value
%   CenterFrequency          - Center frequency (Hz) 
%   FFTLength                - FFT length
%   SampleRate               - Input sample rate (Hz)
%
% % Example: Compute FFT of the [1500 Hz, 2500 Hz] band using zoom FFT.
%   Fs = 48e3;        % Input sample rate
%   CF = 2000;        % Desired center frequency
%   BW = 1000;        % Bandwidth of interest (centered at CF)
%   D  =  Fs/BW;      % Decimation factor
%   fftlen = 64;      % FFT length
%   L  = D * fftlen;  % Frame size
%  
%   zfft = dsp.ZoomFFT(D,CF,Fs,...
%                     'FFTLength',fftlen);
%    
% % Specify frequency points at which FFT is computed
%   Fsd = Fs / D;
%   F   = CF + Fsd/fftlen*(0:fftlen-1)-Fsd/2;
%  
% % Spectrum visualization scope
%   ap = dsp.ArrayPlot(...
%                     'XDataMode','Custom',...
%                     'CustomXData',F,...
%                     'YLabel','z .* conj(z)',...
%                     'XLabel','Frequency (Hz)',...
%                     'YLimits',[0 1.1e3],...
%                     'Title',sprintf('Resolution = %f Hz',(Fs/D)/fftlen));
%  
% % Sine wave generator
%   tones = [1625 2000 2125];
%   sin = dsp.SineWave('SampleRate',Fs,'Frequency',tones,...
%                      'SamplesPerFrame',L);
%  
%   for index = 1:100
%       x = sum(sin(),2) +  1e-1 * randn(L,1);
%       z = zfft(x);
%       z = fftshift(z);
%       ap( z .* conj(z) );
%   end
%
%   See also dsp.FFT, dsp.IFFT

 
% Copyright 2016-2022 The MathWorks, Inc.

    methods
        function out=ZoomFFT
        end

        function out=cacheFFTLength(~) %#ok<STOUT>
        end

        function out=crossValidateProperties(~) %#ok<STOUT>
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
            % Modify order of display
        end

        function out=isFFTAutoMode(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

    end
    properties
        % CenterFrequency Center frequency (Hz)
        %  Specify the center frequency of the desired band in Hz as a real,
        %  finite numeric scalar in the range (-SampleRate/2,SampleRate/2). The
        %  default is 0 Hz. This property is tunable.
        CenterFrequency;

        % DecimationFactor Decimation factor
        %  Specify the factor by which to reduce the bandwidth of the input
        %  signal as a positive integer scalar value. The number of rows of the
        %  input must be a multiple of the decimation factor. The default is 2.
        DecimationFactor;

        % FFTLength FFT length
        %  Specify the FFT length as a positive scalar integer. The default
        %  value of this property is [], which means that the FFT length is
        %  equal to the frame size (number of input rows) divided by the
        %  decimation factor.
        FFTLength;

        % NumChannels Cached number of channels (used for error checking)
        NumChannels;

        % SampleRate Input sample rate (Hz)
        %  Specify the sampling rate of the input in Hertz as a real, finite
        %  numeric scalar. The default is 44100 Hz.
        SampleRate;

        % pNFFT Cached FFT length
        pNFFT;

    end
end
