classdef VariableBandwidthFIRFilter< dsp.internal.VariableBandwidthFilterBase
%VariableBandwidthFIRFilter Variable bandwidth FIR filter
%   VBFIR = dsp.VariableBandwidthFIRFilter returns a System object, VBFIR, 
%   which independently filters each channel of the input over time using
%   specified FIR filter specifications. The FIR filter's cutoff frequency
%   may be tuned during the filtering operation. The FIR filter is designed
%   using the window method. 
%
%   VBFIR = dsp.VariableBandwidthFIRFilter('Name', Value, ...) returns a 
%   Variable Bandwidth FIR Filter System object, VBFIR, with each specified 
%   property name set to the specified value. You can specify additional 
%   name-value pair arguments in any order as (Name1,Value1,...,NameN,
%   ValueN).
%
%   Step method syntax:
%
%   Y = step(VBFIR, X) filters the real or complex input signal X using the
%   specified filter to produce the output Y. The System object filters
%   each channel of the input signal independently over time.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   VariableBandwidthFIRFilter methods:
%
%   step          - See above description for use of this method
%   release       - Allow property value and input characteristics changes                      
%   clone         - Create Variable Bandwidth FIR Filter object with 
%                   same property values                      
%   isLocked      - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>         - Reset the internal states to initial conditions
%
%   VariableBandwidthFIRFilter properties:
%
%   SampleRate                   - Input sample rate
%   FilterType                   - FIR filter type
%   FilterOrder                  - FIR filter order
%   NormalizedFrequency          - Provide normalized frequencies for filter specifications
%   Window                       - Window function
%   KaiserWindowParameter        - Kaiser window parameter
%   SidelobeAttenuation          - Chebyshev window sidelobe attenuation
%   CutoffFrequency              - Filter cutoff frequency
%   CenterFrequency              - Filter center frequency
%   Bandwidth                    - Filter bandwidth            
%
%   This System object supports several filter analysis methods. For more
%   information, type dsp.VariableBandwidthFIRFilter.helpFilterAnalysis
%
%   % Example: Filter a signal through a variable bandwidth bandpass FIR
%   % filter. Tune the center frequency and the bandwidth of the FIR 
%   % filter. 
%   Fs = 44100; % Input sample rate
%   FrameLength = 1024;
%   % Define a bandpass variable bandwidth FIR filter:
%   VBFIR = dsp.VariableBandwidthFIRFilter(FilterType='Bandpass',...
%                                          FilterOrder=100,...
%                                          NormalizedFrequency=false,...
%                                          SampleRate=Fs,...
%                                          CenterFrequency=1e4,...
%                                          Bandwidth=4e3);
%   TFE     = dsp.TransferFunctionEstimator('FrequencyRange','onesided');
%   PLOTTER = dsp.ArrayPlot(PlotType='Line',...
%                           XOffset=0,...
%                           YLimits=[-120 5], ...
%                           SampleIncrement=Fs/FrameLength,...
%                           YLabel='Frequency Response (dB)',...
%                           XLabel='Frequency (Hz)',...
%                           Title='System Transfer Function');
%   SINE = dsp.SineWave(SamplesPerFrame=FrameLength);
%   for index=1:500
%      % Generate input
%      x = SINE() + randn(FrameLength,1);
%      % Pass input through the filter
%      y = VBFIR(x);
%      % Transfer function estimation
%      H = TFE(x,y);
%      % Plot transfer function
%      PLOTTER(20*log10(abs(H)))   
%      % Tune bandwidth and center frequency of the FIR filter
%      if (index==250)
%         VBFIR.CenterFrequency = 5000;
%         VBFIR.Bandwidth = 2000;
%      end
%   end
%
%   See also dsp.VariableBandwidthIIRFilter, dsp.FIRFilter, dsp.IIRFilter, 
%            dsp.BiquadFilter, dsp.AllpoleFilter

 
%   Copyright 2013-2020 The MathWorks, Inc.

    methods
        function out=VariableBandwidthFIRFilter
            % Constructor
        end

        function out=coeffs(~) %#ok<STOUT>
        end

        function out=crossValidateProperties(~) %#ok<STOUT>
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
            % Modify order of display
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
            % Tune the filter coefficients
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Invoke setupImpl method of base class
        end

        function out=stepImpl(~) %#ok<STOUT>
            % step the FIR filter
        end

        function out=tuneCoefficients(~) %#ok<STOUT>
        end

        function out=updateBandpassCoefficients(~) %#ok<STOUT>
            % Modulate the lowpass coefficients by 2 * cos(wc.n)
        end

        function out=updateBandstopCoefficients(~) %#ok<STOUT>
            % Modulate the lowpass coefficients by 2 * cos(wc.n) and then flip
            % the frequency response
        end

        function out=updateHighpassCoefficients(~) %#ok<STOUT>
            % Get highpass coefficients from lowpass coefficients (Hhp(w) = 1 -
            % Hlp(w))
        end

        function out=updateLowpassCoefficients(~) %#ok<STOUT>
            % Tune filter coefficients to new cutoff frequency
            % Compute coefficients of truncated ideal lowpass impulse response
        end

        function out=validateFrequencyRange(~) %#ok<STOUT>
            % CutoffFrequency must be less than SampleRate/2
            % This method is invoked in validatePropertiesImpl of the base class
        end

    end
    properties
        % CutoffFrequency Filter Cutoff frequency 
        %   Specify the filter cutoff frequency as a real, positive scalar
        %   less than SampleRate/2. This property applies when you set the
        %   FilterType property to 'Lowpass' or 'Highpass'. Specify the value of
        %   filter cutoff frequency in Hertz when NormalizedFrequency is set to
        %   false and in normalized units when NormalizedFrequency is set to
        %   true. The default is 512 Hz. This property is tunable.
        CutoffFrequency;

        % FilterOrder FIR filter order
        %   Specify the order of the FIR filter as a positive integer scalar. The 
        %   default is 30.
        FilterOrder;

        % KaiserWindowParameter Kaiser window parameter
        %   Specify the Kaiser window parameter as a real scalar. This property 
        %   applies when you set the  Window property to 'Kaiser'. The default is 
        %   0.5;
        KaiserWindowParameter;

        % SidelobeAttenuation  Chebyshev window sidelobe attenuation (dB)
        %   Specify the Chebyshev window sidelobe attenuation as a real, positive 
        %   scalar in decibels (dB). This property applies when you set the 
        %   Window property to 'Chebyshev'. The default is 60 dB.
        SidelobeAttenuation;

        % Window Window function
        %   Specify the window function used to design the FIR filter as one of 
        %   'Hann' | 'Hamming' | 'Chebyshev' | 'Kaiser'. The default is 'Hann'.
        Window;

    end
end
