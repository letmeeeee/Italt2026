classdef FrequencyDomainAdaptiveFilter< matlab.System
%FrequencyDomainAdaptiveFilter Computes output, error and coefficients using
%                              frequency domain FIR adaptive filter.
%
%   FDAFILT = dsp.FrequencyDomainAdaptiveFilter returns a frequency domain
%   FIR adaptive filter System object(TM), FDAFILT. This System object is
%   used to compute the filtered output and the filter error for a given
%   input and desired signal.
%
%   FDAFILT = dsp.FrequencyDomainAdaptiveFilter('PropertyName',PropertyValue,...)
%   returns a FrequencyDomainAdaptiveFilter System object, FDAFILT, with
%   each specified property set to the specified value.
%
%   FDAFILT = dsp.FrequencyDomainAdaptiveFilter(LEN, 'PropertyName', ...
%       PropertyValue, ...)
%   returns a FrequencyDomainAdaptiveFilter System object, FDAFILT, with
%   the Length property set to LEN, and other specified properties set to
%   the specified values.
%
%   Step method syntax:
%
%   [Y, ERR] = step(FDAFILT, X, D) filters the input X, using D as the
%   desired signal, and returns the filtered output in Y and the filter
%   error in ERR. The System object estimates the filter weights needed to
%   minimize the error between the output signal and the desired signal.
%   The FFT of these filter weights can be obtained by accessing the
%   FFTCoefficients property after calling the step method by
%   FDAFILT.FFTCoefficients.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   FrequencyDomainAdaptiveFilter methods:
%
%   step                - See above description for use of this method.
%   release             - Allow changes in non-tunable property values and
%                         input characteristics.
%   clone               - Create a FrequencyDomainAdaptiveFilter object
%                         with the same property values and internal
%                         states.
%   isLocked            - Locked status of the filter object (logical).
%   <a href="matlab:help matlab.System/reset   ">reset</a>               - Reset the internal states to their initial
%                         conditions.
%
%   FrequencyDomainAdaptiveFilter properties:
%
%   Method              - Method to calculate the filter
%                         coefficients
%   Length              - Length of filter coefficients vector
%   BlockLength         - Block length for the coefficient updates
%   StepSize            - Adaptation step size
%   LeakageFactor       - Adaptation leakage factor
%   AveragingFactor     - Averaging factor for the signal power
%   Offset              - Offset for the normalization terms
%   InitialPower        - Initial FFT input signal power
%   InitialCoefficients - Initial time-domain coefficients of the filter
%   LockCoefficients    - Locked status of the coefficient updates
%
%
%   % EXAMPLE #1: QPSK adaptive equalization using a 32-coefficient FIR
%   %   filter (1024 iterations).
%
%     D = 16;                       % Number of samples of delay
%     b  = exp(1i*pi/4)*[-0.7 1];   % Numerator coefficients of channel
%     a  = [1 -0.7];                % Denominator coefficients of channel
%     ntr= 1024;                    % Number of iterations
%     s  = sign(randn(1,ntr+D))+1i*sign(randn(1,ntr+D));    % QPSK signal
%     n  = 0.1*(randn(1,ntr+D) + 1i*randn(1,ntr+D));        % Noise signal
%     r  = filter(b,a,s) + n;       % Received signal
%     x  = r(1+D:ntr+D);            % Input signal (received signal)
%     d  = s(1:ntr);                % Desired signal (delayed QPSK signal)
%     mu  = 0.1;                    % Step size
%     fdafilt = dsp.FrequencyDomainAdaptiveFilter('Length',32,'StepSize',mu);
%     [y,e] = fdafilt(x,d);
%     subplot(2,2,1); plot(1:ntr,real([d;y;e]));
%     legend('Desired','Output','Error'); title('In-Phase Components');
%     xlabel('Time Index'); ylabel('signal value');
%     subplot(2,2,2); plot(1:ntr,imag([d;y;e]));
%     legend('Desired','Output','Error'); title('Quadrature Components');
%     xlabel('Time Index'); ylabel('signal value');
%     subplot(2,2,3); plot(x(ntr-100:ntr),'.'); axis([-3 3 -3 3]);
%     title('Received Signal Scatter Plot'); axis('square');
%     xlabel('Real[x]'); ylabel('Imag[x]'); grid on;
%     subplot(2,2,4); plot(y(ntr-100:ntr),'.'); axis([-3 3 -3 3]);
%     title('Equalized Signal Scatter Plot'); axis('square');
%     xlabel('Real[y]'); ylabel('Imag[y]'); grid on;
%
%   % EXAMPLE #2: Use a frequency-domain adaptive filter to estimate the
%   % coefficients of a long FIR filter. The FIR filter models a room 
%   % impulse response. Use partitioned FDAF to reduce filter latency.
%
%     fs = 16e3;
%     M  = 8192; % Impulse response length
% 
%     [B,A] = cheby2(4,20,[0.1 0.7]);
%     impulseResponseGenerator = dsp.IIRFilter(...
%                                 'Numerator', [zeros(1,6) B], ...
%                                 'Denominator', A);
%     roomImpulseResponse = impulseResponseGenerator( ...
%     (log(0.99*rand(1,M)+0.01).*sign(randn(1,M)).*exp(-0.002*(1:M)))');
%     roomImpulseResponse = roomImpulseResponse/norm(roomImpulseResponse);
%     room = dsp.FIRFilter('Numerator', roomImpulseResponse');
% 
%     lmsfilt = dsp.FrequencyDomainAdaptiveFilter(...
%                          'Method','Partitioned constrained FDAF',...
%                          'Length', M/4, ...
%                          'BlockLength', 128,...
%                          'StepSize', 0.025, ...
%                          'InitialPower', 0.01, ...
%                          'AveragingFactor', 0.98,...
%                          'Offset',1,...
%                          'LeakageFactor',1);
% 
%     FrameSize = lmsfilt.BlockLength; NIter = 2000;
%  
%     AP = dsp.ArrayPlot('YLimits',[-0.1 .3],'ShowLegend',true, ...
%                      'Position',[0 0 560 420],'ChannelNames', ...
%                      {'Actual Coefficients', 'Estimated Coefficients'});
% 
%     TS = timescope('SampleRate',fs,...
%                    'TimeSpanSource','property',...
%                    'TimeSpan',FrameSize*NIter/fs,...
%                    'YLimits',[-50 0],'Title','Learning curve',...
%                    'YLabel','dB');
% 
%     signalmean = dsp.MovingAverage('SpecifyWindowLength',false);
% 
%     % Stream
%     for k = 1:NIter
%       x = randn(FrameSize,1);                 % input signal
%       d = room(x) + 0.01*randn(FrameSize,1);  % desired signal
%       [y,e] = lmsfilt(x,d);
%       % Transform the adapting FFT coefficients to the time-domain:
%       FFTCoeffs = lmsfilt.FFTCoefficients;
%       w    = ifft(FFTCoeffs, [] , 2, 'symmetric');
%       w    = w(:,1:FrameSize) + w(:,FrameSize+1:end);
%       w = reshape(w.',1, M/4);
%       AP([roomImpulseResponse(1:M/4),w.']); 
%       TS(10*log10(signalmean(abs(e).^2)));
%     end

 
%   Copyright 1995-2023 The MathWorks, Inc.

    methods
        function out=FrequencyDomainAdaptiveFilter
            % Support name-value pair arguments as well as alternatively
            % allow the Length property to be a value-only argument.
        end

        function out=coefficientsLocked(~) %#ok<STOUT>
        end

        function out=getFilterParameterStruct(~) %#ok<STOUT>
        end

        function out=getNumInputsImpl(~) %#ok<STOUT>
            % Specify number of System inputs
        end

        function out=getNumOutputsImpl(~) %#ok<STOUT>
            % Specify number of System outputs
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
            % Get default parameters group for this System object
        end

        function out=initializePartitionVariables(~) %#ok<STOUT>
            % Load the required constant properties
        end

        function out=initializeVariables(~) %#ok<STOUT>
            % Load the required constant properties
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=isPartitioned(~) %#ok<STOUT>
        end

        function out=loadFDAFProperties(~) %#ok<STOUT>
            % Load the required constant properties
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=loadPBFDAFProperties(~) %#ok<STOUT>
            % Load the required constant properties
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
            % Local copy of the required properties
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Set InputDataType to be the data type of x and initialize the
            % FilterParameters property based on that. The FilterParameters
            % property is a structure with all the filter parameters casted
            % to the data type of the inputs.
        end

        function out=stepCFDAF(~) %#ok<STOUT>
            % Load the required properties
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=stepPBCFDAF(~) %#ok<STOUT>
            % Load the required properties
        end

        function out=stepPBUCFDAF(~) %#ok<STOUT>
            % Load the required properties
        end

        function out=stepUFDAF(~) %#ok<STOUT>
            % Load the required properties
        end

        function out=updateFilterParameters(~) %#ok<STOUT>
            % If the tunable properties are changed, update the
            % FilterParameters private property that stores their
            % type-casted version in a structure.
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            % Validating the size of the inputs x and d. Inputs must be
            % vectors.
        end

        function out=validatePropertiesImpl(~) %#ok<STOUT>
            % Validating the dimensions of the InitialCoefficients property
        end

    end
    properties
        %AveragingFactor Averaging factor
        %   Specify the averaging factor used to compute the exponentially
        %   windowed FFT input signal powers for the coefficient updates as
        %   a scalar positive numeric value less than or equal to 1. The
        %   default value of this property is 0.9. This property is
        %   tunable.
        AveragingFactor;

        %BlockLength Block length
        %   Specify the block length of the coefficients updates as a
        %   positive integer value. The length of the input vectors must be
        %   divisible by the BlockLength property value. The default value
        %   of the BlockLength property is set to the Length property
        %   value.
        BlockLength;

        %Coefficients Current FFT coefficients of the filter
        %   This property stores the current discrete Fourier transform of
        %   the filter coefficients as a row vector. The length of this
        %   vector is equal to the sum of the Length property value and the
        %   BlockLength property value. This property is initialized to the
        %   FFT values of the InitialCoefficients property.
        FFTCoefficients;

        %FilterParameters Private structure to store the filter parameters
        %   This is a private MATLAB structure that stores all the filter
        %   parameters casted to the data type of the inputs. For
        %   FrequencyDomainAdaptiveFilter System object, StepSize,
        %   LeakageFactor, AveragingFactor, Offset and InitialPower are the
        %   filter parameters. The FilterParameters property is initialized
        %   in setup method.
        FilterParameters;

        %InitialCoefficients Initial time-domain coefficients
        %   Specify the initial time-domain coefficients of the adaptive
        %   filter as a scalar or a vector of length equal to the Length
        %   property value. The adaptive filter object uses these
        %   coefficients to compute the initial frequency-domain filter
        %   coefficients. The default value of this property is 0. This
        %   property is tunable.
        InitialCoefficients;

        %InitialPower Initial FFT input signal power
        %   Specify the initial common value of all of the FFT input signal
        %   powers as a scalar positive numeric value. The default value of
        %   this property is 1. This property is tunable.
        InitialPower;

        %InputDataType Data type of the inputs
        %   This is a private property that stores the data type of the
        %   inputs and it is used to set the data type of all the
        %   DiscreteState properties and the outputs.
        InputDataType;

        %LeakageFactor Leakage factor
        %   Specify the leakage factor used in leaky adaptive filter as a
        %   scalar numeric value between 0 and 1, both inclusive. When the
        %   value is less than 1, the System object implements a leaky
        %   adaptive algorithm. The default value of this property is 1,
        %   providing no leakage in the adapting method. This property is
        %   tunable.
        LeakageFactor;

        %Length Filter length
        %   Specify the length of the FIR filter coefficients vector as a
        %   positive integer value. The default value of this property is
        %   32.
        Length;

        %LockCoefficients Locked status of the coefficient updates
        %   Specify whether the filter coefficient values should be locked.
        %   By default, the value of this property is false, and the object
        %   continuously updates the filter coefficients. If this property
        %   is set to true, the filter coefficients do not get updated and
        %   their values remain at the current value. This property is
        %   tunable.
        LockCoefficients;

        %Method Method
        %   Specify the method used to calculate filter coefficients as one
        %   of ['Constrained FDAF' | 'Unconstrained FDAF' | 'Partitioned
        %   constrained FDAF' | 'Partitioned unconstrained FDAF']. The
        %   default is 'Constrained FDAF'.
        Method;

        %Offset Offset
        %   Specify the offset for the normalization terms in the
        %   coefficient updates as a scalar non-negative numeric value.
        %   This property value is used to avoid divide by zeros or divide
        %   by very small numbers if any of the FFT input signal powers
        %   become very small. The default value of this property is 0.
        %   This property is tunable.
        Offset;

        %Power Current FFT input signal power
        %   This property stores the current values of FFT input signal
        %   powers as a column vector. The length of this vector is equal
        %   to the sum of the Length property value and the BlockLength
        %   property value. This property is initialized to a vector of
        %   appropriate length and data type with each of the elements
        %   equal to the InitialPower property value.
        Power;

        %States Current internal states of the filter
        %   This property stores the current internal states of the filter
        %   as a column vector. The length of this vector is equal to the
        %   Length property value. This property is initialized to a vector
        %   of zeros of appropriate length and data type.
        States;

        %StepSize Step size
        %   Specify the adaptation step size factor as a positive numeric
        %   scalar less than or equal to 1. Setting the StepSize property
        %   equal to one provides the fastest convergence during
        %   adaptation. The default value of this property is 1. This
        %   property is tunable.
        StepSize;

        % pLastChunk Used in partitioned modes
        pLastChunk;

        % pMethod Cache method as an integer
        pMethod;

        %privBlockLength A private property to store the value explicitly
        %   set to the BlockLength property.
        privBlockLength;

        %privBlockLengthDefined A Private logical property to denote
        %   whether the BlockLength property has been explicitly set.
        privBlockLengthDefined;

    end
end
