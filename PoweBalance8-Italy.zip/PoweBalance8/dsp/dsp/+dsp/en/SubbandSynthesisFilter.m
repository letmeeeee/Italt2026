classdef SubbandSynthesisFilter< matlab.System
%SubbandSynthesisFilter Reconstruct signal from high-frequency and low-
%                       frequency subbands
%   SSF = dsp.SubbandSynthesisFilter returns a two-channel subband
%   synthesis filter System object, SSF, that reconstructs a signal from
%   its high-frequency subband and low-frequency subband, each with half
%   the bandwidth of the original signal.
%
%   SSF = dsp.SubbandSynthesisFilter('PropertyName', PropertyValue, ...)
%   returns a two-channel subband synthesis filter System object, SSF,
%   with each specified property set to the specified value.
%
%   SSF = dsp.SubbandSynthesisFilter(LPCOEFFS, HPCOEFFS, 'PropertyName',
%   PropertyValue, ...) returns a two-channel subband synthesis filter
%   System object, SSF, with the LowpassCoefficients property set to
%   LPCOEFFS, the HighpassCoefficients property set to HPCOEFFS, and other
%   specified properties set to the specified values.
%
%   Step method syntax:
%
%   Y = step(SSF, IN1, IN2) reconstructs a signal from the subband signals
%   IN1 and IN2.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   SubbandSynthesisFilter methods:
%
%   step     - See above description for use of this method
%   release  - Allow property value and input characteristics changes
%   clone    - Create two-channel subband synthesis filter object with same
%              property values
%   isLocked - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>    - Reset states of filter
%
%   SubbandSynthesisFilter properties:
%
%   LowpassCoefficients  - Lowpass FIR filter coefficients
%   HighpassCoefficients - Highpass FIR filter coefficients
%
%   This System object supports fixed-point operations. For more
%   information, type dsp.SubbandSynthesisFilter.helpFixedPoint.
%
%   % EXAMPLE: Use SubbandAnalysisFilter and SubbandSynthesisFilter System
%   %          objects to show perfect reconstruction.
%      load dspwlets; % load the filter coefficients lod, hid, lor and hir
%      SAF = dsp.SubbandAnalysisFilter(lod, hid);
%      SSF = dsp.SubbandSynthesisFilter(lor, hir);
%      u = randn(128,1);
%      [hi, lo] = SAF(u); % Two channel analysis
%      y = SSF(hi, lo);   % Two channel synthesis
%      % Plot difference between original and reconstructed signals with
%      % filter latency compensated
%      plot(u(1:end-7)-y(8:end));
%
%   See also dsp.SubbandAnalysisFilter,
%            dsp.DyadicSynthesisFilterBank,
%            dsp.SubbandSynthesisFilter.helpFixedPoint.

 
%   Copyright 1995-2023 The MathWorks, Inc.

    methods
        function out=SubbandSynthesisFilter
        end

        function out=getNumInputsImpl(~) %#ok<STOUT>
        end

        function out=helpFixedPoint(~) %#ok<STOUT>
            %helpFixedPoint Display dsp.SubbandSynthesisFilter System
            %               object fixed-point information
            %   dsp.SubbandSynthesisFilter.helpFixedPoint displays information
            %   about fixed-point properties and operations of the
            %   dsp.SubbandSynthesisFilter System object.
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            %check input dimensions
        end

    end
    properties
        %AccumulatorDataType Accumulator word- and fraction-length designations
        %   Specify the accumulator fixed-point data type as one of ['Full precision' |
        %   'Same as product' | 'Same as input' | 'Custom']. This property is
        %   applicable when the  FullPrecisionOverride property is false. The
        %   default is 'Full precision'.
        AccumulatorDataType;

        %CoefficientsDataType Coefficient word- and fraction-length designations
        %   Specify the FIR filter coefficients fixed-point data type as one of
        %   ['Same word length as input' | 'Custom']. The default is 'Same
        %   word length as input'.
        CoefficientsDataType;

        %CustomAccumulatorDataType Accumulator word and fraction lengths
        %   Specify the accumulator fixed-point type as an auto-signed, scaled
        %   numerictype object. This property is applicable when the
        %   FullPrecisionOverride property is false and when the
        %   AccumulatorDataType property is 'Custom'. The default value of this
        %   property is numerictype([],32,30).
        %
        %   See also numerictype.
        CustomAccumulatorDataType;

        %CustomCoefficientsDataType Coefficient word and fraction lengths
        %   Specify the FIR filter coefficients fixed-point type as an
        %   auto-signed numerictype object. This property is applicable when
        %   the CoefficientsDataType property is 'Custom'. The default value of
        %   this property is numerictype([],16,15).
        %
        %   See also numerictype.
        CustomCoefficientsDataType;

        %CustomOutputDataType Output word and fraction lengths
        %   Specify the output fixed-point type as an auto-signed, scaled
        %   numerictype object. This property is applicable when the
        %   FullPrecisionOverride property is false and when the
        %   OutputDataType property is 'Custom'. The default value of this
        %   property is numerictype([],16,14).
        %
        %   See also numerictype.
        CustomOutputDataType;

        %CustomProductDataType Product word and fraction lengths
        %   Specify the product fixed-point type as an auto-signed, scaled
        %   numerictype object. This property is applicable when the
        %   FullPrecisionOverride property is false and when the
        %   ProductDataType property is 'Custom'. The default value of this
        %   property is numerictype([],32,30).
        %
        %   See also numerictype.
        CustomProductDataType;

        %FullPrecisionOverride Full precision override for fixed-point arithmetic
        %   Specify whether to use full precision rules. If you set
        %   FullPrecisionOverride to true the object computes all
        %   internal arithmetic and output data types using full
        %   precision rules. These rules guarantee that no quantization
        %   occurs within the object. Bits are added as needed to ensure
        %   that no round-off or overflow occurs. If you set
        %   FullPrecisionOverride to false, fixed-point data types
        %   are controlled through individual property settings.
        FullPrecisionOverride;

        %HighpassCoefficients Highpass FIR filter coefficients
        %   Specify a vector of highpass FIR filter coefficients, in descending
        %   powers of z. The highpass filter should be a halfband filter that
        %   passes the frequency band stopped by the filter specified in the
        %   LowpassCoefficients property. The default values of this property
        %   specify a filter based on a 3rd-order Daubechies wavelet.
        HighpassCoefficients;

        %LowpassCoefficients Lowpass FIR filter coefficients
        %   Specify a vector of lowpass FIR filter coefficients, in descending
        %   powers of z. The lowpass filter should be a halfband filter that
        %   passes the frequency band stopped by the filter specified in the
        %   HighpassCoefficients property. The default values of this property
        %   specify a filter based on a 3rd-order Daubechies wavelet.
        LowpassCoefficients;

        %OutputDataType Output word- and fraction-length designations
        %   Specify the output fixed-point data type as one of ['Same as
        %   accumulator' | 'Same as product' | 'Same as input' | 'Custom'].
        %   This property is applicable when the FullPrecisionOverride
        %   property is false. The default is 'Same as accumulator'.
        OutputDataType;

        %OverflowAction Overflow action for fixed-point operations
        %   Specify the overflow action as one of ['Wrap' | 'Saturate']. This
        %   property is applicable when the object is not in a full precision
        %   configuration. The default is 'Wrap'.
        OverflowAction;

        %ProductDataType Product word- and fraction-length designations
        %   Specify the product fixed-point data type as one of ['Full
        %   precision' | 'Same as input' | 'Custom']. This property is
        %   applicable when the FullPrecisionOverride property is false. The
        %   default is 'Full precision'.
        ProductDataType;

        %RoundingMethod Rounding method for fixed-point operations
        %   Specify the rounding method as one of ['Ceiling' | 'Convergent' |
        %   'Floor' | 'Nearest' | 'Round' | 'Zero']. This property is
        %   applicable when the object is not in a full precision
        %   configuration. The default is 'Floor'.
        RoundingMethod;

    end
end
