classdef ParallelFilter< dsp.internal.FilterStructure
%ParallelFilter A parallel sum filter structure.
%   This System object filters its input through several filter branches, 
%   and sum the resulting branch outputs. The parallel filter object can
%   be used for simulation and analysis.
%
%   PF = dsp.ParallelFilter returns a System object, PF, that has a single
%   branch of dsp.FIRFilter.
%
%   PF = dsp.ParallelFilter(FILTER1, FILTER2, ...) returns a parallel stack 
%   System object, PF, with first branch set to FILTER1, second branch set 
%   to FILTER2, and so on.
%
%   PF = dsp.ParallelFilter(..., CloneBranches=val) sets the CloneBranches
%   property to val, which can be true or false.
%
%   Step method syntax:
%
%   Y = PF(X) runs the input X through the parallel filter PF, and
%   returns the filtered output Y.
%
%   ParallelFilter methods:
%
%   step                  - See above description for use of this method
%   release               - Allow property value and input characteristics
%                           to change
%   clone                 - Create dsp.ParallelFilter object with same
%                           property values
%   isLocked              - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>                 - Reset the internal states of all branches to
%                           initial conditions
%   addBranch             - Add a new filter branch to the parallel filter
%   removeBranch          - Remove a branch from the parallel filter
%   releaseBranches       - Release the locked state of all branches in the
%                           parallel filter
%   getNumBranches        - Get the number of branches in the parallel 
%                           filter object
%   generateFilteringCode - Generate equivalent MATLAB code that performs 
%                           the filtering operation of the parallel filter
%
%   ParallelFilter properties:
%
%   CloneBranches - Control branch cloning
%   Branch1      - First branch of the parallel filter
%
%   You can grow the number of branches by using the addBranch method of
%   dsp.ParallelFilter. For a list of System objects that can be used as
%   branches of the parallel filter, type
%   dsp.ParallelFilter.helpSupportedSystemObjects
%
%   This System object supports several filter analysis methods. For more
%   information, type dsp.ParallelFilter.helpFilterAnalysis.
%
%   % EXAMPLE 1: Construct a parallel filter in three ways
%   % First, create the branches
%   B1 = dsp.FIRFilter;
%   B2 = dsp.Delay(3);
%
%   % Option 1: Specify branches while constructing the dsp.ParallelFilter 
%   % object
%   pf1 = dsp.ParallelFilter(B1, B2);
%
%   % Option 2: Use the parallel filter function
%   pf2 = parallel(B1, B2);
%
%   % Option 3: Use the addBranch function to add the branches.
%   pf3 = dsp.ParallelFilter(B1);
%   addBranch(pf3, B2);
%
%   % EXAMPLE 2: Construct a polyphase FIR decimator using the parallel() 
%   % function. Visualize its frequency response using fvtool. Pass a
%   % random input through the decimator.
%
%   % Construction
%   M = 3;
%   coeffs = designMultirateFIR(1, M);
%   
%   branches = cell(1,M);
%   for phase=1:M
%       downsample = dsp.FIRDecimator(M,1); % Trivial downsample
%       phaseDelay = dsp.Delay(phase-1);
%       phaseFIR = dsp.FIRFilter(coeffs(phase:3:end));
%       branches{phase} = cascade(phaseDelay, downsample, phaseFIR);
%   end
%   
%   PFdecim = parallel(branches{:});
%   fvtool(PFdecim)
%   
%   % Simulation with random input
%   x = randn(1200,2);
%   for idx = 1:100
%       y = PFdecim(x);
%   end
%
%   % EXAMPLE 3: Branch cloning v.s. branch referencing
%   B1 = dsp.FIRInterpolator(13);
%   B2 = dsp.FIRDecimator(17);
%   pf_clone = dsp.ParallelFilter(B1, B2)
%   pf_ref = dsp.ParallelFilter(B1, B2, CloneBranches = false)
%
%   % Change a property in the user-provided branch
%   B1.InterpolationFactor = 19
%
%   % Check if the change in the interpolation factor of B1 has affected
%   % the interpolation factor of Branch1 stored in the parallel filter
%   pf_clone.Branch1.InterpolationFactor   % no sync (clone)
%   pf_ref.Branch1.InterpolationFactor     % sync (reference)
%
%   See also parallel, dsp.FilterCascade

 
%   Copyright 2022-2023 The MathWorks, Inc.

    methods
        function out=ParallelFilter
            % Constructor
        end

        function out=addBranch(~) %#ok<STOUT>
            %ADDBRANCH Add a branch to parallel filter
            %
            %   addBranch(PF, FILTER) adds FILTER as a branch at the end of the 
            %   parallel stack PF.
            %
            %   addBranch(PF, FILTER, IDX) adds the filter defined in FILTER at 
            %   branch position IDX of the parallel filter in PF. All existing 
            %   branches from IDX to end of the parallel filter are shifted down 
            %   further down the stack.
            %
            %   % Example 1: Add a branch at the end of the parallel filter
            %   pf = dsp.ParallelFilter;
            %   addBranch(pf, dsp.IIRFilter);
            %
            %   % Example 2: Add a filter at the second branch of the filter
            %   % parallel filter consisting of three filters
            %   pf = parallel(dsp.CICDecimator, dsp.FIRDecimator);
            %   addBranch(pf, dsp.FarrowRateConverter(48,24), 2);
        end

        function out=branchRateConversionFactors(~) %#ok<STOUT>
        end

        function out=convertToDFILT(~) %#ok<STOUT>
            % Convert the System object to a dfilt object for analysis
        end

        function out=generateFilteringCode(~) %#ok<STOUT>
            %GENERATEFILTERINGCODE Generate MATLAB code to filter using a parallel
            %   structure
            %
            %   generateFilteringCode(PF) creates a new file in the editor that
            %   contains code to create the branches of the parallel filter and 
            %   process the input data through the branches.
            %
            %   generateFilteringCode(PF, FNAME) generates the code and saves
            %   it to the file specified in the string FNAME. If a file named FNAME
            %   already exists, its content is replaced.
            %
            %   % Example:
            %   PF = parallel(dsp.FIRFilter(Numerator = ones(1,5)), dsp.SOSFilter);
            %   fName = 'filterScript.m';  % The code will be saved in this
            %                               % file in the current directory
            %   generateFilteringCode(PF, fName);
        end

        function out=getDiscreteStateProperties(~) %#ok<STOUT>
        end

        function out=getNumBranches(~) %#ok<STOUT>
            %GETNUMBRANCHES Number of filters in parallel filter
            %
            %   N = getNumBranches(PF) returns the number of branches in the 
            %           parallel filter object, PF.
            %   
            %
            %   % Example:
            %   PF = parallel(dsp.FIRFilter, dsp.IIRFilter);
            %   N = getNumBranches(PF);    % This will return 2
        end

        function out=helpSupportedSystemObjects(~) %#ok<STOUT>
            %HELPSUPPORTEDSYSTEMOBJECTS List all System objects supported by
            % dsp.ParallelFilter
            %
            % supportedObjs = dsp.ParallelFilter.helpSupportedSystemObjects
            %                   Display a list of System objects that can be used 
            %                   as branches of a dsp.ParallelFilter object
        end

        function out=infoImpl(~) %#ok<STOUT>
        end

        function out=isequal(~) %#ok<STOUT>
            %ISEQUAL Determine if two ParallelFilter objects are equal.
            %
            %   isequal(PF1, PF2) returns logical 1 (TRUE) if all branches of PF1
            %   are exactly the same in value as those of PF2.
            %
            %   % Example:
            %   PF1 = dsp.ParallelFilter(dsp.FIRDecimator, ...
            %                           dsp.FIRFilter(Numerator=ones(1,5)));
            %   PF2 = dsp.ParallelFilter(dsp.FIRDecimator, dsp.FIRFilter);
            %                           
            %   isequal(PF1, PF2);  % This will return false because Branch2 of
            %                       % both objects is not same
            %   PF3 = dsp.ParallelFilter(dsp.FIRDecimator, ...
            %                            dsp.FIRFilter(Numerator=ones(1,5)));
            %   isequal(PF1, PF3);  % This will return true
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Setting CloneBranches to false will avoid unnecessary cloning the result of
            % matlab.System.loadBoject()
        end

        function out=releaseBranches(~) %#ok<STOUT>
            %releaseBranches Release the locked state of all branches
            %
            %   releaseBranches(PF) calls RELEASE method on all branches of the
            %   parallel filter PF.
            %
            %   Use this function to ensure branches are released, even if the
            %   containing dsp.ParallelFilter object is not locked (in which case
            %   calling the release(PF) has no effect).
            %
            %   % Example:
            %   FIRFilt = dsp.FIRFilter;
            %   y = FIRFilt(randn);
            %   PF = dsp.ParallelFilter(dsp.SOSFilter, FIRFilt);
            %   isLocked(PF.Branch2)
            %   releaseBranches(PF);
            %   isLocked(PF.Branch2)
        end

        function out=removeBranch(~) %#ok<STOUT>
            %removeBranch Remove a branch from parallel filter
            %
            %   removeBranch(PF) removes a branch from the end of the parallel
            %   filter in PF.
            %
            %   removeBranch(PF, IDX) removes the branch from the branch position 
            %   IDX of the parallel filter in PF. All existing filters from IDX to 
            %   end of the parallel filter are shifted up the stack.
            %
            %   % Example 1: Remove a branch from the end of the parallel filter
            %   PF = dsp.ParallelFilter(dsp.FIRFilter, dsp.IIRFilter);
            %   removeBranch(PF);
            %
            %   % Example 2: Remove a filter from the third branch of a parallel filter
            %   % consisting of four branches
            %   PF = parallel(dsp.FIRFilter, dsp.Delay, dsp.IIRFilter, dsp.Delay);
            %   removeBranch(PF, 3);
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Called on saving the object
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Verify all branches have a single port, and setup
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=validateBranchRates(~) %#ok<STOUT>
            % Make sure all branches have the same rate conversion ratio.
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

    end
    properties
        %Branch1 First branch of parallel filter
        %   Specify the first branch of the parallel filter, as a filter
        %   System object. The default value of this property is
        %   dsp.FIRFilter.
        Branch1;

        %Branch10 Tenth branch of parallel filter
        Branch10;

        %Branch11 Eleventh branch of parallel filter
        Branch11;

        %Branch12 Twelfth branch of parallel filter
        Branch12;

        %Branch13 Thirteenth branch of parallel filter
        Branch13;

        %Branch14 Fourteenth branch of parallel filter
        Branch14;

        %Branch15 Fifteenth branch of parallel filter
        Branch15;

        %Branch16 Sixeenth branch of parallel filter
        Branch16;

        %Branch17 Seventeenth branch of parallel filter
        Branch17;

        %Branch18 Eighteenth branch of parallel filter
        Branch18;

        %Branch19 Nineteenth branch of parallel filter
        Branch19;

        %Branch2 Second branch of parallel filter
        Branch2;

        %Branch20 Twentieth branch of parallel filter
        Branch20;

        %Branch21 Twenty first branch of parallel filter
        Branch21;

        %Branch22 Twenty second branch of parallel filter
        Branch22;

        %Branch23 Twenty thid branch of parallel filter
        Branch23;

        %Branch24 Twenty fourth branch of parallel filter
        Branch24;

        %Branch3 Third branch of parallel filter
        Branch3;

        %Branch4 Fourth branch of parallel filter
        Branch4;

        %Branch5 Fifth branch of parallel filter
        Branch5;

        %Branch6 Sixth branch of parallel filter
        Branch6;

        %Branch7 Seventh branch of parallel filter
        Branch7;

        %Branch8 Eighth branch of parallel filter
        Branch8;

        %Branch9 Nine branch of parallel filter
        Branch9;

        %CloneBranches Control branch cloning
        %
        % If CloneBranches is false, the parallel filter branches assigned to the
        % ParallelFilter object occupy the same memory as the branches provided by
        % the user. You can add branches while creating the ParallelFilter object,
        % by direct assignment, or by using the addBranch method.
        %
        % If CloneBranches is set to true, the branches stored in the ParallelFilter
        % object are mere clones of the branches provided by the user, and do not
        % occupy the same memory.
        %
        % The default is true. This parameter can be set on construction only.
        CloneBranches;

        pNumBranches;

    end
end
