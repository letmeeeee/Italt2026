classdef ColoredNoise< matlab.System & matlab.system.mixin.FiniteSource
%ColoredNoise Generate a colored noise signal
%  CN = dsp.ColoredNoise returns a colored noise object, CN, that outputs a
%  noise signal one sample or frame at a time, with a 1/f^alpha spectral
%  characteristic over its entire frequency range. Typical values for alpha
%  are: alpha = 1 (pink noise), alpha = 2 (Brownian noise).
%
%  CN = dsp.ColoredNoise(Name=Value, ...) returns a colored noise object,
%  CN, with each specified property set to a specified value.
%
%  CN = dsp.ColoredNoise(POW,SAMP,CHAN,Name=Value) returns a colored noise
%  object, CN, with InverseFrequencyPower property set to POW,
%  SamplesPerFrame property set to SAMP, NumChannels property set to CHAN
%  and other specified properties set to specified values. Alternatively,
%  POW can be set to a color by name, such as "pink".
%
%  The ColoredNoise object uses the default MATLAB random stream. Reset
%  the default stream for repeatable simulations. Type 'help RandStream'
%  for more information.
%
%  Step method syntax:
%
%  Y = step(CN) outputs one sample or frame of data, Y.
%
%  Y = step(CN,L) outputs one frame of data, Y, of length L. This syntax
%  applies when SamplesPerFrameSource is 'Input port'.
%
%  System objects may be called directly like a function instead of using
%  the step method. For example, y = step(obj) and y = obj() are
%  equivalent.
%
%  ColoredNoise methods:
%
%  step     - Generate colored noise signal
%  release  - Allow property value and input characteristics changes
%  clone    - Create colored noise object with same property values
%  isLocked - Locked status (logical)
%  <a href="matlab:help matlab.System/reset   ">reset</a>    - Reset the generator internal states and the random number
%             stream if the RandomStream property is set to
%             'mt19937ar with seed'
%
%  ColoredNoise properties:
%
%  Color                 - Noise Color
%  InverseFrequencyPower - Define alpha, inverse frequency power in
%                          spectral characteristic 1/f^alpha.
%  BoundedOutput         - Guarantee the output is bounded (+/-1)
%  NumChannels           - Number of output channels
%  SamplesPerFrameSource - Source of number of samples per frame
%  SamplesPerFrame       - Number of samples per output channel
%  MaxSamplesPerFrame    - Maximum number of samples per output channel
%  OutputDataType        - Output data type
%  RandomStream          - Source of random number stream
%  Seed                  - Initial seed of mt19937ar random number stream
%
%  % EXAMPLE: Define a pink noise generator to output 2 channels of 1024
%  % noise samples and compute the power spectrum of the averaged signal 
%  % using a spectrum analyzer:
%
%  pn = dsp.ColoredNoise("pink",1024,2);
%  scope = spectrumAnalyzer(SpectrumType="power-density", ...
%      Method="welch", ....
%      PlotAsTwoSidedSpectrum=false, ...
%      FrequencyScale="log", ...
%      OverlapPercent=50, ...
%      Window="hamming", ...
%      YLimits=[-20,25]);
%  tic
%  while toc < 30    % Run for 30 seconds
%      pink = pn();  % pink is a 1024-by-2 frame of samples
%      scope(pink);
%  end

 
%  Copyright 2013-2022 The MathWorks, Inc.

    methods
        function out=ColoredNoise
        end

        function out=getExcitationNoise(~) %#ok<STOUT>
        end

        function out=getFilt(~) %#ok<STOUT>
            % Filter design function for 1/f^alpha power law
        end

        function out=getInverseFrequencyPower(~) %#ok<STOUT>
            % Return inverse frequency power based on selected noise color
        end

        function out=getNumInputsImpl(~) %#ok<STOUT>
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
            % Seed is unused when RandomStream is set to 'Global stream'
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Call base class method
            % Load this first so "getInverseFrequencyPower" has the data it needs
        end

        function out=resetImpl(~) %#ok<STOUT>
            % Reset Random Stream
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Default implementation saves all public properties
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
            % Create random vector
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

        function out=validateSamplesPerFrame(~) %#ok<STOUT>
        end

    end
    properties
        %BoundedOutput Guarantee the output is bounded (+/-1)
        %   Specify if the output is bounded inside +1 and -1 as true or
        %   false. If true, the internal random source is uniform instead
        %   of Gaussian, and a gain is applied so that the absolute maximum
        %   output never exceeds 1. For example, if COLOR is set to
        %   'white', there is no color filter and the output is uniform
        %   noise of amplitude +1 to -1. The output distribution of
        %   filtered noise (ex. pink noise) is quasi- Gaussian. The bounded
        %   output option is useful for applications such as digital audio,
        %   where the signal must be guaranteed to never exceed a certain
        %   value. The default value is 'false'.
        BoundedOutput;

        % Color Noise color
        %   Specify the noise color as one of 'pink'|'white'|'brown'|'blue'
        %   |'purple'|'custom'. Each color is associated with an inverse 
        %   frequency power of the generated noise sequence.
        %   For pink noise, set Color to 'pink'. The inverse frequency 
        %   power of pink noise is equal to 1. 
        %   For white noise, set Color to 'white'. The inverse frequency 
        %   power of white noise is equal to 0.
        %   For brown noise (also called red or Brownian noise), set 
        %   Color to 'brown'. The inverse frequency power of brown noise
        %   is equal to 2.
        %   For blue noise (also called azure noise), set Color to 
        %   'blue'.  The inverse frequency power of blue noise is equal to 
        %   -1.
        %   For purple noise (also called violet noise), set Color to 
        %   'purple'. The inverse frequency power of purple noise is equal 
        %   to -2.
        %   For noise with a custom inverse frequency power, set Color to 
        %   'custom'. In this case, the inverse frequency power is equal
        %   to the value specified in InverseFrequencyPower. 
        %   InverseFrequencyPower can be any value in the interval [-2,2].
        %   InverseFrequencyPower is relevant only when Color is set to
        %   'custom'.
        %   The default of this property is 'custom'
        Color;

        %InverseFrequencyPower  Power of inverse frequency
        %   Specify alpha in the 1/f^alpha spectral characteristic of the
        %   generated noise sequence over its entire frequency range.
        %   InverseFrequencyPower can be any value in the interval [-2,2].
        %   This property is relevant when the Color property is 'custom'. 
        %   The default value is 1 (pink noise).
        InverseFrequencyPower;

        % MaxSamplesPerFrame Maximum samples per frame 
        %   Specify the maximum number of samples per frame. This property
        %   applies when SamplesPerFrameSource is set to 'Input port'. The
        %   default value is 192000.
        MaxSamplesPerFrame;

        %NumChannels Number of output channels
        %   Specify the number of output channels as an integer.
        %   The default value is 1.
        NumChannels;

        %OutputDataType Output data type
        %   Specify the output data type as one of 'double' | 'single'.
        %   The default value is 'double'.
        OutputDataType;

        %RandomStream Random number source
        %   Specify the source of random number stream as one of
        %   'Global stream' | 'mt19937ar with seed'. If RandomStream is set
        %   to 'Global stream', the current global random number stream is
        %   used for normally distributed random number generation. If
        %   RandomStream is set to 'mt19937ar with seed', the mt19937ar
        %   algorithm is used for normally distributed random number
        %   generation, in which case the reset method re-initializes the
        %   random number stream to the value of the Seed property.
        %   The default value is 'Global stream'.
        RandomStream;

        %SamplesPerFrame Number of samples per output channel
        %   Specify the number of samples to buffer into each output
        %   channel. This property applies when you set
        %   SamplesPerFrameSource to 'Property'. The default value is 1024.
        SamplesPerFrame;

        %SamplesPerFrameSource Samples per frame source
        %   Specify the source of the number of samples per frame as one of
        %   'Property' or 'Input port'. The default is 'Property'.
        SamplesPerFrameSource;

        %Seed Initial seed
        %   Specify the initial seed of a mt19937ar random number generator
        %   algorithm as a double precision, real, nonnegative integer
        %   scalar. This property applies when you set the RandomStream
        %   property to 'mt19937ar with seed'. The Seed is to re-initialize
        %   the mt19937ar random number stream in the reset method.
        %   The default value is 67.
        Seed;

        pDenFilterCoef;

        %pFilterStates Holds internal filter states
        pFilterStates;

        %Filter coefficients, impulse response length and gain
        pNumFilterCoef;

        pOutputGain;

        % Random stream object (used in 'mt19937ar with seed' mode)
        pStream;

        % Random number generator state
        pWNState;

    end
end
