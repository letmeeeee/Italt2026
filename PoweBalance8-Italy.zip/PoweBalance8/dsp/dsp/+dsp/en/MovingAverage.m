classdef MovingAverage< dsp.internal.AbstractMovingStatistic
%   MovingAverage Compute moving average 
%   MAVRG = dsp.MovingAverage returns a System object, MAVRG, that computes
%   the moving average of the input signal.
%
%   MAVRG = dsp.MovingAverage(Name=Value, ...) returns a moving average
%   System object, MAVRG, with each specified property name set to the
%   specified value. You can specify additional name-value pair arguments
%   in any order as (Name1=Value1,...,NameN=ValueN).
%
%   MAVRG = dsp.MovingAverage(Length, Overlap, PropertyName=PropertyValue,
%   ...) returns a moving average object, MAVRG, with the WindowLength
%   property set to Length, the OverlapLength property set to Overlap
%   and other properties set to the specified values.
%
%   Step method syntax:
%
%   Y = step(MAVRG, X) computes the moving average, Y, of the real or
%   complex input X. Each column of X is a channel. The System object
%   computes the moving average of each channel of the input signal
%   independently over time.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   MovingAverage methods:
%
%   step                     - Compute moving average of the input
%   release                  - Allow property value and input 
%                              characteristics changes, and release moving 
%                              average resources
%   clone                    - Create moving average object with same
%                              property values
%   isLocked                 - Display locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>                    - Reset the states of the moving average
%
%   MovingAverage properties:
%
%   Method                  - Averaging method
%   SpecifyWindowLength     - Choose to specify sliding window length
%   WindowLength            - Sliding window length
%   OverlapLength           - Overlap length between windows
%   ForgettingFactor        - Exponential weighting forgetting factor
%
%  % EXAMPLE: Compute the moving average of a noisy square wave signal.
%  % Use a sliding window average of length 50, an exponentially weighted 
%  % average with a forgetting factor of 0.95, and a sliding window average
%  % of length 50 with an overlap of 45 samples.
%  FrameLength = 100;
%  Fs = 1000;
%  mavrg_slide   = dsp.MovingAverage(50);
%  mavrg_forget  = dsp.MovingAverage(Method='Exponential weighting',...
%                                   ForgettingFactor=0.95);
%  mavrg_overlap = dsp.MovingAverage(50,45);
%  scope  = timescope(SampleRate=[Fs, Fs, Fs, Fs/(50-45)],...
%                     TimeSpanSource='property',...
%                     TimeSpan=10,...
%                     YLimits=[-1.5 1.5]);
%  title = 'Moving Average';
%  scope.Title = title;
%  scope.ChannelNames = {'Original Signal',...
%      'Sliding window of 50 samples with default overlap',...
%      'Exponential weighting with forgetting factor of 0.95',...
%      'Sliding window of 50 samples with overlap of 45 samples'};    
%  count = 1;
%  A = 1;
%  tic;
%  while (toc < 5)
%    count = count + 1;
%    if (count == 10)
%      A = A * -1;
%      count = 1;
%    end
%    x = A + 0.1 * randn(FrameLength,1);
%    y1 = mavrg_slide(x);
%    y2 = mavrg_forget(x);
%    y3 = mavrg_overlap(x);
%    scope(x,y1,y2,y3);
%  end
%
%  See also dsp.MovingRMS, dsp.MovingVariance, 
%  dsp.MovingStandardDeviation, dsp.MovingMinimum, dsp.MovingMaximum, 
%  dsp.MedianFilter, dsp.HampelFilter

     
%   Copyright 2016-2023 The MathWorks, Inc.

    methods
        function out=MovingAverage
        end

        function out=getHeaderImpl(~) %#ok<STOUT>
            % MATLAB System block header
        end

        function out=getIconImpl(~) %#ok<STOUT>
        end

        function out=getStatisticObject(~) %#ok<STOUT>
            % Select internal computing object based on object settings
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

    end
    properties
        % Method Method 
        % Specify the averaging method as 'Sliding window' or 'Exponential
        % weighting'. In the sliding window method, the object computes the
        % moving average by sliding a window along the input. When
        % 'SpecifyWindowLength' is true, the sliding window length is equal
        % to the value of the 'WindowLength' property. When
        % 'SpecifyWindowLength' is false, the sliding window is of infinite
        % length. In this mode, the average is computed for the current
        % sample and all past samples).
        % In the exponential weighting method, the object computes
        % the average over samples weighted by an exponentially decaying
        % forgetting factor. The average of the Nth output sample is equal
        % to avrgN = (1/wN) * sum(lambda.^(N-1:-1:0) .* [x1 x2 x3 ... xN]),
        % where lambda is the forgetting factor, wN =
        % sum(lambda.^(N-1:-1:0)), and [x1 x2 x3 ... xN] is the vector
        % holding the current input sample xN and the N-1 previous samples.
        % The default is 'Sliding window'.
        Method;

    end
end
