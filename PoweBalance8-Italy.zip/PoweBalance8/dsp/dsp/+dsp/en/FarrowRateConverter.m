classdef FarrowRateConverter< dsp.internal.SupportScalarVarSize & dsp.internal.FilterAnalysis
%FarrowRateConverter Polynomial sample rate converter with arbitrary
%conversion factor.
%   SRC = dsp.FarrowRateConverter returns a polynomial sample rate
%   converter which converts the rate of each channel of the input signal
%   from the input sampling rate to the output sampling rate within
%   specified tolerance.
%
%   SRC = dsp.FarrowRateConverter('PropertyName', PropertyValue, ...)
%   returns a polynomial sample rate converter, SRC, with each specified
%   property set to the specified value.
%
%   SRC = dsp.FarrowRateConverter(FSIN, FSOUT, TOL, NP) returns a
%   polynomial sample rate converter, SRC, with InputSampleRate property
%   set to FSIN, OutputSampleRate property set to FSOUT,
%   OutputRateTolerance property set to TOL and PolynomialOrder property
%   set to NP.
%
%   Step method syntax:
%
%   Y = step(SRC, X) designs a polynomial-based interpolation or decimation
%   filter and then uses the filter to convert the rate of each channel
%   (column) of the real or complex input signal X to the output sampling
%   rate specified in SRC.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   FarrowRateConverter methods:
%
%   step                      - See above description for use of this
%                               method
%   release                   - Allow property value and input
%                               characteristics changes
%   clone                     - Create FarrowRateConverter object with same
%                               property values
%   isLocked                  - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>                     - Reset the internal states to initial
%                               conditions
%   getPolynomialCoefficients - Return polynomial coefficients used for
%                               rate conversion
%   getRateChangeFactors      - Get interpolation/decimation factors
%   getActualOutputRate       - Get adjusted output sample rate
%   generatehdl               - Generate HDL code. (Filter Design HDL Coder Required)
%
%   FarrowRateConverter properties:
%
%   InputSampleRate           - Input signal sampling rate (Hz)
%   OutputSampleRate          - Output signal sampling rate (Hz)
%   OutputRateTolerance       - Allowable tolerance for output signal rate
%   Specification             - 'Polynomial order' (default) | 'Coefficients'
%   PolynomialOrder           - Polynomial order for Lagrange interpolation filter
%                               (valid when Specification is 'Polynomial order')
%   Coefficients              - Directly-specified polynomial coefficients
%                               (valid when Specification is 'Coefficients')
%
%   This System object supports several filter analysis methods. For more
%   information, type dsp.FarrowRateConverter.helpFilterAnalysis.
%
%   This System object supports fixed-point operations. For more
%   information, type dsp.FarrowRateConverter.helpFixedPoint.
%
%   % EXAMPLE 1: Resample the input by a factor of 21/19
%   FsIn = 19;
%   frc = dsp.FarrowRateConverter(FsIn, 21);
%   n = (0:40)';
%   u = sin(n*pi/5).*exp(-0.025*(n-20).^2);
%   y = frc(u);
%
%   % Plot the original and resampled signals.
%   [D,FsOut] = frc.outputDelay(); 
%   ts = timescope(2, [FsIn FsOut], TimeDisplayOffset=[0, -D],... 
%                  ChannelNames={'Original','Resampled'},...
%                  PlotType='stem');
%   ts(u,y);
%
%   % EXAMPLE 2: Convert an audio signal from 44.1 kHz to 96 kHz
%   rateconv = dsp.FarrowRateConverter('InputSampleRate',44.1e3,...
%         'OutputSampleRate',96e3);
%   audioReader = dsp.AudioFileReader('guitar10min.ogg','SamplesPerFrame',14700);
%   audioWriter = dsp.AudioFileWriter('guitar10min_96kHz.wav','SampleRate',96e3);
%
%   tic
%   while toc < 10
%       x = audioReader();
%       y = rateconv(x);
%       audioWriter(y);
%   end
%   release(audioReader); release(audioWriter); release(rateconv)
%
%   % EXAMPLE 3: Adjust output sample rate tolerance
%   rateconv = dsp.FarrowRateConverter(InputSampleRate=8e3,...
%       OutputSampleRate=44.1e3);
%
%   % 0% tolerance (default): actual rate conversion factor is L/M=441/80
%   [L,M] = getRateChangeFactors(rateconv)
%
%   % The output sample rate remains as specified
%   FsOut = getActualOutputRate(rateconv)
%
%   % Set 1% tolerance 
%   rateconv.OutputRateTolerance = 0.01;
%
%   % Actual rate conversion factor is now L/M=11/2
%   [Le,Me] = getRateChangeFactors(rateconv)
%
%   % The output sample rate is now 44000 (100Hz below spec)
%   FsOutNew = getActualOutputRate(rateconv)
%
%   See also dsp.SampleRateConverter, dsp.FIRRateConverter,
%            dsp.FIRDecimator, dsp.FIRInterpolator,
%            dsp.FarrowRateConverter.helpFilterAnalysis,
%            designMultirateFIR, designFracDelayFIR.

 
% Copyright 2014-2022 The MathWorks, Inc.

    methods
        function out=FarrowRateConverter
        end

        function out=convertToDFILT(~) %#ok<STOUT>
            % Convert the System object to a mfilt object
        end

        function out=cost(~) %#ok<STOUT>
            %C = cost(obj) compute implementation cost
            %   C = cost(obj) returns a structure C whose fields contain
            %   information about the computation cost of implementing the
            %   Farrow rate converter. The cost estimate contains the
            %   following fields:
            %   NumCoefficients               : Number of farrow filter
            %                                   coefficients
            %   NumStates                     : Number of states
            %   MultiplicationsPerInputSample : Number of multiplications
            %                                   per input sample
            %   AdditionsPerInputSample       : Number of additions per
            %                                   input sample
            %   % Example: Compute cost for conversion between 44.1 kHz and
            %   % 48 kHz with a 0% tolerance
            %   SRC = dsp.FarrowRateConverter;
            %   cost(SRC)
        end

        function out=determineDataTypes(~) %#ok<STOUT>
            % Real or Complex value initializer
        end

        function out=farrowLoop(~) %#ok<STOUT>
        end

        function out=fdhdltool(~) %#ok<STOUT>
            %   FDHDLTOOL(FRC, nt) launches the Generate HDL dialog that lets you
            %   customize and generate Verilog or VHDL code and test benches for
            %   the dsp.FarrowRateConverter, FRC. You have to call FDHDLTOOL
            %   again if you make changes in the filter, FRC, in the command line.
            %
            %   The main dialog and two subordinate dialogs provide access to many
            %   options for customizing the generated filter and test bench code.
            %
            %   The Generate HDL main dialog categorizes options in two frames:
            %
            %   * HDL Filter - Options you are most likely to customize at least once:
            %   language selection, name and location of generated files, reset
            %   specifications, and optimizations.
            %
            %   * Test bench types - Options for naming and specifying the type of test
            %   bench files to generate, and specific types of stimuli the test benches
            %   are to apply.
            %
            %   EXAMPLE:
            %   frc = dsp.FarrowRateConverter;
            %   inT = numerictype(1,16,15);
            %   fdhdltool(frc, inT)
        end

        function out=generatehdl(~) %#ok<STOUT>
            %   GENERATEHDL(FRC, 'InputDataType', nt) automatically generates VHDL
            %   or Verilog code for the dsp.FarrowRateConverter, FRC. The default
            %   language is VHDL; to generate Verilog, supply the
            %   property/value pair 'TargetLanguage','Verilog'. The file is written to
            %   the HDL source directory which defaults to 'hdlsrc' under the
            %   current directory. This directory will be created if necessary.
            %
            %   GENERATEHDL(FRC, PARAMETER1, VALUE1, PARAMETER2, VALUE2, ...)
            %   generates the HDL code with parameter/value pairs. Valid properties
            %   and values for GENERATEHDL are listed in the Filter Design HDL
            %   Coder documentation section "Property Reference."
            %
            %   EXAMPLE:
            %   frc = dsp.FarrowRateConverter;
            %   inT = numerictype(1,16,15);
            %   generatehdl(frc, 'InputDataType', inT)
        end

        function out=getActualOutputRate(~) %#ok<STOUT>
            %FsOut = getActualOutputRate(obj) Get actual output rate
            %   FsOut = getActualOutputRate(obj) returns the actual output
            %   sample rate computed taking into account the
            %   OutputRateTolerance.
            %   % Example: Get actual output sample rate for conversion
            %   % between 44.1 kHz and 48 kHz with a 1% tolerance
            %   SRC = dsp.FarrowRateConverter;
            %   SRC.OutputRateTolerance = 0.01;
            %   FsOut = getActualOutputRate(SRC);
        end

        function out=getPolynomialCoefficients(~) %#ok<STOUT>
            %C = getPolynomialCoefficients(obj) Get polynomial coefficients
            %   C = getPolynomialCoefficients(obj) returns the polynomial
            %   coefficients used in the Farrow filter to perform the
            %   sampling rate conversion in a matrix C.
            %   % Example: Get the filter coefficients used for sample rate
            %   % conversion between 44.1 kHz and 48 kHz
            %   SRC = dsp.FarrowRateConverter;
            %   C = getPolynomialCoefficients(SRC);
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
            %Get default parameters group for this System object
        end

        function out=getRateChangeFactors(~) %#ok<STOUT>
            %[L,M] = getRateChangeFactors(obj) Get rate change factors
            %   [L,M] = getRateChangeFactors(obj) returns the interpolation
            %   factor L and the decimation factor M corresponding to the
            %   input/output sample rates. The factors are computed taking
            %   into account the OutputRateTolerance.
            %   % Example: Get interpolation/decimation factors for
            %   % conversion between 44.1 kHz and 48 kHz
            %   SRC = dsp.FarrowRateConverter;
            %   [L,M] = getRateChangeFactors(SRC);
        end

        function out=helpFixedPoint(~) %#ok<STOUT>
            %helpFixedPoint Display dsp.FarrowRateConverter System object
            %               fixed-point information
            %   dsp.FarrowRateConverter.helpFixedPoint displays information
            %   about fixed-point properties and operations of the
            %   dsp.FarrowRateConverter System object.
        end

        function out=infoImpl(~) %#ok<STOUT>
        end

        function out=isFixedSizeOutput(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
            % Variable size inputs are allowed
        end

        function out=islinphase(~) %#ok<STOUT>
            % If  Lagrange design of odd order, the filter has a linear phase
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Call base class method
        end

        function out=needToDesignFilter(~) %#ok<STOUT>
        end

        function out=outputDelay(~) %#ok<STOUT>
        end

        function out=outputFrameSize(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
            % Unlock number of channels
        end

        function out=resetImpl(~) %#ok<STOUT>
            % Reset the internal states
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Default implementation saves all public properties
        end

        function out=setFarrowSRCProperties(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Create Farrow filter
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            % Invoked at first call to setup/step, and then every time the
            % input dimensions change
        end

    end
    properties
        AdjustedOutputRate;

        %Coefficients Coefficients
        %   Specify the polynomial coefficients. This property must be a
        %   real-valued square matrix. The default value is [-1 1; 1 0].
        %   This property only applies when Specification is 'Coefficients'
        Coefficients;

        %CoefficientsDataType Custom coefficients data type
        %   Specify the coefficients data type with a numerictype object.
        %   The default is numerictype(1,16).
        %   The coefficients data type must be signed.
        CoefficientsDataType;

        CoefficientsExist;

        DecimationFactor;

        %FractionalDelayDataType Custom fractional delay data type
        %   Specify the fractional delay data type with a numerictype object.
        %   The default is numerictype(0,8).
        %   The fractional delay data type must be unsigned.
        FractionalDelayDataType;

        %InputSampleRate Sample rate of input signal (Hz)
        %   Specify the sampling rate of the input signal in Hertz, as a
        %   finite numeric scalar. The default value of this property is
        %   44100
        InputSampleRate;

        InterpolationFactor;

        %MultiplicandDataType Custom multiplicand data type
        %   Specify the multiplicand data type with a numerictype object.
        %   The default is numerictype(1,16,13).
        %   The multiplicand data type must be signed.
        MultiplicandDataType;

        %OutputDataType Output data type
        %   Specify the output data type as a numeric type object or
        %   as one of the following:
        %   [ 'Same word length as input' | 'Same as accumulator' ]
        %   The default is 'Same word length as input'.
        %   The output data type must be signed.
        OutputDataType;

        %OutputRateTolerance Tolerance for output sample rate
        %   Specify the tolerance for the rate desired for the output
        %   signal, as a finite numeric scalar. The output rate tolerance
        %   allows for a simpler design in many cases. However, the actual
        %   output sample rate will vary for the output sample rate
        %   specified within the given tolerance percentage. For example,
        %   if OutputRateTolerance is specified as 0.01, the actual output
        %   sample rate will be in the range given by OutputSampleRate +/-
        %   1%. The default value of this property is 0
        OutputRateTolerance;

        %OutputSampleRate Sample rate of output signal (Hz)
        %   Specify the sampling rate of the output signal in Hertz, as a
        %   finite numeric scalar. The default value of this property is
        %   48000
        OutputSampleRate;

        %OverflowAction Overflow action for fixed-point arithmetic operations
        %   Specify the overflow action as one of ['Wrap' | 'Saturate'].
        %   The default value of this property is 'Wrap'.
        OverflowAction;

        PolynomialCoefficients;

        %PolynomialOrder Polynomial order
        %   Specify the order of the Lagrange interpolation filter, as a
        %   finite numeric scalar. The default value of this property is 3.
        %   This property only applies when Specification is 'Polynomial order'
        PolynomialOrder;

        PrivCoeff;

        PrivL;

        PrivLinv;

        PrivM;

        %RoundingMethod Rounding method for fixed-point arithmetic operations
        %   Specify the rounding method as one of ['Ceiling' | 'Convergent'
        %   | 'Floor' | 'Nearest' | 'Round' | 'Zero']. The default value of
        %   this property is 'Floor'.
        RoundingMethod;

        %Specification Filter specification method
        %   Specify how to determine the polynomial interpolator
        %   coefficients as one of ['Polynomial order' | 'Coefficients'].
        %   The default value of this property is 'Polynomial order'.
        Specification;

        % States Internal filter states
        States;

        % Tnext Used to compute fractional delay
        Tnext;

        %pInputDatatype -  datatype of input when object is locked
        pInputDatatype;

        %pIsFltPt -  Indicates usage of internal double/single datatypes
        pIsFltPt;

    end
end
