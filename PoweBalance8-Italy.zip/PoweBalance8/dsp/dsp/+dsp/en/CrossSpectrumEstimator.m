classdef CrossSpectrumEstimator< dsp.internal.SpectrumEstimatorBase
%CrossSpectrumEstimator Estimate cross-power spectrum density
%   CSE = dsp.CrossSpectrumEstimator returns a System object, CSE, that
%   computes the frequency cross-power spectrum density of real or complex
%   signals via the periodogram method and Welch's averaged, modified
%   periodogram method.
%
%   CSE = dsp.CrossSpectrumEstimator(Name=Value, ...) returns a
%   Cross-Spectrum Estimator System object, CSE, with each specified
%   property name set to the specified value. You can specify additional
%   name-value pair arguments in any order as
%   Name1=Value1,...,NameN=ValueN).
%
%   Step method syntax:
%
%   Pxy = step(CSE, X, Y) computes the frequency cross power spectrum 
%   density , Pxy, of X and Y. X and Y must be of the same size. The 
%   columns of X and Y are treated as independent channels.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   CrossSpectrumEstimator methods:
%
%   step                 - Compute cross power spectrum of inputs (see 
%                          above)
%   release              - Allow property value and input characteristics 
%                          changes, and release Cross Spectrum Estimator 
%                          resources
%   clone                - Create Cross Spectrum Estimator object with same 
%                          property values
%   isLocked             - Display locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>                - Reset the states of the Cross Spectrum Estimator
%   getRBW               - Get the resolution bandwidth of the spectrum
%   getFrequencyVector   - Get the vector of frequencies at which the
%                          spectrum is estimated
%
%   CrossSpectrumEstimator properties:
%
%   SampleRate                   - Sample rate of input 
%   SpectralAverages             - Number of spectral averages
%   FFTLengthSource              - Source of the FFT length value
%   FFTLength                    - FFT length
%   Window                       - Window function
%   SidelobeAttenuation          - Sidelobe attenuation of window
%   FrequencyRange               - Frequency range of the Spectrum estimate
%   AveragingMethod              - Averaging method
%   SpectralAverages             - Number of spectral averages
%   ForgettingFactor             - Forgetting factor
%
%   % EXAMPLE: Compute the cross power spectrum of two noisy sine waves
%   % Initialize
%   frameLength = 1000;
%   Fs = 1000;
%   sine1 = dsp.SineWave(Frequency=200,...
%       SampleRate=Fs,...
%       SamplesPerFrame=frameLength);
%   sine2 = dsp.SineWave(Frequency=100,...
%       SampleRate=Fs,...
%       SamplesPerFrame=frameLength);
%   csestim = dsp.CrossSpectrumEstimator(SampleRate=Fs,...
%       FrequencyRange="centered");
%   scope = dsp.ArrayPlot(PlotType="Line",...
%       XOffset=-Fs/2,...
%       YLimits=[-150 -60],...
%       YLabel="Power Spectrum Density (Watts/Hz)",...
%       XLabel="Frequency (Hz)",...
%       Title="Cross Power Spectrum of Two Signals");
%
%   % Stream processing loop
%   for index = 1:10
%       x = sine1() + 0.05*randn(frameLength,1);
%       y = sine2() + 0.05*randn(frameLength,1);
%       Pxy = csestim(x,y);
%       scope(20*log10(abs(Pxy)));
%   end
%
%   See also dsp.SpectrumEstimator, dsp.TransferFunctionEstimator,
%            spectrumAnalyzer, dsp.ArrayPlot.

 
%   Copyright 2013-2021 The MathWorks, Inc.

    methods
        function out=CrossSpectrumEstimator
            %CrossSpectrumEstimator   Construct the CrossSpectrumEstimator class.
        end

        function out=computeWindowFFT(~) %#ok<STOUT>
            % Window the X data
        end

        function out=convertAndScale(~) %#ok<STOUT>
        end

        function out=getNumInputsImpl(~) %#ok<STOUT>
            % Two inputs x and y
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
            % Modify order of display
        end

        function out=initializeSpectrumCache(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isOutputComplexImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

    end
end
