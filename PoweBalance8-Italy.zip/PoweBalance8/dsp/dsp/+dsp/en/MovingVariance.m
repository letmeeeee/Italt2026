classdef MovingVariance< dsp.internal.AbstractMovingStatistic
%   MovingVariance Compute moving variance 
%   MVAR = dsp.MovingVariance returns a System object, MVAR, that computes
%   the moving variance of the input signal.
%
%   MVAR = dsp.MovingVariance(Name=Value, ...) returns a moving variance
%   System object, MVAR, with each specified property name set to the
%   specified value. You can specify additional name-value pair arguments
%   in any order as (Name1=Value1,...,NameN=ValueN).
%
%   MVAR = dsp.MovingVariance(Length, Overlap, PropertyName=PropertyValue,
%   ...) returns a moving variance object, MVAR, with the WindowLength
%   property set to Length, OverlapLength property set to Overlap and other 
%   properties set to the specified values.
%
%   Step method syntax:
%
%   Y = step(MVAR, X) computes the moving variance, Y, of the real or
%   complex input X. Each column of X is a channel. The System
%   object computes the moving variance of each channel of the input signal
%   independently over time.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   MovingVariance methods:
%
%   step                     - Compute moving variance of input
%   release                  - Allow property value and input 
%                              characteristics changes, and release moving 
%                              variance resources
%   clone                    - Create moving variance object with same
%                              property values
%   isLocked                 - Display locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>                    - Reset the states of the moving variance
%
%   MovingVariance properties:
%
%   Method                  - Averaging method
%   SpecifyWindowLength     - Choose to specify sliding window length
%   WindowLength            - Sliding window length
%   OverlapLength           - Overlap length between windows
%   ForgettingFactor        - Exponential weighting forgetting factor
%
%   % EXAMPLE: Compute the moving variance of Gaussian noise with varying
%   %          power. Use a sliding window variance of length 1000, an 
%   %          exponentially weighted variance with a forgetting factor of
%   %          0.999, and a sliding window variance of length 1000 with
%   %          an overlap of 900 samples.
%   FrameLength = 100;
%   Fs = 100;
%   mvar_slide    = dsp.MovingVariance(1000);
%   mvar_forget   = dsp.MovingVariance(Method='Exponential weighting',...
%                                      ForgettingFactor=0.999);
%   mvar_overlap  = dsp.MovingVariance(1000,900);
%   scope  = timescope(SampleRate=[Fs,Fs,Fs,Fs/(1000-900)],...
%                      TimeSpanSource='property', ...
%                      TimeSpan=1.5e3, ...
%                      YLimits=[0 7e-4]);
%   title = 'Moving Variance';
%   scope.Title = title;
%   scope.ChannelNames = {'Original Signal',...
%       'Sliding window of 900 samples with default overlap',...
%       'Exponential weighting with forgetting factor of 0.999',...
%       'Sliding window of 1000 samples with overlap of 900 samples'};
%   count = 1;
%   noisePower = 1e-4 * [(1:5) (5:-1:1)];
%   index = 1;
%   for index = 1:length(noisePower)
%    np = noisePower(index);
%    yexp = np * ones(FrameLength,1);
%    for frameIdx = 1:150
%     x  = 1 + sqrt(np) * randn(FrameLength,1);
%     y1 = mvar_slide(x);
%     y2 = mvar_forget(x);
%     y3 = mvar_overlap(x);
%     scope(yexp,y1,y2,y3);
%    end
%   end
%
%   See also dsp.MovingAverage, dsp.MovingRMS, 
%   dsp.MovingStandardDeviation, dsp.MovingMinimum, dsp.MovingMaximum

     
%   Copyright 2016-2023 The MathWorks, Inc.

    methods
        function out=MovingVariance
            % Constructor
        end

        function out=getHeaderImpl(~) %#ok<STOUT>
            % MATLAB System block header
        end

        function out=getIconImpl(~) %#ok<STOUT>
        end

        function out=getStatisticObject(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

    end
    properties
        % Method Averaging method
        % Specify the averaging method as 'Sliding window' or
        % 'Exponential weighting'. 
        % In the sliding window method, the object computes the moving variance
        % by sliding a window along the input. When 'SpecifyWindowLength' is
        % true, the sliding window length is equal to the value of the
        % 'WindowLength' property. When 'SpecifyWindowLength' is false, the
        % sliding window is of infinite length. In this mode, the variance is
        % computed for the current sample and all past samples).
        % In the exponential weighting method, the object computes
        % the variance over samples weighted by an exponentially decaying
        % forgetting factor.
        % The default is 'Sliding window'.
        Method;

    end
end
