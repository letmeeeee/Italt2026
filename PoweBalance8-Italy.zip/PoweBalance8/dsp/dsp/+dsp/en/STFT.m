classdef STFT< handle & matlab.mixin.internal.indexing.Paren & matlab.mixin.SetGet
% STFT Short-time FFT
%   STFT = dsp.STFT returns an object, STFT, that implements short-time
%   FFT. The object processes the data independently across each input
%   channel over time.
%
%   STFT = dsp.STFT(WINDOW) returns a short-time FFT object, STFT, with
%   the Window property set to WINDOW.
%
%   STFT = dsp.STFT(WINDOW,OVERLAPLENGTH) returns a short-time FFT object,
%   STFT, with the Window property set to WINDOW, and the OverlapLength
%   property set to OVERLAPLENGTH, respectively.
%
%   STFT = dsp.STFT(WINDOW,OVERLAPLENGTH,NFFT) returns  a short-time FFT
%   object, STFT, with the Window property set to WINDOW, the OverlapLength
%   property set to  OVERLAPLENGTH, and the FFTLength property set to NFFT,
%   respectively.
%
%   STFT = dsp.STFT('Name', Value, ...) returns a short-time FFT object,
%   STFT, with each specified property name set to the specified value.
%   You can specify additional name-value pair arguments in any order as
%   (Name1,Value1,...,NameN, ValueN).
%
%   Step method syntax:
%
%   Y = step(STFT,X) applies short-time FFT on the input X, and returns the
%   frequency-domain output Y. X must be a double-precision or
%   single-precision matrix. The object treats each column as an
%   independent channel. The frame length (number of rows in x) must be
%   equal to or less than the hop length (window length - overlap length).
%   If there are enough samples to form an STFT output, Y is a
%   FFTLength-by-N matrix, where N is the number of input channels. If
%   there are not enough samples to form an STFT output, Y is empty.
%
%   This object may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
% STFT methods:
%
%   step                  - See above description for use of this method
%   release               - Allow property value and input characteristics
%                           to change
%   clone                 - Create STFT object with same property values
%   isLocked              - Locked status (logical)
%   reset                 - Reset the internal states to initial conditions
%   getFrequencyVector    - Get the vector of frequencies at which the
%                           short-time FFT is computed
%
%   STFT properties:
%
%   Window                - Analysis window
%   OverlapLength         - Overlap length
%   FFTLength             - FFT length
%   FrequencyRange        - Frequency range
%
%   % EXAMPLE: Short-time spectral attenuation
%   % Use dsp.STFT and dsp.ISTFT to denoise a signal with wideband
%   % background noise.
%
%   % First, listen to audio signal corrupted by white gaussian noise:
%   FrameLength     = 512;
%   afr = dsp.AudioFileReader('speech_dft.wav',...
%                             'SamplesPerFrame',FrameLength);
%   adw = audioDeviceWriter('SampleRate',22050);
%
%   noiseStd = 0.05;
%   while ~isDone(afr)
%      cleanAudio =  afr();
%      noisyAudio = cleanAudio + noiseStd * randn(FrameLength,1);
%      adw(noisyAudio);
%   end
%
%   reset(afr);
%
%   % Now use stft and istft combined with a gain estimator to remove noise.
%
%   % Define stft parameters:
%   WindowLength    = FrameLength;
%   HopLength       = 16;
%   numHopsPerFrame = FrameLength / 16;
%   FFTLength       = 1024;
%
%   % Define stft and istft objects:
%   win             = hamming(WindowLength,'periodic');
%   stf             = dsp.STFT(win,WindowLength-HopLength,FFTLength);
%   istf            = dsp.ISTFT(win,WindowLength-HopLength,1,0);
%
%   % Define gain estimation parameters:
%   dec      = 16;
%   alpha    = 15;
%   stftNorm = (sum(win.*win) / dec).^2;
%
%   % Perform spectral attenuation
%   while ~isDone(afr)
%     cleanAudio =  afr();
%     noisyAudio = cleanAudio + noiseStd * randn(FrameLength,1);
%
%     y = zeros(FrameLength , 1); % y holds the denoised audio frame
%
%     % Feed audio to stft one hop-length at a time
%     for index = 1:numHopsPerFrame
%
%         X = stf(noisyAudio((index-1)*HopLength+1:index*HopLength));
%
%         % Gain estimator
%         Z = abs(X).^2 / (noiseStd^2 * alpha) / stftNorm;
%         Z(Z<=1) = 1;
%         Z = 1 - 1./Z;
%         Z = sign(Z) .* sqrt(abs(Z));
%         X = X .* Z;
%
%         % Convert back to time-domain
%         y((index-1)*HopLength+1:index*HopLength) = istf(X);
%
%     end
%
%     % Listen to denoised audio:
%     adw(y);
%   end
%
%   See also dsp.ISTFT, dsp.FFT, dsp.IFFT

 
% Copyright 2018-2020 The MathWorks, Inc.

    methods
        function out=STFT
        end

        function out=clone(~) %#ok<STOUT>
            % clone Create object with same property values
            %  C = clone(OBJ) creates another instance of the object, OBJ,
            %  with the same property values. If OBJ is locked, the clone
            %  method creates a copy that is also locked and has states
            %  initialized to the same values as the original. If OBJ is not
            %  locked, the clone method creates a new unlocked object with
            %  uninitialized states.
        end

        function out=getFrequencyVector(~) %#ok<STOUT>
            % getFrequencyVector Get the vector of frequencies at which the
            % short-time FFT is computed.
            %
            % f = getFrequencyVector(OBJ) returns the frequency vector at which
            %   the short-time FFT is computed. The sampling frequency used is
            %   2 * pi.
            %
            % f = getFrequencyVector(OBJ,FS) returns the frequency vector at
            %   which the short-time FFT is computed. The sampling frequency
            %   used is FS.
            %
            %   If you set the FrequencyRange to 'onesided' and the FFT length,
            %   NFFT, is even, the frequency vector is of length NFFT/2+1 and.
            %   If you set the FrequencyRange to 'onesided' and NFFT is odd,
            %   the frequency vector is of length (NFFT+1)/2. If you set the
            %   FrequencyRange to 'twosided', the frequency vector is of length
            %   NFFT.
            %
            % % Example: Get the frequency vector at which the short-time FFT
            % % is computed
            %
            % Fs = 44100;
            % stf = dsp.STFT;
            % f = getFrequencyVector(stf,Fs);
        end

        function out=getNumFrequencySamples(~) %#ok<STOUT>
            % Return the number of frequency samples based on the
            % FrequencyRange and FFTLength
        end

        function out=isLocked(~) %#ok<STOUT>
            % isLocked Locked status for input attributes and non-tunable
            % properties
        end

        function out=isOneSided(~) %#ok<STOUT>
        end

        function out=release(~) %#ok<STOUT>
            % release Allow property value and input characteristics
            % changes
        end

        function out=reset(~) %#ok<STOUT>
            % reset Reset the internal states of the object
        end

        function out=set(~) %#ok<STOUT>
            % Overload set() to enable tab completion of string property
            % values
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=step(~) %#ok<STOUT>
            %     Y = step(OBJ,x) processes the input data, x, to produce the
            %     output, Y, for object, OBJ.
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

        function out=validatePropertiesImpl(~) %#ok<STOUT>
        end

    end
    properties
        % FFTLength FFT length
        % Specify the FFT length as a scalar, positive integer. The default
        % is 512.
        FFTLength;

        %FrequencyRange Frequency range
        % Specify the frequency range as 'onesided' or 'twosided'. If you
        % set the FrequencyRange to 'onesided', the one-sided short-time
        % FFT is computed for real input signals. When the FFT length,
        % NFFT, is even, the short-time FFT length is NFFT/2+1 . If NFFT is
        % odd, the length of the short-time FFT is equal to (NFFT+1)/2. If
        % you set the FrequencyRange to 'twosided', the short-time FFT is
        % computed for complex or real inputs signals. The length of the
        % short-time FFT is equal to NFFT. The default is 'twosided'.
        FrequencyRange;

        % OverlapLength Overlap length
        % Specify the number of samples by which consecutive windows
        % overlap by as a scalar, positive integer. The default is 256.
        OverlapLength;

        % Window Analysis window
        % Specify the analysis window as a vector of real elements. The
        % object buffers the input to overlapping window segments using the
        % specified window length and overlap length, and then multiplies
        % each overlapped segment by the window. The default is
        % sqrt(hann(512,'periodic')). This property is tunable.
        Window;

    end
end
