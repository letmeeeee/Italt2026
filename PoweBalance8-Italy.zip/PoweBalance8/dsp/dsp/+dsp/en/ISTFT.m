classdef ISTFT< handle & matlab.mixin.internal.indexing.Paren & matlab.mixin.SetGet
% ISTFT Inverse short-time FFT
%   ISTFT = dsp.ISTFT returns an object, ISTFT, that implements inverse
%   short-time FFT. The object processes the data independently across
%   each input channel over time.
%
%   ISTFT = dsp.ISTFT(WINDOW) returns an inverse short-time FFT object,
%   ISTFT, with the Window property set to WINDOW.
%
%   ISTFT = dsp.ISTFT(WINDOW,OVERLAPLENGTH) returns an inverse
%   short-time FFT object, ISTFT, with the Window property set to
%   WINDOW, and the OverlapLength property set to OVERLAPLENGTH,
%   respectively.
%
%   ISTFT = dsp.ISTFT(WINDOW,OVERLAPLENGTH,ISCONJSYM) returns an
%   inverse short-time FFT object, ISTFT, with the Window property set
%   to WINDOW, the OverlapLength property set to OVERLAPLENGTH, and the
%   ConjugateSymmetricInput property set to ISCONJSYM, respectively.
%
%   ISTFT = dsp.ISTFT(WINDOW,OVERLAPLENGTH,ISCONJSYM,WOA) returns an
%   inverse short-time FFT object, ISTFT, with the Window property set
%   to WINDOW, the OverlapLength property set to OVERLAPLENGTH, the
%   ConjugateSymmetricInput property set to ISCONJSYM, and the
%   WeightedOverlapAdd property set to WOA, respectively.
%
%   ISTFT = dsp.ISTFT('Name', Value, ...) returns an inverse short-time
%   FFT object, ISTFT, with each specified property name set to the
%   specified value. You can specify additional name-value pair
%   arguments in any order as (Name1,Value1,...,NameN, ValueN).
%
%   Step method syntax:
%
%   Y = step(ISTFT,X) applies inverse short-time FFT on the input X,
%   and returns the time-domain output Y. X must be a double-precision
%   or single-precision matrix. The object treats each column as an
%   independent channel. The FFT length is equal to the number of rows
%   of X. The output frame length (number of rows in Y) is equal to
%   WindowLength - OverlapLength.
%
%   This object may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   ISTFT methods:
%
%   step                     - See above description for use of this
%                              method
%   release                  - Allow property value and input 
%                              characteristics to change
%   clone                    - Create ISTFT object with same property 
%                              values
%   isLocked                 - Locked status (logical)
%   reset                    - Reset the internal states to initial 
%                              conditions
%
%   ISTFT properties:
%
%   Window                   - Synthesis window
%   OverlapLength            - Overlap length
%   ConjugateSymmetricInput  - Input is conjugate symmetric
%   WeightedOverlapAdd       - Apply weighted overlap-add
%   FrequencyRange           - Frequency range
%
%   % EXAMPLE: Short-time spectral attenuation
%   % Use dsp.STFT and dsp.ISTFT to denoise a signal with wideband
%   % background noise.
%
%   % First, listen to audio signal corrupted by white gaussian noise:
%   FrameLength     = 512;
%   afr = dsp.AudioFileReader('speech_dft.wav',...
%                             'SamplesPerFrame',FrameLength);
%   adw = audioDeviceWriter('SampleRate',22050);
%
%   noiseStd = 0.05;
%   while ~isDone(afr)
%      cleanAudio =  afr();
%      noisyAudio = cleanAudio + noiseStd * randn(FrameLength,1);
%      adw(noisyAudio);
%   end
%
%   reset(afr);
%
%   % Now use stft and istft combined with a gain estimator to remove 
%   % noise.
%
%   % Define stft parameters:
%   WindowLength    = FrameLength;
%   HopLength       = 16;
%   numHopsPerFrame = FrameLength / 16;
%   FFTLength       = 1024;
%
%   % Define stft and istft objects:
%   win             = hamming(WindowLength,'periodic');
%   stf             = dsp.STFT(win,WindowLength-HopLength,FFTLength);
%   istf            = dsp.ISTFT(win,WindowLength-HopLength,1,0);
%
%   % Define gain estimation parameters:
%   dec      = 16;
%   alpha    = 15;
%   stftNorm = (sum(win.*win) / dec).^2;
%
%   % Perform spectral attenuation
%   while ~isDone(afr)
%     cleanAudio =  afr();
%     noisyAudio = cleanAudio + noiseStd * randn(FrameLength,1);
%
%     y = zeros(FrameLength , 1); % y holds the denoised audio frame
%
%     % Feed audio to stft one hop-length at a time
%     for index = 1:numHopsPerFrame
%
%         X = stf(noisyAudio((index-1)*HopLength+1:index*HopLength));
%
%         % Gain estimator
%         Z = abs(X).^2 / (noiseStd^2 * alpha) / stftNorm;
%         Z(Z<=1) = 1;
%         Z = 1 - 1./Z;
%         Z = sign(Z) .* sqrt(abs(Z));
%         X = X .* Z;
%
%         % Convert back to time-domain
%         y((index-1)*HopLength+1:index*HopLength) = istf(X);
%
%     end
%
%     % Listen to denoised audio:
%     adw(y);
%   end
%
%   See also dsp.STFT, dsp.FFT, dsp.IFFT

     
    % Copyright 2018-2020 The MathWorks, Inc.

    methods
        function out=ISTFT
        end

        function out=calculateFFTLength(~) %#ok<STOUT>
            % Calculate FFT length based on the current input and frequency
            % range
        end

        function out=calculateNumFrequencySamples(~) %#ok<STOUT>
        end

        function out=clone(~) %#ok<STOUT>
            % clone Create object with same property values
            %  C = clone(OBJ) creates another instance of the object, OBJ,
            %  with the same property values. If OBJ is locked, the clone
            %  method creates a copy that is also locked and has states
            %  initialized to the same values as the original. If OBJ is not
            %  locked, the clone method creates a new unlocked object with
            %  uninitialized states.
        end

        function out=isLocked(~) %#ok<STOUT>
            % isLocked Locked status for input attributes and non-tunable
            % properties
        end

        function out=isOneSided(~) %#ok<STOUT>
        end

        function out=release(~) %#ok<STOUT>
            % release Allow property value and input characteristics
            % changes
        end

        function out=reset(~) %#ok<STOUT>
            % reset Reset the internal states of the object
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=step(~) %#ok<STOUT>
            %     Y = step(OBJ,x) processes the input data, x, to produce the 
            %     output, Y, for object, OBJ.
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

        function out=validatePropertiesImpl(~) %#ok<STOUT>
        end

    end
    properties
        % ConjugateSymmetricInput Input is conjugate symmetric
        % Set this property to true if the input is conjugate symmetric to
        % yield real-valued outputs. The FFT of a real valued signal is
        % conjugate symmetric, and setting this property to true optimizes
        % the IFFT computation method. Setting this property to false for
        % conjugate symmetric inputs results in complex output values with
        % small imaginary parts. Setting this property to true for
        % non-conjugate symmetric inputs results in invalid outputs.
        % The default value of this property is true.
        ConjugateSymmetricInput;

        %FrequencyRange Frequency range
        % Specify the frequency range as 'onesided' or 'twosided'. If you
        % set the FrequencyRange to 'onesided', the one-sided inverse
        % short-time FFT is computed for a one-sided short-time FFT. If the
        % input frame length is odd, the FFT length used is (frame length -
        % 1) * 2. If the input frame length is even, the FFT length used is
        % (frame length * 2) - 1. If you set the FrequencyRange to
        % 'twosided', the inverse short-time FFT is computed for a
        % two-sided short-time FFT. The FFT length used is equal to the
        % input frame length. The default is 'twosided'.
        FrequencyRange;

        % OverlapLength Overlap length
        % Specify the number of samples by which consecutive windows
        % overlap by as a scalar, positive integer. The default is 256.
        OverlapLength;

        % WeightedOverlapAdd  Apply weighted overlap-add
        % Set this property to true to apply weighted overlap-add. In
        % weighted overlap-add, the IFFT output is multiplied by the window
        % prior to overlap-add. Set this property to false to skip
        % multiplication by the window. The default of this property is
        % true.
        WeightedOverlapAdd;

        % Window Synthesis window
        % Specify the synthesis window as a vector of real elements. The
        % default is sqrt(hann(512,'periodic')). This property is tunable.
        Window;

    end
end
