classdef IIRHalfbandDecimator< dsp.internal.IIRHalfbandBase
%IIRHalfbandDecimator Decimate by a factor of two using polyphase IIR
%   This System object lets you design and use decimators that implement
%   IIR halfband structures. Allpass filters are used in the polyphase
%   branches. Filters can be designed either using elliptic or quasi-linear
%   phase design methods. You can convert this System object to an analysis
%   filter bank.
%
%   IIRHALFBANDDECIM = dsp.IIRHalfbandDecimator returns a System object,
%   IIRHALFBANDDECIM, that decimates each channel of the input signal
%   by a factor of 2 using IIR halfband filters.
%
%   IIRHALFBANDDECIM = dsp.IIRHalfbandDecimator(Name=Value, ...) returns
%   a IIR halfband decimator System object, IIRHALFBANDDECIM, with each
%   specified property set to the specified value.
%
%   Step method syntax:
%
%   Y = step(IIRHALFBANDDECIM,X) outputs the decimated values, Y, of the
%   input signal, X. A Ki-by-N input matrix is treated as N independent
%   channels, and the System object decimates each channel over time and
%   generates a Ko-by-N output matrix. Ko = Ki/2, where 2 is the decimation
%   factor. The object supports real and complex floating-point inputs.
%
%   [YLP, YHP] = step(IIRHALFBANDDECIM,X) computes the power-complimentary
%   outputs, YLP and YHP, of the analysis filter bank, IIRHALFBANDDECIM for
%   input X. A Ki-by-N input matrix is treated as N independent channels.
%   The System object generates two power-complementary output signals by
%   adding and subtracting the two polyphase branch outputs respectively.
%   YLP and YHP are of the same data type and size, Ko-by-N. Ko = Ki/2,
%   where 2 is the decimation factor.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   IIRHalfbandDecimator methods:
%   step     - See above description for use of this method
%   release  - Allow property value and input characteristics changes
%   clone    - Create IIR halfband decimator object with same property 
%              values
%   isLocked - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>    - Reset the internal states to initial conditions
%
%   IIRHalfbandDecimator properties:
%
%   SampleRate           - Input sample rate (Hz)
%   Specification        - Filter design parameter specification
%   FilterOrder          - Order of the filter
%   TransitionWidth      - Transition width of the IIR halfband filter
%   StopbandAttenuation  - Minimum attenuation needed in stopband of
%                          the IIR halfband filter (dB)
%   DesignMethod         - Design method for the IIR halfband filter
%   NormalizedFrequency  - Provide normalized frequencies for filter
%                          specifications
%   Structure            - Filter structure used in coefficient mode
%   AllpassCoefficients1 - Branch 1 coefficients, minimum multiplier
%   AllpassCoefficients2 - Branch 2 coefficients, minimum multiplier
%   WDFCoefficients1     - Branch 1 coefficients, wave digital  
%   WDFCoefficients2     - Branch 2 coefficients, wave digital
%   HasPureDelayBranch   - Branch 1 is a delay
%   Delay                - Value of branch 1 delay, in samples
%   HasTrailingFirstOrderSection - Branch 2, last section is 1st order 
%   AllowArbitraryInputLength    - Allow arbitrary input length for fixed-size
%                                  signals in code generation
%
%   This System object supports several filter analysis methods. For
%   more information, type
%   dsp.IIRHalfbandDecimator.helpFilterAnalysis.
%
%   % Example 1: Decimate a signal and plot the spectra
%   
%   Fs = 5000; % Units: Hz
%   frameSize = 2000;
%   
%   SW = dsp.SineWave(Frequency=400, SampleRate=Fs, ...
%                     SamplesPerFrame=frameSize);
%   InputSA = spectrumAnalyzer(PlotAsTwoSidedSpectrum=false, ...
%                     SampleRate=Fs, ShowLegend=true, ...
%                     ChannelNames="Input");
%   OutputSA = spectrumAnalyzer(PlotAsTwoSidedSpectrum=false, ...
%                     SampleRate=Fs/2, ShowLegend=true, ...
%                     ChannelNames="Output");
%   
%   % Construct IIR Half band decimator
%   IIRHALFBANDDECIM = dsp.IIRHalfbandDecimator(...
%       Specification="Filter order and transition width",...
%       FilterOrder=15, TransitionWidth=400, ...
%       SampleRate=Fs);
%   
%   for idx=1:2000
%       Input = SW()+randn(frameSize,1);
%       Output = IIRHALFBANDDECIM(Input);
%       % Plot on scopes
%       InputSA(Input);
%       OutputSA(Output);
%   end
%   
%   % Example 2: Design a quasi-linear phase IIR halfband decimator and
%   % display its frequency response
%   
%   IIRHALFBANDDECIM = dsp.IIRHalfbandDecimator(...
%                       DesignMethod="Quasi-linear phase");
%   
%   % Obtain filter coefficients
%   c = coeffs(IIRHALFBANDDECIM);
%   
%   % Plot the Magnitude and Phase response
%   fvtool(IIRHALFBANDDECIM,Analysis="freq")
%
%   See also dsp.IIRHalfbandInterpolator, dsp.FIRHalfbandDecimator,
%            designHalfbandIIR, dsp.CoupledAllpassFilter

 
%   Copyright 2015-2023 The MathWorks, Inc.

    methods
        function out=IIRHalfbandDecimator
            % Support name-value pair arguments
        end

        function out=crossValidateProperties(~) %#ok<STOUT>
        end

        function out=getNumOutputsImpl(~) %#ok<STOUT>
        end

        function out=getOutputDataTypeImpl(~) %#ok<STOUT>
        end

        function out=getOutputSizeImpl(~) %#ok<STOUT>
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
        end

        function out=getTunablePropertiesSpecificationImpl(~) %#ok<STOUT>
        end

        function out=isDecimator(~) %#ok<STOUT>
        end

        function out=isFixedSizeOutput(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isOutputComplexImpl(~) %#ok<STOUT>
        end

        function out=isOutputFixedSizeImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=postProcessSampleRate(~) %#ok<STOUT>
        end

        function out=realizemdl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=supportsScalarVarsizeImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            % Number of input rows must be a multiple of 2 (the decimation
            % factor)
        end

        function out=validatePropertiesImpl(~) %#ok<STOUT>
        end

    end
    properties
        %AllowArbitraryInputLength Allow arbitrary frame length for fixed-size input signals
        %   When this flag is set to true, the fixed-size input signal can
        %   have a frame size that is not a multiple of the 2. This
        %   property applies only when the input is a fixed-size signal. If
        %   the size of the input signal varies during simulation
        %   (variable-size signal), this property does not apply. The
        %   default value is 'false' and has to be set to 'true' to process
        %   inputs with arbitrary frame lengths.
        AllowArbitraryInputLength;

        % SampleRate Input sample rate (Hz)
        %   Specify the sampling rate of the input in Hertz as a finite
        %   numeric scalar. the default is 44100 Hz.
        SampleRate;

        %TransitionWidth Transition width
        %   Specify the transition width for the designed IIR halfband
        %   filter as a finite positive scalar. Specify the value of
        %   transition width in Hertz when NormalizedFrequency is set to
        %   false and in normalized units when NormalizedFrequency is set
        %   to true. The transition width must be less than half the input
        %   sample rate. This property applies when the Specification is
        %   either 'Filter order and transition width' or 'Transition width
        %   and stopband attenuation'. The default value of this property
        %   is 4100 Hz.
        TransitionWidth;

        isBranch2CarryEmpty;

        % pSR Default sample rate
        pSR;

    end
end
