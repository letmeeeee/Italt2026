classdef FourthOrderSectionFilter< handle & dsp.internal.FourthOrderSectionFilterAnalysis & matlab.mixin.internal.indexing.Paren & matlab.mixin.SetGet
%FOURTHORDERSECTIONFILTER Implement cascade of fourth-order section
%filter.
%
%   FOS = dsp.FourthOrderSectionFilter returns a
%   FourthOrderSectionFilter object, FOS, that implements filter formed
%   of cascade of fourth order sections.
%
%   FOS = dsp.FourthOrderSectionFilter(Name=Value, ...) returns a
%   FourthOrderSectionFilter object, FOS, with each specified property
%   name set to the specified value. You can specify name-value pair
%   arguments in any order as (Name1=Value1,...,NameN=ValueN).
%
%   FOS = dsp.FourthOrderSectionFilter(NUM,DEN) returns a
%   FourthOrderSectionFilter object, FOS, with the Numerator property
%   set to NUM and Denominator property set to DEN.
%
%   Step method syntax:
%
%   Y = step(FOS, X) filters the real or complex input signal X using
%   the specified filter to produce the filtered output, Y. The filter
%   processes each channel of the input signal (each column of X)
%   independently over time.
%
%   dsp.FourthOrderSectionFilter object may be called directly like a
%   function instead of using the step method. For example, y =
%   step(obj, x) and y = obj(x) are equivalent.
%
%   FourthOrderSectionFilter methods:
%
%   step                          - See above description for use of
%                                   this method
%   release                       - Allow property value and input
%                                   characteristics changes
%   clone                         - Create FourthOrderSectionFilter
%                                   object with same property values
%   isLocked                      - Locked status (logical)
%   reset                         - Reset the internal states to
%                                   initial conditions
%
%   This object supports several filter analysis methods. For
%   more information, type
%   dsp.FourthOrderSectionFilter.helpFilterAnalysis.
%
%   FourthOrderSectionFilter properties:
%
%   Numerator   - Numerator coefficients of filter
%   Denominator - Denominator coefficients of filter
%
%   % EXAMPLE 1: Design a fourth-order section (FOS) filter and filter a
%   % sinusoid input signal
%   frameSize = 1024;
%   fs = 1000;
%   SINE1 = dsp.SineWave(5,100,SamplesPerFrame=1024,SampleRate=fs);
%   SINE2 = dsp.SineWave(2,350,pi/2,SamplesPerFrame=1024,...
%       SampleRate=fs);
%
%   % Create an input signal which is the sum of sinusoids
%   x = SINE1() + SINE2();
%
%   % FOS Numerator and Denominator coefficients are obtained using
%   % designParamEq which is part of Audio Toolbox:
%   %N = [2,4];
%   %gain = [5,10];
%   %centerFreq = [0.025,0.75];
%   %bandwidth = [0.025,0.35];
%   %mode = 'fos';
%   %[num,den] = designParamEQ(N,gain,centerFreq,bandwidth,mode);
%
%   num = [1.0223   -1.9368    0.9205         0         0
%          1.5171    2.3980    1.4317    0.6416    0.2752];
%
%   den = [-1.9368    0.9428         0         0
%           2.0136    1.9224    1.0260    0.3016];
%
%   % Construct FOS IIR filter
%   fos = dsp.FourthOrderSectionFilter(Numerator=num,...
%   Denominator=den);
%
%   % Construct a spectrum analyzer to visualize the original
%   % sinusoid signal and the filtered signal
%   scope = spectrumAnalyzer(...
%     SampleRate=fs,...
%     PlotAsTwoSidedSpectrum=false,...
%     Title="Original and Filtered Signals",...
%     ShowLegend=true,...
%     ChannelNames=["Original Signal","Filtered Signal"]);
%
%   % Filter the input signal, and visualize the original spectrum and
%   % filtered spectrum.
%   for idx = 1:10
%       y = fos(x);
%       scope([x,y]);
%   end
%
%   % Release the system object
%   release(scope);
%
%   % EXAMPLE 2: Design a lowpass fourth-order section (FOS) filter
%   % using fdesign and filter a sinusoid input signal
%
%   % Filter design parameters
%   N = 6; Fp = 0.5; Ap = 1; Ast = 60;
%
%   % Input Parameters
%   Fs = 44100;
%   FrameLength = 1024;
%
%   % Design a lowpass filter using fdesign
%   fdo = fdopts.sosscaling;
%   fdo.NumeratorConstraint='none';
%   fdo.ScaleValueConstraint='unit';
%
%   f = fdesign.lowpass("N,Fp,Ap,Ast",N,Fp,Ap,Ast,2);
%   hFilter = design(f,"ellip",SystemObject=true,...
%     FilterStructure="df2tsos",SOSScaleNorm="Linf",...
%      SOSScaleOpts=fdo);
%   sosV =  hFilter.SOSMatrix;
%
%   % Extract the Numerator and Denominator from SOS Matrix
%   num = zeros(size(sosV,1),5);
%   den = zeros(size(sosV,1),5);
%
%   for i = 1:size(sosV,1)
%      [num0,den0] = iirlp2bp(sosV(i,1:3),sosV(i,4:6),Fp,[0.25,0.75]);
%      num(i,1:length(num0)) = num0;
%      den(i,1:length(num0)) = den0;
%   end
%
%   % Create a fourth-order section filter
%   fos = dsp.FourthOrderSectionFilter(num,den);
%
%   TFE = dsp.TransferFunctionEstimator(FrequencyRange="onesided");
%   PLOTTER = dsp.ArrayPlot(PlotType="Line",...
%       XOffset=0,...
%       YLimits=[-120 5], ...
%       SampleIncrement=Fs/FrameLength,...
%       YLabel="Frequency Response (dB)",...
%       XLabel="Frequency (Hz)",...
%       Title="System Transfer Function");
%
%   SINE = dsp.SineWave(SamplesPerFrame=FrameLength);
%   for index=1:500
%       % Generate input
%       x = SINE() + randn(FrameLength,1);
%       % Pass input through the filter
%       y = fos(x);
%       % Transfer function estimation
%       H = TFE(x,y);
%       % plot transfer function
%       PLOTTER(20*log10(abs(H)))
%   end
%
%   % Release the system object
%   release(TFE);
%   release(PLOTTER);
%   release(SINE);
%
%   See also dsp.BiquadFilter

     
    % Copyright 2018-2021 The MathWorks, Inc.

    methods
        function out=FourthOrderSectionFilter
            % Accept as Name-Value or Value only arguments
        end

        function out=loadobj(~) %#ok<STOUT>
            % Create an instance of the class
        end

    end
    properties
        %Denominator Denominator coefficients of filter
        % Specify the denominator coefficients of size Lx4, or Lx5, where L
        % is the number of sections. The leading denominator coefficients
        % are assumed to be 1 always - if denominator is of size Lx4,
        % one(s) are appended to make the size Lx5. If the denominator is
        % of size Lx5, the first column values are ignored and appended
        % with one(s). The size of this property cannot be modified once
        % STEP method is called. However, the values can be modified. The
        % default value is [1 0.1 0.2 0.3 0.4].
        Denominator;

        %Numerator Numerator coefficients of filter
        % Specify the numerator coefficients of size Lx5, where L is the
        % number of sections. The size of this property cannot be modified
        % once STEP method is called. However, the values can be modified.
        % The default value is [1 0.1 0.2 0.3 0.4].
        Numerator;

    end
end
