classdef VariableBandwidthIIRFilter< dsp.internal.VariableBandwidthFilterBase
%VariableBandwidthIIRFilter Variable bandwidth IIR filter
%   VBIIR = dsp.VariableBandwidthIIRFilter returns a System object, VBIIR, 
%   which independently filters each channel of the input over time using
%   specified IIR filter specifications. The IIR filter's passband 
%   frequency may be tuned during the filtering operation. The IIR filter 
%   is designed using the elliptical method. The IIR filter is tuned using 
%   IIR spectral transformations based on allpass filters [1]. 
%
%   VBIIR = dsp.VariableBandwidthIIRFilter('Name', Value, ...) returns a 
%   Variable Bandwidth IIR Filter System object, VBIIR, with each specified 
%   property name set to the specified value. You can specify additional 
%   name-value pair arguments in any order as (Name1,Value1,...,NameN,
%   ValueN).
%
%   Step method syntax:
%
%   Y = step(VBIIR, X) filters the real or complex input signal X using the
%   specified filter to produce the output Y. The System object filters
%   each channel of the input signal independently over time.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   VariableBandwidthIIRFilter methods:
%
%   step          - See above description for use of this method
%   release       - Allow property value and input characteristics changes                      
%   clone         - Create Variable Bandwidth IIR Filter object with 
%                   same property values                      
%   isLocked      - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>         - Reset the internal states to initial conditions
%
%   VariableBandwidthIIRFilter properties:
%
%   SampleRate                   - Input sample rate
%   FilterType                   - IIR filter type
%   FilterOrder                  - IIR filter order
%   NormalizedFrequency          - Provide normalized frequencies for filter specifications
%   PassbandFrequency            - Filter passband frequency
%   CenterFrequency              - Filter center frequency
%   Bandwidth                    - Filter bandwidth
%   PassbandRipple               - Filter passband ripple
%   StopbandAttenuation          - Filter stopband attenuation
%
%   This System object supports several filter analysis methods. For more
%   information, type dsp.VariableBandwidthIIRFilter.helpFilterAnalysis
%
%   % Example: Filter a signal through a variable bandwidth bandpass IIR
%   % filter. Tune the center frequency and the bandwidth of the IIR filter. 
%   Fs = 44100; % Input sample rate
%   FrameLength = 1024;
%   % Define a bandpass variable bandwidth IIR filter:
%   VBIIR = dsp.VariableBandwidthIIRFilter(FilterType='Bandpass',...
%                                          FilterOrder=8,...
%                                          NormalizedFrequency=false,...
%                                          SampleRate=Fs,...
%                                          CenterFrequency=1e4,...
%                                          Bandwidth=4e3);
%   TFE = dsp.TransferFunctionEstimator('FrequencyRange','onesided');
%   PLOTTER = dsp.ArrayPlot(PlotType='Line',...
%                           XOffset=0,...
%                           YLimits=[-120 5], ...
%                           SampleIncrement=Fs/FrameLength,...
%                           YLabel='Frequency Response (dB)',...
%                           XLabel='Frequency (Hz)',...
%                           Title='System Transfer Function');
%   SINE = dsp.SineWave(SamplesPerFrame=FrameLength);
%   for index=1:500
%      % Generate input
%      x = SINE() + randn(FrameLength,1);
%      % Pass input through the filter
%      y = VBIIR(x);
%      % Transfer function estimation
%      H = TFE(x,y);
%      % plot transfer function
%      PLOTTER(20*log10(abs(H)))   
%      % Tune bandwidth and center frequency of the IIR filter
%      if (index==250)
%        VBIIR.CenterFrequency = 5000;
%        VBIIR.Bandwidth = 2000;
%      end
%   end
%
%   See also dsp.VariableBandwidthFIRFilter, dsp.FIRFilter, dsp.IIRFilter, 
%            dsp.BiquadFilter, dsp.SOSFilter, dsp.AllpoleFilter

 
%   Copyright 2013-2022 The MathWorks, Inc.

    methods
        function out=VariableBandwidthIIRFilter
            % Constructor
        end

        function out=crossValidateProperties(~) %#ok<STOUT>
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
            % Modify order of display
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=newpoly(~) %#ok<STOUT>
            % Compute new polynomial after substitution
            % For each coefficient, we will have a resulting polynomial after we
            % substitute, form each polynomial and then add them all up to compute
            % the new numerator or denominator.
        end

        function out=polyallpasssub(~) %#ok<STOUT>
            %POLYALLPASSSUB   Substitute delays in polynomials with allpass filters. 
            % Remove possible trailing zeros and get polynomial lengths
        end

        function out=polypow(~) %#ok<STOUT>
            %POLYPOW   Evaluate polynomial to power of N. 
            % Initialize recursion
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
            % Tune the filter coefficients
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
            % Invoke setupImpl method of base class
        end

        function out=stepImpl(~) %#ok<STOUT>
            % step the IIR filter
        end

        function out=transformSOSSection(~) %#ok<STOUT>
            % Transform each SOS section
        end

        function out=tuneCoefficients(~) %#ok<STOUT>
        end

        function out=validateFrequencyRange(~) %#ok<STOUT>
            % PassbandFrequency must be less than SampleRate/2
            % This method is invoked in validatePropertiesImpl of the base class
        end

    end
    properties
        % FilterOrder IIR filter order
        %   Specify the order of the IIR filter as a positive integer scalar. The 
        %   default is 8.
        FilterOrder;

        % PassbandFrequency Filter passband frequency
        %   Specify the filter passband frequency as a real, positive scalar less
        %   than SampleRate/2. This property applies when you set the FilterType
        %   property to 'Lowpass' or 'Highpass'. Specify the value of passband
        %   frequency in Hertz when you set NormalizedFrequency to false, and set
        %   the value in normalized units when you set NormalizedFrequency to
        %   true. The default is 512 Hz. This property is tunable.
        PassbandFrequency;

        % PassbandRipple Filter passband ripple (dB)
        %   Specify the filter passband ripple as a real, positive scalar in 
        %   decibels (dB). The default is 1 dB.
        PassbandRipple;

        % StopbandAttenuation Filter Stopband attenuation (dB)
        %   Specify the filter stopband attenuation as a real, positive scalar in 
        %   decibels (dB). The default is 60 dB.
        StopbandAttenuation;

    end
end
