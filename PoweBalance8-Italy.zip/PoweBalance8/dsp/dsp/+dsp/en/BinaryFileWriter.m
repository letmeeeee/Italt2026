classdef BinaryFileWriter< matlab.System
% BinaryFileWriter Write binary files
%   writer = dsp.BinaryFileWriter returns a System object, writer, that
%   writes data to binary files. 
%
%   writer = dsp.BinaryFileWriter('Name', Value, ...) returns a binary file
%   writer System object, writer, with each specified property name set to
%   the specified value. You can specify name-value pair arguments in any
%   order.
%
%   writer = dsp.BinaryFileWriter(Name,'PropertyName', PropertyValue, ...)
%   returns a binary file writer object, writer, with the Filename property
%   set to Name, and other properties set to the specified values.
%
%   Step method syntax:
%
%   step(writer,data) writes data to the binary file. 
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, step(obj, x) and obj(x) are equivalent.
%
%   BinaryFileWriter methods:
%
%   step                     - See above description for use of this method
%   release                  - Allow property value and input 
%                              characteristics changes, and release binary  
%                              file writer resources
%   clone                    - Create file writer object with same property 
%                              values
%   isLocked                 - Display locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>                    - Reset to the beginning of the file
%
%   BinaryFileWriter properties:
%
%   Filename            - Name of the file to which to write data
%   HeaderStructure     - Header to write at the beginning of the file
%
%   % EXAMPLE: Create a binary file with a custom header using a 
%   % dsp.BinaryFileWriter System object. Read the header and data from the
%   % file using a dsp.BinaryFileReader System object. 
%   % Specify the file header. 
%   header = struct('A',[1 2 3 4],'B','x7');
%   writer = dsp.BinaryFileWriter('ex_file.bin','HeaderStructure',header);
%  
%   % Write data to file. The header is automatically written before data 
%   % is written.
%   data = sin(2 * pi * (0:1000-1) / 500).' + 0.01 * randn(1000,1);
%   writer(data);
%   release(writer);
% 
%   headerPrototype = struct('A',[0 0 0 0],'B','-0');
%   L = 150;
%   reader = dsp.BinaryFileReader(...
%                   'ex_file.bin','HeaderStructure',headerPrototype,...
%                   'NumChannels',1,'SamplesPerFrame',L);
%   out = zeros(ceil(1000/L) * L,1);
%   % Read header data from the file:
%   header = readHeader(reader);
%   fprintf('header.A: ')
%   fprintf('%d ',header.A)
%   fprintf('\nheader.B: ')
%   fprintf('%s ',header.B)
%   fprintf('\n');
%   index = 1;
%   % Read data until EOF is reached:
%   while ~isDone(reader)
%      out((index-1)*L + 1:index*L,:) = reader();
%      index = index + 1;
%   end
%   release(reader)
%   plot(data,'b-','LineWidth',4)
%   hold on;
%   grid on;
%   plot(out(1:1000),'ro-')
%   legend('Original data', 'Data read from file')
%   xlabel('Index')
%   ylabel('Data')
%
% See also: dsp.BinaryFileReader, dsp.MatFileReader, dsp.MatFileWriter

 
% Copyright 2016-2021 The MathWorks, Inc.

    methods
        function out=BinaryFileWriter
        end

        function out=getPrecision(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Call base class method
        end

        function out=releaseImpl(~) %#ok<STOUT>
            % Write data in buffer
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Default implementation saves all public properties
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

    end
    properties
        %Filename File name
        %   Specify the name of the binary file as a character vector. The
        %   full path for the file needs to be specified only if the file
        %   is not on the MATLAB path. The default value of this property
        %   is 'Untitled.bin'.
        Filename;

        %HeaderStructure File header
        % Set this property if you want to write a header to the file prior
        % to the data.  Specify the header as a scalar structure. Each
        % field of the structure must be a matrix of a built-in type. For
        % example, if HeaderStructure is set to
        % struct('field1',1:10,'field2',single(1)), the object will write a
        % header formed of 10 double-precision values, (1:10), followed by
        % one single-precision value, single(1). The default is struct([]).
        HeaderStructure;

    end
end
