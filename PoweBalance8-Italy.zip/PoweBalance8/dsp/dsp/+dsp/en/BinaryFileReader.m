classdef BinaryFileReader< matlab.System
% BinaryFileReader Read binary files
%   reader = dsp.BinaryFileReader returns a System object, reader, that
%   reads binary files. 
%
%   reader = dsp.BinaryFileReader('Name', Value, ...) returns a binary file
%   reader System object, reader, with each specified property name set to
%   the specified value. You can specify name-value pair arguments in any
%   order as (Name1,Value1,...,NameN, ValueN).
%
%   reader = dsp.BinaryFileReader(Name,'PropertyName', PropertyValue, ...)
%   returns a binary file reader object, reader, with the Filename property
%   set to Name, and other properties set to the specified values.
%
%   Step method syntax:
%
%   data = step(reader) reads data from the binary file. The dimensions,
%   complexity, and datatype of data are determined by the property
%   settings of the object.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj) and y = obj() are
%   equivalent.
%
%   BinaryFileReader methods:
%
%   step                     - See above description for use of this method
%   release                  - Allow property value and input 
%                              characteristics changes, and release binary 
%                              file reader resources
%   clone                    - Create file reader object with same property 
%                              values
%   isLocked                 - Display locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>                    - Reset to the beginning of the file
%   isDone                   - Returns true if object has read beyond the 
%                              end-of-file
%   readHeader               - Read file header
%
%   BinaryFileReader properties:
%
%   Filename            - Name of the file from which to read data
%   HeaderStructure     - Structure of the header at the beginning of the
%                         file
%   SamplesPerFrame     - Number of rows in the output matrix
%   NumChannels         - Number of columns in the output matrix 
%   DataType            - Output datatype
%   IsDataComplex       - Specify data complexity
%
%   % EXAMPLE: Create a binary file with a custom header using a 
%   % dsp.BinaryFileWriter System object. Read the header and data from the
%   % file using a dsp.BinaryFileReader System object. 
%   % Specify the file header. 
%   header = struct('A',[1 2 3 4],'B','x7');
%   writer = dsp.BinaryFileWriter('ex_file.bin','HeaderStructure',header);
%  
%   % Write data to file. The header is automatically written before the
%   % data is written.
%   data = sin(2 * pi * (0:1000-1) / 500).' + 0.01 * randn(1000,1);
%   writer(data);
%   release(writer);
% 
%   % Knowledge of the header structure is assumed:
%   headerPrototype = struct('A',[0 0 0 0],'B','-0');
%   L = 150;
%   reader = dsp.BinaryFileReader(...
%                                'ex_file.bin',...
%                                'HeaderStructure',headerPrototype,...
%                                'NumChannels',1,'SamplesPerFrame',L);
%   out = zeros(ceil(1000/L) * L,1);
%   % Read header data from the file:
%   header = readHeader(reader);
%   fprintf('header.A: ')
%   fprintf('%d ',header.A)
%   fprintf('\nheader.B: ')
%   fprintf('%s ',header.B)
%   fprintf('\n');
%   index = 1;
%   % Read data until EOF is reached:
%   while ~isDone(reader)
%      out((index-1)*L + 1:index*L,:) = reader();
%      index = index + 1;
%   end
%   release(reader)
%   plot(data,'b-','LineWidth',4)
%   hold on;
%   grid on;
%   plot(out(1:1000),'ro')
%   legend('Original data', 'Data read from file')
%   xlabel('Index')
%   ylabel('Data')
%
% See also: dsp.BinaryFileWriter, dsp.MatFileReader, dsp.MatFileWriter

 
% Copyright 2016-2021 The MathWorks, Inc.

    methods
        function out=BinaryFileReader
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
            % Modify order of display
        end

        function out=getStructSize(~) %#ok<STOUT>
        end

        function out=isDone(~) %#ok<STOUT>
            % isDone  True if reader has reached end-of-file
            %
            % isDone(READER) returns true if the binary file reader, READER, has
            % reached the end of the file
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Call base class method
        end

        function out=readHeader(~) %#ok<STOUT>
            % readHeader Read the file header
            %
            % S = readHeader(reader) returns the header structure, S, from the
            % file specified by the binary file reader, reader.  
            %
            % % Example
            % % Write a binary file
            % fid = fopen('myfile.dat','w');
            % % First, write a header. In this example, the header is a 1-by-4
            % % matrix  of double precision values, followed by a 5-by-1 
            % % vector of single-precision values: 
            % fwrite(fid,[1 2 3 4],'double');
            % fwrite(fid,single((1:5).'),'single');
            % % Write data
            % fwrite(fid,(1:1000).','double');
            % fclose(fid);
            % % Read the header using a dsp.BinaryFileReader object
            % reader = dsp.BinaryFileReader('myfile.dat');
            % % Specify the expected header structure:
            % s = struct('A',[0 0 0 0],'B',ones(5,1,'single'));
            % reader.HeaderStructure = s;
            % H = readHeader(reader);
            % fprintf('H.A: ')
            % fprintf('%d ',H.A);
            % fprintf('\nH.A datatype: %s\n',class(H.A))
            % fprintf('H.B: ')
            % fprintf('%d ',H.B);
            % fprintf('\nH.B datatype: %s\n',class(H.B))
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=resolveFileName(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Default implementation saves all public properties
        end

        function out=setupHeaderStruct(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

    end
    properties
        %DataType Storage data type
        % Specify the storage class of the data in the file as
        % 'double','single','int8','int16','int32','int64', 'uint8',
        % 'uint16','uint32' or 'uint64'. This property defines the datatype
        % of the matrix returned by the step method. The default is
        % 'double'.
        DataType;

        %Filename File name
        %   Specify the name of the binary file as a character vector. 
        %   The full path for the file needs to be specified only if the 
        %   file is not on the MATLAB path. The default value of this 
        %   property is 'Untitled.bin'.
        Filename;

        % HeaderStructure Header structure 
        % Set this property if the data in the binary file is preceded by a
        % header. Specify the header as a scalar structure. Each field of
        % the structure must be a matrix of a built-in type. For example,
        % if HeaderStructure is set to
        % struct('field1',1:10,'field2',single(1)), the object assumes that
        % the header is formed by 10 real double-precision values followed
        % by one single-precision value. You can retrieve the header from
        % the file by calling the readHeader method. The default is
        % struct('Field1',[]).
        HeaderStructure;

        % IsDataComplex Data is complex
        % If the data stored in the file is complex, set this property to
        % true. Otherwise, set it to false. The default is false.
        IsDataComplex;

        %NumChannels Number of channels
        % Specify the number of columns of the output matrix returned by
        % step. This property defines the number of consecutive interleaved
        % data samples stored in the file for each time instant. The
        % default is 1.
        NumChannels;

        %SamplesPerFrame Samples per frame
        % Specify the number of rows of the output matrix, data, returned
        % by step. The size of data is SamplesPerFrame-by-NumChannels. Once
        % the file reaches the end, if data is not full, the object fills
        % data with zeros to make it a fully-sized matrix.
        SamplesPerFrame;

        % Saved value of the file identifier
        pFID;

        % pFilename Cache file name
        pFilename;

        pIndex;

        % pIsDone True if there are no more samples in the file
        pIsDone;

        pNumFrames;

    end
end
