classdef CICCompensationInterpolator< dsp.internal.CICCompensationBase
%CICCompensationInterpolator Compensate for CIC filter using an FIR 
%                            interpolator
%   The shortcomings of a CIC interpolator, namely its passband droop and
%   wide transition region, can be compensated by preceding it with a
%   compensation interpolator. This System object provides the ability to
%   design and use such a compensator for the CIC filter.
%   
%   CFIR = dsp.CICCompensationInterpolator returns a System object, CFIR,
%   that applies a FIR interpolator to each channel of the input signal.
%   Using the properties of the object, the interpolation filter can be
%   designed to compensate for a subsequent CIC filter.
%   
%   CFIR = dsp.CICCompensationInterpolator('Name', Value, ...) returns a
%   CIC compensation interpolator System object, CFIR, with each specified
%   property set to the specified value.
%   
%   CFIR = dsp.CICCompensationInterpolator(INTERP,'Name',Value,...) returns
%   a CIC compensation interpolator System object, CFIR, with the
%   InterpolationFactor property set to INTERP, and other specified
%   properties set to the specified values.
%
%   CFIR = dsp.CICCompensationInterpolator(CICINTERP, 'Name', Value, ...)
%   returns a CIC compensation interpolator System object, CFIR, with the
%   CICRateChangeFactor, CICNumSections and CICDifferentialDelay properties
%   set using their corresponding values in the dsp.CICInterpolator System
%   object CICINTERP, and other specified properties set to the specified
%   values.
%
%   CFIR = dsp.CICCompensationInterpolator(CICINTERP, INTERP, 'Name',
%   Value, ...) returns a CIC compensation interpolator System object,
%   CFIR, with the CICRateChangeFactor, CICNumSections and
%   CICDifferentialDelay properties set using their corresponding values in
%   the dsp.CICInterpolator System object CICINTERP, the
%   InterpolationFactor property set to INTERP, and other specified
%   properties set to the specified values.
%
%   Step method syntax:
%
%   Y = step(CFIR, X) outputs the upsampled and filtered values, Y,
%   of the input signal X. A KixN input matrix is treated as N independent
%   channels, and the System object interpolates each channel over the
%   first dimension and generates a KoxN output matrix. Ko = Ki*L where L
%   is the interpolation factor. The object supports real and complex
%   floating-point and fixed-point inputs, except for complex unsigned
%   fixed-point inputs.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   CICCompensationInterpolator methods:
%
%   step      - See above description for use of this method
%   release   - Allow property value and input characteristics changes
%   clone     - Create CIC compensation interpolator object with same 
%               property values
%   isLocked  - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>     - Reset the internal states to initial conditions
% generatehdl - Generate HDL code. (Filter Design HDL Coder Required)
%
%   CICCompensationInterpolator properties:
%
%   SampleRate            - Input sample rate
%   InterpolationFactor   - Interpolation factor
%   CICRateChangeFactor   - Rate change factor of the CIC filter to be
%                           compensated
%   CICNumSections        - Number of sections of the CIC filter to be
%                           compensated
%   CICDifferentialDelay  - Differential delay of the CIC filter to be
%                           compensated
%   DesignForMinimumOrder - Option to have a minimum order design for the
%                           filter in compensation interpolator
%   FilterOrder           - Order of the filter in compensation 
%                           interpolator
%   PassbandFrequency     - Passband frequency of compensation filter
%   StopbandFrequency     - Stopband frequency of compensation filter
%   PassbandRipple        - Allowed passband ripple of compensation filter
%   StopbandAttenuation   - Minimum attenuation needed in stopband of
%                           compensation filter
%
%   This System object supports several filter analysis methods. For more
%   information, type dsp.CICCompensationInterpolator.helpFilterAnalysis.
%
%   This System object supports fixed-point operations. For more
%   information, type dsp.CICCompensationInterpolator.helpFixedPoint.
%
%   % EXAMPLE: Design a compensation interpolator for an existing CIC 
%   % interpolator and visualize the frequency response of the cascade. Use
%   % it on a sample input.
%   
%   % CONSTRUCTION
%   cicinterp = dsp.CICInterpolator(InterpolationFactor = 16, ...
%                                   NumSections = 6);
%   fs = 600;      % Sampling frequency of input of compensation
%                  % interpolator
%   fPass = 100;   % Passband frequency
%   fStop = 250;   % Stopband frequency
%   ast = 80;      % Minimum attenuation of alias components in stopband
%   cfir = dsp.CICCompensationInterpolator(cicinterp, ...
%               InterpolationFactor= 2, ...
%               PassbandFrequency= fPass, ...
%               StopbandFrequency= fStop, ...
%               StopbandAttenuation= ast, ...
%               SampleRate= fs);
%   
%   % FREQUENCY RESPONSE
%   % Next, visualize the cascade frequency response.
%
%   filtcasc = dsp.FilterCascade(cfir, cicinterp);
%   f = fvtool(cfir, cicinterp, filtcasc, ...
%             'Fs', [fs*2, fs*16*2, fs*16*2], 'Arithmetic', 'fixed');
%   set(f, 'NormalizeMagnitudeto1', 'on');
%   legend(f,'CIC Compensation Interpolator','CIC Interpolator', ...
%          'Overall Response');
%
%   % STEP
%   sigsource = dsp.SignalSource(fi(rand(1000,1),1,16,15), ...
%                                SamplesPerFrame = 100);
%   y = fi(zeros(0,1), 1, 32, 20);
%   for ind = 1:10
%       x2 = cfir(sigsource() );
%       y = [y; cicinterp(x2)];
%   end

 
%   Copyright 2013-2022 The MathWorks, Inc.

    methods
        function out=CICCompensationInterpolator
        end

        function out=crossValidateProperties(~) %#ok<STOUT>
        end

        function out=designFilter(~) %#ok<STOUT>
            % Create interpolator System object
        end

        function out=getHeaderImpl(~) %#ok<STOUT>
            % MATLAB System block header
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
        end

        function out=helpFixedPoint(~) %#ok<STOUT>
            %helpFixedPoint Display CICCompensationInterpolator System
            %               object fixed-point information
            %   dsp.CICCompensationInterpolator.helpFixedPoint displays
            %   information about fixed-point properties and operations of
            %   the CICCompensationInterpolator System object.
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=postProcessSampleRate(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
            % Release the interpolator object. This allows users to
            % subsequently modify non-tunable properties and call the step
            % method with a different input datatype, different frame size,
            % or a different number of channels.
        end

        function out=resetImpl(~) %#ok<STOUT>
            % Reset the states of interpolator object
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
            % Interpolate the input by the specified interpolation factor
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            % Verify input to the step function
        end

        function out=validatePropertiesImpl(~) %#ok<STOUT>
            % Verify the values of properties before designing filter
        end

    end
    properties
        %InterpolationFactor Interpolation factor
        %   Specify a positive integer amount by which the input signal
        %   will be interpolated. The default value of this property is 2.
        InterpolationFactor;

        %PassbandFrequency  Passband edge frequency (Hz)
        %   Specify the passband edge frequency of the compensation filter
        %   in Hertz, as a positive real scalar smaller than half the
        %   output sample rate. The default value of this property is
        %   100000 Hz.
        PassbandFrequency;

        % SampleRate Input sample rate (Hz)
        %   Specify the sampling rate of the input in Hertz as a finite
        %   numeric scalar. the default is 600 KHz.
        SampleRate;

        %StopbandFrequency  Stopband edge frequency (Hz)
        %   Specify the stopband edge frequency of the compensation filter
        %   in Hertz, as a positive real scalar smaller than half the
        %   output sample rate. This property applies when you set the
        %   DesignForMinimumOrder property to true. The default value of
        %   this property is 400000 Hz.
        StopbandFrequency;

        pFIRInterpolator;

        pSR;

    end
end
