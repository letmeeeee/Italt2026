classdef MovingStandardDeviation< dsp.internal.AbstractMovingStatistic
%   MovingStandardDeviation Compute moving standard deviation
%   MSTD = dsp.MovingStandardDeviation returns a System object, MSTD, that
%   computes the moving standard deviation of the input signal.
%
%   MSTD = dsp.MovingStandardDeviation(Name=Value, ...) returns a moving
%   standard deviation System object, MSTD, with each specified property
%   name set to the specified value. You can specify additional name-value
%   pair arguments in any order as (Name1=Value1,...,NameN=ValueN).
%
%   MSTD = dsp.MovingStandardDeviation(Length, Overlap, PropertyName=
%   PropertyValue, ...) returns a moving standard deviation object, MSTD,
%   with the WindowLength property set to Length, OverlapLength property
%   set to Overlap, and other properties set to the specified values.
%
%   Step method syntax:
%
%   Y = step(MSTD, X) computes the moving standard deviation, Y, of the
%   real or complex input X. Each column of X is a channel. The System
%   object computes the moving standard deviation of each channel of the
%   input signal independently over time.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   MovingStandardDeviation methods:
%
%   step                     - Compute moving standard deviation of input
%   release                  - Allow property value and input
%                              characteristics changes, and release moving
%                              average resources
%   clone                    - Create moving standard deviation object with
%                              same property values
%   isLocked                 - Display locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>                    - Reset the states of the moving standard
%                              deviation
%
%   MovingStandardDeviation properties:
%
%   Method                  - Averaging method
%   SpecifyWindowLength     - Choose to specify sliding window length
%   WindowLength            - Sliding window length
%   OverlapLength           - Overlap length between windows
%   ForgettingFactor        - Exponential weighting forgetting factor
%
%   % EXAMPLE: Compute the moving standard deviation of Gaussian noise with
%   %          varying power. Use a sliding window variance of length 1000,
%   %          an exponentially weighted variance with forgetting factor
%   %          of 0.999, and a sliding window variance of length 1000 with
%   %          an overlap of 900 samples.
%   FrameLength = 100;
%   Fs = 100;
%   mstd_slide    = dsp.MovingStandardDeviation(1000);
%   mstd_forget   = dsp.MovingStandardDeviation(...
%                                     Method='Exponential weighting',...
%                                     ForgettingFactor=0.999);
%   mstd_overlap  = dsp.MovingStandardDeviation(1000,900);
%   scope  = timescope(SampleRate=[Fs,Fs,Fs,Fs/(1000-900)],...
%                      TimeSpanSource='property',...
%                      TimeSpan=1.5e3,ShowGrid=true,...
%                      YLimits=[0 3e-2]);
%   title = 'Moving Standard Deviation';
%   scope.Title = title;
%   scope.ChannelNames = {'Original Signal',...
%       'Sliding window of 1000 samples with default overlap',...
%       'Exponential weighting with forgetting factor of 0.999',...
%       'Sliding window of 1000 samples with overlap of 900 samples'};
%   count = 1;
%   noisePower = 1e-4 * [(1:5) (5:-1:1)];
%   index = 1;
%   for index = 1:length(noisePower)
%     np = noisePower(index);
%     yexp = sqrt(np) * ones(FrameLength,1);
%     for frameIdx = 1:150
%       x  = sqrt(np) * randn(FrameLength,1);
%       y1 = mstd_slide(x);
%       y2 = mstd_forget(x);
%       y3 = mstd_overlap(x);
%       scope(yexp,y1,y2,y3);
%     end
%   end
%
%   See also dsp.MovingAverage, dsp.MovingRMS, dsp.MovingVariance,
%   dsp.MovingMinimum, dsp.MovingMaximum

 
%   Copyright 2016-2023 The MathWorks, Inc.

    methods
        function out=MovingStandardDeviation
            % Constructor
        end

        function out=getHeaderImpl(~) %#ok<STOUT>
            % MATLAB System block header
        end

        function out=getIconImpl(~) %#ok<STOUT>
        end

        function out=getStatisticObject(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

    end
    properties
        % Method Method
        % Specify the averaging method as one of 'Sliding window' or
        % 'Exponential weighting'.
        % In the sliding window method, the object computes the moving
        % standard deviation by sliding a window along the input. When
        % SpecifyWindowLength is true, the sliding window length is equal
        % to the value of the WindowLength property. When
        % SpecifyWindowLength is false, the sliding window is of infinite
        % length. In this mode, the variance is computed for the current
        % sample and all past samples).
        % In the exponential weighting method, the object computes the
        % standard deviation over samples weighted by an exponentially
        % decaying forgetting factor.
        % The default is 'Sliding window'.
        Method;

    end
end
