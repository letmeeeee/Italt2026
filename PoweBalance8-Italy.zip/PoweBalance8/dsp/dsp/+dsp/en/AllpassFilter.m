classdef AllpassFilter< matlab.System & dsp.internal.FilterAnalysis
%AllpassFilter Single-section or cascaded allpass filter with
%   Minimum-multiplier, Lattice, or Wave Digital structure
%
%   APF = dsp.AllpassFilter returns an allpass filter APF that filters
%   each channel of the input signal independently using an allpass
%   filter with the default structure and coefficients.
%
%   APF = dsp.AllpassFilter('PropertyName', PropertyValue, ...) returns
%   an allpass filter, APF, with each specified property set to a
%   specified value.
%
%   Step method syntax:
%
%   Y = step(APF, X) filters the real or complex input signal X using
%   the specified filter to produce the output Y. Each column of X is
%   treated and filtered independently as a separate channel over time.
%
%   System objects may be called directly like a function instead of
%   using the step method. For example, y = step(obj, x) and y = obj(x)
%   are equivalent.
%
%   AllpassFilter methods:
%
%   step                - See above description for use of this method.
%   release             - Allow changes to non-tunable properties
%                         values and input characteristics.
%   clone               - Create an allpass filter object with the same
%                         property values and internal states.
%   isLocked            - Locked status (logical).
%   <a href="matlab:help matlab.System/reset   ">reset</a>               - Reset the internal states to initial
%                         conditions.
%
%   AllpassFilter properties:
%
%   Structure                 - Internal allpass filter structure.
%   AllpassCoefficients       - Coefficients used with 'Minimum
%                               multiplier' structure.
%   LatticeCoefficients       - Coefficients used with 'Lattice'
%                               structure.
%   WDFCoefficients           - Coefficients used with the 'Wave Digital
%                               Filter' structure.
%   TrailingFirstOrderSection - Is the last section first order.
%
%   This filter supports several filter analysis methods. For more
%   information, type dsp.AllpassFilter.helpFilterAnalysis.
%
%   % EXAMPLE: Implement a lowpass filter using two allpass filters.
%
%     Fs  = 48000;    % in Hz
%     FL = 1024;
%     apfilt1 = dsp.AllpassFilter('AllpassCoefficients',...
%                        [-0.710525516540603   0.208818210000029]);
%     apfilt2 =  dsp.AllpassFilter('AllpassCoefficients',...
%                        [-0.940456403667957   0.6;...
%                         -0.324919696232907   0],...
%                         'TrailingFirstOrderSection',true);
%     tfestim = dsp.TransferFunctionEstimator('FrequencyRange',...
%           'onesided','SpectralAverages',2);
%     scope = dsp.ArrayPlot('PlotType','Line','YLimits', [-80 5],...
%         'YLabel','Magnitude (dB)','SampleIncrement', Fs/FL,...
%         'XLabel','Frequency (Hz)','Title','Magnitude Response',...
%         'ShowLegend', true);
%     tic;
%     while toc < 5
%         in  = randn(FL,1);
%         out = 0.5.*(apfilt1(in) + apfilt2(in));
%         A = tfestim(in, out);
%         scope(db(A));
%     end
%
%   See also dsp.CoupledAllpassFilter, dsp.BiquadFilter, dsp.IIRFilter,
%   dsp.IIRHalfbandInterpolator, dsp.IIRHalfbandDecimator.

 
    %   Copyright 2012-2023 The MathWorks, Inc.

    methods
        function out=AllpassFilter
            % Support name-value pair arguments
        end

        function out=convertToDFILT(~) %#ok<STOUT>
            % Returns equivalent dfilt to current object.
        end

        function out=infoImpl(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=isInputSizeMutableImpl(~) %#ok<STOUT>
            % Support mutable input size
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Re-load state if saved version was locked
        end

        function out=poly2wdf(~) %#ok<STOUT>
            %poly2wdf Converts standard single-section allpass polynomial
            % coefficients into Wave Digital Filter form.
            % Acceptable section orders are 1, 2 and 4. If the order is 4
            % then the first and third coefficients must be zeros.
            %
            %   % EXAMPLE: Convert a single-section dsp.AllpassFilter with
            %   % Minimum multiplier structure into an equivalent Wave
            %   % Digital Filter form
            %
            %   hReference = dsp.AllpassFilter(...
            %       'AllpassCoefficients', [0.1 0.2]);
            %   cPolycoeffs = hReference.AllpassCoefficients;
            %   wdfcoeffs = dsp.AllpassFilter.poly2wdf(cPolycoeffs{1});
            %   hWDFVersion = dsp.AllpassFilter(...
            %     'Structure', 'Wave Digital Filter', ...
            %     'WDFCoefficients', wdfcoeffs);
            %   % Display both filters in fvtool and verify all main
            %   % responses are equal
            %   fvtool(hReference, hWDFVersion)
            %
            % Reference:
            % M. Lutovac, D. Tosic, B. Evans.
            % Filter Design for Signal Processing using MATLAB and
            % Mathematica. Prentice Hall, 2001.
        end

        function out=processTunedPropertiesImpl(~) %#ok<STOUT>
        end

        function out=releaseImpl(~) %#ok<STOUT>
        end

        function out=resetImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
            % Default implementation saves all public properties
        end

        function out=setPrivFilter(~) %#ok<STOUT>
        end

        function out=setupImpl(~) %#ok<STOUT>
        end

        function out=stepImpl(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            % Invoked at first call to setup/step, and then every time the
            % input dimensions change
        end

        function out=wdf2poly(~) %#ok<STOUT>
            %wdf2poly Converts single-section Wave Digital Filter allpass
            % coefficients into standard polynomial form.
            % Acceptable section orders are 1, 2 and 4. If the order is 4
            % then the second and fourth coefficients must be zeros.
            %
            %   % EXAMPLE: Convert a single-section dsp.AllpassFilter with
            %   % Wave Digital Filter structure into an equivalent Minimum
            %   % multiplier form.
            %
            %   hReference = dsp.AllpassFilter(...
            %       'Structure', 'Wave Digital Filter', ...
            %       'WDFCoefficients', [0.1 0.2]);
            %   cWdfcoeffs = hReference.WDFCoefficients;
            %   polycoeffs = dsp.AllpassFilter.wdf2poly(cWdfcoeffs{1});
            %   hMMVersion = dsp.AllpassFilter(...
            %       'AllpassCoefficients', polycoeffs);
            %   % Display both filters in fvtool and verify all main
            %   % responses are equal
            %   fvtool(hReference, hMMVersion)
            %
            % Reference:
            % M. Lutovac, D. Tosic, B. Evans.
            % Filter Design for Signal Processing using MATLAB and
            % Mathematica. Prentice Hall, 2001.
        end

    end
    properties
        %AllpassCoefficients Allpass polynomial coefficients
        %   Specify the real allpass polynomial filter coefficients. This
        %   property is only applicable when the Structure property is set
        %   to 'Minimum multiplier'. The value of this property can be
        %   either a Nx1 or Nx2 matrix of N first or second-order allpass
        %   sections. The default value for this property is [-2^(-1/2)
        %   0.5]. This property is tunable.
        AllpassCoefficients;

        %LatticeCoefficients Lattice allpass coefficients
        %   Specify the real or complex allpass coefficients as lattice
        %   reflection coefficients form. This property is only applicable
        %   when the Structure property is set to 'Lattice'. The value of
        %   this property can be either a row vector  or a column vector.
        %   The default value for this property is [-2^(1/2)/3, 1/2]. This
        %   property is tunable.
        LatticeCoefficients;

        %Structure Internal allpass structure
        %   Specify the internal allpass filter implementation structure as
        %   one of {'Minimum multiplier' | 'Wave Digital Filter' |
        %   'Lattice'}. Each structure uses a different coefficients set,
        %   independently stored in the corresponding object property. The
        %   default is 'Minimum multiplier'.
        Structure;

        %TrailingFirstOrderSection Indicate if last section is first order
        %   For the minimum-multiplier or wave digital structure, specify
        %   whether the last section is a first order section (true) or
        %   whether it is a second order section (false). When set to true,
        %   the second element of the last row of the N-by-2 matrix is
        %   ignored. The default is false.
        TrailingFirstOrderSection;

        %WDFCoefficients Wave Digital Filter allpass coefficients
        %   Specify the real allpass coefficients in Wave Digital Filter
        %   form. This property is only applicable when the Structure
        %   property is set to 'Wave Digital Filter'. The value of this
        %   property can be either a Nx1 or Nx2 matrix of N first or
        %   second-order allpass sections.  All elements must have absolute
        %   value <= 1. The default value for this property is [1/2,
        %   -2^(1/2)/3].
        WDFCoefficients;

    end
end
