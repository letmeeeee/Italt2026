classdef (StrictDefaults)MatFileReader < matlab.System & matlab.system.mixin.FiniteSource
    %MatFileReader File reader
    %   Reader = dsp.MatFileReader returns a System object, Reader, that
    %   reads MAT files.
    %
    %   Reader = dsp.MatFileReader('PropertyName', PropertyValue, ...)
    %   returns a file reader object, Reader, with each specified property
    %   set to the specified value.
    %
    %   Reader = dsp.MatFileReader(FILENAME, VARIABLENAME, SAMPLESPERFRAME,
    %   'PropertyName', PropertyValue, ...) returns a file reader object,
    %   Reader, with the Filename property set to FILENAME, the
    %   VariableName property set to VARIABLENAME, the SamplesPerFrame
    %   property set to SAMPLESPERFRAME, and other properties set to the
    %   specified values.
    %
    %   Step method syntax:
    %
    %   X = step(Reader) reads data, X, from a variable stored in a
    %   MAT-file. The variable is assumed to be N-dimensional and a MATLAB
    %   built-in datatype. The data is read into MATLAB by reading along
    %   the first dimension.
    %
    %   System objects may be called directly like a function instead of
    %   using the step method. For example, y = step(obj) and y = obj()
    %   are equivalent.
    %
    %   MatFileReader methods:
    %
    %   step     - See above description for use of this method
    %   release  - Closes the MAT file
    %   clone    - Create file reader object with same property values
    %   reset    - Reset the reading to the start of the variable
    %   isDone   - Returns true if object has reached end-of-file
    %   isLocked - Locked status (logical)
    %
    %   MatFileReader properties:
    %
    %   Filename             - Name of MAT file to read
    %   VariableName         - Name of variable to read
    %   SamplesPerFrame      - Number of samples per output frame
    %
    %   % EXAMPLE: Use MatFileReader and MatFileWriter to stream data
    %      % First, create a variable name
    %      filename = [tempname '.mat'];
    %
    %      % Next, write that variable to a MAT-file.
    %      originalData = rand(40,2);
    %      save(filename, 'originalData', '-v7.3');
    %
    %      % Finally, stream the variable back into MATLAB.
    %      Reader = dsp.MatFileReader(filename, 'originalData', 4);
    %      while ~isDone(Reader)
    %          finalData = Reader();
    %      end
    %
    %   See also dsp.MatFileWriter.
    
    %   Copyright 2011-2021 The MathWorks, Inc.
    
    properties (Nontunable)
        %Filename The name of the MAT file
        % The Filename property is a value-only property which indicates the
        % name of the file to be read.  The default value of this property is
        % 'Untitled.mat'
        Filename = 'Untitled.mat';
        %VariableName The name of the variable stored in the MAT file
        % The VariableName property corresponds to the name of the variable in
        % the MAT-file which is being read.  The default value of this property
        % is 'x'.
        VariableName = 'x';

        %SamplesPerFrame Number of samples per output frame
        % Every time the step method is called, the number of elements
        % specified by this property are read from the MAT-file. The
        % default value of this property is 1.
        SamplesPerFrame (1, 1) {mustBePositive, mustBeInteger} = 1;
    end
    
    properties (Access = protected)
      % pReadFactor Every time the file is accessed, we read
      % SamplesPerFrame-by-pReadFactor samples
      pNumFrames (1, 1) {mustBePositive, mustBeInteger} = 1;  
    end
    
    properties (Nontunable, Access = protected)
        % pSamplesPerRead Number of read samples every time file is
        % accessed. this value is equal to SamplesPerFrame-by-pNumFrames
        pSamplesPerRead (1, 1) {mustBePositive, mustBeInteger} = 1;
    
        % pBuffer Buffer holding samples read from last file access
        pBuffer
        % pDims   Buffer dimensions
        pDims
        % pMLClass Actual class used to initialize buffers
        pMLClass
    end
    
    properties (Access = protected)
        % pBufferIdx Location to read from buffer
        pBufferIdx = 0
        % pRemainingSegments When there are no more new samples in the
        % file, isDone returns true after pRemainingSegments segments are
        % read from the buffer
        pRemainingSegments = 0
        % pIdxVector Vector used to index into buffer for N-D data
        pIdxVector
    end
    
    properties (Hidden, Access=protected)
        fileID       = 0;
        dsetID       = 0;
        fileSpaceID  = 0;
        memSpaceID   = 0;
        maxPosition  = 0;
        h5datatype   = 0;
        dims         = 0;
        matlabClass  = '';
    end
    
    properties (Access = protected)
       pIsComplex (1, 1) logical 
       % pLastSegmentRead Flag is set to true right after the last
       % available samples are read from the file
       pLastSegmentRead (1, 1) logical
       % pIsDone Flag is set to true when there are no more new samples to
       % output
       pIsDone (1, 1) logical
       % pIs2D   True if the data is two-dimensional
       pIs2D (1, 1) logical
       % pIsChar True if the class of the data is char
       pIsChar (1, 1) logical
    end
   
    
    properties(Access = private)
        position;
    end
    
    methods
        function set.VariableName(obj, value)
            if ~isvarname(value)
                error(message('dsp:MatFileReader:badVariableName'));
            end
            obj.VariableName = char(value);
        end
        
        function set.Filename(obj,name)
            validateattributes( name, { 'char','string' }, { 'nonempty' }, '', 'Filename');
            obj.Filename = char(name);
        end

    end
    
    methods
        function obj = MatFileReader(varargin)
            setProperties(obj, nargin, varargin{:}, 'Filename', 'VariableName','SamplesPerFrame');
        end
    end
    
    methods (Access=protected)
        
        function setupObject(obj, varargin)
            % If the filename is empty and we are writing,
            % create a temporary file
            % Open the file
            if ~exist(obj.Filename, 'file')
                error(message('dsp:MatFileReader:nonExistentFile'));
            end
            if ~H5F.is_hdf5(obj.Filename)
                error(message('dsp:MatFileReader:notMatFile', obj.Filename));
            end
            
            % The maximum buffer length is 1e5
            obj.pNumFrames      = max(1,floor(1e5 / obj.SamplesPerFrame));
            obj.pSamplesPerRead = obj.pNumFrames * obj.SamplesPerFrame;
            try
                obj.fileID = H5F.open(obj.Filename, 'H5F_ACC_RDONLY', 'H5P_DEFAULT');
                path = ['/' obj.VariableName];
                if ~H5L.exists(obj.fileID, path, 'H5P_DEFAULT')
                    error(message('dsp:MatFileReader:noVariable', obj.VariableName, obj.Filename));
                end
                obj.dsetID = H5D.open(obj.fileID, path);
            catch err
                if strcmp(err.identifier, 'MATLAB:hdf5lib2:H5Dopen1:failure')
                    errMsg = sprintf('Could not open %s in %s', ...
                        obj.VariableName, obj.Filename);
                else
                    errMsg = err.message;
                end
                error(message('dsp:MatFileReader:HDF5Error', errMsg));
            end
            readAttributes(obj);
            assertValidClass(obj);
            obj.fileSpaceID = H5D.get_space(obj.dsetID);
            [~, h5Dims]     = H5S.get_simple_extent_dims(obj.fileSpaceID);
            obj.dims        = fliplr(h5Dims);

            obj.maxPosition = ceil(h5Dims(length(obj.dims)) / obj.pSamplesPerRead);
            h5Dims(length(obj.dims)) = obj.pSamplesPerRead;
            obj.memSpaceID = H5S.create_simple(length(h5Dims), h5Dims, []);
            obj.pDims    = fliplr(h5Dims);
            obj.pIs2D    = length(obj.pDims) == 2;
        end
        
        function setupImpl(obj, varargin)
            obj.position = 0;
            setupObject(obj,varargin);
        end
        
        function resetImpl(obj)
            obj.position = 0;
            obj.pBufferIdx = 0;
            obj.pLastSegmentRead = false;
            obj.pIsDone          = false;
            if ~obj.pIs2D
                obj.pIdxVector = repmat({':'}, 1, numel(obj.pDims)); 
            end
        end
        
        function data = readData(obj)
            obj.position = obj.position + 1;
            data = [];
            overshoot = 0;
            h5offset = zeros(1, length(obj.dims));
            h5offset(length(obj.dims)) = (obj.position-1)*obj.pSamplesPerRead;
            h5block  = fliplr(obj.dims);
            h5block(length(obj.dims)) = obj.pSamplesPerRead;
            if obj.position == obj.maxPosition
                reqDims = h5offset + h5block;
                space = H5D.get_space(obj.dsetID);
                [~ , localDims] = H5S.get_simple_extent_dims(space);
                overshoot = reqDims(end) - localDims(end);
                obj.pLastSegmentRead = true;
                % When accessing the buffer after this last readout,
                % the isDone method should return true after
                % pRemainingSegments segments are read
                obj.pRemainingSegments = mod(ceil(obj.pNumFrames * (obj.pSamplesPerRead - overshoot) / obj.pSamplesPerRead),obj.pNumFrames);
                if overshoot
                    h5block = [h5block(1:end-1) obj.pSamplesPerRead - overshoot];
                end
            end
            if obj.position > obj.maxPosition
                if ~obj.pIsComplex % real data
                    data = zeros(fliplr(h5block), obj.pMLClass);
                else               % complex data
                    data.real = zeros(fliplr(h5block), obj.pMLClass);
                    data.imag = zeros(fliplr(h5block), obj.pMLClass);
                end
            else
                H5S.select_hyperslab(obj.fileSpaceID, 'H5S_SELECT_SET',...
                    h5offset, [], [], h5block);
                if overshoot
                    localMemSpaceID = H5S.create_simple(length(h5block), h5block, []);
                    data = H5D.read(obj.dsetID, 'H5ML_DEFAULT',...
                        localMemSpaceID, obj.fileSpaceID, 'H5P_DEFAULT');
                    if ~obj.pIsComplex % real data
                        data = [data ; zeros([overshoot h5block(end-1:-1:1)], obj.pMLClass)];
                    else               % complex data
                        data.real = [data.real ; zeros([overshoot h5block(end-1:-1:1)], obj.pMLClass)];
                        data.imag = [data.imag ; zeros([overshoot h5block(end-1:-1:1)], obj.pMLClass)];
                    end
                else
                    data = H5D.read(obj.dsetID, 'H5ML_DEFAULT',...
                        obj.memSpaceID, obj.fileSpaceID, 'H5P_DEFAULT');
                end
            end
        end
        
        function data = stepImpl(obj) % Read/Write the file
            count = obj.pBufferIdx;
            SPF   = obj.SamplesPerFrame;
            if count == 0
                obj.pBuffer = readData(obj);
            end
            
            if obj.pIs2D
                if ~obj.pIsComplex
                    data = obj.pBuffer(count*SPF + 1:(count+1)*SPF,:);
                else
                    data.real = obj.pBuffer.real(count*SPF + 1:(count+1)*SPF,:);
                    data.imag = obj.pBuffer.imag(count*SPF + 1:(count+1)*SPF,:);
                end
            else
                obj.pIdxVector{1} = count*SPF + 1:(count+1)*SPF;
                if ~obj.pIsComplex
                    data = obj.pBuffer(obj.pIdxVector{:});
                else
                    data.real = obj.pBuffer.real(obj.pIdxVector{:});
                    data.imag = obj.pBuffer.imag(obj.pIdxVector{:});
                end
            end

            count = count+1;
            if count == obj.pNumFrames
               count = 0; 
            end
            
            if obj.pLastSegmentRead && count == obj.pRemainingSegments
                obj.pIsDone = true;
            end
            obj.pBufferIdx = count;
            
            if obj.pIsChar
                data = char(data);
            end
        end
        
        function tf = isDoneImpl(obj)
            tf = obj.pIsDone;
        end
        
        function n = getNumInputsImpl(~)
            n = 0;
        end
        
        function n = getNumOutputsImpl(~)
            n = 1;
        end
        
        function releaseImpl(obj)
            H5D.close(obj.dsetID);
            H5F.close(obj.fileID);
        end
        
        function readAttributes(obj)
            % Read the attribute
            attr_id = H5A.open(obj.dsetID,'MATLAB_class');
            obj.matlabClass = H5A.read(attr_id)';
            obj.pIsChar     = strcmp(obj.matlabClass,'char');
            if obj.pIsChar
                obj.pMLClass = 'uint16';
            else
                obj.pMLClass =  obj.matlabClass;
            end
            type_id = H5D.get_type(obj.dsetID);
            class_id = H5T.get_class(type_id);
            obj.pIsComplex = (class_id == H5ML.get_constant_value('H5T_COMPOUND'));
            
            H5A.close(attr_id);
        end
        
        function assertValidClass(obj)
            switch obj.matlabClass
                case 'double'
                case 'single'
                case 'uint64'
                case 'int64'
                case 'uint32'
                case 'int32'
                case 'uint16'
                case 'int16'
                case 'uint8'
                case 'int8'
                case 'logical'
                case 'char'
                otherwise
                    error(message('dsp:MatFileReader:invalidDataType', obj.matlabClass));
            end
        end
        
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            s.SaveLockedData = false;
            s.position = obj.position;
        end
        
        function loadObjectImpl(obj, s, ~)
            % Call the base class method
            loadObjectImpl@matlab.System(obj, s);
            if isfield(s,'position')
                obj.position = s.position;
            end
        end        
    end
    
    methods(Access=public, Static, Hidden)
        %isEOFPortAvailable Codegen helper method for isDone
        function eofport = isEOFPortAvailable(~)
            eofport = true;
        end
    end
end



