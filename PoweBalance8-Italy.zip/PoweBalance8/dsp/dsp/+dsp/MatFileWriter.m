classdef (StrictDefaults)MatFileWriter < matlab.System
%MatFileWriter File writer
%   Writer = dsp.MatFileWriter returns a System object, Writer, that writes
%   MAT files.
%
%   Writer = dsp.MatFileWriter('PropertyName', PropertyValue, ...) returns
%   a file writer object, Writer, with each specified property set to the
%   specified value.
%
%   Writer = dsp.MatFileWriter(FILENAME, VARIABLENAME, 'PropertyName',
%   PropertyValue, ...) returns a file writer object, Writer, with the
%   Filename property set to FILENAME, the VariableName property set
%   to VARIABLENAME, and other properties set to the specified values.
%
%   Step method syntax:
%
%   step(Writer, X) writes data, X, to a variable stored in a MAT-file. The
%   variable is assumed to be N-dimensional and a MATLAB built-in datatype.
%   The data is written to the file by concatenating along the first
%   dimension.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, step(obj, x) and obj(x) are equivalent.
%
%   MatFileWriter methods:
%
%   step     - See above description for use of this method
%   release  - Closes the MAT file.
%   clone    - Create file writer object with same property values
%   reset    - Reset the writing to the start of the variable
%   isLocked - Locked status (logical)
%
%   MatFileWriter properties:
%
%   Filename             - Name of MAT file to write
%   VariableName         - Name of variable to write
%
%   % EXAMPLE: Use MatFileReader and MatFileWriter to stream data
%      % First, create a variable name
%      filename = [tempname '.mat'];
%
%      % Next, write that variable to a MAT-file.
%      Writer = dsp.MatFileWriter(filename,'VariableName','originalData');
%      for i=1:10
%          originalData = rand(4,2);
%          Writer(originalData);
%      end
%      release(Writer); % This will close the MAT file
%
%      % Finally, load the variable back into MATLAB.
%      data = load(filename, 'originalData');
%
%   See also dsp.MatFileReader.

%   Copyright 2011-2022 The MathWorks, Inc.
  
  
  properties (Nontunable)
    %Filename Name of MAT file to write
    % The Filename property is a value-only property which indicates the
    % name of the file to be written.  The default value of this property
    % is 'Untitled.mat'
    Filename = 'Untitled.mat';
    %VariableName Name of variable to write
    % The VariableName property corresponds to the name of the variable in
    % the MAT-file which is being written.  The default value of this
    % property is 'x'.
    VariableName = 'x';
  end

  properties (Hidden, Access=protected)
    fileID       = 0;
    dsetID       = 0;
    fileSpaceID  = 0;
    memSpaceID   = 0;
    maxPosition  = 0;
    h5datatype   = 0;
    dims         = 0;
    matlabClass  = 0;
    skipVariableCreation = false;
    openExistingdSet     = false;
    fullFilename = '';
  end
  
  properties(Access = private)
    position;
  end
  
  methods
    function obj = MatFileWriter(varargin)
    setProperties(obj, nargin, varargin{:}, 'Filename', 'VariableName');
    end
    
    function set.VariableName(obj, value)
        if ~isvarname(value)
          error(message('dsp:MatFileWriter:badVariableName'));
        end
        obj.VariableName = char(value);
    end
    
    function set.Filename(obj,name)
        validateattributes( name, { 'char','string' }, { 'nonempty' }, '', 'Filename');
        obj.Filename = char(name);
    end

  end
  
  methods (Access=protected)
      
    function setupObject(obj)
            if isempty(obj.Filename)
                obj.Filename = tempname;
            end
            
            % Check for the .mat extension, and add it if it's missing
            [~,~,ext] = fileparts(obj.Filename);
            if isempty(ext)
                obj.Filename=strcat(obj.Filename,'.mat');
            end
            
            % Open the file
            try
                if exist(obj.Filename, 'file')
                    if H5F.is_hdf5(obj.Filename)
                        obj.fileID = H5F.open(obj.Filename,'H5F_ACC_RDWR','H5P_DEFAULT');
                    else
                        error(message('dsp:MatFileWriter:invalidFileType', obj.Filename));
                    end
                else
                    fcpl = H5P.create('H5P_FILE_CREATE');
                    fapl = H5P.create('H5P_FILE_ACCESS');
                    H5P.set_userblock(fcpl,512);
                    obj.fileID = H5F.create(obj.Filename,'H5F_ACC_TRUNC',fcpl,fapl);
                end
            catch err
                error(message('dsp:MatFileWriter:openFile', obj.Filename));
            end
            
            % Set the full filename
            path = fileparts(obj.Filename);
            if isempty(path) || path(1)=='.' % relative path
              obj.fullFilename = fullfile(pwd, obj.Filename);
            else
              obj.fullFilename = obj.Filename;
            end
            
            % Compute the dimensions
            h5Dims      = fliplr(obj.dims);
            h5Maxdims   = h5Dims;
            growableDim = length(obj.dims);
            h5Maxdims(growableDim) = H5ML.get_constant_value('H5S_UNLIMITED');

            chunkSize = dsp.MatFileWriter.getChunkSize(h5Dims, growableDim);
            obj.memSpaceID  = H5S.create_simple(length(h5Dims), h5Dims, []);
            obj.fileSpaceID = H5S.create_simple(length(h5Dims), h5Dims, h5Maxdims);
            
            propListID = H5P.create('H5P_DATASET_CREATE');
            H5P.set_chunk(propListID, chunkSize);
            typeID     = H5T.copy(obj.h5datatype);
            if ~(obj.skipVariableCreation)
                try
                    obj.dsetID = H5D.create(obj.fileID, ['/' obj.VariableName], ...
                        typeID, obj.fileSpaceID, propListID);
                catch err
                    error(message('dsp:MatFileWriter:createDataset', obj.VariableName));
                end
                obj.writeAttributes(obj.matlabClass);
            else
                if (obj.openExistingdSet)
                    obj.dsetID = H5D.open(obj.fileID, ['/' obj.VariableName]);
                    obj.openExistingdSet = false;
                end
                obj.skipVariableCreation = false;
            end
    end
        
    function setupImpl(obj, data)
        obj.dims  = size(data);
        obj.matlabClass = class(data);
        obj.position = 0;
        datatype = dsp.MatFileWriter.getH5Datatype(class(data));
        if isreal(data)
            obj.h5datatype = datatype;
        else
            attrbs = whos('data');
            sizeDT = attrbs.bytes ./ numel(data);
            obj.h5datatype = H5T.create('H5T_COMPOUND',sizeDT);
            H5T.insert(obj.h5datatype,'real',0,datatype);
            H5T.insert(obj.h5datatype,'imag',sizeDT/2,datatype);
        end
        setupObject(obj);
    end
    
    function resetImpl(obj)
    obj.position = 0;
    end
    
    function stepImpl(obj, data) % Write the file
    obj.position = obj.position + 1;
    extend(obj, obj.position);
    
    h5offset = zeros(1, length(obj.dims));
    h5offset(length(obj.dims)) = (obj.position-1)*obj.dims(1);
    h5block = fliplr(obj.dims);

    H5S.select_hyperslab(obj.fileSpaceID, 'H5S_SELECT_SET',...
      h5offset, [], [], h5block);
    if ischar(data)
      data = uint16(data);
    elseif islogical(data)
      data = uint8(data);
    end
    if isreal(data)
    H5D.write(obj.dsetID, 'H5ML_DEFAULT', ...
      obj.memSpaceID, obj.fileSpaceID, ...
      'H5P_DEFAULT', data);
    else
    cvalue.real = real(data);
    cvalue.imag = imag(data);
    H5D.write(obj.dsetID, 'H5ML_DEFAULT', ...
              obj.memSpaceID, obj.fileSpaceID, ...
              'H5P_DEFAULT', cvalue);
    end
    end
    
    function writeAttributes(obj, dataClass)
    % Write the class attribute
    type_id = H5T.copy('H5T_C_S1');
    H5T.set_size(type_id, length(dataClass));
    space_id = H5S.create('H5S_SCALAR');
    attr_id = H5A.create(obj.dsetID, 'MATLAB_class', type_id, space_id,...
      'H5P_DEFAULT','H5P_DEFAULT');
    H5A.write(attr_id, 'H5ML_DEFAULT', dataClass);
    
    % Write the int_decode attribute
    decode = 0;
    switch dataClass
      case 'logical'
        decode = 1;
      case 'char'
        decode = 2;
    end
    if decode
      type_id = H5T.copy('H5T_NATIVE_INT');
      %H5T.set_size(type_id, 1);
      space_id = H5S.create('H5S_SCALAR');
      attr_id = H5A.create(obj.dsetID, 'MATLAB_int_decode', type_id, space_id,...
        'H5P_DEFAULT','H5P_DEFAULT');
      H5A.write(attr_id, 'H5ML_DEFAULT', int32(decode));
    end
    end
 
    function n = getNumInputsImpl(~)
    n = 1;
    end
    function n = getNumOutputsImpl(~)
    n = 0;
    end
    
    function flag = isInactivePropertyImpl(~, ~)
    flag = false;
    end
    
    function releaseImpl(obj) % Destructor code goes here
    H5D.close(obj.dsetID);
    H5F.flush(obj.fileID, 'H5F_SCOPE_GLOBAL');
    H5F.close(obj.fileID);
    dsp.MatFileWriter.writeUserblock(obj.fullFilename);
    end
    
    function extend(obj, extent)
    if extent < obj.position
      return
    end

    newExtent = obj.dims;
    newExtent(1) = obj.dims(1)*extent;
    newExtent = fliplr(newExtent);

    H5D.set_extent(obj.dsetID, newExtent);
    obj.fileSpaceID = H5D.get_space(obj.dsetID);
    end
    
    function s = saveObjectImpl(obj)
        s = saveObjectImpl@matlab.System(obj);
        s.SaveLockedData = false;
        s.position = obj.position;
    end
    
    function loadObjectImpl(obj, s, ~)
        % Call the base class method
        loadObjectImpl@matlab.System(obj, s);
        if isfield(s,'position')
            obj.position = s.position;
        end
    end
    
    
  end
  
  methods (Static, Access=private)
    function writeUserblock(filename)
    fid = fopen(filename, 'r+');
    frewind(fid);
    matversion = 'MATLAB 7.3 MAT-file, ';
    platform   = ['Platform: ' computer ', '];
    created	   = ['Created on: '  char(datetime('now','Format','MM-dd-yyyy HH:mm:ss'))];
    blather    = ' HDF5 schema 1.00 . ';
    HEADER_LENGTH = 128;
    HDF_VERSION   = hex2dec('0200');
    miKEY         = hex2dec('4D49');
    headerTail = uint16([0,0,0,0, HDF_VERSION, miKEY]);
    headerTail = typecast(headerTail, 'uint8');
    
    bytesOut = fwrite(fid, matversion);
    bytesOut = bytesOut + fwrite(fid, platform);
    bytesOut = bytesOut + fwrite(fid, created);
    bytesOut = bytesOut + fwrite(fid, blather);
    bytesOut = bytesOut + fwrite(fid, ...
      zeros([1, HEADER_LENGTH - bytesOut - length(headerTail)], 'uint8'));
    bytesOut = bytesOut + fwrite(fid, headerTail);
    assert(bytesOut == HEADER_LENGTH);
    fclose(fid);
    end
    
    function sz = getChunkSize(dims, growableDim)
      sz = dims;
      % Write in chunks that are approximately 64k in size
      elemSizeInBytes     = 4; % approximation
      chunkSizeInElements = 2^16 / elemSizeInBytes;
      dims(growableDim)   = 1;
      sz(growableDim)     = max(floor(chunkSizeInElements/prod(dims)), 1);
    end
    
    function datatype = getH5Datatype(matlabClass)
    switch matlabClass
      case 'double'
        datatype = 'H5T_NATIVE_DOUBLE';
      case 'single'
        datatype = 'H5T_NATIVE_FLOAT';
      case 'uint64'
        datatype = 'H5T_NATIVE_UINT64';
      case 'int64'
        datatype = 'H5T_NATIVE_INT64';
      case 'uint32'
        datatype = 'H5T_NATIVE_UINT';
      case 'int32'
        datatype = 'H5T_NATIVE_INT';
      case 'uint16'
        datatype = 'H5T_NATIVE_USHORT';
      case 'int16'
        datatype = 'H5T_NATIVE_SHORT';
      case 'uint8'
        datatype = 'H5T_NATIVE_UCHAR';
      case 'int8'
        datatype = 'H5T_NATIVE_CHAR';
      case 'logical'
        datatype = 'H5T_NATIVE_UCHAR';
      case 'char'
        datatype = 'H5T_NATIVE_USHORT';
      otherwise
        error(message('dsp:MatFileWriter:invalidDataType', matlabClass));
    end
    end
  end
  
end
