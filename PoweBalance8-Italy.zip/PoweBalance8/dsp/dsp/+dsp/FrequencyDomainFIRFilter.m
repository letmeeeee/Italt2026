classdef (StrictDefaults)FrequencyDomainFIRFilter < matlab.System...
        & dsp.enhancedsim.UpdateSysObjBuildInfo
    %   FrequencyDomainFIRFilter Filter input signal in the frequency
    %   domain. fdf = dsp.FrequencyDomainFIRFilter returns a System object,
    %   fdf, which independently filters each channel of the input over
    %   time using the overlap-save or overlap-add method.
    %
    %   fdf = dsp.FrequencyDomainFIRFilter(Name=Value, ...) returns a
    %   frequency domain filter System object, fdf, with each specified
    %   property name set to the specified value. You can specify
    %   additional name-value pair arguments in any order as
    %   (Name1=Value1,...,NameN=ValueN).
    %
    %   fdf = dsp.FrequencyDomainFIRFilter(num) returns a frequency domain
    %   filter object, fdf, with the Numerator property set to num.
    %
    %   Step method syntax:
    %  
    %   Y = step(fdf, X) computes the filtered output, Y, of the input X.
    %   Each column of X is a channel. The System object filters each
    %   channel of the input signal independently over time.
    %
    %   System objects may be called directly like a function instead of
    %   using the step method. For example, y = step(obj, x) and y = obj(x)
    %   are equivalent.
    %
    %   FrequencyDomainFIRFilter methods:
    %
    %   step                     - Filter the input signal in the frequency
    %                              domain
    %   release                  - Allow property value and input
    %                              characteristics changes, and release
    %                              filter resources
    %   clone                    - Create filter object with same
    %                              property values
    %   isLocked                 - Display locked status (logical)
    %   reset                    - Reset the states of the filter
    %   fvtool                   - Visualize the numerator's frequency
    %                              response
    %
    %   FrequencyDomainFIRFilter properties:
    %
    %   Method                     - Frequency-domain filter method
    %   NumeratorDomain            - Numerator domain (Time or Frequency)
    %   Numerator                  - Filter coefficients
    %   FrequencyResponse          - Filter frequency response
    %   FFTLength                  - FFT length
    %   NumeratorLength            - Time-domain numerator length
    %   FilterIsReal               - Filter is real
    %   PartitionForReducedLatency - Partition numerator to reduce latency
    %   PartitionLength            - Numerator partition length
    %   Latency                    - Filter latency (read-only)
    %   NumPaths                   - Number of Paths between each
    %                                transmitter and receiver pair
    %   SumFilteredOutputs         - Sum filtered output contributions from
    %                                all input channels
    %
    %   % Example: Filter input signal using overlap-add, and compare to
    %   % the output of a time-domain FIR filter.
    %
    %   % Design FIR lowpass filter coefficients:
    %   impL    = 400;
    %   Fs      = 8000;
    %   Fcutoff = 2000;
    %   imp     = designLowpassFIR(FilterOrder=impL,...
    %               CutoffFrequency=2*Fcutoff/Fs);
    %
    %   oa  = dsp.FrequencyDomainFIRFilter(imp, Method='overlap-add');
    %   fprintf('Frequency domain filter latency is %dsamples\n',...
    %   oa.Latency);
    %   fir = dsp.FIRFilter(Numerator=imp);
    %   % Delay the FIR output by the frequency-domain filter's latency.
    %   dly = dsp.Delay(Length=oa.Latency);
    %
    %   numFrames = 1e4;
    %   frameLen  = 256;
    %
    %   sin_100Hz = dsp.SineWave(Frequency=100, SampleRate=Fs,...
    %                            SamplesPerFrame=frameLen);
    %   sin_3KHz  = dsp.SineWave(Frequency=3e3, SampleRate=Fs,...
    %                            SamplesPerFrame=frameLen);
    %
    %   ts = timescope(TimeSpanSource='property',...
    %                  TimeSpan=5 * frameLen/Fs,...
    %                  YLimits=[-1.1 1.1],...
    %                  ShowLegend=true,...
    %                  SampleRate=Fs,...
    %                  ChannelNames={'Overlap-add','Direct-form FIR'});
    %
    %   for idx = 1:numFrames
    %     x = sin_100Hz() + sin_3KHz() + 0.01 * randn(frameLen,1);
    %     y1 = oa(x);
    %     y2 = fir(dly(x));
    %     ts([y1,y2]);
    %   end
    %
    %   % Example: Use overlap-save to pass an input signal through an
    %   % FIR filter of length 3000. Partition numerator to reduce latency.
    %   % Compare to the output of a time-domain FIR filter.
    %
    %   % Design FIR lowpass filter coefficients:
    %   impL    = 3000;
    %   Fs      = 8000;
    %   Fcutoff = 2000;
    %   imp     = designLowpassFIR(FilterOrder=impL,...
    %   CutoffFrequency=2*Fcutoff/Fs);
    %
    %   os  = dsp.FrequencyDomainFIRFilter(imp, Method='overlap-save',...
    %                                    PartitionForReducedLatency=true,...
    %                                    PartitionLength=256);
    %   fprintf('Frequency domain filter latency is %d samples\n',...
    %   os.Latency);
    %   fir = dsp.FIRFilter(Numerator=imp);
    %   dly = dsp.Delay(Length=os.Latency);
    %
    %   numFrames = 1e4;
    %   frameLen  = 256;
    %
    %   sin_100Hz = dsp.SineWave(Frequency=100,SampleRate=Fs,...
    %                            SamplesPerFrame=frameLen);
    %   sin_3KHz  = dsp.SineWave(Frequency=3e3,SampleRate=Fs,...
    %                            SamplesPerFrame=frameLen);
    %
    %   ts = timescope(TimeSpanSource='property',...
    %                  TimeSpan=5 * frameLen/Fs,...
    %                  YLimits=[-1.1 1.1],...
    %                  ShowLegend=true,...
    %                  SampleRate=Fs,...
    %                  ChannelNames={'Overlap-save','Direct-form FIR'});
    %
    %   for idx = 1:numFrames
    %       x = sin_100Hz() + sin_3KHz() + .1 * randn(frameLen,1);
    %       y1 = os(x);
    %       y2 = fir(dly(x));
    %       ts([y1,y2]);
    %   end
    %
    %   % Example: Specify the filter's frequency response. Filter input
    %   % signal using overlap-add, and compare to the output of a
    %   % time-domain FIR filter.
    %
    %   % Design FIR lowpass filter coefficients:
    %   impL    = 400;
    %   Fs      = 8000;
    %   Fcutoff = 2000;
    %   imp     = designLowpassFIR(FilterOrder=impL,...
    %   CutoffFrequency=2*Fcutoff/Fs);
    %
    %   H   = fft(imp, 2 * numel(imp));
    %   oa  = dsp.FrequencyDomainFIRFilter(NumeratorDomain='Frequency',...
    %                                      FrequencyResponse=H,...
    %                                      NumeratorLength=numel(imp),...
    %                                      Method='overlap-add');
    %   fprintf('Frequency domain filter latency is %d samples\n',...
    %   oa.Latency);
    %   fir = dsp.FIRFilter(Numerator=imp);
    %   % Delay the FIR output by the frequency-domain filter's latency.
    %   dly = dsp.Delay(Length=oa.Latency);
    %
    %   numFrames = 1e4;
    %   frameLen  = 256;
    %
    %   sin_100Hz = dsp.SineWave(Frequency=100,SampleRate=Fs,...
    %                            SamplesPerFrame=frameLen);
    %   sin_3KHz  = dsp.SineWave(Frequency=3e3,SampleRate=Fs,...
    %                            SamplesPerFrame=frameLen);
    %
    %   ts = timescope(TimeSpanSource='property',...
    %                  TimeSpan=5 * frameLen/Fs,...
    %                  YLimits=[-1.1 1.1],...
    %                  SampleRate=Fs,...
    %                  ChannelNames={'Overlap-add','Direct-form FIR'});
    %
    %   for idx = 1:numFrames
    %     x = sin_100Hz() + sin_3KHz() + 0.01 * randn(frameLen,1);
    %     y1 = oa(x);
    %     y2 = fir(dly(x));
    %     ts([y1,y2]);
    %   end
    %
    %   % Example: Filter an input signal using a 3-by-2 MIMO system that
    %   % is modeled using multiple filters.
    % 
    %   % Design FIR lowpass filter coefficients:
    %   impL    = 400;
    %   Fs      = 8000;
    %
    %   % Number of filters is six for three transmitters (input channels),
    %   % two receivers and one path between each transmitter-receiver
    %   % pair.
    %   
    %   num  = [ % Transmitter 1, Receiver 1
    %           designLowpassFIR(FilterOrder=impL,CutoffFrequency=0.1);...
    %            % Transmitter 1, Receiver 2
    %           designLowpassFIR(FilterOrder=impL,CutoffFrequency=0.15);...
    %            % Transmitter 2, Receiver 1
    %           designLowpassFIR(FilterOrder=impL,CutoffFrequency=0.2);...
    %            % Transmitter 2, Receiver 2
    %           designLowpassFIR(FilterOrder=impL,CutoffFrequency=0.25);...
    %            % Transmitter 3, Receiver 1
    %           designLowpassFIR(FilterOrder=impL,CutoffFrequency=0.3);...
    %            % Transmitter 3, Receiver 2
    %           designLowpassFIR(FilterOrder=impL,CutoffFrequency=0.35)];
    %  
    %   % Compute output using overlap-save method
    %   filt  = dsp.FrequencyDomainFIRFilter(Numerator=num,...
    %   Method='overlap-save');
    %   numFrames = 1e4;
    %   frameLen  = 256;
    %
    %   sin_Hz = dsp.SineWave(Frequency=[100 200 300],SampleRate=Fs,...
    %                        SamplesPerFrame=frameLen);
    %   sin_KHz  = dsp.SineWave(Frequency=[2e3 2.5e3 3e3],SampleRate=Fs,...
    %                        SamplesPerFrame=frameLen);
    %
    %   specScope = spectrumAnalyzer(SampleRate=Fs,PlotAsTwoSidedSpectrum=false, ...
    %           ChannelNames={'Transmitter 1','Transmitter 2','Transmitter 3', ...
    %           'Receiver 1','Receiver 2'},ShowLegend=true);
    %
    %   for idx = 1:numFrames
    %       x = sin_Hz() + sin_KHz() + 0.01 * randn(frameLen, 3);
    %       y = filt(x);
    %
    %       specScope([x, y]);
    %   end
    %
    %   % Example: Filter an input signal through three distinct paths
    %   % between the input and the output by specifying three filters to
    %   % model the frequency responses across each path.
    %
    %   % Design FIR lowpass filter coefficients:
    %   impL    = 400;
    %   Fs      = 8000;
    %
    %   num = [ 
    %   designFracDelayFIR(0.1,impL); % Path 1
    %   designFracDelayFIR(0.2,impL); % Path 2
    %   designFracDelayFIR(0.3,impL); % Path 3
    %   ];
    % 
    %   % Compute SISO output using overlap-add method
    %   filt  = dsp.FrequencyDomainFIRFilter(Numerator=num,...
    %                        Method='overlap-add',NumPaths=3);
    %   numFrames = 1e3;
    %   frameLen  = 1024;
    %
    %   sin_200Hz = dsp.SineWave(Frequency=200,SampleRate=Fs,...
    %                        SamplesPerFrame=frameLen);
    %   sin_4KHz  = dsp.SineWave(Frequency=4e3,SampleRate=Fs,...
    %                        SamplesPerFrame=frameLen);
    %
    %   specScope = spectrumAnalyzer(SampleRate=Fs,PlotAsTwoSidedSpectrum=false, ...
    %                ChannelNames={'Transmitter','Receiver'},ShowLegend=true);
    %
    %   for idx = 1:numFrames
    %       x = sin_200Hz() + sin_4KHz() + 0.01 * randn(frameLen, 1);
    %       y = filt(x);
    %
    %       specScope([x, y])
    %   end
    %
    %   See also dsp.FIRFilter
    
% Copyright 2017-2023 The MathWorks, Inc.

    %#codegen
    %#ok<*EMCLS>

    properties
        % Numerator Filter coefficients
        % Specify the filter coefficients as a real or complex numeric row
        % vector or matrix. When PartitionForReducedLatency is true, more
        % than one filter can not be specified thus, Numerator must be a row
        % vector. When PartitionForReducedLatency is false, multiple
        % filters can be specified. Numerator can be a row vector or matrix
        % of size NumFilt-by-FiltLen, where NumFilt is the number of
        % filters, and FiltLen is the filter length. NumFilt =
        % size(input,2)*NumPaths*NumRx where NumRx is the number of
        % receivers i.e. size(y,2). The filters must be given in
        % the same order as input channels. The first NumRx*NumPaths
        % filters correspond to the first input channel within which
        % (i-1)*NumPaths + 1 to i*NumPaths filters compute the output for
        % the ith receiver. Similarly, the next NumRx*NumPaths filters
        % correspond to the second channel and so forth. This property is
        % tunable but the size must remain the same. This property is
        % applicable when NumeratorDomain is 'Time'. The default value of
        % this property is fir1(100,0.3).
        Numerator = fir1(100,0.3);
        % FrequencyResponse Frequency response
        % Specify the filter frequency response. When
        % PartitionForReducedLatency is false, FrequencyResponse can be a
        % row vector or matrix of size NumFilt-by-FFTLength, where NumFilt
        % is the number of filters. When PartitionForReducedLatency is
        % true, more than one filter can not be specified and it must be a
        % 2*P-by-N matrix, where P is the partition size, and N is the
        % number partitions. This property is applicable when
        % NumeratorDomain is 'Frequency'. The default value of this
        % property is fft(fir1(100,0.3), 202). This property is tunable.
        FrequencyResponse = fft(fir1(100,0.3), 202);
    end

    properties (Nontunable)
        % NumeratorLength Time-domain numerator length
        % Specify the time-domain numerator length as a positive scalar.
        % This property is applicable when NumeratorDomain is 'Frequency'.
        % The default value of this property is 101.
        NumeratorLength (1, 1) {mustBePositive, mustBeInteger} = 101;

        % NumeratorDomain Numerator domain
        % Specify the numerator domain as 'Time' or 'Frequency'. When
        % NumeratorDomain is 'Time', you specify the time-domain filter
        % numerator in the Numerator property. When NumeratorDomain is
        % 'Frequency', you specify the filter's frequency response in the
        % FrequencyResponse property. The default is 'Time'.
        NumeratorDomain (1, :) char {matlab.system.mustBeMemberMessageID(NumeratorDomain, ...
            {'dsp:system:FrequencyDomainFIRFilter:Domain_Time',;...
            'dsp:system:FrequencyDomainFIRFilter:Domain_Frequency'})}= 'Time';

        % Method Frequency-domain filter method
        %  Specify the frequency-domain filter method as 'Overlap-save' or
        %  'Overlap-add'. The default is 'Overlap-save'.
        Method (1, :) char {matlab.system.mustBeMemberMessageID(Method, ...
            {'dsp:system:FrequencyDomainFIRFilter:Method_OverlapSave',;...
            'dsp:system:FrequencyDomainFIRFilter:Method_OverlapAdd'})} = 'Overlap-save';

        % FFTLength FFT length
        %  Specify the FFT length as a positive scalar integer. The default
        %  value of this property is [], which means that the FFT length is
        %  equal to twice the numerator length. This property applies when
        %  PartitionForReducedLatency is false and NumeratorDomain is
        %  'Time'.
        FFTLength       = [];

        % FilterIsReal Filter is real
        % Specify if the filter coefficients are all real. This property
        % applies when NumeratorDomain is 'Frequency'. The default is true.
        FilterIsReal (1, 1) logical = true; 

        % PartitionForReducedLatency Partition numerator to reduce latency
        %   When PartitionForReducedLatency is false, the filter uses the
        %   traditional overlap-save or overlap-add method. The latency in
        %   that case is FFTLength - length(Numerator) + 1. To reduce the
        %   latency, set PartitionForReducedLatency to true. In this mode,
        %   the numerator is partitioned into segments with length
        %   specified by the PartitionLength property. The filter performs
        %   overlap-save or overlap-add on each partition, and combines the
        %   partial results to form the overall output. The latency is now
        %   reduced to the partition length.
        PartitionForReducedLatency (1, 1) logical = false;

        % PartitionLength Numerator partition length
        %  Specify the numerator partition length as a positive scalar
        %  integer less than or equal to the length of the numerator. The
        %  default is 32. This property applies when
        %  PartitionForReducedLatency is true and NumeratorDomain is
        %  'Time'.
        PartitionLength (1, 1) {mustBePositive, mustBeInteger}   = 32;

        % NumPaths Number of propagation paths between each transmitter and
        % receiver pair
        %  Specify the number of paths between each transmitter (input
        %  channel) and receiver (output channel) as a positive integer.
        %  Each path is represented by a unique filter. Specifying number
        %  of paths greater than one can be used to model multipath
        %  propagation. The default value of this property is 1. This
        %  property is applicable when the number of filters is greater
        %  than 1 and PartitionForReducedLatency is false.
        NumPaths (1, 1) {mustBePositive, mustBeInteger} = 1;

        % SumFilteredOutputs Sum filtered output contributions from all
        % input channels
        %   When SumFilteredOutputs is true, the filtered output from each
        %   input channel for a given receiver is added to generate a
        %   L-by-R matrix output where L is the input frame size and R is
        %   the number of receivers. The number of receivers is
        %   NumFilt/(size(input, 2)*NumPaths, where NumFilt is the number
        %   of filters. When SumFilteredOutputs is false, no summation
        %   across input channels takes place. The output will be an
        %   L-by-R-by-size(input, 2) 3D matrix. This property is applicable
        %   when the number of filters is greater than 1 and
        %   PartitionForReducedLatency is false.
        SumFilteredOutputs (1, 1) logical = true;
    end

    properties (Nontunable, Dependent, SetAccess = private)
        % Latency Filter latency
        %   Use this read-only property to access the filter latency, in
        %   samples. When PartitionForReducedLatency is false, the latency
        %   is equal to FFTLength - length(Numerator) + 1. When
        %   PartitionForReducedLatency is true, the latency is equal to
        %   the partition length.
        Latency;
    end

    properties(Access = protected, Nontunable)
        % pNumeratorLength Numerator length
        pNumeratorLength
        % pNumFilters Number of Filters
        pNumFilters = 1;
    end

    properties(Access = protected)
        % pFilter Frequency-domain Filter
        pFilter
    end

    properties(Access = private)
        % NumChannels Cache number of input channels
        NumChannels = int32(-1);
    end

    properties(Access = private, Nontunable)
        % pFFTLength Cache FFT length
        pFFTLength
        % pDatatype Cache datatype
        pDatatype;
    end

    methods
        function obj = FrequencyDomainFIRFilter(varargin)
            setProperties(obj,nargin,varargin{:},'Numerator');
        end

        function set.FFTLength(obj,val)
            if isempty(val)
                validateattributes(val, {'numeric'},{},...
                    '','FFTLength');
            else
                validateattributes(val, {'numeric'},{'finite','scalar','integer','real','positive'},...
                    '','FFTLength');
            end
            obj.FFTLength = double(val);
        end

        function set.PartitionLength(obj,val)
            validateattributes(val, {'numeric'},{'finite','scalar','integer','real','positive'},...
                '','PartitionLength');
            obj.PartitionLength = double(val);
        end

        function set.Numerator(obj, value)
            validateNumerator(obj, value);
            obj.Numerator = value;
        end

        function set.FrequencyResponse(obj, value)
            validateattributes(value, ...
                {'numeric'}, {'finite', 'nonempty','2d'}, '', 'FrequencyResponse');
            obj.FrequencyResponse = value;
        end

        function lat = get.Latency(obj)
            if strcmp(obj.NumeratorDomain,'Time')
                if obj.PartitionForReducedLatency
                    l = obj.PartitionLength;
                else
                    if isempty(obj.FFTLength)
                        fftlen =  2*size(obj.Numerator, 2);
                    else
                        fftlen = obj.FFTLength;
                    end
                    l = fftlen - size(obj.Numerator, 2) + 1;
                end
            else
                if obj.PartitionForReducedLatency
                    l = size(obj.FrequencyResponse , 1) / 2;
                else
                    fftlen = size(obj.FrequencyResponse , 2);
                    l      = fftlen - obj.NumeratorLength + 1;
                end
            end
            lat = uint32(l);
        end

        function varargout = fvtool(obj,varargin)
            % Visualize the filter's frequency response. Visualize the
            % magnitude response, phase response, group delay, impulse
            % response, or pole-zero plot.
            %
            % Example
            % h    = firpm(25,[0 .4 .5 1],[0 0 1 1],'h');
            % filt = dsp.FrequencyDomainFIRFilter(h);
            % fvtool(filt)

            % Convert string inputs to char inputs
            [varargin{:}] = convertStringsToChars(varargin{:});

            c = obj.coeffs;
            num = c.Numerator;

            numFilters = size(num, 1);
            coder.internal.errorIf(numFilters>1 && obj.PartitionForReducedLatency, ...
                'dsp:system:FrequencyDomainFIRFilter:MultipleFiltersPartition');

            filt = cell(1, numFilters);
            filt{1} = dsp.FIRFilter('Numerator', num(1, :));

            if isLocked(obj)
                filt{1}(cast(1, obj.pDatatype));
            end

            fvt = fvtool(filt{1}, varargin{:});

            if nargout > 0
                varargout{1} = fvt;
            end

            if numFilters > 1
                for i = 2:numFilters
                    filt{i} = dsp.FIRFilter('Numerator', num(i, :));

                    if isLocked(obj)
                        filt{i}(cast(1, obj.pDatatype));
                    end

                    addfilter(fvt, filt{i}, varargin{:});
                end
            end
        end
    end

    methods(Access = protected)

        function flag = isPartitioned(obj)
            flag = obj.PartitionForReducedLatency;
        end

        function validateNumerator(obj, value)
            validateattributes(value, ...
                {'numeric'}, {'finite', 'nonempty', '2d'}, '', 'Numerator');
        end

        function validateProps(obj)
            if strcmp(obj.NumeratorDomain,'Time')
                 coder.internal.errorIf((size(obj.Numerator, 1)>1) && obj.PartitionForReducedLatency, ...
                        'dsp:system:FrequencyDomainFIRFilter:MultipleFiltersPartition');
                coder.internal.errorIf(obj.PartitionForReducedLatency && obj.PartitionLength > size(obj.Numerator, 2), ...
                    'dsp:system:FrequencyDomainFIRFilter:InvalidPartitionLength');
                coder.internal.errorIf(~obj.PartitionForReducedLatency && ~obj.inheritFFT && (isempty(obj.FFTLength) || obj.FFTLength < size(obj.Numerator, 2)), ...
                    'dsp:system:FrequencyDomainFIRFilter:InvalidFFTLength');
            else
                coder.internal.errorIf(...
                    obj.PartitionForReducedLatency && mod(size(obj.FrequencyResponse,1),2)==1, ...
                    'dsp:system:FrequencyDomainFIRFilter:FrequencyResponseSizePartition');
                coder.internal.errorIf(~obj.PartitionForReducedLatency && size(obj.FrequencyResponse, 2) < obj.NumeratorLength, ...
                    'dsp:system:FrequencyDomainFIRFilter:InvalidFFTLengthFreqDomain');
            end
        end

        function validatePropertiesImpl(obj)
            validateProps(obj);
        end

        function flag = inheritFFT(obj)
            flag = isempty(obj.FFTLength);
        end

        function numchans = getNumChannels(~,u)
            % GETNUMCHANNELS Return the number of input channels
            numchans = size(u,2);
        end

        function pnum = getNumeratorPrototype(obj)
            if strcmp(obj.NumeratorDomain,'Time')
                pnum =  obj.Numerator;
            else
                pnum =  obj.FrequencyResponse;
            end
        end
        
        function setupImpl(obj,u)

            %  Get the number of input channels
            numchans = getNumChannels(obj, u);

            % Disallow a first step with zero channels
            coder.internal.errorIf(numchans == 0,'dsp:system:Shared:EmptyFirstStep');

            obj.NumChannels = int32(numchans);
            obj.pDatatype = class(u);

            if strcmp(obj.NumeratorDomain,'Time')
                num =  obj.Numerator;
                [numFilters, obj.pNumeratorLength] = size(obj.Numerator);
            else
                num =  obj.FrequencyResponse;

                if ~isPartitioned(obj)
                    [numFilters, obj.pNumeratorLength] = size(obj.FrequencyResponse);
                else
                    obj.pNumeratorLength = numel(obj.FrequencyResponse);
                    numFilters = 1;
                end
            end

            isMIMO = false; 

            if numFilters>1
                if ~isPartitioned(obj)
                    isMIMO = true;
                    obj.pNumFilters = numFilters;
                else
                    coder.internal.errorIf(strcmp(obj.NumeratorDomain, 'Time'), ...
                        'dsp:system:FrequencyDomainFIRFilter:MultipleFiltersPartition');
                end
            end

            coder.internal.errorIf(isMIMO && ...
                mod(obj.pNumFilters, obj.NumChannels*obj.NumPaths)~=0, ...
                'dsp:system:FrequencyDomainFIRFilter:InvalidNumberofFilters');

            if strcmp(obj.NumeratorDomain,'Time')
                if ~obj.PartitionForReducedLatency
                    if  inheritFFT(obj)
                        obj.pFFTLength = 2 * obj.pNumeratorLength;
                    else
                        obj.pFFTLength =  obj.FFTLength;
                    end
                end
            else
                obj.pFFTLength = obj.pNumeratorLength;
            end

            % Select frequency-domain filter object
            if isMIMO
                if ~isPartitioned(obj)
                    if strcmp(obj.Method,'Overlap-save')

                        obj.pFilter = dsp.internal.MIMONoPartitionOS(...
                            'NumeratorDomain',obj.NumeratorDomain,...
                            'Numerator',num,...
                            'FFTLength',obj.pFFTLength,...
                            'NumeratorLength',obj.NumeratorLength,...
                            'FilterIsReal',obj.FilterIsReal, ...
                            'NumPaths', obj.NumPaths, ...
                            'SumFilteredOutputs', obj.SumFilteredOutputs);
                    else
                        obj.pFilter = dsp.internal.MIMONoPartitionOA(...
                            'NumeratorDomain',obj.NumeratorDomain,...
                            'Numerator',num,...
                            'FFTLength',obj.pFFTLength,...
                            'NumeratorLength',obj.NumeratorLength,...
                            'FilterIsReal',obj.FilterIsReal, ...
                            'NumPaths', obj.NumPaths, ...
                            'SumFilteredOutputs', obj.SumFilteredOutputs);
                    end
                end
            else
                if strcmp(obj.Method,'Overlap-save')
                    if ~isPartitioned(obj)
                        obj.pFilter = dsp.internal.NoPartitionOS('Domain',obj.NumeratorDomain,...
                            'Numerator',num,...
                            'FFTLength',obj.pFFTLength,...
                            'NumeratorLength',obj.NumeratorLength,...
                            'FilterIsReal',obj.FilterIsReal);
                    else
                        obj.pFilter = dsp.internal.PartitionOS('Domain',obj.NumeratorDomain,...
                            'Numerator',num,...
                            'PartitionLength',obj.PartitionLength,...
                            'FilterIsReal',obj.FilterIsReal);
                    end
                else
                    if ~isPartitioned(obj)
                        obj.pFilter = dsp.internal.NoPartitionOA('Domain',obj.NumeratorDomain,...
                            'Numerator',num,...
                            'FFTLength',obj.pFFTLength,...
                            'NumeratorLength',obj.NumeratorLength,...
                            'FilterIsReal',obj.FilterIsReal);
                    else
                        obj.pFilter = dsp.internal.PartitionOA('Domain',obj.NumeratorDomain,...
                            'Numerator',num,...
                            'PartitionLength',obj.PartitionLength,...
                            'FilterIsReal',obj.FilterIsReal);
                    end

                end

                setNumchans(obj.pFilter , numchans); 
                setup(obj.pFilter,u);
            end
        end

        function y = stepImpl(obj,u)
            y = obj.pFilter(u);
        end

        function resetImpl(obj)
            reset(obj.pFilter);
        end

        function releaseImpl(obj)
            release(obj.pFilter);
            obj.NumChannels = int32(-1);
        end

        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end

        function flag = isInactivePropertyImpl(obj, prop)
            flag = false;
            switch prop
                case 'FFTLength'
                    flag = strcmp(obj.NumeratorDomain,'Frequency') || isPartitioned(obj);
                case 'PartitionForReducedLatency'
                    %Partitioning is currently not supported if multiple
                    %filters are provided
                    flag = (strcmp(obj.NumeratorDomain,'Time') && size(obj.Numerator, 1)>1) &&...
                        ~isPartitioned(obj); 
                case 'PartitionLength'
                    flag = ~obj.PartitionForReducedLatency || strcmp(obj.NumeratorDomain,'Frequency') ||...
                    (strcmp(obj.NumeratorDomain,'Time') && size(obj.Numerator, 1)>1) ;
                case {'FilterIsReal','FrequencyResponse'}
                    flag =  strcmp(obj.NumeratorDomain,'Time');
                case 'NumeratorLength'
                    flag =  strcmp(obj.NumeratorDomain,'Time') || isPartitioned(obj);
                case 'Numerator'
                    flag =  strcmp(obj.NumeratorDomain,'Frequency');
                case {'NumPaths', 'SumFilteredOutputs'}
                    flag = (strcmp(obj.NumeratorDomain,'Time') && size(obj.Numerator, 1) == 1)||...
                        (strcmp(obj.NumeratorDomain,'Frequency') && size(obj.FrequencyResponse, 1) == 1)||...
                        isPartitioned(obj);
            end
        end

        function processTunedPropertiesImpl(obj)
            coder.internal.errorIf(strcmp(obj.NumeratorDomain,'Time') && obj.pNumeratorLength ~= size(obj.Numerator, 2),'dsp:system:FrequencyDomainFIRFilter:ChangedNumLength');
            coder.internal.errorIf((strcmp(obj.NumeratorDomain,'Time') && obj.pNumFilters ~= size(obj.Numerator, 1)) || ...
                (strcmp(obj.NumeratorDomain,'Frequency') && ~isPartitioned(obj) && obj.pNumFilters ~= size(obj.FrequencyResponse, 1)), ...
                'dsp:system:FrequencyDomainFIRFilter:ChangedNumFilters');
      
            if strcmp(obj.NumeratorDomain,'Time')
                obj.pFilter.Numerator = obj.Numerator;
            else
                obj.pFilter.Numerator = obj.FrequencyResponse;
            end
        end

        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            if isLocked(obj)
                s.pFilter      = matlab.System.saveObject(obj.pFilter);
                s.NumChannels  = obj.NumChannels;
                s.pFFTLength   = obj.pFFTLength;
                s.pDatatype    = obj.pDatatype;
                s.pNumeratorLength = obj.pNumeratorLength;
                s.pNumFilters  = obj.pNumFilters;
            end
        end

        function s = loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                obj.pFilter      = matlab.System.loadObject(s.pFilter);
                obj.NumChannels  = s.NumChannels;
                obj.pFFTLength   = s.pFFTLength;
                obj.pDatatype    = s.pDatatype;
                obj.pNumeratorLength = s.pNumeratorLength;
                if isfield(s, 'pNumFilters')
                    obj.pNumFilters  = s.pNumFilters;
                end
            end
            loadObjectImpl@matlab.System(obj, s, wasLocked);
        end

        function validateInputsImpl(obj,u)
            validateattributes(u, {'single', 'double'}, {'2d'},'','')
            if obj.NumChannels == -1 || obj.NumChannels == 0 || size(u,2) == 0
                return;
            end
            coder.internal.errorIf(size(u,2) ~= obj.NumChannels, ...
                'dsp:system:Shared:numChannels');
        end

        function c = coeffs(obj)
            % c = coeffs(obj) Return structure with filter coefficients
            %   c = coeffs(obj) returns the overall time domain filter
            %   coefficients in a structure.

            if strcmp(obj.NumeratorDomain,'Time')
                c.Numerator = obj.Numerator;
            else 
                if ~obj.PartitionForReducedLatency
                    num = ifft(obj.FrequencyResponse, [], 2);
                    c.Numerator = num(:, 1:obj.NumeratorLength);
                else
                    num = ifft(obj.FrequencyResponse, [], 1);
                    num = num(1:size(obj.FrequencyResponse,1)/2, :);
                    c.Numerator = num(:).'; 
                end
            end
        end
    end

    methods(Static, Access=protected)
        function group = getPropertyGroupsImpl
            % Modify order of display
            group =  matlab.system.display.Section(...
                'Title', 'Parameters', ...
                'PropertyList', {'Method','NumeratorDomain','Numerator',...
                'FrequencyResponse','NumeratorLength','FilterIsReal',...
                'NumPaths', 'SumFilteredOutputs',...
                'PartitionForReducedLatency','FFTLength',...
                'PartitionLength','Latency'},...
                'DependOnPrivatePropertyList', {'Latency'});
        end
    end

    methods (Static)
        function H = partitionNumerator(NUM,P)
            % partitionNumerator Partition numerator.
            % H = partitionNumerator(NUM,P) partitions the numerator, NUM,
            % using a partition length P. H is a 2*P-by-N matrix, where N
            % is the number of partitions. NUM must be a row vector.
            %
            % % Example:
            % h = fir1(299,.3);
            % H = dsp.FrequencyDomainFIRFilter.partitionNumerator(h,30);
            N = ceil(length(NUM) / P);
            pad = (N * P) - length(NUM);
            NUM = [NUM  zeros(1,pad,'like',NUM)];
            H = dsp.internal.PartitionOAOSBase.getIRFreqDomain(P, N, NUM, 2*P , class(NUM));
        end
    end
end
