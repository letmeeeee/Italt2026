classdef (StrictDefaults)PeakToRMS < matlab.System
%PeakToRMS Compute peak-to-root-mean-square of the vector elements
%   PTR = dsp.PeakToRMS returns a System object, PTR, that
%   computes the ratio of the maximum magnitude (peak) to the
%   root-mean-square (RMS) value in an input or a sequence of inputs.
%
%   PTR = dsp.PeakToRMS('PropertyName', PropertyValue, ...) returns a
%   PeakToRMS System object, PTR, with each specified property set to
%   the specified value.
%
%   Step method syntax:
%
%   Y = step(PTR, X) computes the peak-to-RMS ratio, Y, of floating point
%   input vector X. When the RunningPeakToRMS property is true, Y
%   corresponds to the peak-to-RMS ratio of the input elements over
%   successive calls to the step method.
%
%   Y = step(PTR, X, R) computes the peak-to-RMS ratio of the input
%   elements over successive calls to the step method. The object
%   optionally resets its state based on the reset input signal, R, and the
%   ResetCondition property. This is possible when you set both the
%   RunningPeakToRMS and the ResetInputPort properties to true.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   PeakToRMS methods:
%
%   step     - See above description for use of this method
%   release  - Allow property value and input characteristics changes
%   clone    - Create PeakToRMS object with same property values
%   isLocked - Locked status (logical)
%   reset    - Reset the states of running peak-to-RMS ratio
%
%   PeakToRMS properties:
%
%   RunningPeakToRMS     - Calculation over successive calls to step method
%   ResetInputPort       - Enables resetting in running peak-to-RMS mode
%   ResetCondition       - Reset condition for running peak-to-RMS mode
%   Dimension            - Dimension to operate along
%   CustomDimension      - Numerical dimension to operate along
%   DecibelScaledOutput  - Report output in decibels (dB)
%
%   % EXAMPLE #1: Determine the peak-to-RMS ratio of a vector input
%      in1 = (1:10)';
%      pr1 = dsp.PeakToRMS;
%      y1  = pr1(in1)
%
%   % EXAMPLE #2: Determine the peak-to-RMS ratio of a matrix input
%      in2 = magic(4);
%      pr2 = dsp.PeakToRMS;
%      pr2.Dimension = 'All';
%      y2  = pr2(in2)
%
%   See also dsp.PeakToRMS

%   Copyright 2008-2021 The MathWorks, Inc.

%#ok<*EMCLS>
%#codegen

  properties (Nontunable)
    %ResetCondition Reset condition for running peak-to-RMS mode
    %   Specify the event to reset the running peak-to-RMS as one of
    %   'Rising edge' | 'Falling edge' | 'Either edge' | 'Non-zero', where
    %   the default is 'Non-zero'. This property is applicable when the
    %   ResetInputPort property is true. 
    ResetCondition = 'Non-zero'
    %Dimension Dimension to operate along    
    %   Specify the dimension along which to calculate the peak-to-RMS
    %   ratio as one of 'All' | 'Row' | 'Column' | 'Custom', where the
    %   default is 'Column'. This property is applicable when the
    %   RunningPeakToRMS property is false.
    Dimension = 'Column'
  
    %CustomDimension Numerical dimension to operate along
    %   Specify the dimension as a positive integer, along which the
    %   peak-to-RMS ratio is computed. The value of this property cannot
    %   exceed the number of dimensions in the input signal. This property
    %   is applicable when Dimension property is 'Custom'. The default
    %   value of this property is 1.
    CustomDimension (1, 1) {mustBePositive, mustBeInteger} = 1

    %RunningPeakToRMS Calculation over successive calls to step method
    %   Set this property to true to enable the calculation of the
    %   peak-to-RMS ratio over successive calls to the step method. The
    %   default value of this property is false.
    RunningPeakToRMS (1, 1) logical = false
    %ResetInputPort Enables resetting in running peak-to-RMS mode 
    %   Set this property to true to enable resetting the running RMS. When
    %   the property is set to true, a reset input must be specified to the
    %   step method to reset the running peak-to-RMS ratio. This property
    %   is applicable when the RunningPeakToRMS property is true. The
    %   default value of this property is false.
    ResetInputPort (1, 1) logical = false
    %DecibelScaledOutput report output in decibels (dB)
    %   Set this property to true to enable output in dB. Set this
    %   property to false to report output as a ratio. The default value
    %   of this property is false.
    DecibelScaledOutput (1, 1) logical = false
  end
  
  properties(Constant, Hidden)
    ResetConditionSet = dsp.CommonSets.getSet('ResetCondition');
    DimensionSet = dsp.CommonSets.getSet('Dimension');
  end

  properties(Access = private)
    cMax
    cRMS
  end
  
  methods
    function obj = PeakToRMS(varargin)
      setProperties(obj, nargin, varargin{:});
    end
  end

  methods(Access=protected)

    function flag = isInactivePropertyImpl(obj, prop)
      if obj.RunningPeakToRMS
        flag = strcmp(prop,'Dimension') ...
            || strcmp(prop,'CustomDimension') ...
            || ~obj.ResetInputPort && strcmp(prop,'ResetCondition');
      else
        flag = strcmp(prop,'ResetInputPort') ...
            || strcmp(prop,'ResetCondition') ...
            || ~strcmp(obj.Dimension, 'Custom') ...
                && strcmp(prop,'CustomDimension');
      end
    end
    

    function flag = isInputSizeMutableImpl(~,~)
      flag = true;
    end    
    
    function num = getNumInputsImpl(obj)
      num = 1 + (obj.RunningPeakToRMS && obj.ResetInputPort);
    end
        
    function validateInputsImpl(obj, varargin)
        
      coder.internal.errorIf(~isfloat(varargin{1}),...
                             'measure:PeakToRMS:inDataTypeNotFloat');
                         
      coder.internal.errorIf(~isInactivePropertyImpl...
                            (obj,'CustomDimension') ...
                            && ndims(varargin{1}) < obj.CustomDimension,...
                            'measure:PeakToRMS:inSigDimNotSetting');

      coder.internal.errorIf( nargin>2 && (~isscalar(varargin{2}) ...
                             || ~isreal(varargin{2})),...
                            'measure:PeakToRMS:inputMustBeRealScalar','R');
   
     coder.internal.errorIf( ...
                obj.RunningPeakToRMS && numel(size(varargin{1})) > 2,...
                             'measure:PeakToRMS:inSigMustBe2DForFrames');
                                               
    end
    
    function setupImpl(obj, varargin)      
      if obj.RunningPeakToRMS
        if obj.ResetInputPort
          obj.cMax = dsp.internal.Maximum( ...
                 'RunningMaximum',true, ...
                 'ResetInputPort', true, ...
                 'ResetCondition', obj.ResetCondition);
          obj.cRMS = dsp.internal.RMS( ...
                 'RunningRMS',true, ...
                 'ResetInputPort', true, ...
                 'ResetCondition', obj.ResetCondition);
        else
          obj.cMax = dsp.internal.Maximum( ...
                 'RunningMaximum',true);
          obj.cRMS = dsp.internal.RMS( ...
                 'RunningRMS',true);
        end
      else
        if strcmp(obj.Dimension,'Custom')
          obj.cMax = dsp.internal.Maximum('Dimension','Custom', ...
                                 'CustomDimension', obj.CustomDimension);
          obj.cRMS = dsp.internal.RMS('Dimension','Custom', ...
                             'CustomDimension', obj.CustomDimension);
        else
          obj.cMax = dsp.internal.Maximum('Dimension', obj.Dimension);
          obj.cRMS = dsp.internal.RMS('Dimension', obj.Dimension);
        end
      end
    end

    function y = stepImpl(obj, varargin)
      x = abs(varargin{1});
      max = step(obj.cMax,x, varargin{2:end});
      rms = step(obj.cRMS,x, varargin{2:end});
      y = max ./ rms;
      if obj.DecibelScaledOutput
        y = 20.*log10(y);
      end
    end
    
    function resetImpl(obj)
        reset(obj.cMax);
        reset(obj.cRMS);
    end
    
    function releaseImpl(obj)
        release(obj.cMax);
        release(obj.cRMS);
    end
    
    function s = saveObjectImpl(obj)
        s = saveObjectImpl@matlab.System(obj);
        if isLocked(obj)
            s.cMax      = matlab.System.saveObject(obj.cMax);
            s.cRMS      = matlab.System.saveObject(obj.cRMS);
        end
    end
    
    function loadObjectImpl(obj, s, wasLocked)
        if wasLocked
            obj.cMax     =  matlab.System.loadObject(s.cMax);
            obj.cRMS      =  matlab.System.loadObject(s.cRMS);
        end
        % Call the base class method
        loadObjectImpl@matlab.System(obj, s);
    end
    
  end

  methods(Static,Hidden,Access=protected)
    function groups = getPropertyGroupsImpl
      props = {...
        'RunningPeakToRMS', ...
        'ResetInputPort', ...
        'ResetCondition', ...
        'Dimension', ...
        'CustomDimension', ...
        'DecibelScaledOutput'
        };
      groups = matlab.system.display.Section('Title', 'Parameters',...
                                             'PropertyList', props);
    end
  end
end

