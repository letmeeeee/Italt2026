classdef (StrictDefaults)AllpassFilter < matlab.System & dsp.internal.FilterAnalysis
    %AllpassFilter Single-section or cascaded allpass filter with
    %   Minimum-multiplier, Lattice, or Wave Digital structure
    %
    %   APF = dsp.AllpassFilter returns an allpass filter APF that filters
    %   each channel of the input signal independently using an allpass
    %   filter with the default structure and coefficients.
    %
    %   APF = dsp.AllpassFilter('PropertyName', PropertyValue, ...) returns
    %   an allpass filter, APF, with each specified property set to a
    %   specified value.
    %
    %   Step method syntax:
    %
    %   Y = step(APF, X) filters the real or complex input signal X using
    %   the specified filter to produce the output Y. Each column of X is
    %   treated and filtered independently as a separate channel over time.
    %
    %   System objects may be called directly like a function instead of
    %   using the step method. For example, y = step(obj, x) and y = obj(x)
    %   are equivalent.
    %
    %   AllpassFilter methods:
    %
    %   step                - See above description for use of this method.
    %   release             - Allow changes to non-tunable properties
    %                         values and input characteristics.
    %   clone               - Create an allpass filter object with the same
    %                         property values and internal states.
    %   isLocked            - Locked status (logical).
    %   reset               - Reset the internal states to initial
    %                         conditions.
    %
    %   AllpassFilter properties:
    %
    %   Structure                 - Internal allpass filter structure.
    %   AllpassCoefficients       - Coefficients used with 'Minimum
    %                               multiplier' structure.
    %   LatticeCoefficients       - Coefficients used with 'Lattice'
    %                               structure.
    %   WDFCoefficients           - Coefficients used with the 'Wave Digital
    %                               Filter' structure.
    %   TrailingFirstOrderSection - Is the last section first order.
    %
    %   This filter supports several filter analysis methods. For more
    %   information, type dsp.AllpassFilter.helpFilterAnalysis.
    %
    %   % EXAMPLE: Implement a lowpass filter using two allpass filters.
    %
    %     Fs  = 48000;    % in Hz
    %     FL = 1024;
    %     apfilt1 = dsp.AllpassFilter('AllpassCoefficients',...
    %                        [-0.710525516540603   0.208818210000029]);
    %     apfilt2 =  dsp.AllpassFilter('AllpassCoefficients',...
    %                        [-0.940456403667957   0.6;...
    %                         -0.324919696232907   0],...
    %                         'TrailingFirstOrderSection',true);
    %     tfestim = dsp.TransferFunctionEstimator('FrequencyRange',...
    %           'onesided','SpectralAverages',2);
    %     scope = dsp.ArrayPlot('PlotType','Line','YLimits', [-80 5],...
    %         'YLabel','Magnitude (dB)','SampleIncrement', Fs/FL,...
    %         'XLabel','Frequency (Hz)','Title','Magnitude Response',...
    %         'ShowLegend', true);
    %     tic;
    %     while toc < 5
    %         in  = randn(FL,1);
    %         out = 0.5.*(apfilt1(in) + apfilt2(in));
    %         A = tfestim(in, out);
    %         scope(db(A));
    %     end
    %
    %   See also dsp.CoupledAllpassFilter, dsp.BiquadFilter, dsp.IIRFilter,
    %   dsp.IIRHalfbandInterpolator, dsp.IIRHalfbandDecimator.

    %   Copyright 2012-2023 The MathWorks, Inc.

    %#codegen
    properties(Nontunable)
        %Structure Internal allpass structure
        %   Specify the internal allpass filter implementation structure as
        %   one of {'Minimum multiplier' | 'Wave Digital Filter' |
        %   'Lattice'}. Each structure uses a different coefficients set,
        %   independently stored in the corresponding object property. The
        %   default is 'Minimum multiplier'.
        Structure  (1, :) char {matlab.system.mustBeMemberMessageID(Structure, ...
                    {'dsp:system:AllpassFilter:Structure_Minimummultiplier',;...
                     'dsp:system:AllpassFilter:Structure_WaveDigitalFilter',;...
                     'dsp:system:AllpassFilter:Structure_Lattice'})} = 'Minimum multiplier';
    end
    properties
        %AllpassCoefficients Allpass polynomial coefficients
        %   Specify the real allpass polynomial filter coefficients. This
        %   property is only applicable when the Structure property is set
        %   to 'Minimum multiplier'. The value of this property can be
        %   either a Nx1 or Nx2 matrix of N first or second-order allpass
        %   sections. The default value for this property is [-2^(-1/2)
        %   0.5]. This property is tunable.
        AllpassCoefficients = [-2^(-1/2), 1/2]

        %LatticeCoefficients Lattice allpass coefficients
        %   Specify the real or complex allpass coefficients as lattice
        %   reflection coefficients form. This property is only applicable
        %   when the Structure property is set to 'Lattice'. The value of
        %   this property can be either a row vector  or a column vector.
        %   The default value for this property is [-2^(1/2)/3, 1/2]. This
        %   property is tunable.
        LatticeCoefficients = [-2^(1/2)/3, 1/2]
    end

    properties(Nontunable)
        %WDFCoefficients Wave Digital Filter allpass coefficients
        %   Specify the real allpass coefficients in Wave Digital Filter
        %   form. This property is only applicable when the Structure
        %   property is set to 'Wave Digital Filter'. The value of this
        %   property can be either a Nx1 or Nx2 matrix of N first or
        %   second-order allpass sections.  All elements must have absolute
        %   value <= 1. The default value for this property is [1/2,
        %   -2^(1/2)/3].
        WDFCoefficients = [1/2, -2^(1/2)/3]

        %TrailingFirstOrderSection Indicate if last section is first order
        %   For the minimum-multiplier or wave digital structure, specify
        %   whether the last section is a first order section (true) or
        %   whether it is a second order section (false). When set to true,
        %   the second element of the last row of the N-by-2 matrix is
        %   ignored. The default is false.
        TrailingFirstOrderSection (1, 1) logical = false
    end

    properties(Access = private)

        privAllpassFilter

    end

    methods

        % Constructor

        function obj = AllpassFilter(varargin)
            % Support name-value pair arguments
            setProperties(obj, nargin, varargin{:});

        end

        % Accessor methods

        function set.AllpassCoefficients(obj, value)
            validateattributes(value, {'numeric'}, ...
                {'finite','real'},...
                'set.AllpassCoefficients','AllpassCoefficients');
            [r,c] = size(value);
            if (r > 1) && (c > 2)
                coder.internal.errorIf(true, ['dsp:system',...
                    ':AllpassFilter:coeffSize']);
            end
            obj.AllpassCoefficients = value;
        end

        function set.WDFCoefficients(obj, value)
            validateattributes(value, {'numeric'}, {'finite', 'real'}, ...
                'set.WDFCoefficients', 'WDFCoefficients');
            [~,c] = size(value);
            if (c > 2)
                coder.internal.errorIf(true, ['dsp:system',...
                    ':AllpassFilter:wdfcoeffSize']);
            end
            if(any(any(abs(value) > 1)))
                coder.internal.errorIf(true, ['dsp:system',...
                    ':AllpassFilter:wdfCoeBiggerThanOne'])
            end
            obj.WDFCoefficients = value;
        end

        function set.LatticeCoefficients(obj, value)
            validateattributes(value, {'numeric'}, ...
                {'finite'},...
                'set.LatticeCoefficients','LatticeCoefficients');
            if all(size(value)>1)
                coder.internal.errorIf(true, ['dsp:system',...
                    ':AllpassFilter:latticeCoeffSize']);
            end
            obj.LatticeCoefficients = value;
        end

    end

    methods (Access = protected)

        % Relevant to matlab.System

        function setupImpl(obj, u)
            setPrivFilter(obj);
            setup(obj.privAllpassFilter, u);
        end

        function releaseImpl(obj)
            release(obj.privAllpassFilter);
        end

        function resetImpl(obj)

           reset(obj.privAllpassFilter);

        end

        function x = stepImpl(obj, u)

            x = step(obj.privAllpassFilter,u);
        end


        function validateInputsImpl(obj, u)
            % Invoked at first call to setup/step, and then every time the
            % input dimensions change
            validateattributes(u, {'single', 'double'}, {'2d'},'','');


            % Cache input data type for filter analysis
            if isempty(coder.target)
                if ~isempty(u)
                    cacheInputDataType(obj,u)
                end
            end
        end

        function flag = isInputSizeMutableImpl(~,~)
            % Support mutable input size
            flag = true;
        end

        function flag = isInactivePropertyImpl(obj, propertyName)
            flag = false;

            if(strcmp(propertyName, 'AllpassCoefficients'))
                flag = ~strcmp(obj.Structure, 'Minimum multiplier');
            elseif(strcmp(propertyName, 'TrailingFirstOrderSection'))
                switch obj.Structure
                    case 'Minimum multiplier'
                        flag = iscell(obj.AllpassCoefficients);
                    case 'Wave Digital Filter'
                        flag = iscell(obj.WDFCoefficients);
                    otherwise %Lattice
                        flag = true;
                end
            elseif(strcmp(propertyName, 'WDFCoefficients'))
                flag = ~strcmp(obj.Structure, 'Wave Digital Filter');
            elseif(strcmp(propertyName, 'LatticeCoefficients'))
                flag = ~strcmp(obj.Structure, 'Lattice');
            end
        end


        function s = saveObjectImpl(obj)
            % Default implementation saves all public properties
            s = saveObjectImpl@matlab.System(obj);

            if isLocked(obj)
                % All the following are set at setup
                s.privAllpassFilter = matlab.System.saveObject(obj.privAllpassFilter);
            end
            % Save filter analysis class properties
            s = saveFA(obj, s);
        end

        function s = loadObjectImpl(obj, s, wasLocked)
            % Re-load state if saved version was locked
            if wasLocked
                % All the following were set at setup
                if isfield(s,'privAllpassFilter')
                    obj.privAllpassFilter = matlab.System.loadObject(s.privAllpassFilter);
                else
                    setPrivFilter(obj);
                end

                obj.pLockedArithmetic = s.pLockedArithmetic;
            end

            % Call base class method
            loadObjectImpl@matlab.System(obj,s,wasLocked);

            % Load filter analysis class properties
            loadFA(obj, s, wasLocked);
        end

        function y = infoImpl(obj,varargin)
            if ~isLocked(obj)
                setPrivFilter(obj);
            end
            y = infoImpl(obj.privAllpassFilter,varargin{:});
        end

        % Relevant to dsp.internal.FilterAnalysis

        function d = convertToDFILT(obj, arith)
            % Returns equivalent dfilt to current object.
            if ~isLocked(obj)
                setPrivFilter(obj);
            end
            d = convertToDFILT(obj.privAllpassFilter, arith);
            d.PersistentMemory = true;
        end

        function processTunedPropertiesImpl(obj)
            switch obj.Structure
                case 'Minimum multiplier'
                    obj.privAllpassFilter.AllpassCoefficients = obj.AllpassCoefficients;
                case 'Lattice'
                    obj.privAllpassFilter.LatticeCoefficients = obj.LatticeCoefficients;
            end
        end


        function setPrivFilter(obj)
            if isempty(coder.target)
                switch obj.Structure
                    case 'Minimum multiplier'
                        if iscell(obj.AllpassCoefficients) || ...
                                (isrow(obj.AllpassCoefficients) && length(obj.AllpassCoefficients) > 2)
                            obj.privAllpassFilter = dsp.internal.LegacyAllpassFilter(...
                                'AllpassCoefficients',obj.AllpassCoefficients);
                        else
                            obj.privAllpassFilter = dsp.internal.NewAllpassFilter(...
                                'AllpassCoefficients',obj.AllpassCoefficients);
                            obj.privAllpassFilter.TrailingFirstOrderSection = ...
                                obj.TrailingFirstOrderSection;
                        end

                    case 'Lattice'
                        if iscell(obj.LatticeCoefficients)
                            obj.privAllpassFilter = dsp.internal.LegacyAllpassFilter(...
                                'Structure','Lattice',...
                                'LatticeCoefficients',obj.LatticeCoefficients);
                        else
                            obj.privAllpassFilter = dsp.internal.NewAllpassFilter(...
                                'Structure','Lattice',...
                                'LatticeCoefficients',obj.LatticeCoefficients);
                        end

                    case 'Wave Digital Filter'
                        if iscell(obj.WDFCoefficients) || ...
                                (isrow(obj.WDFCoefficients) && length(obj.WDFCoefficients) > 2)
                            obj.privAllpassFilter = dsp.internal.LegacyAllpassFilter(...
                                'Structure', 'Wave Digital Filter', ...
                                'WDFCoefficients',obj.WDFCoefficients);
                        else
                            obj.privAllpassFilter = dsp.internal.NewAllpassFilter(...
                                'Structure','Wave Digital Filter',...
                                'WDFCoefficients',obj.WDFCoefficients, ...
                                'TrailingFirstOrderSection', obj.TrailingFirstOrderSection);
                        end


                end

            else
                switch obj.Structure
                    case 'Minimum multiplier'
                        obj.privAllpassFilter = dsp.internal.NewAllpassFilter(...
                            'AllpassCoefficients',obj.AllpassCoefficients);
                        obj.privAllpassFilter.TrailingFirstOrderSection = ...
                            obj.TrailingFirstOrderSection;
                    case 'Lattice'
                        obj.privAllpassFilter = dsp.internal.NewAllpassFilter(...
                            'Structure','Lattice',...
                            'LatticeCoefficients',obj.LatticeCoefficients);
                    case 'Wave Digital Filter'
                        obj.privAllpassFilter = dsp.internal.NewAllpassFilter(...
                            'Structure','Wave Digital Filter',...
                            'WDFCoefficients',obj.WDFCoefficients, ...
                            'TrailingFirstOrderSection', obj.TrailingFirstOrderSection);
                end
            end
        end

    end

    methods(Hidden)
        function setActiveCoefficients(obj, coe)
            if ~isLocked(obj)
                setPrivFilter(obj);
            end
            setActiveCoefficients(obj.privAllpassFilter, coe);
        end
        function flag = isPropertyActive(obj,prop)
            flag = ~isInactivePropertyImpl(obj, prop);
        end
        function restrictionsCell = getFixedPointRestrictions(obj,~)
            if ~isLocked(obj)
                setPrivFilter(obj);
            end
            restrictionsCell = getFixedPointRestrictions(obj.privAllpassFilter);
        end
        function props = getFixedPointProperties(obj)
            if ~isLocked(obj)
                setPrivFilter(obj);
            end
            props = getFixedPointProperties(obj.privAllpassFilter);
        end
        function props = getNonFixedPointProperties(obj)
            if ~isLocked(obj)
                setPrivFilter(obj);
            end
            props = getNonFixedPointProperties(obj.privAllpassFilter);
        end
    end

    methods (Static)
        function g = poly2wdf(c)
            %poly2wdf Converts standard single-section allpass polynomial
            % coefficients into Wave Digital Filter form.
            % Acceptable section orders are 1, 2 and 4. If the order is 4
            % then the first and third coefficients must be zeros.
            %
            %   % EXAMPLE: Convert a single-section dsp.AllpassFilter with
            %   % Minimum multiplier structure into an equivalent Wave
            %   % Digital Filter form
            %
            %   hReference = dsp.AllpassFilter(...
            %       'AllpassCoefficients', [0.1 0.2]);
            %   cPolycoeffs = hReference.AllpassCoefficients;
            %   wdfcoeffs = dsp.AllpassFilter.poly2wdf(cPolycoeffs{1});
            %   hWDFVersion = dsp.AllpassFilter(...
            %     'Structure', 'Wave Digital Filter', ...
            %     'WDFCoefficients', wdfcoeffs);
            %   % Display both filters in fvtool and verify all main
            %   % responses are equal
            %   fvtool(hReference, hWDFVersion)
            %
            % Reference:
            % M. Lutovac, D. Tosic, B. Evans.
            % Filter Design for Signal Processing using MATLAB and
            % Mathematica. Prentice Hall, 2001.

            validateattributes(c, {'single', 'double'}, {'row'});
            if(all(length(c) ~= [1,2,4]) || ...
                    (length(c) == 4 && ~all(c([1,3])==0)))
                coder.internal.errorIf(true, ['dsp:system',...
                    ':AllpassFilter:wdfSectionOrdersOnly124poly'])
            end
            switch length(c)
                case 1
                    g = c;
                case 2
                    g = [c(2), c(1)/(1+c(2))];
                case 4
                    % This works only when c is of the form [0;c(2);0;c(4)]
                    g = [c(4), 0, c(2)/(1+c(4)), 0];
                otherwise
                    g = [];
                    assert(false)
            end
        end

        function c = wdf2poly(g)
            %wdf2poly Converts single-section Wave Digital Filter allpass
            % coefficients into standard polynomial form.
            % Acceptable section orders are 1, 2 and 4. If the order is 4
            % then the second and fourth coefficients must be zeros.
            %
            %   % EXAMPLE: Convert a single-section dsp.AllpassFilter with
            %   % Wave Digital Filter structure into an equivalent Minimum
            %   % multiplier form.
            %
            %   hReference = dsp.AllpassFilter(...
            %       'Structure', 'Wave Digital Filter', ...
            %       'WDFCoefficients', [0.1 0.2]);
            %   cWdfcoeffs = hReference.WDFCoefficients;
            %   polycoeffs = dsp.AllpassFilter.wdf2poly(cWdfcoeffs{1});
            %   hMMVersion = dsp.AllpassFilter(...
            %       'AllpassCoefficients', polycoeffs);
            %   % Display both filters in fvtool and verify all main
            %   % responses are equal
            %   fvtool(hReference, hMMVersion)
            %
            % Reference:
            % M. Lutovac, D. Tosic, B. Evans.
            % Filter Design for Signal Processing using MATLAB and
            % Mathematica. Prentice Hall, 2001.

            validateattributes(g, {'single', 'double'}, {'row'});
            if(all(length(g) ~= [1,2,4]) || ...
                    (length(g) == 4 && ~all(g([2,4])==0)))
                coder.internal.errorIf(true, ['dsp:system',...
                    ':AllpassFilter:wdfSectionOrdersOnly124wdf'])
            end
            switch(length(g))
                case 1
                    % Order 1
                    c = g;
                case 2
                    % Order 2
                    c = [g(2)*(1 + g(1)), g(1)];
                case 4
                    % Order 4
                    c = [0, g(3)*(1 + g(1)), 0, g(1)];
                otherwise
                    c = [];
                    assert(false)
            end
        end
    end
end
