classdef (StrictDefaults) IIRHalfbandInterpolator < dsp.internal.IIRHalfbandBase
%IIRHalfbandInterpolator Interpolate by a factor of two using polyphase IIR
%   This System object lets you design and use interpolator that implements
%   IIR halfband structures. Allpass filters are used in the polyphase
%   branches. Filters can be designed either using elliptic or quasi-linear
%   phase design methods. You can convert this System object to a synthesis
%   filter bank.
%
%   IIRHALFBANDINTERP = dsp.IIRHalfbandInterpolator returns a System
%   object, IIRHALFBANDINTERP, that interpolates each channel of the input
%   signal by a factor of 2 using IIR halfband filters.
%
%   IIRHALFBANDINTERP = dsp.IIRHalfbandInterpolator(Name=Value, ...)
%   returns an IIR halfband interpolator System object, IIRHALFBANDINTERP,
%   with each specified property set to the specified value.
%
%   Step method syntax:
%
%   Y = step(IIRHALFBANDINTERP,X) outputs the interpolated values, Y, of
%   the input signal, X. A Ki-by-N input matrix is treated as N independent
%   channels, and the System object interpolates each channel over time and
%   generates a Ko-by-N output matrix. Ko = 2*Ki, where 2 is the
%   interpolation factor. The object supports real and complex
%   floating-point inputs.
%
%   Y = step(IIRHALFBANDINTERP,X1,X2) computes the output, Y of the
%   synthesis filter bank, IIRHALFBANDINTERP. IIRHALFBANDINTERP acts as a
%   synthesis filter bank when 'FilterBankInputPort' property of the System
%   object is true. X1 and X2 are two power-complementary input matrices of
%   the same data type and size Ki-by-N. N is the number of independent
%   channels in each input signal. The System object generates two
%   polyphase branch signals by subtracting and adding the two inputs
%   respectively. The output signals from the two branches are commuted to
%   form the resultant signal, Y, a Ko-by-N matrix. Ko = 2*Ki, where 2 is
%   the interpolation factor.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   IIRHalfbandInterpolator methods:
%   step     - See above description for use of this method
%   release  - Allow property value and input characteristics changes
%   clone    - Create IIR halfband interpolator object with same 
%              property values
%   isLocked - Locked status (logical)
%   reset    - Reset the internal states to initial conditions
%
%   IIRHalfbandInterpolator properties:
%
%   SampleRate           - Input sample rate (Hz)
%   Specification        - Filter design parameter specification
%   FilterOrder          - Order of the filter
%   TransitionWidth      - Transition width of the IIR halfband filter
%   StopbandAttenuation  - Minimum attenuation needed in stopband of
%                          the IIR halfband filter (dB)
%   DesignMethod         - Design method for the IIR halfband filter
%   NormalizedFrequency  - Provide normalized frequencies for filter
%                          specifications
%   FilterBankInputPort  - Option to use object as synthesis filter bank
%   Structure            - Filter structure used in coefficient mode
%   AllpassCoefficients1 - Branch 1 coefficients, minimum multiplier
%   AllpassCoefficients2 - Branch 2 coefficients, minimum multiplier
%   WDFCoefficients1     - Branch 1 coefficients, wave digital  
%   WDFCoefficients2     - Branch 2 coefficients, wave digital
%   HasPureDelayBranch   - Branch 1 is a delay
%   Delay                - Value of branch 1 delay, in samples
%   HasTrailingFirstOrderSection - Branch 2, last section is 1st order 
%
%   This System object supports several filter analysis methods. For
%   more information, type
%   dsp.IIRHalfbandInterpolator.helpFilterAnalysis.
%
%   % Example 1: Interpolate a signal and plot the spectra 
%   
%   Fs = 5000; % Units: Hz
%   frameSize = 2000;
%   
%   SW = dsp.SineWave(Frequency=400, SampleRate=Fs, ...
%                     SamplesPerFrame=frameSize);
%   InputSA = spectrumAnalyzer(PlotAsTwoSidedSpectrum=false, ...
%                     SampleRate=Fs, ShowLegend=true, ...
%                     ChannelNames="Input");
%   OutputSA = spectrumAnalyzer(PlotAsTwoSidedSpectrum=false, ...
%                     SampleRate=Fs*2, ShowLegend=true, ...
%                     ChannelNames="Output");
%   
%   % Construct IIR Half band Interpolator
%   IIRHALFBANDINTERP = dsp.IIRHalfbandInterpolator(...
%       Specification="Filter order and transition width",...
%       FilterOrder=15, TransitionWidth=400, ...
%       SampleRate=Fs);
%   
%   for idx = 1:2000
%       Input = SW()+randn(frameSize,1);
%       Output = IIRHALFBANDINTERP(Input);
%       % Plot on scopes
%       InputSA(Input);
%       OutputSA(Output);
%   end
%   
%   % Example 2: Design a quasi-linear phase IIR halfband interpolator and
%   % display its frequency response
%   
%   IIRHALFBANDINTERP = dsp.IIRHalfbandInterpolator(...
%                       DesignMethod="Quasi-linear phase");
%   
%   % Obtain filter coefficients
%   c = coeffs(IIRHALFBANDINTERP);
%   
%   % Plot the Magnitude and Phase response
%   fvtool(IIRHALFBANDINTERP,Analysis="freq")
%
%   See also dsp.IIRHalfbandDecimator, dsp.FIRHalfbandInterpolator,
%            designHalfbandIIR, dsp.CoupledAllpassFilter

%   Copyright 2015-2023 The MathWorks, Inc.

%#codegen
%#ok<*EMCA>
    properties (Nontunable)
        % SampleRate Input sample rate (Hz)
        %   Specify the sampling rate of the input in Hertz as a finite
        %   numeric scalar. the default is 22.0 MHz.
        SampleRate = 22.05e3;
        %TransitionWidth Transition width 
        %   Specify the transition width for the designed IIR halfband
        %   filter as a finite positive scalar. Specify the value of
        %   transition width in Hertz when NormalizedFrequency is set to
        %   false and in normalized units when NormalizedFrequency is set
        %   to true. The transition width must be less than half the input
        %   sample rate. This property applies when the Specification is
        %   either 'Filter order and transition width' or 'Transition width
        %   and stopband attenuation'. The default value of this property
        %   is 4100 Hz.
        TransitionWidth = 4.1e3;
    
        %FilterBankInputPort Input highpass subband
        %   Specify if the interpolator should be a synthesis filter bank,
        %   as a logical scalar. When this property is set to false, the
        %   object acts as an interpolator. If the property is set to true,
        %   the object takes two inputs to the step method and acts as a
        %   synthesis filter bank. The default of this property is false.
        FilterBankInputPort (1, 1) logical = false
    end

    properties (Access = protected, Nontunable)
        % pSR Default sample rate
        pSR = 22.05e3;
    end
        
    %----------------------------------------------------------------------
    % Public methods
    %----------------------------------------------------------------------
    methods
        function obj = IIRHalfbandInterpolator(varargin)
            % Constructor
            % Support name-value pair arguments
            setProperties(obj, nargin, varargin{:});
            if obj.NormalizedFrequency  
                isTransitionWidthSpecified = false;
                for i = 1:2:numel(varargin)
                    if strcmp(varargin{i}, 'TransitionWidth')
                        isTransitionWidthSpecified = true;
                    end
                end
                if ~isTransitionWidthSpecified
                    obj.TransitionWidth = 4.1e3/(22050);
                end
            end
        end
        %------------------------------------------------------------------      
        function set.SampleRate(obj,val)
            validateattributes(val,...
                {'double','single'}, ...
                {'real','scalar','positive','finite'},...
                '','SampleRate');
            obj.SampleRate = val;
            postProcessSampleRate(obj,val);
        end
        %------------------------------------------------------------------
        function set.TransitionWidth(obj,TW)
            validateattributes(TW,{'single','double'},{'real','positive',...
                'finite','scalar'},'','TransitionWidth');
            obj.TransitionWidth = TW;
            needToDesignFilters(obj);
        end
        %------------------------------------------------------------------
        function realizemdl(obj,varargin)
            if obj.FilterBankInputPort
                warning(message('dsp:system:FIRHalfbandInterpolator:realizemdlFilterBank'));
            end
            realizemdl@dsp.internal.FilterAnalysis(obj, varargin{:});
        end
    end
    %----------------------------------------------------------------------
    % Protected methods
    %----------------------------------------------------------------------
    methods (Access = protected)
        function validateInputsImpl(obj,varargin)
            
            % Checks on first input
            u1 = varargin{1};
            validateInputsImpl@dsp.internal.IIRHalfbandBase(obj, u1);

            if obj.FilterBankInputPort
                % Second input needs to be the same type and size as
                % first input
                u2 = varargin{2};
                validateattributes(u2, {'single','double'},...
                {'finite','2d'},'','input');
                coder.internal.errorIf(~isequal(size(u1),size(u2)),...
                    'dsp:system:SubbandSynthesisFilter:inputsSizeMismatch');
                coder.internal.errorIf(~strcmp(class(u1),class(u2)),...
                    'dsp:system:SubbandSynthesisFilter:inputsDataTypeMismatch2');
            end
        end
        %------------------------------------------------------------------
        function validatePropertiesImpl(obj)
            validatePropertiesImpl@dsp.internal.IIRHalfbandBase(obj);
        end
        %------------------------------------------------------------------
        function crossValidateProperties(obj)
            outputFs = getSampleRate(obj)*2;
            if ~strcmp(obj.Specification, 'Filter order and stopband attenuation')
                % Transition width must be less than half the output sample rate
                coder.internal.errorIf(obj.TransitionWidth >= outputFs/2, ...
                    'dsp:system:FIRHalfbandInterpolator:TransitionWidth', ...
                    floor(outputFs/2),...
                    round((outputFs/2 - floor(outputFs/2)) * 10));
            end
        end
        %------------------------------------------------------------------
        function y = stepImpl(obj, varargin)
            
            if obj.FilterBankInputPort
                u1 = varargin{1}-varargin{2};
                u2 = varargin{1}+varargin{2};
            else
                u1 = varargin{1};
                u2 = varargin{1};
            end
            
            nc = getNumChannels(obj,u1);
            
            if obj.pCachedNoDelay 

                % Local copies of states
                Z1 = obj.pStates.Branch1;
                Z2 = obj.pStates.Branch2;
                
                if obj.pCachedUsesMinMult 
                    [y1,Z1] = dsp.internal.AllpassMinMult.stepMinMultCascade(...
                        u1, Z1, obj.pBranchInfo1, obj.pBranchCoef1);
                    [y2,Z2] = dsp.internal.AllpassMinMult.stepMinMultCascade(...
                        u2, Z2, obj.pBranchInfo2, obj.pBranchCoef2);
                else
                    %wave digital
                    [y1,Z1] = dsp.internal.WaveDigitalFilter.stepWDFCascade(...
                        u1,Z1, obj.pBranchInfo1, obj.pBranchCoef1,nc);
                    [y2,Z2] = dsp.internal.WaveDigitalFilter.stepWDFCascade(...
                        u2,Z2, obj.pBranchInfo2, obj.pBranchCoef2,nc);
                end
                
                % Save states
                obj.pStates.Branch1 = Z1;
                obj.pStates.Branch2 = Z2;
                
            else
                
                % Local copies of delay and coefficients
                delayObj = obj.pDelay;
                
                % Local copies of states
                Z2 = obj.pStates.Branch2;
                
                % ----- Delay: First branch
                y1 = step(delayObj, u1);
                
                % ----- Second branch
                if obj.pCachedUsesMinMult
                    [y2,Z2] = dsp.internal.AllpassMinMult.stepMinMultCascade(...
                        u2, Z2, obj.pBranchInfo2, obj.pBranchCoef2);
                else
                    %wave digital
                    [y2,Z2] = dsp.internal.WaveDigitalFilter.stepWDFCascade(...
                        u2, Z2, obj.pBranchInfo2, obj.pBranchCoef2,nc);
                end
                 
                
                % Save states
                obj.pStates.Branch2 = Z2;
                
            end
            
            % Compute output
            y = zeros(2*size(u1,1),size(u1,2), 'like', u1);
            y(1:2:end) = y1;
            y(2:2:end) = y2;
        end
        %------------------------------------------------------------------
        function val = isDecimator(~)
            val = false;
        end
        %------------------------------------------------------------------
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@dsp.internal.IIRHalfbandBase(obj);
        end
        %------------------------------------------------------------------
        function loadObjectImpl(obj, s, wasLocked)
            loadObjectImpl@dsp.internal.IIRHalfbandBase(obj, s, wasLocked);
        end
        %------------------------------------------------------------------
        function val = getNumInputsImpl(obj)
            val = 1+obj.FilterBankInputPort;
        end
         %------------------------------------------------------------------
        function varargout = getInputNamesImpl(obj)
            % Name of input ports (shows on block icon)
            if ~obj.FilterBankInputPort
                varargout{1} =   '';
            else % power-complementary inputs
                varargout{1} =   'LP';
                varargout{2} =   'HP';
            end
        end
        %------------------------------------------------------------------
        function varargout = getOutputNamesImpl(~)
            % Name of output port (shows on block icon)
            varargout{1} =   '';
        end
        %------------------------------------------------------------------
        function icon = getIconImpl(obj)
            % MATLAB system block icon
            if ~obj.FilterBankInputPort
                icon = getString(message(...
                    'dsp:system:IIRHalfbandInterpolator:interpolatorIconString'));
            else % power-complementary outputs requested
                icon = getString(message(...
                    'dsp:system:IIRHalfbandInterpolator:synthesisIconString'));
            end
        end
        %------------------------------------------------------------------
        function val = supportsMultipleInstanceImpl(~)
            % Support in for-each subsystem
            val = true;
        end

        % PROPAGATOR METHODS: (used by Simulink)
        %------------------------------------------------------------------
        function varargout = getOutputSizeImpl(obj)
            varargout{1} = propagatedInputSize(obj,1);
            varargout{1}(1) = varargout{1}(1)*2;
        end
        %------------------------------------------------------------------
        function varargout = getOutputDataTypeImpl(obj)
            varargout{1} = propagatedInputDataType(obj,1);
        end
        %------------------------------------------------------------------
        function varargout = isOutputComplexImpl(obj)
            varargout{1} = propagatedInputComplexity(obj,1);
        end
        %------------------------------------------------------------------
        function varargout = isOutputFixedSizeImpl(obj)
            varargout{1} = propagatedInputFixedSize(obj,1);
        end
        %------------------------------------------------------------------ 
        function postProcessSampleRate(obj,val)
            needToDesignFilters(obj);
            obj.pSR = val;
        end
        %------------------------------------------------------------------
        function dt = getTunablePropertiesSpecificationImpl(obj,~)
            dt = propagatedInputDataType(obj,1);
        end
        function flag = isInactivePropertyImpl(obj, prop)            
            switch prop
                case {'SampleRateMode'}
                    flag = true;
                otherwise
                    flag = isInactivePropertyImpl@dsp.internal.IIRHalfbandBase(obj,prop);
            end
        end
    end
    %----------------------------------------------------------------------
    % Static hidden methods
    %----------------------------------------------------------------------
    methods (Static, Hidden)
        function props = getDisplayPropertiesImpl()
            props = {...
                'Specification',...
                'FilterOrder', ...
                'TransitionWidth', ...
                'StopbandAttenuation', ...
                'DesignMethod', ...
                'FilterBankInputPort', ...
                'NormalizedFrequency', ...
                'SampleRate', ...
                'Structure', ...
                'HasPureDelayBranch', ...
                'Delay', ...
                'AllpassCoefficients1', ...
                'AllpassCoefficients2', ...
                'WDFCoefficients1', ...
                'WDFCoefficients2', ...
                'HasTrailingFirstOrderSection'};
        end
    end
    %----------------------------------------------------------------------
    % Static protected methods
    %----------------------------------------------------------------------
    methods (Static, Access=protected)
        function mainS = getPropertyGroupsImpl
            props = dsp.IIRHalfbandInterpolator.getDisplayPropertiesImpl;
            mainS = matlab.system.display.Section('Title', ...
                getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', props);
            
            filterVis = dsp.internal.FilterVisualizationButton;
            mainS.Actions = filterVis.fvtoolAction;
        end
        
        %------------------------------------------------------------------
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.IIRHalfbandInterpolator', ...
                'ShowSourceLink', true, ...
                'Title', getString(message('dsp:system:IIRHalfbandInterpolator:titleString')),...
                'Text',  getString(message('dsp:system:IIRHalfbandInterpolator:descriptionString')));
        end
    end
    %----------------------------------------------------------------------
    % Hidden methods
    %----------------------------------------------------------------------
    methods (Hidden)
        function props = getNonFixedPointProperties(~)
            props = dsp.IIRHalfbandInterpolator.getDisplayPropertiesImpl;
        end

        function [L,M] = rateConversionFactors(obj) %#ok
            nargoutchk(2, 2);
            L = 2;
            M = 1;
        end
    end
end
