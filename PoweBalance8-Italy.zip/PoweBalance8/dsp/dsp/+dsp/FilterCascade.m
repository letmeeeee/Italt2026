classdef FilterCascade < dsp.internal.FilterStructure 
%FilterCascade Construct a cascade of filter System objects, delays, and
%scalar gains
%   This is a multistage System object that allows cascading of filter
%   System objects, delays, and scalar gains. The cascade can then be used
%   for analysis, for generating filtering code, or for simulation.
%
%   FC = dsp.FilterCascade returns a System object, FC, that has a single
%   stage of dsp.FIRFilter.
%
%   FC = dsp.FilterCascade(FILTER1, FILTER2, ...) returns a multistage
%   System object, FC, with first stage set to FILTER1, second stage set to
%   FILTER2, and so on.
%
%   FC = dsp.FilterCascade(..., CloneStages=val) sets the CloneStages
%   property to val, which can be true or false.
%
%   Step method syntax:
%
%   Y = step(FC,X) runs the input X through the filter cascade FC, and
%   returns the filtered output Y.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   FilterCascade methods:
%
%   step                  - See above description for use of this method
%   release               - Allow property value and input characteristics
%                           to change
%   clone                 - Create dsp.FilterCascade object with same
%                           property values
%   isLocked              - Locked status (logical)
%   reset                 - Reset the internal states of all stages to
%                           initial conditions
%   addStage              - Add a new filter stage to the cascade
%   removeStage           - Remove a stage from the cascade
%   releaseStages         - Release the locked state of all stages in the
%                           cascade
%   getNumStages          - Get the number of stages in the cascade object
%   generateFilteringCode - Generate MATLAB code that can perform the
%                           filtering operation of the whole cascade
%   generatehdl           - Generate HDL code.
%                           (Filter Design HDL Coder Required)
%
%   FilterCascade properties:
%
%   CloneStages - Control stage cloning
%   Stage1      - First stage of the filter cascade
%
%   You can grow the number of stages by using the addStage method of
%   dsp.FilterCascade. For a list of System objects that can be used as
%   stages of the filter cascade, type
%   dsp.FilterCascade.helpSupportedSystemObjects
%
%   This System object supports several filter analysis methods. For more
%   information, type dsp.FilterCascade.helpFilterAnalysis.
%
%   % EXAMPLE 1: Construct a cascade in three ways
%   % First, create the stages
%   s1 = dsp.FIRInterpolator(13);
%   s2 = dsp.FIRDecimator(17);
%
%   % Option 1: Specify stages while constructing the dsp.FilterCascade 
%   % object
%   fc1 = dsp.FilterCascade(s1,s2);
%
%   % Option 2: Use the cascade function
%   fc2 = cascade(s1, s2);
%
%   % Option 3: Construct an empty cascade, then use the addStage function 
%   % to add the stages.
%   fc3 = dsp.FilterCascade;
%   addStage(fc3, s1);
%   addStage(fc3, s2);
%
%   % EXAMPLE 2: Design a compensation decimator for a CIC decimator and
%   % visualize the frequency response of the cascade through
%   % dsp.FilterCascade. Step through the filter cascade. 
%
%   % Construction
%   cicdecim = dsp.CICDecimator(DecimationFactor = 6, ...
%                               NumSections = 6);
%   decimcasc = cascade(cicdecim, 1/gain(cicdecim));
%   fs = 16e3;     % Sample rate at the input of compensation decimator
%   fPass = 4e3;   % Passband frequency
%   fStop = 4.5e3; % Stopband frequency
%   ciccomp = dsp.CICCompensationDecimator(cicdecim, ...
%                             DecimationFactor  = 2, ...
%                             PassbandFrequency = fPass, ...
%                             StopbandFrequency = fStop, ...
%                             SampleRate = fs);
%
%   % Frequency response
%   % Next, visualize the cascade frequency response using FilterCascade
%   filtchain = dsp.FilterCascade(decimcasc, ciccomp);
%
%   f = fvtool(decimcasc, ciccomp, filtchain, Fs = [fs*6,fs,fs*6],...
%       Arithmetic = 'fixed');
%   legend(f,'CIC Decimator','CIC Compensation Decimator', ...
%            'Overall Response');
%
%   % Simulation with random input
%   x = randn(1200,2);
%   for idx = 1:100
%       y = filtchain(x);
%   end
%
%   % EXAMPLE 3: Multistage decimator design. Design a two-stage decimator
%   % with a downsampling rate of 4, transition width of 100 Hz, sample 
%   % rate of 2kHz, and a 60 dB attenuation in the stopband. The System 
%   % object returned from designMultistageDecimator is a filter cascade.
%
%   % Use multistage design function to construct a decimator
%   decim = designMultistageDecimator(4, 2000, 100, 60);
%
%   % Verify the design
%   info(decim)
%   fvtool(decim)
%
%   % Generate code to filter data using this design
%   % This saves the code in a file called 'processDecimator.m' in the
%   % current directory, along with any associated classes.
%   generateFilteringCode(decim, 'processDecimator');
%
%   % EXAMPLE 4: Stage cloning v.s. stage referencing
%   s1 = dsp.FIRInterpolator(13);
%   s2 = dsp.FIRDecimator(17);
%   fc_clone = dsp.FilterCascade(s1, s2)
%   fc_ref = dsp.FilterCascade(s1, s2, CloneStages = false)
%
%   % Change a property in the user-provided stage
%   s1.InterpolationFactor = 19
%
%   % Check if the change in the interpolation factor of s1 has affected
%   % the interpolation factor of Stage1 stored in the cascade
%   fc_clone.Stage1.InterpolationFactor   % no sync (clone)
%   fc_ref.Stage1.InterpolationFactor     % sync (reference)
%
%   See also cascade, dsp.ParallelFilter, designMultistageDecimator, 
%   designMultistageInterpolator

%   Copyright 2014-2023 The MathWorks, Inc.

properties (Nontunable)
    %Stage1 First stage of filter cascade
    %   Specify the first stage of the filter cascade, as a filter
    %   System object. The default value of this property is
    %   dsp.FIRFilter.
    Stage1
    %Stage2 Second stage of filter cascade
    Stage2 = 1;
    %Stage3 Third stage of filter cascade
    Stage3 = 1;
    %Stage4 Fourth stage of filter cascade
    Stage4 = 1;
    %Stage5 Fifth stage of filter cascade
    Stage5 = 1;
    %Stage6 Sixth stage of filter cascade
    Stage6 = 1;
    %Stage7 Seventh stage of filter cascade
    Stage7 = 1;
    %Stage8 Eighth stage of filter cascade
    Stage8 = 1;
    %Stage9 Nine stage of filter cascade
    Stage9 = 1;
    %Stage10 Tenth stage of filter cascade
    Stage10 = 1;
    %Stage11 Eleventh stage of filter cascade
    Stage11 = 1;
    %Stage12 Twelfth stage of filter cascade
    Stage12 = 1;
    %Stage13 Thirteenth stage of filter cascade
    Stage13 = 1;
    %Stage14 Fourteenth stage of filter cascade
    Stage14 = 1;
    %Stage15 Fifteenth stage of filter cascade
    Stage15 = 1;

end

properties (Access=protected, Nontunable)
    pNumStages = 0;
end

properties(Nontunable, SetAccess = protected)
    %CloneStages Control stage cloning
    %
    % If CloneStages is false, the cascade stages assigned to the
    % FilterCascade object occupy the same memory as the stages provided by
    % the user. You can add stages while creating the FilterCascade object,
    % by direct assignment, or by using the addStage method.
    %
    % If CloneStages is set to true, the stages stored in the FilterCascade
    % object are mere clones of the stages provided by the user, and do not
    % occupy the same memory.
    %
    % The default is true. This parameter can be set on construction only.
    CloneStages (1, 1) logical = true;
end

properties(Constant, Access = private)
    MaxNumStages = 15;
end

properties (Constant, Hidden)
   ChildLabel = 'Stage';
end


%----------------------------------------------------------------------
% Public methods
%----------------------------------------------------------------------
methods
    function set.Stage1(obj, val)
        obj.Stage1 = checkFilterAndClearMetadata(obj, val, obj.Stage1);
    end
    %------------------------------------------------------------------
    function set.Stage2(obj, val)
        obj.Stage2 = checkFilterAndClearMetadata(obj, val, obj.Stage2);
    end
    %------------------------------------------------------------------
    function set.Stage3(obj, val)
        obj.Stage3 = checkFilterAndClearMetadata(obj, val, obj.Stage3);
    end
    %------------------------------------------------------------------
    function set.Stage4(obj, val)
        obj.Stage4 = checkFilterAndClearMetadata(obj, val, obj.Stage4);
    end
    %------------------------------------------------------------------
    function set.Stage5(obj, val)
        obj.Stage5 = checkFilterAndClearMetadata(obj, val, obj.Stage5);
    end
    %------------------------------------------------------------------
    function set.Stage6(obj, val)
        obj.Stage6 = checkFilterAndClearMetadata(obj, val, obj.Stage6);
    end
    %------------------------------------------------------------------
    function set.Stage7(obj, val)
        obj.Stage7 = checkFilterAndClearMetadata(obj, val, obj.Stage7);
    end
    %------------------------------------------------------------------
    function set.Stage8(obj, val)
        obj.Stage8 = checkFilterAndClearMetadata(obj, val, obj.Stage8);
    end
    %------------------------------------------------------------------
    function set.Stage9(obj, val)
        obj.Stage9 = checkFilterAndClearMetadata(obj, val, obj.Stage9);
    end
    %------------------------------------------------------------------
    function set.Stage10(obj, val)
        obj.Stage10 = checkFilterAndClearMetadata(obj, val, obj.Stage10);
    end
    %------------------------------------------------------------------
    function set.Stage11(obj, val)
        obj.Stage11 = checkFilterAndClearMetadata(obj, val, obj.Stage11);
    end
    %------------------------------------------------------------------
    function set.Stage12(obj, val)
        obj.Stage12 = checkFilterAndClearMetadata(obj, val, obj.Stage12);
    end
    %------------------------------------------------------------------
    function set.Stage13(obj, val)
        obj.Stage13 = checkFilterAndClearMetadata(obj, val, obj.Stage13);
    end
    %------------------------------------------------------------------
    function set.Stage14(obj, val)
        obj.Stage14 = checkFilterAndClearMetadata(obj, val, obj.Stage14);
    end
    %------------------------------------------------------------------
    function set.Stage15(obj, val)
        obj.Stage15 = checkFilterAndClearMetadata(obj, val, obj.Stage15);
    end

    %------------------------------------------------------------------
    % TODO: uncomment this code whenever post-construction changing of
    % CloneStages is called for. This method is commented out since it has
    % no full spec and testing. Note that this method does more than just
    % setting the CloneStages value, but also clones existing references if
    % one switches from 'false' to 'true'.
    % function enableCloneStages(obj,val)
    %   if nargin<2
    %     val = true;
    %   end
    %
    %   % If switching from referencing to cloning - clone existing
    %   % stage references to as to prevent mixed cloned and referenced
    %   % stages.
    %   if val && ~obj.CloneStages
    %       for n=1:obj.pNumStages
    %       obj.(['Stage' num2str(n)]) = obj.(['Stage' num2str(n)]).clone;
    %   end
    %
    %   obj.CloneStages = val;
    % end


    %------------------------------------------------------------------
    function obj = FilterCascade(varargin)
        % Constructor
        if isempty(varargin)
            % Process default constructor dsp.FilterCascade()
            obj.Stage1 = dsp.FIRFilter;
            obj.pNumStages = 1;
        else
            % Process constructor with stages and optional arguments
            % dsp.FilterCascade(stage1,stage2,...,stageN,[CloneStages=val])
            [varargin{:}] = convertStringsToChars(varargin{:});

            % Check if 'CloneStages' has been specified
            csidx = find(strcmp(varargin,'CloneStages'),1,'first');
            if ~isempty(csidx)
                % Make sure value is given
                coder.internal.errorIf(csidx+1>numel(varargin),'MATLAB:system:invalidPVPairs')

                % Assign CloneStages value
                obj.CloneStages = varargin{csidx+1};
                validateattributes(obj.CloneStages, {'logical'},...
                    {'scalar','binary'}, '','CloneStages');

                % Omit the P-V pair
                stages = [varargin(1:csidx-1) varargin(csidx+2:end)];

                % Process dsp.FilterCascade(CloneStages=val) with no stages
                if numel(stages)==0
                    stages = {dsp.FIRFilter};
                end
                obj.setStages(stages);
            else
                obj.setStages(varargin);
            end
        end
    end
    %------------------------------------------------------------------
    function addStage(obj, stage, varargin)
    %ADDSTAGE Add a stage to filter cascade
    %
    %   addStage(FC, FILTERSYSOBJ) adds FILTERSYSOBJ as a stage at the
    %   end of the filter cascade in FC.
    %
    %   addStage(FC, FILTERSYSOBJ, STAGEIDX) adds the filter defined in
    %   FILTERSYSOBJ at stage position STAGEIDX of the filter cascade
    %   in FC. All existing filters from STAGEIDX to end of the cascade
    %   are shifted down further in the cascade.
    %
    %   % Example 1: Add a stage at the end of the filter cascade
    %   filtcasc = dsp.FilterCascade;
    %   addStage(filtcasc, dsp.IIRFilter);
    %
    %   % Example 2: Add a filter at the second stage of the filter
    %   % cascade consisting of three filters
    %   filtcasc = cascade(dsp.CICDecimator,dsp.FIRDecimator,dsp.FIRFilter);
    %   addStage(filtcasc, dsp.IIRFilter, 2);

        narginchk(2,3);

        if isLocked(obj)
            error(message('dsp:system:FilterCascade:addRemoveOnLocked', 'add'));
        end

        if obj.pNumStages == obj.MaxNumStages
            error(message('dsp:system:FilterCascade:maximumStages',obj.MaxNumStages));
        end

        if ~isempty(varargin)
            addStageNum = varargin{1};
            validateattributes(addStageNum, {'numeric'}, ...
                {'positive', 'integer', 'scalar', 'finite', ...
                '<=', obj.pNumStages+1}, ...
                'addStage', 'stage position');
        end

        obj.pNumStages = obj.pNumStages+1;
        currentStage = sprintf('Stage%d',obj.pNumStages);
        if isempty(varargin)
            obj.(currentStage)=stage;
        else
            % shift stages to the right
            for idx = obj.pNumStages:-1:addStageNum+1
                rightStage = sprintf('Stage%d',idx);
                leftStage = sprintf('Stage%d',idx-1);
                obj.(rightStage) = obj.(leftStage);
            end
            obj.(sprintf('Stage%d',addStageNum)) = stage;
        end
    end
    %------------------------------------------------------------------
    function removeStage(obj, varargin)
    %REMOVESTAGE Remove a stage from filter cascade
    %
    %   removeStage(FC) removes a stage from the end of the filter
    %   cascade in FC.
    %
    %   removeStage(FC, STAGEIDX) removes the stage from the stage
    %   position STAGEIDX of the filter cascade in FC. All existing
    %   filters from STAGEIDX to end of the cascade are shifted up in
    %   the cascade.
    %
    %   % Example 1: Remove a stage from the end of the filter cascade
    %   FC = dsp.FilterCascade(dsp.FIRFilter, dsp.IIRFilter);
    %   removeStage(FC);
    %
    %   % Example 2: Remove a filter from the third stage of a cascade
    %   % consisting of four stages
    %   FC = cascade(dsp.FIRInterpolator, dsp.FIRInterpolator, ...
    %                dsp.FIRDecimator, dsp.FIRDecimator);
    %   removeStage(FC, 3);

        narginchk(1,2);

        coder.internal.errorIf(isLocked(obj), 'dsp:system:FilterCascade:addRemoveOnLocked', 'remove');
        coder.internal.errorIf(obj.pNumStages == 1, 'dsp:system:FilterCascade:minimumStages');

        if ~isempty(varargin)
            remStageNum = varargin{1};
            validateattributes(remStageNum, {'numeric'}, ...
                {'positive', 'integer', 'scalar', 'finite', ...
                '<=', obj.pNumStages}, ...
                'removeStage', 'stage position');

            % move stages to the left
            for idx = remStageNum:obj.pNumStages-1
                leftStage = sprintf('Stage%d',idx);
                rightStage = sprintf('Stage%d',idx+1);
                tmp = obj.(rightStage);
                obj.(rightStage) = 1; % Remove handle instance (avoid double instance error)
                obj.(leftStage) = tmp;
            end
        end

        discardedStage = sprintf('Stage%d',obj.pNumStages);
        obj.(discardedStage) = 1;

        obj.pNumStages = obj.pNumStages-1;
        clearMetaData(obj);
    end
    %------------------------------------------------------------------
    function releaseStages(obj)
    %RELEASESTAGE Release the locked state of all stages in the cascade
    %
    %   releaseStages(FC) calls RELEASE method on all stages of the
    %   filter cascade in FC.
    %
    %   % Example:
    %   FIRFilt = dsp.FIRFilter;
    %   y = FIRFilt(randn);
    %   FC = dsp.FilterCascade(dsp.FIRInterpolator, FIRFilt);
    %   isLocked(FC.Stage2)
    %   releaseStages(FC);
    %   isLocked(FC.Stage2)
        obj.releaseChildren();
    end
    %------------------------------------------------------------------
    function n = getNumStages(obj)
    %GETNUMSTAGES Number of filters in cascade
    %
    %   N = getNumStages(FC) returns the number of stages in the filter
    %   cascade object, FC.
    %
    %   % Example:
    %   FC = cascade(dsp.FIRFilter, dsp.IIRFilter);
    %   N = getNumStages(FC);    % This will return 2
        n = obj.pNumStages;
    end
    %------------------------------------------------------------------
    %------------------------------------------------------------------
    function generateFilteringCode(obj, functionName)
    %GENERATEFILTERINGCODE Generate MATLAB code to filter using a cascade
    %
    %   generateFilteringCode(FC) creates a new file in the editor that
    %   contains code to create stages of the cascade and use the
    %   stages to process input data in sequence.
    %
    %   generateFilteringCode(FC, FNAME) generates the code and saves
    %   it to the file specified in the string FNAME. If a file named FNAME
    %   already exists, its content is replaced.
    %
    %   % Example:
    %   FC = dsp.FilterCascade(dsp.FIRFilter(Numerator=ones(1,5)),...
    %                          dsp.FIRDecimator);
    %   fName = 'filterCascade.m';  % The code will be saved in this
    %                               % file in the current directory
    %   generateFilteringCode(FC, fName);

        arguments
            obj;
            functionName (1,:) char = 'filterCascade';
        end

        % If a customer name is specified, write to a file
        WriteFile = (nargin>1);
        generateFilterCodeImpl(obj, functionName, WriteFile);
    end

    %------------------------------------------------------------------
    function flag = isequal(obj, obj2)
    %ISEQUAL Determine if two FilterCascade objects are equal.
    %
    %   isequal(FC1, FC2) returns logical 1 (TRUE) if all stages of FC1
    %   are exactly the same in value as those of FC2.
    %
    %   % Example:
    %   FC1 = dsp.FilterCascade(dsp.FIRDecimator, ...
    %                           dsp.FIRFilter('Numerator',ones(1,5)));
    %   FC2 = dsp.FilterCascade(dsp.FIRDecimator, ...
    %                           dsp.FIRFilter);
    %   isequal(FC1, FC2);  % This will return false because Stage2 of
    %                       % both objects is not same
    %   FC3 = dsp.FilterCascade(dsp.FIRDecimator, ...
    %                           dsp.FIRFilter('Numerator',ones(1,5)));
    %   isequal(FC1, FC3);  % This will return true
        flag = isequal@dsp.internal.FilterStructure(obj,obj2);
    end

    %------------------------------------------------------------------
    function flag = isFilterCascade(~)
        flag = true;
    end

    %------------------------------------------------------------------
    function fdhdltool(obj,InputNumericType)
        %   FDHDLTOOL(Hb, nt) launches the Generate HDL dialog that lets you
        %   customize and generate Verilog or VHDL code and test benches for
        %   the quantized System object filter, Hb. You have to call FDHDLTOOL
        %   again if you make changes in the filter, Hb, in the command line.
        %
        %   The main dialog and two subordinate dialogs provide access to many
        %   options for customizing the generated filter and test bench code.
        %
        %   The Generate HDL main dialog categorizes options in two frames:
        %
        %   * HDL Filter - Options you are most likely to customize at least once:
        %   language selection, name and location of generated files, reset
        %   specifications, and optimizations.
        %
        %   * Test bench types - Options for naming and specifying the type of test
        %   bench files to generate, and specific types of stimuli the test benches
        %   are to apply.
        %
        %   EXAMPLE:
        %   cascadeFilter = dsp.FilterCascade(dsp.FIRFilter,dsp.FIRDecimator);
        %   T = numerictype(1,16,15);
        %   fdhdltool(cascadeFilter, T)

        if ~exist('InputNumericType','var')
            error(message('hdlfilter:privgeneratehdl:fdhdltoolinputdatatypenotspecified'));
        end

        casfilt = dsp.internal.CascadeHDL(obj,'InputDataType',InputNumericType);
        % Call fdhdltool with our created mfilt.cascade
        fdhdltool(casfilt,'InputDataType',InputNumericType);
    end

     %-----------------------------------------------------------------
    function generatehdl(obj,varargin)
        %   GENERATEHDL(Hb, 'InputDataType', nt) automatically generates VHDL
        %   or Verilog code for the quantized filter, Hb. The default
        %   language is VHDL; to generate Verilog, supply the
        %   property/value pair 'TargetLanguage','Verilog'. The file is written to
        %   the HDL source directory which defaults to 'hdlsrc' under the
        %   current directory. This directory will be created if necessary.
        %
        %   GENERATEHDL(Hb, PARAMETER1, VALUE1, PARAMETER2, VALUE2, ...)
        %   generates the HDL code with parameter/value pairs. Valid properties
        %   and values for GENERATEHDL are listed in the Filter Design HDL
        %   Coder documentation section "Property Reference."
        %
        %   EXAMPLE:
        %   cascadeFilter = dsp.FilterCascade(dsp.FIRFilter,dsp.FIRDecimator);
        %   T = numerictype(1,16,15);
        %   generatehdl(cascadeFilter, 'InputDataType', T)

        for k = 1:length(varargin)
            if iscell(varargin{k})
                [varargin{k}{:}] = convertStringsToChars(varargin{k}{:});
            else
                varargin{k} = convertStringsToChars(varargin{k});
            end
        end

        casfilt = dsp.internal.CascadeHDL(obj,varargin{:});
        % call generatehdl with our created mfilt.cascade.
        generatehdl(casfilt,varargin{:});
    end
    %------------------------------------------------------------------
    function [D,varargout] = outputDelay(obj,varargin)
        if nargin > 1
            [varargin{:}] = convertStringsToChars(varargin{:});
        end

        [FsIn, Fc, tol, N, DefaultFc] = parseOutputDelayArguments(obj,varargin{:});
        
        % For cascades, there is no need for each stage to warn about a 
        % nonlinear phase. Instead, this check is performed once.
        w = warning('off', 'dsp:system:FilterAnalysis:NonlinearPhase');
        restoreWarn = onCleanup(@() warning(w));
        
        linphase  = obj.islinphase;
        BandOutputRequested = nargout>2;

        % Emit a warning if the cascade has a nonlinear phase and warning
        % suppression conditions aren't met
        NonlinearWarning = ~(BandOutputRequested || ~DefaultFc) && ~linphase;
        coder.internal.warningIf(NonlinearWarning ,'dsp:system:FilterAnalysis:NonlinearPhaseCascade', Fc)

        [Ls, Ms] = rateConversionFactorsVectors(obj);
        D  = 0;        
        
        Lk = [1 cumprod(Ls)];
        Mk = [1 cumprod(Ms)];

        Fsk = FsIn;
        for k = 1:obj.getNumStages
            stgk = obj.getStage(k); 
            % Composite stages and acummulate delays
            if obj.isNumericScalarFilter(stgk)
                Dk = 0;
            else
                if ~DefaultFc
                    % If working with user-specified frequency
                    % Adjust user frequency to current stage
                    fk = Fc*Lk(k)/Mk(k);
                    [Dk,Fsk] = outputDelay(stgk, FsIn = Fsk, Fc=fk);
                else
                    [Dk,Fsk] = outputDelay(stgk, FsIn = Fsk);
                end
            end
            D = D + Dk;
        end

        if nargout>1
            varargout{1} = Fsk;
        end

        if BandOutputRequested
            if linphase
                varargout{2} = [-FsIn/2 FsIn/2];
            else
                % Determine if cascade can be reduced to a single filter
                % stage equivalent
                id = obj.validateratechangefactors();
                reducible = isempty(id);

                % If a single stage equivalent does not exists
                if ~reducible
                    reasonstr = string(message(id));
                    coder.internal.error('dsp:system:FilterAnalysis:IrreducibleCascadeBandUnsupported',reasonstr);
                end

                L = prod(Ls);
                GD = L*D*FsIn; % Group delay equivalent of the outputDelay value
                varargout{2} = obj.groupDelayBand(FsIn,Fc, GD, tol, N);
            end
        end
    end

    function flag = islinphase(obj,varargin)
        % First, check sufficient confition: all stages have a linear phase
        % ⟹ a cascade has a linear phase. 
        flag = true;
        for n=1:getNumStages(obj)
            stgn = obj.getStage(n);
            flag = flag && islinphase(stgn,varargin{:});
            
            % If flag is false for any reason, break early.
            if ~flag
                break;
            end
        end

        % Otherwise, check necessary condition: a cascade has a linear
        % phase ⟺ all its reduced form stages have a linear phase.
        if ~flag
            Mc = obj.toMultirateChain();
            flag = Mc.islinphase;
        end
    end
end


%----------------------------------------------------------------------
% Protected methods
%----------------------------------------------------------------------
methods(Access=protected)
    %----------------------------------------------------------------------
    function C = toMultirateChain(obj)
        % Convert the cascade into a MultirateChain object. 
        % The MultirateChain is an internal structure that allows multirate
        % cascades manipulation and analysis. 

        C = dsp.internal.MultirateAnalysis.MultirateChain;
        for n = 1:obj.getNumStages()
            stgn = obj.getStage(n);

            if obj.isNumericScalarFilter(stgn)
                % If the n'th stage is a numeric stage (a scaling block),
                % create a FilterStage object cell of the form {num,den,power}.
                stgc = dsp.internal.MultirateAnalysis.MultirateChain({{stgn,1,1}}, skipTrivial=true);
            else
                % Otherwise, the stage is a FilterAnalysis type object. 
                % Defer to toMultirateChain implementation of the stage itself
                stgc = stgn.toMultirateChain(); 
            end

            C.addChain(stgc)
        end
    end
        
 
    %------------------------------------------------------------------
    function setupImpl(obj,varargin)
        % Verify all stages have a single port
        for n=1:obj.getNumStages 
            stg = obj.getStage(n);
            if ~obj.isNumericScalarFilter(stg)
                ni = stg.getNumInputs;
                if ni>1
                    coder.internal.error('dsp:system:FilterCascade:multipleInputs',n,ni);
                end
            end
        end

        % Can only setup the first stage since we do not yet know the
        % size and data type for input of subsequent stages
        if ~obj.isNumericScalarFilter(obj.Stage1) && ~isLocked(obj.Stage1)
            setup(obj.Stage1, varargin{:});
        end
    end    
    %------------------------------------------------------------------
    function y = stepImpl(obj,varargin)

        stage1 = obj.Stage1;
        if ~obj.isNumericScalarFilter(stage1)
            y = step(stage1, varargin{:});
        else
            y = varargin{1}*stage1;
        end
        coder.extrinsic('sprintf');
        for ind = 2:obj.pNumStages
            stageIdx = coder.const(@sprintf,'Stage%d', ind);
            stage = obj.(stageIdx);
            if ~obj.isNumericScalarFilter(stage)
                y = step(stage, y);
            else
                y = y*stage;
            end
        end
    end

    %------------------------------------------------------------------
    function s = saveObjectImpl(obj)
        % Called on saving the object
        s.pNumStages = obj.pNumStages;
        s.CloneStages = obj.CloneStages;
        for ind = 1:obj.pNumStages
            stageIdx = sprintf('Stage%d',ind);
            if ~obj.isNumericScalarFilter(obj.(stageIdx))
                s.(stageIdx) = matlab.System.saveObject(obj.(stageIdx));
            else
                s.(stageIdx) = obj.(stageIdx);
            end
        end
        s = saveFA(obj, s);   % Save filter analysis class properties
    end
    %------------------------------------------------------------------
    function loadObjectImpl(obj, s, wasLocked)

        % Setting CloneStages to false will avoid unnecessary cloning the result of
        % matlab.System.loadBoject()
        obj.CloneStages = false;

        % Call base class method
        for ind = 1:s.pNumStages
            stageIdx = sprintf('Stage%d',ind);
            if ~obj.isNumericScalarFilter(s.(stageIdx))
                obj.(stageIdx) = matlab.System.loadObject(s.(stageIdx));
            else
                obj.(stageIdx) = s.(stageIdx);
            end
        end
        obj.pNumStages = s.pNumStages;
        if isfield(s,'CloneStages')
            obj.CloneStages = s.CloneStages;
        else
            obj.CloneStages = true;
        end

        loadFA(obj, s, wasLocked); % Load filter analysis class properties
    end

    %------------------------------------------------------------------
    function d = convertToDFILT(obj,arith)
        % Convert the System object to a dfilt object for analysis

        % Suppress MFILT deprecation warning
        w = warning('off', 'dsp:mfilt:mfilt:Obsolete');
        restoreWarn = onCleanup(@() warning(w));

        % Create empty cascade mfilt.
        d = mfilt.cascade; %#ok
        % The default cascade object comes with two dummy sections.
        % First remove them:
        d.removestage(1:2);

        for ind = 1:obj.pNumStages
            stage = getStage(obj,ind);
            if obj.isNumericScalarFilter(stage)
                dfiltStage = dsp.util.scalarDFILT(stage, arith);
            else
                dfiltStage = todfilt(stage, arith);
            end

            if isa(stage, 'dsp.FilterCascade')
                % Unroll individual stages instead of a single cascade
                % stage
                for ind2 = 1:nstages(dfiltStage)
                    d.addstage(dfiltStage.Stage(ind2));
                end
            else
                d.addstage(dfiltStage);
            end
        end

    end
    %------------------------------------------------------------------
    function infoStr = infoImpl(obj,varargin)
        s = StringWriter;
        s.addcr('Discrete-Time Filter Cascade');
        s.addcr('----------------------------');
        s.addcr('Number of stages: %d', obj.pNumStages);
        if obj.CloneStages
            s.addcr('Stage cloning: enabled');
        else
            s.addcr('Stage cloning: disabled');
        end

        for idx = 1:obj.pNumStages
            s.craddcr('Stage%d: %s', idx, class(obj.(sprintf('Stage%d',idx))));
            s.addcr('-------', idx);
            stage = obj.(sprintf('Stage%d',idx));
            if ~obj.isNumericScalarFilter(stage)
                stageChar = info(stage, varargin{:});
            else
                stageChar = '';
            end
            if isempty(stageChar)
                s.addcr;
            else
                stageChar = [stageChar, repmat('\n', size(stageChar,1), 1)]; %#ok
                stageChar = stageChar';
                s.addcr(stageChar(:)');
            end
        end
        infoStr = sprintf(char(s));
    end
end % methods (protected)

%----------------------------------------------------------------------
% Hidden methods
%----------------------------------------------------------------------
methods (Hidden)   
    function n = numChildren(obj)
        n = getNumStages(obj);
    end

    function h = child(obj, k)
        h = getStage(obj, k);
    end

    function b = clonedChildren(obj)
        b = obj.CloneStages;
    end

    %----------------------------------------------------------------------
    function C = asCell(obj, args)
        arguments
            obj
            args.Unroll (1,1) logical = false
            args.Clone  (1,1) logical = true
        end
        C = {};
        for k=1:getNumStages(obj)
            sk = obj.getStage(k);
            if isa(sk,'dsp.FilterCascade') && args.Unroll
                C =[C sk.asCell(Unroll=args.Unroll, Clone=args.Clone)]; %#ok
            else
                if args.Clone && ~obj.isNumericScalarFilter(sk)
                    C{end+1} = clone(sk); %#ok
                else
                    C{end+1} = sk; %#ok
                end
            end
        end
    end
    
    %----------------------------------------------------------------------
    function s = getStage(obj, n)
        s = obj.(['Stage' num2str(n)]);
    end

    %----------------------------------------------------------------------
    function id = validateratechangefactors(obj,varargin)
      [d, varargin] = parseArithmetic(obj,varargin); %#ok
      id = validateratechangefactors(d);
    end

    %----------------------------------------------------------------------    
    function FsIn = inputSampleRate(obj)
        if obj.getNumStages>0
            FsIn = obj.Stage1.inputSampleRate;
        else
            FsIn = 1;
        end
    end

    %----------------------------------------------------------------------
    function [L,M] = rateConversionFactorsVectors(obj)
        nargoutchk(2, 2);
        N = obj.getNumStages;
        L = ones(1,N);
        M = ones(1,N);

        for k = 1:N 
            stage = obj.getStage(k);

            % If stage is a scalar, then L=M=1. Otherwise, find its factors
            if ~obj.isNumericScalarFilter(stage)
                [L(k), M(k)] = rateConversionFactors(stage);
            end
        end
    end

    %----------------------------------------------------------------------
    function [L,M] = rateConversionFactors(obj)
        nargoutchk(2, 2);
        [L,M] = rateConversionFactorsVectors(obj);
        L = prod(L);
        M = prod(M);
    end

    %----------------------------------------------------------------------
    function setStages(obj,stages)
        for ind = 1:length(stages)
            stageIdx = coder.const(@sprintf, 'Stage%d',ind);
            obj.(stageIdx) = stages{ind};
            obj.pNumStages = ind; % Update the number of stages
        end
    end 
end


%----------------------------------------------------------------------
% Static methods
%----------------------------------------------------------------------
methods (Static)
    function supportedObjs = helpSupportedSystemObjects()
    %HELPSUPPORTEDSYSTEMOBJECTS List all System objects supported by
    % dsp.FilterCascade
    %
    % supportedObjs = dsp.FilterCascade.helpSupportedSystemObjects
    %                   Display a list of System objects that can be used 
    %                   as stages of a dsp.FilterCascade object
        str = StringWriter;
        addcr(str,'dsp.FilterCascade supports these filter System objects as stages:');
        supportedObjects = dsp.internal.FilterAnalysis.listFilterAnalysisObjects(true);
        addStr = @(objName)addcr(str,'%s',objName);
        cellfun(addStr,supportedObjects);
        supportedObjs = string(str);
    end
end


end %classdef
