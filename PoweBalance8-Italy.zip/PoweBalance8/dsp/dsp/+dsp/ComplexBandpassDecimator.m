classdef (StrictDefaults)ComplexBandpassDecimator < dsp.internal.SampleRateEngine
    %   ComplexBandpassDecimator One-sided bandpass decimator
    %   bpdecim = dsp.ComplexBandpassDecimator returns a System object,
    %   bpdecim, which independently filters each channel of the input over
    %   time using a one-sided, multistage complex bandpass decimation
    %   filter. The object determines the bandwidth of interest using the
    %   specified center frequency, decimation factor and bandwidth values.
    %
    %   bpdecim = dsp.ComplexBandpassDecimator(Name=Value, ...) returns a
    %   complex bandpass decimator System object, bpdecim, with each
    %   specified property name set to the specified value. You can specify
    %   additional name-value pair arguments in any order as
    %   (Name1=Value1,...,NameN=ValueN).
    %
    %   bpdecim = dsp.ComplexBandpassDecimator(D) returns a complex
    %   bandpass decimator object, bpdecim, with the DecimationFactor
    %   property set to D.
    %
    %   bpdecim = dsp.ComplexBandpassDecimator(D,Fc) returns a complex
    %   bandpass decimator object, bpdecim, with the DecimationFactor
    %   property set to D, and the CenterFrequency property set to Fc.
    %
    %   bpdecim = dsp.ComplexBandpassDecimator(D,Fc,Fs) returns a complex
    %   bandpass decimator object, bpdecim, with the DecimationFactor
    %   property set to D, the CenterFrequency property set to Fc, and the
    %   SampleRate property set to Fs.
    %
    %   Step method syntax:
    %
    %   Y = step(bpdecim, X) filters the real or complex input signal X to
    %   produce the output Y. The System object filters each channel of the
    %   input signal independently over time. The frame size (first
    %   dimension) of X must be a multiple of the decimation factor.
    %
    %   System objects may be called directly like a function instead of
    %   using the step method. For example, y = step(obj, x) and y = obj(x)
    %   are equivalent.
    %
    %   ComplexBandpassDecimator methods:
    %
    %   step                     - See above description for use of this 
    %                              method
    %   release                  - Allow property value and input
    %                              characteristics changes, and release
    %                              filter resources
    %   clone                    - Create complex bandpass decimator with
    %                              same property values
    %   isLocked                 - Display locked status (logical)
    %   reset                    - Reset the states of the filter
    %   cost                     - Compute implementation cost
    %   freqz                    - Compute/plot frequency response
    %   visualizeFilterStages    - Visualize filter stages
    %
    %   ComplexBandpassDecimator properties:
    %
    %   Specification               - Filter specification
    %   DecimationFactor            - Decimation factor
    %   CenterFrequency             - Center frequency (Hz)
    %   MinimizeComplexCoefficients - Minimize complex coefficients
    %   Bandwidth                   - Bandwidth (Hz)
    %   StopbandAttenuation         - Stopband attenuation (dB)
    %   PassbandRipple              - Passband ripple (dB)
    %   TransitionWidth             - Transition width (Hz)
    %   MixToBaseband               - Mix signal to baseband
    %   SampleRate                  - Input sample rate (Hz)
    %
    % % Example: Filter input signal through a complex bandpass decimator.
    % % Visualize filtered spectrum.
    %   Fs = 48e3;        % Input sample rate
    %   CF = 2000;        % Desired center frequency
    %   BW = 1000;        % Bandwidth of interest (centered at CF)
    %   D  =  Fs/BW;      % Decimation factor
    %   FrameLength = 1200;
    %
    %   bpdecim = dsp.ComplexBandpassDecimator(D,CF,Fs);
    %
    % % Visualize the stages of the filter:
    %   visualizeFilterStages(bpdecim)
    %
    % % Display filter info
    %   fprintf('%s',info(bpdecim));
    %
    % % Spectrum visualization scope
    %   sa = spectrumAnalyzer(SampleRate=Fs/D,...
    %                         Method="welch", ...
    %                         YLimits=[-120 40],...
    %                         FrequencyOffset=CF);
    %
    % % Sine wave generator
    %   tones = [1625 2000 2125];
    %   sin = dsp.SineWave(SampleRate=Fs,Frequency=tones,...
    %                      SamplesPerFrame=FrameLength);
    %
    %   for index = 1:1000
    %       x = sum(sin(),2) +  1e-4 * randn(FrameLength,1);
    %       z = bpdecim(x);
    %       sa(z);
    %   end
    %
    %   See also dsp.DigitalDownConverter,  dsp.DigitalUpConverter, 
    %            dsp.ZoomFFT
    
    % Copyright 2016-2022 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCLS>
    
    properties
        % CenterFrequency Center frequency (Hz)
        %  Specify the center frequency of the desired band in Hz as a
        %  real, finite numeric scalar in the range
        %  (-SampleRate/2,SampleRate/2). The default is 0 Hz. This property
        %  is tunable.
        CenterFrequency = 0;
    end
    
    properties (Nontunable)
        % Specification Filter specification
        %   Set the specification as one of 'Decimation factor' |
        %   'Bandwidth' | 'Decimation factor and bandwidth'. The default of
        %   this property is 'Decimation factor'.
        Specification = 'Decimation factor'
    end
    
    properties(Constant, Hidden)
        SpecificationSet = matlab.system.StringSet( { ...
            'Decimation factor', ...
            'Bandwidth',...
            'Decimation factor and bandwidth'} );
    end
    
    properties (Nontunable)
        % DecimationFactor Decimation factor
        %  Specify the factor by which to reduce the bandwidth of the input
        %  signal as a positive integer scalar value. The number of rows of
        %  the input must be a multiple of the decimation factor. This
        %  property applies when Specification is either 'Decimation
        %  factor' or 'Decimation factor and bandwidth'. The default is 2.
        DecimationFactor (1, 1) {mustBePositive, mustBeInteger} = 2;
    
        % SampleRate Input sample rate (Hz)
        %  Specify the sampling rate of the input in Hz, as a real, numeric
        %  scalar. The default is 44100 Hz.
        SampleRate = 44.1e3;
        % Bandwidth Frequency Bandwidth (Hz)
        %  Specify the width of the frequency band of interest as a
        %  positive scalar value, in Hertz. This property applies when
        %  Specification is either 'Bandwidth' or 'Decimation factor and
        %  bandwidth'. The default is 5000 Hz.
        Bandwidth = 5000;
        %StopbandAttenuation Stopband attenuation (dB)
        %  Specify the stopband attenuation of the filter in dB, as a
        %  finite positive scalar. The default is 80 dB.
        StopbandAttenuation = 80;
        % PassbandRipple Passband ripple (dB)
        %  Specify the passband ripple of the filter in dB, as a positive
        %  scalar. This property applies when Specification is either
        %  'Bandwidth' or 'Decimation factor and bandwidth'. The default is
        %  1 dB.
        PassbandRipple = 1;
        % TransitionWidth Transition width (Hz)
        %  Specify the transition width of the filter in Hz, as a positive
        %  scalar. The default is 100 Hz.
        TransitionWidth = 100;
    
        % MinimizeComplexCoefficients Reduce number of complex coefficients
        % Set this property to true to minimize the number of complex
        % filter coefficients. When this property is set to true, the first
        % stage of the multistage filter is bandpass (complex
        % coefficients), centered at the specified center frequency. The
        % first stage is followed by a mixing stage that heterodynes the
        % signal to DC, and then by the remaining filter stages, all with
        % real coefficients. When this property is set to false, the input
        % signal is first passed through the different stages of the
        % multistage filter. All stages are bandpass (complex
        % coefficients). The signal is then heterodyned to DC if
        % MixToBaseband is true and the frequency offset resulting from the
        % decimation is non-zero. The default is true.
        MinimizeComplexCoefficients (1, 1) logical = true;
        % MixToBaseband Mix signal to baseband
        %  Set this property to true to heterodyne the filtered, decimated
        %  signal to DC. This mixing stage runs at the output sample rate
        %  of the filter. Set this property to false to skip this stage.
        %  This property applies when MinimizeComplexCoefficients is false.
        %  The default is true.
        MixToBaseband (1, 1) logical = true;
    end
    
    properties (Constant, Hidden)
        % SampleRateSet is used to setup the choices (specify on
        % dialog/inherited) for SampleRate
        SampleRateSet = matlab.system.SourceSet({'PropertyOrMethod', ...
            'SystemBlock', 'InheritSampleRate',...
            'getInheritedSampleRate',true});
    end
    
    properties (Access=private)
        % Transformed bandpass coefficients (we support up to 9 stages)
        bp_coeff1
        bp_coeff2
        bp_coeff3
        bp_coeff4
        bp_coeff5
        bp_coeff6
        bp_coeff7
        bp_coeff8
        bp_coeff9
        
        % Parameters for final corrective mixer (running at lowest rate)
        pcf              % Cache offset frequency
        useExtraMixer    % determine if we need a mixer
        pOffset          % Counter to keep track of elapsed time in mixer
        
        % AreFiltersDesigned Used to skip unnecessary redesign of filter
        AreFiltersDesigned = false;
        
    end
    
    properties (Nontunable, Access=private)
        % Nstages Number of filter stages
        Nstages = 0;
        
        % Filters from the different stages
        filt1
        filt2
        filt3
        filt4
        filt5
        filt6
        filt7
        filt8
        filt9
        
        % Prototype lowpass coefficients
        coeff1
        coeff2
        coeff3
        coeff4
        coeff5
        coeff6
        coeff7
        coeff8
        coeff9
        
        % Vector of decimation factors
        decs
        
        % Vector of filter lengths
        coeffLen
        
        % For corrective mixer
        pFsd
        
        % Cached datatype and complexity
        pDatatype
        pIsInputComplex
        
        % Cached decimation factor and bandwidth
        pDecimationFactor
        pBandwidth
    end
    
    properties(Constant, Access = private)
        FilterNumber = ['1';'2';'3';'4';'5';'6';'7';'8';'9'];
        MaxFilters = 9;
    end
    
    
    properties (Access = protected)
        % Handle to freqz plot
        freqzHandle = -1;
        % NumChannels Cached number of channels (used for error checking)
        NumChannels(1,1) int32 = int32(-1);
    end
    
    methods
        % Constructor
        function obj = ComplexBandpassDecimator(varargin)
            setProperties(obj,nargin,varargin{:},...
                'DecimationFactor', 'CenterFrequency','SampleRate');
        end
        
        function set.CenterFrequency(obj,value)
            validateattributes(value,...
                {'double','single'}, ...
                {'real','scalar','finite'},...
                '','CenterFrequency');
            obj.CenterFrequency = value;
            needToDesignFilters(obj);
        end
        
        function set.SampleRate(obj,value)
            validateattributes(value,...
                {'double','single'}, ...
                {'real','scalar','positive','finite'},...
                '','SampleRate');
            obj.SampleRate = value;
            needToDesignFilters(obj);
        end
        
        function set.Specification(obj,val)
            obj.Specification = val;
            needToDesignFilters(obj);
        end
        
        function set.DecimationFactor(obj,val)
            obj.DecimationFactor = val;
            needToDesignFilters(obj);
        end
        
        function set.MinimizeComplexCoefficients(obj,val)
            obj.MinimizeComplexCoefficients = val;
            needToDesignFilters(obj);
        end
        
        function set.Bandwidth(obj,val)
            validateattributes(val,...
                {'double','single'}, ...
                {'real','scalar','positive','finite'},...
                '','Bandwidth');
            obj.Bandwidth = val;
            needToDesignFilters(obj);
        end
        
        function set.StopbandAttenuation(obj,Astop)
            validateattributes(Astop,{'numeric'},{'finite','scalar',...
                'real','>',0},'','StopbandAttenuation');
            %cast to enforce double precision on Astop
            obj.StopbandAttenuation = double(Astop);
            needToDesignFilters(obj);
        end
        
        function set.PassbandRipple(obj,Ap)
            validateattributes(Ap,{'numeric'},{'finite','scalar',...
                'real','>',0},'','PassbandRipple');
            %cast to enforce double precision on Astop
            obj.PassbandRipple = double(Ap);
            needToDesignFilters(obj);
        end
        
        function set.TransitionWidth(obj,TW)
            validateattributes(TW,{'numeric'},{'finite','scalar',...
                'real','>',0},'','TransitionWidth');
            %cast to enforce double precision on Astop
            obj.TransitionWidth = double(TW);
            needToDesignFilters(obj);
        end
        
        function  visualizeFilterStages(obj)
            %visualizeFilterStages(obj) Visualize filter stages
            %   visualizeFilterStages(obj) shows the response of each
            %   individual filter stage using FVTool.
            %   % Example: Visualize the stages for a decimate-by-12
            %   % filter:
            %   bp = dsp.ComplexBandpassDecimator(12,5000,44100);
            %   visualizeFilterStages(bp)
            [FsIn,~,g] = FsPerStage(obj);
            for idx = 1:obj.Nstages
                s{idx} = g.(['Stage', num2str(idx)]); %#ok<*EMCA>
            end
            fvtool(s{:},'Fs',FsIn,...
                'NormalizeMagnitudeto1','on','Legend','on');
        end
        
        function c = cost(obj)
            %C = cost(obj) Compute implementation cost
            %   C = cost(obj) returns a structure C whose fields contain
            %   information about the computation cost of implementing the
            %   complex bandpass decimator. The cost estimate contains the
            %   following fields:
            %   NumCoefficients                   : Number of filter 
            %                                       coefficients (excluding 
            %                                       coefficients with 
            %                                       values 0, 1 or -1)
            %   NumStates                         : Number of states
            %   RealMultiplicationsPerInputSample : Number of real 
            %                                       multiplications per 
            %                                       input sample
            %   RealAdditionsPerInputSample       : Number of real 
            %                                       additions per input 
            %                                       sample
            %
            %   A complex-by-complex multiplication is assumed to require 3
            %   real multiplications and 5 real additions.
            %
            %   % Example: Compute cost for a decimate-by-12
            %   % filter. 
            %   bp = dsp.ComplexBandpassDecimator(12,5000,44100);
            %   cost(bp)
            
            numAdds_a = 2; % First stage real additions (from adds)
            if isLocked(obj) &&  obj.pIsInputComplex
                numMult_m = 3; % First stage real multiplies (from multiplies)
                numAdds_m = 5; % First stage real additions  (from multiplies)
            else
                numMult_m = 2; % First stage real multiplies (from multiplies)
                numAdds_m = 0; % First stage real additions  (from multiplies)
            end
            
            if obj.MinimizeComplexCoefficients
                c = costMinimizeComplex(obj,numMult_m,numAdds_m,numAdds_a);
            else
                c = costAllComplex(obj,numMult_m,numAdds_m,numAdds_a);
            end
        end
        
        function varargout = freqz(obj,f,range)
            %[H,f] = freqz(obj,N,range) Frequency response
            %   [H,f] = freqz(obj,N,range) returns the complex frequency
            %   response H and the frequency vector f at which H is
            %   computed. N is the number of frequency points. If not
            %   specified, it defaults to 8192. range is the frequency
            %   range over which the response is computed; range can be
            %   either 'half' or 'whole'. If not specified, it defaults to
            %   'half'.
            %
            %   [H,f] = freqz(obj,f) returns the complex frequency response
            %   H computed at the frequency points specified by vector f.
            %   The vector f is assumed to be in Hz.
            %
            %   % Example: Compute the frequency response of a
            %   % decimate-by-12 filter:
            %   bp = dsp.ComplexBandpassDecimator(12,5000,44100); 
            %   [H,f] = freqz(bp); 
            %   plot(f,20*log10(abs(H))); grid on;
            %   xlabel('Frequency (Hz)'); ylabel('H (dB)');
            
            if nargin < 2
                f = 8192;
            end
            
            if nargin < 3
                range = 'half';
            else
                range = char(range);
            end
            
            [FsIn,rcf,g] = FsPerStage(obj);
            
            NStages = obj.Nstages;
            
            if length(f) == 1
                %NFFT specified
                MaxFreq = obj.SampleRate;
                if strcmpi(range,'half')
                    f = linspace(0,MaxFreq/2-MaxFreq/(2*f),f)';
                else
                    f = linspace(-MaxFreq/2,MaxFreq/2-MaxFreq/f,f)';
                end
            end
            
            [H,f] = freqz(g.Stage1,f,FsIn(1)*rcf(1,1));
            
            Fc = obj.CenterFrequency * obj.decs(1);
            Fs = obj.SampleRate;
            for k = 2:NStages
                if obj.MinimizeComplexCoefficients
                    coeffs = g.(['Stage',num2str(k)]).Numerator;
                    coeffs    = coeffs .*exp(1j*(Fc / Fs)*2*pi*(0:numel(coeffs)-1));
                    g.(['Stage',num2str(k)]).Numerator = coeffs;
                    Fc = Fc * obj.decs(k);
                end
                H = H.*freqz(g.(['Stage',num2str(k)]),f,FsIn(k)*rcf(k,1));
            end
            
            if nargout == 0
                % Plot frequency response
                if ishandle(obj.freqzHandle)
                    figure(obj.freqzHandle);
                else
                    obj.freqzHandle = figure;
                end
                
                subplot(2,1,1),plot(f,20*log10(abs(H)));
                grid on
                xlabel('Frequency (Hz)')
                ylabel('Magnitude (dB)')
                xlim([0 f(end)])
                subplot(2,1,2),plot(f,unwrap(angle(H)));
                grid on
                xlabel('Frequency (Hz)')
                ylabel('Phase (degrees)')
                xlim([0 f(end)])
                
            else
                if nargout > 0
                    varargout{1} = H;
                end
                if nargout > 1
                    varargout{2} = f;
                end
            end
        end
    end

    methods (Access=protected)
        
        function needToDesignFilters(obj)
            obj.AreFiltersDesigned = false;
        end
        
        function flag = isInactivePropertyImpl(obj, prop)
            flag = isInactivePropertyImpl@dsp.internal.SampleRateEngine(obj,prop);
            switch prop
                case 'DecimationFactor'
                    flag = strcmp(obj.Specification,'Bandwidth');
                case {'Bandwidth','PassbandRipple'}
                    flag = strcmp(obj.Specification,'Decimation factor');
                case 'MixToBaseband'
                    flag = obj.MinimizeComplexCoefficients;
            end
        end
        
        function [FsIn,rcf,g] = FsPerStage(obj)
            
            g = getFilters(obj);
            
            NStages = obj.Nstages;
            InFs = obj.SampleRate;
            
            % Store input rate of each filter in chain
            FsIn = zeros(NStages,1);
            FsIn(1) = InFs;
            
            % Store rate change of each filter
            rcf = zeros(NStages,2);
            
            for k = 1:NStages
                h = g.(['Stage',num2str(k)]);
                className = class(h);
                if strcmpi(className,'dsp.FIRDecimator')
                    rcf(k,:) = [1 h.DecimationFactor];
                else
                    rcf(k,:) = [1 1];
                end
                if k < NStages
                    FsIn(k+1) = FsIn(k)*rcf(k,1)/rcf(k,2);
                end
            end
        end
        
        function s = infoImpl(obj,varargin)
            
            g = getFilters(obj);
            c = cost(obj);
            
            NStages = obj.Nstages;
            s = '';
            
            M = obj.pDecimationFactor;
            
            s = [s,sprintf('Overall Decimation Factor       : %d\n',M)];
            s = [s,sprintf('Bandwidth                       : %d Hz\n',obj.pBandwidth)];
            
            if ~obj.MinimizeComplexCoefficients
                s = [s,sprintf('Output offset frequency         : %d Hz\n',getFrequencyOffset(obj))];
                if obj.MixToBaseband
                    str = 'yes';
                else
                    str = 'no';
                end
                s = [s,sprintf('Output heterodyned to DC        : %s\n',str)];
            end
            
            s = [s,sprintf('Number of Filters               : %d\n',NStages)];
            s = [s,sprintf('Real multiplications per Input Sample: %f\n',c.RealMultiplicationsPerInputSample)];
            s = [s,sprintf('Real additions per Input Sample      : %f\n',c.RealAdditionsPerInputSample)];
            s = [s,sprintf('Number of Coefficients               : %d\n',c.NumCoefficients)];
            s = [s,sprintf('Filters:                         \n')];
            for k = 1:NStages
                s = [s,sprintf('   Filter %d:\n',k)]; %#ok
                h = g.(['Stage',num2str(k)]);
                className = class(h);
                if strcmpi(className,'dsp.FIRDecimator')
                    s = [s,sprintf('   dsp.FIRDecimator     - Decimation Factor   : %d \n',h.DecimationFactor)]; %#ok
                elseif strcmpi(className,'dsp.FIRFilter')
                    s = [s,sprintf('   dsp.FIRFilter  - Decimation Factor: 1 \n')]; %#ok
                end
            end
        end
        
        function setupImpl(obj, u)
            
            setupImpl@dsp.internal.SampleRateEngine(obj,u);
            
            numchans = getNumChannels(obj,u);
            
            % Disallow a first step with zero channels
            coder.internal.errorIf(numchans == 0,'dsp:system:Shared:EmptyFirstStep');
            
            obj.NumChannels = int32(numchans);
            
            obj.pDatatype = class(u);
            obj.pIsInputComplex = ~isreal(u);
            
            setfilters(obj);
            obj.pOffset = cast(0,obj.pDatatype);
            
            if obj.MinimizeComplexCoefficients
                obj.pFsd  = cast(obj.SampleRate,obj.pDatatype) /cast(obj.decs(1),obj.pDatatype);
            else
                obj.pFsd  = cast(obj.SampleRate,obj.pDatatype) /cast(obj.pDecimationFactor,obj.pDatatype);
            end
            
            obj.AreFiltersDesigned = true;
        end
        
        function crossValidateProperties(obj)
            Fs = obj.SampleRate;
            
            Fc = obj.CenterFrequency(1);
            coder.internal.errorIf(Fc >= Fs/2 || Fc <= -Fs/2 ,...
                'dsp:system:ComplexBandpassDecimator:InvalidCenterFrequency');
            
            if strcmp(obj.Specification, 'Decimation factor')
                D  = obj.DecimationFactor;
                coder.internal.errorIf( Fc ~=0 && (Fc - Fs/(2*D) < -Fs/2 || Fc + Fs/(2*D) > Fs/2) ,...
                    'dsp:system:ComplexBandpassDecimator:NyquistBrokenDecimation');
            else
                BW  = obj.Bandwidth;
                coder.internal.errorIf( (Fc - BW/2 < -Fs/2 || Fc + BW/2 > Fs/2) ,...
                    'dsp:system:ComplexBandpassDecimator:NyquistBrokenBandwidth');
            end
        end
        
        function setDecimationFactor(obj)
            if strcmp(obj.Specification,'Decimation factor')
                obj.pDecimationFactor = obj.DecimationFactor;
                obj.pBandwidth        = obj.SampleRate / obj.DecimationFactor;
            elseif strcmp(obj.Specification,'Bandwidth')
                obj.pDecimationFactor = floor(obj.SampleRate / (obj.Bandwidth + obj.TransitionWidth) );
                obj.pBandwidth        = obj.Bandwidth;
            else
                obj.pBandwidth        = obj.Bandwidth;
                obj.pDecimationFactor = obj.DecimationFactor;
            end
        end
        
        function setfilters(obj)
            
            coder.extrinsic('dsp.ComplexBandpassDecimator.designfilters');
            
            setDecimationFactor(obj);
            
            if isempty(coder.target)
                if isempty(obj.pDatatype)
                    obj.pDatatype = 'double';
                end
            end
            
            [s, numStages] = coder.const(@obj.designfilters, ...
                obj.Specification, obj.SampleRate, obj.pDecimationFactor, obj.pBandwidth, obj.StopbandAttenuation,obj.PassbandRipple,obj.TransitionWidth,obj.pDatatype);
            
            obj.Nstages = numStages;
            decVect     = zeros(1,numStages,obj.pDatatype);
            
            if obj.MinimizeComplexCoefficients
                if s.rcf1(2) > 1
                    obj.filt1 =  dsp.FIRDecimator(...
                        'DecimationFactor',s.rcf1(2),...
                        'NumeratorSource','Input port',...
                        'AllowArbitraryInputLength', ...
                        coder.const(isInputArbitraryOrVarSize(obj,s.rcf1(2))));
                else
                    obj.filt1 =  dsp.FIRFilter('NumeratorSource','Input port');
                end
                obj.coeff1   = s.coeff1;
                obj.coeffLen = numel(s.coeff1);
                decVect(1) = s.rcf1(2);
                
                for k = coder.unroll(2:obj.MaxFilters, true)
                    if k<=obj.Nstages
                        % Decimator
                        if s.(['rcf',obj.FilterNumber(k)])(2) > 1
                            obj.(['filt',obj.FilterNumber(k)]) = dsp.FIRDecimator(...
                                'DecimationFactor',s.(['rcf',obj.FilterNumber(k)])(2),...
                                'Numerator',s.(['coeff',obj.FilterNumber(k)]),...
                                'AllowArbitraryInputLength', ...
                                coder.const(isInputArbitraryOrVarSize(obj,s.(['rcf',obj.FilterNumber(k)])(2))));
                        else
                            obj.(['filt',obj.FilterNumber(k)]) = dsp.FIRFilter(...
                                'Numerator',s.(['coeff',obj.FilterNumber(k)]));
                        end
                        decVect(k) = s.(['rcf',obj.FilterNumber(k)])(2);
                    end
                end
                obj.decs     = decVect;
            else
                
                clen        = zeros(1,numStages,obj.pDatatype);
                
                for k = coder.unroll(1:obj.MaxFilters, true)
                    if k<=obj.Nstages
                        
                        if s.(['rcf',obj.FilterNumber(k)])(2) > 1
                            obj.(['filt',obj.FilterNumber(k)]) = dsp.FIRDecimator(...
                                'DecimationFactor',s.(['rcf',obj.FilterNumber(k)])(2),...
                                'NumeratorSource','Input port',...
                                'AllowArbitraryInputLength', ...
                                coder.const(isInputArbitraryOrVarSize(obj,s.(['rcf',obj.FilterNumber(k)])(2))));
                        else
                            obj.(['filt',obj.FilterNumber(k)]) = dsp.FIRFilter(...
                                'NumeratorSource','Input port');
                        end
                        
                        obj.(['coeff',obj.FilterNumber(k)]) = s.(['coeff',obj.FilterNumber(k)]);
                        decVect(k) = s.(['rcf',obj.FilterNumber(k)])(2);
                        clen(k) = numel(s.(['coeff',obj.FilterNumber(k)]));
                    end
                end
                
                obj.decs     = decVect;
                obj.coeffLen = clen;
            end
            
            tuneCoefficients(obj);
        end
        
        function tuneCoefficients(obj)
            
            % Perform frequency shift on coefficients to get bandpass filter
            dt = obj.pDatatype;
            numStages = obj.Nstages;
            FcVect    = zeros(1,numStages,dt);
            
            DVect = obj.decs;
            Fc = cast(obj.CenterFrequency,dt);
            Fs  = cast(obj.SampleRate,dt);
            piDT = cast(pi,dt);
            
            if obj.MinimizeComplexCoefficients
                
                obj.bp_coeff1     = obj.coeff1 .*exp(1j*(Fc/ Fs)*2*piDT*(0:obj.coeffLen-1));
                
                % Check if selected center frequency is of the form K*Fs/M
                BWFactor = cast(DVect(1),dt);
                fd = Fc -(Fs/BWFactor)*floor((BWFactor*Fc + Fs/2)/Fs);
                obj.pcf   = fd;
                obj.useExtraMixer = ~(fd == 0);
            else
                M  = cast(1,dt);
                
                for index = 1:numStages
                    FcVect(index) = M * Fc;
                    M  = M * DVect(index);
                end
                
                obj.bp_coeff1     = obj.coeff1 .*exp(1j*(FcVect(1) / Fs)*2*piDT*(0:obj.coeffLen(1)-1));
                if (numStages > 1)
                    obj.bp_coeff2 = obj.coeff2 .*exp(1j*(FcVect(2) / Fs)*2*piDT*(0:obj.coeffLen(2)-1));
                end
                if (numStages > 2)
                    obj.bp_coeff3 = obj.coeff3 .*exp(1j*(FcVect(3) / Fs)*2*piDT*(0:obj.coeffLen(3)-1));
                end
                if (numStages > 3)
                    obj.bp_coeff4 = obj.coeff4 .*exp(1j*(FcVect(4) / Fs)*2*piDT*(0:obj.coeffLen(4)-1));
                end
                if (numStages > 4)
                    obj.bp_coeff5 = obj.coeff5 .*exp(1j*(FcVect(5) / Fs)*2*piDT*(0:obj.coeffLen(5)-1));
                end
                if (numStages > 5)
                    obj.bp_coeff6 = obj.coeff6 .*exp(1j*(FcVect(6) / Fs)*2*piDT*(0:obj.coeffLen(6)-1));
                end
                if (numStages > 6)
                    obj.bp_coeff7 = obj.coeff7 .*exp(1j*(FcVect(7) / Fs)*2*piDT*(0:obj.coeffLen(7)-1));
                end
                if (numStages > 7)
                    obj.bp_coeff8 = obj.coeff8 .*exp(1j*(FcVect(8) / Fs)*2*piDT*(0:obj.coeffLen(8)-1));
                end
                if (numStages > 8)
                    obj.bp_coeff9 = obj.coeff9 .*exp(1j*(FcVect(9) / Fs)*2*piDT*(0:obj.coeffLen(9)-1));
                end
                
                % Check if selected center frequency is of the form K*Fs/M
                BWFactor = cast(obj.pDecimationFactor,dt);
                fd = Fc -(Fs/BWFactor)*floor((BWFactor*Fc + Fs/2)/Fs);
                obj.pcf   = fd;
                obj.useExtraMixer = ~(fd == 0) && obj.MixToBaseband;
            end
            
        end
        
        function processTunedPropertiesImpl(obj)
            processTunedPropertiesImpl@ dsp.internal.SampleRateEngine(obj);
            tuneCoefficients(obj)
        end
        
        function resetImpl(obj)
            % Reset the filters
            for k = coder.unroll(1:obj.MaxFilters, true)
                if k<=obj.Nstages
                    reset(obj.(['filt',obj.FilterNumber(k)]));
                end
            end
            obj.pOffset = cast(0,obj.pDatatype);
        end
        
        function releaseImpl(obj)
            % Release the filters
            for k = coder.unroll(1:obj.MaxFilters, true)
                if k<=obj.Nstages
                    release(obj.(['filt',obj.FilterNumber(k)]));
                end
            end
            obj.NumChannels = int32(-1);
        end
        
        function z = stepImpl(obj, u)
            if isempty(u)
                z = u;
                return;
            end
            
            if obj.MinimizeComplexCoefficients
                
                y0 = step(obj.filt1,u,complex(obj.bp_coeff1));
                
                y1 = mix(obj,y0);
                
                if obj.Nstages > 1
                    y2 = step(obj.filt2,y1);
                else
                    z = y1;
                    return;
                end
                if obj.Nstages > 2
                    y3 = step(obj.filt3,y2);
                else
                    z = y2;
                    return;
                end
                if obj.Nstages > 3
                    y4 = step(obj.filt4,y3);
                else
                    z = y3;
                    return;
                end
                if obj.Nstages > 4
                    y5 = step(obj.filt5,y4);
                else
                    z = y4;
                    return;
                end
                if obj.Nstages > 5
                    y6 = step(obj.filt6,y5);
                else
                    z = y5;
                    return;
                end
                if obj.Nstages > 6
                    y7 = step(obj.filt7,y6);
                else
                    z = y6;
                    return;
                end
                if obj.Nstages > 7
                    y8 = step(obj.filt8,y7);
                else
                    z = y7;
                    return;
                end
                if obj.Nstages > 8
                    z = step(obj.filt9,y8);
                else
                    z = y8;
                end
            else
                y1 = step(obj.filt1,u,complex(obj.bp_coeff1));
                if obj.Nstages > 1
                    y2 = step(obj.filt2,y1,complex(obj.bp_coeff2));
                else
                    z = mix(obj,y1);
                    return;
                end
                if obj.Nstages > 2
                    y3 = step(obj.filt3,y2,complex(obj.bp_coeff3));
                else
                    z = mix(obj,y2);
                    return;
                end
                if obj.Nstages > 3
                    y4 = step(obj.filt4,y3,complex(obj.bp_coeff4));
                else
                    z = mix(obj,y3);
                    return;
                end
                if obj.Nstages > 4
                    y5 = step(obj.filt5,y4,complex(obj.bp_coeff5));
                else
                    z = mix(obj,y4);
                    return;
                end
                if obj.Nstages > 5
                    y6 = step(obj.filt6,y5,complex(obj.bp_coeff6));
                else
                    z = mix(obj,y5);
                    return;
                end
                if obj.Nstages > 6
                    y7 = step(obj.filt7,y6,complex(obj.bp_coeff7));
                else
                    z = mix(obj,y6);
                    return;
                end
                if obj.Nstages > 7
                    y8 = step(obj.filt8,y7,complex(obj.bp_coeff8));
                else
                    z = mix(obj,y7);
                    return;
                end
                if obj.Nstages > 8
                    y = step(obj.filt9,y8,complex(obj.bp_coeff9));
                    z = mix(obj,y);
                else
                    z = mix(obj,y8);
                    return;
                end
            end
        end
        
        function z = mix(obj,y)
            if obj.useExtraMixer
                l = repmat((0:cast(size(y,1),obj.pDatatype) -1).',1,size(y,2));
                offset = obj.pOffset;
                z = exp(-2*cast(pi,obj.pDatatype)*(l+offset)*obj.pcf/obj.pFsd*1j) .* y;
                offset = offset + size(y,1);
                obj.pOffset = offset;
            else
                z = y;
            end
        end
        
        
        function C = getFilters(obj)
            %C = getFilters(obj) get filters
            if ~obj.AreFiltersDesigned
                setfilters(obj);
                obj.AreFiltersDesigned = true;
            end
            
            myfilt = clone(obj.filt1);
            release(myfilt);
            myfilt.NumeratorSource = 'Property';
            myfilt.Numerator = complex(obj.bp_coeff1);
            
            C = dsp.FilterCascade(myfilt);
            
            for idx = 2:obj.Nstages
                myfilt = clone(obj.(['filt', num2str(idx)]));
                release(myfilt);
                if ~obj.MinimizeComplexCoefficients
                    myfilt.NumeratorSource = 'Property';
                    myfilt.Numerator = complex(obj.(['bp_coeff', num2str(idx)]));
                end
                addStage(C,myfilt);
            end
        end
        
        function validateInputsImpl(obj,u)
            if isempty(u)
                return;
            end
            validateattributes(u, {'single', 'double'}, {'2d'},'','')
                      
            if obj.NumChannels ~= -1 && obj.NumChannels ~= 0
                coder.internal.errorIf(size(u,2) ~= obj.NumChannels, ['dsp:system',...
                    ':Shared:numChannels']);
            end
        end
        
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            if isLocked(obj)
                
                s.Nstages = obj.Nstages;
                for k = coder.unroll(1:obj.MaxFilters, true)
                    if k<=obj.Nstages
                        s.(['filt',obj.FilterNumber(k)]) = matlab.System.saveObject(obj.(['filt',obj.FilterNumber(k)]));
                    end
                end
                
                s.bp_coeff1 = obj.bp_coeff1;
                s.bp_coeff2 = obj.bp_coeff2;
                s.bp_coeff3 = obj.bp_coeff3;
                s.bp_coeff4 = obj.bp_coeff4;
                s.bp_coeff5 = obj.bp_coeff5;
                s.bp_coeff6 = obj.bp_coeff6;
                s.bp_coeff7 = obj.bp_coeff7;
                s.bp_coeff8 = obj.bp_coeff8;
                s.bp_coeff9 = obj.bp_coeff9;
                
                s.pcf = obj.pcf;
                
                s.useExtraMixer = obj.useExtraMixer;
                s.pOffset = obj.pOffset;
                
                s.coeff1 = obj.coeff1;
                s.coeff2 = obj.coeff2;
                s.coeff3 = obj.coeff3;
                s.coeff4 = obj.coeff4;
                s.coeff5 = obj.coeff5;
                s.coeff6 = obj.coeff6;
                s.coeff7 = obj.coeff7;
                s.coeff8 = obj.coeff8;
                s.coeff9 = obj.coeff9;
                s.decs = obj.decs;
                s.coeffLen = obj.coeffLen;
                s.pFsd = obj.pFsd;
                s.pDatatype = obj.pDatatype;
                s.pIsInputComplex = obj.pIsInputComplex;
                s.pDecimationFactor = obj.pDecimationFactor;
                s.pBandwidth = obj.pBandwidth;
                
                s.NumChannels = obj.NumChannels;
            end
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                obj.Nstages = s.Nstages;
                for k = coder.unroll(1:obj.MaxFilters, true)
                    if k<=obj.Nstages
                        obj.(['filt',obj.FilterNumber(k)]) = matlab.System.loadObject(s.(['filt',obj.FilterNumber(k)]));
                    end
                end
                
                obj.bp_coeff1 = s.bp_coeff1;
                obj.bp_coeff2 = s.bp_coeff2;
                obj.bp_coeff3 = s.bp_coeff3;
                obj.bp_coeff4 = s.bp_coeff4;
                obj.bp_coeff5 = s.bp_coeff5;
                obj.bp_coeff6 = s.bp_coeff6;
                obj.bp_coeff7 = s.bp_coeff7;
                obj.bp_coeff8 = s.bp_coeff8;
                obj.bp_coeff9 = s.bp_coeff9;
                
                obj.pcf = s.pcf;
                
                obj.useExtraMixer = s.useExtraMixer;
                obj.pOffset = s.pOffset;
                
                obj.coeff1 = s.coeff1;
                obj.coeff2 = s.coeff2;
                obj.coeff3 = s.coeff3;
                obj.coeff4 = s.coeff4;
                obj.coeff5 = s.coeff5;
                obj.coeff6 = s.coeff6;
                obj.coeff7 = s.coeff7;
                obj.coeff8 = s.coeff8;
                obj.coeff9 = s.coeff9;
                obj.decs = s.decs;
                obj.coeffLen = s.coeffLen;
                obj.pFsd = s.pFsd;
                obj.pDatatype = s.pDatatype;
                obj.pIsInputComplex = s.pIsInputComplex;
                obj.pDecimationFactor = s.pDecimationFactor;
                obj.pBandwidth        = s.pBandwidth;
                obj.NumChannels       = s.NumChannels;
            end
            loadObjectImpl@matlab.System(obj, s, wasLocked);
        end
        
        function foffset = getFrequencyOffset(obj)
            %offset = getFrequencyOffset(obj) get frequency offset
            %   offset = getFrequencyOffset(obj) returns the frequency at
            %   which the decimated, filtered output is centered. If the
            %   MixToBaseband property is true, the filter heterodynes the
            %   output to DC.
            if isLocked(obj)
                foffset = obj.pcf;
            else
                Fs = obj.SampleRate;
                
                if strcmp(obj.Specification,'Decimation factor')
                    D = obj.DecimationFactor;
                elseif strcmp(obj.Specification,'Bandwidth')
                    D = floor(Fs / (obj.Bandwidth + obj.TransitionWidth) );
                else
                    D = obj.DecimationFactor;
                end
                
                Fc = obj.CenterFrequency;
                foffset = Fc -(Fs/D)*floor((D*Fc + Fs/2)/Fs);
            end
        end
          
        function c = costAllComplex(obj,numMult_m,numAdds_m,numAdds_a)
            g = getFilters(obj);
            
            if obj.CenterFrequency ~= 0
                
                multiplicationsPerInputSample = 0;
                additionsPerInputSample       = 0;
                
                M = 1;
                % All stages have complex coefficients
                for index = 1:obj.Nstages
                    cstage = cost(g.(['Stage' num2str(index)]));
                    % Stage 1
                    if index==1
                        multiplicationsPerInputSample = multiplicationsPerInputSample + ...
                                                        numMult_m * cstage.MultiplicationsPerInputSample/M;
                        additionsPerInputSample       = additionsPerInputSample + ...
                                                        numAdds_m * cstage.MultiplicationsPerInputSample/M + ...
                                                        numAdds_a * cstage.AdditionsPerInputSample/M;
                    else
                        multiplicationsPerInputSample = multiplicationsPerInputSample + 3 * cstage.MultiplicationsPerInputSample/M;
                        additionsPerInputSample       = additionsPerInputSample + 5 * cstage.MultiplicationsPerInputSample/M + 2 * cstage.AdditionsPerInputSample/M;
                    end
                    if isa(g.(['Stage' num2str(index)]),'dsp.FIRDecimator')
                        M = M *  g.(['Stage' num2str(index)]).DecimationFactor;
                    end
                end
                
                % Mixer: Input is complex, coeff is complex
                if obj.MixToBaseband && obj.useExtraMixer
                    multiplicationsPerInputSample = multiplicationsPerInputSample + 3/obj.pDecimationFactor;
                    additionsPerInputSample       = additionsPerInputSample       + 5/obj.pDecimationFactor;
                end
                
                call = cost(g);
                
                c.NumCoefficients                   = call.NumCoefficients;
                c.NumStates                         = call.NumStates;
                c.RealMultiplicationsPerInputSample = multiplicationsPerInputSample;
                c.RealAdditionsPerInputSample       = additionsPerInputSample;
            else
                % Does this take the complexity of the input into account?
                call = cost(g);
                c.NumCoefficients = call.NumCoefficients;
                c.NumStates       = call.NumStates;
                if numMult_m == 3 % Complex input
                    c.RealMultiplicationsPerInputSample = 2 * call.MultiplicationsPerInputSample;
                    c.RealAdditionsPerInputSample       = 2 * call.AdditionsPerInputSample;
                else
                    c.RealMultiplicationsPerInputSample = call.MultiplicationsPerInputSample;
                    c.RealAdditionsPerInputSample       = call.AdditionsPerInputSample;
                end
            end
            
        end
        
        function c = costMinimizeComplex(obj,numMult_m,numAdds_m,numAdds_a)
            
            g = getFilters(obj);
            
            if obj.CenterFrequency ~= 0
                multiplicationsPerInputSample = 0;
                additionsPerInputSample       = 0;
                
                % Stage1 has complex coefficients
                c1 = cost(g.Stage1);
                multiplicationsPerInputSample = multiplicationsPerInputSample + ...
                                                numMult_m * c1.MultiplicationsPerInputSample;
                additionsPerInputSample       = additionsPerInputSample       + ...
                                                numAdds_m * c1.MultiplicationsPerInputSample +...
                                                numAdds_a * c1.AdditionsPerInputSample;
                
                % Mixer: Input is complex, coeff is complex
                if obj.useExtraMixer
                    if isa(g.Stage1,'dsp.FIRDecimator')
                        multiplicationsPerInputSample = multiplicationsPerInputSample + 3/g.Stage1.DecimationFactor;
                        additionsPerInputSample       = additionsPerInputSample       + 5/g.Stage1.DecimationFactor;
                        M = g.Stage1.DecimationFactor;
                    else
                        multiplicationsPerInputSample = multiplicationsPerInputSample + 3;
                        additionsPerInputSample       = additionsPerInputSample       + 5;
                        M = 1;
                    end
                end
                
                for index = 2:obj.Nstages
                    cstage = cost(g.(['Stage' num2str(index)]));
                    multiplicationsPerInputSample = multiplicationsPerInputSample + 2 * cstage.MultiplicationsPerInputSample/M;
                    additionsPerInputSample       = additionsPerInputSample + 2 * cstage.AdditionsPerInputSample/M;
                    if isa(g.(['Stage' num2str(index)]),'dsp.FIRDecimator')
                        M = M *  g.(['Stage' num2str(index)]).DecimationFactor;
                    end
                end
                
                call = cost(g);
                
                c.NumCoefficients                   = call.NumCoefficients;
                c.NumStates                         = call.NumStates;
                c.RealMultiplicationsPerInputSample = multiplicationsPerInputSample;
                c.RealAdditionsPerInputSample       = additionsPerInputSample;
                
            else
                call = cost(g);
                c.NumCoefficients = call.NumCoefficients;
                c.NumStates       = call.NumStates;
                if numMult_m == 3 % Complex input
                    c.RealMultiplicationsPerInputSample = 2 * call.MultiplicationsPerInputSample;
                    c.RealAdditionsPerInputSample       = 2 * call.AdditionsPerInputSample;
                else
                    c.RealMultiplicationsPerInputSample = call.MultiplicationsPerInputSample;
                    c.RealAdditionsPerInputSample       = call.AdditionsPerInputSample;
                end
            end
        end

    end
    
    methods (Static, Hidden)
        function [s, Nstages] = designfilters(Spec, SampleRate, ...
                DecimationFactor, BW ,  Astop, Ap, TW, dt)

            % Suppress MFILT deprecation warning on calling design method
            % without "SystemObject" flag set to true.
            w = warning('off', 'dsp:fdesign:basecatalog:UseSystemObjectForMultirateDesigns');
            restoreWarn = onCleanup(@() warning(w));
            
            M1  = DecimationFactor;
            
            if strcmp(Spec,'Decimation factor')
                
                coder.internal.errorIf(...
                    M1 < 2, ...
                    'dsp:system:ComplexBandpassDecimator:DecimationFactorOne');
                
                fmd                  = dsp.filterdesign.internal.nyquistNstage;
                fmd.RateChangeFactor = M1;
                fmd.TransitionWidth  = TW;
                fmd.Astop            = Astop;
                fmd.SampleRate       = SampleRate;
            else
                Fp  = BW/2;
                fmd                  = dsp.filterdesign.internal.equirippleNstage;
                fmd.RateChangeFactor = M1;
                fmd.Fpass            = Fp;
                fmd.TransitionWidth  = TW;
                fmd.Apass            = Ap;
                fmd.Astop            = Astop;
                fmd.SampleRate       = SampleRate;
            end
            
            if TW / (0.5*SampleRate/M1) < 1e-3
                 coder.internal.warning(...
                    'dsp:system:ComplexBandpassDecimator:NarrowTransitionWidth')
            end
            
            if (M1 > 2)                
                hmd = dynprogDesign(fmd);
            else                
                fmd.HalfbandDesignMethod = 'kaiserwin';
                hmd = dynprogDesign(fmd);
            end
            
            finalIdx = 0;
            s = struct;
            
            Nstages = getNumStages(hmd);
            coder.internal.errorIf(...
                Nstages > 9, ...
                'dsp:system:ComplexBandpassDecimator:TooManyStages');
            for k = 1:Nstages
                finalIdx = finalIdx + 1;
                s.(['coeff',num2str(finalIdx)]) = ...
                    cast(hmd.(['Stage',num2str(k)]).Numerator,dt);
                if isa(hmd.(['Stage',num2str(k)]),'dsp.FIRDecimator')
                    s.(['rcf',num2str(finalIdx)]) = ...
                        cast([1,hmd.(['Stage',num2str(k)]).DecimationFactor],dt);
                else
                    s.(['rcf',num2str(finalIdx)]) = ...
                        cast([1,1],dt);
                end
            end                        
        end
    end
    
    %----------------------------------------------------------------------
    methods(Static,Access=protected)
        function groups = getPropertyGroupsImpl
            
            props = {'CenterFrequency',...
                'Specification',...
                'DecimationFactor',...
                'Bandwidth',...
                'StopbandAttenuation',...
                'PassbandRipple',...
                'TransitionWidth',...
                'MinimizeComplexCoefficients',...
                'MixToBaseband',...
                'InheritSampleRate',...
                'SampleRate'};
            
            mainS = matlab.system.display.Section('Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', props);
            filterVis = dsp.internal.FilterVisualizationButton;
            mainS.Actions = filterVis.fvtoolAction;
            mainSG = matlab.system.display.SectionGroup('TitleSource', 'Auto', ...
                'Sections', mainS);
            
            groups = mainSG;
        end
        
    end
    
end
