classdef (StrictDefaults)ColoredNoise < dsp.ColoredNoise
%ColoredNoise Generate a colored noise signal
%  This class is used by the Colored Noise block and is intended for usage 
%  inside a MATLAB System block only. If you want to use the object in 
%  MATLAB, use dsp.ColoredNoise instead.
%
%  ColoredNoise properties:
%
%  Color                 - Noise Color
%  InverseFrequencyPower - Define alpha, inverse frequency power in
%                          spectral characteristic 1/f^alpha.
%  SamplesPerFrame       - Number of samples per output channel
%  NumChannels           - Number of output channels
%  RandomStream          - Source of random number stream
%  Seed                  - Initial seed of mt19937ar random number stream
%  OutputDataType        - Output data type
%  BoundedOutput         - Guarantee the output is bounded (+/-1)
%  SampleTime            - Output sample time
%
%  See also dsp.ColoredNoise

%  Copyright 2014-2022 The MathWorks, Inc.

%#codegen
%#ok<*EMCA>

    properties (Nontunable)
        %SampleTime Output sample time (s)
        %   Specify the sample time (in second) as a positive scalar
        %   The default value of this property is 1.
        SampleTime = 1;
    end

    methods
        % Constructor
        function obj = ColoredNoise(varargin)
            setProperties(obj, nargin, varargin{:});
        end
        
        function set.SampleTime(obj, val)
            validateattributes(val, ...
                {'double'}, ...
                {'real', 'positive', 'scalar', 'finite'}, ...
                'set.SampleTime', ...
                'SampleTime');
            obj.SampleTime = val;
        end 
    end

    methods (Access=protected)

        % For MATLAB System block
        function varargout = isOutputComplexImpl(~)
            varargout = {false};
        end

        function varargout = getOutputSizeImpl(obj)
            varargout = {[obj.SamplesPerFrame obj.NumChannels]};
        end

        function varargout = getOutputDataTypeImpl(obj)
            varargout = {obj.OutputDataType};
        end
        
        function varargout = isOutputFixedSizeImpl(~)
            varargout = {true};
        end        
        
        function sts = getSampleTimeImpl(obj)
            Ts = obj.SampleTime * obj.SamplesPerFrame;
            sts = createSampleTime(obj, 'Type', 'Discrete', 'SampleTime', Ts);
        end 
        
        function str = getIconImpl(obj)
            switch obj.Color
                case 'pink'
                    str = getString(message('dsp:system:ColoredNoise:iconStringPink'));
                case 'brown'
                    str = getString(message('dsp:system:ColoredNoise:iconStringBrown'));
                case 'white'
                    str = getString(message('dsp:system:ColoredNoise:iconStringWhite'));
                case 'blue'
                    str = getString(message('dsp:system:ColoredNoise:iconStringBlue'));
                case 'purple'
                    str = getString(message('dsp:system:ColoredNoise:iconStringPurple'));
                case 'custom'
                    str = getString(message('dsp:system:ColoredNoise:iconStringCustom'));
            end
            str = sprintf(str);
        end   
        
        function varargout = getOutputNamesImpl(~)
            varargout = {''};
        end   
        
        function b = supportsMultipleInstanceImpl(~)
            b = true;
        end
    end
    
    methods(Static, Access = protected)
        
        function header = getHeaderImpl
            header = matlab.system.display.Header('dsp.simulink.ColoredNoise', ...
                'ShowSourceLink', false, ...
                'Title', 'dsp:system:ColoredNoise:titleString',...
                'Text',  'dsp:system:ColoredNoise:textString');
        end
        
        function groups = getPropertyGroupsImpl
            props = {...
                matlab.system.display.internal.Property('Color','Description','dsp:system:ColoredNoise:Color_MP'), ...
                matlab.system.display.internal.Property('InverseFrequencyPower','Description','dsp:system:ColoredNoise:InverseFrequencyPower_MP'), ...
                matlab.system.display.internal.Property('BoundedOutput','Description','dsp:system:ColoredNoise:BoundedOutput_MP'), ...
                matlab.system.display.internal.Property('NumChannels','Description','dsp:system:ColoredNoise:NumChannels_MP'), ...
                matlab.system.display.internal.Property('OutputDataType','Description','dsp:system:ColoredNoise:OutputDataType_MP'), ...
                matlab.system.display.internal.Property('SamplesPerFrame','Description','dsp:system:ColoredNoise:SamplesPerFrame_MP'), ...
                matlab.system.display.internal.Property('SampleTime','Description','dsp:system:ColoredNoise:SampleTime_MP')};

            param = matlab.system.display.Section( ...
                'Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', props);
            
            pRandStream = matlab.system.display.internal.Property('RandomStream','IsGraphical', false, 'UseClassDefault', false, 'Default', 'mt19937ar with seed','Description','dsp:system:ColoredNoise:RandomStream_MP');
            pSeed = matlab.system.display.internal.Property('Seed','Description','dsp:system:ColoredNoise:Seed_MP');
            randomization = matlab.system.display.Section( ...
                'Title', getString(message('dsp:system:ColoredNoise:randomizationSection')), ...
                'PropertyList', {pRandStream, pSeed});
            
            groups = [param randomization];
        end
    end      
end
