classdef (StrictDefaults)SampleRateConverter < dsp.SampleRateConverter
% This class is used for the Sample Rate Converter block in dspsigops

% Copyright 2021-2023 The MathWorks, Inc.

%#codegen
properties (Nontunable)
     %AllowArbitraryInputLength Allow arbitrary input length in Codegen
        %  When this flag is set to false, input frames in code generation
        %  must have a length that is a multiple of the decimation factor.
        %  Using an input which doesn't satisfy the length requirement
        %  results with an error.
        %  When this flag is set to true, input size is notrestricted and 
        %  can be arbitrary, but the output may have a variable size.
        %  Use this flag for cases that require fixed frame sizes, such
        %  as code generation requirements where the output size must be
        %  fixed. The default value is 'false'.
        AllowArbitraryInputLength (1,1) logical = false;
end
methods
    function obj = SampleRateConverter(varargin)
        %Constructor
        obj = obj@dsp.SampleRateConverter(varargin{:});
    end
end

methods (Access=protected)
    function sts = getSampleTimeImpl(obj)
        % Object has states. Disallow const sample time
        sts = createSampleTime(obj, Type = 'Inherited', Disallow='Constant');
    end

    function setupImpl(obj, u)        
        dsp.internal.checkSampleTime(obj);
        setupImpl@dsp.SampleRateConverter(obj, u);
    end

    % Block Icon
    function icon = getIconImpl(~)
        icon = getString(message('dsp:system:SampleRateConverter:BlockIcon'));
    end
    
    function varargout = getInputNamesImpl(~)
        varargout{1} = '';
    end
    
    function varargout = getOutputNamesImpl(~)
        varargout{1} = '';
    end
    
    function flag = supportsMultipleInstanceImpl(obj)
        flag = isFixedSizeOutput(obj);
    end

    %Propagators
    function isComplex = isOutputComplexImpl(obj)
        isComplex = propagatedInputComplexity(obj, 1);
    end
    
    function outputSize = getOutputSizeImpl(obj)

        [~, Mnet] = getRateChangeFactors(obj);      
        inputSize =  propagatedInputSize(obj, 1);
        fixedInput = propagatedInputFixedSize(obj,1);
        if isempty(fixedInput)
            fixedInput = false;
        end
        
        % Enforce length conditions if arbitrary length is not allowed
        if obj.AllowArbitraryInputLength == false
            arbsizelabel = message('dsp:blkprm_prompts:EnableArbitrary_MP').getString;
            coder.internal.errorIf(fixedInput && rem(inputSize(1),Mnet), ...
                                'dsp:system:SampleRateConverter:frameSize', Mnet, arbsizelabel);
        end
        C = getFilters(obj);    
        [L, M] = rateConversionFactorsVectors(C);
        nStages = getNumStages(C);
        outputframeLength = inputSize(1);
        for i = 1:nStages
            outputframeLength = ceil(outputframeLength * L(i)/M(i));
        end

        outputSize = [ outputframeLength inputSize(2)];
    end

    function outputDT = getOutputDataTypeImpl(obj)
        outputDT = propagatedInputDataType(obj, 1);
    end
    
    function flag = isInputSizeMutableImpl(~,~)
            flag = true;
    end
    function isFixedOutput = isOutputFixedSizeImpl(obj)
        % If varsize input or arbitrary input allowed => varsize output,
        % otherwise fixed
        isFixedOutput = isFixedSizeOutput(obj);

    end
    function isFixedOutput = isFixedSizeOutput(obj)
        % If varsize input or arbitrary input allowed =>varsize output, otherwise fixed
        isFixedOutput = propagatedInputFixedSize(obj,1) && ~obj.AllowArbitraryInputLength;
    end  
end

methods(Static, Access=protected)
    function group = getPropertyGroupsImpl
        %Get default parameters group for this System object

        propertyList = {
            matlab.system.display.internal.Property('InputSampleRate','Description','dsp:system:SampleRateConverter:InputSampleRate_MP'), ...
            matlab.system.display.internal.Property('OutputSampleRate','Description','dsp:system:SampleRateConverter:OutputSampleRate_MP'), ...
            matlab.system.display.internal.Property('OutputRateTolerance','Description','dsp:system:SampleRateConverter:OutputRateTolerance_MP'), ...
            matlab.system.display.internal.Property('Bandwidth','Description','dsp:system:SampleRateConverter:Bandwidth_MP'), ...
            matlab.system.display.internal.Property('StopbandAttenuation','Description','dsp:system:SampleRateConverter:StopbandAttenuation_MP'), ...
            matlab.system.display.internal.Property('AllowArbitraryInputLength','Description','dsp:blkprm_prompts:EnableArbitrary_MP'), ...
        };

        parameterString = message('dsp:system:Shared:Parameters');
        group = matlab.system.display.Section(Title=parameterString.getString, PropertyList=propertyList);
        
        % Visualize button
        filterVis = dsp.internal.FilterVisualizationButton;
        
        % Info button
        filterInfo = dsp.simulink.internal.FilterInfoButton;
        
        group.Actions = [filterVis.fvtoolAction , filterInfo.infoAction];
    end
    
    %------------------------------------------------------------------
    function header = getHeaderImpl
        % MATLAB System block header
        header = matlab.system.display.Header(...
            'dsp.simulink.SampleRateConverter', ...
            ShowSourceLink = true, ...
            Title = 'dsp:system:SampleRateConverter:BlockTitle',...
            Text = 'dsp:system:SampleRateConverter:BlockDescription');
    end
end

methods (Hidden)
    function f = callFvtool(obj)
        % Used to bring up fvtool plot when object is used in Simulink
        freqz(obj,8192,'half');
        f = obj.freqzHandle;
        freqzName = message('dsp:system:Shared:filterResponseName','').getString;
        set(f,'Name',freqzName);
    end
    
    function f = updateFvtoolFigure(obj,~)
        % Used to update fvtool plot when object is used in Simulink
        freqz(obj,8192,'half');
        f = obj.freqzHandle;
    end
    
    function f = updateFvtoolLegend(~, f, blkh)
        % Used to update fvtool legend when object is used in Simulink
        legendStr = get_param(blkh, 'Name');
        ax = get(f, 'Children');
        legend(ax(1), legendStr);
        legend(ax(2), legendStr);
    end

    function [flag,errID] = isFVtoolSupported(~)
        % Method used in visualize button on block
        flag = true;
        errID = '';
    end
    
    function infoText = getFilterInfo(obj)
        % Used to return the info text that will be shown when the
        % filter info for the block is shown
        infoText = info(obj);
    end
end
end %classdef
