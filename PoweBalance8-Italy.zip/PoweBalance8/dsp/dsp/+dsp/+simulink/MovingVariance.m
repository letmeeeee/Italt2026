classdef (StrictDefaults)MovingVariance < dsp.MovingVariance
    %

    % Copyright 2017-2022 The MathWorks, Inc.
        
    %#codegen
    %#ok<*EMCA>
    
   properties (Nontunable)
        % ForgettingFactorPort Specify forgetting factor from input port
        ForgettingFactorPort (1, 1) logical = false;

        %AllowArbitraryInputLength Allow arbitrary input length
        %   When this flag is set to false, input frame length must be a
        %   multiple of the Hop Size (Window Length - Overlap Length).
        %   Using an input which doesn't satisfy the length requirement
        %   results in an error. When this flag is set to true, input
        %   size is not restricted and can be arbitrary. The output in this
        %   case has a variable size. 
        %   The default value is 'false'.
        AllowArbitraryInputLength (1, 1) logical = false;
   end
    
   properties (Constant, Hidden)
        ForgettingFactorSet = matlab.system.SourceSet( ...
        dsp.simulink.internal.MovingStatisticsPolicy('SystemBlock', 'ForgettingFactorPort', 1, 'lambda'), ...
          {'Property','MATLAB','ForgettingFactorPort'})
   end
    
    methods
        function obj = MovingVariance(varargin)
            obj@dsp.MovingVariance(varargin{:});
        end
    end
    
    methods (Access = protected)
        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end
        function setupImpl(obj,u)
            setupImpl@dsp.MovingVariance(obj,u);
        end

        function validateInputsImpl(obj,varargin)
            validateInputsImpl@dsp.MovingVariance(obj,varargin{1});
            if strcmp(obj.Method,'Sliding window') && obj.SpecifyWindowLength

                if obj.getExecPlatformIndex()
                    sz = propagatedInputSize(obj, 1);
                    frameSize = sz(1);
                else
                    frameSize = size(varargin{1},1);
                end
        
                WL = obj.WindowLength;
                OL = obj.OverlapLength;

                fixedInput = propagatedInputFixedSize(obj,1);   
                arblabel = 'Allow Arbitrary Fixed size signals';
                mitigationstr = sprintf('Select the ''%s'' check box',arblabel); 
                coder.internal.errorIf(~isempty(fixedInput) && fixedInput && ~obj.AllowArbitraryInputLength && mod(frameSize, WL-OL) ~= 0, ...
                    'dsp:system:MovingStatistic:inputSizeArbitrary',frameSize, WL-OL, mitigationstr);             
            end
        end
        
        function name = getInputNamesImpl(obj)
            if  ~strcmp(obj.Method,'Sliding window') && obj.ForgettingFactorPort
                name = 'x';
            else
                name = '';
            end
        end
        
        function validateForgettingFactor(~,val)
            validateattributes(val,...
                {'double','single'},...
                {'real','scalar','finite','>=',0,'<=',1},...
                '','ForgettingFactor');
        end

        function outputSize = getOutputSizeImpl(obj)
            inputSize =  propagatedInputSize(obj, 1);
            
            if isempty(inputSize) || ~(strcmp(obj.Method,'Sliding window') && obj.SpecifyWindowLength)
                outputSize = inputSize;
            else
                % Only for sliding window method 
                WL = obj.WindowLength;
                OL = obj.OverlapLength;
                % For varsize, return the maximal output size rather than
                % the actual size.
                outputSize = [ceil(inputSize(1)/(WL-OL)) inputSize(2)];               
            end
        end
        function flag = isOutputFixedSizeImpl(obj)              
            fixedInput = propagatedInputFixedSize(obj,1);            
            if strcmp(obj.Method,'Sliding window') && obj.SpecifyWindowLength
                % Varsize output if input is varsize or arbitrary input is allowed
                flag = isFixedSizeOutput(obj);
            else
                flag = fixedInput;
            end
        end
        function isFixedOutput = isFixedSizeOutput(obj)
            % Varsize output if input is varsize or arbitrary input is allowed
            isFixedOutput = propagatedInputFixedSize(obj,1) && ~obj.AllowArbitraryInputLength;
	    end
        function flag = isInactivePropertyImpl(obj, prop)            
            switch prop
                case {'AllowArbitraryInputLength'}
                    flag = strcmp(obj.Method,'Exponential weighting') || ~obj.SpecifyWindowLength;
                otherwise
                    flag = isInactivePropertyImpl@dsp.MovingVariance(obj,prop);
            end
        end 
        function val = supportsMultipleInstanceImpl(obj)
            if strcmp(obj.Method,'Sliding window') && obj.SpecifyWindowLength
                % Foreach is allowed only for fixed size outputs (which requires
                % a fixed size input, and no arbitrary).
                val = propagatedInputFixedSize(obj,1) && ~obj.AllowArbitraryInputLength;
            else
                val = true;
            end
        end
        function s = saveObjectImpl(obj)
	        s = saveObjectImpl@dsp.MovingVariance(obj);
	        s.AllowArbitraryInputLength= obj.AllowArbitraryInputLength;
	    end
	
	    function s = loadObjectImpl(obj, s, wasLocked)
	        loadObjectImpl@dsp.MovingVariance(obj,s,wasLocked);
	        if isfield(s,'AllowArbitraryInputLength')
	            obj.AllowArbitraryInputLength = s.AllowArbitraryInputLength;
	        end
	    end
    end
 
    %% Block header - widget grouping
    methods(Static, Access=protected)
        function mainS = getPropertyGroupsImpl
            % Modify order of display
            props = {...
                matlab.system.display.internal.Property('Method','Description','dsp:StatisticsBlockDialog:Method_MP'),...
                matlab.system.display.internal.Property('ForgettingFactorPort','Description','dsp:StatisticsBlockDialog:ForgettingFactorPort_MP'),...
                matlab.system.display.internal.Property('SpecifyWindowLength','Description','dsp:StatisticsBlockDialog:SpecifyWindowLength_MP'),...
                matlab.system.display.internal.Property('WindowLength','Description','dsp:StatisticsBlockDialog:WindowLength_MP'),...
                matlab.system.display.internal.Property('OverlapLength','Description','dsp:StatisticsBlockDialog:OverlapLength_MP'),...
                matlab.system.display.internal.Property('AllowArbitraryInputLength','Description','dsp:blkprm_prompts:AllowArbitraryFixedInput_MP'),...
                matlab.system.display.internal.Property('ForgettingFactor','Description','dsp:StatisticsBlockDialog:ForgettingFactor_MP')};
                
            mainS =  matlab.system.display.Section(...
                'Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', props,'DependOnPrivatePropertyList',{'OverlapLength'});
        end

    end

end