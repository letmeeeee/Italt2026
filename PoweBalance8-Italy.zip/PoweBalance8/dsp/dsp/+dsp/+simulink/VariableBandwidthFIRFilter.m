classdef VariableBandwidthFIRFilter < dsp.VariableBandwidthFIRFilter & ...
        dsp.simulink.mixin.FilterResponseVisualizable
    % This class is used for Variable Bandwidth FIR Filter block in
    % dspfdesign
    
    %   Copyright 2017-2022 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCLS>
    properties(Nontunable)
        %BandwidthPort Specify bandwidth from input port
        BandwidthPort (1, 1) logical = false;
        %CenterFrequencyPort Specify center frequency from input port
        CenterFrequencyPort (1, 1) logical = false;
        %CutoffFrequencyPort Specify cutoff frequency from input port
        CutoffFrequencyPort (1, 1) logical = false;
    end
    
    properties (Constant, Hidden)
        CenterFrequencySet = matlab.system.SourceSet( ...
            dsp.simulink.internal.VariableBandwidthFilterPolicy('SystemBlock', 'CenterFrequencyPort', 1, 'Fc'), ...
            {'Property','MATLAB','CenterFrequencyPort'})
        BandwidthSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.VariableBandwidthFilterPolicy('SystemBlock', 'BandwidthPort', 2, 'BW'), ...
            {'Property','MATLAB','BandwidthPort'})
        CutoffFrequencySet = matlab.system.SourceSet( ...
            dsp.simulink.internal.VariableBandwidthFilterPolicy('SystemBlock', 'CutoffFrequencyPort', 3, 'Fcut'), ...
            {'Property','MATLAB','CutoffFrequencyPort'})
    end
    
%--------------------------------------------------------------------------
% Public methods
%--------------------------------------------------------------------------
    methods
        function obj = VariableBandwidthFIRFilter(varargin)
            % Constructor
            obj@dsp.VariableBandwidthFIRFilter(varargin{:})
        end
    end
%--------------------------------------------------------------------------
% Protected methods
%--------------------------------------------------------------------------
    methods (Access = protected)
        
        function validateInputsImpl(obj,varargin)
            validateInputsImpl@dsp.internal.VariableBandwidthFilterBase(obj,varargin{:});
        end
        %------------------------------------------------------------------
        function icon = getIconImpl(~)
            % MATLAB system block icon
            icon = getString(message(...
                'dsp:system:VariableBandwidthFilter:BlockIconFIR'));
        end
        %------------------------------------------------------------------
        function varargout = getInputNamesImpl(obj)
            if isLPHPSpecicifcationFromInputPort(obj) || isBPBSSpecicifcationFromInputPort(obj)
                varargout{1} = 'x';
            else
                varargout{1} = '';
            end
        end
        %------------------------------------------------------------------
        function processTunedPropertiesImpl(obj)
            % Validate the filter specs and values if they are specified
            % from the input port
            if isLPHPSpecicifcationFromInputPort(obj) || isBPBSSpecicifcationFromInputPort(obj)
                validateFilterSpec(obj);
            end
            % Tune the filter coefficients
            processTunedPropertiesImpl@dsp.VariableBandwidthFIRFilter(obj);
        end
        
        %------------------------------------------------------------------
        function crossValidateProperties(obj)
            % Validate the filter specs and values if they are specified on
            % the dialog
            if isLPHPSpecicifcationFromDialog(obj) || isBPBSSpecicifcationFromDialog(obj)
                validateFilterSpec(obj);
            end
        end
        %------------------------------------------------------------------
        function validateFilterSpec(obj)
            Fs = getSampleRate(obj);
            % Cross-validation of filter specifications
            if strcmp(obj.FilterType,'Bandpass') || ...
                    strcmp(obj.FilterType,'Bandstop')

                freqUnits = getFrequencyUnits(obj);
                coder.internal.errorIf(obj.CenterFrequency >= Fs/2, 'dsp:system:VariableBandwidthFilter:CharacteristicTooLarge','CenterFrequency', floor(Fs), round((Fs - floor(Fs)) * 10),freqUnits);
                coder.internal.errorIf(obj.Bandwidth >= Fs/2, 'dsp:system:VariableBandwidthFilter:CharacteristicTooLarge','Bandwidth' , floor(Fs), round((Fs - floor(Fs)) * 10),freqUnits);
                coder.internal.errorIf(obj.CenterFrequency + obj.Bandwidth/2 >= Fs/2, 'dsp:system:VariableBandwidthFilter:CharacteristicTooLarge','CenterFrequency + Bandwidth/2' , floor(Fs), round((Fs - floor(Fs)) * 10),freqUnits);
                coder.internal.errorIf(obj.CenterFrequency>0 && obj.Bandwidth > 0 && (obj.CenterFrequency - obj.Bandwidth/2 <= 0), 'dsp:system:VariableBandwidthFilter:CFMinusBandwidthNegative');
            else % highpass/lowpass validation
                validateFrequencyRange(obj);
            end
        end
        function flag = isInactivePropertyImpl(obj, prop)
            flag = false;
            switch prop
                case {'NormalizedFrequency'}
                    flag = true;
                case {'CutoffFrequency'}
                    if ~strcmp(obj.FilterType,'Lowpass') && ...
                        ~strcmp(obj.FilterType,'Highpass')
                        flag = true;
                    end
                case {'SidelobeAttenuation'}
                    if ~strcmp(obj.Window,'Chebyshev')
                        flag = true;
                    end
                case {'KaiserWindowParameter'}
                    if ~strcmp(obj.Window,'Kaiser')
                        flag = true;
                    end    
                otherwise
                    flag = isInactivePropertyImpl@dsp.internal.VariableBandwidthFilterBase(obj,prop);
            end
        end
        function validatePropertiesImpl(obj)
            if ~isSampleRateInherited(obj)
                crossValidateProperties(obj);
            end            
        end
        %------------------------------------------------------------------
        function flag = isLPHPSpecicifcationFromInputPort(obj)
            flag = obj.CutoffFrequencyPort && any(strcmp(obj.FilterType,{'Lowpass','Highpass'}));

        end
        %------------------------------------------------------------------
        function flag = isBPBSSpecicifcationFromInputPort(obj)
            flag = (obj.CenterFrequencyPort || obj.BandwidthPort) && any(strcmp(obj.FilterType,{'Bandpass','BandStop'}));
        end
        %------------------------------------------------------------------
        function flag = isLPHPSpecicifcationFromDialog(obj)
            flag = ~obj.CutoffFrequencyPort && any(strcmp(obj.FilterType,{'Lowpass','Highpass'}));
        end
        %------------------------------------------------------------------
        function flag = isBPBSSpecicifcationFromDialog(obj)
            flag = (~obj.CenterFrequencyPort || ~obj.BandwidthPort) && any(strcmp(obj.FilterType,{'Bandpass','BandStop'}));
        end
    end
%--------------------------------------------------------------------------
% Hidden methods
%--------------------------------------------------------------------------
    methods (Hidden)        
        function [flag,errID] = isFVtoolSupported(obj)
            % Method used in visualize button on block
            flag  = true;
            errID = '';
            if isLPHPSpecicifcationFromInputPort(obj)
                flag = false;
                errID = 'dsp:system:VariableBandwidthFilter:fvtoolButtonFIRLPHPDisabled';
            elseif isBPBSSpecicifcationFromInputPort(obj)
                flag = false;
                errID = 'dsp:system:VariableBandwidthFilter:fvtoolButtonBPBSDisabled';
            elseif isprop(obj, 'SampleRateMode')
               if isSampleRateInherited(obj)
                  flag = false;
                  errID = 'dsp:system:Shared:fvtoolButtonInheritSRTexDropdown';
               end
            end
        end        
    end
%--------------------------------------------------------------------------
% Static, hidden methods
%--------------------------------------------------------------------------
    methods (Static, Hidden)
        %------------------------------------------------------------------
        function props = getDisplayPropertiesImpl()
            props = {'FilterOrder','FilterType','CutoffFrequencyPort','CutoffFrequency',...
                'CenterFrequencyPort','CenterFrequency','BandwidthPort','Bandwidth', ...
                'Window','KaiserWindowParameter','SidelobeAttenuation','SampleRateMode','SampleRate'};
        end
        %------------------------------------------------------------------
        function checkVal(value,prop)
            validateattributes(value,{'double','single'},...
                {'real','scalar','>=',0,'finite'},...
                '',prop);
        end
    end
%--------------------------------------------------------------------------
% Static, Protected methods
%--------------------------------------------------------------------------
    methods(Static, Access=protected)
        %------------------------------------------------------------------
        function mainS = getPropertyGroupsImpl
            % Modify order of display
            props = {...
                matlab.system.display.internal.Property('FilterOrder','Description','dsp:system:VariableBandwidthFilter:FilterOrder_MP'), ...
                matlab.system.display.internal.Property('FilterType','Description','dsp:system:VariableBandwidthFilter:FilterType_MP'), ...
                matlab.system.display.internal.Property('CutoffFrequencyPort','Description','dsp:system:VariableBandwidthFilter:CutoffFrequencyPort_MP'), ...
                matlab.system.display.internal.Property('CutoffFrequency','Description','dsp:system:VariableBandwidthFilter:CutoffFrequency_MP'), ...
                matlab.system.display.internal.Property('CenterFrequencyPort','Description','dsp:system:VariableBandwidthFilter:CenterFrequencyPort_MP'), ...
                matlab.system.display.internal.Property('CenterFrequency','Description','dsp:system:VariableBandwidthFilter:CenterFrequency_MP'), ...
                matlab.system.display.internal.Property('BandwidthPort','Description','dsp:system:VariableBandwidthFilter:BandwidthPort_MP'), ...
                matlab.system.display.internal.Property('Bandwidth','Description','dsp:system:VariableBandwidthFilter:Bandwidth_MP'), ...
                matlab.system.display.internal.Property('Window','Description','dsp:system:VariableBandwidthFilter:Window_MP'), ...
                matlab.system.display.internal.Property('KaiserWindowParameter','Description','dsp:system:VariableBandwidthFilter:KaiserWindowParameter_MP'), ...
                matlab.system.display.internal.Property('SidelobeAttenuation','Description','dsp:system:VariableBandwidthFilter:SidelobeAttenuation_MP'), ...
                matlab.system.display.internal.Property('SampleRateMode','Description','dsp:system:VariableBandwidthFilter:SampleRateMode_MP'), ...
                matlab.system.display.internal.Property('SampleRate','Description','dsp:system:VariableBandwidthFilter:SampleRate_MP')};
            mainS =  matlab.system.display.Section(...
                Title='dsp:system:Shared:Parameters', ...
                PropertyList=props);
            
            filterVis = dsp.simulink.internal.FilterResponseVisualizationButton;
            mainS.Actions = filterVis.visualizeAction;
        end        
        %------------------------------------------------------------------
        function header = getHeaderImpl
            % MATLAB System block header
            title = 'dsp:system:VariableBandwidthFilter:VariableFIRTop';
            text = 'dsp:system:VariableBandwidthFilter:VariableFIRHeader';
            header = matlab.system.display.Header('dsp.simulink.VariableBandwidthFIRFilter', ...
                ShowSourceLink=true, Title=title, Text=text);
        end
    end
end
