classdef FilterInfoButton
    %FilterInfoButton Button to view filter info button on the dialog of
    %System block.
    %  Example usage in getPropertyGroupsImpl method of a System object:
    %      mainS = matlab.system.display.Section('Title', 'Parameters', ...
    %                 'PropertyList', props);
    %      filterInfo =
    %      dsp.simulink.internal.FilterInfoButton;
    %      mainS.Actions = filterInfo.infoAction;
    %  This will add a 'View Info' button on the dialog when the
    %  System object is used in a MATLAB System block. Clicking the button
    %  will open a dialog showing filter specific information
    
    % Copyright 2021-2022 The MathWorks, Inc.
    
    properties (Transient)
        % Holds information about the button
        infoAction
    end
%--------------------------------------------------------------------------
% Public methods
%--------------------------------------------------------------------------
    methods
        %------------------------------------------------------------------
        function obj = FilterInfoButton
            % Create the button
            obj.infoAction = matlab.system.display.Action(...
                @dsp.simulink.internal.FilterInfoButton.onViewInfo, ...
                'Label',getString(message('dsp:system:Shared:Info')),...
                'Placement','last','Alignment','right');
            % Associate callbacks for dialog apply and block delete
            matlab.system.display.internal.setCallbacks(obj.infoAction, ...
                'DialogAppliedFcn', @dsp.simulink.internal.FilterInfoButton.onDialogApplied, ...
                'SystemDeletedFcn', @dsp.simulink.internal.FilterInfoButton.onSystemDeleted, ...
                'PropertyResolveErrorFcn', @dsp.simulink.internal.FilterInfoButton.onUnresolvedProperty, ...
                'IsEnabledFcn', @dsp.simulink.internal.FilterInfoButton.isFilterInfoEnabled);
        end
    end
%--------------------------------------------------------------------------
% Static protected methods
%--------------------------------------------------------------------------
    methods (Static, Access=protected)
        %------------------------------------------------------------------
        function onViewInfo(actionData, sysObj)
            f = [];
            if isfield(actionData.UserData,'InfoHandle')
                f = actionData.UserData.InfoHandle;
            end
            if isempty(f) || ~ishandle(f)
                % Cache object characteristics
                ud = actionData.UserData;
                ud = dsp.simulink.internal.FilterInfoButton.cacheProperties(ud,sysObj);
                % Get Info text from the block object
                infoText = getFilterInfo(sysObj);
                % Get the block name
                blockName = get_param(actionData.SystemHandle,'Name');
                % Create the message dialog
                ud.InfoHandle = dsp.util.msgbox(infoText,blockName);
                % Cache the user data
                actionData.UserData = ud;
            else
                % apply changes and bring focus to figure
                dsp.simulink.internal.FilterInfoButton.onDialogApplied(actionData, sysObj);
                figure(f);
            end
        end
        %------------------------------------------------------------------
        function onDialogApplied(actionData, sysObj)
            % Refresh info if needed
            f = [];
            if isfield(actionData.UserData,'InfoHandle')
                f = actionData.UserData.InfoHandle;
            end
            if ~isempty(f) && ishandle(f)
                if ~dsp.simulink.internal.FilterInfoButton.propertiesChanged(actionData.UserData,sysObj)
                    return;
                end
                actionData.UserData = dsp.simulink.internal.FilterInfoButton.cacheProperties(actionData.UserData,sysObj);
                % Get Info text from the block object
                infoText = getFilterInfo(sysObj);
                % Re-adjust box size to handle new string
                dsp.simulink.internal.FilterInfoButton.adjustInfoBoxText(f, infoText);
            end
        end
        %------------------------------------------------------------------
        function adjustInfoBoxText(f, infoText)
            pos0 = get(f,'Position');
            stringObject = findall(f,'Type','Text');
            extent0 = get(stringObject,'Extent');
            set(stringObject,'String',infoText);
            extent1 = get(stringObject,'Extent');
            set(f,'Position',[pos0(1:2) pos0(3:4) + (extent1(3:4) - extent0(3:4))]);
        end
        %------------------------------------------------------------------
        function onUnresolvedProperty(actionData, e, ~)
            f = [];
            if isfield(actionData.UserData,'InfoHandle')
                f = actionData.UserData.InfoHandle;
            end
            if ~isempty(f) && isvalid(f)
                % update existing plot to show nothing
                infoText = getString(message('dsp:system:Shared:infoButtonUnresolvedParameter', e.message));
                dsp.simulink.internal.FilterInfoButton.adjustInfoBoxText(f, infoText);
            end
            % Abort callback
            throw(e);
        end
        %------------------------------------------------------------------
        function onSystemDeleted(actionData)
            f = [];
            % Close Info
            if isfield(actionData.UserData,'InfoHandle')
                f = actionData.UserData.InfoHandle;
            end
            if ~isempty(f) && ishandle(f)
                close(f);
            end
        end
        %------------------------------------------------------------------
        function flag = isFilterInfoEnabled(blkh)
            try
                sysObj = dsp.simulink.internal.FilterInfoButton.getSystemObjectDescriptor(blkh);
                flag = isFVtoolSupported(sysObj);
            catch 
                flag = false;
            end
        end
        %------------------------------------------------------------------
        function flag =  propertiesChanged(ud,sysObj)
            if isfield(ud,'Filter')
                flag = false;
                props = properties(sysObj);
                pObj = ud.Filter;
                for index = 1:length(props)
                    if (pObj.(props{index}) ~= sysObj.(props{index}))
                        flag = true;
                        return;
                    end
                end
            else
                flag = true;
            end
        end
        %------------------------------------------------------------------
        function  ud = cacheProperties(ud,sysObj)
            if ~isfield(ud,'Filter')
                ud.Filter = eval(class(sysObj));
            end
            props = properties(sysObj);
            for index = 1:length(props)
                % Do not update the cached object properties if they did
                % not change
                if ~isequal(ud.Filter.(props{index}),sysObj.(props{index}))
                    ud.Filter.(props{index}) = sysObj.(props{index});
                end
            end
        end
    end

%--------------------------------------------------------------------------
% Static hidden methods
%--------------------------------------------------------------------------
    methods (Static, Hidden)
        %------------------------------------------------------------------
        function sysObj = getSystemObjectDescriptor(blkh)
            actionMap = getKeyValue(matlab.system.ui.PlatformDescriptor.SystemMap, blkh);
            keys = actionMap.keys;
            actionCache = actionMap(keys{1});
            sysObj = matlab.system.ui.SimulinkDescriptor.getBlockActionSystemObjectInstance(...
                blkh, get(blkh,'System'), actionCache.Action, actionCache.ActionData);
        end
    end
end