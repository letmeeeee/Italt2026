classdef TunableBandpassBandstopIIRPolicy < matlab.system.CustomPropertyOrInput
% TunableBandpassBandstopIIRPolicy This class defines how the tunable design
% parameters for TunableBandpassIIRFilter and TunableBandstopIIRFilter are
% provided
    
%   Copyright 2022 The MathWorks, Inc.

%#codegen
    
    methods
        %------------------------------------------------------------------
        function this = TunableBandpassBandstopIIRPolicy(aClient, aCPN, aOrdinal,aInputLabel)
            this@matlab.system.CustomPropertyOrInput(aClient, aCPN, aOrdinal,aInputLabel);
        end
    end
    
    methods (Static)
        %------------------------------------------------------------------
        function flag = isPropertyActive(this,prop, flag)
            switch prop
                case  'FilterOrder'
                    flag = ~this.FilterOrderPort;
                case 'F3dB1'
                    flag = ~this.F3dB1Port;
                case 'F3dB2'
                    flag = ~this.F3dB2Port;
                case 'Apass'
                    flag = ~this.ApassPort && strcmp(this.DesignMethod, 'Chebyshev Type I');
                case 'ApassPort'
                    flag = strcmp(this.DesignMethod, 'Chebyshev Type I');
                case 'Astop'
                    flag = ~this.AstopPort && strcmp(this.DesignMethod, 'Chebyshev Type II');
                case 'AstopPort'
                    flag = strcmp(this.DesignMethod, 'Chebyshev Type II');
            end
        end
        %------------------------------------------------------------------
        function flag = isInputActive(this,prop,flag)
            switch prop
                case  'FilterOrder'
                    flag = this.FilterOrderPort;
                case 'F3dB1'
                    flag = this.F3dB1Port;
                case 'F3dB2'
                    flag = this.F3dB2Port; 
                case 'Apass'
                    flag = this.ApassPort && strcmp(this.DesignMethod, 'Chebyshev Type I');
                case 'Astop'
                    flag = this.AstopPort && strcmp(this.DesignMethod, 'Chebyshev Type II');
            end                                   
        end
    end
end