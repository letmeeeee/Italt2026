classdef VariableRateConversionPolicy < matlab.system.CustomPropertyOrInput
    % VariableRateConversionPolicy This class defines how tunable coefficients are
    % specified for the Variable FIR Interpolation and Variable FIR Decimation blocks

    %   Copyright 2022-2023 The MathWorks, Inc.

    %#codegen

    methods
        function obj = VariableRateConversionPolicy(aClient, aCPN, aOrdinal,aInputLabel)
            obj@matlab.system.CustomPropertyOrInput(aClient, aCPN, aOrdinal,aInputLabel);
        end
    end

    methods (Static)

        function flag = isPropertyActive(obj,prop,flag)

            switch prop
                case 'Coefficients'
                    fromPort  = obj.CoefficientsPort;
                    flag = ~fromPort && strcmp(obj.CoefficientSource,'Dialog parameter');
                case 'CoefficientsPort'
                    flag = strcmp(obj.CoefficientSource,'Input port');
                case 'InterpolationFactor'
                    flag = ~obj.InterpolationFactorPort && strcmpi(obj.Specification, 'Interpolation factor');
                case 'InterpolationFactorPort'
                    flag = strcmpi(obj.Specification, 'Interpolation factor');
                case 'DecimationFactor'
                    flag = ~obj.DecimationFactorPort && strcmpi(obj.Specification, 'Decimation factor');
                case 'DecimationFactorPort'
                    flag = strcmpi(obj.Specification, 'Decimation factor');
                otherwise
            end
        end
        function flag = isInputActive(obj,prop,flag)
            switch prop
                case 'Coefficients'
                    flag = strcmp(obj.CoefficientSource,'Input port');
                case 'InterpolationFactor'
                    flag = obj.InterpolationFactorPort && strcmpi(obj.Specification, 'Interpolation factor');
                case 'DecimationFactor'
                    flag = obj.DecimationFactorPort && strcmpi(obj.Specification, 'Decimation factor');
            end
        end
    end

end
