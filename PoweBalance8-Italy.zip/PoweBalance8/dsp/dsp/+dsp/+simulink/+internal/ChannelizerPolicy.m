classdef ChannelizerPolicy < matlab.system.CustomPropertyOrInput
    % ChannelizerPolicy This class defines how tunable coefficients are
    % specified for the Channelizer and Channel Synthesizer blocks
    
    %   Copyright 2017-2019 The MathWorks, Inc.
    
    %#codegen
    
    methods
        function obj = ChannelizerPolicy(aClient, aCPN, aOrdinal,aInputLabel)
            obj@matlab.system.CustomPropertyOrInput(aClient, aCPN, aOrdinal,aInputLabel);
        end
    end
    
    methods (Static)
        
        function flag = isPropertyActive(obj,prop, flag)
            
            switch prop
                case  'LowpassCoefficients'
                    fromPort  = obj.CoefficientsPort;
                    flag = ~fromPort && strcmp(obj.Specification,'Coefficients');
                case 'CoefficientsPort'
                    flag = strcmp(obj.Specification,'Coefficients');
            end
            
        end
        function flag = isInputActive(obj,prop,flag)
            
            if strcmp(prop,  'LowpassCoefficients')
                fromPort  = obj.CoefficientsPort;
                flag = fromPort && strcmp(obj.Specification,'Coefficients');
            end
            
        end
    end
    
end