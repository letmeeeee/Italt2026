classdef AllpassFilterPolicy < matlab.system.CustomPropertyOrInput
% AllpassFilterPolicy This class defines how the tunable parameters
% AllpassCoefficients and LatticeCoefficients are specified on the Allpass
% Filter block
    
 %   Copyright 2017 The MathWorks, Inc.

    %#codegen
    
    methods
        function obj = AllpassFilterPolicy(aClient, aCPN, aOrdinal,aInputLabel)
            obj@matlab.system.CustomPropertyOrInput(aClient, aCPN, aOrdinal,aInputLabel);
        end
    end
    
    methods (Static)

        function flag = isPropertyActive(obj,prop, flag)

            switch prop
                case  'AllpassCoefficientsPort'
                    flag = strcmp(obj.Structure,'Minimum multiplier');
                case  'AllpassCoefficients'
                    fromPort  = obj.AllpassCoefficientsPort;
                    flag = ~fromPort && strcmp(obj.Structure,'Minimum multiplier');                    
                case  'LatticeCoefficientsPort'
                    flag = strcmp(obj.Structure,'Lattice');
                case  'LatticeCoefficients'
                    fromPort  = obj.LatticeCoefficientsPort;
                    flag = ~fromPort && strcmp(obj.Structure,'Lattice');
                otherwise
            end
            
        end
        function flag = isInputActive(obj,prop,flag)
            switch prop
                case 'AllpassCoefficients'
                    fromPort  = obj.AllpassCoefficientsPort;
                    flag = fromPort && strcmp(obj.Structure,'Minimum multiplier');
                case 'LatticeCoefficients'
                    fromPort  = obj.LatticeCoefficientsPort;
                    flag = fromPort && strcmp(obj.Structure,'Lattice');
                otherwise
            end            
        end
    end
    
end