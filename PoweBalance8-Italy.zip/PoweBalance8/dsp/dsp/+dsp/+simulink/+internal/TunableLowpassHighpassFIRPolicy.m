classdef TunableLowpassHighpassFIRPolicy < matlab.system.CustomPropertyOrInput
% TunableLowpassHighpassFIRPolicy This class defines how the tunable design
% parameters for TunableLowpassFIRFilter and TunableHighpassFIRFilter are
% provided
    
%   Copyright 2022-2023 The MathWorks, Inc.

%#codegen
    
    methods
        %------------------------------------------------------------------
        function this = TunableLowpassHighpassFIRPolicy(aClient, aCPN, aOrdinal,aInputLabel)
            this@matlab.system.CustomPropertyOrInput(aClient, aCPN, aOrdinal,aInputLabel);
        end
    end
    
    methods (Static)
        %------------------------------------------------------------------
        function flag = isPropertyActive(this,prop,flag)
            switch prop
                case  'FilterOrder'
                    flag = ~this.FilterOrderPort;
                case 'CutoffFrequency'
                    flag = ~this.CutoffFrequencyPort;
                case 'SidelobeAttenuation'
                    flag = ~this.SidelobeAttenuationPort && isChebwin(this);
                case 'SidelobeAttenuationPort'
                    flag = isChebwin(this);
                case 'KaiserWindowParameter'
                    flag = ~this.KaiserWindowParameterPort && isKaiser(this);
                case 'KaiserWindowParameterPort'
                    flag = isKaiser(this);
            end
        end
        %------------------------------------------------------------------
        function flag = isInputActive(this,prop,flag)
            switch prop
                case  'FilterOrder'
                    flag = this.FilterOrderPort;
                case 'CutoffFrequency'
                    flag = this.CutoffFrequencyPort;
                case 'SidelobeAttenuation'
                    flag = this.SidelobeAttenuationPort && isChebwin(this);
                case 'KaiserWindowParameter'
                    flag = this.KaiserWindowParameterPort && isKaiser(this);
            end
        end
    end
end
