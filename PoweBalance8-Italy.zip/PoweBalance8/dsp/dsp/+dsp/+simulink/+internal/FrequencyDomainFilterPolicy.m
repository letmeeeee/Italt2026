classdef FrequencyDomainFilterPolicy < matlab.system.CustomPropertyOrInput
% FrequencyDomainFilterPolicy

 %   Copyright 2017 The MathWorks, Inc.

    %#codegen
    
    methods
        function obj = FrequencyDomainFilterPolicy(aClient, aCPN, aOrdinal,aInputLabel)
            obj@matlab.system.CustomPropertyOrInput(aClient, aCPN, aOrdinal,aInputLabel);
        end
    end
    
    methods (Static)

        function flag = isPropertyActive(obj,prop, flag)
            switch prop
                case  'SpecifyNumeratorFromPort'
                    flag = strcmp(obj.NumeratorDomain,'Time');
                case  'SpecifyFrequencyResponseFromPort'
                    flag = ~strcmp(obj.NumeratorDomain,'Time');
                case 'Numerator'
                    flag = strcmp(obj.NumeratorDomain,'Time') && ~obj.SpecifyNumeratorFromPort;
               case 'FrequencyResponse'
                   flag = ~strcmp(obj.NumeratorDomain,'Time') && ~obj.SpecifyFrequencyResponseFromPort;
            end
        end
        
        function flag = isInputActive(obj,prop,flag)
            
            switch prop
                case 'Numerator'
                    flag = strcmp(obj.NumeratorDomain,'Time') && obj.SpecifyNumeratorFromPort;
                case 'FrequencyResponse'
                    flag = ~strcmp(obj.NumeratorDomain,'Time') && obj.SpecifyFrequencyResponseFromPort;
            end
                    
        end
    end
    
end