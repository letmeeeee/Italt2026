classdef IIRHalfbandPolicy < matlab.system.CustomPropertyOrInput
% IIRHalfbandPolicy This class defines how the tunable parameters
% AllpassCoefficients1 and AllpassCoefficients2 are specified on the
% IIRHalfbandDecimator and IIRHalfbandInterpolator blocks
    
 %   Copyright 2017-2022 The MathWorks, Inc.

    %#codegen
    
    methods
        function obj = IIRHalfbandPolicy(aClient, aCPN, aOrdinal,aInputLabel)
            obj@matlab.system.CustomPropertyOrInput(aClient, aCPN, aOrdinal,aInputLabel);
        end
    end
    
    methods (Static)

        function flag = isPropertyActive(obj,prop, flag)

            switch prop
                case  'CoefficientsPort'
                    flag = strcmp(obj.Specification,'Coefficients') && ... 
                           strcmp(obj.Structure,'Minimum multiplier');
                case  {'AllpassCoefficients1','AllpassCoefficients2'}
                    fromPort  = obj.CoefficientsPort;
                    flag = ~fromPort && strcmp(obj.Specification,'Coefficients') && ...
                                        strcmp(obj.Structure,'Minimum multiplier');
                    
                    %First branch coefficients edit-box should be hidden if
                    %it is set to be a pure delay.
                    if strcmpi(prop,'AllpassCoefficients1')
                       flag = flag &&~obj.HasPureDelayBranch;   
                    end

                otherwise
            end
            
        end
        function flag = isInputActive(obj,prop,flag)
            switch prop
                case 'AllpassCoefficients1'
                    fromPort  = obj.CoefficientsPort;
                    flag = fromPort && strcmp(obj.Specification,'Coefficients') && ...
                                       strcmp(obj.Structure,'Minimum multiplier') && ~obj.HasPureDelayBranch;
                case 'AllpassCoefficients2'
                    fromPort  = obj.CoefficientsPort;
                    flag = fromPort && strcmp(obj.Specification,'Coefficients') && ...
                                       strcmp(obj.Structure,'Minimum multiplier');
                otherwise
            end            
        end
    end
    
end