classdef VariableBandwidthFilterPolicy < matlab.system.CustomPropertyOrInput
    % VariableBandwidthFilterPolicy This class defines how the tunable
    % parameters Bandwidth, BandwidthCoefficient, CenterFrequency,
    % CutoffFrequency and PassbandFrequency are specified on the
    % VariableBandwidthFIRFilter and VariableBandwidthIIRFilter blocks
    
    %   Copyright 2017 The MathWorks, Inc.
    
    %#codegen
    
    methods
        function obj = VariableBandwidthFilterPolicy(aClient, aCPN, aOrdinal,aInputLabel)
            obj@matlab.system.CustomPropertyOrInput(aClient, aCPN, aOrdinal,aInputLabel);
        end
    end
    
    methods (Static)
        
        function flag = isPropertyActive(obj,prop, flag)
            
            switch prop
                
                case  'CenterFrequencyPort'
                    flag = any(strcmp(obj.FilterType,{'Bandpass','Bandstop'}));
                case  'BandwidthPort'
                    flag = any(strcmp(obj.FilterType,{'Bandpass','Bandstop'}));
                case {'CutoffFrequencyPort','PassbandFrequencyPort'}
                    flag = any(strcmp(obj.FilterType,{'Lowpass','Highpass'}));
   
                case  'CenterFrequency'
                    fromPort  = obj.CenterFrequencyPort;
                    flag = ~fromPort && any(strcmp(obj.FilterType,{'Bandpass','Bandstop'}));
                case  'Bandwidth'
                    fromPort  = obj.BandwidthPort;
                    flag = ~fromPort && any(strcmp(obj.FilterType,{'Bandpass','Bandstop'}));
                case  'CutoffFrequency'
                    fromPort  = obj.CutoffFrequencyPort;
                    flag = ~fromPort && any(strcmp(obj.FilterType,{'Lowpass','Highpass'}));
                case  'PassbandFrequency'
                    fromPort  = obj.PassbandFrequencyPort;
                    flag = ~fromPort && any(strcmp(obj.FilterType,{'Lowpass','Highpass'}));
                otherwise
            end
            
        end
        function flag = isInputActive(obj,prop,flag)
            switch prop
                
                case  'CenterFrequency'
                    fromPort  = obj.CenterFrequencyPort;
                    flag = fromPort && any(strcmp(obj.FilterType,{'Bandpass','Bandstop'}));
                case  'Bandwidth'
                    fromPort  = obj.BandwidthPort;
                    flag = fromPort && any(strcmp(obj.FilterType,{'Bandpass','Bandstop'}));
                case  'CutoffFrequency'
                    fromPort  = obj.CutoffFrequencyPort;
                    flag = fromPort && any(strcmp(obj.FilterType,{'Lowpass','Highpass'}));
                case  'PassbandFrequency'
                    fromPort  = obj.PassbandFrequencyPort;
                    flag = fromPort && any(strcmp(obj.FilterType,{'Lowpass','Highpass'}));
                    
                otherwise
            end
        end
    end
end