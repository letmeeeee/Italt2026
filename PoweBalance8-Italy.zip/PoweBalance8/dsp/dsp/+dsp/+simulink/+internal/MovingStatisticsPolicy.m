classdef MovingStatisticsPolicy < matlab.system.CustomPropertyOrInput
% MovingStatisticsPolicy This class defines how the tunable parameter
% ForgettingFactor is specified on the moving stats blocks
    
 %   Copyright 2017 The MathWorks, Inc.

    %#codegen
    
    methods
        function obj = MovingStatisticsPolicy(aClient, aCPN, aOrdinal,aInputLabel)
            obj@matlab.system.CustomPropertyOrInput(aClient, aCPN, aOrdinal,aInputLabel);
        end
    end
    
    methods (Static)

        function flag = isPropertyActive(obj,prop, flag)

            switch prop
                case  'ForgettingFactorPort'
                    flag = ~strcmp(obj.Method,'Sliding window');
                case  'ForgettingFactor'
                    fromPort  = obj.ForgettingFactorPort;
                    flag = ~fromPort && ~strcmp(obj.Method,'Sliding window');
            end
            
        end
        function flag = isInputActive(obj,prop,flag)
            
            if strcmp( prop , 'ForgettingFactor')
                fromPort  = obj.ForgettingFactorPort;
                flag = fromPort && ~strcmp(obj.Method,'Sliding window');
            end
            
        end
    end
    
end