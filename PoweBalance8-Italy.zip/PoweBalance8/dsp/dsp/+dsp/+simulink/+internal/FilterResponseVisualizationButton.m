classdef FilterResponseVisualizationButton
    %FilterResponseVisualizationButton Button to view filter response on
    %dialog of System block.
    %  Example usage in getPropertyGroupsImpl method of a System object:
    %      mainS = matlab.system.display.Section('Title', 'Parameters', ...
    %                 'PropertyList', props);
    %      filterVis =
    %      dsp.simulink.internal.FilterResponseVisualizationButton;
    %      mainS.Actions = filterVis.visualizeAction;
    %  This will add a 'View Filter Response' button on the dialog when the
    %  System object is used in a MATLAB System block. Clicking the button
    %  will call dsp.DynamicFilterVisualizer on the object.
    
    % Copyright 2020-2022 The MathWorks, Inc.
    
    properties (Transient)
        % Holds information about the button
        visualizeAction
    end
%--------------------------------------------------------------------------
% Public methods
%--------------------------------------------------------------------------
    methods
        %------------------------------------------------------------------
        function obj = FilterResponseVisualizationButton
            % Create the button
            obj.visualizeAction = matlab.system.display.Action(...
                @dsp.simulink.internal.FilterResponseVisualizationButton.onVisualizeReponse, ...
                'Label',getString(message('dsp:system:Shared:Visualize')),...
                'Placement','last','Alignment','right');
            % Associate callbacks for dialog apply and block delete
            matlab.system.display.internal.setCallbacks(obj.visualizeAction, ...
                'DialogAppliedFcn', @dsp.simulink.internal.FilterResponseVisualizationButton.onDialogApplied, ...
                'SystemDeletedFcn', @dsp.simulink.internal.FilterResponseVisualizationButton.onSystemDeleted, ...
                'PropertyResolveErrorFcn', @dsp.simulink.internal.FilterResponseVisualizationButton.onUnresolvedProperty, ...
                'IsEnabledFcn', @dsp.simulink.internal.FilterResponseVisualizationButton.isVisualizationEnabled);
        end
    end
%--------------------------------------------------------------------------
% Static protected methods
%--------------------------------------------------------------------------
    methods (Static, Access=protected)
        %------------------------------------------------------------------
        function onVisualizeReponse(actionData, sysObj)
            import dsp.simulink.internal.FilterResponseVisualizationButton.*
            % Get cached user data
            userData = actionData.UserData;
            % Get cached system object
            if ~isfield(actionData.UserData,'Filter')
                % Cache object characteristics
                userData = cacheProperties(userData,sysObj);
                userData.forceApply = false;
            end
            % Get cached visualizer
            f = [];
            if isfield(actionData.UserData,'VisualizerHandle')
                % Cache visualization object
                f = actionData.UserData.VisualizerHandle;
            end
            if isempty(f) || ~isvalid(f)
                % Set the block's name to its legend string.
                userData.VisualizerHandle = initVisualizer(actionData,sysObj);
                % Launch the visualizer
                show(userData.VisualizerHandle);
                % Plot the response
                plotResponse(userData);
                % Cache the new user data
                actionData.UserData = userData;
            elseif userData.forceApply
                % Launch the visualizer
                show(userData.VisualizerHandle);
                % Plot the response
                plotResponse(userData);
                % Switch force apply to false
                userData.forceApply = false;
                % Cache the new user data
                actionData.UserData = userData;
            else
                % Apply unapplied changes and bring figure to focus
                show(f);
                onDialogApplied(actionData, sysObj)
            end
        end
        %------------------------------------------------------------------
        function onDialogApplied(actionData, sysObj)
            % Close an existing error dialog
            import dsp.simulink.internal.FilterResponseVisualizationButton.*
            [supported, errID] = isFVtoolSupported(sysObj);
            if supported
                w = [];
                if isfield(actionData.UserData,'errordlgHandle')
                    w = actionData.UserData.errordlgHandle;
                end
                if ~isempty(w) && isvalid(w)
                    delete(w);
                end
            end
            % Refresh plot if needed
            vis = [];
            if isfield(actionData.UserData,'VisualizerHandle')
                vis = actionData.UserData.VisualizerHandle;
            end
            if ~isempty(vis) && isvalid(vis)
                userData = actionData.UserData;
                % if there isn't any annotation on figure and no property
                % has changed then no need to update the plot. Or if the
                % visualizer was closed return early
                annotation = vis.Annotation;
                if ~vis.isVisible || (isempty(annotation) && ~propertiesChanged(userData,sysObj))
                    return;
                end
                % Cache the new property values
                userData = cacheProperties(userData,sysObj);
                % Update plot with new filter. If sample rate is inherited,
                % the update existing plot to show nothing.
                if ~supported
                    str = getString(message(errID));
                    userData = blankAndAnnotate(userData, vis, actionData.SystemHandle, str);
                else
                    % Delete annotation about inherited sample rate
                    vis.Annotation = '';
                    sampleRate = 2;
                    if isprop(userData.Filter,'SampleRate')
                       sampleRate = userData.Filter.SampleRate;
                    end
                    if isprop(sysObj, 'SampleRateMode')
                        if strcmp(sysObj.SampleRateMode,'Use normalized frequency (0 to 1)')
                            sampleRate = 2;
                        end
                    end
                    vis.SampleRate = sampleRate;
                    vis.FrequencyRange = [0 sampleRate/2];
                    % Update visualizer with new filter
                    plotResponse(userData);
                    blkName = get_param(actionData.SystemHandle, 'Name');
                    blkName = strrep(blkName,newline,' ');
                    userData.VisualizerHandle.FilterNames = getVisualizationLegend(userData.Filter,blkName);
                    userData.VisualizerHandle.ShowLegend = true;
                    if isprop(sysObj, 'SampleRateMode')
                        if strcmp(sysObj.SampleRateMode,'Use normalized frequency (0 to 1)')
                            userData.VisualizerHandle.NormalizedFrequency = true;
                        elseif strcmp(sysObj.SampleRateMode,'Specify on dialog')
                            userData.VisualizerHandle.NormalizedFrequency = false;
                        end
                    end
                    
                end
                actionData.UserData = userData;
            end
        end
        %------------------------------------------------------------------
        function onSystemDeleted(actionData)
            % Close an existing warning dialog
            w = [];
            if isfield(actionData.UserData,'errordlgHandle')
                w = actionData.UserData.errordlgHandle;
            end
            if ~isempty(w) && isvalid(w)
                delete(w);
            end
            % Close visualization
            vis = [];
            if isfield(actionData.UserData,'VisualizerHandle')
                vis = actionData.UserData.VisualizerHandle;
            end
            
            if ~isempty(vis) && isvalid(vis) && isobject(vis)
                hide(vis);
            end
        end
        %------------------------------------------------------------------
        function onUnresolvedProperty(actionData, e, ~)
            import dsp.simulink.internal.FilterResponseVisualizationButton.*
            vis = [];
            if isfield(actionData.UserData,'VisualizerHandle')
                vis = actionData.UserData.VisualizerHandle;
            end
            if ~isempty(vis) && isvalid(vis)
                userData = actionData.UserData;
                % update existing plot to show nothing
                str = getString(message('dsp:system:Shared:fvtoolButtonUnresolvedParameter', e.message));
                userData = blankAndAnnotate(userData, vis, actionData.SystemHandle, str);
                actionData.UserData = userData;
            end
            % Abort callback
            throw(e);
        end
        %------------------------------------------------------------------
        function flag = isVisualizationEnabled(blkh)
            try
                sysObj = dsp.simulink.internal.FilterResponseVisualizationButton.getSystemObjectDescriptor(blkh);
                flag = isFVtoolSupported(sysObj);
            catch
                flag = false;
            end
            
        end
        %------------------------------------------------------------------
        function flag =  propertiesChanged(userData,sysObj)
            % Check if a property value has changed since last button press
            if isfield(userData,'Filter')
                isObjFOSFilterObject = false;
                % If the Dynamic Filter Visualizer is called from
                % Fourth-order section filter block with Coefficient Source
                % set to Filter Object, return true always
                if isa(sysObj,'dsp.simulink.FourthOrderSectionFilter')
                    if strcmp(sysObj.CoefficientSource,'Filter object')
                        flag = true;
                        isObjFOSFilterObject = true;
                    end
                end
                if ~isObjFOSFilterObject
                    pObj = userData.Filter;
                    props = properties(pObj);
                    idx = 0;
                    flag = false;
                    w = warning('off', 'MATLAB:system:nonRelevantProperty');
                    restoreWarn = onCleanup(@() warning(w));
                    
                    while (idx < length(props)) && (~flag)
                        idx = idx + 1;
                        flag = flag || ~(isequal(pObj.(props{idx}), sysObj.(props{idx})));
                    end
                end
            else
                flag = true;
            end
        end
        %------------------------------------------------------------------
        function  userData = cacheProperties(userData,sysObj)
            % Save the System object, to act as baseline for checking for
            % any property change in the future
            if ~isfield(userData,'Filter')
                userData.Filter = clone(sysObj);
                return
            end
            w = warning('off', 'MATLAB:system:nonRelevantProperty');
            restoreWarn = onCleanup(@() warning(w));
            
            props = properties(sysObj);
            if ~isempty(intersect(props, 'SampleRate'))
                if (sysObj.SampleRate < 0)
                    % Do not copy SampleRate because it is inherited and
                    % not yet available
                    props = setdiff(props, 'SampleRate', 'stable');
                end
            end
            mco = metaclass(sysObj);
            propList = mco.PropertyList;
            metaNames = {propList.Name};
            
            for index = 1:length(props)
                try
                    ind = find(strcmp(metaNames,props{index}));
                    if ~strcmp(propList(ind).SetAccess,'private')%#ok
                        userData.Filter.(props{index}) = sysObj.(props{index});
                    end
                catch E
                    % swallow the error of setting states
                    if ~strcmp(E.identifier, 'MATLAB:system:stateInvalidPublicSet')
                        throw(E);
                    end
                end
            end
        end
        %------------------------------------------------------------------
        function userData = blankAndAnnotate(userData, vis, blkh, str)
            vis.FilterNames = {get_param(blkh, 'Name')};
            vis.ShowLegend = true;
            vis.Annotation = str;
        end
        %------------------------------------------------------------------
        function vis = initVisualizer(actionData, sysObj)
            % Initialize visualizer
            blkName = get_param(actionData.SystemHandle, 'Name');
            blkName = strrep(blkName,newline,' ');
            % Create the visualizer
            sampleRate = 2;
            normalizedFrequency = true;
            if isprop(sysObj, 'SampleRate')
                sampleRate = sysObj.SampleRate;
                normalizedFrequency = false;
            end
            if isprop(sysObj, 'SampleRateMode')
                if strcmp(sysObj.SampleRateMode,'Use normalized frequency (0 to 1)')
                    normalizedFrequency = true;
                    sampleRate = 2;
                elseif strcmp(sysObj.SampleRateMode,'Specify on dialog')
                    normalizedFrequency = false;
                end
            end
            frequencyRange = [0 sampleRate/2];
            vis = dsp.DynamicFilterVisualizer(2048, ...
                sampleRate, ...
                frequencyRange, ...
                'Name',blkName, ...
                'FilterNames',getVisualizationLegend(sysObj,blkName), ...
                'ShowLegend',true, ...
                'NormalizedFrequency', normalizedFrequency, ...
                'HasStatusbar',false);
        end
        %------------------------------------------------------------------
        function plotResponse(userData)
            % compute and plot the filter frequency response
            filters = getVisualizationFilters(userData.Filter);
            if iscell(filters)
                userData.VisualizerHandle(filters{:});
            else
                userData.VisualizerHandle(filters);
            end
        end
    end
%--------------------------------------------------------------------------
% Static hidden methods
%--------------------------------------------------------------------------
    methods (Static, Hidden)
        %------------------------------------------------------------------
        function userData = qeGetUserData(blkh)
            % Get user data, this is used for testing to give the test
            % harness an early access to the user data.
            import dsp.simulink.internal.FilterResponseVisualizationButton.*
            actionMap = getKeyValue(matlab.system.ui.PlatformDescriptor.SystemMap, blkh);
            keys = actionMap.keys;
            actionCache = actionMap(keys{1});
            sysObj = matlab.system.ui.SimulinkDescriptor.getBlockActionSystemObjectInstance(...
                blkh, get(blkh,'System'), actionCache.Action, actionCache.ActionData);
            userData = actionCache.ActionData.UserData;
            if ~isfield(actionCache.ActionData.UserData,'Filter')
                % Cache object characteristics
                userData = cacheProperties(userData,sysObj);
                userData.forceApply = true;
            end
            if ~isfield(actionCache.ActionData.UserData,'VisualizerHandle')
                % Cache visualization object
                userData.VisualizerHandle = initVisualizer(actionCache.ActionData,sysObj);
            end
            % Cache the user data on the action data
            actionCache.ActionData.UserData = userData;
        end
        %------------------------------------------------------------------
        function sysObj = getSystemObjectDescriptor(blkh)
            actionMap = getKeyValue(matlab.system.ui.PlatformDescriptor.SystemMap, blkh);
            keys = actionMap.keys;
            actionCache = actionMap(keys{1});
            sysObj = matlab.system.ui.SimulinkDescriptor.getBlockActionSystemObjectInstance(...
                blkh, get(blkh,'System'), actionCache.Action, actionCache.ActionData);
        end
    end
end
