classdef TunableBandpassBandstopFIRPolicy < matlab.system.CustomPropertyOrInput
% TunableBandpassBandstopIIRPolicy This class defines how the tunable design
% parameters for TunableBandpassFIRFilter and TunableBandstopFIRFilter are
% provided
    
%   Copyright 2022-2023 The MathWorks, Inc.

%#codegen
    
    methods
        %------------------------------------------------------------------
        function this = TunableBandpassBandstopFIRPolicy(aClient, aCPN, aOrdinal,aInputLabel)
            this@matlab.system.CustomPropertyOrInput(aClient, aCPN, aOrdinal,aInputLabel);
        end
    end
    
    methods (Static)
        %------------------------------------------------------------------
        function flag = isPropertyActive(this,prop, flag)
            switch prop
                case  'FilterOrder'
                    flag = ~this.FilterOrderPort;
                case 'CenterFrequency'
                    flag = ~this.CenterFrequencyPort;
                case 'Bandwidth'
                    flag = ~this.BandwidthPort;
                case 'SidelobeAttenuation'
                    flag = ~this.SidelobeAttenuationPort && isChebwin(this);
                case 'SidelobeAttenuationPort'
                    flag = isChebwin(this);
                case 'KaiserWindowParameter'
                    flag = ~this.KaiserWindowParameterPort && isKaiser(this);
                case 'KaiserWindowParameterPort'
                    flag = isKaiser(this);
            end
        end
        %------------------------------------------------------------------
        function flag = isInputActive(this,prop,flag)
            switch prop
                case  'FilterOrder'
                    flag = this.FilterOrderPort;
                case 'CenterFrequency'
                    flag = this.CenterFrequencyPort;
                case 'SidelobeAttenuation'
                    flag = this.SidelobeAttenuationPort && isChebwin(this);
                case 'KaiserWindowParameter'
                    flag = this.KaiserWindowParameterPort && isKaiser(this);
            end                                   
        end
    end
end
