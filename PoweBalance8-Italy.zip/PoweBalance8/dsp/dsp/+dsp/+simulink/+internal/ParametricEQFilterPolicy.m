classdef ParametricEQFilterPolicy < matlab.system.CustomPropertyOrInput
    % ParametricEQFilterPolicy This class defines how the tunable parameters
    % Bandwidth, CenterFrequency, CutoffFrequency and  PassbandFrequency
    % CenterFrequencyCoefficient, QualityFactor, PeakGain and PeakGaindB are
    % specified on the ParametricEQFilter and NotchPeakFilter blocks 
    
    %   Copyright 2017 The MathWorks, Inc.
    
    %#codegen
    
    methods
        function obj = ParametricEQFilterPolicy(aClient, aCPN, aOrdinal,aInputLabel)
            obj@matlab.system.CustomPropertyOrInput(aClient, aCPN, aOrdinal,aInputLabel);
        end
    end
    
    methods (Static)
        
        function flag = isPropertyActive(obj,prop, flag)
            
            switch prop
                case  'BandwidthPort'
                    flag = strcmp(obj.Specification,'Bandwidth and center frequency');
                case  'CenterFrequencyPort'
                    flag = strcmp(obj.Specification,'Bandwidth and center frequency') || ... 
                           strcmp(obj.Specification,'Quality factor and center frequency');
                case  'PeakGaindBPort'
                    flag = strcmp(obj.Specification,'Bandwidth and center frequency') || ...  
                           strcmp(obj.Specification,'Quality factor and center frequency');
                    
                case  'BandwidthCoefficientPort'
                    flag = strcmp(obj.Specification,'Coefficients');
                case  'CenterFrequencyCoefficientPort'
                    flag = strcmp(obj.Specification,'Coefficients');
                case  'PeakGainPort'
                    flag = strcmp(obj.Specification,'Coefficients');
                    
                case  'QualityFactorPort'
                    flag = strcmp(obj.Specification,'Quality factor and center frequency');
                    
                case  'Bandwidth'
                    fromPort  = obj.BandwidthPort;
                    flag = ~fromPort && strcmp(obj.Specification,'Bandwidth and center frequency');
                case  'CenterFrequency'
                    fromPort  = obj.CenterFrequencyPort;
                    flag = ~fromPort && (strcmp(obj.Specification,'Bandwidth and center frequency') || ... 
                                         strcmp(obj.Specification,'Quality factor and center frequency'));
                case  'PeakGaindB'
                    fromPort  = obj.PeakGaindBPort;
                    flag = ~fromPort && (strcmp(obj.Specification,'Bandwidth and center frequency') || ... 
                                         strcmp(obj.Specification,'Quality factor and center frequency'));
                    
                case  'BandwidthCoefficient'
                    fromPort  = obj.BandwidthCoefficientPort;
                    flag = ~fromPort && strcmp(obj.Specification,'Coefficients');
                case  'CenterFrequencyCoefficient'
                    fromPort  = obj.CenterFrequencyCoefficientPort;
                    flag = ~fromPort && strcmp(obj.Specification,'Coefficients');
                case  'PeakGain'
                    fromPort  = obj.PeakGainPort;
                    flag = ~fromPort && strcmp(obj.Specification,'Coefficients');
                    
                case  'QualityFactor'
                    fromPort  = obj.QualityFactorPort;
                    flag = ~fromPort && strcmp(obj.Specification,'Quality factor and center frequency');  
                otherwise
            end
            
        end
        function flag = isInputActive(obj,prop,flag)
            switch prop
                case 'Bandwidth'
                    fromPort  = obj.BandwidthPort;
                    flag = fromPort && strcmp(obj.Specification,'Bandwidth and center frequency');
                    
                case  'CenterFrequency'
                    fromPort  = obj.CenterFrequencyPort;
                    flag = fromPort && (strcmp(obj.Specification,'Bandwidth and center frequency') || ... 
                                        strcmp(obj.Specification,'Quality factor and center frequency')); 
                case 'PeakGaindB'
                    fromPort  = obj.PeakGaindBPort;
                    flag = fromPort && (strcmp(obj.Specification,'Bandwidth and center frequency') || ... 
                                        strcmp(obj.Specification,'Quality factor and center frequency'));
                    
                case  'BandwidthCoefficient'
                    fromPort  = obj.BandwidthCoefficientPort;
                    flag = fromPort && strcmp(obj.Specification,'Coefficients');
                case  'CenterFrequencyCoefficient'
                    fromPort  = obj.CenterFrequencyCoefficientPort;
                    flag = fromPort && strcmp(obj.Specification,'Coefficients');
                case  'PeakGain'
                    fromPort  = obj.PeakGainPort;
                    flag = fromPort && strcmp(obj.Specification,'Coefficients');
                    
                case  'QualityFactor'
                    fromPort  = obj.QualityFactorPort;
                    flag = fromPort && strcmp(obj.Specification,'Quality factor and center frequency');
                otherwise
            end
        end
    end
end