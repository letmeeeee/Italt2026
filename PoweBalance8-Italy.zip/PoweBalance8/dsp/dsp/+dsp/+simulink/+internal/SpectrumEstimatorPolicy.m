classdef SpectrumEstimatorPolicy < matlab.system.CustomPropertyOrInput
% SpectrumEstimatorPloicy This class defines how the tunable parameter
% ForgettingFactor is specified on the spectrum estimator block
    
 %   Copyright 2018 The MathWorks, Inc.

    %#codegen
    
    methods
        function obj = SpectrumEstimatorPolicy(aClient, aCPN, aOrdinal,aInputLabel)
            obj@matlab.system.CustomPropertyOrInput(aClient, aCPN, aOrdinal,aInputLabel);
        end
    end
    
    methods (Static)

        function flag = isPropertyActive(obj,prop, flag)

            switch prop
                case  'ForgettingFactorPort'
                    flag = ~strcmp(obj.AveragingMethod,'Running');
                case  'ForgettingFactor'
                    fromPort  = obj.ForgettingFactorPort;
                    flag = ~fromPort && ~strcmp(obj.AveragingMethod,'Running');
            end
            
        end
        function flag = isInputActive(obj,prop,flag)
            
            if strcmp( prop , 'ForgettingFactor')
                fromPort  = obj.ForgettingFactorPort;
                flag = fromPort && ~strcmp(obj.AveragingMethod,'Running');
            end
            
        end
    end
    
end