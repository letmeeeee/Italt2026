classdef TunableLowpassHighpassIIRPolicy < matlab.system.CustomPropertyOrInput
% TunableLowpassHighpassIIRPolicy This class defines how the tunable design
% parameters for TunableLowpassIIRFilter and TunableHighpassIIRFilter are
% provided
    
%   Copyright 2022 The MathWorks, Inc.

%#codegen
    
    methods
        %------------------------------------------------------------------
        function this = TunableLowpassHighpassIIRPolicy(aClient, aCPN, aOrdinal,aInputLabel)
            this@matlab.system.CustomPropertyOrInput(aClient, aCPN, aOrdinal,aInputLabel);
        end
    end
    
    methods (Static)
        %------------------------------------------------------------------
        function flag = isPropertyActive(this,prop, flag)
            switch prop
                case  'FilterOrder'
                    flag = ~this.FilterOrderPort;
                case 'F3dB'
                    flag = ~this.F3dBPort;
                case 'Apass'
                    flag = ~this.ApassPort && strcmp(this.DesignMethod, 'Chebyshev Type I');
                case 'ApassPort'
                    flag = strcmp(this.DesignMethod, 'Chebyshev Type I');
                case 'Astop'
                    flag = ~this.AstopPort && strcmp(this.DesignMethod, 'Chebyshev Type II');
                case 'AstopPort'
                    flag = strcmp(this.DesignMethod, 'Chebyshev Type II');

            end
        end
        %------------------------------------------------------------------
        function flag = isInputActive(this,prop,flag)
            switch prop
                case  'FilterOrder'
                    flag = this.FilterOrderPort;
                case 'F3dB'
                    flag = this.F3dBPort;
                case 'Apass'
                    flag = this.ApassPort && strcmp(this.DesignMethod, 'Chebyshev Type I');
                case 'Astop'
                    flag = this.AstopPort && strcmp(this.DesignMethod, 'Chebyshev Type II');
            end                                   
        end
    end
end