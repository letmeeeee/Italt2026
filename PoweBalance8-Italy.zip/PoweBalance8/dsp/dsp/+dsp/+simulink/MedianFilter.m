classdef (StrictDefaults)MedianFilter < dsp.MedianFilter
    % MedianFilter Compute moving median of input
    % This class is used in the Median Filter block in dspstat3 library

    % Copyright 2021-2022 The MathWorks, Inc.
    %#codegen
    %#ok<*EMCLS>
    methods
        function obj = MedianFilter(varargin)
            obj@dsp.MedianFilter(varargin{:});
        end
    end

    methods (Access = protected)
        %% Block Icon
        function icon = getIconImpl(~)
           icon = getString(message('dsp:StatisticsBlockDialog:MedianFilterIcon')); 
        end
        
        %%Propagators
        function cplx = isOutputComplexImpl(obj)
            % Complexity propagator
            cplx = propagatedInputComplexity(obj, 1);
        end
        
        function sz = getOutputSizeImpl(obj)
            % Output size propagator
            sz = propagatedInputSize(obj, 1);
        end
        
        function dt = getOutputDataTypeImpl(obj)
            % Output datatype propagator
            dt = propagatedInputDataType(obj, 1);
        end
        
        function isvar = isOutputFixedSizeImpl(obj)
            isvar = propagatedInputFixedSize(obj,1);
        end
        
        function name = getInputNamesImpl(~)
            name = '';
        end
        
        function name = getOutputNamesImpl(~)
            name = '';
        end
        function val = supportsMultipleInstanceImpl(~)
            % Support in for-each subsystem
            val = true;
        end
    end
        
    methods(Static, Access=protected)
        %% Block header - widget grouping
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.MedianFilter', ...
                ShowSourceLink=true, ...
                Title='dsp:StatisticsBlockDialog:MedianFilterTitle',...
                Text='dsp:StatisticsBlockDialog:MedianFilterHeader');
        end

        function mainS = getPropertyGroupsImpl
            %Get default parameters group for this System object
            propertyList = {
                    matlab.system.display.internal.Property('WindowLength',Description='dsp:StatisticsBlockDialog:WindowLength_MP'), ...
                };

            mainS = matlab.system.display.Section(...
                Title = 'dsp:system:Shared:Parameters', ...
                PropertyList = propertyList);
        end
   end

end