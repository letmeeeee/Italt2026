classdef (StrictDefaults)FIRHalfbandInterpolator < dsp.FIRHalfbandInterpolator
% This class is used for the FIR Halfband Interpolator block in dspfdesign
    
% Copyright 2021-2022 The MathWorks, Inc.

%#codegen
%#ok<*EMCA>

    methods
        function obj = FIRHalfbandInterpolator(varargin)
            obj@dsp.FIRHalfbandInterpolator(varargin{:});
        end
    end
    
    %----------------------------------------------------------------------
    % Protected Methods
    %----------------------------------------------------------------------
    methods (Access = protected)
        
        %------------------------------------------------------------------
        function varargout = getInputNamesImpl(obj)
            % Name of input ports (shows on block icon)
            if ~obj.FilterBankInputPort
                varargout{1} =   '';
            else % power-complementary inputs
                varargout{1} =   'LP';
                varargout{2} =   'HP';
            end
        end               
        %------------------------------------------------------------------
        function varargout = getOutputNamesImpl(~)
            % Name of output port (shows on block icon)
            varargout{1} =   '';
        end
        
        %------------------------------------------------------------------
        function icon = getIconImpl(obj)
            % MATLAB system block icon
            if ~obj.FilterBankInputPort
                icon = getString(message(...
                    'dsp:system:FIRHalfbandInterpolator:interpolatorIconString'));
            else % power-complementary outputs requested
                icon = getString(message(...
                    'dsp:system:FIRHalfbandInterpolator:synthesisIconString'));
            end
        end
        
        %------------------------------------------------------------------
        function val = supportsMultipleInstanceImpl(~)
            % Support in for-each subsystem
            val = true;
        end
        
        % PROPAGATOR METHODS: (used by Simulink)
        %------------------------------------------------------------------
        function varargout = getOutputSizeImpl(obj)
            varargout{1} = propagatedInputSize(obj,1);
            varargout{1}(1) = varargout{1}(1)*2;
        end
        %------------------------------------------------------------------
        function varargout = getOutputDataTypeImpl(obj)
            inputDT = propagatedInputDataType(obj,1);
            if (ischar(inputDT) && any(strcmp(inputDT,{'double', 'single'})))
                % Floating-point input
                varargout{1} = inputDT;
            else
                if ischar(inputDT)
                    % Integer input
                    varargout{1} = numerictype(inputDT);
                else
                    % Fixed-point input
                    varargout{1} = inputDT;
                end
                varargout{1}.Signedness = 'Signed'; % Output is always signed
            end
        end
        %------------------------------------------------------------------
        function varargout = isOutputComplexImpl(obj)
            varargout{1} = propagatedInputComplexity(obj,1);
        end
        %------------------------------------------------------------------
        function varargout = isOutputFixedSizeImpl(obj)
            varargout{1} = propagatedInputFixedSize(obj,1);
        end
        function flag = isInactivePropertyImpl(obj, prop)            
            switch prop
                case {'NormalizedFrequency'}
                    flag = true;
                otherwise
                    flag = isInactivePropertyImpl@dsp.internal.FIRHalfbandBase(obj,prop);
            end
        end
        function validatePropertiesImpl(obj)
            if ~isSampleRateInherited(obj)
                crossValidateProperties(obj);
            end            
        end
    end   
    %----------------------------------------------------------------------
    % Static protected methods
    %----------------------------------------------------------------------
    methods(Static,Access=protected)
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.FIRHalfbandInterpolator', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:system:FIRHalfbandInterpolator:titleString',...
                'Text',  'dsp:system:FIRHalfbandInterpolator:descriptionString');
        end
        function groups = getPropertyGroupsImpl
            props = {...
                matlab.system.display.internal.Property('Specification','Description','dsp:system:FIRHalfbandInterpolator:Specification_MP'), ...
                matlab.system.display.internal.Property('FilterOrder','Description','dsp:system:FIRHalfbandInterpolator:FilterOrder_MP'),...
                matlab.system.display.internal.Property('TransitionWidth','Description','dsp:system:FIRHalfbandInterpolator:TransitionWidth_MP'),...
                matlab.system.display.internal.Property('StopbandAttenuation','Description','dsp:system:FIRHalfbandInterpolator:StopbandAttenuation_MP'),...
                matlab.system.display.internal.Property('DesignMethod','Description','dsp:system:FIRHalfbandInterpolator:DesignMethod_MP'),...
                matlab.system.display.internal.Property('Numerator','Description','dsp:system:FIRHalfbandInterpolator:Numerator_MP'),...
                matlab.system.display.internal.Property('FilterBankInputPort','Description','dsp:system:FIRHalfbandInterpolator:FilterBankInputPort_MP'),...
                matlab.system.display.internal.Property('SampleRateMode','Description','dsp:system:AbstractSampleRateEngine:SampleRateMode_MP'), ...
                matlab.system.display.internal.Property('SampleRate','Description','dsp:system:AbstractSampleRateEngine:SampleRate_MP')};

            mainS = matlab.system.display.Section(...
                'Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', props);
            
            filterVis = dsp.internal.FilterVisualizationButton;
            mainS.Actions = filterVis.fvtoolAction;
            
            mainSG = matlab.system.display.SectionGroup(...
                'TitleSource', 'Auto', ...
                'Sections', mainS);
            dtSG = matlab.system.display.internal.DataTypesGroup(...
                'dsp.FIRHalfbandInterpolator');
            dtSG.PropertyList{2} = ...
                matlab.system.display.internal.DataTypeProperty( ...
                'CoefficientsDataType', ...
                'Prefix', 'coeffs', ...
                'Description', 'Coefficients');
            groups = [mainSG, dtSG];
        end        
    end
    methods (Hidden)
        function f = updateFvtoolFigure(obj,f)
            % Used to update fvtool plot when object is used in Simulink
            setfilter(f, obj);
            if isSampleRateNormalized(obj) || strcmp(obj.Specification, 'Coefficients') 
                f.NormalizedFrequency = 'on';
            else
                f.NormalizedFrequency = 'off';
            end

        end
    end
end
