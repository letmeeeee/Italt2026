classdef QRSolver < dsp.internal.QRSolver
    % QRSolver Find minimum-norm-residual solution to AX = B
    
    %   Copyright 2019-2021 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCA>
        
    methods
        %------------------------------------------------------------------
        % Constructor
        function obj = QRSolver(varargin)
            obj@ dsp.internal.QRSolver(varargin{:});
        end
    end
    
    methods(Access = protected)
        %------------------------------------------------------------------
        function validateInputsImpl(~,A,B)
            % Validate inputs to the step method at initialization
            validateattributes(A, {'single', 'double'}, {'2d'},'','');
            validateattributes(B, {'single', 'double'}, {'2d'},'','');
        end
        %------------------------------------------------------------------
        function N = getNumInputsImpl(~)
            % Specify number of System inputs
            N = 2;
        end
        %------------------------------------------------------------------
        function N = getNumOutputsImpl(~)
            % Specify number of System outputs
            N = 1;
        end
        %------------------------------------------------------------------
        function varargout = getInputNamesImpl(~)
            % Define name of input ports (shows on block icon)
            varargout{1} = 'A';
            varargout{2} = 'B';
        end
        %------------------------------------------------------------------
        function varargout = getOutputNamesImpl(~)
            % Define name of output ports (shows on block icon)
            varargout{1} = 'X';
        end
        %------------------------------------------------------------------
        function flag = isInputSizeMutableImpl(~,~)
            flag = false;
        end
        %------------------------------------------------------------------
        function varargout = isOutputComplexImpl(obj)
            % Complexity propagator
            % Q and R have the same complexity as the input, E is always
            % real
            for ind = 1:getNumOutputs(obj)
                varargout{ind} = propagatedInputComplexity(obj, 1) || ...
                                 propagatedInputComplexity(obj, 2);
            end
        end
        %------------------------------------------------------------------
        function varargout = getOutputSizeImpl(obj)
            % Output size propagator
            ASize = propagatedInputSize(obj, 1);
            BSize = propagatedInputSize(obj, 2);
            varargout{1} = [ASize(2) BSize(2)];
        end
        %------------------------------------------------------------------
        function varargout = getOutputDataTypeImpl(obj)
            % Output datatype propagator
            for ind = 1:getNumOutputs(obj)
                varargout{ind} = propagatedInputDataType(obj, 2);
            end
        end
        %------------------------------------------------------------------
        function varargout = isOutputFixedSizeImpl(obj)
            flag = propagatedInputFixedSize(obj,1);
            for ind = 1:getNumOutputs(obj)
                varargout{ind} = flag;
            end
        end
        %------------------------------------------------------------------
        function val = supportsMultipleInstanceImpl(~)
            % Support in for-each subsystem
            val = true;
        end
        %------------------------------------------------------------------
        function icon = getMaskDisplayImpl(~)
            x=[ 0.2 0.475 .475 0.2 0.2 NaN 0.55 0.64 0.64 0.55 0.55 NaN ...
                0.685 0.73 NaN 0.685 0.73 NaN 0.775 0.865 0.865 0.775 0.775 ];
            y=[ 0.2 0.2 0.7 0.7 0.2 NaN 0.35 0.35 0.7 0.7 0.35 NaN 0.4 ...
                0.4 NaN 0.45 0.45 NaN 0.2 0.2 0.7 0.7 0.2 ];
            
            iconPlotCmds = {['plot(0,0,1,1,' mat2str(x) ',' mat2str(y + 0.05) ');']};
            iconTextCmds = {['text(0.5,0.9,''AX=B (QR)'',''horizontalAlignment'',''center'', ''verticalAlignment'', ''middle'');'...
                            'text(0.4,0.15,''[m x n]'',''horizontalAlignment'',''center'', ''verticalAlignment'', ''middle'');']
                            };
            % 2 inputs (A,B)
            % 1 output (X)
            portLabelCmds = {
                ['port_label(''input'',1,''A'');'...
                'port_label(''input'',2,''B'');'...
                'port_label(''output'',1,''X'');']
                };
            icon = [iconTextCmds;iconPlotCmds;portLabelCmds];
        end
    end
    
    methods(Static, Access = protected)
        %------------------------------------------------------------------
        function header = getHeaderImpl
            % Define header panel for System block dialog
            header = matlab.system.display.Header(...
                'dsp.simulink.QRSolver', ...
                'ShowSourceLink',true, ...
                'Title', 'dsp:system:QRSolver:BlockTitle', ...
                'Text', 'dsp:system:QRSolver:BlockHeader');
        end
    end
end
