classdef (StrictDefaults)PowerMeter < powermeter
%PowerMeter Measure power of signal
% This class is used in the Power Meter block

% Copyright 2020-2022 The MathWorks, Inc.

%#codegen

    properties (Nontunable)
        %CCDFOutput CCDF output
        CCDFOutput = 'Relative power (dB above average power)'
        %ProbabilityVector Specify probability (%) for relative power output
        ProbabilityVector = [10; 1; 0.1; 0.01; 0.001; 0.0001]
        %RelativePowerVector Specify relative power (dB) for probability output
        RelativePowerVector = [0; 3; 6; 9; 12]
        %ResetPort Reset port
        ResetPort (1,1) logical = false
        %AllowArbitraryInputLength Allow arbitrary input length
        %   When this flag is set to false, input frame length must be a
        %   multiple of the Hop Size (Window Length - Overlap Length).
        %   Using an input which doesn't satisfy the length requirement
        %   results in an error. When this flag is set to true, input
        %   size is not restricted and can be arbitrary. The output in this
        %   case has a variable size. 
        %   The default value is 'false'.
        AllowArbitraryInputLength (1, 1) logical = false;
    end

    properties(Constant, Hidden)
        CCDFOutputSet = matlab.system.StringSet({ ...
            'Relative power (dB above average power)', ...
            'Probability (%)', ...
            'Relative power and probability (whole CCDF curve)'});
    end
    %----------------------------------------------------------------------
    % Public methods
    %----------------------------------------------------------------------
    methods
        %------------------------------------------------------------------
        function obj = PowerMeter(varargin)
            obj@powermeter(varargin{:});
        end
        %------------------------------------------------------------------
        function set.ProbabilityVector(obj, value)
            validateattributes(value,{'single','double'},{'real','nonnegative','finite','nonnan','column','<=',100},'','probability');
            obj.ProbabilityVector = value;
        end
        %------------------------------------------------------------------
        function set.RelativePowerVector(obj, value)
            validateattributes(value,{'single','double'},{'real','finite','nonnan','column'},'','relative power');
            obj.RelativePowerVector = value;
        end
    end
    %----------------------------------------------------------------------
    % Protected methods
    %----------------------------------------------------------------------
    methods (Access = protected)
        %------------------------------------------------------------------
        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end
        %------------------------------------------------------------------
        function setupImpl(obj,u)
            setupImpl@powermeter(obj,u);
        end
        %------------------------------------------------------------------
        function validateInputsImpl(obj,varargin)
            validateInputsImpl@powermeter(obj,varargin{1});

            if obj.getExecPlatformIndex()
                sz = propagatedInputSize(obj, 1);
                frameSize = sz(1);
            else
                frameSize = size(varargin{1},1);
            end
            if ~obj.ComputeCCDF
                WL = obj.WindowLength;
                OL = obj.OverlapLength;
                fixedInput = propagatedInputFixedSize(obj,1);   
                arblabel = 'Allow Arbitrary Fixed size signals';
                mitigationstr = sprintf('Select the ''%s'' check box',arblabel); 
                coder.internal.errorIf(~isempty(fixedInput) && fixedInput && ~obj.AllowArbitraryInputLength && mod(frameSize, WL-OL) ~= 0, ...
                    'dsp:system:MovingStatistic:inputSizeArbitrary',frameSize, WL-OL, mitigationstr);         
            end
        end
        %------------------------------------------------------------------
        function icon = getIconImpl(~)
            icon = getString(message('dsp:system:powermeter:BlockIcon'));
        end
        %------------------------------------------------------------------
        function varargout = stepImpl(obj,u,varargin)
            if strcmpi(obj.Measurement,'All')
                y = cell(1,3);
            else
                y = cell(1,1);
            end
            if obj.ResetPort
                if logical(varargin{1})
                    reset(obj);
                end
            end
            [y{:}] = stepImpl@powermeter(obj,u);
            if obj.ComputeCCDF
                dt = getDataType(obj);
                if strcmpi(obj.CCDFOutput,'Relative power (dB above average power)')
                    varargout = {y{:} relativePower(obj, cast(obj.ProbabilityVector, dt))};
                elseif strcmpi(obj.CCDFOutput,'Probability (%)')
                    varargout = {y{:} probability(obj, cast(obj.RelativePowerVector, dt))};
                else % 'Relative power and probability (whole CCDF curve)'
                    [relpwr, prob] = ccdf(obj);
                    varargout = {y{:} relpwr prob};
                end
            else
                varargout = y;
            end
        end
        %------------------------------------------------------------------
        function flag = isInactivePropertyImpl(obj,prop)
            if obj.ComputeCCDF
                if any(strcmpi(prop,{'WindowLength','OverlapLength','AllowArbitraryInputLength'}))
                    flag = true;
                elseif any(strcmpi(prop,{'PowerResolution','PowerRange'}))
                    flag = false;
                elseif strcmpi(prop,'ProbabilityVector') && ...
                    any(strcmpi(obj.CCDFOutput,{'Probability (%)','Relative power and probability (whole CCDF curve)'}))
                    flag = true;
                elseif strcmpi(prop,'RelativePowerVector') && ...
                    any(strcmpi(obj.CCDFOutput,{'Relative power (dB above average power)','Relative power and probability (whole CCDF curve)'}))
                    flag = true;
                else
                    flag = false;
                end
            else
                if any(strcmpi(prop,{'WindowLength','OverlapLength'}))
                    flag = false;
                elseif any(strcmpi(prop,{'PowerResolution','PowerRange','CCDFOutput','ProbabilityVector','RelativePowerVector','ResetPort'}))
                    flag = true;
                else
                    flag = false;
                end
            end
        end
        %------------------------------------------------------------------
        function num = getNumInputsImpl(obj)
            if obj.ComputeCCDF && obj.ResetPort
                num = 2;
            else
                num = 1;
            end
        end
        %------------------------------------------------------------------
        function num = getNumOutputsImpl(obj)
            if strcmp(obj.Measurement, 'All')
                num = 3;
            else
                num = 1;
            end

            if obj.ComputeCCDF
                if strcmpi(obj.CCDFOutput,'Relative power and probability (whole CCDF curve)')
                    num = num + 2;
                else
                    num = num + 1;
                end
            end
        end
        %------------------------------------------------------------------
        function name = getInputNamesImpl(obj)
            if obj.ComputeCCDF && obj.ResetPort
                name = ["" "Rst"];
            else
                name = "";
            end
        end
        %------------------------------------------------------------------
        function name = getOutputNamesImpl(obj)
            switch obj.Measurement
                case {'All'}
                    name = ["Avg","Peak","PAPR"];
                case {'Average power'}
                    name = "Avg";
                case {'Peak power'}
                    name = "Peak";
                case {'Peak-to-average power ratio'}
                    name = "PAPR";
            end
            if obj.ComputeCCDF
                switch obj.CCDFOutput
                    case 'Relative power and probability (whole CCDF curve)'
                        name = [name,"RelPwr","Prob"];
                    case 'Probability (%)'
                        name = [name,"Prob"];
                    case 'Relative power (dB above average power)'
                        name = [name,"RelPwr"];
                end
            end
        end
        %------------------------------------------------------------------
        function varargout = isOutputComplexImpl(obj)
            % Complexity propagator
            if strcmp(obj.Measurement, 'All')
                varargout = {false false false};
            else
                varargout = {false};
            end

            if obj.ComputeCCDF
                if strcmpi(obj.CCDFOutput,'Relative power and probability (whole CCDF curve)')
                    varargout = {varargout{:} false false};
                else
                    varargout = {varargout{:} false};
                end
            end
        end
        %------------------------------------------------------------------
        function n = getNumChans(obj,~)
            thisSize = propagatedInputSize(obj, 1);
            n = thisSize(2);
        end
        %------------------------------------------------------------------
        function varargout = getOutputSizeImpl(obj)
            % Output size propagator
            inputSize =  propagatedInputSize(obj, 1);
            if isempty(inputSize)
                sz = inputSize;
            else
                % Only for sliding window method
                WL = obj.WindowLength;
                OL = obj.OverlapLength;
                % For varsize, return the maximal output size rather than
                % the actual size.
                sz = [ceil(inputSize(1)/(WL-OL)) inputSize(2)];
            end
            if obj.ComputeCCDF
                if ~isempty(sz)
                    sz(1) = 1;
                    numChan = sz(2);
                else
                    numChan = 0;
                end
                if strcmp(obj.Measurement, 'All')
                    varargout = {sz sz sz};
                else
                    varargout = {sz};
                end
                if strcmpi(obj.CCDFOutput,'Relative power (dB above average power)')
                    varargout = {varargout{:} [length(obj.ProbabilityVector) numChan]};
                elseif strcmpi(obj.CCDFOutput,'Probability (%)')
                    varargout = {varargout{:} [length(obj.RelativePowerVector) numChan]};
                else % 'Relative power and probability (whole CCDF curve)'
                    szCCDF = [ceil(obj.PowerRange/obj.PowerResolution)+1 numChan];
                    varargout = {varargout{:} szCCDF szCCDF};
                end
            else
                if strcmp(obj.Measurement, 'All')
                    varargout = {sz sz sz};
                else
                    varargout = {sz};
                end
            end
        end
        %------------------------------------------------------------------
        function varargout = getOutputDataTypeImpl(obj)
            % Output datatype propagator
            dt = propagatedInputDataType(obj, 1);
            if strcmp(obj.Measurement, 'All')
                varargout = {dt dt dt};
            else
                varargout = {dt};
            end
            if obj.ComputeCCDF
                if strcmpi(obj.CCDFOutput,'Relative power and probability (whole CCDF curve)')
                    varargout = {varargout{:} dt dt};
                else
                    varargout = {varargout{:} dt};
                end
            end
        end
        %------------------------------------------------------------------
        function varargout = isOutputFixedSizeImpl(obj)
            if obj.ComputeCCDF
                isFixedSize = true;
            else
                isFixedSize = isFixedSizeOutput(obj);
            end
            if strcmp(obj.Measurement, 'All')
                varargout = {isFixedSize isFixedSize isFixedSize};
            else
                varargout = {isFixedSize};
            end
            if obj.ComputeCCDF
                if strcmpi(obj.CCDFOutput,'Relative power and probability (whole CCDF curve)')
                    varargout = {varargout{:} true true};
                else
                    varargout = {varargout{:} true};
                end
            end
        end
        function isFixedOutput = isFixedSizeOutput(obj)
            % Varsize output if input is varsize or arbitrary input is allowed
            isFixedOutput = propagatedInputFixedSize(obj,1) && ~obj.AllowArbitraryInputLength;
	    end
        %------------------------------------------------------------------
        function val = supportsMultipleInstanceImpl(obj)
            % Support in for-each subsystem
            if ~obj.ComputeCCDF
                % Foreach is allowed only for fixed size outputs (which requires
                % a fixed size input, and no arbitrary).
                val = propagatedInputFixedSize(obj,1) && ~obj.AllowArbitraryInputLength;
            else
                val = true;
            end
        end
        function s = saveObjectImpl(obj)
	        s = saveObjectImpl@powermeter(obj);
	        s.AllowArbitraryInputLength= obj.AllowArbitraryInputLength;
	    end
	
	    function s = loadObjectImpl(obj, s, wasLocked)
	        loadObjectImpl@powermeter(obj,s,wasLocked);
	        if isfield(s,'AllowArbitraryInputLength')
	            obj.AllowArbitraryInputLength = s.AllowArbitraryInputLength;
	        end
	    end
    end
    %----------------------------------------------------------------------
    % Static protected methods
    %----------------------------------------------------------------------
    methods(Static, Access=protected)
        %------------------------------------------------------------------
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.PowerMeter', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:system:powermeter:BlockName',...
                'Text', 'dsp:system:powermeter:BlockHeader');
        end
        %------------------------------------------------------------------
        function groups = getPropertyGroupsImpl
            props = {...
                matlab.system.display.internal.Property('Measurement','Description','dsp:system:powermeter:Measurement_MP'), ...
                matlab.system.display.internal.Property('ReferenceLoad','Description','dsp:system:powermeter:ReferenceLoad_MP'), ...
                matlab.system.display.internal.Property('OutputPowerUnits','Description','dsp:system:powermeter:OutputPowerUnits_MP'), ...
                matlab.system.display.internal.Property('WindowLength','Description','dsp:system:powermeter:WindowLength_MP'), ...
                matlab.system.display.internal.Property('OverlapLength','Description','dsp:system:powermeter:OverlapLength_MP'),...
                matlab.system.display.internal.Property('AllowArbitraryInputLength','Description','dsp:blkprm_prompts:AllowArbitraryFixedInput_MP'),...
                matlab.system.display.internal.Property('ComputeCCDF','Description','dsp:system:powermeter:ComputeCCDF_MP'), ...
                matlab.system.display.internal.Property('PowerRange','Description','dsp:system:powermeter:PowerRange_MP'), ...
                matlab.system.display.internal.Property('PowerResolution','Description','dsp:system:powermeter:PowerResolution_MP'), ...
                matlab.system.display.internal.Property('CCDFOutput','Description','dsp:system:powermeter:CCDFOutput_MP'), ...
                matlab.system.display.internal.Property('ProbabilityVector','Description','dsp:system:powermeter:ProbabilityVector_MP'), ...
                matlab.system.display.internal.Property('RelativePowerVector','Description','dsp:system:powermeter:RelativePowerVector_MP'), ...
                matlab.system.display.internal.Property('ResetPort','Description','dsp:system:powermeter:ResetPort_MP')};
            parameterString = message('dsp:system:Shared:Parameters');
            groups = matlab.system.display.Section('Title', ...
                parameterString.getString, ...
                'PropertyList',props);
        end
    end
end
