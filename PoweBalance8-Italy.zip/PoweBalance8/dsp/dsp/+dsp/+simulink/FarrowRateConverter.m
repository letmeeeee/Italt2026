classdef (StrictDefaults) FarrowRateConverter < dsp.FarrowRateConverter 
% This class is used for the Farrow Rate Converter block in dspsigops

% Copyright 2021-2023 The MathWorks, Inc.

%#codegen
%#ok<*EMCA>

properties (Nontunable)
    %AllowArbitraryInputLength Allow arbitrary input length.
    %   When this flag is set to false, input frame length must be a 
    %   multiple of the decimation factor. Using an input which doesn't 
    %   satisfy the length requirement results in an error. When this flag 
    %   is set to true, input frame size is not restricted and can be 
    %   arbitrary. The output in this case has a variable size.
    %   The default value is 'false'.
    AllowArbitraryInputLength (1, 1) logical = false;
end

methods
    % Constructor
    function obj = FarrowRateConverter(varargin)
        obj = obj@dsp.FarrowRateConverter(varargin{:});
    end
end

methods (Access = protected)

    function flag = isInputSizeMutableImpl(~,~)
        % Variable size inputs are allowed
        flag = true;
    end

    function isFixedOutput = isFixedSizeOutput(obj)
        % Varsize output if input is varsize or arbitrary input is allowed
        isFixedOutput = propagatedInputFixedSize(obj,1) && ~obj.AllowArbitraryInputLength;
    end

    function validateInputsImpl(obj, u) 
        validateInputsImpl@dsp.FarrowRateConverter(obj,u);
            
        if ~obj.CoefficientsExist
            return
        end

        % Obtain number of channels
        if obj.getExecPlatformIndex()
            sz = propagatedInputSize(obj, 1);
            nu = sz(1);
        else
            nu = size(u,1);
        end

        M = coder.const(obj.DecimationFactor);
        fixedInput = propagatedInputFixedSize(obj,1);        

        arblabel = message('dsp:blkprm_prompts:AllowArbitraryFixedInput_MP').string;
        if ~isempty(fixedInput)
            coder.internal.errorIf(fixedInput(1) && ~obj.AllowArbitraryInputLength(1) && mod(nu(1), M(1)) ~= 0, ...
                'dsp:system:FarrowRateConverter:inputSize',nu(1), M(1), arblabel);
        end
    end

    function setupImpl(obj, u)
        % Enforce discrete simulation time
        dsp.internal.checkSampleTime(obj);
        setupImpl@dsp.FarrowRateConverter(obj,u);
    end

    %Propagators
    function isComplex = isOutputComplexImpl(obj)
        isComplex = propagatedInputComplexity(obj, 1);
    end

    function isFixedOutput = isOutputFixedSizeImpl(obj)
        % Varsize output if input is varsize or arbitrary input is allowed
        isFixedOutput = isFixedSizeOutput(obj);
    end
 
    function outputSize = getOutputSizeImpl(obj)
        setFarrowSRCProperties(obj);
        
        inputSize = propagatedInputSize(obj, 1);
        
        % Notes:
        % 1) For varsize, return the maximal output size rather than the actual size.
        % 2) The true output size depends on internal datatypes: single vs double
        %    different roundoffs, so frame size may be longer by 1 sample for 
        %    float PrivL. Ideally, we'd use PrivL and PrivM for
        %    this calculation to get the exact length. Alas, this method is called 
        %    before setupImpl, so datatypes aren't even known at this point. 

        if ~isempty(inputSize)
            L = coder.const(obj.InterpolationFactor);
            M = coder.const(obj.DecimationFactor);
            outputSize = [ceil(inputSize(1) * L/M) inputSize(2)];
        else
            outputSize = [];
        end
    end

    function outputDT = getOutputDataTypeImpl(obj)
        dt1 = propagatedInputDataType(obj,1);
        if(~isempty(dt1))
            if ischar(dt1) % string, e.g. 'double', 'int16',  etc.
                protoTypeToUse = eval([dt1 '(0)']);
            else % numerictype
                protoTypeToUse = fi(0,dt1);
            end

            if ~obj.CoefficientsExist
                setFarrowSRCProperties(obj);
            end

            dataTypes = determineDataTypes(obj, protoTypeToUse);

            if isfi(dataTypes.outT)
                outputDT = dataTypes.outT.numerictype();
            else
                outputDT = class(dataTypes.outT);
            end
        else
            outputDT = [];
        end
    end

    function s = saveObjectImpl(obj)
        % Default implementation saves all public properties
        s = saveObjectImpl@dsp.FarrowRateConverter(obj);
        s.AllowArbitraryInputLength= obj.AllowArbitraryInputLength;
    end

    function s = loadObjectImpl(obj, s, wasLocked)
        % Call base class method
        loadObjectImpl@dsp.FarrowRateConverter(obj,s,wasLocked);
        if isfield(s,'AllowArbitraryInputLength')
            obj.AllowArbitraryInputLength = s.AllowArbitraryInputLength;
        else
            obj.AllowArbitraryInputLength = false;
        end
    end

    % Block Icon
    function icon = getIconImpl(~)
        icon = getString(message('dsp:system:FarrowRateConverter:BlockIcon'));
    end

    function varargout = getInputNamesImpl(~)
        varargout{1} = '';
    end

    function varargout = getOutputNamesImpl(~)
        varargout{1} = '';
    end

    function flag = supportsMultipleInstanceImpl(obj)
        % Foreach is allowed only for fixed size outputs (which requires
        % a fixed size input, and no arbitrary).
        flag = propagatedInputFixedSize(obj,1) && ~obj.AllowArbitraryInputLength;
    end

    function sts = getSampleTimeImpl(obj)
        % Object has states. Disallow const sample time
        sts = createSampleTime(obj, 'Type', 'Inherited', 'Disallow', 'Constant');
    end
end

methods (Static, Access=protected)
    function groups = getPropertyGroupsImpl
        %Get default parameters group for this System object
        propertyList = {
            matlab.system.display.internal.Property('InputSampleRate','Description','dsp:system:FarrowRateConverter:InputSampleRate_MP'), ...
            matlab.system.display.internal.Property('OutputSampleRate','Description','dsp:system:FarrowRateConverter:OutputSampleRate_MP'), ...
            matlab.system.display.internal.Property('OutputRateTolerance','Description','dsp:system:FarrowRateConverter:OutputRateTolerance_MP'), ...
            matlab.system.display.internal.Property('Specification','Description','dsp:system:FarrowRateConverter:Specification_MP'), ...
            matlab.system.display.internal.Property('PolynomialOrder','Description','dsp:system:FarrowRateConverter:PolynomialOrder_MP'), ...
            matlab.system.display.internal.Property('Coefficients','Description','dsp:system:FarrowRateConverter:Coefficients_MP'), ...
            matlab.system.display.internal.Property('AllowArbitraryInputLength','Description','dsp:blkprm_prompts:AllowArbitraryFixedInput_MP'), ...
            };

        parameterString = message('dsp:system:Shared:Parameters');
        
        mainS = matlab.system.display.Section(...
            Title = parameterString.getString, ...
            PropertyList = propertyList);

        % Visualize button
        filterVis = dsp.internal.FilterVisualizationButton;

        % Info button
        buttonString = message('dsp:system:Shared:Info');
        infoAction = matlab.system.display.Action(@dsp.simulink.FarrowRateConverter.onInfoActionCalled, ...
            Label = buttonString.getString, Placement = 'last', Alignment = 'right');
        matlab.system.display.internal.setCallbacks(infoAction, ...
            DialogAppliedFcn = @dsp.simulink.FarrowRateConverter.onDialogApplied, ...
            SystemDeletedFcn = @dsp.simulink.FarrowRateConverter.onSystemDeleted, ...
            PropertyResolveErrorFcn = @dsp.simulink.FarrowRateConverter.onUnresolvedProperty);

        mainS.Actions = [filterVis.fvtoolAction , infoAction];
        mainSG = matlab.system.display.SectionGroup(...
            Title = getString(message('dsp:system:Shared:Main')), ...
            Sections = mainS);

        % Data Types Group
        dtSG = matlab.system.display.internal.DataTypesGroup(...
            'dsp.simulink.FarrowRateConverter');

        % Replace automatically generated 'FractionalDelay' label with 'Fractional Delay'
        idx = find(strcmpi(dtSG.PropertyList,'FractionalDelayDataType'),1,'first');
        dtSG.PropertyList{idx} = ...
            matlab.system.display.internal.DataTypeProperty(...
            'FractionalDelayDataType', ...
            Prefix='FractionalDelay', ...
            Description='dsp:system:FarrowRateConverter:FractionalDelay_MP');

        groups = [mainSG, dtSG];
    end

    function header = getHeaderImpl
        % MATLAB System block header
        header = matlab.system.display.Header(...
            'dsp.simulink.FarrowRateConverter', ...
            ShowSourceLink = true, ...
            Title = 'dsp:system:FarrowRateConverter:BlockTitle',...
            Text = 'dsp:system:FarrowRateConverter:BlockDescription');
    end

    function onInfoActionCalled(actionData, sysObj)
        f = [];
        if isfield(actionData.UserData,'InfoHandle')
            f = actionData.UserData.InfoHandle;
        end
        if isempty(f) || ~ishandle(f)

            % strip off the Arithmetic line
            infoText = dsp.simulink.FarrowRateConverter.fixInfoText(info(sysObj));
            blockName = get_param(actionData.SystemHandle,'Name');
            infoHandle = dsp.util.msgbox(infoText,blockName);

            actionData.UserData.InfoHandle = infoHandle;

        else
            % Apply changes and bring the figure forward
            dsp.simulink.FarrowRateConverter.onDialogApplied(actionData, sysObj);
            figure(f);
        end
    end

    function onDialogApplied(actionData, sysObj)
        f = [];
        if isfield(actionData.UserData,'InfoHandle')
            f = actionData.UserData.InfoHandle;
        end
        if ~isempty(f) && ishandle(f)
            % strip off the Arithmetic line
            infoText = dsp.simulink.FarrowRateConverter.fixInfoText(info(sysObj));
            dsp.simulink.FarrowRateConverter.adjustInfoBoxText(f, infoText);
        end
    end

    function adjustInfoBoxText(f, infoText)
        pos0 = get(f,'Position');
        stringObject = findall(f,'Type','Text');
        extent0 = get(stringObject,'Extent');
        set(stringObject,'String',infoText);
        extent1 = get(stringObject,'Extent');
        set(f,'Position',[pos0(1:2) pos0(3:4) + (extent1(3:4) - extent0(3:4))]);
    end

    function onUnresolvedProperty(actionData, e, ~)
        f = [];
        if isfield(actionData.UserData,'InfoHandle')
            f = actionData.UserData.InfoHandle;
        end
        if ~isempty(f) && isvalid(f)
            % update existing plot to show nothing
            infoText = getString(message('dsp:system:Shared:infoButtonUnresolvedParameter', e.message));
            dsp.simulink.FarrowRateConverter.adjustInfoBoxText(f, infoText);
        end

        % Abort callback
        throw(e);
    end

    function infoOut = fixInfoText(infoIn)
        for index = 1:size(infoIn,1)
            ArithmeticStr = message('signal:dfilt:info:Arithmetic').getString;
            if contains(infoIn(index,:),ArithmeticStr)
                target = index;
                break
            end
        end
        infoOut = [infoIn(1:target-1,:) ; infoIn(target+1:end,:)] ;
    end

    function onSystemDeleted(actionData)
        f = [];
        % Close Info
        if isfield(actionData.UserData,'InfoHandle')
            f = actionData.UserData.InfoHandle;
        end
        if ~isempty(f) && ishandle(f)
            close(f);
        end
    end

end

methods(Hidden)
    function fpi = getCompiledFixedPointInfo(obj)
        % Make sure System object properties and type info available
        if ~obj.CoefficientsExist
            setFarrowSRCProperties(obj);
        end
        if isLocked(obj)
            % Get compiled (locked) data types for return struct
            dt1 = obj.pInputDatatype;
            if ischar(dt1) % string, e.g. 'double', 'int16', etc.
                protoTypeToUse = eval([dt1 '(0)']);
            else % numerictype
                protoTypeToUse = fi(0, dt1);
            end
            dataTypes = determineDataTypes(obj, protoTypeToUse);
            fpi = struct( ...
                'CoefficientsDataType',    numerictype(dataTypes.cofT), ...
                'FractionalDelayDataType', numerictype(dataTypes.frdT), ...
                'MultiplicandDataType',    numerictype(dataTypes.mcdT), ...
                'OutputDataType',          numerictype(dataTypes.outT));
        else
            % Set default return structure
            fpi = struct( ...
                'CoefficientsDataType',    numerictype('double'), ...
                'FractionalDelayDataType', numerictype('double'), ...
                'MultiplicandDataType',    numerictype('double'), ...
                'OutputDataType',          numerictype('double'));
        end
    end
end


methods (Static, Hidden)
    function a = getAlternateBlock
        a = [];
    end
end

end