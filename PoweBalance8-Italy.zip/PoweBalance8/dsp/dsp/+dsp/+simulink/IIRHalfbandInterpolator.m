classdef IIRHalfbandInterpolator < dsp.IIRHalfbandInterpolator
    % This class is used for the IIR Halfband Interpolator block in dspfdesign
    
    % Copyright 2017-2022 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCA>
    
    properties (Nontunable)
        %CoefficientsPort Specify coefficients from input port
        CoefficientsPort (1, 1) logical = false;
    end
    
    properties (Constant, Hidden)
        AllpassCoefficients1Set = matlab.system.SourceSet( ...
            dsp.simulink.internal.IIRHalfbandPolicy('SystemBlock', 'CoefficientsPort', 1, 'coeffs1'), ...
            {'Property','MATLAB','CoefficientsPort'})
        AllpassCoefficients2Set = matlab.system.SourceSet( ...
            dsp.simulink.internal.IIRHalfbandPolicy('SystemBlock', 'CoefficientsPort', 2, 'coeffs2'), ...
            {'Property','MATLAB','CoefficientsPort'})
    end
    %----------------------------------------------------------------------
    % Public Methods
    %----------------------------------------------------------------------
    methods
        function obj = IIRHalfbandInterpolator(varargin)
            obj@dsp.IIRHalfbandInterpolator(varargin{:});
        end
    end
    %----------------------------------------------------------------------
    % Protected Methods
    %----------------------------------------------------------------------
    methods (Access = protected)
        function validateInputsImpl(obj,varargin)
            validateInputsImpl@dsp.IIRHalfbandInterpolator(obj,varargin{:});
        end
        %------------------------------------------------------------------
        function val = getNumInputsImpl(obj)
            val = 1+obj.FilterBankInputPort;
        end
        %------------------------------------------------------------------
        function varargout = getInputNamesImpl(obj)
            % Name of input ports (shows on block icon)
            if ~obj.FilterBankInputPort && ~obj.CoefficientsPort
                varargout{1} =   '';
            elseif ~obj.FilterBankInputPort && obj.CoefficientsPort
                varargout{1} =   'x';
            else % power-complementary inputs
                varargout{1} =   'LP';
                varargout{2} =   'HP';
            end
        end
        %------------------------------------------------------------------
        function varargout = getOutputNamesImpl(~)
            % Name of output port (shows on block icon)
            varargout{1} =   '';
        end
        %------------------------------------------------------------------
        function icon = getIconImpl(obj)
            % MATLAB system block icon
            if ~obj.FilterBankInputPort
                icon = getString(message(...
                    'dsp:system:IIRHalfbandInterpolator:interpolatorIconString'));
            else % power-complementary outputs requested
                icon = getString(message(...
                    'dsp:system:IIRHalfbandInterpolator:synthesisIconString'));
            end
        end
        %------------------------------------------------------------------
        function val = supportsMultipleInstanceImpl(~)
            % Support in for-each subsystem
            val = true;
        end
        % PROPAGATOR METHODS: (used by Simulink)
        %------------------------------------------------------------------
        function varargout = getOutputSizeImpl(obj)
            varargout{1} = propagatedInputSize(obj,1);
            varargout{1}(1) = varargout{1}(1)*2;
        end
        %------------------------------------------------------------------
        function varargout = getOutputDataTypeImpl(obj)
            varargout{1} = propagatedInputDataType(obj,1);
        end
        %------------------------------------------------------------------
        function varargout = isOutputComplexImpl(obj)
            varargout{1} = propagatedInputComplexity(obj,1);
        end
        %------------------------------------------------------------------
        function varargout = isOutputFixedSizeImpl(obj)
            varargout{1} = propagatedInputFixedSize(obj,1);
        end
        function flag = isInactivePropertyImpl(obj, prop)            
            switch prop
                case {'NormalizedFrequency'}
                    flag = true;
                otherwise
                    flag = isInactivePropertyImpl@dsp.internal.IIRHalfbandBase(obj,prop);
            end
        end
        function validatePropertiesImpl(obj)
            if ~isSampleRateInherited(obj)
                crossValidateProperties(obj);
            end            
        end
    end
    %----------------------------------------------------------------------
    % Static hidden methods
    %----------------------------------------------------------------------
    methods(Static,Hidden)
        function props = getDisplayPropertiesImpl()
            props = { ...
                matlab.system.display.internal.Property('Specification','Description','dsp:system:IIRHalfbandInterpolator:Specification_MP'), ...
                matlab.system.display.internal.Property('FilterOrder','Description','dsp:system:IIRHalfbandInterpolator:FilterOrder_MP'), ...
                matlab.system.display.internal.Property('TransitionWidth','Description','dsp:system:IIRHalfbandInterpolator:TransitionWidth_MP'), ...
                matlab.system.display.internal.Property('StopbandAttenuation','Description','dsp:system:IIRHalfbandInterpolator:StopbandAttenuation_MP'), ...
                matlab.system.display.internal.Property('DesignMethod','Description','dsp:system:IIRHalfbandInterpolator:DesignMethod_MP'), ...
                matlab.system.display.internal.Property('FilterBankInputPort','Description','dsp:system:IIRHalfbandInterpolator:FilterBankInputPort_MP'), ...
                matlab.system.display.internal.Property('SampleRateMode','Description','dsp:system:AbstractSampleRateEngine:SampleRateMode_MP'), ...
                matlab.system.display.internal.Property('SampleRate','Description','dsp:system:AbstractSampleRateEngine:SampleRate_MP'), ...
                matlab.system.display.internal.Property('Structure','Description','dsp:system:IIRHalfbandInterpolator:Structure_MP'), ...
                matlab.system.display.internal.Property('HasPureDelayBranch','Description','dsp:system:IIRHalfbandInterpolator:HasPureDelayBranch_MP'), ...
                matlab.system.display.internal.Property('Delay','Description','dsp:system:IIRHalfbandInterpolator:Delay_MP'), ...
                matlab.system.display.internal.Property('CoefficientsPort','Description','dsp:system:IIRHalfbandInterpolator:CoefficientsPort_MP'), ...
                matlab.system.display.internal.Property('AllpassCoefficients1','Description','dsp:system:IIRHalfbandInterpolator:AllpassCoefficients1_MP'), ...
                matlab.system.display.internal.Property('AllpassCoefficients2','Description','dsp:system:IIRHalfbandInterpolator:AllpassCoefficients2_MP'), ...
                matlab.system.display.internal.Property('WDFCoefficients1','Description','dsp:system:IIRHalfbandInterpolator:WDFCoefficients1_MP'), ...
                matlab.system.display.internal.Property('WDFCoefficients2','Description','dsp:system:IIRHalfbandInterpolator:WDFCoefficients2_MP'), ...
                matlab.system.display.internal.Property('HasTrailingFirstOrderSection','Description','dsp:system:IIRHalfbandInterpolator:HasTrailingFirstOrderSection_MP')};
        end
    end
    %----------------------------------------------------------------------
    % Static protected methods
    %----------------------------------------------------------------------
    methods(Static,Access=protected)
        function mainS = getPropertyGroupsImpl
            props = dsp.simulink.IIRHalfbandInterpolator.getDisplayPropertiesImpl;
            mainS = matlab.system.display.Section(...
                'Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', props);
            
            filterVis = dsp.internal.FilterVisualizationButton;
            mainS.Actions = filterVis.fvtoolAction;
        end
        
        %------------------------------------------------------------------
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.IIRHalfbandInterpolator', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:system:IIRHalfbandInterpolator:titleString',...
                'Text',  'dsp:system:IIRHalfbandInterpolator:descriptionString');
        end
    end
    %----------------------------------------------------------------------
    % Hidden methods
    %----------------------------------------------------------------------
    methods (Hidden) 
        function f = updateFvtoolFigure(obj,f)
            % Used to update fvtool plot when object is used in Simulink
            setfilter(f, obj);
            if isSampleRateNormalized(obj) || strcmp(obj.Specification, 'Coefficients') 
                f.NormalizedFrequency = 'on';
            else
                f.NormalizedFrequency = 'off';
            end

        end
    end
end
