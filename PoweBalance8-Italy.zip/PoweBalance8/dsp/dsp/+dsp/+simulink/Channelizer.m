classdef (StrictDefaults)Channelizer < dsp.Channelizer
    %Channelizer Polyphase FFT analysis filter bank.
    % This class is used in the Channelizer block

    % Copyright 2016-2022 The MathWorks, Inc.

    %#codegen
    %#ok<*EMCA>

    properties (Nontunable)
        % CoefficientsPort Specify coefficients from input port
        CoefficientsPort (1, 1) logical = false;
    end

    properties (Constant, Hidden)
        LowpassCoefficientsSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.ChannelizerPolicy('SystemBlock', 'CoefficientsPort', 1, 'coeffs'), ...
            {'Property','MATLAB','CoefficientsPort'})
    end

    %----------------------------------------------------------------------
    % Protected methods
    %----------------------------------------------------------------------
    methods (Access = protected)
        %------------------------------------------------------------------
        function setupImpl(obj, u)

            sts = getSampleTime(obj);
            % Never allow continuous time
            coder.internal.errorIf(sts.SampleTime==0,...
                'dsp:system:Shared:ContinuousTimeNotAllowed');

            setupImpl@dsp.Channelizer(obj,u);
        end
        %------------------------------------------------------------------
        function validateInputsImpl(obj,varargin)
            validateInputsImpl@dsp.Channelizer(obj,varargin{1});
        end
        % Propagators
        %------------------------------------------------------------------
        function cp = isOutputComplexImpl(~)
            cp = true;
        end
        %------------------------------------------------------------------
        function sz = getOutputSizeImpl(obj)
            % If M is the number of frequency bands and x is a Lx1 matrix,
            % y will have dimensions L/MxM. If x has more than one channel,
            % i.e. x is LxN, y will be 3 dimensional with dimensions
            % L/MxMxN.
            in_sz = propagatedInputSize(obj, 1);

            M = double(obj.NumFrequencyBands);
            D = double(obj.DecimationFactor);
            fixedInput = propagatedInputFixedSize(obj, 1);
            coder.internal.errorIf(~obj.AllowArbitraryInputLength && rem(in_sz(1),D)~=0 && fixedInput, ...
                'dsp:system:Channelizer:frameSizeBlk',in_sz(1),D);

            if (in_sz(2) == 1)
                sz = [ceil(in_sz(1) / D) , M];
            else
                sz = [ceil(in_sz(1) / D), M, in_sz(2)];
            end
        end
        %------------------------------------------------------------------
        function ol = getOutputFrameSize(obj, Lx)
            if ~obj.AllowArbitraryInputLength
                D = coder.const(obj.DecimationFactor);
                ol = int32(ceil(Lx/D));
            else
                ol = getOutputFrameSize@dsp.Channelizer(obj, Lx);
            end
        end
        %------------------------------------------------------------------
        function isfixed = isOutputFixedSizeImpl(obj)
            % Output is fixed only when AllowArbitraryInputLength is false, 
            % otherwise the output frame size varies.
            fixedInput = propagatedInputFixedSize(obj,1);
            isfixed = ~obj.AllowArbitraryInputLength && fixedInput;
        end
        %------------------------------------------------------------------
        function inputDT = getOutputDataTypeImpl(obj)
            inputDT = propagatedInputDataType(obj,1);
        end
        %------------------------------------------------------------------
        function name = getInputNamesImpl(obj)
            % Input port name to show on the block
            if  strcmp(obj.Specification,'Coefficients') && obj.CoefficientsPort
                name = 'x';
            else
                name = '';
            end
        end
        %------------------------------------------------------------------
        function name = getOutputNamesImpl(~)
            % Ouput port name to show on the block
            name = '';
        end
        %------------------------------------------------------------------
        function icon = getIconImpl(~)
            % Block Icon
            icon = getString(message('dsp:system:Channelizer:BlockIcon'));
        end
        %------------------------------------------------------------------
        function val = supportsMultipleInstanceImpl(obj,~)
            % For "For Each" support of the MATLAB System block
            val = ~obj.AllowArbitraryInputLength & propagatedInputFixedSize(obj,1);
        end
        %------------------------------------------------------------------
        function sts = getSampleTimeImpl(obj)
            sts = createSampleTime(obj, 'Type', 'Inherited', ...
                'Disallow', 'Constant');
        end
        %------------------------------------------------------------------
        function nc = getNumChannels(obj,~)
            sz = propagatedInputSize(obj,1);
            nc = sz(2);
        end
    end
    %----------------------------------------------------------------------
    % Static Protected methods
    %----------------------------------------------------------------------
    methods(Static,Access=protected)
        %------------------------------------------------------------------
        function groups = getPropertyGroupsImpl
            props = {...
                matlab.system.display.internal.Property('NumFrequencyBands','Description','dsp:system:Channelizer:NumFrequencyBands_MP'), ...
                matlab.system.display.internal.Property('Specification','Description','dsp:system:Channelizer:Specification_MP'), ...
                matlab.system.display.internal.Property('DecimationFactor','Description','dsp:system:Channelizer:DecimationFactor_MP'), ...
                matlab.system.display.internal.Property('CoefficientsPort','Description','dsp:system:Channelizer:CoefficientsPort_MP'), ...
                matlab.system.display.internal.Property('NumTapsPerBand','Description','dsp:system:Channelizer:NumTapsPerBand_MP'), ...
                matlab.system.display.internal.Property('StopbandAttenuation','Description','dsp:system:Channelizer:StopbandAttenuation_MP'), ...
                matlab.system.display.internal.Property('LowpassCoefficients','Description','dsp:system:Channelizer:LowpassCoefficients_MP'), ...
                matlab.system.display.internal.Property('AllowArbitraryInputLength','Description','dsp:blkprm_prompts:AllowArbitraryFixedInput_MP')};

            parameterString = message('dsp:system:Shared:Parameters');
            groups = matlab.system.display.Section('Title', ...
                parameterString.getString, ...
                'PropertyList',props, ...
                'DependOnPrivatePropertyList',{'DecimationFactor'});
        end
        %------------------------------------------------------------------
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.Channelizer', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:system:Channelizer:BlockName',...
                'Text', 'dsp:system:Channelizer:BlockHeader');
        end
    end
end
