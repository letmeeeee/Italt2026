classdef FourthOrderSectionFilter < matlab.System &...
        dsp.internal.FourthOrderSectionFilterAnalysis & ...
        dsp.simulink.mixin.FilterResponseVisualizable
    % This class is used in the Fourth-order filter section block
    
    % Copyright 2021-2022 The MathWorks, Inc.
    %#codegen
    properties(Nontunable)
        %CoefficientSource Coefficient Source
        CoefficientSource = 'Dialog parameters';
        %FilterObject Filter Object
        FilterObject {mustBeTextScalar} = 'dsp.FourthOrderSectionFilter';
    end
    properties 
        % Numerator - Numerator coefficients 
        Numerator =  [0.07795634 0 -0.15591268 0 0.07795634; 0.06188520 0 -0.12377039 0 0.06188520]
        % Denominator - Denominator coefficients 
        Denominator =  [1 0 1.32091343 0 0.63273879; 1 0 1.04859957 0 0.29614035];

    end
    properties (Constant, Hidden)
        CoefficientSourceSet = matlab.system.StringSet({'Dialog parameters','Input ports','Filter object'});
    end
    properties (Access = protected, Nontunable, PositiveInteger)
        %MaxSections Maximum number of fourth-order sections
        MaxSections = 10;
    end
    properties (Access = protected)
        privFilter
    end
    properties (Access = protected, Nontunable)
        IsCoefficientsFromPort (1, 1) logical = false
    end
    methods
        function obj = FourthOrderSectionFilter(varargin)
                setProperties(obj,nargin,varargin{:})
        end
        function set.Numerator(obj,val)
            validateattributes(val,{'numeric'},{'finite','nonnan','2d',...
                'ncols',5},'set.Numerator','Numerator');
            obj.Numerator = val;
        end
        function set.Denominator(obj,val)
            validateattributes(val,{'numeric'},{'finite','nonnan','2d',...
                },'set.Denominator','Denominator');
            % The Denominator property can be of size Lx4 or Lx5. Depending
            % on the size, append one(s) accordingly
            if size(val,2) == 4
                den = cast([ones(size(val,1),1) val(:,1:4)],'like',val);
            elseif size(val,2) == 5
                den = cast([ones(size(val,1),1) val(:,2:5)],'like',val);
            else
                % Denominator should be atleast of size Lx4.
                coder.internal.error('dsp:system:FourthOrderSectionFilter:incorrectNumCols',size(val,2));
            end            
            obj.Denominator = den; 
        end

    end
    %----------------------------------------------------------------------
    methods(Static,Access=protected)
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.FourthOrderSectionFilter', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:system:FourthOrderSectionFilter:titleString',...
                'Text',  'dsp:system:FourthOrderSectionFilter:descriptionString');
        end
        function mainS = getPropertyGroupsImpl
            props = {...
                matlab.system.display.internal.Property('CoefficientSource','Description','dsp:system:FourthOrderSectionFilter:CoefficientSource_MP'), ...
                matlab.system.display.internal.Property('Numerator','Description','dsp:system:FourthOrderSectionFilter:Numerator_MP'),...
                matlab.system.display.internal.Property('Denominator','Description','dsp:system:FourthOrderSectionFilter:Denominator_MP'),...
                matlab.system.display.internal.Property('FilterObject','Description','dsp:system:FourthOrderSectionFilter:FilterObject_MP')};

            parameterString = message('dsp:system:Shared:Parameters');
            mainS = matlab.system.display.Section('Title', ...
                parameterString.getString, ...
                'PropertyList',props);
            filterVis = dsp.simulink.internal.FilterResponseVisualizationButton;
            mainS.Actions = filterVis.visualizeAction;
        end
    end        
    %----------------------------------------------------------------------
    methods (Access=protected)
        function setupImpl(obj, u, varargin)
            coder.extrinsic('slResolve');
            obj.privFilter = dsp.internal.FourthOrderSectionFiltercgHelper;
            if obj.getExecPlatformIndex()
                thisSize = propagatedInputSize(obj, 1);
                numchans = thisSize(2);
            else
                numchans = size(u,2);
            end
            % Set number of input channels in internal filter for state
            % initialization
            setNumChans(obj.privFilter,numchans );
            
            if strcmp(obj.CoefficientSource,'Dialog parameters')
                obj.privFilter.Numerator =  obj.Numerator;
                obj.privFilter.Denominator = obj.Denominator;
            elseif strcmp(obj.CoefficientSource,'Input ports')
                obj.IsCoefficientsFromPort = true;
                numSize = propagatedInputSize(obj, 2);
                obj.MaxSections = numSize(1);                
                obj.privFilter.Numerator = cast([ones(obj.MaxSections,1) zeros(obj.MaxSections,4)],'like',varargin{1});
                if size(varargin{2},2) == 5
                    obj.privFilter.Denominator = cast([ones(obj.MaxSections,1) zeros(obj.MaxSections,4)],'like',varargin{2});
                else
                    obj.privFilter.Denominator = cast(zeros(obj.MaxSections,4),'like',varargin{2});
                end
            else

                num = coder.const(@get,slResolve(obj.FilterObject,bdroot),'Numerator');
                den = coder.const(@get,slResolve(obj.FilterObject,bdroot),'Denominator');
               
                obj.privFilter.Numerator = num;
                obj.privFilter.Denominator = den;

                % If setup is called during codegen simulation, re-evaluate
                % the filter object in workspace to get the updated value.
                if coder.target('Sfun')
                    % Following lines are required for initialization to
                    % prevent the error 'Cannot pass a mxArray to
                    % 'dsp.internal.FourthOrderSectionFiltercgHelper.set.Numerator'.
                    numUpdated = obj.privFilter.Numerator; %#ok<*NASGU> 
                    denUpdated = obj.privFilter.Denominator;

                    % Get Numerator and Denominator properties of the
                    % object from workspace without const folding
                    numUpdated = get(slResolve(obj.FilterObject,bdroot),'Numerator');
                    denUpdated = get(slResolve(obj.FilterObject,bdroot),'Denominator');

                    obj.privFilter.Numerator = numUpdated;
                    obj.privFilter.Denominator = denUpdated;
                end
            end
        end
        function y = stepImpl (obj, x ,varargin)            
            if  obj.IsCoefficientsFromPort
                NumUnusedSections = obj.MaxSections - size(varargin{1},1);
                NumeratorAppend = cast([ones(NumUnusedSections,1) zeros(NumUnusedSections,4)],'like',varargin{1});
                den5Cols = size(varargin{2},2) == 5;
                if den5Cols
                    DenominatorAppend = cast([ones(NumUnusedSections,1) zeros(NumUnusedSections,4)],'like',varargin{2});
                else
                    DenominatorAppend = cast(zeros(NumUnusedSections,4),'like',varargin{2});
                end

                obj.privFilter.Numerator(1:obj.MaxSections,:) = cast([varargin{1};NumeratorAppend],'like',varargin{1});
                obj.privFilter.Denominator(1:obj.MaxSections ,2-den5Cols:end) = [varargin{2};DenominatorAppend];
            end
            y = obj.privFilter(x);
        end
        function validatePropertiesImpl(obj)
            % Filter object needs to be validated in this method. If not,
            % non-meaningful error will be thrown form isOutputComplexImpl
            % in case the filter object is invalid
            coder.extrinsic('slResolve');
            coder.extrinsic('get_param');
            if strcmp(obj.CoefficientSource,'Filter object')
                % Check if the provided variable exists in workspace
                [~,isExists] = coder.const(@slResolve,obj.FilterObject,bdroot);   
                % Allow filter object to be set to unknown variable when
                % simulation is stopped.
                variableUnknown = ~strcmpi(get_param(bdroot, 'SimulationStatus'),'stopped') &&...
                    ~isExists;
                coder.internal.errorIf(variableUnknown,...
                    'dsp:system:FourthOrderSectionFilter:unknownFOSObject',obj.FilterObject);
                if isExists
                    % Check if the variable is a valid object of type
                    % dsp.FourthOrderSectionFilter
                    baseObjClass = coder.const(@class,slResolve(obj.FilterObject,bdroot));
                    coder.internal.errorIf(...
                        ~isequal((baseObjClass),'dsp.FourthOrderSectionFilter'),...
                        'dsp:system:FourthOrderSectionFilter:incorrectFOSObject');
                end
            end
        end
        function processTunedPropertiesImpl(obj)
            if strcmp(obj.CoefficientSource,'Dialog parameters')
                propChange = isChangedProperty(obj,'Numerator') ||...
                    isChangedProperty(obj,'Denominator');
                if propChange
                    obj.privFilter.Numerator = obj.Numerator;
                    obj.privFilter.Denominator = obj.Denominator;
                end
            end
        end
        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end
        function validateInputsImpl(obj,varargin)
            if  strcmp(obj.CoefficientSource,'Input ports') 

                % Numerator should have 5 columns.
                validateattributes(varargin{2},{'numeric'},{'finite','nonnan','2d',...
                'ncols',5},'FourthOrderSectionFilter','Numerator');

                validateattributes(varargin{3},{'numeric'},{'finite','nonnan','2d',...
                },'FourthOrderSectionFilter','Denominator');

                % Denominator should have 4 or 5 columns.
                coder.internal.errorIf(size(varargin{3},2)~=4 && size(varargin{3},2)~=5,...
                    'dsp:system:FourthOrderSectionFilter:incorrectNumCols',size(varargin{3},2));

                nSections = size(varargin{2},1);               

                % Validate if Denominator has the same number of rows as
                % Numerator.
                validateattributes(varargin{3},{'numeric'},{'nrows',nSections...
                    },'FourthOrderSectionFilter','Denominator');

            end
        end
        function flag = isInactivePropertyImpl(obj,prop)
            switch prop
                case {'Numerator','Denominator'}
                    flag = ~strcmp(obj.CoefficientSource,'Dialog parameters') ;
                case {'FilterObject'}
                    flag = ~strcmp(obj.CoefficientSource,'Filter object') ;
                otherwise
                    flag = false;
            end
        end
        function num = getNumInputsImpl(obj)
            if  strcmp(obj.CoefficientSource,'Input ports') 
                num = 3;
            else
                num = 1;
            end

        end
        % Block Icon
        function icon = getIconImpl(~)
            icon = getString(message('dsp:system:FourthOrderSectionFilter:blockString'));
        end
        function varargout = getInputNamesImpl(obj)
            % Name of input port (shows on block icon)
            % Input port name to show on the block
            if  strcmp(obj.CoefficientSource,'Input ports')
                varargout{1} = 'x';
                varargout{2} = 'Num';
                varargout{3} = 'Den';
            else
                varargout{1} = '';
            end
        end
        
        function name = getOutputNamesImpl(obj)
            if  strcmp(obj.CoefficientSource,'Input ports')
                name = 'y';
            else
                name = '';
            end
        end
        % Propagators
       
        function sz = getOutputSizeImpl(obj)
            sz= propagatedInputSize(obj, 1);
        end
        
        function isfixed = isOutputFixedSizeImpl(obj)
            isfixed = propagatedInputFixedSize(obj,1);
        end
        function dt_out = getOutputDataTypeImpl(obj)
            dt_out = propagatedInputDataType(obj,1);
        end
        function val = supportsMultipleInstanceImpl(~)
            % For "For Each" support of the MATLAB System block
            val = true;
        end
        function cp = isOutputComplexImpl(obj)
            coder.extrinsic('slResolve');
            cp = propagatedInputComplexity(obj,1);
            if (~isempty(cp))
                if  strcmp(obj.CoefficientSource,'Input ports')
                    cp = cp || propagatedInputComplexity(obj,2) || propagatedInputComplexity(obj,3);
                elseif  strcmp(obj.CoefficientSource,'Dialog parameters')
                    cp = cp || ~isreal(obj.Numerator) || ~isreal(obj.Denominator);
                else
                    num = coder.const(@get,slResolve(obj.FilterObject,bdroot),'Numerator');
                    den = coder.const(@get,slResolve(obj.FilterObject,bdroot),'Denominator');
                    cp = cp || ~isreal(num) || ~isreal(den);
                end
            end
        end  
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@matlab.System(obj);
            if isLocked(obj)
                s.privFilter      = matlab.System.saveObject(obj.privFilter);
                s.MaxSections     = obj.MaxSections;
                s.IsCoefficientsFromPort = obj.IsCoefficientsFromPort;
            end
        end
        function loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                obj.privFilter      = matlab.System.loadObject(s.privFilter);
                obj.MaxSections     = s.MaxSections;
                obj.IsCoefficientsFromPort = s.IsCoefficientsFromPort;
            end
            loadObjectImpl@matlab.System(obj, s);
        end
        function resetImpl(obj)
            reset(obj.privFilter);
        end
    end
    %----------------------------------------------------------------------
    methods (Hidden)
        function [flag,errID] = isFVtoolSupported(obj)
            flag = true;
            errID = '';
            if isprop(obj, 'CoefficientSource')
               if  strcmp(obj.CoefficientSource,'Input ports')
                  flag = false;
                  errID = 'dsp:system:FourthOrderSectionFilter:fvtoolCoefficientsPort';
               end
            end
        end
        %------------------------------------------------------------------
        function filters = getVisualizationFilters(obj)
            % Used to return filters that will be shown when the visualize
            % filter response button is clicked.
            if ~isLocked(obj) && strcmpi(obj.CoefficientSource,'Filter object') 
                filters = slResolve(obj.FilterObject,bdroot);
            else
                filters = obj;
            end
        end
    end
end

