classdef VariableFIRInterpolator < dsp.internal.VariableFIRInterpolator
%VARIABLEFIRINTERPOLATOR Variable FIR Interpolator
% This class is used in the Variable FIR Interpolator block to support
    % tunable interpolation factor

%   Copyright 2022-2023 The MathWorks, Inc.

%#codegen

    properties (Nontunable)
        % CoefficientsPort Specify coefficients from input port
        CoefficientsPort (1, 1) logical = false;
        InterpolationFactorPort (1, 1) logical = true;
    end
    
    properties (Constant, Hidden)
        InterpolationFactorSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.VariableRateConversionPolicy('SystemBlock', 'InterpolationFactorPort', 1, 'L'), ...
            {'Property','MATLAB','InterpolationFactorPort'})
        CoefficientsSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.VariableRateConversionPolicy('SystemBlock', 'CoefficientsPort', 2, 'coeffs'), ...
            {'Property','MATLAB','CoefficientsPort'})
    end
   
    methods (Access = protected)
        %------------------------------------------------------------------
        function setupImpl(obj, u)
            sts = getSampleTime(obj);
            % Never allow continuous time
            coder.internal.errorIf(sts.SampleTime==0,...
                'dsp:system:Shared:ContinuousTimeNotAllowed');
            setupImpl@dsp.internal.VariableFIRInterpolator(obj,u);
        end
        %------------------------------------------------------------------
        function validatePropertiesImpl(obj)
            if strcmpi(obj.Specification, 'Interpolation factor') && ~obj.InterpolationFactorPort
                validateattributes(obj.InterpolationFactor,{'numeric'},{'scalar','integer','finite','<=',obj.MaxInterpolationFactor},'','InterpolationFactor');
            end
        end
        %------------------------------------------------------------------
        function l = getOutputSizeImpl(obj)
            % Return size for each output port
            insize = propagatedInputSize(obj,1);
            if strcmpi(obj.Specification,'Interpolation factor')
                l = [insize(1)*obj.MaxInterpolationFactor insize(2)];
            else
                l = [obj.OutputFrameLength insize(2)];
            end
        end
        %------------------------------------------------------------------
        function flag = isOutputFixedSizeImpl(obj)
            if strcmpi(obj.Specification,'Interpolation factor')
                flag = false; % Signal output is varsize
            else
                flag = true;
            end
        end
        %------------------------------------------------------------------
        function flag = isOutputComplexImpl(obj)
            switch obj.CoefficientSource
                case 'Auto'
                    flag = propagatedInputComplexity(obj, 1) || ~isreal(polyphase(obj));
                case 'Dialog parameter'
                    flag = propagatedInputComplexity(obj, 1) || ~isreal(obj.Coefficients);
                case 'Input port'
                    if obj.InterpolationFactorPort && strcmpi(obj.Specification, 'Interpolation factor')
                        flag = propagatedInputComplexity(obj, 1) || propagatedInputComplexity(obj, 3);
                    else
                        flag = propagatedInputComplexity(obj, 1) || propagatedInputComplexity(obj, 2);
                    end
            end
        end
        %------------------------------------------------------------------
        function flag = getOutputDataTypeImpl(obj)
            flag = propagatedInputDataType(obj, 1);
        end
        %------------------------------------------------------------------
        function flag = supportsMultipleInstanceImpl(~)
            flag = true;
        end
        %------------------------------------------------------------------
        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end
        %------------------------------------------------------------------
        function flag = isInputComplexityMutableImpl(~,~)
            % Return false if input complexity cannot change
            % between calls to the System object
            flag = false;
        end
        %------------------------------------------------------------------
        function flag = isInputDataTypeMutableImpl(~,~)
            % Return false if input data type cannot change
            % between calls to the System object
            flag = false;
        end
        %------------------------------------------------------------------
        function icon = getIconImpl(~)
            % Block Icon
            icon = getString(message('dsp:system:VariableFIRInterpolator:BlockIcon'));
        end
        %------------------------------------------------------------------
        function [L,N] = getInputDataSize(obj,~)
            sz = propagatedInputSize(obj, 1);
            L = sz(1);
            N = sz(2);
        end
    end
    methods(Hidden)
        function filters = getVisualizationFilters(obj)
            % Used to return filters that will be shown when the visualize
            % filter response button is clicked.
            if strcmp(obj.CoefficientSource, 'Auto')
                b = obj.polyphase2coeffs;
            else
                b = obj.Coefficients;
            end
            Lm = obj.MaxInterpolationFactor;
            filters = dsp.FIRInterpolator(InterpolationFactor = Lm, Numerator=b);
        end

        function legend = getVisualizationLegend(~,blkName)
            % Used to return the legend that will be shown when the
            % visualize filter response plot is shown
            legend = {blkName};
        end

        function [flag,id] = isFVtoolSupported(obj)
            flag = true;
            id = '';
            isOutFrameLengthSpec = strcmpi(obj.Specification, 'Output frame length');
            isCoefSourceInputPort = strcmpi(obj.CoefficientSource, 'Input port');
            if isOutFrameLengthSpec
                flag = false;
                id = 'dsp:system:VariableFIRDecimator:fvtoolButtonOutputFrameLengthText';
            elseif isCoefSourceInputPort
                flag = false;
                id   = 'dsp:system:VariableFIRDecimator:fvtoolButtonCoeffsPortText';
            end
        end
    end
    methods(Static, Access=protected)
        %------------------------------------------------------------------
        function groups = getPropertyGroupsImpl
            props = {...
                matlab.system.display.internal.Property('Specification','Description','dsp:system:VariableFIRInterpolator:Specification_MP'), ...
                matlab.system.display.internal.Property('OutputFrameLength','Description','dsp:system:VariableFIRInterpolator:OutputFrameLength_MP'), ...
                matlab.system.display.internal.Property('MaxInterpolationFactor','Description','dsp:system:VariableFIRInterpolator:MaxInterpolationFactor_MP'), ...
                matlab.system.display.internal.Property('InterpolationFactorPort','Description','dsp:system:VariableFIRInterpolator:InterpolationFactorPort_MP'), ...
                matlab.system.display.internal.Property('InterpolationFactor','Description','dsp:system:VariableFIRInterpolator:InterpolationFactor_MP'), ...
                matlab.system.display.internal.Property('CoefficientSource','Description','dsp:system:VariableFIRInterpolator:CoefficientSource_MP'), ...
                matlab.system.display.internal.Property('Coefficients','Description','dsp:system:VariableFIRInterpolator:Coefficients_MP')};
            parameterString = message('dsp:system:Shared:Parameters');
            groups = matlab.system.display.Section('Title', ...
                parameterString.getString, ...
                'PropertyList',props);
            filterVis = dsp.simulink.internal.FilterResponseVisualizationButton;
            groups.Actions = filterVis.visualizeAction;
        end
        %------------------------------------------------------------------
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.VariableFIRInterpolator', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:system:VariableFIRInterpolator:BlockName',...
                'Text', 'dsp:system:VariableFIRInterpolator:BlockHeader');
        end
    end
end
