classdef (StrictDefaults)FrequencyDomainFIRFilter < dsp.FrequencyDomainFIRFilter & ...
        dsp.simulink.mixin.FilterResponseVisualizable
    % Used in frequency-domain FIR filter block

    % Copyright 2017-2023 The MathWorks, Inc.

    %#codegen

    properties (Nontunable)
        % OutputFilterLatency Output filter latency
        OutputFilterLatency (1, 1) logical = false;
        % SpecifyNumeratorFromPort Specify coefficients from input port
        SpecifyNumeratorFromPort (1, 1) logical = false;
        % SpecifyFrequencyResponseFromPort Specify frequency response from input port
        SpecifyFrequencyResponseFromPort (1, 1) logical = false;
    end

    properties (Constant, Hidden)
        NumeratorSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.FrequencyDomainFilterPolicy('SystemBlock', 'SpecifyNumeratorFromPort', 1, 'NUM'), ...
            {'Property','MATLAB','SpecifyNumeratorFromPort'})

        FrequencyResponseSet =  matlab.system.SourceSet( ...
            dsp.simulink.internal.FrequencyDomainFilterPolicy('SystemBlock', 'SpecifyFrequencyResponseFromPort', 2, 'NUMFFT'), ...
            {'Property','MATLAB','SpecifyFrequencyResponseFromPort'})
    end

    properties (Nontunable)
        % InheritFFTLength Inherit FFT length from numerator length
        InheritFFTLength (1, 1) logical = true;
    end

    properties (Nontunable, Access = private)
        % pLatency Cache latency
        pLatency;
    end

    methods
        function obj = FrequencyDomainFIRFilter(varargin)
            setProperties(obj, nargin, varargin{:});
        end
    end

    methods (Access = protected)

        function flag = isFromPort(obj)
            flag = (strcmp(obj.NumeratorDomain,'Time') && obj.SpecifyNumeratorFromPort) || ...
                (strcmp(obj.NumeratorDomain,'Frequency') && obj.SpecifyFrequencyResponseFromPort);
        end

        function validateNumerator(obj, value)
            % Multiple Filters can not be specified in Simulink
            validateattributes(value, ...
                {'numeric'}, {'finite', 'nonempty', 'row'}, '', 'Numerator');
        end

        function validateFreqResponse(obj)
            if strcmp(obj.NumeratorDomain,'Frequency')
                % Multiple Filters can not be specified in Simulink
                coder.internal.errorIf(~obj.PartitionForReducedLatency && (size(obj.FrequencyResponse,1) > 1),...
                    'dsp:system:FrequencyDomainFIRFilter:FrequencyResponseSizeNoPartition')
            end
        end

        function validatePropertiesImpl(obj)
            if ~isFromPort(obj)
                validateFreqResponse(obj);
                validatePropertiesImpl@dsp.FrequencyDomainFIRFilter(obj);
            end
        end

        function s = saveObjectImpl(obj)
            s = saveObjectImpl@dsp.FrequencyDomainFIRFilter(obj);
            if isLocked(obj)
                s.pLatency  = obj.pLatency;
            end
        end

        function s = loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                obj.pLatency  = s.pLatency;
            end
            loadObjectImpl@dsp.FrequencyDomainFIRFilter(obj, s, wasLocked);
        end

        function lat = getLatency(obj)
            if strcmp(obj.NumeratorDomain,'Time')
                if obj.PartitionForReducedLatency
                    l = obj.PartitionLength;
                else
                    fftlen = obj.pFilter.FFTLength;
                    l = fftlen - size(obj.pFilter.Numerator, 2) + 1;
                end
            else
                if isPartitioned(obj)
                    l = size(obj.pFilter.Numerator, 1) / 2;
                else
                    fftlen = size(obj.pFilter.Numerator, 2);
                    l      = fftlen - obj.NumeratorLength + 1;
                end
            end
            lat = uint32(l);
        end

        function setupImpl(obj,u)

            ts = getSampleTime(obj);
            coder.internal.errorIf(ts.SampleTime==0,...
                'dsp:system:Shared:ContinuousTimeNotAllowed');

            if isFromPort(obj)
                validateFreqResponse(obj);
                validateProps(obj);
            end

            setupImpl@dsp.FrequencyDomainFIRFilter(obj,u);

            obj.pLatency = getLatency(obj);

        end 
        
        function flag = isInactivePropertyImpl(obj, prop)
            switch prop
                case 'SpecifyNumeratorFromPort'
                    flag = ~strcmp(obj.NumeratorDomain,'Time');
                case 'SpecifyFrequencyResponseFromPort'
                    flag = strcmp(obj.NumeratorDomain,'Time');
                case 'FrequencyResponse'
                    flag = strcmp(obj.NumeratorDomain,'Time') || ~obj.SpecifyFrequencyResponseFromPort;
                case 'Numerator'
                    flag = ~strcmp(obj.NumeratorDomain,'Time') || ~obj.SpecifyNumeratorFromPort;
                case 'FFTLength'
                    flag = strcmp(obj.NumeratorDomain,'Frequency')  || obj.PartitionForReducedLatency || obj.InheritFFTLength;
                case 'InheritFFTLength'
                    flag = strcmp(obj.NumeratorDomain,'Frequency') || obj.PartitionForReducedLatency;
                otherwise
                    flag = isInactivePropertyImpl@dsp.FrequencyDomainFIRFilter(obj,prop);
            end
        end

        function numchans = getNumChannels(obj,~)
            % GETNUMCHANNELS Return the number of input channels
            thisSize = propagatedInputSize(obj, 1);
            numchans = thisSize(2);
        end

        function n = getNumOutputsImpl(obj)
            n =  1 + double(obj.OutputFilterLatency);
        end

        function dt = getTunablePropertiesSpecificationImpl(obj,~)
            dt = propagatedInputDataType(obj,1);
        end

        function varargout = stepImpl(obj, u)

            varargout{1} = stepImpl@dsp.FrequencyDomainFIRFilter(obj,u);
            if obj.OutputFilterLatency
                varargout{2} = obj.pLatency;
            end
        end

        function validateInputsImpl(obj,u,varargin)
            validateInputsImpl@dsp.FrequencyDomainFIRFilter(obj,u);
        end

        function icon = getIconImpl(obj)
            if strcmp(obj.Method,'Overlap-add')
                icon = getString(message('dsp:system:FrequencyDomainFIRFilter:OAIcon'));
            else
                icon = getString(message('dsp:system:FrequencyDomainFIRFilter:OSIcon'));
            end
        end

        function varargout = isOutputComplexImpl(obj)

            if isFromPort(obj)
                if strcmp(obj.NumeratorDomain,'Frequency')
                    varargout{1} = ~obj.FilterIsReal || propagatedInputComplexity(obj, 2) || propagatedInputComplexity(obj, 1);
                else
                    varargout{1} = propagatedInputComplexity(obj, 2) || propagatedInputComplexity(obj, 1);
                end
            else
                if strcmp(obj.NumeratorDomain,'Frequency')
                    varargout{1} = ~(obj.FilterIsReal && isreal(obj.Numerator) &&  ~propagatedInputComplexity(obj, 1));
                else
                    varargout{1} = ~isreal(obj.Numerator) || propagatedInputComplexity(obj, 1);
                end
            end

            if obj.OutputFilterLatency
                varargout{2} = false;
            end
        end

        function varargout = getOutputSizeImpl(obj)
            % Output size propagator
            varargout{1}  = propagatedInputSize(obj, 1);
            if obj.OutputFilterLatency
                varargout{2} = [1 1];
            end
        end

        function varargout = getOutputDataTypeImpl(obj)
            % Output datatype propagator
            varargout{1} = propagatedInputDataType(obj, 1);
            if obj.OutputFilterLatency
                varargout{2} = 'uint32';
            end
        end

        function varargout = isOutputFixedSizeImpl(obj)
            varargout{1} = propagatedInputFixedSize(obj,1);
            if obj.OutputFilterLatency
                varargout{2} = true;
            end
        end

        function flag = inheritFFT(obj)
            flag = obj.InheritFFTLength;
        end

        function varargout = getInputNamesImpl(obj)
            if strcmp(obj.NumeratorDomain,'Time') && obj.SpecifyNumeratorFromPort
                varargout{1} = 'x';
                varargout{2} = 'NUM';
            elseif strcmp(obj.NumeratorDomain,'Frequency') && obj.SpecifyFrequencyResponseFromPort
                varargout{1} = 'x';
                varargout{2} = 'NUMFFT';
            else
                varargout{1} = '';
                varargout{2} = '';
            end
        end

        function varargout = getOutputNamesImpl(obj)
            if obj.OutputFilterLatency
                varargout{1} = 'y';
                varargout{2} = 'latency';
            else
                varargout{1} = '';
                varargout{2} = '';
            end
        end

        function sts = getSampleTimeImpl(obj)
            sts = createSampleTime(obj, 'Type', 'Inherited', ...
                'Disallow', 'Constant');
        end

        function flag = supportsMultipleInstanceImpl(~)
            flag = true;
        end
    end

    methods(Hidden)
        function filter = getVisualizationFilters(obj)
            % Used to return filter that will be shown when the visualize
            % filter response button is clicked.
            c = coeffs(obj);
            filter = c.Numerator;
        end

        function [flag,id] = isFVtoolSupported(obj)
            flag = ~isFromPort(obj);
            if strcmp(obj.NumeratorDomain,'Time')
                id   = 'dsp:system:FrequencyDomainFIRFilter:fvtoolButtonCoeffsPortText';
            else
                id   = 'dsp:system:FrequencyDomainFIRFilter:fvtoolButtonFreqResPortText';
            end
        end
    end

    methods(Static, Access=protected)
        function group = getPropertyGroupsImpl
            % Modify order of display
            props = {...
                matlab.system.display.internal.Property('Method','Description','dsp:DSPFilterImplementationsBlockDialog:Method_MP'),...
                matlab.system.display.internal.Property('NumeratorDomain','Description','dsp:DSPFilterImplementationsBlockDialog:NumeratorDomain_MP'),...
                matlab.system.display.internal.Property('SpecifyNumeratorFromPort','Description','dsp:DSPFilterImplementationsBlockDialog:SpecifyNumeratorFromPort_MP'),...
                matlab.system.display.internal.Property('SpecifyFrequencyResponseFromPort','Description','dsp:DSPFilterImplementationsBlockDialog:SpecifyFrequencyResponseFromPort_MP'),...
                matlab.system.display.internal.Property('FrequencyResponse','Description','dsp:DSPFilterImplementationsBlockDialog:FrequencyResponse_MP'),...
                matlab.system.display.internal.Property('Numerator','Description','dsp:DSPFilterImplementationsBlockDialog:Numerator_MP'),...
                matlab.system.display.internal.Property('PartitionForReducedLatency','Description','dsp:DSPFilterImplementationsBlockDialog:PartitionForReducedLatency_MP'),...
                matlab.system.display.internal.Property('NumeratorLength','Description','dsp:DSPFilterImplementationsBlockDialog:NumeratorLength_MP'),...
                matlab.system.display.internal.Property('InheritFFTLength','Description','dsp:DSPFilterImplementationsBlockDialog:InheritFFTLength_MP'),...
                matlab.system.display.internal.Property('FFTLength','Description','dsp:DSPFilterImplementationsBlockDialog:FFTLength_MP'),...
                matlab.system.display.internal.Property('PartitionLength','Description','dsp:DSPFilterImplementationsBlockDialog:PartitionLength_MP'),...
                matlab.system.display.internal.Property('FilterIsReal','Description','dsp:DSPFilterImplementationsBlockDialog:FilterIsReal_MP'),...
                matlab.system.display.internal.Property('OutputFilterLatency','Description','dsp:DSPFilterImplementationsBlockDialog:OutputFilterLatency_MP')};
            group =  matlab.system.display.Section(...
                'Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', props);
            filterVis = dsp.simulink.internal.FilterResponseVisualizationButton;
            group.Actions = filterVis.visualizeAction;
        end

        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.FrequencyDomainFIRFilter', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:system:FrequencyDomainFIRFilter:Title',...
                'Text', 'dsp:system:FrequencyDomainFIRFilter:BlockDescription');
        end
    end
end
