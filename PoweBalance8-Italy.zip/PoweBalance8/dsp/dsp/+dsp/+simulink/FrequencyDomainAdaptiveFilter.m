classdef FrequencyDomainAdaptiveFilter < dsp.FrequencyDomainAdaptiveFilter
%

% Copyright 2017 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCLS>
    
    properties(Nontunable)
        % AdaptPort Enable adapt port
        AdaptPort (1, 1) logical = false; 
        % ResetPort Enable reset port
        ResetPort (1, 1) logical = false; 
        % FFTCoefficientsPort  Output filter FFT coefficients
        FFTCoefficientsPort (1, 1) logical = false;
        % LeakageFactorPort Specify leakage factor from port
        LeakageFactorPort (1, 1) logical = false; 
        % StepSizePort Specify step size from port
        StepSizePort (1, 1) logical = false; 
        % OffsetPort Specify offset from port
        OffsetPort (1, 1) logical = false; 
        % AveragingFactorPort Specify averaging factor from port
        AveragingFactorPort (1, 1) logical = false;
    end
    
    properties (Constant, Hidden)
        StepSizeSet = matlab.system.SourceSet({'PropertyOrInput', ...
            'SystemBlock', 'StepSizePort', 1, 'Mu'});
        LeakageFactorSet = matlab.system.SourceSet({'PropertyOrInput', ...
            'SystemBlock', 'LeakageFactorPort', 2, 'Leak'});
        AveragingFactorSet = matlab.system.SourceSet({'PropertyOrInput', ...
            'SystemBlock', 'AveragingFactorPort', 3, 'Avg'});
        OffsetSet = matlab.system.SourceSet({'PropertyOrInput', ...
            'SystemBlock', 'OffsetPort', 4, 'Offset'});
    end
    
    properties (Access = private)
        pFirstStep (1, 1) logical = false;
    end
    
    methods
        
        % Constructor 
        function obj = FrequencyDomainAdaptiveFilter(varargin)
            obj = obj@dsp.FrequencyDomainAdaptiveFilter(varargin{:});
        end 
        
    end
    
    methods(Access = protected)

        function setupImpl(obj,varargin)

            % Never allow continuous time
            sts = getSampleTime(obj);
            coder.internal.errorIf(sts.SampleTime==0,...
                'dsp:system:Shared:ContinuousTimeNotAllowed');
            
            setupImpl@dsp.FrequencyDomainAdaptiveFilter(obj,varargin{:});
            
        obj.pFirstStep =  obj.LeakageFactorPort || obj.StepSizePort ...
           || obj.OffsetPort  ||obj.AveragingFactorPort;
       
        end
        
        function [y,e,varargout] = stepImpl(obj, x, d , varargin)
            
            if obj.pFirstStep
                updateFilterParameters(obj);
                obj.pFirstStep = false;
            end
            
            if obj.ResetPort && varargin{end}
                reset(obj);
            end

            [y,e] = stepImpl@dsp.FrequencyDomainAdaptiveFilter(obj, x, d , varargin{:});
            
            if obj.FFTCoefficientsPort
              varargout{1} =  obj.FFTCoefficients;
            end

        end
        
        function coeffsLocked = coefficientsLocked(obj,varargin)
            if obj.AdaptPort
                coeffsLocked = varargin{1} == 0;
            else
               coeffsLocked = false; 
            end
        end
        
        function validateInputsImpl(obj,varargin)
            validateInputsImpl@dsp.FrequencyDomainAdaptiveFilter(obj,varargin{1},varargin{2});
            % Validate adapt and reset ports
            ind = 3;
            if obj.AdaptPort
                adPortSig = varargin{ind};
                validateattributes(adPortSig, {'logical','numeric'}, ...
                {'2d', 'nonsparse', 'scalar', 'real', 'finite'}, '', ...
                'Adapt');         
                ind = ind + 1;
            end
            if obj.ResetPort
                resetPortSig = varargin{ind};
                validateattributes(resetPortSig, {'logical','numeric'}, ...
                {'2d', 'nonsparse', 'scalar', 'real', 'finite'}, '', ...
                'Reset');         
            end
        end

        function num = getNumOutputsImpl(obj)
            num = 2 + obj.FFTCoefficientsPort; 
        end
        function num = getNumInputsImpl(obj)
            num = 2 + obj.AdaptPort + obj.ResetPort;
        end
        
        function flag = supportsMultipleInstanceImpl(~)
            flag = true;
        end
        
        function dt = getTunablePropertiesSpecificationImpl(obj,~)
            dt = propagatedInputDataType(obj,1);
        end
        
        function sts = getSampleTimeImpl(obj)
            sts = createSampleTime(obj, 'Type', 'Inherited', ...
                                   'Disallow', 'Constant');
        end
        
        %% Block Icon
        function icon = getIconImpl(~)
            icon =  getString(message(...
                    'dsp:system:FrequencyDomainAdaptiveFilter:BlockIcon'));
        end

        %%Propagators
        function varargout = isOutputComplexImpl(obj)
            % Complexity propagator
            cplx = propagatedInputComplexity(obj,1);
            varargout{1} = cplx;
            varargout{2} = cplx;
            varargout{3} = true;
        end
        
        function varargout = getOutputSizeImpl(obj)
            % Output size propagator
            sz = propagatedInputSize(obj,1);
            varargout{1} = sz;
            varargout{2} = sz;
            if ~isPartitioned(obj)
                varargout{3} = [1 , obj.Length + obj.BlockLength];
            else
                varargout{3} = [obj.Length / obj.BlockLength , 2 * obj.BlockLength];
            end
        end
        
        function varargout = getOutputDataTypeImpl(obj)
            % Output datatype propagator
            dt = propagatedInputDataType(obj,1);
            varargout{1} = dt;
            varargout{2} = dt;
            varargout{3} = dt;
        end
        
         function varargout  = isOutputFixedSizeImpl(obj)
             varargout{1} = propagatedInputFixedSize(obj,1);
             varargout{2} = propagatedInputFixedSize(obj,1);
             varargout{3} = true;
         end
         
        function varargout = getInputNamesImpl(obj)
             varargout{1} = 'Input';
             varargout{2} = 'Desired';
             ind = 3;
             if obj.AdaptPort
                varargout{ind} = 'Adapt';
                ind = ind + 1;
             end
             if obj.ResetPort
                varargout{ind} = 'Reset';
             end
        end
        
        function varargout = getOutputNamesImpl(~)
             varargout{1} = 'Output';
             varargout{2} = 'Error';
             varargout{3} = 'FFTCoeffs';
        end
        
        function [sz,dt,cp] = getDiscreteStateSpecificationImpl(obj,name)
            
            dt = propagatedInputDataType(obj, 1);
            
            switch name
                case 'FFTCoefficients'
                    if ~isPartitioned(obj)
                        sz = [1 , obj.Length + obj.BlockLength];
                        cp = true;
                    else
                        sz = [obj.Length / obj.BlockLength , 2 * obj.BlockLength];
                        cp = true;
                    end
                case 'States'
                    if ~isPartitioned(obj)
                        sz = [obj.Length 1];
                        cp = propagatedInputComplexity(obj, 1);
                    else
                        sz = [2 * obj.BlockLength,obj.Length / obj.BlockLength - 1];
                        cp = true;
                    end
                case 'Power'
                    cp = false;
                    if ~isPartitioned(obj)
                        sz = [ obj.Length + obj.BlockLength , 1];
                    else
                        sz = [ 2 * obj.BlockLength , 1];
                    end
            end
            
        end
        
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@dsp.FrequencyDomainAdaptiveFilter(obj);
            if isLocked(obj)
                s.pFirstStep = obj.pFirstStep;
            end
        end
        
        function loadObjectImpl(obj, s, wasLocked)
            loadObjectImpl@dsp.FrequencyDomainAdaptiveFilter(obj, s, wasLocked);
            if wasLocked
                obj.pFirstStep = s.pFirstStep;
            end
        end
  
    end
    
    %% Block header - widget grouping
    methods(Static, Access=protected)
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.FrequencyDomainAdaptiveFilter', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:system:FrequencyDomainAdaptiveFilter:BlockTitle',...
                'Text',  'dsp:system:FrequencyDomainAdaptiveFilter:BlockHeader');
        end
        
        function groups = getPropertyGroupsImpl
            % Block property ordering

             props1 = {...
                matlab.system.display.internal.Property('Method','Description','dsp:DSPAdaptiveBlockDialog:Method_MP'),...
                matlab.system.display.internal.Property('Length','Description','dsp:DSPAdaptiveBlockDialog:L_MP'),...
                matlab.system.display.internal.Property('BlockLength','Description','dsp:DSPAdaptiveBlockDialog:N_MP')};
 
             section1 =  matlab.system.display.Section(...
                'Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', props1,...
                'DependOnPrivatePropertyList',{'BlockLength'});
            
             props2 = {...
                matlab.system.display.internal.Property('StepSizePort','Description','dsp:DSPAdaptiveBlockDialog:StepSizePort_MP'),...
                matlab.system.display.internal.Property('StepSize','Description','dsp:DSPAdaptiveBlockDialog:StepSize_MP'),...
                matlab.system.display.internal.Property('LeakageFactorPort','Description','dsp:DSPAdaptiveBlockDialog:LeakageFactorPort_MP'),...
                matlab.system.display.internal.Property('LeakageFactor','Description','dsp:DSPAdaptiveBlockDialog:LeakageFactor_MP'),...
                matlab.system.display.internal.Property('AveragingFactorPort','Description','dsp:DSPAdaptiveBlockDialog:AveragingFactorPort_MP'),...
                matlab.system.display.internal.Property('AveragingFactor','Description','dsp:DSPAdaptiveBlockDialog:AveragingFactor_MP'),...
                matlab.system.display.internal.Property('OffsetPort','Description','dsp:DSPAdaptiveBlockDialog:OffsetPort_MP'),...
                matlab.system.display.internal.Property('Offset','Description','dsp:DSPAdaptiveBlockDialog:Offset_MP')};

             section2 =  matlab.system.display.Section(...
                'Title', '', ...
                'PropertyList', props2);
            
             props3 = {...
                matlab.system.display.internal.Property('AdaptPort','Description','dsp:DSPAdaptiveBlockDialog:AdaptPort_MP'),...
                matlab.system.display.internal.Property('ResetPort','Description','dsp:DSPAdaptiveBlockDialog:ResetPort_MP'),...
                matlab.system.display.internal.Property('FFTCoefficientsPort','Description','dsp:DSPAdaptiveBlockDialog:FFTCoefficientsPort_MP')};
 
            section3 =  matlab.system.display.Section(...
                'Title', '', ...
                'PropertyList', props3);
            
            props4 = {...
                matlab.system.display.internal.Property('InitialPower','Description','dsp:DSPAdaptiveBlockDialog:InitialPower_MP'),...
                matlab.system.display.internal.Property('InitialCoefficients','Description','dsp:DSPAdaptiveBlockDialog:InitialCoefficients_MP')};
 
             section4 =  matlab.system.display.Section(...
                'Title', '', ...
                'PropertyList', props4);
            
            groups = [section1 section2 section4,section3];
            
        end
    end
    
    methods (Static, Hidden)
        function flag = checkVal(val)
            flag = ~(isscalar(val) && val >= 0 && val <= 1 && isreal(val));
        end 
    end
    
end
