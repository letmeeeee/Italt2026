classdef (StrictDefaults)BinaryFileReader < dsp.BinaryFileReader & ...
        matlab.system.mixin.FiniteSource

% This class is used in the binary file reader block

% Copyright 2016-2023 The MathWorks, Inc.

%#codegen
%#ok<*EMCLS>

    properties (Nontunable)
        %SampleTime Sample time (s)
        SampleTime   = 1;

        % OutputEOF Output end-of-file indicator
        OutputEOF (1, 1) logical = false
    end

    properties (Nontunable, Access = private)
        % pDataType Actual datatype
        pDataType
    end
    %----------------------------------------------------------------------
    % Public methods
    %----------------------------------------------------------------------
    methods
        % Constructor for the System object
        function obj = BinaryFileReader(varargin)
            setProperties(obj, nargin, varargin{:});
        end
    end
    %----------------------------------------------------------------------
    % Protected methods
    %----------------------------------------------------------------------
    methods(Access = protected)
        %------------------------------------------------------------------
        function validatePropertiesImpl(obj)
            non_unicode_filename = any(uint16(obj.Filename)>127);

            if ~coder.const(feval('dsp.enhancedsim.IsModelSimInCodeGenTLC')) && isempty(coder.target)
                codegen_mode = strcmpi(get_param(gcb, 'SimulateUsing'),'Code generation');
            else
                codegen_mode = true;
            end
            coder.internal.errorIf(codegen_mode && non_unicode_filename, 'dsp:binaryfileio:NonASCIIUnsupported')
        end
        %------------------------------------------------------------------
        function setpDataType(obj)
            dt = overrideDataType(obj, numerictype(obj.DataType));

            coder.internal.errorIf(~isempty(strfind(dt.DataTypeMode,'Scaled double')), ['dsp:binaryfileio',...
                ':NoScaledDouble']);

            if strcmp(dt.DataTypeMode,'Double')
                obj.pDataType = 'double';
            elseif strcmp(dt.DataTypeMode,'Single')
                obj.pDataType = 'single';
            else
                obj.pDataType = obj.DataType;
            end
        end
        %------------------------------------------------------------------
        function n = getNumOutputsImpl(obj)
            n = 1+ double(obj.OutputEOF);
        end
        %------------------------------------------------------------------
        function setupImpl(obj)
            setpDataType(obj);
            setupImpl@dsp.BinaryFileReader(obj);
        end
        %------------------------------------------------------------------
        function varargout = stepImpl(obj)
            if (obj.OutputEOF)
                varargout{2} = obj.pIsDone(obj.pIndex);
            end
            y = stepImpl@dsp.BinaryFileReader(obj);
            varargout{1} = cast(y,obj.pDataType);
        end
        %------------------------------------------------------------------
        %Propagators
        function varargout = isOutputComplexImpl(obj)
            varargout{1} = obj.IsDataComplex;
            varargout{2} = false;
        end
        %------------------------------------------------------------------
        function varargout = getOutputSizeImpl(obj)
            varargout{1} = [obj.SamplesPerFrame obj.NumChannels];
            varargout{2} = [1 1];
        end
        %------------------------------------------------------------------
        function varargout = getOutputDataTypeImpl(obj)
            dt = overrideDataType(obj, numerictype(obj.DataType));
            varargout{1} = dt;
            varargout{2} = 'logical';
        end
        %------------------------------------------------------------------
        function varargout = isOutputFixedSizeImpl(~)
            varargout{1} = true;
            varargout{2} = true;
        end
        %------------------------------------------------------------------
        function sts = getSampleTimeImpl(obj)
            Ts = obj.SampleTime * obj.SamplesPerFrame;
            sts = createSampleTime(obj, 'Type', 'Discrete', 'SampleTime', Ts);
        end
        %------------------------------------------------------------------
        function varargout = getOutputNamesImpl(obj)
            if ~obj.OutputEOF
                varargout{1} = '';
            else
                varargout{1} = 'data';
                varargout{2} = 'EOF';
            end
        end
        %------------------------------------------------------------------
        function icon = getIconImpl(~)
            icon = getString(message('dsp:binaryfileio:BinaryFileReaderIcon'));
        end
        %------------------------------------------------------------------
        function resolvedName = resolveFileName(obj)
            coder.extrinsic('dsp.simulink.BinaryFileReader.resolve');
            coder.extrinsic('dsp.BinaryFileReader.checkFileName');
            resolvedName = coder.const(@dsp.simulink.BinaryFileReader.resolve,obj.pFilename);
            [~,exists] = coder.const(@dsp.BinaryFileReader.checkFileName,resolvedName);
            if isempty(coder.target)
                coder.internal.errorIf(exists~=2, ['dsp:binaryfileio',...
                    ':FileDoesNotExist']);
            end
        end
    end
    %----------------------------------------------------------------------
    % Static Proteced methods
    %----------------------------------------------------------------------
    methods(Static, Access=protected)
        %------------------------------------------------------------------
        function group = getPropertyGroupsImpl
            % Modify order of display
            props = {matlab.system.display.internal.Property('Filename','Description','dsp:binaryfileio:Filename_MP'), ...
                matlab.system.display.internal.Property('HeaderStructure','Description','dsp:binaryfileio:HeaderStructure_MP'), ...
                matlab.system.display.internal.Property('DataType','Description','dsp:binaryfileio:DataType_MP'), ...
                matlab.system.display.internal.Property('IsDataComplex','Description','dsp:binaryfileio:IsDataComplex_MP'), ...
                matlab.system.display.internal.Property('SamplesPerFrame','Description','dsp:binaryfileio:SamplesPerFrame_MP'), ...
                matlab.system.display.internal.Property('NumChannels','Description','dsp:binaryfileio:NumChannels_MP'), ...
                matlab.system.display.internal.Property('OutputEOF','Description','dsp:binaryfileio:OutputEOF_MP'), ...
                matlab.system.display.internal.Property('SampleTime','Description','dsp:binaryfileio:SampleTime_MP')};
            group =  matlab.system.display.Section(...
                'Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', props, ...
                'DependOnPrivatePropertyList',{'Filename','HeaderStructure','DataType','HeaderStructure'});

            % Browse button
            browseButton = matlab.system.display.Action(...
                @dsp.simulink.BinaryFileReader.onBrowseFile, ...
                'Label','dsp:binaryfileio:BrowseButton',...
                'Placement','HeaderStructure','Alignment','right');

            % Export header button
            exportHeaderButton = matlab.system.display.Action(...
                @dsp.simulink.BinaryFileReader.onExportHeader, ...
                'Label','dsp:binaryfileio:ExportButton',...
                'Placement','DataType','Alignment','right');

            group.Actions = [browseButton exportHeaderButton];
        end
        %------------------------------------------------------------------
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.BinaryFileReader', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:binaryfileio:BinaryFileReaderTitle',...
                'Text', 'dsp:binaryfileio:BinaryFileReaderHeader');
        end
    end
    %----------------------------------------------------------------------
    % Static Hidden methods
    %----------------------------------------------------------------------
    methods(Static, Hidden)
        %------------------------------------------------------------------
        function resolvedName = resolve(filename)
            resolvedName = filename;
            if exist(filename,'file')
                return;
            end
            try %#ok
                % Try evaluating as a variable
                filename = slResolve(filename,gcbh);
                if ~ischar(filename) || isempty(filename)
                    return;
                end
                name = strrep(filename,'\','/');
                % Check if file exists
                if ~exist(name,'file')
                    return;
                end
                resolvedName = name;
            catch e %#ok
            end
        end
        %------------------------------------------------------------------
        function onBrowseFile(~, ~)
            % Select file via browse button
            % This function modifies settings of blocks in the subsystem. This
            % should not dirty the model
            model = bdroot(gcb);
            dirtyFlag = get_param(model,'Dirty');
            c = onCleanup(@()set_param(model,'Dirty',dirtyFlag));
            [filename, pathname] = uigetfile('*');
            if filename
                fname = fullfile(pathname,filename);
                set_param(gcb,'Filename',fname);
            end
        end
        %------------------------------------------------------------------
        function onExportHeader(~, ~)
            % Export file header to base workspace
            % This function modifies settings of blocks in the subsystem. This
            % should not dirty the model
            model = bdroot(gcb);
            dirtyFlag = get_param(model,'Dirty');
            c = onCleanup(@()set_param(model,'Dirty',dirtyFlag));
            filename = get_param(gcb,'Filename');
            filename = dsp.simulink.BinaryFileReader.resolve(filename);
            reader = dsp.BinaryFileReader(filename);
            headerPrototype  = slResolve(get_param(gcb,'HeaderStructure'),gcb);
            reader.HeaderStructure = headerPrototype;
            header = readHeader(reader);
            [~,NAME,~] = fileparts(filename);
            if isvarname(NAME)
                varname = NAME;
            else
                varname = 'binary_file';
            end
            varname = sprintf('%s_header',varname);
            assignin('base',varname,header);
        end
    end
end
