classdef (StrictDefaults)AllpassFilter <  dsp.internal.NewAllpassFilter
    % This class is used for the Allpass Filter block in dsparch4

    % Copyright 2014-2020 The MathWorks, Inc.

    %#codegen
    %#ok<*EMCA>

    properties (Nontunable)
        % AllpassCoefficientsPort Specify coefficients from input port
        AllpassCoefficientsPort (1, 1) logical = false;
        % LatticeCoefficientsPort Specify coefficients from input port
        LatticeCoefficientsPort (1, 1) logical = false;
    end

    methods
        function obj = AllpassFilter(varargin)
            obj@dsp.internal.NewAllpassFilter(varargin{:});
        end
    end

    properties (Constant, Hidden)
        AllpassCoefficientsSet = matlab.system.SourceSet( ...
        dsp.simulink.internal.AllpassFilterPolicy('SystemBlock', 'AllpassCoefficientsPort', 1, 'coeffs'), ...
          {'Property','MATLAB','AllpassCoefficientsPort'})

        LatticeCoefficientsSet = matlab.system.SourceSet( ...
        dsp.simulink.internal.AllpassFilterPolicy('SystemBlock', 'LatticeCoefficientsPort', 2, 'coeffs'), ...
          {'Property','MATLAB','LatticeCoefficientsPort'})
    end

    methods (Access = protected)

        % Relevant to matlab.System

        function validateInputsImpl(obj,varargin)
            validateInputsImpl@dsp.internal.NewAllpassFilter(obj,varargin{1});
        end

        function setupImpl(obj, u)

            ts = getSampleTime(obj);
            % Never allow continuous time
            coder.internal.errorIf(ts.SampleTime==0,...
                'dsp:system:Shared:ContinuousTimeNotAllowed');
            setupImpl@dsp.internal.NewAllpassFilter(obj,u);
        end

        %%Propagators
        function cp = isOutputComplexImpl(obj)
            cp = propagatedInputComplexity(obj, 1);
        end

        function sz = getOutputSizeImpl(obj)
            sz= propagatedInputSize(obj, 1);
        end

        function isfixed = isOutputFixedSizeImpl(obj)
            isfixed = propagatedInputFixedSize(obj,1);
        end

        function inputDT = getOutputDataTypeImpl(obj)
            inputDT = propagatedInputDataType(obj,1);
        end

        function icon = getIconImpl(~)
            % Block Icon
            icon = getString(message('dsp:system:AllpassFilter:BlockIcon'));
        end

        function val = supportsMultipleInstanceImpl(~)
            % For "For Each" support of the MATLAB System block
            val = true;
        end

        function name = getInputNamesImpl(obj)
            % Input port name to show on the block
            if obj.AllpassCoefficientsPort || obj.LatticeCoefficientsPort
                name = 'x';
            else
                name = '';
            end
        end

        function name = getOutputNamesImpl(~)
            % Ouput port name to show on the block
            name = '';
        end

        function [sz,dt,cp] = getDiscreteStateSpecificationImpl(obj,~)
            sz0 = propagatedInputSize(obj, 1);
            numChans = sz0(2);
            if (strcmp(obj.Structure,'Minimum multiplier') && obj.AllpassCoefficientsPort) || ...
                    (strcmp(obj.Structure,'Lattice') && obj.LatticeCoefficientsPort)
                szcoe = propagatedInputSize(obj, 2);
                r = szcoe(1);
                c = szcoe(2);
                N = max(szcoe);
            else
                coe = getCoefficients(obj);
                [r, c] = size(coe);
                N = length(coe);
            end
            numSections = r;

            switch(obj.Structure)
                case 'Minimum multiplier'
                    % Minimum multiplier case needs twice as many states
                    sz = [2*c numChans numSections];
                case 'Lattice'
                    sz = [N numChans numSections];
                case 'Wave Digital Filter'
                    sz = [c numChans numSections];
            end

            dt = propagatedInputDataType(obj, 1);
            cp = propagatedInputComplexity(obj, 1);
        end

        function sts = getSampleTimeImpl(obj)
            sts = createSampleTime(obj, 'Type', 'Inherited', ...
                                   'Disallow', 'Constant');
        end

        function nc = getNumChs(obj,~)
            sz = propagatedInputSize(obj,1);
            nc = sz(2);
        end

        function dt = getTunablePropertiesSpecificationImpl(obj,~)
            dt = propagatedInputDataType(obj,1);
        end
    end

    methods (Hidden, Static)

        function props = getDisplayPropertiesImpl()
            props = {...
                matlab.system.display.internal.Property('Structure','Description','dsp:system:AllpassFilter:Structure_MP'), ...
                matlab.system.display.internal.Property('AllpassCoefficientsPort','Description','dsp:system:AllpassFilter:AllpassCoefficientsPort_MP'), ...
                matlab.system.display.internal.Property('AllpassCoefficients','Description','dsp:system:AllpassFilter:AllpassCoefficients_MP'), ...
                matlab.system.display.internal.Property('LatticeCoefficientsPort','Description','dsp:system:AllpassFilter:LatticeCoefficientsPort_MP'), ...
                matlab.system.display.internal.Property('LatticeCoefficients','Description','dsp:system:AllpassFilter:LatticeCoefficients_MP'), ...
                matlab.system.display.internal.Property('WDFCoefficients','Description','dsp:system:AllpassFilter:WDFCoefficients_MP'), ...
                matlab.system.display.internal.Property('TrailingFirstOrderSection','Description','dsp:system:AllpassFilter:TrailingFirstOrderSection_MP')};
        end

    end

    methods(Static,Access=protected)

        function groups = getPropertyGroupsImpl
            props = dsp.simulink.AllpassFilter.getDisplayPropertiesImpl;

            parameterString = message('dsp:system:Shared:Parameters');
            groups = matlab.system.display.Section('Title', ...
                parameterString.getString, ...
                'PropertyList',props);

            % Visualize button
            filterVis = dsp.internal.FilterVisualizationButton;

            groups.Actions = [filterVis.fvtoolAction];
        end

        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.AllpassFilter', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:system:AllpassFilter:BlockName',...
                'Text',  'dsp:system:AllpassFilter:BlockHeader');
        end

    end
    methods (Hidden)

        function [flag,errID] = isFVtoolSupported(obj)
            % Specify if fvtool plot is supported, and what error should be
            % used when it is not supported.
            [flag,errID] = isFVtoolSupported@dsp.internal.FilterAnalysis(obj);
            if ((strcmp(obj.Structure,'Minimum multiplier') && obj.AllpassCoefficientsPort) || ...
                    (strcmp(obj.Structure,'Lattice') && obj.LatticeCoefficientsPort))
                flag = false;
                errID = 'dsp:system:Shared:fvtoolButtonSpecifyCoefficientsText';
            end

        end
    end
end

