classdef (StrictDefaults)FIRHalfbandDecimator < dsp.FIRHalfbandDecimator
% This class is used for the FIR Halfband Decimator block in dspfdesign
    
% Copyright 2014-2022 The MathWorks, Inc.

%#codegen
%#ok<*EMCA>

    properties (Nontunable)
        %FilterBankOutputPort Output highpass subband
        %   Specify if the block should be an analysis filter bank, as a
        %   logical scalar. When this property is set to false, the block
        %   acts as a decimator. If the property is set to true, the object
        %   acts as an analysis filter bank, producing two
        %   power-complementary outputs. The default of this property is
        %   false.
        FilterBankOutputPort (1, 1) logical = false;
    end
    
    %----------------------------------------------------------------------
    % Public Methods
    %----------------------------------------------------------------------
    methods
        function obj = FIRHalfbandDecimator(varargin)
            obj@dsp.FIRHalfbandDecimator(varargin{:});
        end
    end
    
    %----------------------------------------------------------------------
    % Protected Methods
    %----------------------------------------------------------------------
    methods (Access = protected)
        function num = getNumOutputsImpl(obj)
            num = 1+obj.FilterBankOutputPort;
        end
        
        %------------------------------------------------------------------
        function varargout = getInputNamesImpl(~)
            % Name of input port (shows on block icon)
            varargout{1} = '';
        end
        
        %------------------------------------------------------------------
        function varargout = getOutputNamesImpl(obj)
            % Name of output ports (shows on block icon)
            if ~obj.FilterBankOutputPort
                varargout{1} =   '';
            else % power-complementary outputs
                varargout{1} =   'LP';
                varargout{2} =   'HP';
            end
        end
        
        %------------------------------------------------------------------
        function icon = getIconImpl(obj)
            % MATLAB system block icon
            if ~obj.FilterBankOutputPort
                icon = getString(message(...
                    'dsp:system:FIRHalfbandDecimator:decimatorIconString'));
            else % power-complementary outputs requested
                icon = getString(message(...
                    'dsp:system:FIRHalfbandDecimator:analysisIconString'));
            end
        end
        
        %------------------------------------------------------------------
        function val = supportsMultipleInstanceImpl(obj)
            % Support in for-each subsystem
            val = ~obj.AllowArbitraryInputLength & propagatedInputFixedSize(obj,1);
        end
        
        %------------------------------------------------------------------
        % PROPAGATOR METHODS: (used by Simulink)
        %------------------------------------------------------------------
        function varargout = getOutputSizeImpl(obj)
            inputSize = propagatedInputSize(obj,1);
            fixedInput = propagatedInputFixedSize(obj, 1);
            coder.internal.errorIf(~obj.AllowArbitraryInputLength && rem(inputSize(1),2)~=0 && fixedInput, ...
                'dsp:system:FIRHalfbandDecimator:invalidInputDimsForHalfbandDecimBlock');
            varargout{1} = inputSize;
            varargout{1}(1) = ceil(varargout{1}(1)/2);
            if obj.FilterBankOutputPort
                varargout{2} = varargout{1};
            end
        end
        
        %------------------------------------------------------------------
        function varargout = getOutputDataTypeImpl(obj)
            inputDT = propagatedInputDataType(obj,1);
            if isempty(inputDT)
                return;
            elseif (ischar(inputDT) && any(strcmp(inputDT,{'double', 'single'})))
                % Floating-point input
                varargout{1} = inputDT;
            else
                % Fixed-point or integer inputs
                coder.internal.errorIf( ...
                    ~strcmp(obj.Specification, 'Coefficients') && ...
                    isSampleRateInherited(obj) && ~ischar(inputDT), ...
                    'dsp:system:FIRHalfbandDecimator:fixedPointWithInheritSampleRate');
            
                if ischar(inputDT)
                    inputDT = numerictype(inputDT); % For integer inputs
                end
                
                if strcmp(obj.Specification, 'Coefficients')
                    Coeff = obj.Numerator;
                else
                    Coeff = dsp.internal.FIRHalfbandBase.designHalfBand(...
                        obj.Specification,       ...
                        obj.FilterOrder,         ...
                        obj.TransitionWidth,     ...
                        obj.StopbandAttenuation, ...
                        getSampleRate(obj),          ...
                        obj.DesignMethod);
                end
                % We exclude 0.5 from the computation because we are using
                % the polyphase branch of the FIR decimator that has all
                % non-zero valued coefficients except for the middle 0.5
                % coefficient.
                Coeff = Coeff(Coeff~=0.5);
                Coeff = Coeff(Coeff~=0);
                w = fi(Coeff, obj.CoefficientsDataType);
                
                % Compute output data type
                [FIRoutputWL, FIRoutputFL] = ...
                    dsp.FIRHalfbandDecimator.filterPrecision(w, inputDT);
                if strcmp(inputDT.Signedness, 'Signed')
                    WLGrowth = 1;
                else
                    % Coeff is always signed. So when input is unsigned,
                    % the addition is signed + unsigned. Word length grows
                    % by 2 in such full precision additions.
                    WLGrowth = 2;
                end
                FL = inputDT.WordLength-(FIRoutputWL+WLGrowth-FIRoutputFL);
                
                varargout{1} = numerictype(true, inputDT.WordLength, FL);
            end
            
            if obj.FilterBankOutputPort
                varargout{2} = varargout{1};
            end
        end
        
        %------------------------------------------------------------------
        function varargout = isOutputComplexImpl(obj)
            varargout{1} = propagatedInputComplexity(obj,1);
            if obj.FilterBankOutputPort
                varargout{2} = varargout{1};
            end
        end
        
        %------------------------------------------------------------------
        function varargout = isOutputFixedSizeImpl(obj)
            isfixed = isFixedSizeOutput(obj);
            varargout{1} = isfixed;
            if obj.FilterBankOutputPort
                varargout{2} = varargout{1};
            end
        end
        function isFixedOutput = isFixedSizeOutput(obj)
            % Varsize output if input is varsize or arbitrary input is allowed
            isFixedOutput = propagatedInputFixedSize(obj,1) && ~obj.AllowArbitraryInputLength;
        end
        function flag = isInactivePropertyImpl(obj, prop)            
            switch prop
                case {'NormalizedFrequency'}
                    flag = true;
                otherwise
                    flag = isInactivePropertyImpl@dsp.internal.FIRHalfbandBase(obj,prop);
            end
        end
        function validatePropertiesImpl(obj)
            if ~isSampleRateInherited(obj)
                crossValidateProperties(obj);
            end            
        end
    end
    
    %----------------------------------------------------------------------
    % Static hidden methods
    %----------------------------------------------------------------------
    methods(Static,Hidden)
        function props = getDisplayPropertiesImpl()
            props = {                   ...
                matlab.system.display.internal.Property('Specification','Description','dsp:system:FIRHalfbandDecimator:Specification_MP'), ...
                matlab.system.display.internal.Property('FilterOrder','Description','dsp:system:FIRHalfbandDecimator:FilterOrder_MP'), ...
                matlab.system.display.internal.Property('TransitionWidth','Description','dsp:system:FIRHalfbandDecimator:TransitionWidth_MP'), ...
                matlab.system.display.internal.Property('StopbandAttenuation','Description','dsp:system:FIRHalfbandDecimator:StopbandAttenuation_MP'), ...
                matlab.system.display.internal.Property('DesignMethod','Description','dsp:system:FIRHalfbandDecimator:DesignMethod_MP'), ...
                matlab.system.display.internal.Property('Numerator','Description','dsp:system:FIRHalfbandDecimator:Numerator_MP'), ...
                matlab.system.display.internal.Property('FilterBankOutputPort','Description','dsp:system:FIRHalfbandDecimator:FilterBankOutputPort_MP'), ...
                matlab.system.display.internal.Property('SampleRateMode','Description','dsp:system:AbstractSampleRateEngine:SampleRateMode_MP'), ...
                matlab.system.display.internal.Property('SampleRate','Description','dsp:system:AbstractSampleRateEngine:SampleRate_MP'),...
                matlab.system.display.internal.Property('AllowArbitraryInputLength','Description','dsp:blkprm_prompts:AllowArbitraryFixedInput_MP')};
        end
    end
    %----------------------------------------------------------------------
    % Static protected methods
    %----------------------------------------------------------------------
    methods(Static,Access=protected)
        function groups = getPropertyGroupsImpl
            props = dsp.simulink.FIRHalfbandDecimator.getDisplayPropertiesImpl;
            
            mainS = matlab.system.display.Section(...
                'Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', props, ...
                'DependOnPrivatePropertyList',{'SampleRate'});
            
            filterVis = dsp.internal.FilterVisualizationButton;
            mainS.Actions = filterVis.fvtoolAction;
            
            mainSG = matlab.system.display.SectionGroup(...
                'TitleSource', 'Auto',...
                'Sections', mainS);
            dtSG = matlab.system.display.internal.DataTypesGroup(...
                'dsp.FIRHalfbandDecimator');
            dtSG.PropertyList{2} = ...
                matlab.system.display.internal.DataTypeProperty( ...
                'CoefficientsDataType', ...
                'Prefix', 'coeffs', ...
                'Description', 'Coefficients');
            
            groups = [mainSG, dtSG];

        end
        %------------------------------------------------------------------
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.FIRHalfbandDecimator', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:system:FIRHalfbandDecimator:titleString',...
                'Text',  'dsp:system:FIRHalfbandDecimator:descriptionString');
        end
    end
    methods (Hidden)
        function f = updateFvtoolFigure(obj,f)
            % Used to update fvtool plot when object is used in Simulink
            setfilter(f, obj);
            if isSampleRateNormalized(obj) || strcmp(obj.Specification, 'Coefficients') 
                f.NormalizedFrequency = 'on';
            else
                f.NormalizedFrequency = 'off';
            end

        end
    end
end
