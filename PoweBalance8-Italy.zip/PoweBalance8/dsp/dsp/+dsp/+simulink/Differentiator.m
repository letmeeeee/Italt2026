classdef (StrictDefaults)Differentiator < dsp.Differentiator
    %Differentiator Direct form FIR full band differentiator filter
    %This class is used in the Differentiator filter block in dspfdesign

    % Copyright 2021-2022 The MathWorks, Inc.    
    %#codegen
    %#ok<*EMCA>

    methods
        function obj = Differentiator(varargin)
            obj@dsp.Differentiator(varargin{:});
        end
    end

    methods (Access = protected)
        %%Propagators
        function cp = isOutputComplexImpl(obj)
            cp = propagatedInputComplexity(obj, 1);
        end
        
        function sz = getOutputSizeImpl(obj)
            sz= propagatedInputSize(obj, 1);
        end
        
        function isfixed = isOutputFixedSizeImpl(obj)
            isfixed = propagatedInputFixedSize(obj,1);
        end
        
        function varargout = getOutputDataTypeImpl(obj)
            inputDT = propagatedInputDataType(obj,1);
            if isempty(inputDT)
               return; 
            end
            if (ischar(inputDT) && any(strcmp(inputDT,{'double', 'single'})))
                varargout{1} = inputDT;
            else
                if ischar(inputDT)
                    % For integer input
                    inputDT = numerictype(inputDT);
                end
                b = computeFIRCoefficients(obj);
                w = fi(b, obj.CoefficientsDataType); % fi filter weights
                % compute output data type
                [~,~,outputWL, outputFL] = coder.const(@dsp.Differentiator.firPrecision, ...
                    w,inputDT);
                varargout{1} = numerictype(true, outputWL, outputFL);
            end
        end
        
        function icon = getIconImpl(~)
            % Block Icon
            iconStr = getString(message('dsp:system:Differentiator:DiffBlockIcon'));
            icon = sprintf(iconStr);
        end
        
        function val = supportsMultipleInstanceImpl(~)
            % For "For Each" support of the MATLAB System block
            val = true;
        end
        
        function name = getInputNamesImpl(~)
            % Input port name to show on the block
            name = '';
        end
        
        function name = getOutputNamesImpl(~)
            % Output port name to show on the block
            name = '';
        end
        
    end

    methods(Static,Access=protected)
        function groups = getPropertyGroupsImpl
            props = {...
                matlab.system.display.internal.Property('DesignForMinimumOrder',Description='dsp:system:Differentiator:DesignForMinimumOrder_MP'), ...
                matlab.system.display.internal.Property('FilterOrder',Description='dsp:system:Differentiator:FilterOrder_MP'), ...
                matlab.system.display.internal.Property('PassbandRipple',Description='dsp:system:Differentiator:PassbandRipple_MP'),...
                matlab.system.display.internal.Property('ScaleCoefficients',Description='dsp:system:Differentiator:ScaleCoefficients_MP')};
            
            mainS = matlab.system.display.Section(Title='dsp:system:Shared:Parameters', PropertyList=props);
            filterVis = dsp.internal.FilterVisualizationButton;
            mainS.Actions = filterVis.fvtoolAction;
            mainSG = matlab.system.display.SectionGroup(TitleSource='Auto', Sections=mainS);

            dtSG = matlab.system.display.internal.DataTypesGroup(...
                'dsp.Differentiator');
            dtSG.PropertyList{2} = matlab.system.display.internal.DataTypeProperty('CoefficientsDataType', ...
                Prefix='coeffs', ...
                Description='dsp:system:Shared:Coefficients');
            groups = [mainSG, dtSG];
        end 

        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.Differentiator', ...
                ShowSourceLink=true, ...
                Title='dsp:system:Differentiator:DiffBlockName',...
                Text='dsp:system:Differentiator:DiffBlockHeader');
        end
    end

end