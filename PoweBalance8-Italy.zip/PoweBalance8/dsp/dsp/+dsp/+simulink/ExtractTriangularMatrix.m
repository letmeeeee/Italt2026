classdef (StrictDefaults)ExtractTriangularMatrix < matlab.System
    
    % This System object used under dspmtrx3/Extract Triangular Matrix
    % block.
    
    %  Copyright 2016-2021 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCA>
    
    properties (Nontunable)
        % fcn Extract
        fcn = 'Upper'
    end
    
    properties (Access = private, Nontunable)
        fcnKey = uint8(1);
    end
    
    properties(Constant, Hidden)
        fcnSet = matlab.system.StringSet( { ...
            'Upper','Lower'} );
    end
    
    methods
        % Constructor
        function obj = ExtractTriangularMatrix(varargin)
            setProperties(obj, nargin, varargin{:});
        end
    end
    
    methods (Access=protected)
        
        function setupImpl(obj)
            if strcmp(obj.fcn,'Upper')
                obj.fcnKey = uint8(1);
            else
                obj.fcnKey = uint8(0);
            end
        end
        
        function y = stepImpl(obj,u)
            if obj.fcnKey == 1
                y = triu(u);
            else
                y = tril(u);
            end
        end
        
        
        function val = supportsMultipleInstanceImpl(~)
            val = true;
        end
        
        function s = saveObjectImpl(obj)
            % Default implementation saves all public properties
            s = saveObjectImpl@matlab.System(obj);
            
            if isLocked(obj)
                % All the following are set at setup
                s.fcnKey = obj.fcnKey;
            end
            
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            % Re-load state if saved version was locked
            if wasLocked
                obj.fcnKey = s.fcnKey;
            end
            % Call base class method
            loadObjectImpl@matlab.System(obj,s,wasLocked);
        end
        
        % Block Icon
        function icon = getMaskDisplayImpl(obj)
            switch(obj.fcn)
                case 'Upper'
                    x = [.87 .87 .58 .87 NaN ...
                        0.12 0.45 0.45 0.12 0.12 NaN ...
                        0.525 0.525 0.475 0.475 0.525 0.525 0.565 0.525 ];
                    y = [0.3 0.7 0.7 0.3 NaN ...
                        0.3 0.3 0.7 0.7 0.3 NaN ...
                        0.435 0.475 0.475 0.525 0.525 0.565 0.5 0.435];
                    s = 'U';
                case 'Lower'
                    x = [.58 .87 .58 .58 NaN ...
                        0.12 0.45 0.45 0.12 0.12 NaN ...
                        0.525 0.525 0.475 0.475 0.525 0.525 0.565 0.525 ];
                    y = [0.3 0.3 0.7 0.3 NaN ...
                        0.3 0.3 0.7 0.7 0.3 NaN ...
                        0.435 0.475 0.475 0.525 0.525 0.565 0.5 0.435];
                    s = 'L';
            end
            
            icon = {['plot(0,0,1,1,' mat2str(x) ',' mat2str(y) ');'],...
                    'port_label(''input'',1,''A'');',...
                    ['port_label(''output'',1,''' s ''');']}; 
        end
        
        function name = getInputNamesImpl(~)
            name = '';
        end
        
        function name = getOutputNamesImpl(~)
            name = '';
        end
        
    end
    
    %% Block header - widget grouping
    methods(Static, Access=protected)
        function mainS = getPropertyGroupsImpl
            % Modify order of display
            mainS =  matlab.system.display.Section(...
                'Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', {matlab.system.display.internal.Property('fcn','Description','dsp:DSPMatrixOperationsBlockDialog:fcn_MP')});
        end
        %------------------------------------------------------------------
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.ExtractTriangularMatrix', ...
                'ShowSourceLink', false, ...
                'Title', 'dsp:system:ExtractTriangularMatrix:BlockTitle',...
                'Text',  'dsp:system:ExtractTriangularMatrix:BlockHeader');
        end
    end
    
end
