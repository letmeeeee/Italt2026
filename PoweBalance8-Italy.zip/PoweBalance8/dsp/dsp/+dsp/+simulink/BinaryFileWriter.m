classdef (StrictDefaults)BinaryFileWriter < dsp.BinaryFileWriter
    
    % This class is used in the binary file writer block
    
    % Copyright 2020-2022 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCLS>
    
    %----------------------------------------------------------------------
    % Public methods
    %----------------------------------------------------------------------
    methods
        %------------------------------------------------------------------
        % Constructor for the System object
        function obj = BinaryFileWriter(varargin)
            setProperties(obj, nargin, varargin{:});
        end
    end
    %----------------------------------------------------------------------
    % Protected methods
    %----------------------------------------------------------------------
    % Overridden implementation methods
    methods(Access = protected)
        function validatePropertiesImpl(obj)
            non_unicode_filename = any(uint16(obj.Filename)>127);

            if ~coder.const(feval('dsp.enhancedsim.IsModelSimInCodeGenTLC')) && isempty(coder.target)
                codegen_mode = strcmpi(get_param(gcb, 'SimulateUsing'),'Code generation');
            else
                codegen_mode = true;
            end
            coder.internal.errorIf(codegen_mode && non_unicode_filename, 'dsp:binaryfileio:NonASCIIUnsupported')
        end

        %------------------------------------------------------------------
        function validateInputsImpl(obj,u)
            % Simulink propagates int64 and uint64 as embedded.fi. No
            % Fixed Point license is needed
            u = castFiToMATLAB(u);
            validateInputsImpl@dsp.BinaryFileWriter(obj,u);
        end
        %------------------------------------------------------------------
        function fmt = getPrecision(obj, u)
            % Simulink propagates int64 and uint64 as embedded.fi. No
            % Fixed Point license in needed
            u = castFiToMATLAB(u);
            fmt = getPrecision@dsp.BinaryFileWriter(obj,u);
        end
        %%Propagators
        %------------------------------------------------------------------
        function icon = getIconImpl(~)
            icon = getString(message('dsp:binaryfileio:BinaryFileWriterIcon'));
        end
        %------------------------------------------------------------------
        function s = getInputNamesImpl(~)
            s = '';
        end
    end
    %----------------------------------------------------------------------
    % Static Protected methods
    %----------------------------------------------------------------------
    % Block header - widget grouping
    methods(Static, Access=protected)
        %------------------------------------------------------------------
        function group = getPropertyGroupsImpl
            % Modify order of display
            props = {matlab.system.display.internal.Property('Filename','Description','dsp:binaryfileio:Filename_MP'), ...
                     matlab.system.display.internal.Property('HeaderStructure','Description','dsp:binaryfileio:HeaderStructure_MP')};
            group =  matlab.system.display.Section(...
                'Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', props,...
                'DependOnPrivatePropertyList',{'Filename'});
            % SaveAs action button
            buttonString = message('dsp:binaryfileio:SaveAsButton');
            saveAsAction = matlab.system.display.Action(...
                @dsp.simulink.BinaryFileWriter.onSaveAs, ...
                'Label',buttonString.getString,...
                'Placement','HeaderStructure','Alignment', 'right');
            group.Actions = saveAsAction;
        end
        %------------------------------------------------------------------
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.BinaryFileWriter', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:binaryfileio:BinaryFileWriterTitle',...
                'Text',  'dsp:binaryfileio:BinaryFileWriterHeader');
        end
    end
    %----------------------------------------------------------------------
    % Static Hidden methods
    %----------------------------------------------------------------------
    methods(Static, Hidden)
        function onSaveAs(~, ~)
            model = bdroot(gcb);
            dirtyFlag = get_param(model,'Dirty');
            c = onCleanup(@()set_param(model,'Dirty',dirtyFlag));
    
            % Select file via browse button
            [filename, pathname] = uiputfile('*');
            if filename
                fname = fullfile(pathname,filename);
                set_param(gcb,'Filename',fname);
            end
        end
    end
end
