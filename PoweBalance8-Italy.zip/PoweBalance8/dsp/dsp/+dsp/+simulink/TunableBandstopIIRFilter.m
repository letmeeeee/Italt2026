classdef TunableBandstopIIRFilter < dsp.internal.TunableBandstopIIRFilter
% TunableBandstopIIRFilter Design bandstop IIR filter with tunable
% specifications

%   Copyright 2022-2023 The MathWorks, Inc.

%#codegen

    properties(Nontunable)
        %FilterOrderPort Specify filter order from input port
        FilterOrderPort (1,1) logical = false;
        %F3dB1Port Specify first 3-dB cutoff frequency from input port
        F3dB1Port (1,1) logical = false;
        %F3dB2Port Specify second 3-dB cutoff frequency from input port
        F3dB2Port (1,1) logical = false;
        %ApassPort Specify passband ripple from input port
        ApassPort (1,1) logical = false;
        %AstopPort Specify stopband attenuation from input port
        AstopPort (1,1) logical = false;
        %SampleTime Sample time (s)
        %   Specify sample time as a positive scalar in seconds -1 for
        %   inherited or Inf for constant. The default is -1.
        SampleTime = -1;
    end

    properties (Constant, Hidden)
        FilterOrderSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.TunableBandpassBandstopIIRPolicy('SystemBlock', 'FilterOrderPort', 1, 'N'), ...
            {'Property','MATLAB','FilterOrderPort'});
        F3dB1Set = matlab.system.SourceSet( ...
            dsp.simulink.internal.TunableBandpassBandstopIIRPolicy('SystemBlock', 'F3dB1Port', 2, 'Fc1'), ...
            {'Property','MATLAB','F3dB1Port'});
        F3dB2Set = matlab.system.SourceSet( ...
            dsp.simulink.internal.TunableBandpassBandstopIIRPolicy('SystemBlock', 'F3dB2Port', 3, 'Fc2'), ...
            {'Property','MATLAB','F3dB2Port'});
        ApassSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.TunableBandpassBandstopIIRPolicy('SystemBlock', 'ApassPort', 4, 'Ap'), ...
            {'Property','MATLAB','ApassPort'});
        AstopSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.TunableBandpassBandstopIIRPolicy('SystemBlock', 'AstopPort', 5, 'Ast'), ...
            {'Property','MATLAB','AstopPort'});
    end

    methods
        %------------------------------------------------------------------
        % Constructor
        function this = TunableBandstopIIRFilter(varargin)
            % Support name-value pair arguments when constructing object
            setProperties(this,nargin,varargin{:});
        end
        %------------------------------------------------------------------
        function set.SampleTime(this, value)
            validateattributes(value, {'double','single'}, {'real','scalar'}, 'set.SampleTime','SampleTime');
            this.SampleTime = value;
        end
    end

    methods(Access = protected)
        %------------------------------------------------------------------
        function flag = isInputSizeMutableImpl(~,~)
            % Return false if input size cannot change
            % between calls to the System object
            flag = false;
        end
        %------------------------------------------------------------------
        function num = getNumOutputsImpl(this)
            % Define total number of outputs for system with optional
            % outputs
            num = 2;
            if isScaleValueAllowed(this)
                num = 3;
            end
        end
        %------------------------------------------------------------------
        function varargout = isOutputFixedSizeImpl(this)
            % Return false if input size cannot change
            % between calls to the System object
            varargout{1} = true;
            varargout{2} = true;
            if isScaleValueAllowed(this)
                varargout{3} = true;
            end
        end
        %------------------------------------------------------------------
        function varargout = isOutputComplexImpl(this)
            varargout{1} = false;
            varargout{2} = false;
            if isScaleValueAllowed(this)
                varargout{3} = false;
            end
        end
        %------------------------------------------------------------------
        function varargout = getOutputSizeImpl(this)
            % Return size for each output port
            dims = getCoefficientsDimensions(this);
            varargout{1} = dims;
            varargout{2} = dims;
            if isScaleValueAllowed(this)
                varargout{3} = [dims(1) + 1 1];
            end
        end
        %------------------------------------------------------------------
        function varargout = getOutputDataTypeImpl(this)
            dt = this.OutputDataType;
            varargout{1} = dt;
            varargout{2} = dt;
            if isScaleValueAllowed(this)
                varargout{3} = dt;
            end
        end
        %------------------------------------------------------------------
        function name = getOutputNamesImpl(this)
            name = ["Num", "Den"];
            if isScaleValueAllowed(this)
                name = ["Num", "Den", "g"];
            end
        end
        %------------------------------------------------------------------
        function icon = getIconImpl(~)
            icon = getString(message('dsp:system:TunableIIRFilter:TunableBSFIIRBlockIcon'));
        end
        %------------------------------------------------------------------
        function val = supportsMultipleInstanceImpl(~,~)
            % For "For Each" support of the MATLAB System block
            val = true;
        end
        %------------------------------------------------------------------
        function validateF3dB1(this, value, compareWithMax, varargin)
           validateF3dB1@dsp.internal.TunableBandstopIIRFilter(this, value, compareWithMax, this.F3dB1Port);
        end
        %------------------------------------------------------------------
        function validateF3dB2(this, value, compareWithMin, varargin)
           validateF3dB2@dsp.internal.TunableBandstopIIRFilter(this, value, compareWithMin, this.F3dB2Port);
        end
        %------------------------------------------------------------------
        function validateApass(this, value, varargin)
           validateApass@dsp.internal.AbstractTunableIIRFilter(this, value, this.ApassPort);
        end
        %------------------------------------------------------------------
        function validateAstop(this, value, varargin)
           validateAstop@dsp.internal.AbstractTunableIIRFilter(this, value, this.AstopPort);
        end
        %------------------------------------------------------------------
        function sts = getSampleTimeImpl(this)
            if this.SampleTime == -1
                sts = createSampleTime(this,'Type','Inherited');
            else
                sts = createSampleTime(this,'Type','Discrete','SampleTime', this.SampleTime);
            end
        end
    end

    methods(Static, Access = protected)
        %------------------------------------------------------------------
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.TunableBandstopIIRFilter', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:system:TunableIIRFilter:TunableBSFIIRBlockName',...
                'Text', 'dsp:system:TunableIIRFilter:TunableBSFIIRBlockHeader');
        end
        %------------------------------------------------------------------
        function groups = getPropertyGroupsImpl
            props = {...
                matlab.system.display.internal.Property('DesignMethod','Description','dsp:system:TunableIIRFilter:DesignMethod_MP'), ...
                matlab.system.display.internal.Property('FilterOrderPort','Description','dsp:system:TunableIIRFilter:FilterOrderPort_MP'), ...
                matlab.system.display.internal.Property('FilterOrder','Description','dsp:system:TunableIIRFilter:EvenFilterOrder_MP'), ...
                matlab.system.display.internal.Property('MaxOrder','Description','dsp:system:TunableIIRFilter:MaxEvenOrder_MP'), ...
                matlab.system.display.internal.Property('HasScaleValues','Description','dsp:system:TunableIIRFilter:HasScaleValues_MP'), ...
                matlab.system.display.internal.Property('F3dB1Port','Description','dsp:system:TunableIIRFilter:F3dB1Port_MP'), ...
                matlab.system.display.internal.Property('F3dB1','Description','dsp:system:TunableIIRFilter:F3dB1_MP'), ...
                matlab.system.display.internal.Property('F3dB2Port','Description','dsp:system:TunableIIRFilter:F3dB2Port_MP'), ...
                matlab.system.display.internal.Property('F3dB2','Description','dsp:system:TunableIIRFilter:F3dB2_MP'), ...
                matlab.system.display.internal.Property('ApassPort','Description','dsp:system:TunableIIRFilter:ApassPort_MP'), ...
                matlab.system.display.internal.Property('Apass','Description','dsp:system:TunableIIRFilter:Apass_MP'), ...
                matlab.system.display.internal.Property('AstopPort','Description','dsp:system:TunableIIRFilter:AstopPort_MP'), ...
                matlab.system.display.internal.Property('Astop','Description','dsp:system:TunableIIRFilter:Astop_MP'), ...
                matlab.system.display.internal.Property('SampleTime','Description','dsp:system:TunableIIRFilter:SampleTime_MP'), ...
                matlab.system.display.internal.Property('CascadeSectionsForm','Description','dsp:system:TunableIIRFilter:CascadeSectionsForm_MP'), ...
                matlab.system.display.internal.Property('OutputDataType','Description','dsp:system:TunableIIRFilter:OutputDataType_MP')};

            groups = matlab.system.display.Section('Title', ...
                'dsp:system:Shared:Parameters', ...
                'PropertyList',props);
        end    
    end
end
