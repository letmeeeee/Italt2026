classdef (StrictDefaults)TransferFunctionEstimator < dsp.TransferFunctionEstimator
    % This class is internally used for the Discrete Transfer Function
    % Estimator block

    %#codegen
    %#ok<*EMCLS>

    %   Copyright 2015-2020 The MathWorks, Inc.

    properties (Access = private)
        % Count number of received frames. Used to ignore latency frames
        pFrameCounter;
        % Latency (frames)
        % System latency in frames. The first pFrameDelay frames must be ignored
        % because they are all-zeros (initial conditions) caused by non-zero
        % multirate latency
        pFrameDelay;
    end

    properties(Nontunable)
        % ForgettingFactorPort Specify forgetting factor from input port
        ForgettingFactorPort (1, 1) logical = false;
    end
    properties (Constant, Hidden)
        ForgettingFactorSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.SpectrumEstimatorPolicy('SystemBlock', 'ForgettingFactorPort', 1, 'lambda'), ...
            {'Property','MATLAB','ForgettingFactorPort'})
    end

    methods
        function obj = TransferFunctionEstimator(varargin)
            %SpectrumEstimator   Construct the SpectrumEstimator class.
            obj@dsp.TransferFunctionEstimator(varargin{:})
        end
    end

    methods(Access = protected)

        function setupImpl(obj,x,y)

            setupImpl@dsp.TransferFunctionEstimator(obj,x,y);

            coder.extrinsic('dsp.simulink.TransferFunctionEstimator.initializeBlock');

            obj.pFrameCounter   = cast(0,class(x));
            [~,obj.pFrameDelay] = coder.const(@dsp.simulink.TransferFunctionEstimator.initializeBlock);
        end

        function varargout  = getInputNamesImpl(obj)
            varargout{1} = 'x';
            varargout{2} = 'y';
            if  ~strcmp(obj.AveragingMethod,'Running') && obj.ForgettingFactorPort
                varargout{3} = 'lambda';
            end
        end

        function  varargout = stepImpl(obj,x,y)
            if obj.pFrameCounter >= obj.pFrameDelay
                if getNumOutputs(obj) == 1
                    TFE = stepImpl@dsp.TransferFunctionEstimator(obj,x,y);
                    varargout{1} = TFE;
                else
                    [TFE , Cxy] = stepImpl@dsp.TransferFunctionEstimator(obj,x,y);
                    varargout{1} = TFE;
                    varargout{2} = Cxy;
                end
            else
                obj.pFrameCounter = obj.pFrameCounter + 1;
                F = getFrequencyVector(obj);
                P = zeros(length(F),size(x,2),class(x)) + 1j * zeros(length(F),size(x,2),class(x));
                varargout{1} = P;
                if getNumOutputs(obj) == 2
                    varargout{2} = zeros(length(F),size(x,2),class(x));
                end
            end
        end

        function s = saveObjectImpl(obj)
            s = saveObjectImpl@dsp.TransferFunctionEstimator(obj);
            if isLocked(obj)
                s.pFrameCounter  = obj.pFrameCounter;
                s.pFrameDelay    = obj.pFrameDelay;
            end
        end

        function loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                obj.pFrameCounter  = s.pFrameCounter;
                obj.pFrameDelay    = s.pFrameDelay;
            end
            loadObjectImpl@dsp.TransferFunctionEstimator(obj,s,wasLocked);
        end

        function validateForgettingFactor(~,val)
            validateattributes(val,...
                {'double','single'},...
                {'real','scalar','finite','>=',0,'<=',1},...
                '','ForgettingFactor');
        end

        function icon = getIconImpl(~)
            icon = getString(message('dsp:system:SpectrumEstimatorBase:TFEIcon'));
        end

        function varargout = getOutputNamesImpl(obj)
            if obj.OutputCoherence
                varargout{1} = 'H';
                varargout{2} = 'Cxy';
            else
                varargout{1} = '';
            end
        end
    end

    methods (Static, Hidden)

        function [Fs,delayFrames] = initializeBlock()
            % Compute Fs and buffer latency based on block and model settings
            computeFs = false;
            bufferBlkName = 'Buffer_x';
            checkRBW = false;
            blk = get_param(gcb,'Parent');
            [Fs,delayFrames] = dsp.internal.initializeSpectrumBlock(blk , checkRBW, computeFs , bufferBlkName);
        end
    end

    methods (Static, Access = protected)

        function varargout = getOutputSizeImpl(obj)
            sz_in = propagatedInputSize(obj,1);
            if(~isempty(sz_in))

                sz_out = sz_in;

                if strcmp(obj.FFTLengthSource,'Auto')
                    NFFT = sz_in(1);
                else
                    NFFT = obj.FFTLength;
                end
                switch obj.FrequencyRange
                    case 'onesided'
                        if mod(NFFT,2)==0
                            sz_out(1) = NFFT/2 + 1;
                        else
                            sz_out(1) = (NFFT+1)/2;
                        end
                    case {'twosided','centered'}
                        sz_out(1) = NFFT;
                end

                varargout{1} = sz_out;
                if nargout == 2
                    varargout{2} = sz_out;
                end
            else
                varargout{1} = [];
            end

        end
        %------------------------------------------------------------------
        function varargout = getOutputDataTypeImpl(obj)
            varargout{1} = propagatedInputDataType(obj,1);
            if nargout == 2
                varargout{2} = propagatedInputDataType(obj,1);
            end
        end
        %------------------------------------------------------------------
        function varargout = isOutputFixedSizeImpl(~)
            varargout{1} = true;
            if nargout == 2
                varargout{2} = true;
            end
        end
        %------------------------------------------------------------------
        function varargout = isOutputComplexImpl(~)
            varargout{1} = true;
            if nargout == 2
                varargout{2} = false;
            end
        end
        %------------------------------------------------------------------
        function flag =  supportsMultipleInstanceImpl(~)
            flag = true;
        end
        %------------------------------------------------------------------
        function group = getPropertyGroupsImpl
            %Get default parameters group for this System object
            parameterString = getString(message('dsp:system:Shared:Parameters'));
            privPropertyList = {'AveragingMethod','SpectralAverages', ...
                'ForgettingFactorPort','ForgettingFactor', ...
                'FFTLengthSource','FFTLength',...
                'Window','SidelobeAttenuation','FrequencyRange','OutputCoherence'};
            propertyList = {matlab.system.display.internal.Property('AveragingMethod','Description','dsp:system:SpectrumEstimatorBase:AveragingMethod_MP'), ...
                matlab.system.display.internal.Property('SpectralAverages','Description','dsp:system:SpectrumEstimatorBase:SpectralAverages_MP'), ...
                matlab.system.display.internal.Property('ForgettingFactorPort','Description','dsp:system:SpectrumEstimatorBase:ForgettingFactorPort_MP'), ...
                matlab.system.display.internal.Property('ForgettingFactor','Description','dsp:system:SpectrumEstimatorBase:ForgettingFactor_MP'), ...
                matlab.system.display.internal.Property('FFTLengthSource','Description','dsp:system:SpectrumEstimatorBase:FFTLengthSource_MP'), ...
                matlab.system.display.internal.Property('FFTLength','Description','dsp:system:SpectrumEstimatorBase:FFTLength_MP'), ...
                matlab.system.display.internal.Property('Window','Description','dsp:system:SpectrumEstimatorBase:Window_MP'), ...
                matlab.system.display.internal.Property('SidelobeAttenuation','Description','dsp:system:SpectrumEstimatorBase:SidelobeAttenuation_MP'), ...
                matlab.system.display.internal.Property('FrequencyRange','Description','dsp:system:SpectrumEstimatorBase:FrequencyRange_MP'), ...
                matlab.system.display.internal.Property('OutputCoherence','Description','dsp:system:SpectrumEstimatorBase:OutputCoherence_MP')};
            group = matlab.system.display.Section('Title', parameterString, ...
                'PropertyList', propertyList,...
                'DependOnPrivatePropertyList',privPropertyList);
        end
        %------------------------------------------------------------------
        function header = getHeaderImpl
            header = matlab.system.display.Header('dsp.simulink.TransferFunctionEstimator', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:system:SpectrumEstimatorBase:TFETitle', ...
                'Text', 'dsp:system:SpectrumEstimatorBase:TFEDescription');
        end
    end
end