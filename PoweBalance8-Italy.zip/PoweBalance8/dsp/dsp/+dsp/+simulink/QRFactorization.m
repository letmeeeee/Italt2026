classdef QRFactorization < dsp.internal.QRFactorization
    % QRFactorization Factor arbitrary matrix into unitary and upper
    % triangular components
    
    %   Copyright 2019-2021 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCA>
    
    methods
        %------------------------------------------------------------------
        % Constructor
        function obj = QRFactorization(varargin)
            obj@ dsp.internal.QRFactorization(varargin{:});
        end
    end
    
    methods(Access = protected)
        %------------------------------------------------------------------
        function validateInputsImpl(~,u)
            % Validate inputs to the step method at initialization
            validateattributes(u, {'single', 'double'}, {'2d'},'','')
        end
        %------------------------------------------------------------------
        function setupImpl(obj,u)
            setupImpl@dsp.internal.QRFactorization(obj,u);
        end
        %------------------------------------------------------------------
        function N = getNumOutputsImpl(~)
            % Specify number of System outputs
            N = 3;
        end
        %------------------------------------------------------------------
        function varargout = getInputNamesImpl(~)
            % Define name of input ports (shows on block icon)
            varargout{1} = 'A';
        end
        %------------------------------------------------------------------
        function varargout = getOutputNamesImpl(~)
            % Define name of output ports (shows on block icon)
            varargout{1} = 'Q';
            varargout{2} = 'R';
            varargout{3} = 'E';
        end
        %------------------------------------------------------------------
        function flag = isInputSizeMutableImpl(~,~)
            flag = false;
        end
        %------------------------------------------------------------------
        function varargout = isOutputComplexImpl(obj)
            % Complexity propagator
            % Q and R have the same complexity as the input, E is always
            % real
            for ind = 1:getNumOutputs(obj) - 1
                varargout{ind} = propagatedInputComplexity(obj, 1);
            end
            varargout{3} = false;
        end
        %------------------------------------------------------------------
        function varargout = getOutputSizeImpl(obj)
            % Output size propagator
            inSize = propagatedInputSize(obj, 1);
            if(~isempty(inSize))
                if(strcmpi(obj.outputSize,'Economy'))
                    varargout{1} = [inSize(1) min(inSize(1),inSize(2))];
                    varargout{2} = [min(inSize(1),inSize(2)) inSize(2)]; 
                else
                    varargout{1} = [inSize(1) inSize(1)];
                    varargout{2} = inSize;
                end
                varargout{3} = [1 inSize(2)];
            end
        end
        %------------------------------------------------------------------
        function varargout = getOutputDataTypeImpl(obj)
            % Output datatype propagator
            for ind = 1:getNumOutputs(obj)
                varargout{ind} = propagatedInputDataType(obj, 1);
            end
        end
        %------------------------------------------------------------------
        function varargout = isOutputFixedSizeImpl(obj)
            flag = propagatedInputFixedSize(obj,1);
            for ind = 1:getNumOutputs(obj)
                varargout{ind} = flag;
            end
        end
        %------------------------------------------------------------------
        function val = supportsMultipleInstanceImpl(~)
            % Support in for-each subsystem
            val = true;
        end
        %------------------------------------------------------------------
        function icon = getMaskDisplayImpl(~)
            x = [ 0.4785 0.6699 0.6699 0.4785 0.4785 NaN 0.875568 0.70644 ...
                0.875568 0.875568 NaN 0.12006 0.348 0.348 0.12006 0.12006 ...
                NaN 0.424125 0.424125 0.384975 0.384975 0.424125 0.424125 ...
                0.455445 0.424125 ];
            y = [ 0.1 0.1 .7 0.7 0.1 NaN 0.1 0.7 0.7 0.1 NaN 0.1 0.1 0.7 ...
                0.7 0.1 NaN 0.335 0.375 0.375 0.425 0.425 0.465 0.4 0.335 ];
            
            iconPlotCmds = {['plot(0,0,1,1,' mat2str(x) ',' mat2str(y) ');']};
            iconTextCmds = {'text(0.5,0.9,''A(:,E) = Q R'',''horizontalAlignment'',''center'', ''verticalAlignment'', ''middle'')'};
            % 1 input (A)
            % 3 outputs (Q,R,E)
            portLabelCmds = {
                ['port_label(''input'',1,''A'');'...
                'port_label(''output'',1,''Q'');'...
                'port_label(''output'',2,''R'');'...
                'port_label(''output'',3,''E'');']
                };
            icon = [iconTextCmds;iconPlotCmds;portLabelCmds];
        end
    end
    
    methods(Static, Access = protected)
        %------------------------------------------------------------------
        function header = getHeaderImpl
            % Define header panel for System block dialog
            header = matlab.system.display.Header(...
                'dsp.simulink.QRFactorization', ...
                'ShowSourceLink',true, ...
                'Title', 'dsp:system:QRFactorization:BlockTitle', ...
                'Text', 'dsp:system:QRFactorization:BlockHeader');
        end
        %------------------------------------------------------------------
        function group = getPropertyGroupsImpl
            %Get default parameters group for this System object
            props = {matlab.system.display.internal.Property('outputSize','Description','dsp:system:QRFactorization:outputSize_MP')};
            group = matlab.system.display.Section(...
                'Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', props);
        end
    end
end
