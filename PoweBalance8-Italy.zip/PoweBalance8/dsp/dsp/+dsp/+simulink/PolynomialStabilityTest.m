classdef (StrictDefaults)PolynomialStabilityTest < matlab.System
    
    % This System object used under dsppolyfun/Polynomial stability test block.
    
    %  Copyright 2016-2021 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCA>
    
    methods
        % Constructor
        function obj = PolynomialStabilityTest(varargin)
            setProperties(obj, nargin, varargin{:});
        end
    end
    
    methods (Access=protected)
        
        function validateInputsImpl(~,u)
            validateattributes(u, {'single', 'double'}, {'2d'},'','')
        end
        
        function y = stepImpl(~,u)
            
            numChans = size(u,2);
            y = true(1,numChans);
            
            % Schur-Cohn Stability Test
            % See Proakis - Digital Signal Processing
            for index = 1:numChans
                
                a = u(:,index).';
                
                p  = length(a) - 1;
                a0 = a(1);
                
                A = a/a0;
                B = A;
                
                for m=p+1:-1:2
                    K = A(m);
                    if (abs(K) > 1)
                        y(index) = false;
                        break;
                    end
                    B(1:m) = conj(fliplr(A(1:m)));
                    A(1:m) = (A(1:m)-K*B(1:m))/(1-K*conj(K));
                end
            end
            
        end
        
        
        function val = supportsMultipleInstanceImpl(~)
            val = true;
        end
        
        %% Block Icon
        function icon = getIconImpl(~)
            icon = getString(message('dsp:system:PolynomialStabilityTest:BlockIcon'));
        end
        
        %%Propagators
        
        function cplx = isOutputComplexImpl(~)
            % Complexity propagator
            cplx = false;
        end
        
        function sz = getOutputSizeImpl(obj)
            sz_in = propagatedInputSize(obj, 1);
            sz = [1 , sz_in(2)];
        end
        
        function dt = getOutputDataTypeImpl(~)
            dt = 'logical';
        end
        
        function f = isOutputFixedSizeImpl(obj)
            f = propagatedInputFixedSize(obj,1);
        end
        
        function name = getInputNamesImpl(~)
            name = '';
        end
        
        function name = getOutputNamesImpl(~)
            name = '';
        end
        
    end
    
    %% Block header - widget grouping
    methods(Static, Access=protected)
        %------------------------------------------------------------------
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.PolynomialStabilityTest', ...
                'ShowSourceLink', false, ...
                'Title', 'dsp:system:PolynomialStabilityTest:BlockTitle',...
                'Text', 'dsp:system:PolynomialStabilityTest:BlockHeader');
        end
    end
    
end