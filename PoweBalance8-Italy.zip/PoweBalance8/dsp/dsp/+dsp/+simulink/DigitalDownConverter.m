classdef (StrictDefaults)DigitalDownConverter < dsp.DigitalDownConverter
% This class is used for the Digital Down Converter block in dspsigops

% Copyright 2021-2023 The MathWorks, Inc.

%#codegen
%#ok<*EMCA>
    
    %----------------------------------------------------------------------
    % Public methods
    %----------------------------------------------------------------------
    methods
        function obj = DigitalDownConverter(varargin)
            obj@dsp.DigitalDownConverter(varargin{:})          
        end
    end

    %----------------------------------------------------------------------
    % Protected methods
    %----------------------------------------------------------------------
    methods (Access = protected)
        %------------------------------------------------------------------
        function icon = getIconImpl(~)
            icon = getString(message('dsp:system:DigitalDownConverter:iconString'));
        end
        %------------------------------------------------------------------
        function varargout = getInputNamesImpl(obj)
            if ~strcmp(obj.Oscillator,'Input port')
                varargout{1} = '';
            else
                varargout{1} = 'In';
                varargout{2} = 'Osc';
            end
        end
        %------------------------------------------------------------------
        function varargout = getOutputNamesImpl(~)
             varargout{1} = '';
        end
    end

    methods(Static,Hidden,Access=protected)
        function groups = getPropertyGroupsImpl    
            props = {...
                matlab.system.display.internal.Property('DecimationFactor',Description='dsp:system:DigitalDownConverter:DecimationFactor_MP'), ...
                matlab.system.display.internal.Property('MinimumOrderDesign',Description='dsp:system:DigitalDownConverter:MinimumOrderDesign_MP'), ...
                matlab.system.display.internal.Property('NumCICSections', Description='dsp:system:DigitalDownConverter:NumCICSections_MP'), ...
                matlab.system.display.internal.Property('ThirdFilterOrder', Description='dsp:system:DigitalDownConverter:ThirdFilterOrder_MP'), ...                
                matlab.system.display.internal.Property('StopbandFrequencySource', Description='dsp:system:DigitalDownConverter:StopbandFrequencySource_MP'), ...
                matlab.system.display.internal.Property('Oscillator', Description='dsp:system:DigitalDownConverter:Oscillator_MP'), ...
                matlab.system.display.internal.Property('CenterFrequency', Description='dsp:system:DigitalDownConverter:CenterFrequency_MP'), ...
                matlab.system.display.internal.Property('SecondFilterOrder',Description='dsp:system:DigitalConverterBase:SecondFilterOrder_MP'), ...
                matlab.system.display.internal.Property('Bandwidth',Description='dsp:system:DigitalConverterBase:Bandwidth_MP'), ...
                matlab.system.display.internal.Property('StopbandFrequency',Description='dsp:system:DigitalConverterBase:StopbandFrequency_MP'), ...
                matlab.system.display.internal.Property('PassbandRipple',Description='dsp:system:DigitalConverterBase:PassbandRipple_MP'), ...
                matlab.system.display.internal.Property('StopbandAttenuation', Description='dsp:system:DigitalConverterBase:StopbandAttenuation_MP'), ...
                matlab.system.display.internal.Property('NumAccumulatorBits', Description='dsp:system:DigitalConverterBase:NumAccumulatorBits_MP'), ...
                matlab.system.display.internal.Property('NumQuantizedAccumulatorBits', Description='dsp:system:DigitalConverterBase:NumQuantizedAccumulatorBits_MP'), ...
                matlab.system.display.internal.Property('Dither', Description='dsp:system:DigitalConverterBase:Dither_MP'), ...
                matlab.system.display.internal.Property('NumDitherBits', Description='dsp:system:DigitalConverterBase:NumDitherBits_MP'), ...
                matlab.system.display.internal.Property('InheritSampleRate', Description='dsp:system:AbstractSampleRateEngine:InheritSampleRate_MP'), ...
                matlab.system.display.internal.Property('SampleRate',Description='dsp:system:AbstractSampleRateEngine:SampleRate_MP'), ...
            };
            
            mainS = matlab.system.display.Section(Title='Parameters', PropertyList=props);
            
            % Visualization button
            filterVis = dsp.internal.FilterVisualizationButton;
            mainS.Actions = filterVis.fvtoolAction;
            
            mainSG = matlab.system.display.SectionGroup(TitleSource='Auto', Sections=mainS);
            dtSG = matlab.system.display.internal.DataTypesGroup(mfilename('class'));
            dtSG.PropertyList{1} = matlab.system.display.internal.DataTypeProperty('FiltersInputDataType', Prefix='stageInput', Description='Stage input');            
            dtSG.PropertyList{3} = matlab.system.display.internal.DataTypeProperty('OutputDataType', Prefix='output', Description='Output');   
            groups = [mainSG, dtSG];            
        end

        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.DigitalDownConverter', ...
                ShowSourceLink=true, ...
                Title='dsp:system:DigitalDownConverter:titleString', ...
                Text='dsp:system:DigitalDownConverter:descriptionString');
        end
    end
end
