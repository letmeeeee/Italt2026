classdef (StrictDefaults)ZoomFFT < dsp.ZoomFFT
    
    % ZOOMFFT Implements zoom FFT
    % This class is used in the Zoom FFT block
    
    % Copyright 2022 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCLS>
    
    properties (Nontunable)
        % CenterFrequencyPort Specify center frequency from input port
        CenterFrequencyPort (1, 1) logical = false;
    
        % InheritFFTLength Inherit FFT Length from input dimensions
        %  Specify how to determine the FFT length. When this property is
        %  set to true, the FFT length is equal to the number of rows of
        %  the input signal divided by the decimation factor. when it is
        %  set to false, the FFT length is equal to the value of the
        %  FFtLength property.
        InheritFFTLength (1, 1) logical = true;
        %AllowArbitraryInputLength Allow arbitrary frame length for fixed-size input signals
        %  When this flag is set to false, input frames in code generation
        %  must have a length that is a multiple of the decimation factor.
        %  Using an input which doesn't satisfy the length requirement
        %  results with an error.
        %  When this flag is set to true, input size is notrestricted and 
        %  can be arbitrary, but the output may have a variable size.
        %  Use this flag for cases that require fixed frame sizes, such
        %  as code generation requirements where the output size must be
        %  fixed. The default value is 'false'.
        AllowArbitraryInputLength (1,1) logical = false;
    end
    
    properties (Constant, Hidden)
        % CenterFrequencySet is used to setup the choices for CenterFrequency
        CenterFrequencySet = matlab.system.SourceSet({'PropertyOrInput', ...
            'SystemBlock', 'CenterFrequencyPort', 1, 'Fc'});
    end
    
    methods
        %CONSTRUCTOR
        function obj = ZoomFFT(varargin)
            setProperties(obj, nargin, varargin{:});
        end
    end

    methods(Access = protected)

        function cacheFFTLength(obj)
            if isFFTAutoMode(obj)
              obj.pNFFT = [];
            else
              obj.pNFFT = obj.FFTLength; 
            end
        end
        
        function flag = isFFTAutoMode(obj)
            flag = obj.InheritFFTLength;
        end
        
        %%Propagators
        
        function o = isOutputComplexImpl(~)
            o = true;
        end
        
        function sz = getOutputSizeImpl(obj)

            sz_in = propagatedInputSize(obj, 1);
            if ~isempty(sz_in)
                if isFFTAutoMode(obj)
                    nfft = sz_in(1) / obj.DecimationFactor;
                else
                    nfft = obj.FFTLength;
                end
                fixedInput = propagatedInputFixedSize(obj, 1);
                if isempty(fixedInput)
                    fixedInput = false;
                end
                arbLabel = message('dsp:blkprm_prompts:AllowArbitraryFixedInput_MP').string;
                coder.internal.errorIf((obj.AllowArbitraryInputLength == false) && ...
                    (mod(sz_in(1),obj.DecimationFactor)~=0) && ...
                    fixedInput, ...
                    'dsp:system:ZoomFFT:inputSizeBlock', ...
                    sz_in(1),obj.DecimationFactor,arbLabel);
                sz = [ceil(nfft) sz_in(2)];
            else
                sz = [];
            end
        end
        
        function dt = getOutputDataTypeImpl(obj)
            dt = propagatedInputDataType(obj, 1);
        end
        
        function isFixedOutput = isOutputFixedSizeImpl(obj)
            % If varsize input or arbitrary input allowed =>varsize output, otherwise fixed
            isFixedOutput = isFixedSizeOutput(obj);
        end
        
        function name = getInputNamesImpl(obj)
            if obj.CenterFrequencyPort
                name = 'x';
            else
                name = '';
            end
        end
        
        function name = getOutputNamesImpl(~)
            name = '';
        end
        
        function validateInputsImpl(obj,varargin)
            u = varargin{1};
            if isempty(u)
                return;
            end
            validateattributes(u, {'single', 'double'}, {'2d'},'','')
            if ~isempty(coder.target)
                coder.internal.errorIf(~obj.AllowArbitraryInputLength &&...
                    mod( size(u,1),obj.DecimationFactor)~=0 && ...
                    propagatedInputFixedSize(obj,1), ...
                    'dsp:system:ZoomFFT:inputSizeBlock', ...
                    size(u,1),obj.DecimationFactor);
            end
            if ~isFFTAutoMode(obj)
                % We do not allow input wrapping/truncating for FFT
                coder.internal.errorIf(...
                    (obj.FFTLength < size(u,1)/ obj.DecimationFactor), ...
                    'dsp:system:ZoomFFT:InvalidFFTLength');
            end

            if obj.NumChannels ~= -1 && obj.NumChannels ~= 0
                coder.internal.errorIf(size(u,2) ~= obj.NumChannels, ['dsp:system',...
                    ':Shared:numChannels']);
            end
        end
        
        function flag = isInactivePropertyImpl(obj,prop)
           flag = false;
           if strcmp(prop,'FFTLength')
              flag =obj.InheritFFTLength;
           end
        end
        
        function dt = getTunablePropertiesSpecificationImpl(obj,~)
            dt = propagatedInputDataType(obj,1);
        end
        
        function flag = supportsMultipleInstanceImpl(obj)
           % Multiple instances are allowed only if the outputsize is fixed
            flag = isFixedSizeOutput(obj); 
        end
        
        function flag = isInputSizeMutableImpl(~,~)
            % input arg may change size after locked
            flag = true;
        end
        function isFixedOutput = isFixedSizeOutput(obj)
            % Varsize output if input is varsize or arbitrary input is allowed
            isFixedOutput = propagatedInputFixedSize(obj,1) && ~obj.AllowArbitraryInputLength;
        end        
        function flag = isInputComplexityMutableImpl(~,~)
            % input arg may change complexity after locked
            flag = true;
        end
        
        %% Block Icon
        function icon = getIconImpl(~)
            icon = getString(message('dsp:system:ZoomFFT:BlockIcon'));
        end
    end
    
    %% Block header - widget grouping
    methods(Static, Access=protected)
        
        function group = getPropertyGroupsImpl
            % Modify order of display
            DecimationS =  matlab.system.display.Section(...
                Title= getString(message('dsp:system:Shared:Parameters')), ...
                PropertyList={matlab.system.display.internal.Property('DecimationFactor', Description='dsp:system:ZoomFFT:DecimationFactor_MP')});
            
             CFS =  matlab.system.display.Section(...
                Title='', ...
                PropertyList={matlab.system.display.internal.Property('CenterFrequencyPort', Description='dsp:system:ZoomFFT:CenterFrequencyPort_MP'),...
                              matlab.system.display.internal.Property('CenterFrequency', Description='dsp:system:ZoomFFT:CenterFrequency_MP')});
            
             FFTS =  matlab.system.display.Section(...
                Title='', ...
                PropertyList={matlab.system.display.internal.Property('InheritFFTLength', Description='dsp:system:ZoomFFT:InheritFFTLength_MP'),...
                              matlab.system.display.internal.Property('FFTLength', Description='dsp:system:ZoomFFT:FFTLength_MP')});
            
            SampleRateS  =  matlab.system.display.Section(...
                Title='',...
                PropertyList={matlab.system.display.internal.Property('InheritSampleRate', Description='dsp:system:ZoomFFT:InheritSampleRate_MP'),...
                              matlab.system.display.internal.Property('SampleRate', Description='dsp:system:ZoomFFT:SampleRate_MP')});
            
            ArbS=matlab.system.display.Section(...
                Title='', ...
                PropertyList={matlab.system.display.internal.Property('AllowArbitraryInputLength', Description='dsp:system:ZoomFFT:AllowArbsize_MP')});

            group = [DecimationS CFS FFTS SampleRateS ArbS];
        end
        
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.ZoomFFT', ...
                ShowSourceLink= true, ...
                Title='dsp:system:ZoomFFT:BlockTitle',...
                Text='dsp:system:ZoomFFT:BlockHeader');
        end
    end
    
    
end