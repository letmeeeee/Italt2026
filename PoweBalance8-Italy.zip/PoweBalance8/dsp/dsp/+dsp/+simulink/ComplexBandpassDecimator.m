classdef ComplexBandpassDecimator < dsp.ComplexBandpassDecimator & dsp.simulink.mixin.FilterResponseVisualizable
    %ComplexBandpassDecimator One-sided bandpass decimator
    % This class is used in the Complex Bandpass Decimator block
    
    % Copyright 2016-2022 The MathWorks, Inc.
    
    %#codegen
    
    properties (Nontunable)
        % CenterFrequencyPort Specify center frequency from input port
        CenterFrequencyPort (1, 1) logical = false;

        %AllowArbitraryInputLength Allow arbitrary input length in Codegen
        %  When this flag is set to false, input frames in code generation
        %  must have a length that is a multiple of the decimation factor.
        %  Using an input which doesn't satisfy the length requirement
        %  results with an error.
        %  When this flag is set to true, input size is notrestricted and 
        %  can be arbitrary, but the output may have a variable size.
        %  Use this flag for cases that require fixed frame sizes, such
        %  as code generation requirements where the output size must be
        %  fixed. The default value is 'false'.
        AllowArbitraryInputLength (1,1) logical = false;
    end
    
    properties (Constant, Hidden)
        % CenterFrequencySet is used to setup the choices for
        % CenterFrequency
        CenterFrequencySet = matlab.system.SourceSet({'PropertyOrInput',...
            'SystemBlock', 'CenterFrequencyPort', 1, 'Fc'});
    end
    
    methods
        function obj = ComplexBandpassDecimator(varargin)
            obj@dsp.ComplexBandpassDecimator(varargin{:})
        end
    end
    
    methods (Access = protected)
        function validateInputsImpl(obj,varargin)
            u = varargin{1};
            if isempty(u)
                return;
            end

            validateattributes(u, {'single', 'double'}, {'2d'},'','')
            
            if ~isempty(coder.target)
                if strcmp(obj.Specification,'Decimation factor')
                    D = obj.DecimationFactor;
                elseif strcmp(obj.Specification,'Bandwidth')
                    D = floor(obj.SampleRate ...
                    / (obj.Bandwidth + obj.TransitionWidth));
                else
                    D = obj.DecimationFactor;
                end
                coder.internal.errorIf(~obj.AllowArbitraryInputLength &&...
                    mod( size(u,1),D)~=0 && ...
                    propagatedInputFixedSize(obj,1), ...
                    'dsp:system:ComplexBandpassDecimator:inputSizeBlock', ...
                    size(u,1),D);
            end
            
            if obj.NumChannels ~= -1 && obj.NumChannels ~= 0
                coder.internal.errorIf(size(u,2) ~= obj.NumChannels, ['dsp:system',...
                    ':Shared:numChannels']);
            end
        end
        
        function name = getInputNamesImpl(obj)
            if obj.CenterFrequencyPort
                name = 'x';
            else
                name = '';
            end
        end
        
        function name = getOutputNamesImpl(~)
            name = '';
        end
        
        function crossValidateProperties(obj)
            crossValidateProperties@dsp.ComplexBandpassDecimator(obj);
            coder.internal.errorIf(strcmp(obj.Specification,'Bandwidth') && obj.InheritSampleRate,...
                'dsp:system:ComplexBandpassDecimator:FsInheritedBWMode');
        end

        % Block Icon
        function icon = getIconImpl(~)
            icon = getString(message('dsp:system:ComplexBandpassDecimator:Icon'));
        end
        
        %Propagators
        
        % Since center frequency is tunable, the output must be complex
        function isCplx = isOutputComplexImpl(~)
            isCplx = true;
        end
        
        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end

        function isFixedOutput = isFixedSizeOutput(obj)
            % Varsize output if input is varsize or arbitrary input is allowed
            isFixedOutput = propagatedInputFixedSize(obj,1) && ~obj.AllowArbitraryInputLength;
        end

        function sz = getOutputSizeImpl(obj)
            in_sz = propagatedInputSize(obj, 1);
            if ~isempty(in_sz)
                if strcmp(obj.Specification,'Bandwidth')
                    coder.internal.errorIf(strcmp(obj.Specification,'Bandwidth') ...
                        && obj.InheritSampleRate,...
                        'dsp:system:ComplexBandpassDecimator:FsInheritedBWMode');
                    
                    Fs = obj.SampleRate;
                    D = floor(Fs / (obj.Bandwidth + obj.TransitionWidth) );
                else
                    D = obj.DecimationFactor;
                end
                fixedInput = propagatedInputFixedSize(obj, 1);
                if isempty(fixedInput)
                    fixedInput = false;
                end
                arbLabel = message('dsp:blkprm_prompts:AllowArbitraryFixedInput_MP').string;
                coder.internal.errorIf((obj.AllowArbitraryInputLength == false) && ...
                    (mod(in_sz(1),D)~=0) && ...
                    fixedInput, ...
                    'dsp:system:ComplexBandpassDecimator:inputSizeBlock', ...
                    in_sz(1),D,arbLabel);
                sz = [ceil(in_sz(1)/D) in_sz(2)];
            else
                sz = [];
            end
        end
        
        function dt = getOutputDataTypeImpl(obj)
            dt = propagatedInputDataType(obj, 1);
        end
        
        function isFixedOutput = isOutputFixedSizeImpl(obj)
            % If varsize input or arbitrary input allowed =>varsize output, otherwise fixed
            isFixedOutput = isFixedSizeOutput(obj);
        end
        
        function dt = getTunablePropertiesSpecificationImpl(obj,~)
            dt = propagatedInputDataType(obj,1);
        end
        
        function val = supportsMultipleInstanceImpl(obj)
            % Multiple instances are allowed only if the outputsize is fixed
            val = isFixedSizeOutput(obj);
        end
    end
    
    % Block header - widget grouping
    methods(Static, Access=protected)
        function groups = getPropertyGroupsImpl
            props = {...
                matlab.system.display.internal.Property('Specification','Description','dsp:system:ComplexBandpassDecimator:Specification_MP'), ...
                matlab.system.display.internal.Property('DecimationFactor','Description','dsp:system:ComplexBandpassDecimator:DecimationFactor_MP'), ...
                matlab.system.display.internal.Property('Bandwidth','Description','dsp:system:ComplexBandpassDecimator:Bandwidth_MP'), ...
                matlab.system.display.internal.Property('CenterFrequencyPort','Description','dsp:system:ComplexBandpassDecimator:CenterFrequencyPort_MP'), ...
                matlab.system.display.internal.Property('CenterFrequency','Description','dsp:system:ComplexBandpassDecimator:CenterFrequency_MP'), ...
                matlab.system.display.internal.Property('StopbandAttenuation','Description','dsp:system:ComplexBandpassDecimator:StopbandAttenuation_MP'), ...
                matlab.system.display.internal.Property('PassbandRipple','Description','dsp:system:ComplexBandpassDecimator:PassbandRipple_MP'), ...
                matlab.system.display.internal.Property('TransitionWidth','Description','dsp:system:ComplexBandpassDecimator:TransitionWidth_MP'), ...
                matlab.system.display.internal.Property('MinimizeComplexCoefficients','Description','dsp:system:ComplexBandpassDecimator:MinimizeComplexCoefficients_MP'), ...
                matlab.system.display.internal.Property('MixToBaseband','Description','dsp:system:ComplexBandpassDecimator:MixToBaseband_MP'), ...
                matlab.system.display.internal.Property('InheritSampleRate','Description','dsp:system:AbstractSampleRateEngine:InheritSampleRate_MP'), ...
                matlab.system.display.internal.Property('SampleRate','Description','dsp:system:AbstractSampleRateEngine:SampleRate_MP'), ...
                matlab.system.display.internal.Property('AllowArbitraryInputLength','Description','dsp:blkprm_prompts:AllowArbitraryFixedInput_MP')};
            
            mainS = matlab.system.display.Section('Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', props);
            % View response button
            filterVis = dsp.simulink.internal.FilterResponseVisualizationButton;
            % Info button
            filterInfo = dsp.simulink.internal.FilterInfoButton;
            
            mainS.Actions = [filterVis.visualizeAction , filterInfo.infoAction];
            mainSG = matlab.system.display.SectionGroup('TitleSource', 'Auto', ...
                'Sections', mainS);
            groups = mainSG;
        end
        
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.ComplexBandpassDecimator', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:system:ComplexBandpassDecimator:Title',...
                'Text', 'dsp:system:ComplexBandpassDecimator:Text');
        end
    end
    
    methods (Hidden)        
        function [flag,errID] = isFVtoolSupported(obj)
            % Method used in visualize button on block
            flag  = true;
            errID = '';
            if obj.CenterFrequencyPort
                flag = false;
                errID = 'dsp:system:ComplexBandpassDecimator:fvtoolButtonDisabled';
            elseif  obj.InheritSampleRate
                flag = false;
                errID  = 'dsp:system:Shared:fvtoolButtonInheritSRText';
            end
        end
        
        function filters = getVisualizationFilters(obj)
            % Used to return filters that will be shown when the visualize
            % filter response button is clicked.
            filters = getFilters(obj);
        end
                        
        function infoText = getFilterInfo(obj)
            % Used to return the info text that will be shown when the
            % filter info for the block is shown
            if obj.CenterFrequencyPort
                infoText = getString(message('dsp:system:ComplexBandpassDecimator:InfoDisabledCF'));
            elseif obj.InheritSampleRate
                infoText = getString(message('dsp:system:ComplexBandpassDecimator:InfoDisabledFs'));
            else
                infoText = info(obj);
            end
        end
    end
end
