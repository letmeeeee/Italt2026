classdef FilterResponseVisualizable < handle
%FILTERRESPONSEVISULIZABLE Define the interface for simulink blocks that
%have a 'View Filter Response button'

    % Copyright 2022 The MathWorks, Inc.

    %#codegen

    methods (Hidden)
        function filters = getVisualizationFilters(this)
            % Used to return filters that will be shown when the visualize
            % filter response button is clicked.
            filters = this;
        end

        function legend = getVisualizationLegend(this,blkName) %#ok<INUSD>
            % Used to return the legend that will be shown when the
            % visualize filter response plot is shown
            legend = {blkName};
        end
    end
end