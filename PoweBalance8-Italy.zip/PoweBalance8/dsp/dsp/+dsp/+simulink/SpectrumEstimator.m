classdef (StrictDefaults)SpectrumEstimator < dsp.SpectrumEstimator
% This class is internally used for the Spectrum Estimator block

%#codegen
%#ok<*EMCLS>

%   Copyright 2015-2022 The MathWorks, Inc.

    properties(Nontunable)
        % Output frequency vector
        OutputFrequencyVector (1, 1) logical = false;
        % Output RBW
        OutputRBW (1, 1) logical = false;

        % Set FFT lengths smaller than 1024 to 1024
        AdjustFFTLength (1, 1) logical = false;
        % ForgettingFactorPort Specify forgetting factor from input port
        ForgettingFactorPort (1, 1) logical = false;
    end

    properties (Access = private)
        % Used internally to cache sample rate
        pSR;
        % Cache frequency vector
        pFreq;
        % Cache RBW
        pRBW;
        % Count number of received frames. Used to ignore latency frames
        pFrameCounter = 0;
        % Latency (frames)
        % System latency in frames. The first pFrameDelay frames must be ignored
        % because they are all-zeros (initial conditions) caused by non-zero
        % multirate latency
        pFrameDelay = 0;
    end

    properties (Access = private, Nontunable)
        % Cache output port indices
        pMinHoldPort
        pFreqPort
        pRBWPort
    end

    properties (Constant, Hidden)
        ForgettingFactorSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.SpectrumEstimatorPolicy('SystemBlock', 'ForgettingFactorPort', 1, 'lambda'), ...
            {'Property','MATLAB','ForgettingFactorPort'})
    end

    methods
        function obj = SpectrumEstimator(varargin)
            %SpectrumEstimator   Construct the SpectrumEstimator class.
            obj@dsp.SpectrumEstimator(varargin{:})
        end
    end

    methods(Access = protected)

        function validateForgettingFactor(~,val)
            validateattributes(val,...
                {'double','single'},...
                {'real','scalar','finite','>=',0,'<=',1},...
                '','ForgettingFactor');
        end

        function o = getNumOutputsImpl(obj)
            o = getNumOutputsImpl@dsp.SpectrumEstimator(obj) + obj.OutputFrequencyVector + obj.OutputRBW;
        end

        function name  = getInputNamesImpl(obj)
            if  ~strcmp(obj.AveragingMethod,'Running') && obj.ForgettingFactorPort
                name = 'x';
            else
                name = '';
            end
        end

        function varargout  = getOutputNamesImpl(obj)
            setName = false;
            ind = 2;
            if obj.OutputMaxHoldSpectrum
                varargout{ind} = 'P_max';
                ind = ind + 1;
                setName = true;
            end

            if obj.OutputMinHoldSpectrum
                varargout{ind} = 'P_min';
                ind = ind + 1;
                setName = true;
            end
            if obj.OutputFrequencyVector
                varargout{ind} = 'F';
                ind = ind + 1;
                setName = true;
            end

            if obj.OutputRBW
                varargout{ind} = 'RBW';
                setName = true;
            end

            if setName
                varargout{1} = 'P';
            else
                varargout{1} = '';
            end
        end

        function setupImpl(obj,x)

            setupImpl@dsp.SpectrumEstimator(obj,x);

            coder.extrinsic('dsp.simulink.SpectrumEstimator.initializeBlock');

            [Fs,obj.pFrameDelay] = coder.const(@dsp.simulink.SpectrumEstimator.initializeBlock);

            if obj.InheritSampleRate
                obj.pSR = Fs;
            end

            if strcmp(obj.FFTLengthSource,'Auto')
                if fixFFTLength(obj)
                    Npts = max(size(x,1),1024);
                else
                    Npts = size(x,1);
                end
            else
                Npts = obj.FFTLength;
            end

            coder.extrinsic('dsp.internal.SpectrumEstimatorBase.computeFrequencyVector');

            % Cache frequency vector and RBW
            if obj.OutputFrequencyVector
                CenterDC = strcmp(obj.FrequencyRange,'centered');
                isOneSided =  strcmp(obj.FrequencyRange,'onesided');
                Fs         = getSampleRate(obj);
                obj.pFreq = Fs * coder.const(@obj.computeFrequencyVector , CenterDC ,isOneSided ,  1 , Npts , class(x));
            end
            if obj.OutputRBW
                obj.pRBW   = computeRBW(obj,getSampleRate(obj));
            end

            % Cache output port indices
            indMaxHold = 2;
            if obj.OutputMaxHoldSpectrum
                obj.pMinHoldPort = indMaxHold + 1;
            else
                obj.pMinHoldPort = indMaxHold;
            end

            if obj.OutputMinHoldSpectrum
                obj.pFreqPort = obj.pMinHoldPort + 1;
            else
                obj.pFreqPort = obj.pMinHoldPort;
            end

            if obj.OutputFrequencyVector
                obj.pRBWPort = obj.pFreqPort + 1;
            else
                obj.pRBWPort = obj.pFreqPort;
            end

            obj.pFrameCounter = cast(0,class(x));

        end

        function flag = fixFFTLength(obj)
            % FFT lengths smaller than 1024 are set to 1024 for certain block
            % modes
            flag = strcmp(obj.Method,'Welch') && obj.AdjustFFTLength;
        end

        function varargout = stepImpl(obj,x)

            if obj.pFrameCounter >= obj.pFrameDelay

                if obj.OutputMaxHoldSpectrum
                    if obj.OutputMinHoldSpectrum
                        [P,maxHold,minHold] = stepImpl@dsp.SpectrumEstimator(obj,x);
                    else
                        [P,maxHold] = stepImpl@dsp.SpectrumEstimator(obj,x);
                    end
                else
                    if obj.OutputMinHoldSpectrum
                        [P,minHold] = stepImpl@dsp.SpectrumEstimator(obj,x);
                    else
                        P = stepImpl@dsp.SpectrumEstimator(obj,x);
                    end
                end

                varargout{1} = P;
                indMaxHold = 2;

                if obj.OutputMaxHoldSpectrum
                    varargout{indMaxHold} = maxHold;
                end

                if obj.OutputMinHoldSpectrum
                    varargout{obj.pMinHoldPort} = minHold;
                end

            else % input is all-zeros (latency)
                obj.pFrameCounter = obj.pFrameCounter + 1;
                F = getFrequencyVector(obj);
                if strcmp(obj.PowerUnits,'Watts')
                    P = zeros(length(F),getNumberOfChannels(obj),getDatatype(obj));
                else
                    P = -Inf * ones(length(F),getNumberOfChannels(obj),getDatatype(obj));
                end

                varargout{1} = P;
                if obj.OutputMaxHoldSpectrum
                    varargout{2} =  P;
                end
                if obj.OutputMinHoldSpectrum
                    varargout{obj.pMinHoldPort} = P;
                end
            end

            if obj.OutputFrequencyVector
                varargout{obj.pFreqPort} = obj.pFreq;
            end

            if obj.OutputRBW
                varargout{obj.pRBWPort} = obj.pRBW;
            end

        end

        function s = saveObjectImpl(obj)
            s = saveObjectImpl@dsp.SpectrumEstimator(obj);
            if isLocked(obj)
                if obj.OutputFrequencyVector
                    s.pFreq      = obj.pFreq;
                end
                if obj.OutputRBW
                    s.pRBW       = obj.pRBW;
                end
                s.pSR = obj.pSR;
                s.pMinHoldPort  = obj.pMinHoldPort;
                s.pFreqPort     = obj.pFreqPort;
                s.pRBWPort      = obj.pRBWPort;
                s.pFrameCounter = obj.pFrameCounter;
                s.pFrameDelay   = obj.pFrameDelay;
            end
        end

        function loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                if s.OutputFrequencyVector
                    obj.pFreq = s.pFreq;
                end
                if s.OutputRBW
                    obj.pRBW = s.pRBW;
                end
                obj.pSR            = s.pSR;
                obj.pMinHoldPort   = s.pMinHoldPort;
                obj.pFreqPort      = s.pFreqPort;
                obj.pRBWPort       = s.pRBWPort;
                obj.pFrameCounter  = s.pFrameCounter;
                obj.pFrameDelay    = s.pFrameDelay;
            end
            loadObjectImpl@dsp.SpectrumEstimator(obj,s,wasLocked);
        end

        % Propagators
        function varargout = isOutputComplexImpl(~)
            varargout{1} = false;
            varargout{2} = false;
            varargout{3} = false;
            varargout{4} = false;
            varargout{5} = false;
        end
        %------------------------------------------------------------------
        function varargout = getOutputSizeImpl(obj)
            sz =  getOutputSizeImpl@dsp.SpectrumEstimator(obj);
            varargout{1} = sz;
            ind = 2;

            if obj.OutputMaxHoldSpectrum
                varargout{ind} = sz;
                ind = ind + 1;
            end

            if obj.OutputMinHoldSpectrum
                varargout{ind} = sz;
                ind = ind + 1;
            end

            if obj.OutputFrequencyVector
                varargout{ind} = [sz(1) 1];
                ind = ind + 1;
            end

            if obj.OutputRBW
                varargout{ind} = [1 1];
            end

        end
        %------------------------------------------------------------------
        function varargout = getOutputDataTypeImpl(obj)
            varargout{1}  = propagatedInputDataType(obj,1);
            varargout{2}  = propagatedInputDataType(obj,1);
            varargout{3}  = propagatedInputDataType(obj,1);
            varargout{4}  = propagatedInputDataType(obj,1);
            varargout{5}  = propagatedInputDataType(obj,1);
        end
        %------------------------------------------------------------------
        function varargout = isOutputFixedSizeImpl(~)
            varargout{1} = true;
            varargout{2} = true;
            varargout{3} = true;
            varargout{4} = true;
            varargout{5} = true;
        end
        %------------------------------------------------------------------
        function Fs = getSampleRate(obj)

            coder.extrinsic('dsp.simulink.SpectrumEstimator.initializeBlock');

            if obj.InheritSampleRate
                if isempty(coder.target)
                    if ~isempty(obj.pSR)
                        Fs = obj.pSR;
                    else
                        Fs = 1;
                    end
                else
                    Fs = coder.const(obj.initializeBlock());
                end
            else
                Fs = obj.SampleRate;
            end
        end
        %------------------------------------------------------------------
        function flag = isInactivePropertyImpl(obj, prop)
            flag = isInactivePropertyImpl@dsp.SpectrumEstimator(obj, prop);
            switch prop
                case 'AdjustFFTLength'
                    flag = strcmp(obj.FFTLengthSource,'Property');
            end
        end
    end

    methods (Static, Hidden)
        function [Fs,delayFrames] = initializeBlock()
            % Compute Fs and buffer latency based on block and model settings
            computeFs = true;
            bufferBlkName = 'Buffer';
            checkRBW = true;
            blk = get_param(gcbh,'Parent');
            [Fs,delayFrames] = dsp.internal.initializeSpectrumBlock(blk , checkRBW, computeFs , bufferBlkName);
        end
    end

    methods (Static, Access = protected)
        function group = getPropertyGroupsImpl
            % Modify order of display
            props = {...
                matlab.system.display.internal.Property('Method','Description','dsp:system:SpectrumEstimatorBase:Method_MP'), ...
                matlab.system.display.internal.Property('NumTapsPerBand','Description','dsp:system:SpectrumEstimatorBase:NumTapsPerBand_MP'), ...
                matlab.system.display.internal.Property('AveragingMethod','Description','dsp:system:SpectrumEstimatorBase:AveragingMethod_MP'), ...
                matlab.system.display.internal.Property('SpectralAverages','Description','dsp:system:SpectrumEstimatorBase:SpectralAverages_MP'), ...
                matlab.system.display.internal.Property('ForgettingFactorPort','Description','dsp:system:SpectrumEstimatorBase:ForgettingFactorPort_MP'), ...
                matlab.system.display.internal.Property('ForgettingFactor','Description','dsp:system:SpectrumEstimatorBase:ForgettingFactor_MP'), ...
                matlab.system.display.internal.Property('FFTLengthSource','Description','dsp:system:SpectrumEstimatorBase:FFTLengthSource_MP'), ...
                matlab.system.display.internal.Property('FFTLength','Description','dsp:system:SpectrumEstimatorBase:FFTLength_MP'), ...
                matlab.system.display.internal.Property('AdjustFFTLength','Description','dsp:system:SpectrumEstimatorBase:AdjustFFTLength_MP'), ...
                matlab.system.display.internal.Property('Window','Description','dsp:system:SpectrumEstimatorBase:Window_MP'), ...
                matlab.system.display.internal.Property('SidelobeAttenuation','Description','dsp:system:SpectrumEstimatorBase:SidelobeAttenuation_MP'), ...
                matlab.system.display.internal.Property('FrequencyRange','Description','dsp:system:SpectrumEstimatorBase:FrequencyRange_MP'), ...
                matlab.system.display.internal.Property('SpectrumType','Description','dsp:system:SpectrumEstimatorBase:SpectrumType_MP'), ...
                matlab.system.display.internal.Property('PowerUnits','Description','dsp:system:SpectrumEstimatorBase:PowerUnits_MP'), ...
                matlab.system.display.internal.Property('ReferenceLoad','Description','dsp:system:SpectrumEstimatorBase:ReferenceLoad_MP'), ...
                matlab.system.display.internal.Property('OutputMaxHoldSpectrum','Description','dsp:system:SpectrumEstimatorBase:OutputMaxHoldSpectrum_MP'), ...
                matlab.system.display.internal.Property('OutputMinHoldSpectrum','Description','dsp:system:SpectrumEstimatorBase:OutputMinHoldSpectrum_MP'), ...
                matlab.system.display.internal.Property('OutputFrequencyVector','Description','dsp:system:SpectrumEstimatorBase:OutputFrequencyVector_MP'), ...
                matlab.system.display.internal.Property('OutputRBW','Description','dsp:system:SpectrumEstimatorBase:OutputRBW_MP'), ...
                matlab.system.display.internal.Property('InheritSampleRate', Description='dsp:system:AbstractSampleRateEngine:InheritSampleRate_MP'), ...
                matlab.system.display.internal.Property('SampleRate',Description='dsp:system:AbstractSampleRateEngine:SampleRate_MP')};

            group =  matlab.system.display.Section(...
                'Title', 'Parameters', ...
                'PropertyList', props);
        end
        %------------------------------------------------------------------
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header('dsp.simulink.SpectrumEstimator', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:system:SpectrumEstimatorBase:SpectrumEstimatorTitle',...
                'Text','dsp:system:SpectrumEstimatorBase:SpectrumEstimatorDescription');
        end
    end
end