classdef ParametricEQFilter < dsp.internal.ParametricEQFilterBase
    % This class is used for the Parametric EQ Filter block in dspfdesign

    % Copyright 2017-2020 The MathWorks, Inc.

    %#codegen
    %#ok<*EMCA>
    properties(Nontunable)
        %BandwidthPort Specify bandwidth from input port
        BandwidthPort (1, 1) logical = false;
        %CenterFrequencyPort Specify center frequency from input port
        CenterFrequencyPort (1, 1) logical = false;
        %QualityFactorPort Specify quality factor from input port
        QualityFactorPort (1, 1) logical = false;
        %PeakGainPort Specify gain from input port
        PeakGainPort (1, 1) logical = false;
        %PeakGaindBPort Specify gain (dB) from input port
        PeakGaindBPort (1, 1) logical = false;
        %BandwidthCoefficientPort Specify bandwidth coefficient from input port
        BandwidthCoefficientPort (1, 1) logical = false;
        %CenterFrequencyCoefficientPort Specify center frequency coefficient from input port
        CenterFrequencyCoefficientPort (1, 1) logical = false;
    end

    properties (Constant, Hidden)
        BandwidthSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.ParametricEQFilterPolicy('SystemBlock', 'BandwidthPort', 1, 'BW'), ...
            {'Property','MATLAB','BandwidthPort'})
        CenterFrequencySet = matlab.system.SourceSet( ...
            dsp.simulink.internal.ParametricEQFilterPolicy('SystemBlock', 'CenterFrequencyPort', 2, 'Fc'), ...
            {'Property','MATLAB','CenterFrequencyPort'})
        PeakGaindBSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.ParametricEQFilterPolicy('SystemBlock', 'PeakGaindBPort', 3, 'PGaindB'), ...
            {'Property','MATLAB','PeakGaindBPort'})

        BandwidthCoefficientSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.ParametricEQFilterPolicy('SystemBlock', 'BandwidthCoefficientPort', 4, 'BWCoeff'), ...
            {'Property','MATLAB','BandwidthCoefficientPort'})
        CenterFrequencyCoefficientSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.ParametricEQFilterPolicy('SystemBlock', 'CenterFrequencyCoefficientPort', 5, 'FcCoeff'), ...
            {'Property','MATLAB','CenterFrequencyCoefficientPort'})
        PeakGainSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.ParametricEQFilterPolicy('SystemBlock', 'PeakGainPort', 6, 'PGain'), ...
            {'Property','MATLAB','PeakGainPort'})

        QualityFactorSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.ParametricEQFilterPolicy('SystemBlock', 'QualityFactorPort', 7, 'Q'), ...
            {'Property','MATLAB','QualityFactorPort'})
    end
    %----------------------------------------------------------------------
    % Public Methods
    %----------------------------------------------------------------------
    methods
        function obj = ParametricEQFilter(varargin)
            obj@dsp.internal.ParametricEQFilterBase(varargin{:});
        end

        function value = getQualityFactor(obj)

            if obj.QualityFactorPort && obj.QualityFactor==0
                % if quality Factor is coming from an input port initially it
                % will be zero. Zero is not a valid value fro Quality Factor.
                % Hence setting it to a valid value;
                value = 5;
            else
                value = getQualityFactor@dsp.internal.ParametricEQFilterBase(obj);
            end
        end
    end

    %----------------------------------------------------------------------
    % Protected Methods
    %----------------------------------------------------------------------

    methods (Access=protected)

        function validateInputsImpl(obj,varargin)
            validateInputsImpl@dsp.internal.ParametricEQFilterBase(obj,varargin{:});
        end

        %%Propagators
        function varargout = isOutputComplexImpl(obj)
            % Complexity propagator
            for ind = 1:getNumOutputs(obj)
                varargout{ind} = propagatedInputComplexity(obj, 1);
            end
        end

        function varargout = getOutputSizeImpl(obj)
            % Output size propagator
            for ind = 1:getNumOutputs(obj)
                varargout{ind} = propagatedInputSize(obj, 1);
            end
        end

        function varargout = getOutputDataTypeImpl(obj)
            % Output datatype propagator
            for ind = 1:getNumOutputs(obj)
                varargout{ind} = propagatedInputDataType(obj, 1);
            end
        end

        function varargout = isOutputFixedSizeImpl(obj)
            flag = propagatedInputFixedSize(obj,1);
            for ind = 1:getNumOutputs(obj)
                varargout{ind} = flag;
            end
        end

        % Input/Output port labels
        function name = getOutputNamesImpl(~)
            name = '';
        end

        function varargout = getInputNamesImpl(obj)
            if ((obj.BandwidthPort || obj.CenterFrequencyPort || obj.PeakGaindBPort) && strcmp(obj.Specification,'Bandwidth and center frequency')) || ...
                    ((obj.BandwidthCoefficientPort || obj.CenterFrequencyCoefficientPort || obj.PeakGainPort) && strcmp(obj.Specification,'Coefficients')) || ...
                    ((obj.QualityFactorPort || obj.CenterFrequencyPort) && strcmp(obj.Specification,'Quality factor and center frequency'))
                varargout{1} = 'x';
            else
                varargout{1} = '';
            end
        end

        function icon = getIconImpl(~)
            % MATLAB system block icon
            icon = getString(message(...
                'dsp:system:ParametricEQFilter:BlockIcon'));
        end
    end
    %----------------------------------------------------------------------
    % Static hidden methods
    %----------------------------------------------------------------------
    methods(Static,Hidden)
        function props = getDisplayPropertiesImpl()
            props = {...
                'Specification',...
                'BandwidthPort', ...
                'Bandwidth', ...
                'CenterFrequencyPort', ...
                'CenterFrequency', ...
                'BandwidthCoefficientPort', ...
                'BandwidthCoefficient', ...
                'PeakGaindBPort', ...
                'PeakGaindB', ...
                'CenterFrequencyCoefficientPort',...
                'CenterFrequencyCoefficient',...
                'QualityFactorPort', ...
                'QualityFactor', ...
                'PeakGainPort', ...
                'PeakGain', ...
                'InheritSampleRate', ...
                'SampleRate'};
        end

        function checkVal(Q)
            coder.internal.errorIf(~isnumeric(Q) || ~isscalar(Q) ||...
                ~isreal(Q) || Q < 0, ['dsp:system',...
                ':NotchPeakFilter:QFactor']);
        end
    end

    %--------------------------------------------------------------------------
    % Static Protected methods
    %--------------------------------------------------------------------------


    methods(Static, Access=protected)
        function mainS = getPropertyGroupsImpl
            %Get default parameters group for this System object
            props = dsp.simulink.ParametricEQFilter.getDisplayPropertiesImpl;
            mainS = matlab.system.display.Section(...
                'Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', props);

            filterVis = dsp.internal.FilterVisualizationButton;
            mainS.Actions = filterVis.fvtoolAction;
        end

        %------------------------------------------------------------------
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.ParametricEQFilter', ...
                'ShowSourceLink', true, ...
                'Title', getString(message('dsp:system:ParametricEQFilter:BlockTitle')),...
                'Text',  getString(message('dsp:system:ParametricEQFilter:BlockHeader')));
        end
    end
end

