classdef (StrictDefaults)ChannelSynthesizer < dsp.ChannelSynthesizer
    %ChannelSynthesizer Polyphase FFT synthesis filter bank
    % This class is used in the ChannelSynthesizer block
    
    % Copyright 2016-2021 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCA>
    
    properties (Nontunable)
        % CoefficientsPort Specify coefficients from input port
        CoefficientsPort (1, 1) logical = false;
    end
    
    properties (Constant, Hidden)
        LowpassCoefficientsSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.ChannelizerPolicy('SystemBlock', 'CoefficientsPort', 1, 'coeffs'), ...
            {'Property','MATLAB','CoefficientsPort'})
    end
    
    methods (Access = protected)
        
        function validateInputsImpl(obj,varargin)
            validateInputsImpl@dsp.ChannelSynthesizer(obj,varargin{1});
        end
        
        function setupImpl(obj, u)
            
            ts = getSampleTime(obj);
            % Never allow continuous time
            coder.internal.errorIf(ts.SampleTime==0,...
                'dsp:system:Shared:ContinuousTimeNotAllowed');
            setupImpl@dsp.ChannelSynthesizer(obj,u);
        end
        
        % Propagators
        function cp = isOutputComplexImpl(~)
            cp = true;
        end
        
        function sz = getOutputSizeImpl(obj)
            %If x is three dimensional, each matrix corresponds to a separate
            %channel. If M is the number of frequency bands and x is a LxM
            %matrix, y will have dimensions L*Mx1. If x has more than one
            %channel, i.e. x is LxMxN, y will have dimensions LxMxN.
            in_sz = propagatedInputSize(obj, 1);
            
            if numel(in_sz) == 2
                sz = [prod(in_sz) , 1];
            else
                sz = [in_sz(1)*in_sz(2) , in_sz(3)];
            end
        end
        
        function isfixed = isOutputFixedSizeImpl(obj)
            isfixed = propagatedInputFixedSize(obj,1);
        end
        
        function inputDT = getOutputDataTypeImpl(obj)
            inputDT = propagatedInputDataType(obj,1);
        end
        
        function name = getInputNamesImpl(obj)
            % Input port name to show on the block
            if strcmp(obj.Specification,'Coefficients') && obj.CoefficientsPort
                name = 'x';
            else
                name = '';
            end
        end
        
        function name = getOutputNamesImpl(~)
            % Output port name to show on the block
            name = '';
        end
        
        function icon = getIconImpl(~)
            % Block Icon
            icon = getString(message('dsp:system:ChannelSynthesizer:BlockIcon'));
        end
        
        function val = supportsMultipleInstanceImpl(~)
            % For "For Each" support of the MATLAB System block
            val = true;
        end
        
        function sts = getSampleTimeImpl(obj)
            sts = createSampleTime(obj, 'Type', 'Inherited', ...
                'Disallow', 'Constant');
        end
        
        function nc = getNumChs(obj,~)
            sz = propagatedInputSize(obj,1);
            if numel(sz)==3
                nc = sz(3);
            else
                nc = 1;
            end
        end
        
        function nb = getNumBands(obj,u)%#ok
            % Return the number of bands
            thisSize = propagatedInputSize(obj, 1);
            nb = thisSize(2);
        end
        
    end
    
    methods(Static,Access=protected)
        
        function groups = getPropertyGroupsImpl
            props = {...
                matlab.system.display.internal.Property('Specification','Description','dsp:system:Channelizer:Specification_MP'), ...
                matlab.system.display.internal.Property('CoefficientsPort','Description','dsp:system:Channelizer:CoefficientsPort_MP'), ...
                matlab.system.display.internal.Property('NumTapsPerBand','Description','dsp:system:Channelizer:NumTapsPerBand_MP'), ...
                matlab.system.display.internal.Property('StopbandAttenuation','Description','dsp:system:Channelizer:StopbandAttenuation_MP'), ...
                matlab.system.display.internal.Property('LowpassCoefficients','Description','dsp:system:Channelizer:LowpassCoefficients_MP')};
            
            parameterString = message('dsp:system:Shared:Parameters');
            groups = matlab.system.display.Section('Title', ...
                parameterString.getString, ...
                'PropertyList',props);
        end
        
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.ChannelSynthesizer', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:system:ChannelSynthesizer:BlockName',...
                'Text', 'dsp:system:ChannelSynthesizer:BlockHeader');
        end
        
    end
    
end
