classdef (StrictDefaults)DigitalUpConverter < dsp.DigitalUpConverter
% This class is used for the Digital Up Converter block in dspsigops

%   Copyright 2021-2023 The MathWorks, Inc.

%#codegen
%#ok<*EMCA>
    
    %---------------------------------------------------------------------------
    % Public methods
    %---------------------------------------------------------------------------
    methods
        function obj = DigitalUpConverter(varargin)
            obj@dsp.DigitalUpConverter(varargin{:})
        end
    end
    %--------------------------------------------------------------------------
    % Protected methods
    %--------------------------------------------------------------------------
    methods (Access = protected)
        %------------------------------------------------------------------
        function icon = getIconImpl(~)
            icon = getString(message('dsp:system:DigitalUpConverter:iconString'));
        end
        %------------------------------------------------------------------
        function varargout = getInputNamesImpl(~)
            varargout{1} = '';
        end
        %------------------------------------------------------------------
        function varargout = getOutputNamesImpl(~)
            varargout{1} = '';
        end
    end
    
    methods(Static,Hidden,Access=protected)
        function groups = getPropertyGroupsImpl

            props = {...
                matlab.system.display.internal.Property('InterpolationFactor',Description='dsp:system:DigitalUpConverter:InterpolationFactor_MP'), ...
                matlab.system.display.internal.Property('MinimumOrderDesign',Description='dsp:system:DigitalUpConverter:MinimumOrderDesign_MP'), ...
                matlab.system.display.internal.Property('FirstFilterOrder',Description='dsp:system:DigitalUpConverter:FirstFilterOrder_MP'), ...
                matlab.system.display.internal.Property('NumCICSections',Description='dsp:system:DigitalUpConverter:NumCICSections_MP'), ...
                matlab.system.display.internal.Property('StopbandFrequencySource',Description='dsp:system:DigitalUpConverter:StopbandFrequencySource_MP'), ...
                matlab.system.display.internal.Property('Oscillator', Description='dsp:system:DigitalUpConverter:Oscillator_MP'), ...
                matlab.system.display.internal.Property('CenterFrequency', Description='dsp:system:DigitalUpConverter:CenterFrequency_MP'), ...
                matlab.system.display.internal.Property('SecondFilterOrder',Description='dsp:system:DigitalConverterBase:SecondFilterOrder_MP'), ...
                matlab.system.display.internal.Property('Bandwidth',Description='dsp:system:DigitalConverterBase:Bandwidth_MP'), ...
                matlab.system.display.internal.Property('StopbandFrequency',Description='dsp:system:DigitalConverterBase:StopbandFrequency_MP'), ...
                matlab.system.display.internal.Property('PassbandRipple',Description='dsp:system:DigitalConverterBase:PassbandRipple_MP'), ...
                matlab.system.display.internal.Property('StopbandAttenuation', Description='dsp:system:DigitalConverterBase:StopbandAttenuation_MP'), ...
                matlab.system.display.internal.Property('NumAccumulatorBits', Description='dsp:system:DigitalConverterBase:NumAccumulatorBits_MP'), ...
                matlab.system.display.internal.Property('NumQuantizedAccumulatorBits', Description='dsp:system:DigitalConverterBase:NumQuantizedAccumulatorBits_MP'), ...
                matlab.system.display.internal.Property('Dither', Description='dsp:system:DigitalConverterBase:Dither_MP'), ...
                matlab.system.display.internal.Property('NumDitherBits', Description='dsp:system:DigitalConverterBase:NumDitherBits_MP'), ...
                matlab.system.display.internal.Property('InheritSampleRate', Description='dsp:system:AbstractSampleRateEngine:InheritSampleRate_MP'), ...
                matlab.system.display.internal.Property('SampleRate',Description='dsp:system:AbstractSampleRateEngine:SampleRate_MP'), ...
                };

            mainS = matlab.system.display.Section(Title='Parameters', PropertyList=props);
            
            % Visualization button
            filterVis = dsp.internal.FilterVisualizationButton;
            mainS.Actions = filterVis.fvtoolAction;
            
            mainSG = matlab.system.display.SectionGroup(TitleSource='Auto', Sections=mainS);

            dt = matlab.system.display.internal.DataTypesGroup(mfilename('class'));
            dt.PropertyList{1} = matlab.system.display.internal.DataTypeProperty('FiltersOutputDataType', Prefix='stageOutput', Description='Stage output');            
            dt.PropertyList{3} = matlab.system.display.internal.DataTypeProperty('OutputDataType', Prefix='output', Description='Output');          
            groups = [mainSG, dt];
        end

        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.DigitalUpConverter', ...
                ShowSourceLink=true, ...
                Title='dsp:system:DigitalUpConverter:titleString', ...
                Text='dsp:system:DigitalUpConverter:descriptionString');
        end
    end
end

