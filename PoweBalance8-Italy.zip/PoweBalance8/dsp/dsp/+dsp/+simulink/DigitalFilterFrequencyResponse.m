classdef DigitalFilterFrequencyResponse < dsp.internal.DigitalFilterFrequencyResponse
    % DigitalFilterFrequencyResponse Compute digital filter frequency
    % response
    %#codegen

    methods
        %------------------------------------------------------------------
        % Constructor
        function this = DigitalFilterFrequencyResponse(varargin)
            % Support name-value pair arguments when constructing object
            setProperties(this,nargin,varargin{:})
        end
    end

    methods(Access = protected)
        %------------------------------------------------------------------
        function setupImpl(this, varargin)
            sts = getSampleTime(this);
            % Never allow continuous time
            coder.internal.errorIf(sts.SampleTime==0,'dsp:system:Shared:ContinuousTimeNotAllowed');
            setupImpl@dsp.internal.DigitalFilterFrequencyResponse(this, varargin{:});
        end
        %------------------------------------------------------------------
        function num = getNumInputsImpl(this)
            % Define total number of inputs for system with optional
            % inputs
            isIIR = strcmpi(this.FilterType, 'IIR');
            num = (1 + isIIR) * this.NumFilters;
        end
        %------------------------------------------------------------------
        function name = getInputNamesImpl(this)
            isIIR = strcmpi(this.FilterType, 'IIR');
            name = strings(1, this.NumFilters * (1 + isIIR));
            for idx = 1:this.NumFilters
                name((1 + isIIR)*(idx-1) + 1) = "Num" + idx;
                if isIIR
                    name((1+isIIR)*idx) = "Den" + idx;
                end
            end
        end
        %------------------------------------------------------------------
        function flag = isOutputFixedSizeImpl(~)
            % Return false if input size cannot change
            % between calls to the System object
            flag = false;
        end
        %------------------------------------------------------------------
        function flag = isOutputComplexImpl(~)
            flag = true;
        end
        %------------------------------------------------------------------
        function sz = getOutputSizeImpl(this)
            % Return size for each output port
            sz = [this.pMaxFFTLength this.NumFilters];
        end
        %------------------------------------------------------------------
        function outputDT = getOutputDataTypeImpl(~)
            outputDT = 'double';
        end
        %------------------------------------------------------------------
        function name = getOutputNamesImpl(~)
            name = "h";
        end
        %------------------------------------------------------------------
        function icon = getIconImpl(~)
            icon = getString(message('dsp:system:DigitalFilterFrequencyResponse:BlockIcon'));
        end
    end

    methods(Static, Access = protected)
        %------------------------------------------------------------------
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.DigitalFilterFrequencyResponse', ...
                'ShowSourceLink', true, ...
                'Title', 'Digital Filter Frequency Response',...
                'Text', 'Compute the frequency response of digital filters');
        end
        %------------------------------------------------------------------
        function groups = getPropertyGroupsImpl
            props = {...
                matlab.system.display.internal.Property('NumFilters','Description','dsp:system:DigitalFilterFrequencyResponse:NumFilters_MP'), ...
                matlab.system.display.internal.Property('FilterType','Description','dsp:system:DigitalFilterFrequencyResponse:FilterType_MP'), ...
                matlab.system.display.internal.Property('FFTLength','Description','dsp:system:DigitalFilterFrequencyResponse:FFTLength_MP'), ...
                matlab.system.display.internal.Property('NormalizedFrequency','Description','dsp:system:DigitalFilterFrequencyResponse:NormalizedFrequency_MP'), ...
                matlab.system.display.internal.Property('SampleRate','Description','dsp:system:DigitalFilterFrequencyResponse:SampleRate_MP'), ...
                matlab.system.display.internal.Property('FrequencyRange','Description','dsp:system:DigitalFilterFrequencyResponse:FrequencyRange_MP'), ...
                matlab.system.display.internal.Property('XScale','Description','dsp:system:DigitalFilterFrequencyResponse:XScale_MP')};
            groups = matlab.system.display.Section('Title', ...
                'dsp:system:Shared:Parameters', ...
                'PropertyList',props, ...
                'DependOnPrivatePropertyList',{'FrequencyRange'});
        end
    end
end
