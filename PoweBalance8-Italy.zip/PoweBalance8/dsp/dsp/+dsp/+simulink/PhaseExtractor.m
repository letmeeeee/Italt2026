classdef (StrictDefaults)PhaseExtractor < dsp.PhaseExtractor
    %PhaseExtractor Extract unwrapped phase from input
    % This class is used in the Phase Extractor block in dspsigops

    % Copyright 2021 The MathWorks, Inc.

    %#codegen
    %#ok<*EMCA>

    methods (Access=protected)
        function sts = getSampleTimeImpl(obj)
            if obj.TreatFramesIndependently
                % The object is stateless. Allow propagation of constant sample
                % time
                mode = 'Allow';
            else
                % The object has state. Disallow propagation of constant sample
                % time
                mode = 'Disallow';
            end

            sts = createSampleTime(obj, 'Type', 'Inherited', ...
                mode, 'Constant');
        end

        % Propagators
        function varargout = isOutputComplexImpl(~)
            % Complexity propagator
            varargout = {false};
        end

        function varargout = getOutputSizeImpl(obj)
            % Output size propagator
            varargout = {propagatedInputSize(obj, 1)};
        end

        function varargout = getOutputDataTypeImpl(obj)
            % Output datatype propagator
            varargout = {propagatedInputDataType(obj, 1)};
        end

        % Input/Output port labels
        function name = getOutputNamesImpl(~)
            name = '';
        end

        function name = getInputNamesImpl(~)
            name = '';
        end

        function icon = getIconImpl(~)
            % MATLAB system block icon
            icon = getString(message('dsp:system:PhaseExtractor:BlockIcon'));
        end
    end

    %----------------------------------------------------------------------
    % Static, Protected methods
    %----------------------------------------------------------------------
    methods(Static, Access=protected)
        function group = getPropertyGroupsImpl
            % Modify order of display
            props = {matlab.system.display.internal.Property('TreatFramesIndependently','Description','dsp:system:PhaseExtractor:TreatFramesIndependently_MP')};
            group =  matlab.system.display.Section(...
                'Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', props);
        end
        %------------------------------------------------------------------
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header('dsp.simulink.PhaseExtractor', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:system:PhaseExtractor:BlockName',...
                'Text', 'dsp:system:PhaseExtractor:BlockHeader');
        end
    end

end
