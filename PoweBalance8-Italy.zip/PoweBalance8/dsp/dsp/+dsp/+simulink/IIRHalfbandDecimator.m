classdef (StrictDefaults)IIRHalfbandDecimator < dsp.IIRHalfbandDecimator
    % This class is used for the IIR Halfband Decimator block in dspfdesign
    
    % Copyright 2014-2023 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCA>
    properties (Nontunable)
        %FilterBankOutputPort Output highpass subband
        %   Specify if the block should be an analysis filter bank, as a
        %   logical scalar. When this property is set to false, the block
        %   acts as a decimator. If the property is set to true, the object
        %   acts as an analysis filter bank, producing two
        %   power-complementary outputs. The default of this property is
        %   false.
        FilterBankOutputPort (1, 1) logical = false;
        
        %CoefficientsPort Specify coefficients from input port
        CoefficientsPort (1, 1) logical = false;
    end
    
    properties (Constant, Hidden)
        AllpassCoefficients1Set = matlab.system.SourceSet( ...
            dsp.simulink.internal.IIRHalfbandPolicy('SystemBlock', 'CoefficientsPort', 1, 'coeffs1'), ...
            {'Property','MATLAB','CoefficientsPort'})
        AllpassCoefficients2Set = matlab.system.SourceSet( ...
            dsp.simulink.internal.IIRHalfbandPolicy('SystemBlock', 'CoefficientsPort', 2, 'coeffs2'), ...
            {'Property','MATLAB','CoefficientsPort'})
    end
    %----------------------------------------------------------------------
    % Public Methods
    %----------------------------------------------------------------------
    methods
        function obj = IIRHalfbandDecimator(varargin)
            obj@dsp.IIRHalfbandDecimator(varargin{:});
        end
    end
    %----------------------------------------------------------------------
    % Protected Methods
    %----------------------------------------------------------------------
    methods (Access = protected)
        
        function validateInputsImpl(obj,varargin)
            validateInputsImpl@dsp.IIRHalfbandDecimator(obj,varargin{:});
        end
        %------------------------------------------------------------------
        function num = getNumOutputsImpl(obj)
            num = 1+obj.FilterBankOutputPort;
        end
        %------------------------------------------------------------------
        function varargout = getInputNamesImpl(obj)
            % Name of input port (shows on block icon)
            % Input port name to show on the block
            if obj.CoefficientsPort
                varargout{1} = 'x';
            else
                varargout{1} = '';
            end
        end
        %------------------------------------------------------------------
        function varargout = getOutputNamesImpl(obj)
            % Name of output ports (shows on block icon)
            if ~obj.FilterBankOutputPort
                varargout{1} =   '';
            else % power-complementary outputs requested
                varargout{1} =   'LP';
                varargout{2} =   'HP';
            end
        end
        %------------------------------------------------------------------
        function icon = getIconImpl(obj)
            % MATLAB system block icon
            if ~obj.FilterBankOutputPort
                icon = getString(message(...
                    'dsp:system:IIRHalfbandDecimator:decimatorIconString'));
            else % power-complementary outputs requested
                icon = getString(message(...
                    'dsp:system:IIRHalfbandDecimator:analysisIconString'));
            end
        end
        %------------------------------------------------------------------
        function val = supportsMultipleInstanceImpl(obj)
            % Support in for-each subsystem
            val = ~obj.AllowArbitraryInputLength & propagatedInputFixedSize(obj,1);
        end
        % PROPAGATOR METHODS: (used by Simulink)
        %------------------------------------------------------------------
        function varargout = getOutputSizeImpl(obj)
            inputSize = propagatedInputSize(obj,1);
            fixedInput = propagatedInputFixedSize(obj, 1);
            coder.internal.errorIf(~obj.AllowArbitraryInputLength && rem(inputSize(1),2)~=0 && fixedInput, ...
                'dsp:system:FIRHalfbandDecimator:invalidInputDimsForHalfbandDecimBlock');
            varargout{1} = inputSize;
            varargout{1}(1) = ceil(varargout{1}(1)/2);
            if obj.FilterBankOutputPort
                varargout{2} = varargout{1};
            end
        end
        %------------------------------------------------------------------
        function varargout = getOutputDataTypeImpl(obj)
            varargout{1} = propagatedInputDataType(obj,1);
            if obj.FilterBankOutputPort
                varargout{2} = varargout{1};
            end
        end
        %------------------------------------------------------------------
        function varargout = isOutputComplexImpl(obj)
            varargout{1} = propagatedInputComplexity(obj,1);
            if obj.FilterBankOutputPort
                varargout{2} = varargout{1};
            end
        end
        %------------------------------------------------------------------
        function varargout = isOutputFixedSizeImpl(obj)
            varargout{1} =  isFixedSizeOutput(obj);
            if obj.FilterBankOutputPort
                varargout{2} = varargout{1};
            end
        end
        function isFixedOutput = isFixedSizeOutput(obj)
            % Varsize output if input is varsize or arbitrary input is allowed
            isFixedOutput = propagatedInputFixedSize(obj,1) && ~obj.AllowArbitraryInputLength;
        end
        function flag = isInactivePropertyImpl(obj, prop)            
            switch prop
                case {'NormalizedFrequency'}
                    flag = true;
                otherwise
                    flag = isInactivePropertyImpl@dsp.internal.IIRHalfbandBase(obj,prop);
            end
        end
        function validatePropertiesImpl(obj)
            if ~isSampleRateInherited(obj)
                crossValidateProperties(obj);
            end            
        end
    end
    %----------------------------------------------------------------------
    % Static hidden methods
    %----------------------------------------------------------------------
    methods(Static,Hidden)
        function props = getDisplayPropertiesImpl()
            props = { ...
                matlab.system.display.internal.Property('Specification','Description','dsp:system:IIRHalfbandDecimator:Specification_MP'), ...
                matlab.system.display.internal.Property('FilterOrder','Description','dsp:system:IIRHalfbandDecimator:FilterOrder_MP'), ...
                matlab.system.display.internal.Property('TransitionWidth','Description','dsp:system:IIRHalfbandDecimator:TransitionWidth_MP'), ...
                matlab.system.display.internal.Property('StopbandAttenuation','Description','dsp:system:IIRHalfbandDecimator:StopbandAttenuation_MP'), ...
                matlab.system.display.internal.Property('DesignMethod','Description','dsp:system:IIRHalfbandDecimator:DesignMethod_MP'), ...
                matlab.system.display.internal.Property('Structure','Description','dsp:system:IIRHalfbandDecimator:Structure_MP'), ...
                matlab.system.display.internal.Property('HasPureDelayBranch','Description','dsp:system:IIRHalfbandDecimator:HasPureDelayBranch_MP'), ...
                matlab.system.display.internal.Property('Delay','Description','dsp:system:IIRHalfbandDecimator:Delay_MP'), ...
                matlab.system.display.internal.Property('CoefficientsPort','Description','dsp:system:IIRHalfbandDecimator:CoefficientsPort_MP'), ...
                matlab.system.display.internal.Property('AllpassCoefficients1','Description','dsp:system:IIRHalfbandDecimator:AllpassCoefficients1_MP'), ...
                matlab.system.display.internal.Property('AllpassCoefficients2','Description','dsp:system:IIRHalfbandDecimator:AllpassCoefficients2_MP'), ...
                matlab.system.display.internal.Property('WDFCoefficients1','Description','dsp:system:IIRHalfbandDecimator:WDFCoefficients1_MP'), ...
                matlab.system.display.internal.Property('WDFCoefficients2','Description','dsp:system:IIRHalfbandDecimator:WDFCoefficients2_MP'), ...
                matlab.system.display.internal.Property('HasTrailingFirstOrderSection','Description','dsp:system:IIRHalfbandDecimator:HasTrailingFirstOrderSection_MP'), ...
                matlab.system.display.internal.Property('FilterBankOutputPort','Description','dsp:system:IIRHalfbandDecimator:FilterBankOutputPort_MP'), ...
                matlab.system.display.internal.Property('SampleRateMode','Description','dsp:system:AbstractSampleRateEngine:SampleRateMode_MP'), ...
                matlab.system.display.internal.Property('SampleRate','Description','dsp:system:AbstractSampleRateEngine:SampleRate_MP'),...
                matlab.system.display.internal.Property('AllowArbitraryInputLength','Description','dsp:blkprm_prompts:AllowArbitraryFixedInput_MP')};

        end
    end
    %----------------------------------------------------------------------
    % Static protected methods
    %----------------------------------------------------------------------
    methods(Static,Access=protected)
        function mainS = getPropertyGroupsImpl
            props = dsp.simulink.IIRHalfbandDecimator.getDisplayPropertiesImpl;
            
            mainS = matlab.system.display.Section(...
                'Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', props);
            
            filterVis = dsp.internal.FilterVisualizationButton;
            mainS.Actions = filterVis.fvtoolAction;
        end
        %------------------------------------------------------------------
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.IIRHalfbandDecimator', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:system:IIRHalfbandDecimator:titleString',...
                'Text',  'dsp:system:IIRHalfbandDecimator:descriptionString');
        end
    end
    %----------------------------------------------------------------------
    % Hidden methods
    %----------------------------------------------------------------------
    methods (Hidden)
        function f = updateFvtoolFigure(obj,f)
            % Used to update fvtool plot when object is used in Simulink
            setfilter(f, obj);
            if isSampleRateNormalized(obj) || strcmp(obj.Specification, 'Coefficients') 
                f.NormalizedFrequency = 'on';
            else
                f.NormalizedFrequency = 'off';
            end

        end
    end
end
