classdef (StrictDefaults)SVD < matlab.System
    % This System object used under dspfactors/Single Value Decomposition
    % block.

    %#codegen
    %#ok<*EMCLS>

    %   Copyright 2015-2021 The MathWorks, Inc.

    % Public, tunable properties.
    properties(Nontunable)
        % Show ports with U and V matrices
        wantv (1, 1) logical = false;
        % Show error status port (E)
        wanterr (1, 1) logical = false;
    end
    
    methods (Access = protected)
        function validateInputsImpl(~,u)
            validateattributes(u, {'single', 'double'}, {'2d'},'','')
        end
        % Block Icon 
        function icon = getMaskDisplayImpl(obj)
            x = [0.1 0.25 0.25 0.1 0.1 NaN ...
                 0.3191 0.3191 0.2800 0.2800 0.3191 0.3191 0.3504 0.3191 NaN ...
                 0.38 0.53 0.53 0.38 0.38 NaN ...
                 0.57 0.69 NaN ...
                 0.73 0.87 0.87 0.73 0.73 NaN ...
                 0.57 0.61 NaN ...
                 0.66 0.69 NaN ...
                 0.685 0.685 NaN ...
                 0.686 0.686 NaN ...
                 0.688 0.688 NaN ...
                 0.57 0.61 NaN ...
                 0.66 0.69 NaN ...
                 0.57 0.57 NaN ...
                 0.5709 0.5709 NaN ...
                 0.569 0.569];
            
            y = [0.1 0.1 0.65 0.65 0.1 NaN ...
                 0.335 0.375 0.375 0.425 0.425 0.465 0.4 0.335 NaN ...
                 0.1 0.1 0.65 0.65 0.1 NaN ...
                 0.3 0.1 NaN ...
                 0.1 0.1 0.3 0.3 0.1 NaN ...
                 0.3 0.3 NaN ...
                 0.3 0.3 NaN ...
                 0.3 0.27 NaN ...
                 0.21 0.18 NaN ...
                 0.13 0.1 NaN ...
                 0.1 0.1 NaN ...
                 0.1 0.1 NaN ...
                 0.1 0.13 NaN ...
                 0.18 0.21 NaN ...
                 0.27 0.3];

            iconPlotCmds = {['plot(0,0,1,1,' mat2str(x) ',' mat2str(y) ');']};
            iconTextCmds = {'text(0.5,0.9,''A = U * S * V '''''',''horizontalAlignment'', ''center'', ''verticalAlignment'', ''middle'')'};
            switch (obj.wantv*2+obj.wanterr)
                case 0
                    % 1 input (A)
                    % 1 output (S)
                    portLabelCmds = {
                        ['port_label(''input'',1,''A'');'...
                         'port_label(''output'',1,''S'');'...
                         'port_label(''output'',1,'''');'...
                         'port_label(''output'',1,'''');'...
                         'port_label(''output'',1,'''');']
                        };
                case 1
                    % 1 input (A)
                    % 2 outputs (S,E)
                    portLabelCmds = {
                        ['port_label(''input'',1,''A'');'...
                         'port_label(''output'',1,''S'');'...
                         'port_label(''output'',2,''E'');'...
                         'port_label(''output'',2,'''');'...
                         'port_label(''output'',2,'''');']
                        };
                case 2
                    % 1 input (A)
                    % 3 outputs (U,S,V)
                    portLabelCmds = {
                        ['port_label(''input'',1,''A'');'...
                         'port_label(''output'',1,''U'');'...
                         'port_label(''output'',2,''S'');'...
                         'port_label(''output'',3,''V'');'...
                         'port_label(''output'',3,'''');']
                        };
                case 3
                    % 1 input (A)
                    % 4 outputs (U,S,V,E)
                    portLabelCmds = {
                        ['port_label(''input'',1,''A'');'...
                         'port_label(''output'',1,''U'');'...
                         'port_label(''output'',2,''S'');'...
                         'port_label(''output'',3,''V'');'...
                         'port_label(''output'',4,''E'');']
                        };
            end
            icon = [iconTextCmds;iconPlotCmds;portLabelCmds];
        end

        function val = supportsMultipleInstanceImpl(~)
            val = true;
        end

        function varargout = getOutputSizeImpl(obj)
            inputSize = propagatedInputSize(obj,1);
            if inputSize(1) < inputSize(2) % Short and fat
                ssz = inputSize(1);
            else % Square, or tall and skinny
                ssz = inputSize(2);
            end
            if obj.wantv
                varargout{1} = [inputSize(1), ssz];
                varargout{2} = [ssz, 1];
                varargout{3} = [inputSize(2), ssz];
            else
                varargout{1} = [ssz, 1];
            end
            if obj.wanterr
                varargout{getErrorPort(obj)} = [1,1];
            end
        end
        
        function varargout = getOutputDataTypeImpl(obj)
            varargout{1} = propagatedInputDataType(obj,1);
            if obj.wantv
                varargout{2} = propagatedInputDataType(obj,1);
                varargout{3} = propagatedInputDataType(obj,1);
            end
            if obj.wanterr
                varargout{getErrorPort(obj)} = 'logical';
            end
        end
        
        function varargout = isOutputComplexImpl(obj)
            if obj.wantv
                varargout{1} = propagatedInputComplexity(obj,1);
                varargout{2} = false;
                varargout{3} = propagatedInputComplexity(obj,1);
            else
                varargout{1} = false;
            end
            if obj.wanterr
                varargout{getErrorPort(obj)} = false;
            end
        end
        
        
        function varargout = isOutputFixedSizeImpl(obj)
            varargout{1} = true;
            if obj.wantv
                varargout{2} = true;
                varargout{3} = true;
            end
            if obj.wanterr
                varargout{getErrorPort(obj)} = true;
            end
        end
            
        function varargout = getOutputNamesImpl(obj)
            if obj.wantv
                varargout{1} =   'U';
                varargout{2} =   'S';
                varargout{3} =   'V';
            else
                varargout{1} =   'S';
            end
            if obj.wanterr
                varargout{getErrorPort(obj)} =   'E';
            end
        end
        
        function [varargout] = stepImpl(obj,A)
            if all(isfinite(A(:)))
                if obj.wantv
                    [u,s,v] = svd(A, 'econ');
                    varargout{1} = u;
                    varargout{2} = diag(s);
                    varargout{3} = v;
                else
                    s = svd(A, 'econ');
                    varargout{1} = s;
                end
                if obj.wanterr
                    varargout{getErrorPort(obj)} = false;
                end
            else
                [n,m] = size(A);
                p = min(n,m);
                if obj.wantv
                    varargout{1} = zeros(n,p, 'like', A);
                    varargout{2} = real(zeros(p,1, 'like', A));
                    varargout{3} = zeros(m,p, 'like', A);
                else
                    varargout{1} = real(zeros(p,1, 'like', A));
                end
                if obj.wanterr
                    varargout{getErrorPort(obj)} = true;
                end
            end
        end
        
        function N = getNumOutputsImpl(obj)
            N = 1;
            if obj.wantv
                N = N + 2;
            end
            N = N + obj.wanterr;
        end
    end
    
    methods(Static, Access = protected)
        
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header('dsp.simulink.SVD', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:system:SVD:BlockTitle', ...
                'Text', 'dsp:system:SVD:BlockHeader');
        end
        function mainS = getPropertyGroupsImpl
            % Modify order of display
            props = {matlab.system.display.internal.Property('wantv','Description','dsp:system:SVD:wantv_MP'), ...
                matlab.system.display.internal.Property('wanterr','Description','dsp:system:SVD:wanterr_MP')};
            mainS =  matlab.system.display.Section(...
                'Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', props);
        end
    end
end

function portidx = getErrorPort(obj)
    if obj.wantv
        portidx = 4;
    else
        portidx = 2;
    end
end