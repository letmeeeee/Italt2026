classdef (StrictDefaults)NotchPeakFilter < dsp.NotchPeakFilter & ...
        dsp.simulink.mixin.FilterResponseVisualizable
    % This class is used for the Notch-Peak Filter block in dspfdesign
    
    % Copyright 2014-2022 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCA>
    
    properties(Nontunable)
        %BandwidthPort Specify bandwidth from input port
        BandwidthPort (1, 1) logical = false;
        %CenterFrequencyPort Specify center frequency from input port
        CenterFrequencyPort (1, 1) logical = false;
        %QualityFactorPort Specify quality factor from input port
        QualityFactorPort (1, 1) logical = false;
        
        %BandwidthCoefficientPort Specify bandwidth coefficient from input port
        BandwidthCoefficientPort (1, 1) logical = false;
        %CenterFrequencyCoefficientPort Specify center frequency coefficient from input port
        CenterFrequencyCoefficientPort (1, 1) logical = false;
    end
    
    properties (Constant, Hidden)
        BandwidthSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.ParametricEQFilterPolicy('SystemBlock', 'BandwidthPort', 1, 'BW'), ...
            {'Property','MATLAB','BandwidthPort'})
        CenterFrequencySet = matlab.system.SourceSet( ...
            dsp.simulink.internal.ParametricEQFilterPolicy('SystemBlock', 'CenterFrequencyPort', 2, 'Fc'), ...
            {'Property','MATLAB','CenterFrequencyPort'})
        
        
        BandwidthCoefficientSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.ParametricEQFilterPolicy('SystemBlock', 'BandwidthCoefficientPort', 3, 'BWCoeff'), ...
            {'Property','MATLAB','BandwidthCoefficientPort'})
        CenterFrequencyCoefficientSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.ParametricEQFilterPolicy('SystemBlock', 'CenterFrequencyCoefficientPort', 4, 'FcCoeff'), ...
            {'Property','MATLAB','CenterFrequencyCoefficientPort'})
        
        
        QualityFactorSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.ParametricEQFilterPolicy('SystemBlock', 'QualityFactorPort', 5, 'Q'), ...
            {'Property','MATLAB','QualityFactorPort'})
    end
    
    properties (Nontunable)
        % Output Filter output
        % Output of the filter. To output the notch response only, set
        % this property to 'Notch'. To get the peak response only, set this
        % property to 'Peak'. To get both responses, set this property to
        % 'Notch and Peak'.
        Output = 'Notch and Peak'
    end
    
    properties (Access = private, Nontunable)
        % Property used to avoid strcmp usage for Output property
        pOutputID;
    end
    
    properties(Constant, Hidden)
        OutputSet = matlab.system.StringSet( { ...
            'Notch', ...
            'Peak',...
            'Notch and Peak'} );
    end
    
    methods
        function obj = NotchPeakFilter(varargin)
            obj@dsp.NotchPeakFilter(varargin{:});
        end
        
        function varargout = fvtool(obj)
            if nargout > 0
                varargout{1} = callFvtool(obj);
            else
                callFvtool(obj);
            end
        end
    end
    
    methods (Access=protected)
        
        function validateInputsImpl(obj,varargin)
            validateInputsImpl@dsp.NotchPeakFilter(obj,varargin{:});
        end
        
        function N = getNumOutputsImpl(obj)
            % Specify number of System outputs
            N = 1 + strcmp(obj.Output,'Notch and Peak');
        end
        
        function varargout = getInputNamesImpl(obj)
            if ((obj.BandwidthPort || obj.CenterFrequencyPort) && strcmp(obj.Specification,'Bandwidth and center frequency')) || ...
                    ((obj.BandwidthCoefficientPort || obj.CenterFrequencyCoefficientPort) && strcmp(obj.Specification,'Coefficients')) || ...
                    ((obj.QualityFactorPort || obj.CenterFrequencyPort) && strcmp(obj.Specification,'Quality factor and center frequency'))
                varargout{1} = 'x';
            else
                varargout{1} = '';
            end
        end
        
        function varargout = getOutputNamesImpl(obj)
            % Define name of output ports (shows on block icon)
            if strcmp(obj.Output,'Notch') || strcmp(obj.Output,'Peak')
                varargout{1} =   '';
            else % notch and peak output ports requested
                varargout{1} =   'notch';
                varargout{2} =   'peak';
            end
        end
        
        function setupImpl(obj,u)
            setupImpl@dsp.NotchPeakFilter(obj,u);
            switch obj.Output
                case 'Notch'
                    obj.pOutputID = 0;
                case 'Peak'
                    obj.pOutputID = 1;
                case 'Notch and Peak'
                    obj.pOutputID = 2;
            end
        end
        
        function varargout = stepImpl(obj,u)
            [y_notch,y_peak] = stepImpl@dsp.NotchPeakFilter(obj,u);
            if obj.pOutputID == 0
                varargout{1} = y_notch;
            elseif obj.pOutputID == 1
                varargout{1} = y_peak;
            else
                varargout{1} = y_notch;
                varargout{2} = y_peak;
            end
        end
        
        function s = saveObjectImpl(obj)
            % Default implementation saves all public properties
            s = saveObjectImpl@dsp.NotchPeakFilter(obj);
            
            if isLocked(obj)
                % All the following are set at setup
                s.pOutputID = obj.pOutputID;
            end
            
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            % Re-load state if saved version was locked
            if wasLocked
                obj.pOutputID = s.pOutputID;
            end
            % Call base class method
            loadObjectImpl@dsp.NotchPeakFilter(obj,s,wasLocked);
        end
        
        function val = supportsMultipleInstanceImpl(~)
            % Support in for-each subsystem
            val = true;
        end
        
        %%Propagators
        function varargout = isOutputComplexImpl(obj)
            % Complexity propagator
            for ind = 1:getNumOutputs(obj)
                varargout{ind} = propagatedInputComplexity(obj, 1);
            end
        end
        
        function varargout = getOutputSizeImpl(obj)
            % Output size propagator
            for ind = 1:getNumOutputs(obj)
                varargout{ind} = propagatedInputSize(obj, 1);
            end
        end
        
        function varargout = getOutputDataTypeImpl(obj)
            % Output datatype propagator
            for ind = 1:getNumOutputs(obj)
                varargout{ind} = propagatedInputDataType(obj, 1);
            end
        end
        
        function varargout = isOutputFixedSizeImpl(obj)
            flag = propagatedInputFixedSize(obj,1);
            for ind = 1:getNumOutputs(obj)
                varargout{ind} = flag;
            end
        end
        
        %Block Icon
        function icon = getIconImpl(obj)
            % MATLAB system block icon
            if strcmp(obj.Output,'Notch')
                icon = getString(message('dsp:system:NotchPeakFilter:notchIcon'));
            elseif strcmp(obj.Output,'Peak')
                icon = getString(message('dsp:system:NotchPeakFilter:peakIcon'));
            else % notch and peak output ports requested
                icon = getString(message('dsp:system:NotchPeakFilter:notchPeakIcon'));
            end
        end
        
        function dt = getTunablePropertiesSpecificationImpl(obj,~)
            dt = propagatedInputDataType(obj,1);
        end
        
    end
    
    %------------------------------------------------------------------------
    methods(Static, Hidden)
        function checkVal(Q)
            coder.internal.errorIf(~isnumeric(Q) || ~isscalar(Q) ||...
                ~isreal(Q) || Q < 0, 'dsp:system:NotchPeakFilter:QFactor');
        end
        
        function props = getDisplayPropertiesImpl()            
            props = {...
                matlab.system.display.internal.Property('Specification',Description='dsp:system:NotchPeakFilter:Specification_MP')...
                matlab.system.display.internal.Property('BandwidthPort',Description='dsp:system:NotchPeakFilter:BandwidthPort_MP')...
                matlab.system.display.internal.Property('Bandwidth',Description='dsp:system:NotchPeakFilter:Bandwidth_MP')...
                matlab.system.display.internal.Property('QualityFactorPort',Description='dsp:system:NotchPeakFilter:QualityFactorPort_MP')...
                matlab.system.display.internal.Property('QualityFactor',Description='dsp:system:NotchPeakFilter:QualityFactor_MP')...
                matlab.system.display.internal.Property('CenterFrequencyPort',Description='dsp:system:NotchPeakFilter:CenterFrequencyPort_MP')...
                matlab.system.display.internal.Property('CenterFrequency',Description='dsp:system:NotchPeakFilter:CenterFrequency_MP')...
                matlab.system.display.internal.Property('BandwidthCoefficientPort',Description='dsp:system:NotchPeakFilter:BandwidthCoefficientPort_MP')...
                matlab.system.display.internal.Property('BandwidthCoefficient',Description='dsp:system:NotchPeakFilter:BandwidthCoefficient_MP')...
                matlab.system.display.internal.Property('CenterFrequencyCoefficientPort',Description='dsp:system:NotchPeakFilter:CenterFrequencyCoefficientPort_MP')...
                matlab.system.display.internal.Property('CenterFrequencyCoefficient',Description='dsp:system:NotchPeakFilter:CenterFrequencyCoefficient_MP')...
                matlab.system.display.internal.Property('Output',Description='dsp:system:NotchPeakFilter:Output_MP')...
                matlab.system.display.internal.Property('InheritSampleRate',Description='dsp:system:NotchPeakFilter:InheritSampleRate_MP')...
                matlab.system.display.internal.Property('SampleRate',Description='dsp:system:NotchPeakFilter:SampleRate_MP')};
        end
    end
    
    % Block header - widget grouping
    methods(Static, Access=protected)
        function mainS = getPropertyGroupsImpl
            % Modify order of display
            props = dsp.simulink.NotchPeakFilter.getDisplayPropertiesImpl;
            mainS =  matlab.system.display.Section(...
                Title='dsp:system:Shared:Parameters', ...
                PropertyList=props);
            
            filterVis = dsp.simulink.internal.FilterResponseVisualizationButton;
            mainS.Actions = filterVis.visualizeAction;
        end
        %------------------------------------------------------------------
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.NotchPeakFilter', ...
                ShowSourceLink=true, ...
                Title='dsp:system:NotchPeakFilter:BlockTitle',...
                Text='dsp:system:NotchPeakFilter:BlockHeader');
        end
    end
%--------------------------------------------------------------------------
% Hidden methods
%--------------------------------------------------------------------------    
    methods(Hidden)
        %------------------------------------------------------------------
        function filters = getVisualizationFilters(obj)
            % Used to return filters that will be shown when the visualize
            % filter response button is clicked.
            a1 = getBandwidthCoefficient(obj);
            a2 = getCenterFrequencyCoefficient(obj);
            if strcmp(obj.Output, 'Notch')
                filters{1} = dfilt.calattice([],[a2;a1]);
            elseif strcmp(obj.Output, 'Peak')
                filters{1} = dfilt.parallel(dfilt.scalar(0.5), ...
                    dfilt.cascade(dfilt.latticeallpass([a2;a1]), dfilt.scalar(-0.5)));
            else
                % Both responses are requested: Add legend to the plot
                filters{1} = dfilt.calattice([],[a2;a1]);
                filters{2} = dfilt.parallel(dfilt.scalar(0.5), ...
                    dfilt.cascade(dfilt.latticeallpass([a2;a1]), dfilt.scalar(-0.5)));
            end
        end
        %------------------------------------------------------------------
        function legend = getVisualizationLegend(obj, blkName)
            % Used to return the legend that will be shown when the
            % visualize filter response plot is shown
            if ~strcmp(obj.Output, 'Notch and Peak')
                legend = {blkName};
            else
                legend = {[getString(message('dsp:system:NotchPeakFilter:notchIcon')), ' (', blkName, ')'], ...
                    [getString(message('dsp:system:NotchPeakFilter:peakIcon')), ' (', blkName, ')']};
            end
        end
    end
end

