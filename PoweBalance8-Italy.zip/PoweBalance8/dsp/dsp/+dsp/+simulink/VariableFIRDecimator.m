classdef VariableFIRDecimator < dsp.internal.VariableFIRDecimator
    % This class is used in the Variable FIR Decimator block to support
    % tunable decimation factor

    % Copyright 2022-2023 The MathWorks, Inc.

    %#codegen

    properties (Nontunable)
        % CoefficientsPort Specify coefficients from input port
        CoefficientsPort (1, 1) logical = false;
        DecimationFactorPort (1, 1) logical = true;
    end

    properties (Constant, Hidden)
        DecimationFactorSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.VariableRateConversionPolicy('SystemBlock', 'DecimationFactorPort', 1, 'M'), ...
            {'Property','MATLAB','DecimationFactorPort'})
        CoefficientsSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.VariableRateConversionPolicy('SystemBlock', 'CoefficientsPort', 2, 'coeffs'), ...
            {'Property','MATLAB','CoefficientsPort'})
    end

    methods (Access = protected)
        %------------------------------------------------------------------
        function setupImpl(obj, u)
            setupImpl@dsp.internal.VariableFIRDecimator(obj,u);
        end
        %------------------------------------------------------------------
        function validatePropertiesImpl(obj)
            if strcmpi(obj.Specification, 'Decimation factor') && ~obj.DecimationFactorPort
                validateattributes(obj.DecimationFactor,{'numeric'},{'scalar', 'finite', 'integer','<=',obj.MaxDecimationFactor},'','DecimationFactor');
            end
        end
        %------------------------------------------------------------------
        function outsize = getOutputSizeImpl(obj)
            % Return size for each output port
            outsize = propagatedInputSize(obj,1);
            if ~strcmpi(obj.Specification,'Decimation factor') && ~isempty(outsize)
                 outsize(1) = obj.OutputFrameLength;
            end
        end
        %------------------------------------------------------------------
        function flag = isOutputFixedSizeImpl(obj)
            if strcmpi(obj.Specification,'Decimation factor')
                flag = false; % Signal output is varsize
            else
                flag = true;
            end
        end
        %------------------------------------------------------------------
        function flag = isOutputComplexImpl(obj)
            switch obj.CoefficientSource
                case 'Auto'
                    flag = propagatedInputComplexity(obj, 1) || ~isreal(polyphase(obj));
                case 'Dialog parameter'
                    flag = propagatedInputComplexity(obj, 1) || ~isreal(obj.Coefficients);
                case 'Input port'
                    if obj.DecimationFactorPort && strcmpi(obj.Specification, 'Decimation factor')
                        flag = propagatedInputComplexity(obj, 1) || propagatedInputComplexity(obj, 3);
                    else
                        flag = propagatedInputComplexity(obj, 1) || propagatedInputComplexity(obj, 2);
                    end
            end
        end
        %------------------------------------------------------------------
        function flag = getOutputDataTypeImpl(obj)
            flag = propagatedInputDataType(obj, 1);
        end
        %------------------------------------------------------------------
        function flag = supportsMultipleInstanceImpl(~)
            flag = true;
        end
        %------------------------------------------------------------------
        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end
        %------------------------------------------------------------------
        function flag = isInputComplexityMutableImpl(~,~)
            % Return false if input complexity cannot change
            % between calls to the System object
            flag = false;
        end
        %------------------------------------------------------------------
        function flag = isInputDataTypeMutableImpl(~,~)
            % Return false if input data type cannot change
            % between calls to the System object
            flag = false;
        end
        %------------------------------------------------------------------
        function icon = getIconImpl(~)
            % Block Icon
            icon = getString(message('dsp:system:VariableFIRDecimator:BlockIcon'));
        end
        %------------------------------------------------------------------
        function [L,N] = getInputDataSize(obj,~)
            sz = propagatedInputSize(obj, 1);
            L = sz(1);
            N = sz(2);
        end
    end

    methods(Hidden)
        function filters = getVisualizationFilters(obj)
            % Used to return filters that will be shown when the visualize
            % filter response button is clicked.
            if strcmp(obj.CoefficientSource, 'Auto')
                h = obj.polyphase2coeffs;
            else
                h = obj.Coefficients;
            end
            
            Mmax = obj.MaxDecimationFactor;
            filters = dsp.FIRDecimator(DecimationFactor = Mmax, Numerator = h);
        end
        %------------------------------------------------------------------
        function legend = getVisualizationLegend(~,blkName)
            % Used to return the legend that will be shown when the
            % visualize filter response plot is shown
            legend = {blkName};
        end
        %------------------------------------------------------------------
        function [flag,id] = isFVtoolSupported(obj)
            flag = true;
            id = '';
            isOutFrameLengthSpec = strcmpi(obj.Specification, 'Output frame length');
            isCoefSourceInputPort = strcmpi(obj.CoefficientSource, 'Input port');
            if isOutFrameLengthSpec
                flag = false;
                id = 'dsp:system:VariableFIRDecimator:fvtoolButtonOutputFrameLengthText';
            elseif isCoefSourceInputPort
                flag = false;
                id   = 'dsp:system:VariableFIRDecimator:fvtoolButtonCoeffsPortText';
            end
        end
    end

    methods(Static, Access=protected)
        %------------------------------------------------------------------
        function groups = getPropertyGroupsImpl
            props = {...
                matlab.system.display.internal.Property('Specification','Description','dsp:system:VariableFIRDecimator:Specification_MP'), ...
                matlab.system.display.internal.Property('OutputFrameLength','Description','dsp:system:VariableFIRDecimator:OutputFrameLength_MP'), ...
                matlab.system.display.internal.Property('MaxDecimationFactor','Description','dsp:system:VariableFIRDecimator:MaxDecimationFactor_MP'), ...
                matlab.system.display.internal.Property('DecimationFactorPort','Description','dsp:system:VariableFIRDecimator:DecimationFactorPort_MP'), ...
                matlab.system.display.internal.Property('DecimationFactor','Description','dsp:system:VariableFIRDecimator:DecimationFactor_MP'), ...
                matlab.system.display.internal.Property('CoefficientSource','Description','dsp:system:VariableFIRDecimator:CoefficientSource_MP'), ...
                matlab.system.display.internal.Property('Coefficients','Description','dsp:system:VariableFIRDecimator:Coefficients_MP')};
            parameterString = message('dsp:system:Shared:Parameters');
            groups = matlab.system.display.Section('Title', ...
                parameterString.getString, ...
                'PropertyList',props);
            filterVis = dsp.simulink.internal.FilterResponseVisualizationButton;
            groups.Actions = filterVis.visualizeAction;
        end
        %------------------------------------------------------------------
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.VariableFIRDecimator', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:system:VariableFIRDecimator:BlockName',...
                'Text', 'dsp:system:VariableFIRDecimator:BlockHeader');
        end
    end
end
