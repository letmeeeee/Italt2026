classdef (StrictDefaults)CICCompensationDecimator < dsp.CICCompensationDecimator 
% This class is used for the CIC Compensation Decimator block in
% dspfdesign.

%   Copyright 2021-2022 The MathWorks, Inc.

%#codegen
%#ok<*EMCA>

%----------------------------------------------------------------------
% Public methods
%----------------------------------------------------------------------
properties (Nontunable)
    %AllowArbitraryInputLength Allow arbitrary input length in Codegen
    %  When this flag is set to false, input frames in code generation
    %  must have a length that is a multiple of the decimation factor.
    %  Using an input which doesn't satisfy the length requirement
    %  results with an error.
    %  When this flag is set to true, input size is notrestricted and 
    %  can be arbitrary, but the output may have a variable size.
    %  Use this flag for cases that require fixed frame sizes, such
    %  as code generation requirements where the output size must be
    %  fixed. The default value is 'false'.
    AllowArbitraryInputLength (1,1) logical = false;
end
methods
    function obj = CICCompensationDecimator(varargin)
        obj = obj@dsp.CICCompensationDecimator(varargin{:});
    end
end
%----------------------------------------------------------------------
% Protected methods
%----------------------------------------------------------------------
methods (Access=protected)
    %------------------------------------------------------------------
    function validateInputsImpl(obj,varargin)
        u = varargin{1};
        if isempty(u)
            return;
        end

        if ~isempty(coder.target)
            D = obj.DecimationFactor;
            coder.internal.errorIf(~obj.AllowArbitraryInputLength &&...
                mod( size(u,1),D)~=0 && ...
                propagatedInputFixedSize(obj,1), ...
                'dsp:system:CICCompensationDecimator:inputSizeBlock', ...
                size(u,1),D);
        end

        if obj.NumChannels ~= -1 && obj.NumChannels ~= 0
            coder.internal.errorIf(size(u,2) ~= obj.NumChannels, ['dsp:system',...
                ':Shared:numChannels']);
        end
    end
    %------------------------------------------------------------------
    function isFixedOutput = isFixedSizeOutput(obj)
        % Varsize output if input is varsize or arbitrary input is allowed
        isFixedOutput = propagatedInputFixedSize(obj,1) && ~obj.AllowArbitraryInputLength;
    end
    %------------------------------------------------------------------    
    function varargout = getInputNamesImpl(~)
        % Name of input ports (shows on block icon)
        varargout{1} =   '';
    end
    %------------------------------------------------------------------
    function varargout = getOutputNamesImpl(~)
        % Name of output port (shows on block icon)
        varargout{1} =   '';
    end
    %------------------------------------------------------------------
    function icon = getIconImpl(~)
        % MATLAB system block icon
        icon = getString(message(...
                'dsp:system:CICCompensationDecimator:iconString'));
    end
    %------------------------------------------------------------------
    function val = supportsMultipleInstanceImpl(obj)
        % Support in for-each subsystem
        val = isFixedSizeOutput(obj);
    end
    %------------------------------------------------------------------
    function flag = isInputSizeMutableImpl(~,~)
        flag = true;
    end
    %------------------------------------------------------------------
    function isFixedOutput = isOutputFixedSizeImpl(obj)
        %if varsize input or arbitrary input allowed => varsize output,
        % otherwise fixed
        isFixedOutput = isFixedSizeOutput(obj);
    end
    %------------------------------------------------------------------
    % PROPAGATOR METHODS: (used by Simulink)
    %------------------------------------------------------------------
    function varargout = getOutputSizeImpl(obj)
        inputSize = propagatedInputSize(obj,1);
        if isempty(inputSize)
            varargout = inputSize;
        end
        fixedInput = propagatedInputFixedSize(obj, 1);
        if isempty(fixedInput)
            fixedInput = false;
        end
        arbLabel = message('dsp:blkprm_prompts:AllowArbitraryFixedInput_MP').string;
        coder.internal.errorIf((obj.AllowArbitraryInputLength == false) && ...
            (mod(inputSize(1),obj.DecimationFactor)~=0) && ...
            fixedInput, ...
            'dsp:system:CICCompensationDecimator:inputSizeBlock', ...
            inputSize(1),obj.DecimationFactor,arbLabel);
        varargout{1} = inputSize;
        varargout{1}(1) = ceil(varargout{1}(1)/obj.DecimationFactor);
    end
    %------------------------------------------------------------------
    function varargout = getOutputDataTypeImpl(obj)
        inputDT = propagatedInputDataType(obj,1);
        coder.internal.errorIf(obj.InheritSampleRate && ~ischar(inputDT), ...
            'dsp:system:FIRHalfbandDecimator:fixedPointWithInheritSampleRate');
        if isempty(inputDT)
            return;
        elseif (ischar(inputDT) && any(strcmp(inputDT,{'double', 'single'})))
            varargout{1} = inputDT;
        else
            num = dsp.CICCompensationDecimator.designCompensator( ...
                obj.DecimationFactor, obj.DesignForMinimumOrder, ...
                obj.CICNumSections, obj.CICDifferentialDelay, ...
                obj.CICRateChangeFactor, obj.FilterOrder, ...
                obj.PassbandFrequency, obj.StopbandFrequency, ...
                obj.PassbandRipple, obj.StopbandAttenuation, obj.SampleRate);
            w = fi(num, obj.CoefficientsDataType);  % vector of filter weights of type fi
            if ischar(inputDT)
                % For integer input
                inputDT = numerictype(inputDT);
            end
            [outputWL, outputFL] = coder.const(...
                @dsp.CICCompensationDecimator.filterPrecision, w, inputDT);
            varargout{1} = numerictype(1, outputWL, outputFL);
        end
    end
end
%----------------------------------------------------------------------
% Static protected methods
%----------------------------------------------------------------------
methods(Static,Access=protected)
    function groups = getPropertyGroupsImpl
        CICprops = dsp.internal.CICCompensationBase.getCICProperties;
        arbProps = matlab.system.display.internal.Property('AllowArbitraryInputLength', ...
                        Description='dsp:blkprm_prompts:AllowArbitraryFixedInput_MP');
        FilterProps = [{matlab.system.display.internal.Property('DecimationFactor', ...
                        Description='dsp:system:CICCompensationDecimator:DecimationFactor_MP')},... 
                       dsp.internal.CICCompensationBase.getFilterProperties,...
                       {arbProps}];
        
        CICSection = matlab.system.display.Section(...
            Title = 'dsp:system:CICCompensationBase:CICTitleString', ...
            PropertyList = CICprops);
        
        filterSection = matlab.system.display.Section(...
            Title = 'dsp:system:CICCompensationBase:FilterTitleString', ...
            PropertyList = FilterProps);
        
        filterVis = dsp.internal.FilterVisualizationButton;
        filterSection.Actions = filterVis.fvtoolAction;
        
        mainSG = matlab.system.display.SectionGroup(...
            TitleSource='Auto', ...
            Sections=[CICSection filterSection]);
        dtSG = matlab.system.display.internal.DataTypesGroup('dsp.CICCompensationDecimator');
        dtSG.PropertyList{2} = matlab.system.display.internal.DataTypeProperty('CoefficientsDataType', ...
            Prefix='coeffs', ...
            Description = 'dsp:system:CICCompensationBase:Coefficients_MP');
        groups = [mainSG, dtSG];
    end
    %------------------------------------------------------------------
    function header = getHeaderImpl
        % MATLAB System block header
        header = matlab.system.display.Header(...
            'dsp.simulink.CICCompensationDecimator', ...
            ShowSourceLink = true, ...
            Title = 'dsp:system:CICCompensationDecimator:titleString',...
            Text = 'dsp:system:CICCompensationDecimator:descriptionString');
    end
end
end
