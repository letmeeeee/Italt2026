classdef (StrictDefaults)CICCompensationInterpolator < dsp.CICCompensationInterpolator
% This class is used for the CIC Compensation Interpolator block in
% dspfdesign.

% Copyright 2021-2022 The MathWorks, Inc.

%#codegen
%#ok<*EMCA>

methods
    function obj = CICCompensationInterpolator(varargin)
        obj = obj@dsp.CICCompensationInterpolator(varargin{:});
    end
end

%----------------------------------------------------------------------
% Protected methods
%----------------------------------------------------------------------
methods (Access=protected)
    %------------------------------------------------------------------
    function varargout = getInputNamesImpl(~)
        % Name of input ports (shows on block icon)
        varargout{1} =   '';
    end
    %------------------------------------------------------------------
    function varargout = getOutputNamesImpl(~)
        % Name of output port (shows on block icon)
        varargout{1} =   '';
    end
    %------------------------------------------------------------------
    function icon = getIconImpl(~)
        % MATLAB system block icon
        icon = getString(message(...
                'dsp:system:CICCompensationInterpolator:iconString'));
    end
    %------------------------------------------------------------------
    function val = supportsMultipleInstanceImpl(~)
        % Support in for-each subsystem
        val = true;
    end
    % PROPAGATOR METHODS: (used by Simulink)
    %------------------------------------------------------------------
    function varargout = getOutputSizeImpl(obj)
        varargout{1} = propagatedInputSize(obj,1);
        varargout{1}(1) = varargout{1}(1)*obj.InterpolationFactor;
    end
    %------------------------------------------------------------------
    function varargout = getOutputDataTypeImpl(obj)
        inputDT = propagatedInputDataType(obj,1);
        coder.internal.errorIf(obj.InheritSampleRate && ~ischar(inputDT), ...
            'dsp:system:FIRHalfbandDecimator:fixedPointWithInheritSampleRate');
        if isempty(inputDT)
            return;
        elseif (ischar(inputDT) && any(strcmp(inputDT,{'double', 'single'})))
            varargout{1} = inputDT;
        else
            num = dsp.CICCompensationInterpolator.designCompensator(...
                obj.InterpolationFactor, obj.DesignForMinimumOrder, ...
                obj.CICNumSections, obj.CICDifferentialDelay, ...
                obj.CICRateChangeFactor, obj.FilterOrder, ...
                obj.PassbandFrequency, obj.StopbandFrequency, ...
                obj.PassbandRipple, obj.StopbandAttenuation, obj.SampleRate);
            w = fi(num, obj.CoefficientsDataType);  % vector of filter weights of type fi
            if ischar(inputDT)
                % For integer input
                inputDT = numerictype(inputDT);
            end
            [outputWL, outputFL] = coder.const(...
                @dsp.CICCompensationInterpolator.filterPrecision, ...
                w, inputDT, obj.InterpolationFactor);
            varargout{1} = numerictype(1, outputWL, outputFL);
        end
    end
    %------------------------------------------------------------------
    function varargout = isOutputComplexImpl(obj)
        varargout{1} = propagatedInputComplexity(obj,1);
    end
    %------------------------------------------------------------------
    function varargout = isOutputFixedSizeImpl(obj)
        varargout{1} = propagatedInputFixedSize(obj,1);
    end
    %------------------------------------------------------------------ 
    function postProcessSampleRate(obj,val)
        needToDesignFilters(obj);
        obj.pSR = val;
    end
end

%----------------------------------------------------------------------
% Static protected methods
%----------------------------------------------------------------------
methods(Static,Access=protected)
    function groups = getPropertyGroupsImpl
        CICprops = dsp.internal.CICCompensationBase.getCICProperties;

        FilterProps = [{matlab.system.display.internal.Property('InterpolationFactor', ...
                        Description='dsp:system:CICCompensationInterpolator:InterpolationFactor_MP')},... 
                       dsp.internal.CICCompensationBase.getFilterProperties];

        CICSection = matlab.system.display.Section(...
            Title='dsp:system:CICCompensationBase:CICTitleString', ...
            PropertyList=CICprops);
        
        filterSection = matlab.system.display.Section(...
            Title = 'dsp:system:CICCompensationBase:FilterTitleString', ...
            PropertyList = FilterProps); 
        
        filterVis = dsp.internal.FilterVisualizationButton;
        filterSection.Actions = filterVis.fvtoolAction;
        
        mainSG = matlab.system.display.SectionGroup(...
            TitleSource = 'Auto', ...
            Sections = [CICSection filterSection]);

        dtSG = matlab.system.display.internal.DataTypesGroup('dsp.CICCompensationInterpolator');

        dtSG.PropertyList{2} = matlab.system.display.internal.DataTypeProperty('CoefficientsDataType', ...
            Prefix = 'coeffs', ...
            Description = 'dsp:system:CICCompensationBase:Coefficients_MP');
        groups = [mainSG, dtSG];
    end
    %------------------------------------------------------------------
    function header = getHeaderImpl
        % MATLAB System block header
        header = matlab.system.display.Header(...
            'dsp.simulink.CICCompensationInterpolator', ...
            ShowSourceLink = true, ...
            Title = 'dsp:system:CICCompensationInterpolator:titleString',...
            Text = 'dsp:system:CICCompensationInterpolator:descriptionString');
    end
end
end
