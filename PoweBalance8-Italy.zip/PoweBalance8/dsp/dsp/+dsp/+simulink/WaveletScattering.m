classdef WaveletScattering < matlab.System

% This class is used in the Wavelet Scattering block

% Copyright 2022 The MathWorks, Inc.

%#codegen
%#ok<*EMCLS>

    properties (Nontunable)
        % SignalLength Signal length
        SignalLength = 1024
        % SpecifySampleRate Specify sample rate
        SpecifySampleRate (1,1) logical = false
        % SampleRate Sample rate (Hz)
        SampleRate = 16e3
        % InvarianceScaleSamples Invariance scale (samples)
        InvarianceScaleSamples = 512
        % InvarianceScaleSeconds Invariance scale (s)
        InvarianceScaleSeconds = 0.032
        % QualityFactors Quality factors
        QualityFactors = [8 1]
        % Boundary Boundary
        Boundary (1,:) char {mustBeMember(Boundary,{'periodic' 'reflection'})} = 'periodic'
        % OversamplingFactor Oversampling factor
        OversamplingFactor = 0
        % OptimizePath Optimize path
        OptimizePath (1,1) logical = false
        % FeatureMatrixNormalization Feature matrix normalization
        FeatureMatrixNormalization (1,:) char {mustBeMember(FeatureMatrixNormalization,{'parent' 'none'})} = 'none' 
        % FeatureMatrixTransform Feature matrix transform
        FeatureMatrixTransform (1,:) char {mustBeMember(FeatureMatrixTransform,{'log' 'none'})} = 'none' 
        % IncludeZeroOrderCoeff Include the zeroth-order scattering coefficients
        IncludeZeroOrderCoeff (1,1) logical  = false;
    end

    properties(Access = private)
        pWaveletScatterer
    end

    properties (Access = private, Nontunable)
        % pNumCoefficients Determines output first dimension
        pNumCoefficients
        % pNumPaths Determines output second dimension
        pNumPaths
    end

    methods
        % Constructor
        function obj = WaveletScattering(varargin)
            setProperties(obj, nargin, varargin{:});
        end

        function set.SampleRate(obj,val)
            validateattributes(val,...
                {'double','single'},...
                {'real','scalar','finite','>',0},...
                '','SampleRate');
            obj.SampleRate = val;
        end


        function set.SignalLength(obj,val)
            validateattributes(val,...
                {'numeric'},...
                {'real','scalar','finite','positive','integer'},...
                '','SignalLength');
            obj.SignalLength = val;
        end

        function set.InvarianceScaleSamples(obj,val)
            validateattributes(val,...
                {'numeric'},...
                {'real','scalar','finite','positive','integer'},...
                '','InvarianceScaleSamples');
            obj.InvarianceScaleSamples = val;
        end

        function set.InvarianceScaleSeconds(obj,val)
            validateattributes(val,...
                {'numeric'},...
                {'real','scalar','finite','positive'},...
                '','InvarianceScaleSeconds');
            obj.InvarianceScaleSeconds = val;
        end

        function set.OversamplingFactor(obj,val)
            if ~(isinf(val)&& val>=0)
                validateattributes(val,{'numeric'},...
                    {'scalar','nonnegative','integer'},'','OversamplingFactor');
            end
            obj.OversamplingFactor = val;
        end

        function set.QualityFactors(obj,val)
            validateattributes(val,{'numeric'},...
                {'vector','real','nonincreasing','integer','<=',32},'','QualityFactors');
            obj.QualityFactors = val;
        end

    end

    methods(Access = protected)
        function setupImpl(obj,u)
            coder.extrinsic('dsp.simulink.WaveletScattering.getDimensions');
            if obj.SpecifySampleRate
                obj.pWaveletScatterer = waveletScattering("SignalLength",obj.SignalLength,...
                    "SamplingFrequency",double(obj.SampleRate),...
                    "InvarianceScale",double(obj.InvarianceScaleSeconds),...
                    "QualityFactors",double(obj.QualityFactors),...
                    "Boundary",obj.Boundary,...
                    "Precision",class(u),...
                    "OversamplingFactor",double(obj.OversamplingFactor),...
                    "OptimizePath",obj.OptimizePath);
                % Determine output size
                [obj.pNumCoefficients,obj.pNumPaths] = coder.const(@obj.getDimensions,obj.SignalLength,obj.InvarianceScaleSeconds,obj.QualityFactors,obj.Boundary,obj.OversamplingFactor,obj.OptimizePath,obj.SampleRate);
            else
                obj.pWaveletScatterer = waveletScattering("SignalLength",obj.SignalLength,...
                    "InvarianceScale",double(obj.InvarianceScaleSamples),...
                    "QualityFactors",double(obj.QualityFactors),...
                    "Boundary",obj.Boundary,...
                    "Precision",class(u),...
                    "OversamplingFactor",double(obj.OversamplingFactor),...
                    "OptimizePath",obj.OptimizePath);
                % Determine output size
                [obj.pNumCoefficients,obj.pNumPaths] = coder.const(@obj.getDimensions,obj.SignalLength,obj.InvarianceScaleSamples,obj.QualityFactors,obj.Boundary,obj.OversamplingFactor,obj.OptimizePath,-1);
            end
        end

        function varargout = stepImpl(obj,u)
            fm = featureMatrix(obj.pWaveletScatterer,u,'Normalization',obj.FeatureMatrixNormalization,'Transform',obj.FeatureMatrixTransform);
            % Indexing necessary for codegen
            if obj.IncludeZeroOrderCoeff
                fm = fm(1:obj.pNumPaths,1:obj.pNumCoefficients,1:size(u,2),1:size(u,3));
            else
                fm = fm(2:obj.pNumPaths,1:obj.pNumCoefficients,1:size(u,2),1:size(u,3));
            end
            varargout{1} = fm;
        end

        function n = getNumOutputsImpl(~)
            n = 1;
        end

        function n = getOutputNamesImpl(~)
            n = '';
        end

        function varargout = isOutputComplexImpl(~)
            varargout{1} = false;
        end
        
        function varargout = getOutputSizeImpl(obj)
            coder.extrinsic('dsp.simulink.WaveletScattering.getDimensions');
            if obj.SpecifySampleRate
                [nC,nP] = coder.const(@obj.getDimensions,obj.SignalLength,obj.InvarianceScaleSeconds,obj.QualityFactors,obj.Boundary,obj.OversamplingFactor,obj.OptimizePath,obj.SampleRate);
            else
                [nC,nP] = coder.const(@obj.getDimensions,obj.SignalLength,obj.InvarianceScaleSamples,obj.QualityFactors,obj.Boundary,obj.OversamplingFactor,obj.OptimizePath,-1);
            end
            if ~obj.IncludeZeroOrderCoeff
                nP = nP - 1;
            end
            sz0 = propagatedInputSize(obj, 1);
            if isempty(sz0)
                varargout{1} = [];
                return
            end

            if numel(sz0)==2
                if sz0(2)==1
                    varargout{1} = [nP,nC];
                else
                    varargout{1} = [nP,nC,sz0(2)];
                end
            else
                if sz0(2)==1
                    varargout{1} = [nP,nC,1,sz0(3)];
                else
                    varargout{1} = [nP,nC,sz0(2),sz0(3)];
                end
            end
        end

        function varargout = getOutputDataTypeImpl(obj)
            varargout{1} = propagatedInputDataType(obj,1);
        end
        
        function varargout = isOutputFixedSizeImpl(~)
            varargout{1} = true;
        end

        function flag = isInactivePropertyImpl(obj, prop)
            flag = false;
            if strcmp(prop,'InvarianceScaleSeconds') || strcmp(prop,'SampleRate')
                flag = ~obj.SpecifySampleRate;
            end
            if strcmp(prop,'InvarianceScaleSamples')
                flag = obj.SpecifySampleRate;
            end
        end

        function s = saveObjectImpl(obj)
            % Default implementation saves all public properties
            s = saveObjectImpl@matlab.System(obj);
            if isLocked(obj)
                s.pNumCoefficients = obj.pNumCoefficients;
                s.pNumPaths = obj.pNumPaths;                
                s.pWaveletScatterer = saveobj(obj.pWaveletScatterer);
            end
        end
        
        function s = loadObjectImpl(obj, s, wasLocked)
            % Re-load state if saved version was locked
            if wasLocked
                obj.pNumCoefficients = s.pNumCoefficients;
                obj.pNumPaths = s.pNumPaths;     
                obj.pWaveletScatterer = loadobj(s.pWaveletScatterer);  
            end
            loadObjectImpl@matlab.System(obj,s,wasLocked);
        end

        function val = supportsMultipleInstanceImpl(~)
            % For "For Each" support of the MATLAB System block
            val = true;
        end
    end

    methods (Access = protected, Static)
        function group = getPropertyGroupsImpl
            group =  matlab.system.display.Section(...
                'Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', {...
                'SignalLength' 'SpecifySampleRate' 'SampleRate' 'InvarianceScaleSeconds' 'InvarianceScaleSamples' 'IncludeZeroOrderCoeff' 'QualityFactors' 'Boundary' 'OversamplingFactor' 'OptimizePath' 'FeatureMatrixNormalization' 'FeatureMatrixTransform'});
        end

        function header = getHeaderImpl
            header =  matlab.system.display.Header('WaveletScattering', ...
                'ShowSourceLink', true, 'Title','Wavelet Scattering', ...
                'Text', 'Perform wavelet scattering');
        end
    end

    methods (Static, Hidden)
        function [numC,numP] = getDimensions(SignalLength,InvarianceScale,QualityFactors,Boundary,OversamplingFactor,OptimizePath,SampleRate)
            if SampleRate ==-1
                w = waveletScattering("SignalLength",SignalLength,...
                    "InvarianceScale",InvarianceScale,...
                    "QualityFactors",QualityFactors,...
                    "Boundary",Boundary,...
                    "OversamplingFactor",OversamplingFactor,...
                    "OptimizePath",OptimizePath);
            else
                w = waveletScattering("SignalLength",SignalLength,...
                    "SamplingFrequency",SampleRate,...
                    "InvarianceScale",InvarianceScale,...
                    "QualityFactors",QualityFactors,...
                    "Boundary",Boundary,...
                    "OversamplingFactor",OversamplingFactor,...
                    "OptimizePath",OptimizePath);
            end
            numC = numCoefficients(w);
            [~,p] = paths(w);
            numP = sum(p);

        end
    end
end