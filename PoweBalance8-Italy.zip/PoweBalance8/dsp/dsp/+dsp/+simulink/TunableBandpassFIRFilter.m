classdef TunableBandpassFIRFilter < dsp.internal.TunableBandpassFIRFilter
    % TunableHighpassFIRFilter Design bandpass FIR filter with tunable
    % specifications

    %   Copyright 2022-2023 The MathWorks, Inc.

    %#codegen

    properties(Nontunable)
        %FilterOrderPort Specify filter order from input port
        FilterOrderPort (1,1) logical = false;
        %CenterFrequencyPort Specify center frequency from input port
        CenterFrequencyPort (1,1) logical = false;
        %BandwidthPort Specify bandwidth from input port
        BandwidthPort (1,1) logical = false;
        %SidelobeAttenuationPort Specify sidelobe attenuation from input
        %port
        SidelobeAttenuationPort (1,1) logical = false;
        %KaiserWindowParameterPort Specify kaiser window parameter from
        %input port
        KaiserWindowParameterPort (1,1) logical = false;
        %SampleTime Sample time (s)
        %   Specify sample time as a positive scalar in seconds -1 for
        %   inherited or Inf for constant. The default is -1.
        SampleTime = -1;
    end

    properties (Constant, Hidden)
        FilterOrderSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.TunableLowpassHighpassFIRPolicy('SystemBlock', 'FilterOrderPort', 1, 'N'), ...
            {'Property','MATLAB','FilterOrderPort'});
        CenterFrequencySet = matlab.system.SourceSet( ...
            dsp.simulink.internal.TunableBandpassBandstopFIRPolicy('SystemBlock', 'CenterFrequencyPort', 2, 'Fc'), ...
            {'Property','MATLAB','CenterFrequencyPort'});
        BandwidthSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.TunableBandpassBandstopFIRPolicy('SystemBlock', 'BandwidthPort', 3, 'BW'), ...
            {'Property','MATLAB','BandwidthPort'});
        SidelobeAttenuationSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.TunableBandpassBandstopFIRPolicy('SystemBlock', 'SidelobeAttenuationPort', 4, 'r'), ...
            {'Property','MATLAB','SidelobeAttenuationPort'});
        KaiserWindowParameterSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.TunableBandpassBandstopFIRPolicy('SystemBlock', 'KaiserWindowParameterPort', 5, 'beta'), ...
            {'Property','MATLAB','KaiserWindowParameterPort'});
    end

    methods
        %------------------------------------------------------------------
        % Constructor
        function this = TunableBandpassFIRFilter(varargin)
            % Support name-value pair arguments when constructing object
            setProperties(this,nargin,varargin{:})
        end
        %------------------------------------------------------------------
        function set.SampleTime(this, value)
            validateattributes(value, {'double','single'}, {'real','scalar'}, 'set.SampleTime','SampleTime');
            this.SampleTime = value;
        end
    end

    methods(Access = protected)
        %------------------------------------------------------------------
        function flag = isInputSizeMutableImpl(~,~)
            % Return false if input size cannot change
            % between calls to the System object
            flag = false;
        end
        %------------------------------------------------------------------
        function num = getNumOutputsImpl(~)
            % Define total number of outputs for system with optional
            % outputs
            num = 1;
        end
        %------------------------------------------------------------------
        function flag = isOutputFixedSizeImpl(~)
            % Return false if input size cannot change
            % between calls to the System object
            flag = true;
        end
        %------------------------------------------------------------------
        function flag = isOutputComplexImpl(~)
            flag = false;
        end
        %------------------------------------------------------------------
        function b = getOutputSizeImpl(this)
            % Return size for each output port
            dims = getCoefficientsDimensions(this);
            b = dims;
        end
        %------------------------------------------------------------------
        function out = getOutputDataTypeImpl(this)
            dt = this.OutputDataType;
            out = dt;
        end
        %------------------------------------------------------------------
        function name = getOutputNamesImpl(~)
            name = "Num";
        end
        %------------------------------------------------------------------
        function icon = getIconImpl(~)
            icon = getString(message('dsp:system:TunableFIRFilter:TunableBPFFIRBlockIcon'));
        end
        %------------------------------------------------------------------
        function val = supportsMultipleInstanceImpl(~,~)
            % For "For Each" support of the MATLAB System block
            val = true;
        end
        %------------------------------------------------------------------
        function validateCenterFrequency(this, value, varargin)
            validateCenterFrequency@dsp.internal.TunableBandpassFIRFilter(this, value, this.CenterFrequencyPort);
        end
        %------------------------------------------------------------------
        function validateBandwidth(this, value, varargin)
            validateBandwidth@dsp.internal.TunableBandpassFIRFilter(this, value, this.BandwidthPort);
        end
        %------------------------------------------------------------------
        function validateSidelobeAttenuation(this, value, varargin)
            validateSidelobeAttenuation@dsp.internal.AbstractTunableFIRFilter(this, value, this.SidelobeAttenuationPort);
        end
        %------------------------------------------------------------------
        function sts = getSampleTimeImpl(this)
            if this.SampleTime == -1
                sts = createSampleTime(this,'Type','Inherited');
            else
                sts = createSampleTime(this,'Type','Discrete','SampleTime', this.SampleTime);
            end
        end
    end

    methods(Static, Access = protected)
        %------------------------------------------------------------------
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.TunableBandpassFIRFilter', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:system:TunableFIRFilter:TunableBPFFIRBlockName',...
                'Text', 'dsp:system:TunableFIRFilter:TunableBPFFIRBlockHeader');
        end
        %------------------------------------------------------------------
        function groups = getPropertyGroupsImpl
            props = {...
                matlab.system.display.internal.Property('FilterOrderPort','Description','dsp:system:TunableFIRFilter:FilterOrderPort_MP'), ...
                matlab.system.display.internal.Property('FilterOrder','Description','dsp:system:TunableFIRFilter:FilterOrder_MP'), ...
                matlab.system.display.internal.Property('MaxOrder','Description','dsp:system:TunableFIRFilter:MaxOrder_MP'), ...
                matlab.system.display.internal.Property('CenterFrequencyPort','Description','dsp:system:TunableFIRFilter:CenterFrequencyPort_MP'), ...
                matlab.system.display.internal.Property('CenterFrequency','Description','dsp:system:TunableFIRFilter:CenterFrequency_MP'), ...
                matlab.system.display.internal.Property('BandwidthPort','Description','dsp:system:TunableFIRFilter:BandwidthPort_MP'), ...
                matlab.system.display.internal.Property('Bandwidth','Description','dsp:system:TunableFIRFilter:Bandwidth_MP'), ...
                matlab.system.display.internal.Property('Window','Description','dsp:system:TunableFIRFilter:Window_MP'), ...
                matlab.system.display.internal.Property('SidelobeAttenuationPort','Description','dsp:system:TunableFIRFilter:SidelobeAttenuationPort_MP'), ...
                matlab.system.display.internal.Property('SidelobeAttenuation','Description','dsp:system:TunableFIRFilter:SidelobeAttenuation_MP'), ...
                matlab.system.display.internal.Property('KaiserWindowParameterPort','Description','dsp:system:TunableFIRFilter:KaiserWindowParameterPort_MP'), ...
                matlab.system.display.internal.Property('KaiserWindowParameter','Description','dsp:system:TunableFIRFilter:KaiserWindowParameter_MP'), ...
                matlab.system.display.internal.Property('SampleTime','Description','dsp:system:TunableFIRFilter:SampleTime_MP'), ...
                matlab.system.display.internal.Property('OutputDataType','Description','dsp:system:TunableFIRFilter:OutputDataType_MP')};
            groups = matlab.system.display.Section('Title', ...
                'dsp:system:Shared:Parameters', ...
                'PropertyList',props);
        end
    end
end
