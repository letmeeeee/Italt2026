classdef (StrictDefaults)DCBlocker < dsp.DCBlocker
    %DCBlocker Block DC component from input signal
    % This class is used in the DC Blocker block in dspsigops

    % Copyright 2021 The MathWorks, Inc.

    %#codegen
    %#ok<*EMCA>

    methods (Access=protected)
        function icon = getIconImpl(~)
            icon = getString(message('dsp:system:DCBlocker:BlockIcon'));
        end

        function varargout = getInputNamesImpl(obj)
            varargout = cell(1, getNumInputs(obj));
            varargout{1} = '';
        end

        function varargout = getOutputNamesImpl(obj)
            varargout = cell(1, getNumOutputs(obj));
            varargout{1} = '';
        end

        function varargout = getOutputSizeImpl(obj)
            varargout = {propagatedInputSize(obj, 1)};
        end

        function varargout = getOutputDataTypeImpl(obj)
            varargout = {propagatedInputDataType(obj, 1)};
        end

        function varargout = isOutputComplexImpl(obj)
            varargout = {propagatedInputComplexity(obj, 1)};
        end

        function flag =  supportsMultipleInstanceImpl(~)
            flag = true;
        end

        function sts = getSampleTimeImpl(obj)
            if strcmpi(obj.Algorithm, 'Subtract mean')
                % the object has no state in this mode. Allow const sample time
                mode =  'Allow';
            else % object has state
                mode = 'Disallow';
            end

            sts = createSampleTime(obj, 'Type', 'Inherited', mode, 'Constant');
        end

    end

    methods(Static, Access = protected)
        function header = getHeaderImpl
            header = matlab.system.display.Header('dsp.simulink.DCBlocker', ...
                'Title', 'dsp:system:DCBlocker:BlockName',...
                'Text', 'dsp:system:DCBlocker:BlockHeader');
        end

        function mainS = getPropertyGroupsImpl

            props = {...
                matlab.system.display.internal.Property('Algorithm','Description','dsp:system:DCBlocker:Algorithm_MP'), ...
                matlab.system.display.internal.Property('NormalizedBandwidth','Description','dsp:system:DCBlocker:NormalizedBandwidth_MP'), ...
                matlab.system.display.internal.Property('Length','Description','dsp:system:DCBlocker:Length_MP'), ...
                matlab.system.display.internal.Property('Order','Description','dsp:system:DCBlocker:Order_MP')};
       
            mainS = matlab.system.display.Section('Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', props);

            filterVis = dsp.internal.FilterVisualizationButton;
            mainS.Actions = filterVis.fvtoolAction;

        end
    end

    methods (Hidden)
        function [flag,errID] = isFVtoolSupported(~)
            % Method used for 'visualize' button on block
            flag = true;
            errID = '';
        end

        function f = callFvtool(obj)
            % Used to bring up fvtool plot when object is used in Simulink
            f = fvtool(obj);
        end

        function f = updateFvtoolFigure(obj, f)
            % Used to update fvtool plot when object is used in Simulink
            usingSubtractMean = strcmpi(obj.Algorithm, 'Subtract mean');
            coder.internal.errorIf(usingSubtractMean, ...
                'dsp:system:DCBlocker:DCBlocker_novisualization');

            filt = getFVTOOLFilter(obj);
            setfilter(f, filt);

            if strcmpi(obj.Algorithm, 'CIC')
                Mcic = dsp.DCBlocker.computeDiffDelayForCIC(obj.NormalizedBandwidth);
                msg = sprintf(['Number of sections = 2\nDifferential delay = ' ...
                    num2str(Mcic) ' samples']);
                annotation('textbox', [0.65, 0.7, 0.1, 0.1], ...
                    'String', msg);
            else
                % Delete a previous annotation that may have been left behind by
                % CIC filter visualization
                ah = findall(get(get(f, 'CurrentAxes'), 'Parent'), 'Type', 'textbox');
                if ~isempty(ah) && isvalid(ah)
                    delete(ah);
                end
            end
        end

        function f = updateFvtoolLegend(~, f, blkh)
            % Used to update fvtool legend when object is used in Simulink
            legend(f, get_param(blkh, 'Name'));
        end
    end
end
