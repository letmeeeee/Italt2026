classdef (StrictDefaults)HighpassFilter < dsp.HighpassFilter
    %

    % Copyright 2021-2022 The MathWorks, Inc.
        
    %#codegen
    %#ok<*EMCA>
    methods
        function obj = HighpassFilter(varargin)
            obj@dsp.HighpassFilter(varargin{:});
        end
    end
    %----------------------------------------------------------------------
    methods(Static,Hidden,Access=protected)
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.HighpassFilter', ...
                ShowSourceLink=true, ...
                Title='dsp:system:HPLPFilter:HPBlockName',...
                Text='dsp:system:HPLPFilter:HPBlockHeader');
        end
        function groups = getPropertyGroupsImpl
            props = {...
                matlab.system.display.internal.Property('FilterType',Description = 'dsp:system:HPLPFilter:FilterType_MP'), ...
                matlab.system.display.internal.Property('DesignForMinimumOrder',Description = 'dsp:system:HPLPFilter:DesignForMinimumOrder_MP'), ...
                matlab.system.display.internal.Property('FilterOrder',Description = 'dsp:system:HPLPFilter:FilterOrder_MP'), ...
                matlab.system.display.internal.Property('StopbandFrequency',Description = 'dsp:system:HPLPFilter:StopbandFrequency_MP'), ...
                matlab.system.display.internal.Property('PassbandFrequency',Description = 'dsp:system:HPLPFilter:PassbandFrequency_MP'), ...
                matlab.system.display.internal.Property('StopbandAttenuation',Description = 'dsp:system:HPLPFilter:StopbandAttenuation_MP'), ...
                matlab.system.display.internal.Property('PassbandRipple',Description = 'dsp:system:HPLPFilter:PassbandRipple_MP'), ...
                matlab.system.display.internal.Property('SampleRateMode',Description = 'dsp:system:HPLPFilter:SampleRateMode_MP'), ...
                matlab.system.display.internal.Property('SampleRate',Description = 'dsp:system:HPLPFilter:SampleRate_MP')};
            
            mainS = matlab.system.display.Section(Title='dsp:system:Shared:Parameters', PropertyList=props);
            filterVis = dsp.internal.FilterVisualizationButton;
            mainS.Actions = filterVis.fvtoolAction;
            mainSG = matlab.system.display.SectionGroup(TitleSource='Auto', Sections=mainS);

            dtSG = matlab.system.display.internal.DataTypesGroup('dsp.simulink.HighpassFilter');
            dtSG.PropertyList{2} = matlab.system.display.internal.DataTypeProperty('CoefficientsDataType', ...
                Prefix='coeffs', ...
                Description='dsp:system:Shared:Coefficients');
            groups = [mainSG, dtSG];
        end
    end
    methods (Static, Hidden)
        function a = getAlternateBlock
            a = [];
        end
    end
    %----------------------------------------------------------------------
    methods (Access=protected)
        % Block Icon
        function icon = getIconImpl(~)
            iconStr = getString(message('dsp:system:HPLPFilter:HPBlockIcon'));
            icon = sprintf(iconStr);
        end
        function flag = isInactivePropertyImpl(obj, prop)            
            switch prop
                case {'NormalizedFrequency'}
                    flag = true;
                otherwise
                    flag = isInactivePropertyImpl@dsp.internal.LPHPFilterBase(obj,prop);
            end
        end 
        function validatePropertiesImpl(obj)
            if ~isSampleRateInherited(obj)
                crossValidateProperties(obj);
            end            
        end        
    end
    methods (Hidden)
        function [flag,errID] = isFVtoolSupported(obj)
            flag = true;
            errID = '';
            if isprop(obj, 'SampleRateMode')
               if isSampleRateInherited(obj)
                  flag = false;
                  errID = 'dsp:system:Shared:fvtoolButtonInheritSRTexDropdown';
               end
            end
        end
        function f = updateFvtoolFigure(obj,f)
            % Used to update fvtool plot when object is used in Simulink
            setfilter(f, obj);
            if isSampleRateNormalized(obj)
                f.NormalizedFrequency = 'on';
            else
                f.NormalizedFrequency = 'off';
            end

        end
    end
end
