classdef LMSUpdate < dsp.internal.LMSUpdate
% This class is used in the LMS Update block
%
%   See also dsp.LMSFilter, dsp.BlockLMSFilter

%   Copyright 1995-2021 The MathWorks, Inc.

%#codegen

%For MATLAB compiler support

%#ok<*EMCLS>
%#ok<*EMCA>

methods
    %CONSTRUCTOR
    function obj = LMSUpdate(varargin)
        obj@dsp.internal.LMSUpdate(varargin{:})
    end    
    
end

methods(Access=protected)         
    
    function flag = supportsMultipleInstanceImpl(~)
        flag = true;
    end
    
    function sts = getSampleTimeImpl(obj)
        sts = createSampleTime(obj, 'Type', 'Inherited', ...
                               'Disallow', 'Constant');
    end

    %%Propagators
    function varargout = getOutputSizeImpl(obj)
        % Output size propagator
        varargout = {[obj.NumFilters obj.Length]}; 
    end 

    function varargout = isOutputFixedSizeImpl(~)
        varargout{1} = true;
    end
   
    function varargout = getOutputDataTypeImpl(obj)
        % Output datatype propagator
        varargout = {propagatedInputDataType(obj, 1)};
    end
    
    function varargout = isOutputComplexImpl(obj)
        % Complexity propagator
        prpgtCplx = propagatedInputComplexity(obj,1) || propagatedInputComplexity(obj,2);
        varargout{1} = prpgtCplx;
    end

    function varargout = getInputNamesImpl(obj)
        varargout = cell(1, getNumInputs(obj));
        inPortIdx = 1;
        varargout{inPortIdx} = ...
            getString(message('dsp:system:LMSUpdate:InputPortLabel'));
        inPortIdx = inPortIdx + 1;
        varargout{inPortIdx} = ...
            getString(message('dsp:system:LMSUpdate:ErrorPortLabel'));

        if strcmp(obj.StepSizeSource, 'Input port')
            inPortIdx = inPortIdx + 1;
            varargout{inPortIdx} = ...
                getString(message('dsp:system:LMSUpdate:StepSizePortLabel'));
        end
        
        if (obj.EnableAdaptInput)
            inPortIdx = inPortIdx + 1;
            varargout{inPortIdx} = ...
                getString(message('dsp:system:LMSUpdate:AdaptPortLabel'));
        end
        
        if (obj.EnableResetInput)
            inPortIdx = inPortIdx + 1;
            varargout{inPortIdx} = ...
                getString(message('dsp:system:LMSUpdate:ResetPortLabel'));
        end
    end
    
    function varargout = getOutputNamesImpl(~)
        varargout{1} = ...
            getString(message('dsp:system:LMSUpdate:WeightsPortLabel'));
    end    
 
        
    function icon = getIconImpl(~)
        % MATLAB system block icon
        icon = getString(message('dsp:system:LMSUpdate:BlockTitle'));
    end
    
end

%----------------------------------------------------------------------
% Static, Protected methods
%----------------------------------------------------------------------
methods(Static, Access=protected)
    function header = getHeaderImpl
        % MATLAB System block header
        header = matlab.system.display.Header( ...
            'dsp.simulink.LMSUpdate', ...
            'ShowSourceLink', true, ...
            'Title', 'dsp:system:LMSUpdate:BlockTitle', ...
            'Text',  'dsp:system:LMSUpdate:BlockHeader');
    end

    function mainS = getPropertyGroupsImpl
        props = {...
            matlab.system.display.internal.Property('Method','Description','dsp:system:LMSUpdate:Method_MP'), ...
            matlab.system.display.internal.Property('Length','Description','dsp:system:LMSUpdate:Length_MP'),...
            matlab.system.display.internal.Property('NumFilters','Description','dsp:system:LMSUpdate:NumFilters_MP'),...
            matlab.system.display.internal.Property('StepSizeSource','Description','dsp:system:LMSUpdate:StepSizeSource_MP'),...
            matlab.system.display.internal.Property('StepSize','Description','dsp:system:LMSUpdate:StepSize_MP'),...
            matlab.system.display.internal.Property('LeakageFactor','Description','dsp:system:LMSUpdate:LeakageFactor_MP'),...
            matlab.system.display.internal.Property('InitialConditions','Description','dsp:system:LMSUpdate:InitialConditions_MP'),...
            matlab.system.display.internal.Property('AdaptiveFilterMode','Description','dsp:system:LMSUpdate:AdaptiveFilterMode_MP'),...
            matlab.system.display.internal.Property('EnableAdaptInput','Description','dsp:system:LMSUpdate:EnableAdaptInput_MP'),...
            matlab.system.display.internal.Property('EnableResetInput','Description','dsp:system:LMSUpdate:EnableResetInput_MP'),...
           };


        parameterString = message('dsp:system:Shared:Parameters');
        mainS = matlab.system.display.Section('Title', ...
            parameterString.getString, ...
            'PropertyList',props);
    end
end

end
