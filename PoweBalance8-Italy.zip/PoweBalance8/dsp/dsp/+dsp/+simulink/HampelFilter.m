classdef (StrictDefaults)HampelFilter < dsp.HampelFilter
    
% This class is used in the Hampel filter block. 
    
% Copyright 2016-2022 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCLS>
    
    properties(Nontunable)
        % EnableIsOutlierOutput Output outlier status
        EnableIsOutlierOutput (1, 1) logical = false; 
    
        % ThresholdPort Specify threshold from input port
        ThresholdPort (1, 1) logical = false;
    end
     
    properties (Constant, Hidden)
        % ThresholdSet is used to setup the choices for Threshold
        ThresholdSet = matlab.system.SourceSet({'PropertyOrInput', ...
            'SystemBlock', 'ThresholdPort', 1, 'T'});
    end

    methods
        
        % Constructor 
        function obj = HampelFilter(varargin)
            obj = obj@dsp.HampelFilter(varargin{:});
        end 
        
    end
    
    methods(Access = protected)
        
        function validateInputsImpl(obj,varargin)
            validateInputsImpl@dsp.HampelFilter(obj,varargin{1});
        end
        
        function numchans = getNumChans(obj,~)
            thisSize = propagatedInputSize(obj, 1);
            numchans = thisSize(2);
        end
        
        function varargout = stepImpl(obj,u)
           outputs = cell(2,1);
           [y,isOutlier] = step(obj.pMID,u);

           outputs{1} = y;
           outputs{2} = isOutlier;
           
           for i = 1:nargout
               varargout{i} = outputs{i};
           end
        end
        
        function num = getNumOutputsImpl(obj)
            num = 1 + obj.EnableIsOutlierOutput;
        end
        
        function flag = supportsMultipleInstanceImpl(~)
            flag = true;
        end
        
        function dt = getTunablePropertiesSpecificationImpl(obj,~)
            dt = propagatedInputDataType(obj,1);
        end
        
        %% Block Icon
        function icon = getIconImpl(~)
            icon = getString(message('dsp:StatisticsBlockDialog:HampelFilterIcon'));
        end
        
        %%Propagators
        function [cplx1,cplx2] = isOutputComplexImpl(obj)
            % Complexity propagator
            cplx1 = propagatedInputComplexity(obj,1);
            cplx2 = false;
        end
        
        function sts = getSampleTimeImpl(obj)
            sts = createSampleTime(obj, Type='Inherited', Disallow='Constant');
        end
        
        function [sz1,sz2] = getOutputSizeImpl(obj)
            % Output size propagator
            sz1 = propagatedInputSize(obj,1);
            sz2 = sz1;
        end
        
        function [dt1,dt2] = getOutputDataTypeImpl(obj)
            % Output datatype propagator
            dt1 = propagatedInputDataType(obj,1);
            dt2 = 'logical';
        end
        
        function [isfixed1,isfixed2] = isOutputFixedSizeImpl(obj)
            [isfixed1] = propagatedInputFixedSize(obj,1);
            [isfixed2] = isfixed1;
        end
        
        function name = getInputNamesImpl(obj)
            if obj.ThresholdPort
                name = 'x';
            else
                name = '';
            end
        end
        
        function varargout = getOutputNamesImpl(obj)
            if ~obj.EnableIsOutlierOutput
                varargout{1} = '';
            else
                varargout{1} = 'y';
                varargout{2} = 'outlier';
            end
        end
        
    end
    
    %% Block header - widget grouping
    methods(Static, Access=protected)
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.HampelFilter', ...
                ShowSourceLink=true, ...
                Title='dsp:StatisticsBlockDialog:HampelFilterTitle',...
                Text='dsp:StatisticsBlockDialog:HampelFilterHeader');
        end
        
        function groups = getPropertyGroupsImpl
            % Block property ordering
            propertyList = {
                matlab.system.display.internal.Property('WindowLength', Description='dsp:StatisticsBlockDialog:WindowLength_MP'), ...
                matlab.system.display.internal.Property('ThresholdPort', Description='dsp:StatisticsBlockDialog:ThresholdPort_MP'), ...
                matlab.system.display.internal.Property('Threshold', Description='dsp:StatisticsBlockDialog:Threshold_MP'), ...
                matlab.system.display.internal.Property('EnableIsOutlierOutput', Description='dsp:StatisticsBlockDialog:EnableIsOutlierOutput_MP'), ...
            };

            parameterString = message('dsp:system:Shared:Parameters');

            tabGroup = matlab.system.display.Section(Title = parameterString.getString, PropertyList = propertyList);

            groups = tabGroup;
        end
    end
    
end
