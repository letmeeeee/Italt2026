classdef (StrictDefaults)Pseudoinverse < matlab.System 
% This System object used under dspinverses/Pseudoinverse block.

    %#codegen
    %#ok<*EMCLS>

%   Copyright 2015-2021 The MathWorks, Inc.

    % Public, tunable properties.
    properties(Nontunable)
        % Show error status port (E)
        wanterr (1, 1) logical = false;
    end
    
    methods (Access = protected)
        function validateInputsImpl(~,u)
            validateattributes(u, {'single', 'double'}, {'2d'},'','')
        end
 
        function s = getIconImpl(~)
            s = getString(message('dsp:system:Pseudoinverse:BlockIcon'));
        end
     
        function val = supportsMultipleInstanceImpl(~)
            val = true;
        end

        function varargout = getOutputSizeImpl(obj)
            inputSize = propagatedInputSize(obj,1);
            inputSize = fliplr(inputSize);
            varargout{1} = inputSize;
            
            if obj.wanterr
                varargout{2} = [1,1];
            end
        end
        
        function varargout = getOutputDataTypeImpl(obj)
            varargout{1} = propagatedInputDataType(obj,1);
            if obj.wanterr
                varargout{2} = 'logical';
            end
        end
        
        function varargout = isOutputComplexImpl(obj)
            varargout{1} = propagatedInputComplexity(obj,1);
            if obj.wanterr
                varargout{2} = false;
            end
        end
        
        function varargout = isOutputFixedSizeImpl(obj)
            varargout{1} = propagatedInputFixedSize(obj,1);
            if obj.wanterr
                varargout{2} = true;
            end
        end
            
        function varargout = getOutputNamesImpl(obj)
            if obj.wanterr
                varargout{1} =   'X';
                varargout{2} =   'E';
            else
                varargout{1} =   'X';
            end
        end
        
        function [X,varargout] = stepImpl(obj,A)
            if all(isfinite(A(:)))
                X = pinv(A);
                if obj.wanterr
                    varargout{1} = false;
                end
            else
                X = zeros(fliplr(size(A)),'like',A);
                if obj.wanterr
                    varargout{1} = true;
                end
            end
        end
        
        function N = getNumOutputsImpl(obj)
            N = obj.wanterr + 1;
        end
    end
    
    methods(Static, Access = protected)
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header('dsp.simulink.Pseudoinverse', ...
                'ShowSourceLink', true, ...
                'Title','dsp:system:Pseudoinverse:BlockName',...
                'Text','dsp:system:Pseudoinverse:BlockHeader');
        end 
        function mainS = getPropertyGroupsImpl
            % Modify order of display
            props = {matlab.system.display.internal.Property('wanterr','Description','dsp:system:Pseudoinverse:wanterr_MP')};
            mainS =  matlab.system.display.Section(...
                'Title', getString(message('dsp:system:Shared:Parameters')), ...
                'PropertyList', props);
        end
    end
end
