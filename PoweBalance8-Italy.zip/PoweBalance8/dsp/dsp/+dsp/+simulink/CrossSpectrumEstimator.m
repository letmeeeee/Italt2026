classdef (StrictDefaults)CrossSpectrumEstimator < dsp.CrossSpectrumEstimator
    % This class is internally used for the Cross-Spectrum Estimator block

    %#codegen
    %#ok<*EMCLS>

    %   Copyright 2015-2020 The MathWorks, Inc.

    properties (Access = private)
        % Count number of received frames. Used to ignore latency frames
        pFrameCounter;
        % Latency (frames) System latency in frames. The first pFrameDelay
        % frames must be ignored because they are all-zeros (initial
        % conditions) caused by non-zero multirate latency
        pFrameDelay;
        % pSR Cache inherited sample rate
        pSR
    end

    properties(Nontunable)
        % ForgettingFactorPort Specify forgetting factor from input port
        ForgettingFactorPort (1, 1) logical = false;
    end

    properties (Constant, Hidden)
        ForgettingFactorSet = matlab.system.SourceSet( ...
            dsp.simulink.internal.SpectrumEstimatorPolicy('SystemBlock', 'ForgettingFactorPort', 1, 'lambda'), ...
            {'Property','MATLAB','ForgettingFactorPort'})
    end

    methods
        function obj = CrossSpectrumEstimator(varargin)
            %SpectrumEstimator   Construct the SpectrumEstimator class.
            obj@dsp.CrossSpectrumEstimator(varargin{:})
        end
    end

    methods(Access = protected)
        function Fs = getSampleRate(obj)

            coder.extrinsic('dsp.simulink.CrossSpectrumEstimator.initializeBlock');

            if obj.InheritSampleRate
                if isempty(coder.target)
                    if ~isempty(obj.pSR)
                        Fs = obj.pSR;
                    else
                        Fs = 1;
                    end
                else
                    Fs = coder.const(obj.initializeBlock());
                end
            else
                Fs = obj.SampleRate;
            end
        end
    end

    methods(Access = protected)
        function validateForgettingFactor(~,val)
            validateattributes(val,...
                {'double','single'},...
                {'real','scalar','finite','>=',0,'<=',1},...
                '','ForgettingFactor');
        end

        function varargout  = getInputNamesImpl(obj)
            varargout{1} = 'x';
            varargout{2} = 'y';
            if  ~strcmp(obj.AveragingMethod,'Running') && obj.ForgettingFactorPort
                varargout{3} = 'lambda';
            end
        end

        function setupImpl(obj,x,y)

            setupImpl@dsp.CrossSpectrumEstimator(obj,x,y);

            coder.extrinsic('dsp.simulink.CrossSpectrumEstimator.initializeBlock');

            obj.pFrameCounter = cast(0,class(x));
            [Fs,obj.pFrameDelay] = coder.const(@dsp.simulink.CrossSpectrumEstimator.initializeBlock);
            if obj.InheritSampleRate
                obj.pSR = Fs;
            end

        end

        function  Pxy = stepImpl(obj,x,y)
            if obj.pFrameCounter >= obj.pFrameDelay
                Pxy = stepImpl@dsp.CrossSpectrumEstimator(obj,x,y);
            else
                obj.pFrameCounter = obj.pFrameCounter + 1;
                F = getFrequencyVector(obj);
                Pxy = zeros(length(F),getNumberOfChannels(obj),getDatatype(obj)) + 1j * zeros(length(F),getNumberOfChannels(obj),getDatatype(obj));
            end
        end

        function s = saveObjectImpl(obj)
            s = saveObjectImpl@dsp.CrossSpectrumEstimator(obj);
            if isLocked(obj)
                s.pFrameCounter  = obj.pFrameCounter;
                s.pFrameDelay    = s.pFrameDelay;
            end
        end

        function loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                obj.pFrameCounter  = s.pFrameCounter;
                obj.pFrameDelay    = s.pFrameDelay;
            end
            loadObjectImpl@dsp.CrossSpectrumEstimator(obj,s,wasLocked);
        end

        function icon = getIconImpl(~)
            % MATLAB system block icon
            icon = getString(message('dsp:system:SpectrumEstimatorBase:CrossSpectrumEstimatorIcon'));
        end
    end

    methods (Static, Hidden)
        function [Fs,delayFrames] = initializeBlock()
            % Compute Fs and buffer latency based on block and model settings
            computeFs = true;
            bufferBlkName = 'Buffer_x';
            checkRBW = false;
            blk = get_param(gcbh,'Parent');
            [Fs,delayFrames] = dsp.internal.initializeSpectrumBlock(blk , checkRBW, computeFs , bufferBlkName);
        end
    end

    methods (Static, Access = protected)
        function group = getPropertyGroupsImpl
            % Modify order of display
            propertyList = {matlab.system.display.internal.Property('AveragingMethod','Description','dsp:system:SpectrumEstimatorBase:AveragingMethod_MP'), ...
                matlab.system.display.internal.Property('SpectralAverages','Description','dsp:system:SpectrumEstimatorBase:SpectralAverages_MP'), ...
                matlab.system.display.internal.Property('ForgettingFactorPort','Description','dsp:system:SpectrumEstimatorBase:ForgettingFactorPort_MP'), ...
                matlab.system.display.internal.Property('ForgettingFactor','Description','dsp:system:SpectrumEstimatorBase:ForgettingFactor_MP'), ...
                matlab.system.display.internal.Property('FFTLengthSource','Description','dsp:system:SpectrumEstimatorBase:FFTLengthSource_MP'), ...
                matlab.system.display.internal.Property('FFTLength','Description','dsp:system:SpectrumEstimatorBase:FFTLength_MP'), ...
                matlab.system.display.internal.Property('Window','Description','dsp:system:SpectrumEstimatorBase:Window_MP'), ...
                matlab.system.display.internal.Property('SidelobeAttenuation','Description','dsp:system:SpectrumEstimatorBase:SidelobeAttenuation_MP'), ...
                matlab.system.display.internal.Property('FrequencyRange','Description','dsp:system:SpectrumEstimatorBase:FrequencyRange_MP'), ...
                matlab.system.display.internal.Property('InheritSampleRate','Description','dsp:system:AbstractSampleRateEngine:InheritSampleRate_MP'), ...
                matlab.system.display.internal.Property('SampleRate','Description','dsp:system:AbstractSampleRateEngine:SampleRate_MP')};
            group =  matlab.system.display.Section(...
                'Title', 'Parameters', ...
                'PropertyList', propertyList);
        end
        %------------------------------------------------------------------
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header('dsp.simulink.CrossSpectrumEstimator', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:system:SpectrumEstimatorBase:CrossSpectrumEstimatorTitle',...,...
                'Text', 'dsp:system:SpectrumEstimatorBase:CrossSpectrumEstimatorDescription');
        end
    end
end