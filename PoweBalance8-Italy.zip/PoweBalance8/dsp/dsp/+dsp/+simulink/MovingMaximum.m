classdef (StrictDefaults)MovingMaximum < dsp.MovingMaximum
    % MovingMaximum Compute moving maximum of input
    % This class is used in the Moving Maximum block in dspstat3 library

    % Copyright 2021 The MathWorks, Inc.
    %#codegen
    %#ok<*EMCLS>
    methods
        function obj = MovingMaximum(varargin)
            obj@dsp.MovingMaximum(varargin{:});
        end
    end
    methods(Access = protected)
        %% Block Icon
        function icon = getIconImpl(~)
           icon = getString(message('dsp:StatisticsBlockDialog:MovingMaxIcon')); 
        end   

        function name = getInputNamesImpl(~)
            name = '';
        end
        
        function name = getOutputNamesImpl(~)
            name = '';
        end
        
        function val = supportsMultipleInstanceImpl(~)
            % Support in for-each subsystem
            val = true;
        end
        
        %%Propagators
        function cplx = isOutputComplexImpl(obj)
            % Complexity propagator
            cplx = propagatedInputComplexity(obj, 1);
        end
        
        function sz = getOutputSizeImpl(obj)
            % Output size propagator
            sz = propagatedInputSize(obj, 1);
        end
        
        function dt = getOutputDataTypeImpl(obj)
            % Output datatype propagator
            dt = propagatedInputDataType(obj, 1);
        end
        
        function isvar = isOutputFixedSizeImpl(obj)
            isvar = propagatedInputFixedSize(obj,1);
        end
    end

    methods(Static, Access=protected)
        %% Block header - widget grouping
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.MovingMaximum', ...
                'ShowSourceLink', true, ...
                'Title','dsp:StatisticsBlockDialog:MovingMaxTitle',...
                'Text',  'dsp:StatisticsBlockDialog:MovingMaxHeader');
        end
    end

end