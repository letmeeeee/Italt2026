classdef (StrictDefaults)MovingMinimum < dsp.MovingMinimum
    % MovingMinimum Compute moving minimum of input
    % This class is used in the Moving Minimum block in dspstat3 library

    % Copyright 2021 The MathWorks, Inc.
    %#codegen
    %#ok<*EMCLS>
    methods
        function obj = MovingMinimum(varargin)
            obj@dsp.MovingMinimum(varargin{:});
        end
    end
    methods(Access = protected)
        %% Block Icon
        function icon = getIconImpl(~)
           icon = getString(message('dsp:StatisticsBlockDialog:MovingMinIcon')); 
        end 
        function name = getInputNamesImpl(~)
            name = '';
        end
        
        function name = getOutputNamesImpl(~)
            name = '';
        end
        
        function val = supportsMultipleInstanceImpl(~)
            % Support in for-each subsystem
            val = true;
        end
        
        %%Propagators
        function cplx = isOutputComplexImpl(obj)
            % Complexity propagator
            cplx = propagatedInputComplexity(obj, 1);
        end
        
        function sz = getOutputSizeImpl(obj)
            % Output size propagator
            sz = propagatedInputSize(obj, 1);
        end
        
        function dt = getOutputDataTypeImpl(obj)
            % Output datatype propagator
            dt = propagatedInputDataType(obj, 1);
        end
        
        function isvar = isOutputFixedSizeImpl(obj)
            isvar = propagatedInputFixedSize(obj,1);
        end        
    end

    methods(Static, Access=protected)
        %% Block header - widget grouping        
        function header = getHeaderImpl
            % MATLAB System block header
            header = matlab.system.display.Header(...
                'dsp.simulink.MovingMinimum', ...
                'ShowSourceLink', true, ...
                'Title', 'dsp:StatisticsBlockDialog:MovingMinTitle',...
                'Text',  'dsp:StatisticsBlockDialog:MovingMinHeader');
        end
    end

end