classdef (StrictDefaults)ZoomFFT < dsp.internal.SampleRateEngine
%   ZoomFFT Compute the FFT of a portion of the spectrum at high resolution
%   ZFFT = dsp.ZoomFFT returns a System object, ZFFT, that performs an FFT
%   on a portion of the input signal's frequency range. The object
%   determines the frequency range over which to perform the FFT using the
%   specified center frequency and decimation factor values. 
%
%   ZFFT = dsp.ZoomFFT('Name', Value, ...) returns a zoom FFT System
%   object, ZFFT, with each specified property name set to the specified
%   value. You can specify additional name-value pair arguments in any
%   order as (Name1,Value1,...,NameN, ValueN).
%
%   ZFFT = dsp.ZoomFFT(D) returns a zoom FFT object, ZFFT, with the
%   DecimationFactor property set to D.
%  
%   ZFFT = dsp.ZoomFFT(D,Fc) returns a zoom FFT object, ZFFT, with the
%   DecimationFactor property set to D, and the CenterFrequency property
%   set to Fc.
%
%   ZFFT = dsp.ZoomFFT(D,Fc,Fs) returns a zoom FFT object, ZFFT, with the
%   DecimationFactor property set to D, the CenterFrequency property
%   set to Fc, and the SampleRate property set to Fs.
%    
%   Step method syntax:
%
%   Y = step(ZFFT, X) computes the zoom FFT, Y, of the input X. Each
%   column of X is a channel. The System object computes the FFT of each
%   channel of the input signal independently over time. The frame size
%   (first dimension) of x must be a multiple of the decimation factor.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   ZoomFFT methods:
%
%   step                     - Compute zoom FFT of input
%   release                  - Allow property value and input 
%                              characteristics changes, and release zoom
%                              FFT resources
%   clone                    - Create zoom FFT object with same
%                              property values
%   isLocked                 - Display locked status (logical)
%   reset                    - Reset the states of the zoom FFT
%
%   ZoomFFT properties:
%
%   DecimationFactor         - Decimation factor as an integer value
%   CenterFrequency          - Center frequency (Hz) 
%   FFTLength                - FFT length
%   SampleRate               - Input sample rate (Hz)
%
% % Example: Compute FFT of the [1500 Hz, 2500 Hz] band using zoom FFT.
%   Fs = 48e3;        % Input sample rate
%   CF = 2000;        % Desired center frequency
%   BW = 1000;        % Bandwidth of interest (centered at CF)
%   D  =  Fs/BW;      % Decimation factor
%   fftlen = 64;      % FFT length
%   L  = D * fftlen;  % Frame size
%  
%   zfft = dsp.ZoomFFT(D,CF,Fs,...
%                     'FFTLength',fftlen);
%    
% % Specify frequency points at which FFT is computed
%   Fsd = Fs / D;
%   F   = CF + Fsd/fftlen*(0:fftlen-1)-Fsd/2;
%  
% % Spectrum visualization scope
%   ap = dsp.ArrayPlot(...
%                     'XDataMode','Custom',...
%                     'CustomXData',F,...
%                     'YLabel','z .* conj(z)',...
%                     'XLabel','Frequency (Hz)',...
%                     'YLimits',[0 1.1e3],...
%                     'Title',sprintf('Resolution = %f Hz',(Fs/D)/fftlen));
%  
% % Sine wave generator
%   tones = [1625 2000 2125];
%   sin = dsp.SineWave('SampleRate',Fs,'Frequency',tones,...
%                      'SamplesPerFrame',L);
%  
%   for index = 1:100
%       x = sum(sin(),2) +  1e-1 * randn(L,1);
%       z = zfft(x);
%       z = fftshift(z);
%       ap( z .* conj(z) );
%   end
%
%   See also dsp.FFT, dsp.IFFT

% Copyright 2016-2022 The MathWorks, Inc.
    
%#codegen
%#ok<*EMCLS>

properties (Nontunable)
    % SampleRate Input sample rate (Hz)
    %  Specify the sampling rate of the input in Hertz as a real, finite
    %  numeric scalar. The default is 44100 Hz.
    SampleRate = 44100;
end

properties
    % CenterFrequency Center frequency (Hz)
    %  Specify the center frequency of the desired band in Hz as a real,
    %  finite numeric scalar in the range (-SampleRate/2,SampleRate/2). The
    %  default is 0 Hz. This property is tunable.
    CenterFrequency = 0;
end

properties (Nontunable)
    % DecimationFactor Decimation factor
    %  Specify the factor by which to reduce the bandwidth of the input
    %  signal as a positive integer scalar value. The number of rows of the
    %  input must be a multiple of the decimation factor. The default is 2.
    DecimationFactor (1, 1) {mustBePositive, mustBeInteger} = 2;

    % FFTLength FFT length
    %  Specify the FFT length as a positive scalar integer. The default
    %  value of this property is [], which means that the FFT length is
    %  equal to the frame size (number of input rows) divided by the
    %  decimation factor.
    FFTLength  = [];
end

properties (Constant, Hidden)
    % SampleRateSet SourceSet used to control SampleRate setting in the
    % block (specify on dialog or via input port characteristics)
    SampleRateSet = matlab.system.SourceSet({'PropertyOrMethod', ...
        'SystemBlock', 'InheritSampleRate', 'getInheritedSampleRate',true});
end

properties(Access = private)
    % pdecim Internal decimation object
    pdecim
end

properties(Access = protected, Nontunable)
    % pNFFT Cached FFT length
    pNFFT
end
properties (Access = protected)
     % NumChannels Cached number of channels (used for error checking)
    NumChannels(1,1) int32 = int32(-1);
end

methods
    % Constructor
    function obj = ZoomFFT(varargin)
        setProperties(obj, nargin, varargin{:},...
            'DecimationFactor', 'CenterFrequency','SampleRate');
        obj.NumChannels = int32(-1);
    end
    
    function set.CenterFrequency(obj,value)
        validateattributes(value,...
            {'double','single'}, ...
            {'real','scalar','finite'},...
            '','CenterFrequency');
        obj.CenterFrequency = value;
    end
    
    function set.SampleRate(obj,value)
        validateattributes(value,...
            {'double','single'}, ...
            {'real','scalar','positive','finite'},...
            '','SampleRate');
        obj.SampleRate = value;
    end
    
    function set.FFTLength(obj, val)
        if isempty(val)
            validateattributes(val, {'numeric'},{},...
                '','FFTLength');
        else
            validateattributes(val, {'numeric'},{'finite','scalar','integer','real','positive'},...
                '','FFTLength');
        end
        obj.FFTLength = double(val);
    end
    
end

methods(Access = protected)
    
    function setupImpl(obj,u)
        
        setupImpl@dsp.internal.SampleRateEngine(obj,u);
        
        numchans = getNumChannels(obj,u);
        % Disallow a first step with zero channels
        coder.internal.errorIf(numchans == 0,'dsp:system:Shared:EmptyFirstStep');
            
        obj.NumChannels = int32(numchans);
        
        % Set internal decimation filter
        if obj.DecimationFactor > 1
            obj.pdecim = dsp.ComplexBandpassDecimator(obj.DecimationFactor ,...
                obj.CenterFrequency , obj.SampleRate,...
                'TransitionWidth',0.01*obj.SampleRate/obj.DecimationFactor,...
                'MinimizeComplexCoefficients',false);
        else
            % Edge case - no decimation (pass through)
            obj.pdecim = dsp.FIRFilter('Numerator',1);
        end
        
        if ~isFFTAutoMode(obj)
            % We do not allow input wrapping/truncating for FFT
            coder.internal.errorIf(...
                (obj.FFTLength <  size(u,1)/ obj.DecimationFactor), ...
                'dsp:system:ZoomFFT:InvalidFFTLength');
        end
        
        cacheFFTLength(obj);
    end
    
    function cacheFFTLength(obj)
       obj.pNFFT = obj.FFTLength;
    end
    
    function flag = isFFTAutoMode(obj)
       flag = isempty(obj.FFTLength);
    end
    
    function y = stepImpl(obj,u)
        if isempty(u)
            y = u;
            return;
        end
        z = obj.pdecim(u);
        y = fft(z,obj.pNFFT,1);
    end
    
    function resetImpl(obj)
        reset(obj.pdecim);
    end
    
    function releaseImpl(obj)
        release(obj.pdecim);
        obj.NumChannels = int32(-1);
    end
    
    function processTunedPropertiesImpl(obj)
        if obj.DecimationFactor > 1
            obj.pdecim.CenterFrequency = obj.CenterFrequency;
            crossValidateProperties(obj);
        end
        
    end
    
    function flag = isInputSizeMutableImpl(~,varargin)
        flag = true;
    end
    
    
    function crossValidateProperties(obj)
        Fs = obj.SampleRate;
        
        Fc = obj.CenterFrequency(1);
        coder.internal.errorIf(Fc >= Fs/2 || Fc <= -Fs/2 ,...
            'dsp:system:ZoomFFT:InvalidCenterFrequency');
        
        D  = obj.DecimationFactor;
        coder.internal.errorIf( Fc ~=0 && (Fc - Fs/(2*D) <= -Fs/2 || Fc + Fs/(2*D) >= Fs/2) ,...
            'dsp:system:ZoomFFT:NyquistBroken');
    end
    
    function validateInputsImpl(obj,u)
        if isempty(u)
                return;
        end
        validateattributes(u, {'single', 'double'}, {'2d'},'','')
        if ~isFFTAutoMode(obj)
            % We do not allow input wrapping/truncating for FFT
            coder.internal.errorIf(...
                (obj.FFTLength < size(u,1)/ obj.DecimationFactor), ...
                'dsp:system:ZoomFFT:InvalidFFTLength');
        end
        
        if obj.NumChannels ~= -1 && obj.NumChannels ~= 0
            coder.internal.errorIf(size(u,2) ~= obj.NumChannels, ['dsp:system',...
                ':Shared:numChannels']);
        end
    end
    
    function s = saveObjectImpl(obj)
        s = saveObjectImpl@dsp.internal.SampleRateEngine(obj);
        if isLocked(obj)
            s.pdecim          = matlab.System.saveObject(obj.pdecim);
            s.pNFFT           = obj.pNFFT;
            s.NumChannels     = obj.NumChannels;
        end
    end
    
    function s = loadObjectImpl(obj, s, wasLocked)
        if wasLocked
            obj.pdecim        = matlab.System.loadObject(s.pdecim);
            obj.pNFFT         = s.pNFFT;
            obj.NumChannels   = s.NumChannels;
        end
        loadObjectImpl@dsp.internal.SampleRateEngine(obj, s, wasLocked);
    end

end

methods(Static, Access=protected)
    
    function group = getPropertyGroupsImpl
        % Modify order of display
        props = {...
                 matlab.system.display.internal.Property('DecimationFactor', Description='dsp:system:ZoomFFT:DecimationFactor_MP'),...
                 matlab.system.display.internal.Property('CenterFrequency', Description='dsp:system:ZoomFFT:CenterFrequency_MP'),...
                 matlab.system.display.internal.Property('FFTLength', Description='dsp:system:ZoomFFT:FFTLength_MP'),...
                 matlab.system.display.internal.Property('InheritSampleRate', Description='dsp:system:ZoomFFT:InheritSampleRate_MP'),...
                 matlab.system.display.internal.Property('SampleRate', Description='dsp:system:ZoomFFT:SampleRate_MP')};
        group =  matlab.system.display.Section(...
            Title=getString(message('dsp:system:Shared:Parameters')), ...
            PropertyList=props);
    end
end
end
