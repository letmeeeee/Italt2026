classdef  (StrictDefaults)PhaseExtractor < matlab.System
%   PhaseExtractor Extract unwrapped phase from input 
%   PEX = dsp.PhaseExtractor returns a System object, PEX, that extracts the
%   unwrapped phase of an input signal.
%
%   PEX = dsp.PhaseExtractor('Name', Value, ...) returns a Phase
%   Extractor System object, PEX, with each specified property name set
%   to the specified value. You can specify additional name-value pair
%   arguments in any order as (Name1,Value1,...,NameN, ValueN).
%
%   Step method syntax:
%
%   p = step(PEX, X) computes the unwrapped phase, p, of the complex or real
%   input X. Each column of X is a channel. The System object unwraps the
%   phase of each channel of the input signal independently over time.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%
%   PhaseExtractor methods:
%
%   step                     - Extract unwrapped phase of input
%   release                  - Allow property value and input 
%                              characteristics changes, and release Phase 
%                              Extractor resources
%   clone                    - Create Phase Extractor object with same
%                              property values
%   isLocked                 - Display locked status (logical)
%   reset                    - Reset the states of the Phase Extractor
%
%   PhaseExtractor properties:
%
%   TreatFramesIndependently - Unwrap phase only within the frame
%
%   % Example 1
%   % Unwrap phase of complex sine wave
%   swv = dsp.SineWave('SampleRate',1000,'Frequency',10,...
%                       'ComplexOutput',true,'SamplesPerFrame',128);
%   pex = dsp.PhaseExtractor('TreatFramesIndependently',false);
%   plt = timescope('SampleRate',1000,...
%                   'TimeSpanSource','property','TimeSpan',1.5, ...
%                   'YLimits',[0 80], 'YLabel','Unwrapped Phase (rad)');
%   for ii = 1:10
%       x = swv();
%       plt(pex(x))
%   end
%
%   % Example 2
%   % Plot magnitude and phase response of transfer function of system
%   % represented by third-order IIR filter
%   tfestim = dsp.TransferFunctionEstimator('FrequencyRange','centered');
%   pex     = dsp.PhaseExtractor('TreatFramesIndependently',true);
%   sampleRate = 1e3;
%   magplot = dsp.ArrayPlot('PlotType','Line','XOffset',-sampleRate/2,...
%                            'YLimits',[-120 5],...
%                            'YLabel','Frequency Response (dB)',...
%                            'XLabel','Frequency (Hz)',...
%                            'Title','System Magnitude Response');
%   pexplot = dsp.ArrayPlot('PlotType','Line','XOffset',-sampleRate/2,...
%                              'YLimits',[-15 0],...
%                              'YLabel','Phase Response (rad)',...
%                              'XLabel','Frequency (Hz)',...
%                              'Title','System Phase response');
%   [b,a]  = butter(3,.3);
%   iirflt = dsp.IIRFilter('Numerator',b,'Denominator',a);
%   for ii = 1:100
%       % Generate input
%       x = 0.05*randn(1000,1);
%       % pass through IIR filter
%       y = iirflt(x);
%       % Estimate transfer function
%       Txy = tfestim(x,y);
%       % Plot transfer function magnitude
%       magplot(20*log10(abs(Txy)))
%       % Plot transfer function phase
%       pexplot(pex(Txy))
%   end

%   Copyright 2014-2021 The MathWorks, Inc.

%#codegen
%#ok<*EMCLS>
properties (Nontunable)
    % Unwrap phase only within the frame
    % Specify if the phase is to be unwrapped only within the frame, as a
    % logical scalar. When this property is set to false, the object
    % returns the unwrapped phase while ignoring boundaries between input
    % frames. If the property is set to true, the object
    % treats each frame of input data independently, and resets the initial
    % cumulative unwrapped phase value to zero each time a new input frame
    % is received. The default of this property is false.
    TreatFramesIndependently (1, 1) logical = false;
end

properties (Access = private)
    % pPhaseDifferentiator - Handle to object that performs phase
    % difference
    pPhaseDifferentiator;
    % pCurrentPhase - Cumulative phase
    pCurrentPhase;
end

properties (Access = private, Nontunable)
    % pHasState - Property is true if TreatFramesIndependently is false,
    % and is false is TreatFramesIndependently is true
    pHasState (1, 1) logical;
end

methods
    % Constructor
    function obj = PhaseExtractor(varargin)
        setProperties(obj,nargin,varargin{:});
    end
end

methods (Access = protected)
    function setupImpl(obj,u)
        % Setup object internal properties and states
        obj.pHasState            = ~obj.TreatFramesIndependently;
        obj.pPhaseDifferentiator = dsp.internal.PhaseDifferentiator...
                ('TreatFramesIndependently',obj.TreatFramesIndependently);
        numchan = getNumChannels(obj,u);
        cacheInputDimensions(obj.pPhaseDifferentiator,numchan);
        obj.pCurrentPhase = zeros(1,numchan,class(u));
    end
    
    function phase = stepImpl(obj,x)
        phase     =  cumsum(step(obj.pPhaseDifferentiator,x),1);
        if obj.pHasState
            phase = bsxfun(@plus,phase,obj.pCurrentPhase);
            obj.pCurrentPhase = phase(end,:);
        end
    end
    
    function resetImpl(obj)
        obj.pCurrentPhase = zeros(size(obj.pCurrentPhase),...
                                 'like',obj.pCurrentPhase );
        reset(obj.pPhaseDifferentiator);
    end
    
    function releaseImpl(obj)
        release(obj.pPhaseDifferentiator);
    end
    
    function numchans = getNumChannels(obj,u)
        % GETNUMCHANNELS Return the number of input channels
        if obj.getExecPlatformIndex()
            thisSize = propagatedInputSize(obj, 1);
            numchans = thisSize(2);
        else
            numchans = size(u,2);
        end
    end
        
    % Backup/restore functions
    function s = saveObjectImpl(obj)
        s = saveObjectImpl@matlab.System(obj);
        % Save private properties
        if isLocked(obj)
            s.pCurrentPhase = obj.pCurrentPhase;
            s.pHasState = obj.pHasState;
            s.pPhaseDifferentiator = ...
                matlab.System.saveObject(obj.pPhaseDifferentiator);
        end
    end
    
    function loadObjectImpl(obj,s,wasLocked)
        % Re-load private properties
        if wasLocked
            obj.pCurrentPhase = s.pCurrentPhase;
            obj.pHasState = s.pHasState;
            obj.pPhaseDifferentiator = ...
                matlab.System.loadObject(s.pPhaseDifferentiator);
        end
        % Call base class method
        loadObjectImpl@matlab.System(obj, s, wasLocked);
    end
    
    function validateInputsImpl(~,u)
        % Validate inputs to the step method at initialization.
        validateattributes(u,{'double','single'}, {'2d',...
            'nonsparse'},'','input'); 
    end
    
    function flag = isInputSizeMutableImpl(~,~)
        flag = true;
    end
    
    function flag = isInputComplexityMutableImpl(~,~)
        flag = true;
    end
end
end
