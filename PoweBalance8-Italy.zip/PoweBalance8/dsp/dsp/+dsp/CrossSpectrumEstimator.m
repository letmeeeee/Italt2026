classdef (StrictDefaults)CrossSpectrumEstimator < dsp.internal.SpectrumEstimatorBase
%CrossSpectrumEstimator Estimate cross-power spectrum density
%   CSE = dsp.CrossSpectrumEstimator returns a System object, CSE, that
%   computes the frequency cross-power spectrum density of real or complex
%   signals via the periodogram method and Welch's averaged, modified
%   periodogram method.
%
%   CSE = dsp.CrossSpectrumEstimator(Name=Value, ...) returns a
%   Cross-Spectrum Estimator System object, CSE, with each specified
%   property name set to the specified value. You can specify additional
%   name-value pair arguments in any order as
%   Name1=Value1,...,NameN=ValueN).
%
%   Step method syntax:
%
%   Pxy = step(CSE, X, Y) computes the frequency cross power spectrum 
%   density , Pxy, of X and Y. X and Y must be of the same size. The 
%   columns of X and Y are treated as independent channels.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   CrossSpectrumEstimator methods:
%
%   step                 - Compute cross power spectrum of inputs (see 
%                          above)
%   release              - Allow property value and input characteristics 
%                          changes, and release Cross Spectrum Estimator 
%                          resources
%   clone                - Create Cross Spectrum Estimator object with same 
%                          property values
%   isLocked             - Display locked status (logical)
%   reset                - Reset the states of the Cross Spectrum Estimator
%   getRBW               - Get the resolution bandwidth of the spectrum
%   getFrequencyVector   - Get the vector of frequencies at which the
%                          spectrum is estimated
%
%   CrossSpectrumEstimator properties:
%
%   SampleRate                   - Sample rate of input 
%   SpectralAverages             - Number of spectral averages
%   FFTLengthSource              - Source of the FFT length value
%   FFTLength                    - FFT length
%   Window                       - Window function
%   SidelobeAttenuation          - Sidelobe attenuation of window
%   FrequencyRange               - Frequency range of the Spectrum estimate
%   AveragingMethod              - Averaging method
%   SpectralAverages             - Number of spectral averages
%   ForgettingFactor             - Forgetting factor
%
%   % EXAMPLE: Compute the cross power spectrum of two noisy sine waves
%   % Initialize
%   frameLength = 1000;
%   Fs = 1000;
%   sine1 = dsp.SineWave(Frequency=200,...
%       SampleRate=Fs,...
%       SamplesPerFrame=frameLength);
%   sine2 = dsp.SineWave(Frequency=100,...
%       SampleRate=Fs,...
%       SamplesPerFrame=frameLength);
%   csestim = dsp.CrossSpectrumEstimator(SampleRate=Fs,...
%       FrequencyRange="centered");
%   scope = dsp.ArrayPlot(PlotType="Line",...
%       XOffset=-Fs/2,...
%       YLimits=[-150 -60],...
%       YLabel="Power Spectrum Density (Watts/Hz)",...
%       XLabel="Frequency (Hz)",...
%       Title="Cross Power Spectrum of Two Signals");
%
%   % Stream processing loop
%   for index = 1:10
%       x = sine1() + 0.05*randn(frameLength,1);
%       y = sine2() + 0.05*randn(frameLength,1);
%       Pxy = csestim(x,y);
%       scope(20*log10(abs(Pxy)));
%   end
%
%   See also dsp.SpectrumEstimator, dsp.TransferFunctionEstimator,
%            spectrumAnalyzer, dsp.ArrayPlot.

%   Copyright 2013-2021 The MathWorks, Inc.
  
%#codegen
%#ok<*EMCLS>

methods
  function obj = CrossSpectrumEstimator(varargin)
    %CrossSpectrumEstimator   Construct the CrossSpectrumEstimator class.
    obj@dsp.internal.SpectrumEstimatorBase(varargin{:})    
  end
end
    
methods(Access = protected)

  function num = getNumInputsImpl(~)
    % Two inputs x and y
    num = 2;
  end
  
   function setupImpl(obj,x , ~)
      setupImpl@dsp.internal.SpectrumEstimatorBase(obj,x); 
   end
  
  function validateInputsImpl(obj,x,y)
    validateInputsImpl@dsp.internal.SpectrumEstimatorBase(obj,x);
    % Complex inputs are not allowed for one-sided spectrum estimation
    if strcmp(obj.FrequencyRange,'onesided') && ~isreal(y)
       matlab.system.internal.error(...
       'dsp:system:SpectrumEstimatorBase:InvalidSpectrumType');
    end
    validateattributes(y,{'double','single'}, {'2d',...
                      'nonsparse'},'','y');
    coder.internal.errorIf((ndims(x)~=ndims(y) || ...
                           any(size(x)~=size(y)) || ...
                           ~strcmp(class(x),class(y))),...
       'dsp:system:SpectrumEstimatorBase:InputMismatch');
  end
  
  function s = saveObjectImpl(obj)
     s = saveObjectImpl@dsp.internal.SpectrumEstimatorBase(obj);
  end
  
  function loadObjectImpl(obj, s, wasLocked)
     loadObjectImpl@dsp.internal.SpectrumEstimatorBase(obj,s,wasLocked);
  end

  function Pxy = computeWindowFFT(obj,x,y)
    % Window the X data
    xout = windowData(obj,x);
    % Window the Y data 
    yout = windowData(obj,y);
    % compute FFT
    Z = computeFFT(obj,[xout,yout]);
    nchans = getNumberOfChannels(obj);
    X = Z(:,1:nchans);
    Y = Z(:,nchans+1:2*nchans);
    % Cross-PSD
    Pxy = X.*conj(Y);
  end 
  
  function  Pout = convertAndScale(obj,P)
    Pout = preConvertAndScale(obj,P);
    % Scale with respect to Fs to convert to PSD
    Pout = Pout/getSampleRate(obj);
  end
  
  function initializeSpectrumCache(obj)
     NFFT = getActualFFTLen(obj);
     numChannels = getNumberOfChannels(obj);
     dtType = getDatatype(obj);
     if isRunningAverage(obj)  
         % setup running average matrix
         obj.pPeriodogramMatrix = cast(zeros(NFFT,...
             obj.SpectralAverages,...
             numChannels) ...
             + 1j * zeros(NFFT,...
             obj.SpectralAverages,...
             numChannels) , dtType );
     else
         % setup exponential averaging
         obj.pPreviousAvgSpectrum = cast(zeros(NFFT, ...
             numChannels) + 1j * zeros(NFFT,numChannels),dtType);
         obj.pPreviousWeight = cast(0, dtType);
     end
  end
  
  function flag = isInactivePropertyImpl(obj,prop)
      flag =  isInactivePropertyImpl@dsp.internal.SpectrumEstimatorBase(obj,prop);
      if strcmp(prop,'SampleRate')
         flag =  obj.InheritSampleRate;
      end
      if strcmp(prop,'FFTLength')
         flag =  ~strcmp(obj.FFTLengthSource,'Property');
      end
      if strcmp(prop,'SidelobeAttenuation')
         flag =  ~ ( strcmp(obj.Window,'Chebyshev') ||strcmp(obj.Window,'Kaiser') );
      end
  end

  function cp_out = isOutputComplexImpl(~)
    cp_out = true;
  end
end

methods (Static, Access = protected)
    function group = getPropertyGroupsImpl
        % Modify order of display
        parameterString = getString(message('dsp:system:Shared:Parameters'));
        group =  matlab.system.display.Section(...
            'Title', parameterString, ...
            'PropertyList', {'FFTLengthSource','FFTLength',...
            'Window', 'SidelobeAttenuation','FrequencyRange',...
            'AveragingMethod','SpectralAverages','ForgettingFactor', ...
            'InheritSampleRate','SampleRate'});
    end
end
end
