function flag = isChar(val)
% ISCHAR check if input is valid string or char

%   Copyright 2017-2023 The MathWorks, Inc.

%#codegen
flag = ischar(val) || (isstring(val) && isscalar(val));
end