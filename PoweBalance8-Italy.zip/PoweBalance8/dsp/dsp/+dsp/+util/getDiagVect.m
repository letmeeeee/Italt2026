function Value = getDiagVect(q)
% Utility function used for Constant Diagonal Matrix Forwarding

% Copyright 2014 The MathWorks, Inc.

Value = q(:);
Value = diag(Value);

end