function win = blackman(N,SFlag,DT)
%blackman Blackman window.
%  dsp.util.blackman(N) returns the N-th point symmetric Blackman window in
%  a row vector.
%
%  dsp.util.blackman(N,SFLAG) returns the N-point Blackman window using
%  SFLAG window sampling. SFLAG can be either "symmetric" or "periodic". By
%  default, a symmetric window is returned.
%
%  dsp.util.blackman(N,SFLAG,DT) returns the N-point Blackman window using
%  SFLAG window sampling and DT as the window datatype. DT can be either
%  "double" or "single". By default, a double window is returned.

%  Copyright 2023 The MathWorks, Inc.

%#codegen

arguments
    N (1,1) {mustBeInteger, mustBeReal, mustBePositive}
    SFlag (1,:) char {mustBeMember(SFlag,{'symmetric','periodic'})} = "symmetric";
    DT (1,:) char {mustBeMember(DT,{'double','single'})} = "double";
end

N = cast(N, DT);
zeroCast = zeros(1,1,DT);
oneCast = ones(1,1,DT);
twoCast = oneCast + oneCast;
fourCast = twoCast + twoCast;
halfCast = oneCast / twoCast;
piCast = cast(pi, DT);
startIdx = oneCast;

if SFlag == "periodic"
    N = N + oneCast;
    startIdx = twoCast;
end
win = zeros(1,N,DT);
r = rem(N,twoCast);
if r == zeroCast
    % Even length window    
    halfL = N / twoCast;
    x = (zeroCast:halfL - oneCast) / (N - oneCast);
    w = cast(0.42, DT) - halfCast * cos(twoCast * piCast * x) + cast(0.08, DT) * cos(fourCast * piCast * x);
    win(1,1:N) = [w w(end:-oneCast:startIdx)];
else
    % Odd length window
    halfL = (N + oneCast) / twoCast;
    x = (zeroCast:halfL - oneCast) / (N - oneCast);
    w = cast(0.42, DT) - halfCast * cos(twoCast * piCast * x) + cast(0.08, DT) * cos(fourCast * piCast * x);
    win(1,1:N) = [w w(end-oneCast:-oneCast:startIdx)];
end
end
