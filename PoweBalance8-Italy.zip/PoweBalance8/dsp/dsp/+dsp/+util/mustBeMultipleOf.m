function mustBeMultipleOf(n, m)
%mustBeOdd Validate that an integer n is a multiple of m
%   Copyright 2023 The MathWorks, Inc.

%#codegen

isNotMultipleOf = (rem(n,m)~=0);

if coder.target('MATLAB')
    if isNotMultipleOf
        eidType = 'dsp:designHalfbandIIR:mustBeMultipleOf';
        msgType = ['Input must be a multiple of ' num2str(m)];
        throwAsCaller(MException(eidType, msgType))
    end
else
    coder.internal.errorIf(isNotMultipleOf,'dsp:designHalfbandIIR:mustBeMultipleOf',m);
end

end

