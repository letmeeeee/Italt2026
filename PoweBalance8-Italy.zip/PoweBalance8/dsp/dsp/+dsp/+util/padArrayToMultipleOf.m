function A = padArrayToMultipleOf(A, N, dim)
% padArrayToMultipleOf Pad array A along dimension at dim to be a multiple
% of N. This function supports ND-arrays of all numeric types (including 
% embedded.fi).

%   Copyright 2022 The MathWorks, Inc.

%#codegen

arguments
    A {mustBeNumeric}
    N (1,1) {mustBeInteger, mustBePositive}
    dim (1,1) double {mustBeInteger, mustBePositive} = 1
end

L = size(A, dim);
r = mod(L, N);

% If the dimension dim size already a multiple of N => NOP
if r==0
    return; 
end

% Calculate the pad size
Ln = L+N-r;

% Generate an index array for padding
C = repmat({':'}, 1, ndims(A));

% Extend dimension dim as needed, others remain the same
C{dim} = L+1:Ln;  

% Pad with zeros
A(C{:}) = 0; 

end

