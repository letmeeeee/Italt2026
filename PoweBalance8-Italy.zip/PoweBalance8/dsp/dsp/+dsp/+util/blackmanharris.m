function win = blackmanharris(N,SFlag,DT)
%blackmanharris Blackman-Harris window.
%  dsp.util.blackmanharris(N) returns the N-th point symmetric
%  Blackman-Harris window in a row vector.
%
%  dsp.util.blackmanharris(N,SFLAG) returns the N-point Blackman-Harris
%  window using SFLAG window sampling. SFLAG can be either "symmetric" or
%  "periodic". By default, a symmetric window is returned.
%
%  dsp.util.blackmanharris(N,SFLAG,DT) returns the N-point Blackman-Harris
%  window using SFLAG window sampling and DT as the window datatype. DT can
%  be either "double" or "single". By default, a double window is returned.

%  Copyright 2023 The MathWorks, Inc.

%#codegen

arguments
    N (1,1) {mustBeInteger, mustBeReal, mustBePositive}
    SFlag (1,:) char {mustBeMember(SFlag,{'symmetric','periodic'})} = "symmetric";
    DT (1,:) char {mustBeMember(DT,{'double','single'})} = "double";
end

N = cast(N, DT);
zeroCast = zeros(1,1,DT);
oneCast = ones(1,1,DT);
twoCast = oneCast + oneCast;
threeCast = oneCast + twoCast;
piCast = cast(pi, DT);
win = zeros(1,N,DT);

a = cast([0.35875 0.48829 0.14128 0.01168], DT);
if SFlag == "periodic"
    x = (0:N-1)' * twoCast * piCast / N;
else
    x = (0:N-1)' * twoCast * piCast / (N-1);
end
b = [a(1); -a(2); a(3); -a(4)];
win(1,1:N) = cos(x * [zeroCast oneCast twoCast threeCast]) * b;
end
