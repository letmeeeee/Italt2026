function str = genFilterConstructor(obj)
%genFilterConstructor Generate MATLAB script to construct a given
%dsp.internal.FilterAnalysis object

%   Copyright 2023 The MathWorks, Inc.
    arguments
        obj dsp.internal.FilterAnalysis;
    end

    str = [class(obj), '(  ...\n'];

    hDefault = eval(class(obj));
    p = properties(obj);
    ds = getDiscreteStateProperties(obj);
    p = setdiff(p, ds, 'stable');  % Remove DiscreteState properties
    p = reorderProperties(p);
    for ind=1:length(p)
        prop = p{ind};
        if ~isInactiveProperty(obj, prop)
            % check for value to be different from default
            flagDiff = ~isequal(obj.(prop), hDefault.(prop));

            if flagDiff
                str = [str, prop, '=', getValueString(obj, prop), ', ...\n']; %#ok<AGROW>
            end
        end
    end
    str(end-6:end) = [];
    str = [str ');'];
end

%------------------------------------------------------------------
function ds = getDiscreteStateProperties(obj)
    mc = metaclass(obj);
    mp = mc.PropertyList;
    dsIdx = arrayfun(@(x) isa(x, 'matlab.system.CustomMetaProp') && x.DiscreteState, mp);
    ds = {mp(dsIdx).Name};
end

%------------------------------------------------------------------
function props = reorderProperties(props)
    % FullPrecisionOverride must be listed before any *DataType
    % properties are listed.
    FullPrecisionOverrideIdx = find(cellfun(@(x) strcmpi('FullPrecisionOverride',x),props),1);
    if ~isempty(FullPrecisionOverrideIdx)
        props(FullPrecisionOverrideIdx) = [];
        firstDataTypeIdx = find(cellfun(@(x)~isempty(x), strfind(props, 'DataType')), 1);
        if ~isempty(firstDataTypeIdx)
            props = [props(1:firstDataTypeIdx-1); 'FullPrecisionOverride'; props(firstDataTypeIdx:end)];
        else
            props{end+1} = 'FullPrecisionOverride';
        end
    end

    % RoundingMethod and OverflowAction are listed before the
    % properties that enable them. This causes warnings in
    % constructor of generated MATLAB code. This method reorders
    % the list of properties to push those to the end.

    RoundingMethodIdx = find(cellfun(@(x) strcmpi('RoundingMethod',x),props),1);
    if ~isempty(RoundingMethodIdx)
        props(RoundingMethodIdx) = [];
        props{end+1} = 'RoundingMethod';
    end
    OverflowActionIdx = find(cellfun(@(x) strcmpi('OverflowAction',x),props),1);
    if ~isempty(OverflowActionIdx)
        props(OverflowActionIdx) = [];
        props{end+1} = 'OverflowAction';
    end
end

%------------------------------------------------------------------
function valS = getValueString(obj, prop)
    % Get value corresponding to property as a string.
    % This is used by generateFilteringCode
    propVal = obj.(prop);
    if isa(propVal, 'char')
        valS = ['''',propVal,''''];
        return;
    end
    if isnumeric(propVal)
        % for numeric arrays
        valS = dsp.internal.compactButAccurateMat2Str(propVal);
        return;
    end
    if iscell(propVal)
        % for dsp.AllpassFilter
        valS = '{ ';
        for idx = 1:length(propVal)
            valS = [valS, dsp.internal.compactButAccurateMat2Str(propVal{idx}),',']; %#ok<AGROW>
        end
        valS(end)=[]; % remove extra comma
        valS = [valS, ' }'];
        return;
    end
    if isa(propVal, 'embedded.numerictype')
        valS = tostring(propVal);
        return;
    end

    objS = evalc('longDisplay(obj)');
    propEndIdx = regexp(objS, [' ',prop,': '],'end');
    lineEndIdx = regexp(objS(propEndIdx+1:end), '\n', 'once');
    % for logical or any other type of property not covered above
    valS = strtrim(objS(propEndIdx+1:propEndIdx+lineEndIdx-1));
end