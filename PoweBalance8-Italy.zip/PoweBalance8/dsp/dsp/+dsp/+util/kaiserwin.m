function win = kaiserwin(N,alpha,SFlag,DT,options)
%kaiserwin Kaiser window.
%  dsp.util.kaiserwin(N) returns the N-th point symmetric Kaiser window in
%  a row vector.
%
%  dsp.util.kaiserwin(N,alpha) returns the N-th point alpha-valued
%  symmetric Kaiser window in a row vector.
%
%  dsp.util.kaiserwin(N,alpha,SFLAG) returns the N-point alpha-valued
%  Kaiser window using SFLAG window sampling. SFLAG can be either
%  "symmetric" or "periodic". By default, a symmetric window is returned.
%
%  dsp.util.kaiserwin(N,SFLAG,DT) returns the N-point alpha-valued Kaiser
%  window using SFLAG window sampling and DT as the window datatype. DT can
%  be either "double" or "single". By default, a double window is returned.
%
%  dsp.util.kaiserwin(...,Tolerance=TOL) returns the N-point alpha-valued
%  Kaiser window with tolerance TOL. By default, 1e-9 is used.

%  Copyright 2023 The MathWorks, Inc.

%#codegen

arguments
    N (1,1) {mustBeInteger, mustBeReal, mustBePositive}
    alpha (1,1) {mustBeFloat, mustBeReal, mustBeNonnegative} = 0.5;
    SFlag (1,:) char {mustBeMember(SFlag,{'symmetric','periodic'})} = "symmetric";
    DT (1,:) char {mustBeMember(DT,{'double','single'})} = "double";
    options.Tolerance (1,1) {mustBeFloat, mustBeReal, mustBeNonnegative} = 1e-9;
end

N = cast(N, DT);
alpha = cast(alpha,DT);
tol = cast(options.Tolerance, DT);
oneCast = ones(1,1,DT);
ioa = io(alpha,oneCast,tol);
n = (0:N-1);
win = zeros(1,N,DT);
if SFlag == "symmetric"
    win(1,1:N) = io(alpha * 2*sqrt(n.*(1/(N-1)-n/(N-1)^2)), N, tol)/ioa;
else
    % "periodic"
    win(1,1:N) = io(alpha * 2*sqrt(n.*(1/N-n/N^2)), N, tol)/ioa;
end
end

function s =  io(x,N,tol)
arguments
    x  {mustBeFloat, mustBeReal, mustBeNonnegative}
    N (1,1) {mustBeInteger, mustBeReal, mustBePositive}
    tol (1,1) {mustBeFloat, mustBeReal, mustBeNonnegative}
end

oneCast = ones(1,1,"like",x);
twoCast = oneCast + oneCast;
n = oneCast;
s = ones(1,N,"like",x);
d = ones(1,N,"like",x);
iter = oneCast;
while any(d > tol*s) && iter <= 100
    t = x/(twoCast.*n);
    n = n + oneCast;
    d(1,1:N) = d.*(t.^twoCast);
    s(1,1:N) = s + d;
    iter = iter + oneCast;
end
end