function sendToEditor(str, smartIndent)
% SENDTOEDITOR - This function sends the input text to an editor window and
% indents the text correctly.

% Copyright 2016 The MathWorks, Inc.

if nargin<2
    smartIndent = true;
end
editorDoc = matlab.desktop.editor.newDocument(str);
if smartIndent
    editorDoc.smartIndentContents();
end