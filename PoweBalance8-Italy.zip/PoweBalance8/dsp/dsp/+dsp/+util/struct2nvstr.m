function structNVStr = struct2nvstr(inputStruct, structFields)
%STRUCT2NVSTR Convert a structure into a comma-separated Name=Value string.
% 
% NVSTR = struct2nvstr(INPUTSTRUCT), converts all the fileds in INPUTSTRUCT
% to Name=Value string.
%
% NVSTR = struct2nvstr(INPUTSTRUCT,STRUCTFIELDS), convert INPUTSTRUCT
% fields specified in STRUCTFIELDS to Name=Value string.

%   Copyright 2023 The MathWorks, Inc.

arguments
    inputStruct
    structFields = fieldnames(inputStruct);
end

structNVStr = "";
for k = 1:numel(structFields)
    val = inputStruct.(structFields{k});
    if isnumeric(val)
        valStr = dsp.internal.compactButAccurateMat2Str(val);
    elseif islogical(val)
        valStr = val;
    else % character string presumably
        valStr = """" + val + """";
    end
    if k > 1
        structNVStr = structNVStr + ", " + structFields{k} + "=" + valStr;
    else
        structNVStr = structFields{k} + "=" +valStr;
    end
end
end