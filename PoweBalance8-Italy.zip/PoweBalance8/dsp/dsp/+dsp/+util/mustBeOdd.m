function mustBeOdd(n)
%mustBeOdd Validate that an integer n is an odd number
%   Copyright 2023 The MathWorks, Inc.

%#codegen

nIsEven = rem(n,2)==0;

if coder.target('MATLAB')
    if nIsEven
        eidType = 'dsp:designHalfbandIIR:mustBeOdd';
        msgType = 'Input must be a positive odd integer';
        throwAsCaller(MException(eidType, msgType))
    end
else
    coder.internal.errorIf(nIsEven, 'dsp:designHalfbandIIR:mustBeOdd');
end

end

