function varargout=msgbox(inputStr,blockName)
% msgbox: Custom message box utility
% Used to generate an info message box for certain blocks

%   Copyright 2014-2019 The MathWorks, Inc.

if nargin > 0
        inputStr = convertStringsToChars(inputStr);
end

if nargin > 1
    blockName = convertStringsToChars(blockName);
end

TitleString = message('dsp:system:Shared:InfoName',blockName).getString;

BodyTextString = dialogCellstrHelper(inputStr);

% setup defaults
Interpreter = 'none';

Black = [0 0 0];

%%%%%%%%%%%%%%%%%%%%%
%%% Set Positions %%%
%%%%%%%%%%%%%%%%%%%%%
DefFigPos=get(0,'DefaultFigurePosition');

MsgOff=7;

FigWidth=125;
MsgTxtWidth=FigWidth-2*MsgOff;
    
FigHeight=50;
DefFigPos(3:4)=[FigWidth FigHeight];

MsgTxtXOffset=MsgOff;
MsgTxtYOffset=MsgOff;
MsgTxtHeight=FigHeight-MsgOff-MsgTxtYOffset;
MsgTxtForeClr=Black;

%%%%%%%%%%%%%%%%%%%%%
%%% Create MsgBox %%%
%%%%%%%%%%%%%%%%%%%%%
% See if a modal or replace dialog already exists and delete all of its
% children
MsgboxTag = ['Msgbox_', [blockName ' Info'] ];
WindowStyle='normal';

figureHandle=dialog(                                ...
    'Name'            ,TitleString             , ...
    'Pointer'         ,'arrow'                 , ...
    'Units'           ,'points'                , ...
    'Visible'         ,'off'                   , ...
    'KeyPressFcn'     ,@doKeyPress             , ...
    'WindowStyle'     ,WindowStyle             , ...
    'Toolbar'         ,'none'                  , ...
    'HandleVisibility','on'                    , ...
    'Tag'             ,MsgboxTag                 ...
    );

FigColor=get(figureHandle,'Color');

MsgTxtBackClr=FigColor;

Font.FontUnits='points';
Font.FontSize=get(0,'FactoryUicontrolFontSize');
Font.FontName=get(0,'FixedWidthFontName');
Font.FontWeight=get(figureHandle,'DefaultUicontrolFontWeight');

StFont = Font;
StFont.FontWeight=get(figureHandle, 'DefaultTextFontWeight');

msgPos = [ MsgTxtXOffset MsgTxtYOffset MsgTxtWidth MsgTxtHeight ];
MsgHandle=uicontrol(figureHandle         , ...
    StFont                               , ...
    'Style'              ,'text'         , ...
    'Units'              ,'points'       , ...
    'Position'           , msgPos        , ...
    'String'             ,' '            , ...
    'Tag'                ,'MessageBox'   , ...
    'HorizontalAlignment','left'         , ...
    'BackgroundColor'    ,MsgTxtBackClr  , ...
    'ForegroundColor'    ,MsgTxtForeClr    ...
    );


[WrapString,NewMsgTxtPos]=textwrap(MsgHandle,BodyTextString,75);
delete(MsgHandle);

% place an axes for the message string (use axes
% so we can get Latex interpreter if required)
AxesHandle=axes( ...
    'Parent'             ,figureHandle  , ...
    'Position'           ,[0 0 1 1]     , ...
    'Visible'            ,'off'           ...
    );

texthandle = text( ...
    'Parent'              ,AxesHandle                        , ...
    'Units'               ,'points'                          , ...
    'String'              ,WrapString                        , ...
    StFont                                                   , ...
    'HorizontalAlignment' ,'left'                            , ...
    'VerticalAlignment'   ,'bottom'                          , ...
    'Interpreter'         ,Interpreter                       , ...
    'Tag'                 ,'MessageBox'                        ...
    );

textExtent = get(texthandle, 'Extent');

%textExtent and extent from uicontrol are not the same. For window, extent from uicontrol is larger
%than textExtent. But on Mac, it is reverse. Pick the max value.
MsgTxtWidth=max([MsgTxtWidth NewMsgTxtPos(3) textExtent(3)]);
MsgTxtHeight=max([MsgTxtHeight NewMsgTxtPos(4) textExtent(4)]);

FigWidth=MsgTxtWidth+2*MsgOff;
MsgTxtYOffset=MsgOff;
FigHeight=MsgTxtYOffset+MsgTxtHeight+MsgOff;

DefFigPos(3:4)=[FigWidth FigHeight];
DefFigPos = getnicedialoglocation(DefFigPos, get(figureHandle,'Units'));

set(figureHandle,'Position',DefFigPos);

txtPos = [ MsgTxtXOffset MsgTxtYOffset 0 ];
set(texthandle, 'Position'            ,txtPos);

% make sure we are on screen
movegui(figureHandle)

set(figureHandle,'HandleVisibility','callback');
set(figureHandle,'Visible','on');

% make sure the window gets drawn even if we are in a pause
drawnow

if nargout==1
    varargout{1}=figureHandle;
end

end

%%%%% doKeyPress
function doKeyPress(obj, evd)
    switch(evd.Key)
        case {'return','space','escape'}
            delete(ancestor(obj,'figure'));
    end
end

function outStr = dialogCellstrHelper (inputStr)
% Convert to cell array of strings without eliminating any user input. 
inputCell = {};
for siz = 1:size(inputStr,1)
    inputCell{siz} =inputStr(siz,:); %#ok<AGROW>
end
outStr = inputCell;
end

function figure_size = getnicedialoglocation(figure_size, figure_units)
% adjust the specified figure position to fig nicely over GCBF
% or into the upper 3rd of the screen

convertData.destinationUnits = figure_units;

% If there is no parent figure, use the root's data
% and create a invisible figure as parent
convertData.hFig = figure('visible','off');
convertData.size = get(0,'ScreenSize');
convertData.sourceUnits = get(0,'Units');
c = onCleanup(@() close(convertData.hFig));

% Get the size of the dialog parent in the dialog units
container_size = hgconvertunits(convertData.hFig, convertData.size ,...
    convertData.sourceUnits, convertData.destinationUnits, get(convertData.hFig,'Parent'));

delete(c);

figure_size(1) = container_size(1)  + 1/2*(container_size(3) - figure_size(3));
figure_size(2) = container_size(2)  + 2/3*(container_size(4) - figure_size(4));

end