function mustBeEven(n, eid)
%mustBeEven Validate that an integer n is an even number
%   Copyright 2023 The MathWorks, Inc.

%#codegen

isOdd = (rem(n,2)~=0);

if coder.target('MATLAB')
    if isOdd
        eidType = eid;
        msgType = 'Input must be an even integer';
        throwAsCaller(MException(eidType, msgType))
    end
else
    coder.internal.errorIf(isOdd,eid);
end

end

