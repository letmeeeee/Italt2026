function D = scalarDFILT(alpha ,arith)
% scalarDFILT Create a dfilt.scalar object.
% Used by dsp.FilterCascade and dsp.ParallelFilter

% Copyright 2022 The MathWorks, Inc.

%#codegen

D = dfilt.scalar(alpha);
D.PersistentMemory = true;
if ~isempty(arith)
    D.Arithmetic = arith;
end
if strcmp(arith, 'fixed') && isfi(alpha)
    nt = numerictype(alpha);
    D.CoeffWordLength = nt.WordLength;
    if strcmp(nt.Signedness,'Unsigned')
        D.Signed = false;
    end
    if isbinarypointscalingset(nt)
        D.CoeffAutoScale = false;
        D.CoeffFracLength = nt.FractionLength;
    end
end

end

