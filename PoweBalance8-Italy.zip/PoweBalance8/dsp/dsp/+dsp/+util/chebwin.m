function win = chebwin(N,SLA,DT)
%chebwin Chebyshev window.
%  dsp.util.chebwin(N) returns the N-th point Chebyshev window in a row
%  vector.
%
%  dsp.util.chebwin(N,SLA) returns the N-point Chebyshev window with SLA
%  decibels of relative sidelobe attenuation. By default, SLA is set to 100
%  dB.
%
%  dsp.util.blackmanharris(N,SLA,DT) returns the N-point Blackman-Harris
%  window using SLA sidelobe attenuation and DT as the window datatype. DT
%  can be either "double" or "single". By default, a double window is
%  returned.

%   Copyright 2023 The MathWorks, Inc.

%#codegen

arguments
    N (1,1) {mustBeInteger, mustBeReal, mustBePositive}
    SLA {mustBePositive, mustBeFloat} = 100;
    DT (1,:) char {mustBeMember(DT,{'double','single'})} = "double";
end

N = cast(N, DT);
SLA = cast(SLA, DT);
zeroCast = zeros(1,1,DT);
oneCast = ones(1,1,DT);
twoCast = oneCast + oneCast;
threeCast = oneCast + twoCast;
tenCast = cast(10,DT);
twentyCast = tenCast + tenCast;
win = zeros(1,N,DT);
% Use coder.internal.indexInt to work around mod(single) producing a double
% in generated code (g3099130)
odd = mod(coder.internal.indexInt(N),coder.internal.indexInt(twoCast));
if ~odd
    middle = N / twoCast;
else
    middle = (N + oneCast) / twoCast;
end
b = tenCast^(SLA / twentyCast);
b = tanh(log(b + sqrt(b * b - oneCast)) / (N - oneCast));
b = b * b;
kterm = zeros(1, middle - 2, DT);
if (middle > 2)
    for wIdx = 1 : middle - 2
        kterm(1,wIdx) = b / ((wIdx) * (wIdx + 1));
    end
end
wmax = oneCast / (N - oneCast);
win(1,1) = wmax;
win(1,N) = wmax;
for i = threeCast : middle + oneCast
    t = b;
    s = zeroCast;
    s_old = zeroCast;
    q_k = (i - twoCast) * (N - i + oneCast);
    r_k = 2 - N;
    for k = 2 : i - twoCast
        q_k = q_k + r_k;
        r_k = r_k + 2;
        t = t * q_k * kterm(k - 1);
        s = s + t;
        if s == s_old
            break;
        end
        s_old = s;
    end
    win(1, N - i + twoCast) = b + s;
    win(1, i - 1) = b + s;
    if win(1,i - 1) > wmax
        wmax = win(1,i - 1);
    end
end
win = win./wmax;
end
