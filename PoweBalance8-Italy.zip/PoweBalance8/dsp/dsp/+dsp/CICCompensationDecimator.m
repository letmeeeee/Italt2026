classdef (StrictDefaults)CICCompensationDecimator < ...
        dsp.internal.CICCompensationBase
%CICCompensationDecimator Compensate for CIC filter using an FIR decimator
%   The shortcomings of a CIC decimator, namely its passband droop and wide
%   transition region, can be compensated by following it with a
%   compensation decimator. This System object provides the ability to
%   design and use such a compensator for the CIC filter.
%   
%   CFIR = dsp.CICCompensationDecimator returns a System object, CFIR, that
%   applies a FIR decimator to each channel of the input signal. Using the
%   properties of the object, the decimation filter can be designed to
%   compensate for a preceding CIC filter.
%   
%   CFIR = dsp.CICCompensationDecimator('Name', Value, ...) returns a CIC
%   compensation decimator System object, CFIR, with each specified
%   property set to the specified value.
%   
%   CFIR = dsp.CICCompensationDecimator(DECIM, 'Name', Value, ...) returns
%   a CIC compensation decimator System object, CFIR, with the
%   DecimationFactor property set to DECIM, and other specified properties
%   set to the specified values.
%
%   CFIR = dsp.CICCompensationDecimator(CICDECIM, 'Name', Value, ...)
%   returns a CIC compensation decimator System object, CFIR, with the
%   CICRateChangeFactor, CICNumSections and CICDifferentialDelay properties
%   set using their corresponding values in the dsp.CICDecimator System
%   object CICDECIM, and other specified properties set to the specified
%   values.
%
%   CFIR = dsp.CICCompensationDecimator(CICDECIM, DECIM, 'Name', Value,
%   ...) returns a CIC compensation decimator System object, CFIR, with the
%   CICRateChangeFactor, CICNumSections and CICDifferentialDelay properties
%   set using their corresponding values in the dsp.CICDecimator System
%   object CICDECIM, the DecimationFactor property set to DECIM, and other
%   specified properties set to the specified values.
%
%   Step method syntax:
%
%   Y = step(CFIR, X) outputs the filtered and downsampled values, Y, of
%   the input signal X. A KixN input matrix is treated as N independent
%   channels, and the System object decimates each channel over time and
%   generates a KoxN output matrix. Ko = Ki/M where M is the decimation
%   factor. The object supports real and complex floating-point and
%   fixed-point inputs, except for complex unsigned fixed-point inputs.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   CICCompensationDecimator methods:
%
%   step      - See above description for use of this method
%   release   - Allow property value and input characteristics changes
%   clone     - Create CIC compensation decimator object with same property 
%               values
%   isLocked  - Locked status (logical)
%   reset     - Reset the internal states to initial conditions
% generatehdl - Generate HDL code. (Filter Design HDL Coder Required)
%
%   CICCompensationDecimator properties:
%
%   SampleRate            - Input sample rate
%   DecimationFactor      - Decimation factor
%   CICRateChangeFactor   - Rate change factor of the CIC filter to be
%                           compensated
%   CICNumSections        - Number of sections of the CIC filter to be
%                           compensated
%   CICDifferentialDelay  - Differential delay of the CIC filter to be
%                           compensated
%   DesignForMinimumOrder - Option to have a minimum order design for the
%                           filter in compensation decimator
%   FilterOrder           - Order of the filter in compensation decimator
%   PassbandFrequency     - Passband frequency of compensation filter
%   StopbandFrequency     - Stopband frequency of compensation filter
%   PassbandRipple        - Allowed passband ripple of compensation filter
%   StopbandAttenuation   - Minimum attenuation needed in stopband of
%                           compensation filter
%
%   This System object supports several filter analysis methods. For more
%   information, type dsp.CICCompensationDecimator.helpFilterAnalysis.
%
%   This System object supports fixed-point operations. For more
%   information, type dsp.CICCompensationDecimator.helpFixedPoint.
%
%   % EXAMPLE: Design a compensation decimator for an existing CIC
%   % decimator and visualize the frequency response of the cascade. Use it
%   % on a sample input.
%   
%   % CONSTRUCTION
%   cicdecim = dsp.CICDecimator(DecimationFactor = 6, ...
%                           NumSections = 6);
%   fs = 16e3;     % Sampling frequency of input of compensation decimator
%   fPass = 4e3;   % Passband frequency
%   fStop = 4.5e3; % Stopband frequency
%   cfir = dsp.CICCompensationDecimator(cicdecim, ...
%               DecimationFactor = 2, ...
%               PassbandFrequency = fPass, ...
%               StopbandFrequency = fStop, ...
%               SampleRate = fs);
%   
%   % FREQUENCY RESPONSE
%   % Next, visualize the cascade frequency response
% 
%   filtcasc = dsp.FilterCascade(cicdecim, cfir);
%   f = fvtool(cicdecim, cfir, filtcasc, 'Fs', [fs*6, fs, fs*6], ...
%              'Arithmetic', 'fixed');
%   set(f, 'NormalizeMagnitudeto1', 'on');
%   legend(f,'CIC Decimator','CIC Compensation Decimator', ...
%            'Overall Response');
% 
%   % STEP
%   sigsource = dsp.SignalSource(fi(rand(1200,1),1,16,15), ...
%                                SamplesPerFrame = 120);
%   y = fi(zeros(0,1), 1, 32, 20);
%   for ind = 1:10
%       x2 = cicdecim( sigsource() );
%       y = [y; cfir(x2)];
%   end

%   Copyright 2013-2022 The MathWorks, Inc.

    %#codegen
    %#ok<*EMCA>
    properties (Nontunable)
        % SampleRate Input sample rate (Hz)
        %   Specify the sampling rate of the input in Hertz as a finite
        %   numeric scalar. the default is 1.2 MHz.
        SampleRate = 1200000;
        %DecimationFactor Decimation factor
        %   Specify a positive integer amount by which the input signal
        %   will be decimated. The default value of this property is 2.
        DecimationFactor = 2;
        %PassbandFrequency  Passband edge frequency (Hz)
        %   Specify the passband edge frequency of the compensation filter
        %   in Hertz, as a positive real scalar smaller than half the
        %   input sample rate. The default value of this property is
        %   100000 Hz.
        PassbandFrequency = 100000;
        %StopbandFrequency  Stopband edge frequency (Hz)
        %   Specify the stopband edge frequency of the compensation filter
        %   in Hertz, as a positive real scalar smaller than half the
        %   input sample rate. This property applies when you set the
        %   DesignForMinimumOrder property to true. The default value of
        %   this property is 400000 Hz.
        StopbandFrequency = 400000;
    end
    
    properties (Constant, Hidden)
        % SampleRateSet is used to setup the choices for SampleRate (from
        % dialog or inherit from port)
        SampleRateSet = matlab.system.SourceSet({'PropertyOrMethod', ...
            'SystemBlock', 'InheritSampleRate', 'getInheritedSampleRate',true});
    end


    properties (Access = private)
        pFIRDecimator;
    end
    
    properties (Access = protected, Nontunable)
        pStructure = 'Direct form';
        pSR = 1200000;
    end

    properties (Access = protected)
        % NumChannels Cached number of channels (used for error checking)
        NumChannels(1,1) int32 = int32(-1);
    end
    
    %----------------------------------------------------------------------
    % Public methods
    %----------------------------------------------------------------------
    methods
        function obj = CICCompensationDecimator(varargin)
            if ~isempty(varargin) &&  isa(varargin{1}, 'dsp.CICDecimator')
                % The constructor supports taking in an input of the type
                % dsp.CICDecimator. In that case, the properties
                % CICRateChangeFactor, CICDifferentialDelay and
                % CICNumSections are copied from the dsp.CICDecimator
                % object.
                if isempty(coder.target)
                    if any(strcmpi('CICRateChangeFactor', varargin))
                        coder.internal.warning(...
                            'dsp:system:CICCompensationDecimator:irrelevantConstructorInput',...
                            'CICRateChangeFactor');
                    end
                    if any(strcmpi('CICDifferentialDelay', varargin))
                        coder.internal.warning(...
                            'dsp:system:CICCompensationDecimator:irrelevantConstructorInput',...
                            'CICDifferentialDelay');
                    end
                    if any(strcmpi('CICNumSections', varargin))
                        coder.internal.warning(...
                            'dsp:system:CICCompensationDecimator:irrelevantConstructorInput',...
                            'CICNumSections');
                    end
                end
                % Support name-value pair arguments
                setProperties(obj,nargin-1,varargin{2:end},'DecimationFactor');
                % Copy some properties from CICDecimator input to the
                % constructor
                obj.CICRateChangeFactor = varargin{1}.DecimationFactor;
                obj.CICDifferentialDelay = varargin{1}.DifferentialDelay;
                obj.CICNumSections = varargin{1}.NumSections;
            else
                % Support name-value pair arguments
                setProperties(obj,nargin,varargin{:},'DecimationFactor');
            end
        end
         %------------------------------------------------------------------      
        function set.SampleRate(obj,val)
            validateattributes(val,...
                {'double','single'}, ...
                {'real','scalar','positive','finite'},...
                '','SampleRate');
            obj.SampleRate = val;
            postProcessSampleRate(obj,val);
        end
        %------------------------------------------------------------------
        function set.DecimationFactor(obj, value)
            validateattributes(value, {'numeric'}, ...
                {'real', 'positive', 'integer', 'scalar', 'finite'}, ...
                '', 'DecimationFactor');
            obj.DecimationFactor = value;
            needToDesignFilters(obj)
        end
        %------------------------------------------------------------------
        function set.PassbandFrequency(obj, value)
            validateattributes(value, {'numeric'}, ...
                {'real', 'positive', 'real', 'scalar', 'finite'},...
                '', 'PassbandFrequency');
            obj.PassbandFrequency = value;
            needToDesignFilters(obj)
        end
        %------------------------------------------------------------------
        function set.StopbandFrequency(obj, value)
            validateattributes(value, {'numeric'}, ...
                {'real', 'positive', 'real', 'scalar', 'finite'},...
                '', 'PassbandFrequency');
            obj.StopbandFrequency = value;
            needToDesignFilters(obj)
        end
    end
    %----------------------------------------------------------------------
    methods (Hidden)
        function flag = ishdlable(~)
            flag = true;
        end

        function [L,M] = rateConversionFactors(obj) 
            nargoutchk(2, 2);
            M = obj.DecimationFactor;
            L = 1;
        end
    end
    %----------------------------------------------------------------------
    % Protected methods
    %----------------------------------------------------------------------
    methods (Access=protected)
        
        function validatePropertiesImpl(obj)
             coder.internal.errorIf(obj.StopbandFrequency < obj.PassbandFrequency, ...
                'dsp:system:CICCompensationDecimator:invalidPassbandStopband');
        end
        
        function crossValidateProperties(obj)
            % Verify the values of properties before designing filter
            
            inputSampleRate = obj.SampleRate;
            
            coder.internal.errorIf(obj.PassbandFrequency >= inputSampleRate/2, ...
                'dsp:system:CICCompensationDecimator:invalidPassband');
            
            coder.internal.errorIf(obj.DesignForMinimumOrder && ...
                (obj.StopbandFrequency >= inputSampleRate/2), ...
                'dsp:system:CICCompensationDecimator:invalidStopband');
        end
        %------------------------------------------------------------------
        function validateInputsImpl(obj, u)
            % Verify input to the step function
            
            % input must be numeric
            coder.internal.errorIf(~isnumeric(u), ...
                    'dspshared:system:inDataTypeNotFloatIntFixpt', '');
            
            % input cannot be unsigned complex fixed-point
            if isfi(u)
                coder.internal.errorIf(~issigned(u) && ~isreal(u), ...
                    'dsp:system:CICCompensationDecimator:inputUnsignedComplexFixedPoint');
            end
                    
            % Cache input data type for filter analysis
            if isempty(coder.target)
                if ~isempty(u)
                    cacheInputDataType(obj,u)
                end
            end
        end
        %------------------------------------------------------------------
        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end
        %------------------------------------------------------------------
        function resetImpl(obj)
            % Reset the states of decimator object
            reset(obj.pFIRDecimator);
        end
        %------------------------------------------------------------------
        function releaseImpl(obj)
            % Release the decimator object. This allows users to
            % subsequently modify non-tunable properties and call the step
            % method with a different input datatype, different frame size,
            % or a different number of channels.
            release(obj.pFIRDecimator);
            obj.NumChannels = int32(-1);
            if isempty(coder.target)
                % Set fdesign and fmethod on the object to empty
                setMetaData(obj, [], []);
            end
            needToDesignFilters(obj);
        end
        %------------------------------------------------------------------
        function setupImpl(obj,u)
            setupImpl@dsp.internal.SampleRateEngine(obj,u);
            if ~isfloat(u)
                % Always design filters if setup is called with fixed-point
                % input. This is because getFilter method may have designed
                % filter with a default input data type for fixed-point
                % filter analysis.
                needToDesignFilters(obj);
                designFilter(obj,u);
            else
                designFilter(obj);
            end
            setup(obj.pFIRDecimator,u);

            numchans = getNumChannels(obj,u);
            % Disallow a first step with zero channels
            coder.internal.errorIf(numchans == 0,'dsp:system:Shared:EmptyFirstStep');
            obj.NumChannels = int32(numchans);
        end
        %------------------------------------------------------------------
        function y = stepImpl(obj, u)
            % Decimate the input by the specified decimation factor
            y = step(obj.pFIRDecimator, u);
        end
        %------------------------------------------------------------------
        function designFilter(obj,u)
            % Create decimator System object
            
            if obj.pIsFilterDesigned
                % This helps avoid duplicate construction of filters when
                % setup() is called after getFilter().
                % For codegen, this property is always false.
                return
            end
            
            % Get numerator coefficients using fdesign
            coder.extrinsic('dsp.CICCompensationDecimator.designCompensator');
            if isempty(coder.target)
                [num, DecimObj] = coder.const(@dsp.CICCompensationDecimator.designCompensator, ...
                    obj.DecimationFactor, obj.DesignForMinimumOrder, ...
                    obj.CICNumSections, obj.CICDifferentialDelay, ...
                    obj.CICRateChangeFactor, obj.FilterOrder, ...
                    obj.PassbandFrequency, obj.StopbandFrequency, ...
                    obj.PassbandRipple, obj.StopbandAttenuation, obj.pSR);
            else
                num = coder.const(@dsp.CICCompensationDecimator.designCompensator, ...
                    obj.DecimationFactor, obj.DesignForMinimumOrder, ...
                    obj.CICNumSections, obj.CICDifferentialDelay, ...
                    obj.CICRateChangeFactor, obj.FilterOrder, ...
                    obj.PassbandFrequency, obj.StopbandFrequency, ...
                    obj.PassbandRipple, obj.StopbandAttenuation, obj.pSR);
            end
            
            % For codegen, all the nontunable properties of
            % dsp.FIRDecimator need to be set in its constructor itself.
            
            coder.extrinsic('dsp.CICCompensationDecimator.filterPrecision');
            if nargin<2
                % floating-point input
                obj.pFIRDecimator = dsp.FIRDecimator(obj.DecimationFactor, num, 'Structure', obj.pStructure, ...
                    'AllowArbitraryInputLength',coder.const(isInputArbitraryOrVarSize(obj,obj.DecimationFactor)));
            else
                % fixed-point input
                
                % compute output data type
                w = fi(num, obj.CoefficientsDataType);  % vector of filter weights of type fi
                if ~isfi(u)
                    x = numerictype(class(u));
                else
                    x = numerictype(u);
                end
                [outputWL, outputFL] = coder.const(@dsp.CICCompensationDecimator.filterPrecision, w, x);
                outputDType = numerictype([], outputWL, outputFL);
                
                obj.pFIRDecimator = dsp.FIRDecimator(obj.DecimationFactor, num, ...
                        'Structure', obj.pStructure, ...
                        'CoefficientsDataType', 'Custom', ...
                        'CustomCoefficientsDataType', numerictype([], w.WordLength, w.FractionLength), ...
                        'FullPrecisionOverride', false, ...
                        'OutputDataType', 'Custom', ...
                        'CustomOutputDataType', outputDType, ...
                        'RoundingMethod', obj.RoundingMethod,...
                        'AllowArbitraryInputLength',coder.const(isInputArbitraryOrVarSize(obj,obj.DecimationFactor)));
            end
            
            if isempty(coder.target)
                % Set fdesign and fmethod on the object
                setMetaData(obj, getfdesign(DecimObj), getfmethod(DecimObj));
                % Set pIsFilterDesigned to true to indicate the filter has
                % been designed
                obj.pIsFilterDesigned = true;
            end
        end 
        %------------------------------------------------------------------
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@dsp.internal.CICCompensationBase(obj);
            if isLocked(obj)
                if isempty(obj.pFIRDecimator)
                    s.pFIRDecimator = obj.pFIRDecimator;
                else
                    s.pFIRDecimator = matlab.System.saveObject(obj.pFIRDecimator);
                end
                s.pStructure = obj.pStructure;
                s.NumChannels = obj.NumChannels;
            end
            s.pIsFilterDesigned = obj.pIsFilterDesigned;
        end
        %------------------------------------------------------------------
        function loadObjectImpl(obj, s, wasLocked)
            loadObjectImpl@dsp.internal.CICCompensationBase(obj,s,wasLocked);
            if wasLocked
                if isempty(s.pFIRDecimator)
                    obj.pFIRDecimator = s.pFIRDecimator;
                else
                    obj.pFIRDecimator = matlab.System.loadObject(s.pFIRDecimator);
                end
                obj.pStructure = s.pStructure;
                if isfield(s,'NumChannels')
                    obj.NumChannels = s.NumChannels;
                end
            end
        end
        %------------------------------------------------------------------ 
        function postProcessSampleRate(obj,val)
            needToDesignFilters(obj);
            obj.pSR = val;
        end
    end
    %----------------------------------------------------------------------
    % Hidden methods
    %----------------------------------------------------------------------
    methods (Hidden)
        function props = getNonFixedPointProperties(~)
            props = dsp.CICCompensationDecimator.getDisplayPropertiesImpl;
        end
        %------------------------------------------------------------------
        function FIRDecim = getFilter(obj, varargin)
            %GETFILTER Obtain a clone of the designed filter
            %   FIRDecim = getFilter(obj) returns the underlying filter
            %   'FIRDecim' used to perform the CIC Compensation.
            %
            %   FIRDecim = getFilter(obj, inNT) returns the underlying
            %   filter 'FIRDecim' used to perform the CIC Compensation for
            %   the input numerictype inNT.
            %
            %   Note: This function is not supported to work
            %   with code generation using MATLAB Coder(TM)
            %
            %   % Example: Analysis of filter used as compensator
            %   CICComp = dsp.CICCompensationDecimator;
            %   FIRDecim = getFilter(CICComp)
            %   fvtool(FIRDecim)
            if nargin > 1
                inNT = varargin{1};
                if isfixed(inNT)
                    designFilter(obj, fi(0, inNT));
                else
                    designFilter(obj);
                end
            else
                designFilter(obj);
            end
            FIRDecim = clone(obj.pFIRDecimator);
        end
    end
    %----------------------------------------------------------------------
    % Static methods
    %----------------------------------------------------------------------
    methods(Static)
        function helpFixedPoint
            %helpFixedPoint Display CICCompensationDecimator System object
            %               fixed-point information
            %   dsp.CICCompensationDecimator.helpFixedPoint displays 
            %   information about fixed-point properties and operations of 
            %   the CICCompensationDecimator System object.
            
            matlab.system.dispFixptHelp('dsp.CICCompensationDecimator', ...
                dsp.CICCompensationDecimator.getDisplayFixedPointPropertiesImpl);
        end
    end
    %----------------------------------------------------------------------
    % Static hidden methods
    %----------------------------------------------------------------------
    methods (Static, Hidden)
        function [num, DecimObj] = designCompensator(...
                DecimationFactor, DesignForMinimumOrder, ...
                NumberOfSections, DifferentialDelay, ...
                CICRateChangeFactor, FilterOrder, ...
                Fpass, Fstop, Apass, Astop, SampleRate)
            %designCompensator Design a decimator using specifications and
            %                  return its numerator coefficients
            
            if DesignForMinimumOrder
                Specification = 'Fp,Fst,Ap,Ast';
                f = fdesign.decimator(...
                    DecimationFactor, 'ciccomp', DifferentialDelay, ...
                    NumberOfSections, CICRateChangeFactor, ...
                    Specification, Fpass, Fstop, Apass, Astop, ...
                    SampleRate);
            else
                Specification = 'N,Fp,Ap,Ast';
                f = fdesign.decimator(...
                    DecimationFactor, 'ciccomp', DifferentialDelay, ...
                    NumberOfSections, CICRateChangeFactor, ...
                    Specification, FilterOrder, Fpass, Apass, Astop, ...
                    SampleRate);
            end
            
            if DesignForMinimumOrder
                s = warning('off', 'dsp:fdfmethod:eqriplpminisinc:designargs:InvalidFreqFactor');
                try     %#ok 
                    if strcmp(s.state, 'on')
                        Fpass_norm = 2*Fpass/SampleRate;
                        Fstop_norm = 2*Fstop/SampleRate;
                        fo = Fpass_norm + (Fstop_norm-Fpass_norm)/2;
                        FreqFactor = DifferentialDelay/2;
                        if FreqFactor > 1/fo
                            coder.internal.warning('dsp:system:CICCompensationDecimator:DifferentialDelayTooLarge');
                        end
                    end
                    DecimObj = design(f, 'SystemObject', true);
                    warning(s);
                catch e
                    warning(s);
                    throw(e);
                end
            else
                DecimObj = design(f, 'SystemObject', true);
            end
            
            num = DecimObj.Numerator;
        end
        %------------------------------------------------------------------
        function [outputWL, outputFL] = filterPrecision(w,x)
            %filterPrecision Determine filter precision settings.
            
            % No need to take worst-case WL and FL out of each polyphase
            % branch in decimator case because the branch outputs are added
            [~,Q] = dsp.internal.FIRFilterPrecision(w,x);
            outputWL = Q.WordLength;
            outputFL = Q.FractionLength;
        end
    end
    %----------------------------------------------------------------------
    % Static protected methods
    %----------------------------------------------------------------------
    methods(Static,Access=protected)
        function groups = getPropertyGroupsImpl
            CICprops = dsp.internal.CICCompensationBase.getCICProperties;
            FilterProps = dsp.internal.CICCompensationBase.getFilterProperties;
            
            CICSection = matlab.system.display.Section(...
                'Title', getString(message('dsp:system:CICCompensationBase:CICTitleString')), ...
                'PropertyList', CICprops);
            
            filterSection = matlab.system.display.Section(...
                'Title', getString(message('dsp:system:CICCompensationBase:FilterTitleString')), ...
                'PropertyList', [{'DecimationFactor'}, FilterProps]);
            
            mainSG = matlab.system.display.SectionGroup(...
                'TitleSource', 'Auto', ...
                'Sections', [CICSection filterSection]);

            dtSG = matlab.system.display.internal.DataTypesGroup(...
                'dsp.CICCompensationDecimator');
            
            dtSG.PropertyList{2} = matlab.system.display.internal.DataTypeProperty('CoefficientsDataType', ...
                'Prefix', 'coeffs', ...
                'Description', 'Coefficients');
            
            groups = [mainSG, dtSG];
        end
    end
end
