classdef (StrictDefaults)FarrowRateConverter < dsp.internal.SupportScalarVarSize & ...
        dsp.internal.FilterAnalysis
%FarrowRateConverter Polynomial sample rate converter with arbitrary
%conversion factor.
%   SRC = dsp.FarrowRateConverter returns a polynomial sample rate
%   converter which converts the rate of each channel of the input signal
%   from the input sampling rate to the output sampling rate within
%   specified tolerance.
%
%   SRC = dsp.FarrowRateConverter('PropertyName', PropertyValue, ...)
%   returns a polynomial sample rate converter, SRC, with each specified
%   property set to the specified value.
%
%   SRC = dsp.FarrowRateConverter(FSIN, FSOUT, TOL, NP) returns a
%   polynomial sample rate converter, SRC, with InputSampleRate property
%   set to FSIN, OutputSampleRate property set to FSOUT,
%   OutputRateTolerance property set to TOL and PolynomialOrder property
%   set to NP.
%
%   Step method syntax:
%
%   Y = step(SRC, X) designs a polynomial-based interpolation or decimation
%   filter and then uses the filter to convert the rate of each channel
%   (column) of the real or complex input signal X to the output sampling
%   rate specified in SRC.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   FarrowRateConverter methods:
%
%   step                      - See above description for use of this
%                               method
%   release                   - Allow property value and input
%                               characteristics changes
%   clone                     - Create FarrowRateConverter object with same
%                               property values
%   isLocked                  - Locked status (logical)
%   reset                     - Reset the internal states to initial
%                               conditions
%   getPolynomialCoefficients - Return polynomial coefficients used for
%                               rate conversion
%   getRateChangeFactors      - Get interpolation/decimation factors
%   getActualOutputRate       - Get adjusted output sample rate
%   generatehdl               - Generate HDL code. (Filter Design HDL Coder Required)
%
%   FarrowRateConverter properties:
%
%   InputSampleRate           - Input signal sampling rate (Hz)
%   OutputSampleRate          - Output signal sampling rate (Hz)
%   OutputRateTolerance       - Allowable tolerance for output signal rate
%   Specification             - 'Polynomial order' (default) | 'Coefficients'
%   PolynomialOrder           - Polynomial order for Lagrange interpolation filter
%                               (valid when Specification is 'Polynomial order')
%   Coefficients              - Directly-specified polynomial coefficients
%                               (valid when Specification is 'Coefficients')
%
%   This System object supports several filter analysis methods. For more
%   information, type dsp.FarrowRateConverter.helpFilterAnalysis.
%
%   This System object supports fixed-point operations. For more
%   information, type dsp.FarrowRateConverter.helpFixedPoint.
%
%   % EXAMPLE 1: Resample the input by a factor of 21/19
%   FsIn = 19;
%   frc = dsp.FarrowRateConverter(FsIn, 21);
%   n = (0:40)';
%   u = sin(n*pi/5).*exp(-0.025*(n-20).^2);
%   y = frc(u);
%
%   % Plot the original and resampled signals.
%   [D,FsOut] = frc.outputDelay(); 
%   ts = timescope(2, [FsIn FsOut], TimeDisplayOffset=[0, -D],... 
%                  ChannelNames={'Original','Resampled'},...
%                  PlotType='stem');
%   ts(u,y);
%
%   % EXAMPLE 2: Convert an audio signal from 44.1 kHz to 96 kHz
%   rateconv = dsp.FarrowRateConverter('InputSampleRate',44.1e3,...
%         'OutputSampleRate',96e3);
%   audioReader = dsp.AudioFileReader('guitar10min.ogg','SamplesPerFrame',14700);
%   audioWriter = dsp.AudioFileWriter('guitar10min_96kHz.wav','SampleRate',96e3);
%
%   tic
%   while toc < 10
%       x = audioReader();
%       y = rateconv(x);
%       audioWriter(y);
%   end
%   release(audioReader); release(audioWriter); release(rateconv)
%
%   % EXAMPLE 3: Adjust output sample rate tolerance
%   rateconv = dsp.FarrowRateConverter(InputSampleRate=8e3,...
%       OutputSampleRate=44.1e3);
%
%   % 0% tolerance (default): actual rate conversion factor is L/M=441/80
%   [L,M] = getRateChangeFactors(rateconv)
%
%   % The output sample rate remains as specified
%   FsOut = getActualOutputRate(rateconv)
%
%   % Set 1% tolerance 
%   rateconv.OutputRateTolerance = 0.01;
%
%   % Actual rate conversion factor is now L/M=11/2
%   [Le,Me] = getRateChangeFactors(rateconv)
%
%   % The output sample rate is now 44000 (100Hz below spec)
%   FsOutNew = getActualOutputRate(rateconv)
%
%   See also dsp.SampleRateConverter, dsp.FIRRateConverter,
%            dsp.FIRDecimator, dsp.FIRInterpolator,
%            dsp.FarrowRateConverter.helpFilterAnalysis,
%            designMultirateFIR, designFracDelayFIR.

% Copyright 2014-2022 The MathWorks, Inc.

%#codegen
%#ok<*EMCA>

properties (Nontunable)
    %InputSampleRate Sample rate of input signal (Hz)
    %   Specify the sampling rate of the input signal in Hertz, as a
    %   finite numeric scalar. The default value of this property is
    %   44100
    InputSampleRate = 44.1e3;
    %OutputSampleRate Sample rate of output signal (Hz)
    %   Specify the sampling rate of the output signal in Hertz, as a
    %   finite numeric scalar. The default value of this property is
    %   48000
    OutputSampleRate = 48e3;
    %OutputRateTolerance Tolerance for output sample rate
    %   Specify the tolerance for the rate desired for the output
    %   signal, as a finite numeric scalar. The output rate tolerance
    %   allows for a simpler design in many cases. However, the actual
    %   output sample rate will vary for the output sample rate
    %   specified within the given tolerance percentage. For example,
    %   if OutputRateTolerance is specified as 0.01, the actual output
    %   sample rate will be in the range given by OutputSampleRate +/-
    %   1%. The default value of this property is 0
    OutputRateTolerance = 0;
    %Specification Filter specification method
    %   Specify how to determine the polynomial interpolator
    %   coefficients as one of ['Polynomial order' | 'Coefficients'].
    %   The default value of this property is 'Polynomial order'.
    Specification = 'Polynomial order';
    %PolynomialOrder Polynomial order
    %   Specify the order of the Lagrange interpolation filter, as a
    %   finite numeric scalar. The default value of this property is 3.
    %   This property only applies when Specification is 'Polynomial order'
    PolynomialOrder = 3;
    %Coefficients Coefficients
    %   Specify the polynomial coefficients. This property must be a
    %   real-valued square matrix. The default value is [-1 1; 1 0].
    %   This property only applies when Specification is 'Coefficients'
    Coefficients = [-1 1; 1 0];
    %RoundingMethod Rounding method for fixed-point arithmetic operations
    %   Specify the rounding method as one of ['Ceiling' | 'Convergent'
    %   | 'Floor' | 'Nearest' | 'Round' | 'Zero']. The default value of
    %   this property is 'Floor'.
    RoundingMethod = 'Floor';
    %OverflowAction Overflow action for fixed-point arithmetic operations
    %   Specify the overflow action as one of ['Wrap' | 'Saturate'].
    %   The default value of this property is 'Wrap'.
    OverflowAction = 'Wrap';
    %CoefficientsDataType Custom coefficients data type
    %   Specify the coefficients data type with a numerictype object.
    %   The default is numerictype(1,16).
    %   The coefficients data type must be signed.
    CoefficientsDataType = numerictype(1,16);
    %FractionalDelayDataType Custom fractional delay data type
    %   Specify the fractional delay data type with a numerictype object.
    %   The default is numerictype(0,8).
    %   The fractional delay data type must be unsigned.
    FractionalDelayDataType = numerictype(0,8);
    %MultiplicandDataType Custom multiplicand data type
    %   Specify the multiplicand data type with a numerictype object.
    %   The default is numerictype(1,16,13).
    %   The multiplicand data type must be signed.
    MultiplicandDataType = numerictype(1,16,13);
    %OutputDataType Output data type
    %   Specify the output data type as a numeric type object or
    %   as one of the following:
    %   [ 'Same word length as input' | 'Same as accumulator' ]
    %   The default is 'Same word length as input'.
    %   The output data type must be signed.
    OutputDataType = 'Same word length as input';
end

properties (Nontunable, Access = protected)
    PolynomialCoefficients;
    InterpolationFactor;
    DecimationFactor;
    CoefficientsExist = false;
    AdjustedOutputRate;
    PrivCoeff;
    PrivLinv;
    PrivL;
    PrivM;
    pIsFltPt; % Indicates usage of internal double/single datatypes
    pInputDatatype; % datatype of input when object is locked
end

properties(Constant, Hidden)
    SpecificationSet = matlab.system.StringSet( { ...
        'Polynomial order', ...
        'Coefficients'} );

    RoundingMethodSet = matlab.system.internal.RoundingMethodSet({...
        'Ceiling', ...
        'Convergent', ...
        'Floor', ...
        'Nearest', ...
        'Round', ...
        'Zero'});

    OverflowActionSet = matlab.system.internal.OverflowActionSet;

    CoefficientsDataTypeSet = matlab.system.internal.DataTypeSet( ...
        {matlab.system.internal.CustomDataType('Signedness', {'Signed'}, 'Scaling', {'Unspecified', 'BinaryPoint'})}, ...
        'HasDesignMinimum', false, ...
        'HasDesignMaximum', false);

    FractionalDelayDataTypeSet = matlab.system.internal.DataTypeSet( ...
        {matlab.system.internal.CustomDataType('Signedness', {'Unsigned'}, 'Scaling', {'Unspecified'})}, ...
        'HasDesignMinimum', false, ...
        'HasDesignMaximum', false);

    MultiplicandDataTypeSet = matlab.system.internal.DataTypeSet( ...
        {matlab.system.internal.CustomDataType('Signedness', {'Signed'}, 'Scaling', {'BinaryPoint'})}, ...
        'HasDesignMinimum', false, ...
        'HasDesignMaximum', false);

    OutputDataTypeSet = matlab.system.internal.DataTypeSet( { ...
        'Same word length as input', ...
        'Same as accumulator', ...
        matlab.system.internal.CustomDataType('Signedness', {'Signed'}, 'Scaling', {'Unspecified', 'BinaryPoint'}) }, ...
        'HasDesignMinimum', true, ...
        'HasDesignMaximum', true);

end

properties (Access = protected)
    % Tnext Used to compute fractional delay
    Tnext;
    % States Internal filter states
    States=[];
end

properties (Hidden, Access = protected)
    % Number of channels (locked after stepping)
    numChannels=int16(-1);
end

methods
    % Constructor
    function obj = FarrowRateConverter(varargin)
        setProperties(obj, nargin, varargin{:}, ...
            'InputSampleRate', ...
            'OutputSampleRate', ...
            'OutputRateTolerance', ...
            'PolynomialOrder');
    end

    function set.InputSampleRate(obj, Fs)
        validateattributes(Fs, ...
            {'numeric'}, ...
            {'real', 'positive', 'scalar', 'finite'}, ...
            'set.InputSampleRate', ...
            'InputSampleRate');
        obj.InputSampleRate = Fs;
        needToDesignFilter(obj);
    end

    function set.OutputSampleRate(obj, Fs)
        validateattributes(Fs, ...
            {'numeric'}, ...
            {'real', 'positive', 'scalar', 'finite'}, ...
            'set.OutputSampleRate', ...
            'OutputSampleRate');
        obj.OutputSampleRate = Fs;
        needToDesignFilter(obj);
    end

    function set.OutputRateTolerance(obj, tol)
        validateattributes(tol, ...
            {'numeric'}, ...
            {'real', 'nonnegative', 'scalar', 'finite'}, ...
            'set.OutputRateTolerance', ...
            'OutputRateTolerance');
        obj.OutputRateTolerance = tol;
        needToDesignFilter(obj);
    end

    function set.Specification(obj, S)
        obj.Specification = S;
        needToDesignFilter(obj);
    end

    function set.PolynomialOrder(obj, N)
        validateattributes(N, ...
            {'numeric'}, ...
            {'real','integer','positive','scalar','finite','<=', 4}, ...
            'set.PolynomialOrder', ...
            'PolynomialOrder');
        obj.PolynomialOrder = N;
        needToDesignFilter(obj);
    end

    function set.Coefficients(obj, C)
        validateattributes(C, ...
            {'numeric'}, ...
            {'real','2d','square','finite'}, ...
            'set.Coefficients', ...
            'Coefficients');
        obj.Coefficients = C;
        needToDesignFilter(obj);
    end

    function FsOut = get.AdjustedOutputRate(obj)
        [L, M] = dsp.SampleRateConverter.myrat(obj.InputSampleRate, ...
            obj.OutputSampleRate, obj.OutputRateTolerance);

        FsOut = obj.InputSampleRate*L/M;
    end

    % Fixedpoint restrictions
    function set.CoefficientsDataType(obj,val)
        validateCustomDataType(obj, ...
            'CoefficientsDataType',val, {'SIGNED'});
        obj.CoefficientsDataType = val;
    end

    function set.FractionalDelayDataType(obj,val)
        validateCustomDataType(obj, ...
            'FractionalDelayDataType', val, {'UNSIGNED'});
        obj.FractionalDelayDataType = val;
    end

    function set.MultiplicandDataType(obj,val)
        validateCustomDataType(obj, ...
            'MultiplicandDataType', val, {'SIGNED','SCALED'});
        obj.MultiplicandDataType = val;
    end

    function set.OutputDataType(obj,val)
        if ~isa(val,'char')
            validateCustomDataType(obj, ...
                'OutputDataType',val, {'SIGNED'});
        end
        obj.OutputDataType = val;
    end

    function C = getPolynomialCoefficients(obj)
        %C = getPolynomialCoefficients(obj) Get polynomial coefficients
        %   C = getPolynomialCoefficients(obj) returns the polynomial
        %   coefficients used in the Farrow filter to perform the
        %   sampling rate conversion in a matrix C.
        %   % Example: Get the filter coefficients used for sample rate
        %   % conversion between 44.1 kHz and 48 kHz
        %   SRC = dsp.FarrowRateConverter;
        %   C = getPolynomialCoefficients(SRC);
        if ~obj.CoefficientsExist
            setFarrowSRCProperties(obj);
        end
        C = obj.PolynomialCoefficients';
    end

    function [L, M] = getRateChangeFactors(obj)
        %[L,M] = getRateChangeFactors(obj) Get rate change factors
        %   [L,M] = getRateChangeFactors(obj) returns the interpolation
        %   factor L and the decimation factor M corresponding to the
        %   input/output sample rates. The factors are computed taking
        %   into account the OutputRateTolerance.
        %   % Example: Get interpolation/decimation factors for
        %   % conversion between 44.1 kHz and 48 kHz
        %   SRC = dsp.FarrowRateConverter;
        %   [L,M] = getRateChangeFactors(SRC);
        coder.extrinsic('dsp.SampleRateConverter.myrat');
        [L,M] = coder.const(@dsp.SampleRateConverter.myrat,obj.InputSampleRate,...
            obj.OutputSampleRate,obj.OutputRateTolerance);
    end

    function FsOut = getActualOutputRate(obj)
        %FsOut = getActualOutputRate(obj) Get actual output rate
        %   FsOut = getActualOutputRate(obj) returns the actual output
        %   sample rate computed taking into account the
        %   OutputRateTolerance.
        %   % Example: Get actual output sample rate for conversion
        %   % between 44.1 kHz and 48 kHz with a 1% tolerance
        %   SRC = dsp.FarrowRateConverter;
        %   SRC.OutputRateTolerance = 0.01;
        %   FsOut = getActualOutputRate(SRC);
        [L, M] = getRateChangeFactors(obj);
        FsOut = obj.InputSampleRate*L/M;
    end

    function c = cost(obj, varargin)
        %C = cost(obj) compute implementation cost
        %   C = cost(obj) returns a structure C whose fields contain
        %   information about the computation cost of implementing the
        %   Farrow rate converter. The cost estimate contains the
        %   following fields:
        %   NumCoefficients               : Number of farrow filter
        %                                   coefficients
        %   NumStates                     : Number of states
        %   MultiplicationsPerInputSample : Number of multiplications
        %                                   per input sample
        %   AdditionsPerInputSample       : Number of additions per
        %                                   input sample
        %   % Example: Compute cost for conversion between 44.1 kHz and
        %   % 48 kHz with a 0% tolerance
        %   SRC = dsp.FarrowRateConverter;
        %   cost(SRC)
        c = cost@dsp.internal.FilterAnalysis(obj,varargin{:});
        c.NumCoefficients = size(obj.PolynomialCoefficients,1)*size(obj.PolynomialCoefficients,2);
    end

    function fdhdltool(obj,InputNumericType)
        %   FDHDLTOOL(FRC, nt) launches the Generate HDL dialog that lets you
        %   customize and generate Verilog or VHDL code and test benches for
        %   the dsp.FarrowRateConverter, FRC. You have to call FDHDLTOOL
        %   again if you make changes in the filter, FRC, in the command line.
        %
        %   The main dialog and two subordinate dialogs provide access to many
        %   options for customizing the generated filter and test bench code.
        %
        %   The Generate HDL main dialog categorizes options in two frames:
        %
        %   * HDL Filter - Options you are most likely to customize at least once:
        %   language selection, name and location of generated files, reset
        %   specifications, and optimizations.
        %
        %   * Test bench types - Options for naming and specifying the type of test
        %   bench files to generate, and specific types of stimuli the test benches
        %   are to apply.
        %
        %   EXAMPLE:
        %   frc = dsp.FarrowRateConverter;
        %   inT = numerictype(1,16,15);
        %   fdhdltool(frc, inT)

        if ~exist('InputNumericType','var')
            error(message('hdlfilter:privgeneratehdl:fdhdltoolinputdatatypenotspecified'));
        end

        frc = sysobjHdl(obj,'InputDataType',InputNumericType);
        fdhdltool(frc);
    end

    function generatehdl(obj,varargin)
        %   GENERATEHDL(FRC, 'InputDataType', nt) automatically generates VHDL
        %   or Verilog code for the dsp.FarrowRateConverter, FRC. The default
        %   language is VHDL; to generate Verilog, supply the
        %   property/value pair 'TargetLanguage','Verilog'. The file is written to
        %   the HDL source directory which defaults to 'hdlsrc' under the
        %   current directory. This directory will be created if necessary.
        %
        %   GENERATEHDL(FRC, PARAMETER1, VALUE1, PARAMETER2, VALUE2, ...)
        %   generates the HDL code with parameter/value pairs. Valid properties
        %   and values for GENERATEHDL are listed in the Filter Design HDL
        %   Coder documentation section "Property Reference."
        %
        %   EXAMPLE:
        %   frc = dsp.FarrowRateConverter;
        %   inT = numerictype(1,16,15);
        %   generatehdl(frc, 'InputDataType', inT)

        for k = 1:length(varargin)
            if iscell(varargin{k})
                [varargin{k}{:}] = convertStringsToChars(varargin{k}{:});
            else
                varargin{k} = convertStringsToChars(varargin{k});
            end
        end

        frc = sysobjHdl(obj,varargin{:});
        % do not use System object for testbench for now
        generatehdl(frc,varargin{:});
        % generatehdl(frc,varargin{:},'FilterSystemObject',clone(obj));
    end

    %----------------------------------------------------------------------
    function flag = islinphase(obj,varargin)
        % If  Lagrange design of odd order, the filter has a linear phase
        flag = (mod(obj.PolynomialOrder,2)==1 && obj.Specification=="Polynomial order") || ...
                    islinphase@dsp.internal.FilterAnalysis(obj,varargin{:});
    end
    
    %----------------------------------------------------------------------
    function [D,varargout] = outputDelay(obj,varargin)
        [FsIn, Fc, tol, N, DefaultFc] = parseOutputDelayArguments(obj,varargin{:});
        
        BandOutputRequested = nargout>2;
        
        % For the special case of Fc==0, there is no need to call grpdelay 
        % as we have a closed form for this value. 
        if Fc==0
            [L,M] = obj.rateConversionFactors();

            coder.internal.warningIf(~obj.islinphase && ~(BandOutputRequested || ~DefaultFc),'dsp:system:FilterAnalysis:NonlinearPhase',Fc);

            % Output sample rate and sample time
            FsOut = FsIn*L/M;
            Tsin  = 1/FsIn;
    
            % Scale the delay to sample units
            D = Tsin*(floor(obj.PolynomialOrder/2)+1);

            if nargout>1
                varargout{1} = FsOut;
            end

            % If user asks for band
            if BandOutputRequested                
                varargout{2}= obj.groupDelayBand(FsIn, 0, D*L, tol, N);
            end
        else
            % For all other frequencies, just use the standard method
            [D,varargout{1:nargout-1}] = outputDelay@dsp.internal.FilterAnalysis(obj,varargin{:});
        end
    end
end % VISIBLE PUBLIC METHODS

methods (Access = protected)

    function flag = isInactivePropertyImpl(obj, prop)
        switch prop
            case {'PolynomialOrder'}
                flag = ~strcmp(obj.Specification, 'Polynomial order');

            case {'Coefficients'}
                flag = ~strcmp(obj.Specification, 'Coefficients');

            otherwise
                flag = false;
        end
    end

    function s = saveObjectImpl(obj)
        % Default implementation saves all public properties
        s = saveObjectImpl@matlab.System(obj);

        % Private properties
        if isLocked(obj)
            s.PolynomialCoefficients = obj.PolynomialCoefficients;
            s.InterpolationFactor    = obj.InterpolationFactor;
            s.DecimationFactor       = obj.DecimationFactor;
            s.CoefficientsExist      = obj.CoefficientsExist;
            s.AdjustedOutputRate     = obj.AdjustedOutputRate;
            s.PrivCoeff              = obj.PrivCoeff;
            s.PrivLinv               = obj.PrivLinv;
            s.PrivL                  = obj.PrivL;
            s.PrivM                  = obj.PrivM;
            s.Tnext                  = obj.Tnext;
            s.States                 = obj.States;
            s.pIsFltPt               = obj.pIsFltPt;
            s.pInputDatatype         = obj.pInputDatatype;
            s.numChannels            = obj.numChannels;
        end
        
        s = saveFA(obj, s);   % Save filter analysis class properties
    end

    function s = loadObjectImpl(obj, s, wasLocked)
        % Call base class method
        loadObjectImpl@matlab.System(obj,s,wasLocked);

        % Load private properties
        if wasLocked
            obj.PolynomialCoefficients = s.PolynomialCoefficients;
            obj.InterpolationFactor    = s.InterpolationFactor;
            obj.DecimationFactor       = s.DecimationFactor;
            obj.CoefficientsExist      = s.CoefficientsExist;
            obj.AdjustedOutputRate     = s.AdjustedOutputRate;
            if isfield(s, 'PrivCoeff')
                % New private object properties added in R2016a
                obj.PrivCoeff = s.PrivCoeff;
                obj.PrivLinv  = s.PrivLinv;
                obj.PrivL     = s.PrivL;
                obj.PrivM     = s.PrivM;
            end
            obj.Tnext  = s.Tnext;
            obj.States = s.States;
            if isfield(s,'pIsFltPt')
                obj.pIsFltPt = s.pIsFltPt;
            end

            if isfield(s, 'pInputDatatype')
                obj.pInputDatatype = s.pInputDatatype;
            end
            
            if isfield(s,'numChannels')
                obj.numChannels = s.numChannels;
            end
        end
        loadFA(obj, s, wasLocked); % Load filter analysis class properties
    end

    function resetImpl(obj)
        % Reset the internal states
        if ~isempty(obj.States)
            if ~isfloat(obj.States) || isreal(obj.States)
                obj.States(:) = 0;
            else
                obj.States(:) = 0  + 1j * cast(eps,'like',obj.States);
            end
        end
        obj.Tnext(:) = obj.InterpolationFactor;
    end
    
    function releaseImpl(obj)
        % Unlock number of channels
        obj.numChannels = int16(-1);
    end

    function setFarrowSRCProperties(obj)

        if obj.CoefficientsExist
            % This helps avoid duplicate construction of filter when
            % setup() is called after getPolynomialCoefficients().
            % For codegen, this property is always false.
            return
        end

        isPolynomialOrderSpec = strcmp(obj.Specification, 'Polynomial order');

        if isPolynomialOrderSpec
            NpOrCf = obj.PolynomialOrder;
        else
            NpOrCf = obj.Coefficients;
        end

        coder.extrinsic('dsp.FarrowRateConverter.deriveCoefficients');
        if isempty(coder.target)
            [L, M, C] = obj.deriveCoefficients( ...
                obj.InputSampleRate,     ...
                obj.OutputSampleRate,    ...
                obj.OutputRateTolerance, ...
                isPolynomialOrderSpec,   ...
                NpOrCf);

            obj.CoefficientsExist = true;

            % Set metadata (fdesign and fmethod)
            if isPolynomialOrderSpec
                fd  = fdesign.polysrc(L, M, 'Fractional Delay','Np', NpOrCf, obj.InputSampleRate*L);
                if ~isempty(getcurrentspecs(fd))
                    fmd = fdfmethod.lagrangesrc; % getdesignobj(specs, 'lagrange')
            else
                    fmd = [];
                end

                setMetaData(obj, fd, fmd);
            end
        else
            [L, M, C] = coder.const(@obj.deriveCoefficients, ...
                obj.InputSampleRate,       ...
                obj.OutputSampleRate,      ...
                obj.OutputRateTolerance,   ...
                isPolynomialOrderSpec,         ...
                NpOrCf);
        end

        obj.InterpolationFactor    = L;
        obj.DecimationFactor       = M;
        obj.PolynomialCoefficients = C;
    end

    function needToDesignFilter(obj)
        obj.CoefficientsExist = false;
    end

    function setupImpl(obj, u)
        % Create Farrow filter
        setFarrowSRCProperties(obj);

        % Reset states and constants with type info
        C_dbl = coder.const(obj.PolynomialCoefficients);
        L_dbl = coder.const(obj.InterpolationFactor);
        M_dbl = coder.const(obj.DecimationFactor);
        Np    = coder.const(size(C_dbl,1) - 1);

        obj.pIsFltPt = isfloat(u) && ~isa(u,'embedded.fi');

        % Cache input datatype
        if isa(u, 'embedded.fi')
            obj.pInputDatatype = numerictype(u);
            if isfloat(u) % If the input is a fltpt fi type
                obj.pInputDatatype = lower(obj.pInputDatatype.DataTypeMode);
            end
        else
            obj.pInputDatatype = class(u);
        end

        % Obtain number of channels
        if obj.getExecPlatformIndex()
            % Simulink sometimes calls the setupImpl method with an emtpy
            % input, which throws off caching the number of channels.
            % Safest bet is to obtain the number of channels from propagatedInputSize
            sz = propagatedInputSize(obj, 1);
            nc = sz(2);
        else
            nc = size(u,2);
        end

        if isfloat(u) 
            % Double or Single
            if isreal(u)
                obj.States    = zeros(Np+1, nc, 'like', u);
            else
                obj.States    = complex(zeros(Np+1, nc, 'like', u));
            end
            obj.PrivCoeff = cast(C_dbl,   'like', real(u));
            
            % Store iteration parameters using internal datatype
            obj.PrivL     = cast(L_dbl,   'like', real(u));
            obj.PrivM     = cast(M_dbl,   'like', real(u));
            obj.PrivLinv  = cast(1/L_dbl, 'like', real(u));
            obj.Tnext     = cast(L_dbl,   'like', real(u));
        else
            % Fixed-point
            dataTypes = determineDataTypes(obj, u);

            % Filter arithmetic: Use object FIMATH settings
            objRM  = obj.RoundingMethod;
            objOA  = obj.OverflowAction;
            objFm  = fimath(...
                'RoundingMethod', objRM, 'OverflowAction', objOA);

            obj.States    = setfimath(zeros(Np+1, nc, 'like', dataTypes.inpT), objFm);
            obj.PrivCoeff = setfimath(cast(C_dbl,     'like', dataTypes.cofT), objFm);

            % FD loop computation: (ALSO CONSIDER fdLoopFm = hdlfimath)
            fdLoopFm = objFm;
            maxSum   = coder.const(2 * max([L_dbl(:); M_dbl(:)]));
            maxWL    = coder.const(1 + ceil(log2(maxSum)));
            TnT      = fi(0, numerictype(1, coder.const(maxWL), 0));

            % Store iteration parameters using internal datatype
            obj.PrivL     = setfimath(cast(L_dbl,   'like', TnT), fdLoopFm);
            obj.PrivM     = setfimath(cast(M_dbl,   'like', TnT), fdLoopFm);
            obj.PrivLinv  = setfimath(cast(1/L_dbl, 'like', dataTypes.linT), fdLoopFm);
            obj.Tnext     = setfimath(cast(L_dbl,   'like', TnT), fdLoopFm);
        end

        % Warn if internal datatype is insufficient
        if coder.target('MATLAB')
            coder.internal.warningIf(obj.PrivL~=obj.InterpolationFactor || ...
                obj.PrivM~=obj.DecimationFactor,...
                'dsp:system:FarrowRateConverter:datatypeRounding',...
                class(obj.Tnext),...
                obj.InterpolationFactor,obj.DecimationFactor);
        end
    end
    
    function y = stepImpl(obj, u)
        nu      = size(u,1); % Input frame size
        nc      = size(u,2); % Number of channels
       
        % Cache input dimensions
        if obj.numChannels==-1
            obj.numChannels = int16(nc);
        end

        isFltPt = isfloat(u);
        ny = obj.outputFrameSize(nu);

        if isFltPt
            % Floating point input (double/single or embedded.fi floats)
            MultiplicandPrototype = zeros(1,1,'like',u);
            y  = zeros(ny, nc,  'like', u);
            fd = real(zeros(1, 1, 'like', real(u)));
        else
            % Fixed-point or integer input
            dataTypes = determineDataTypes(obj, u);
            MultiplicandPrototype = dataTypes.mcdT;

            objRM = obj.RoundingMethod;
            objOA = obj.OverflowAction;
            objFm = fimath('RoundingMethod', objRM, 'OverflowAction', objOA);
            y  = setfimath(zeros(ny, nc,  'like', dataTypes.outT), objFm);
            fd = real(setfimath(zeros(1, 1, 'like', dataTypes.frdT), objFm));
        end

        if isempty(coder.target) && obj.pIsFltPt
            [y, lTnext, Z] = dsp.internal.builtins.frc(ny,obj.States,...
                                obj.Tnext, obj.PrivCoeff, ...
                                obj.PrivLinv, obj.PrivL,obj.PrivM,...
                                u);
        else
            [y, lTnext, Z] = obj.farrowLoop(fd,MultiplicandPrototype,u,y);
        end 

        % Update states for next stepImpl
        obj.States(:) = Z;
        obj.Tnext(:)  = lTnext;

        if isempty(coder.target) && ~isFltPt
            y = removefimath(y);
        end
    end

 function [y, lTnext, Z] = farrowLoop(obj,fd,MultiplicandPrototype, u, y)
        nu      = size(u,1); % Input frame size
        nc      = size(u,2); % Number of channels
        
        L       = coder.const(obj.PrivL); 
        M       = coder.const(obj.PrivM);
        lTnext  = obj.Tnext; % Phase
        C_dbl   = coder.const(obj.PolynomialCoefficients);
        Np      = coder.const(size(C_dbl,1) - 1);
        C       = coder.const(obj.PrivCoeff);
        Z       = obj.States;
        Linv    = coder.const(obj.PrivLinv);
        yIdx    = int32(1);

        % Set up multiplicand
        pMpc    = zeros([1 nc], 'like', MultiplicandPrototype);

        for k = 1:nu
            % Update internal states and apply filter coefficients
            Z(:) = [u(k,:); Z(1:end-1,:)];
            
            % Obtain polynomial coefficients for the current interval
            Cz = C*Z;

            % Loop fractional delay over current interval
            while (lTnext >0)
                % Compute fractional delay
                fd(:) = lTnext .* Linv;

                % Apply polynomial using Horner's rule
                pMpc(:) = Cz(1,:);
                yAcc = fd * pMpc;

                for pIdx = 2:Np
                    pMpc(:) = Cz(pIdx,:) + yAcc;
                    yAcc = fd * pMpc;
                end
                y(yIdx, :) = yAcc + Cz(Np+1,:);

                % Update local loop states.
                lTnext(:) = lTnext - M;
                yIdx(:)   = yIdx + 1;
            end

            lTnext(:) = lTnext + L;
        end
    end

    function validateInputsImpl(obj, u) 
        % Invoked at first call to setup/step, and then every time the
        % input dimensions change

        % Make sure System object properties and type info available
        if ~obj.CoefficientsExist
            setFarrowSRCProperties(obj);
        end

        % Check validity of input (SIGNED data types only, '2d' only)
        validateattributes(u, ...
            {'single', 'double', 'embedded.fi', ...
            'int8',   'int16',  'int32', },   ...
            {'2d'}, 'FarrowRateConverter','dataIn');

        if isempty(coder.target) && isa(u,'embedded.fi') && isfixed(u)
            coder.internal.errorIf(~issigned(u),'dsp:system:FarrowRateConverter:inputMustBeSignedFixedPoint');
            coder.internal.errorIf(~isscalingbinarypoint(u),'fixed:fi:inputsMustBeIntOrFixPtBPSOrSDBPS');
        end
        
        % Verify the number of channels hasn't changed
        coder.internal.errorIf((obj.numChannels~=-1) && (size(u,2) ~= obj.numChannels), 'dsp:system:Shared:numChannels');
    end

    function flag = isInputSizeMutableImpl(~,~)
        % Variable size inputs are allowed
        flag = true;
    end

    function s = infoImpl(obj, varargin)

        s = infoFA(obj,varargin{:});

        if obj.OutputRateTolerance ~= 0
            sTol = sprintf('Output Rate Tolerance : %f %%', 100*obj.OutputRateTolerance);
            sFsOut = sprintf('Adjusted Output Rate  : %f', obj.AdjustedOutputRate);
            sz1 = size(s);
            sz2 = size(sTol);
            sz3 = size(sFsOut);

            s(sz1(1)+1,1:sz2(2)) = sTol;
            s(sz1(1)+2,1:sz3(2)) = sFsOut;
        end
    end

    function d = convertToDFILT(obj, arith)
        % Convert the System object to a mfilt object

        % Make sure System object properties and type info available
        if ~obj.CoefficientsExist
            setFarrowSRCProperties(obj);
        end

        % Suppress MFILT deprecation warning
        w = warning('off', 'dsp:mfilt:mfilt:Obsolete');
        restoreWarn = onCleanup(@() warning(w));
        d = dsp.internal.mfilt.farrowsrc( ...
            obj.InterpolationFactor, ...
            obj.DecimationFactor,    ...
            getPolynomialCoefficients(obj));

        % Set MFILT 'Arithmetic'
        if ~isempty(arith)
            % Specified 'Arithmetic' argument takes precedence.
            d.Arithmetic = arith;
        elseif isLocked(obj)
            % Use System object input data types to set 'Arithmetic'
            dt1 = obj.pInputDatatype;
            if ischar(dt1) && (strcmp(dt1,'double') || strcmp(dt1,'single'))
                d.Arithmetic = dt1;
            else
                % Set MFILT to fixed-point
                d.Arithmetic = 'fixed';
            end
        else
            % Unspecified 'Arithmetic', System object not locked
            d.Arithmetic = 'double';
        end

        if strcmp(d.Arithmetic,'fixed')

            isSysObjInpTypeFixPt = false;

            
            if isLocked(obj)
                dt1 = obj.pInputDatatype;
                if ~ischar(dt1) || ~(strcmp(dt1,'double') || strcmp(dt1,'single'))
                    % Sys obj input is signed fixed-point or integer
                    if ischar(dt1) % string, e.g. 'int16', etc.
                        protoTypeToUse = eval([dt1 '(0)']);
                    else % fixed-point numerictype
                        protoTypeToUse = fi(0,dt1);
                    end
                    isSysObjInpTypeFixPt = true;
                end
            end

            if ~isSysObjInpTypeFixPt
                % MFILT is 'fixed' arithmetic AND either:
                %   * System object locked type is double/single
                %   * OR System object is NOT yet locked
                protoTypeToUse = fi(0,1,16,15); % USE DEFAULT
            end

            dataTypes = determineDataTypes(obj,protoTypeToUse);

            if isfi(dataTypes.inpT)
                inpWL = coder.const(dataTypes.inpT.WordLength);
                inpFL = coder.const(dataTypes.inpT.FractionLength);
            else
                % isinteger(dataTypes.inpT)
                switch class(dataTypes.inpT)
                    case {'int8', 'uint8'}
                        inpWL = 8;
                    case {'int16', 'uint16'}
                        inpWL = 16;
                    case {'int32', 'uint32'}
                        inpWL = 32;
                    otherwise
                        inpWL = 64;
                end
                inpFL = 0;
            end

            d.FilterInternals        = 'SpecifyPrecision';
            d.InputWordLength        = inpWL;
            d.InputFracLength        = inpFL;
            d.CoeffAutoScale         = false;
            d.CoeffWordLength        = dataTypes.cofT.WordLength;
            d.CoeffFracLength        = dataTypes.cofT.FractionLength;
            d.ProductWordLength      = dataTypes.prdT.WordLength;
            d.ProductFracLength      = dataTypes.prdT.FractionLength;
            d.AccumWordLength        = dataTypes.accT.WordLength;
            d.AccumFracLength        = dataTypes.accT.FractionLength;
            d.MultiplicandWordLength = dataTypes.mcdT.WordLength;
            d.MultiplicandFracLength = dataTypes.mcdT.FractionLength;
            d.FDAutoScale            = true;
            d.FDWordLength           = dataTypes.frdT.WordLength;
            d.FDProdWordLength       = dataTypes.fdpT.WordLength;
            d.FDProdFracLength       = dataTypes.fdpT.FractionLength;
            d.OutputWordLength       = dataTypes.outT.WordLength;
            d.OutputFracLength       = dataTypes.outT.FractionLength;
            d.OverflowMode           = lower(obj.OverflowAction);
            rmLowerCase              = lower(obj.RoundingMethod);

            switch(rmLowerCase)
                case 'ceiling'
                    d.RoundMode = 'ceil';
                case 'zero'
                    d.RoundMode = 'fix';
                otherwise
                    d.RoundMode = rmLowerCase;
            end

        end % strcmp(d.Arithmetic,'fixed')

        % Set state persistence
        d.PersistentMemory = true;
    end

    function dataTypes = determineDataTypes(obj, inpT)

        % Real or Complex value initializer
        if isreal(inpT)
            rcInit = 0;
        else
            rcInit = complex(0,0);
        end

        if isfloat(inpT) || ~(isinteger(inpT) || isfi(inpT))
            % Floating point inheritance takes precedence:
            cofT = cast(0,      'like', inpT); % Coeffs type (REAL)
            frdT = cast(0,      'like', inpT); % FD type     (REAL)
            linT = cast(0,      'like', inpT); % Linv type   (REAL)
            prdT = cast(rcInit, 'like', inpT); % Coeff Product type
            accT = cast(rcInit, 'like', inpT); % Accumulator type
            mcdT = cast(rcInit, 'like', inpT); % Multiplicand type
            fdpT = cast(rcInit, 'like', inpT); % FDProduct type
            outT = cast(rcInit, 'like', inpT); % Output type

            dataTypes = struct( ...
                'inpT',  inpT,  ...
                'cofT',  cofT,  ...
                'prdT',  prdT,  ...
                'accT',  accT,  ...
                'mcdT',  mcdT,  ...
                'frdT',  frdT,  ...
                'linT',  linT,  ...
                'fdpT',  fdpT,  ...
                'outT',  outT);

        else
            % Fixed-point operation:
            if isfi(inpT)
                inpWL = coder.const(inpT.WordLength);
                inpFL = coder.const(inpT.FractionLength);
            else
                % isinteger(inpT)
                switch class(inpT)
                    case {'int8', 'uint8'}
                        inpWL = 8;
                    case {'int16', 'uint16'}
                        inpWL = 16;
                    case {'int32', 'uint32'}
                        inpWL = 32;
                    otherwise
                        inpWL = 64;
                end
                inpFL = 0;
            end

            % Prototype for Coefficients
            % (might use best precision, might be binary point scaled)
            cofF = fi(obj.getPolynomialCoefficients, ...
                obj.CoefficientsDataType);
            cofT = cast(0, 'like', cofF);

            % Prototype for Fractional Delay (FD values)
            fdWL = coder.const(obj.FractionalDelayDataType.WordLength);
            fdFL = coder.const(fdWL-1);
            frdF = fi(  0, numerictype(0, fdWL, fdFL));
            frdT = cast(0, 'like', frdF);

            % Prototype for "Linv" (1/L) constant value
            linWL = coder.const(fdWL+1);
            linFL = coder.const(fdWL);
            linF  = fi(  0, numerictype(0, linWL, linFL));
            linT  = cast(0, 'like', linF);

            % Prototype for full precision coefficient Product
            % INPUT and COEFFS are always SIGNED only (COEFFS real)
            cofWL = coder.const(cofT.WordLength);
            cofFL = coder.const(cofT.FractionLength);
            prdWL = coder.const(inpWL + cofWL);
            prdFL = coder.const(inpFL + cofFL);
            prdNT = numerictype(1, prdWL, prdFL);
            prdF = fi(  rcInit, prdNT);
            prdT = cast(rcInit, 'like', prdF);

            % Prototype for full precision Accumulator
            % Inputs to Accumulator are the Product (prd) and # accs
            C_dbl = coder.const(obj.PolynomialCoefficients);
            Np    = coder.const(size(C_dbl,1) - 1);
            accWL = coder.const(prdWL + ceil(log2(Np)) + 1);
            accFL = prdFL;
            accNT = numerictype(1, accWL, accFL);
            accF = fi(  rcInit, accNT);
            accT = cast(rcInit, 'like', accF);

            % Prototype for Multiplicand
            mcFi = fi(  rcInit, obj.MultiplicandDataType);
            mcdT = cast(rcInit, 'like', mcFi);

            % Prototype for full precision FDProduct
            % Inputs to this are the Multiplicand (mcd) and FD scalar
            mcdWL = mcdT.WordLength;
            mcdFL = mcdT.FractionLength;
            fdpWL = coder.const(mcdWL + fdWL);
            fdpFL = coder.const(mcdFL + fdFL);
            fdpNT = numerictype(1, fdpWL, fdpFL);
            fdpF  = fi(  rcInit, fdpNT);
            fdpT  = cast(rcInit, 'like', fdpF);

            % Prototype for Output
            outDTSpecified = coder.const(obj.OutputDataType);
            if ischar(outDTSpecified)
                if strcmp(outDTSpecified, 'Same word length as input')
                    % Assuming unity gain
                    outWL = coder.const(inpWL);
                    outFL = coder.const(inpFL);
                    outNT = numerictype(1, outWL, outFL);
                else
                    % No casting case ('Same as accumulator')
                    % Use largest accumulator type prior to output
                    % (keep all bits from acc after final FDProduct)
                    outWL = coder.const(fdpT.WordLength + 1);
                    outFL = coder.const(fdpT.FractionLength);
                    outNT = numerictype(1, outWL, outFL);
                end
            else
                % NUMERICTYPE outDTSpecified
                outWL = coder.const(outDTSpecified.WordLength);
                % NOTE isscalingbinarypoint is NOT same as code below
                if isscaledtype(outDTSpecified) && ...
                        strcmp(outDTSpecified.Scaling,'BinaryPoint')
                    % Binary point scaled: numerictype(1,WL,FL)
                    outFL = coder.const(outDTSpecified.FractionLength);
                    outNT = numerictype(1, outWL, outFL);
                else
                    % Best precision: numerictype(1,WL)
                    if isempty(coder.target)
                        % Assuming unity gain
                        wlAdj = coder.const(outWL - inpWL);
                        outFL = coder.const(inpFL + wlAdj);
                        outNT = numerictype(1, outWL, outFL);
                    else
                        coder.internal.error('dsp:system:FarrowRateConverter:OutputDataTypeFractionLength');
                    end
                end
            end
            outF = fi(rcInit, outNT);
            outT = cast(rcInit, 'like', outF);

            dataTypes = struct( ...
                'inpT',  inpT,  ...
                'cofT',  cofT,  ...
                'prdT',  prdT,  ...
                'accT',  accT,  ...
                'mcdT',  mcdT,  ...
                'frdT',  frdT,  ...
                'linT',  linT,  ...
                'fdpT',  fdpT,  ...
                'outT',  outT);
        end
    end

    function isFixedOutput = isFixedSizeOutput(~) 
        isFixedOutput = false;
    end

    function ny = outputFrameSize(obj,nu)
        fixedOutputSize = coder.const(obj.isFixedSizeOutput());

        % Override System object method to include fixed size output
        if obj.pIsFltPt
            L = coder.const(obj.PrivL);
            M = coder.const(obj.PrivM);
            if fixedOutputSize
                lTnext = coder.const(L);
            else
                lTnext = obj.Tnext;
            end

            ny = ceil(((nu-1)*L + lTnext)/M);
            maxny = ceil((nu*L) / M);
        else
            if obj.PrivL.WordLength>32
                L = uint64(obj.PrivL);
                M = uint64(obj.PrivM);
                if fixedOutputSize
                    lTnext = coder.const(L);
                else
                    lTnext = uint64(obj.Tnext);
                end
            else
                L = uint32(obj.PrivL);
                M = uint32(obj.PrivM);
                if fixedOutputSize
                    lTnext = coder.const(L);
                else
                    lTnext = uint32(obj.Tnext);
                end
            end

            if nu>0
                ny = idivide((nu-1)*L+lTnext,M,'ceil');
            else
                ny = cast(0,'like',L);
            end

            maxny = (nu*L)/M+1;
        end

        % The assert below will hint codegen of an upper bound
        % of the frame size, which helps in varsize allocation
        assert(ny<=maxny);
    end

end % PROTECTED METHODS

methods (Static, Access=protected)
    function groups = getPropertyGroupsImpl
        %Get default parameters group for this System object
        propertyList = {'InputSampleRate','OutputSampleRate',...
            'OutputRateTolerance','Specification',...
            'PolynomialOrder','Coefficients'};

        parameterString = message('dsp:system:Shared:Parameters');
        mainS = matlab.system.display.Section(...
            Title=parameterString.getString, ...
            PropertyList=propertyList);
        mainSG = matlab.system.display.SectionGroup(...
            Title=getString(message('dsp:system:Shared:Main')), ...
            Sections=mainS);

        % Data Types Group
        dtSG = matlab.system.display.internal.DataTypesGroup('dsp.FarrowRateConverter');

        groups = [mainSG, dtSG];
    end
    
end

methods (Static, Hidden)
    function a = getAlternateBlock()
        a = 'dspsigops/Farrow Rate Converter';
    end

    function [L, M, C] = deriveCoefficients(FsIn, FsOut, FsTol, isPolynomialOrderSpec, NpOrCf)
        % Interpolation and decimation factors
        [L, M] = dsp.SampleRateConverter.myrat(FsIn, FsOut, FsTol);

        if (isPolynomialOrderSpec)
            % Design modified Farrow coefficients wherein NpOrCf = polynomial degree
            C = dsp.FarrowRateConverter.designModifiedFarrowCoefficients(NpOrCf);
        else
            % Coefficients matrix is directly-specified
            C = (NpOrCf).';
        end
    end

    function C = designModifiedFarrowCoefficients(N)    
        if N==0
            C = 1;
            return
        end

        % Nondegenerate form, explicitly derived in 
        % http://www.acoustics.hut.fi/~vpv/publications/vesan_vaitos/ch3_pt2_lagrange.pdf
        T = eye(N+1);
        for i = 1:N+1
            for j = i:N+1
                T(i,j) = nchoosek(j-1, i-1)*(floor(N/2))^(j-i);
            end
        end
        C = flipud(T)/fliplr(vander(0:N));

        % Force near-zeros and and near-ones to eliminate roundoff error
        [Ns, Ds]    = rat(C);
        C(Ns == 0)  = 0;
        C(Ns == Ds) = 1;
    
        % Note: below is a shorter alternative 
        % exponents = (0:N);
        % taps = exponents' - floor(N/2);
        % C = flipud(inv(taps.^exponents));
    end

    function props = getDisplayFixedPointPropertiesImpl()
        props = {...
            'RoundingMethod', ...
            'OverflowAction', ...
            'CoefficientsDataType',    ...
            'FractionalDelayDataType', ...
            'MultiplicandDataType',    ...
            'OutputDataType' };
    end
end

methods (Hidden)
    function [L,M] = rateConversionFactors(obj) 
            nargoutchk(2, 2);
            [L,M] = obj.getRateChangeFactors();
    end

    function restrictionsCell = getFixedPointRestrictions(~,~)
        restrictionsCell = {};
    end

    function props = getNonFixedPointProperties(~)
        props = {...
            'InputSampleRate','OutputSampleRate',...
            'OutputRateTolerance','Specification',...
            'PolynomialOrder','Coefficients'};
    end

    function props = getFixedPointProperties(~)
        props = dsp.FarrowRateConverter.getDisplayFixedPointPropertiesImpl;
    end

    function flag = isPropertyActive(obj,prop)
        flag = ~isInactiveProperty(obj, prop);
    end

    function coeffs(~)
        coder.internal.errorIf(true, 'dsp:system:FarrowRateConverter:coeffs');
    end

    function flag = ishdlable(~)
        flag = true;
    end
end


methods (Static)
    function helpFixedPoint
        %helpFixedPoint Display dsp.FarrowRateConverter System object
        %               fixed-point information
        %   dsp.FarrowRateConverter.helpFixedPoint displays information
        %   about fixed-point properties and operations of the
        %   dsp.FarrowRateConverter System object.

        matlab.system.dispFixptHelp('dsp.FarrowRateConverter', { ...
            'RoundingMethod', ...
            'OverflowAction', ...
            'CoefficientsDataType',    ...
            'FractionalDelayDataType', ...
            'MultiplicandDataType',    ...
            'OutputDataType'} );
    end
end
end
