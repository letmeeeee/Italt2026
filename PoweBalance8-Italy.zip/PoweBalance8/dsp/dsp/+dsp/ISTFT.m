classdef ISTFT < handle &  matlab.mixin.internal.indexing.Paren ...
        & matlab.mixin.SetGet
    % ISTFT Inverse short-time FFT
    %   ISTFT = dsp.ISTFT returns an object, ISTFT, that implements inverse
    %   short-time FFT. The object processes the data independently across
    %   each input channel over time.
    %
    %   ISTFT = dsp.ISTFT(WINDOW) returns an inverse short-time FFT object,
    %   ISTFT, with the Window property set to WINDOW.
    %
    %   ISTFT = dsp.ISTFT(WINDOW,OVERLAPLENGTH) returns an inverse
    %   short-time FFT object, ISTFT, with the Window property set to
    %   WINDOW, and the OverlapLength property set to OVERLAPLENGTH,
    %   respectively.
    %
    %   ISTFT = dsp.ISTFT(WINDOW,OVERLAPLENGTH,ISCONJSYM) returns an
    %   inverse short-time FFT object, ISTFT, with the Window property set
    %   to WINDOW, the OverlapLength property set to OVERLAPLENGTH, and the
    %   ConjugateSymmetricInput property set to ISCONJSYM, respectively.
    %
    %   ISTFT = dsp.ISTFT(WINDOW,OVERLAPLENGTH,ISCONJSYM,WOA) returns an
    %   inverse short-time FFT object, ISTFT, with the Window property set
    %   to WINDOW, the OverlapLength property set to OVERLAPLENGTH, the
    %   ConjugateSymmetricInput property set to ISCONJSYM, and the
    %   WeightedOverlapAdd property set to WOA, respectively.
    %
    %   ISTFT = dsp.ISTFT('Name', Value, ...) returns an inverse short-time
    %   FFT object, ISTFT, with each specified property name set to the
    %   specified value. You can specify additional name-value pair
    %   arguments in any order as (Name1,Value1,...,NameN, ValueN).
    %
    %   Step method syntax:
    %
    %   Y = step(ISTFT,X) applies inverse short-time FFT on the input X,
    %   and returns the time-domain output Y. X must be a double-precision
    %   or single-precision matrix. The object treats each column as an
    %   independent channel. The FFT length is equal to the number of rows
    %   of X. The output frame length (number of rows in Y) is equal to
    %   WindowLength - OverlapLength.
    %
    %   This object may be called directly like a function instead of using
    %   the step method. For example, y = step(obj, x) and y = obj(x) are
    %   equivalent.
    %
    %   ISTFT methods:
    %
    %   step                     - See above description for use of this
    %                              method
    %   release                  - Allow property value and input 
    %                              characteristics to change
    %   clone                    - Create ISTFT object with same property 
    %                              values
    %   isLocked                 - Locked status (logical)
    %   reset                    - Reset the internal states to initial 
    %                              conditions
    %
    %   ISTFT properties:
    %
    %   Window                   - Synthesis window
    %   OverlapLength            - Overlap length
    %   ConjugateSymmetricInput  - Input is conjugate symmetric
    %   WeightedOverlapAdd       - Apply weighted overlap-add
    %   FrequencyRange           - Frequency range
    %
    %   % EXAMPLE: Short-time spectral attenuation
    %   % Use dsp.STFT and dsp.ISTFT to denoise a signal with wideband
    %   % background noise.
    %
    %   % First, listen to audio signal corrupted by white gaussian noise:
    %   FrameLength     = 512;
    %   afr = dsp.AudioFileReader('speech_dft.wav',...
    %                             'SamplesPerFrame',FrameLength);
    %   adw = audioDeviceWriter('SampleRate',22050);
    %
    %   noiseStd = 0.05;
    %   while ~isDone(afr)
    %      cleanAudio =  afr();
    %      noisyAudio = cleanAudio + noiseStd * randn(FrameLength,1);
    %      adw(noisyAudio);
    %   end
    %
    %   reset(afr);
    %
    %   % Now use stft and istft combined with a gain estimator to remove 
    %   % noise.
    %
    %   % Define stft parameters:
    %   WindowLength    = FrameLength;
    %   HopLength       = 16;
    %   numHopsPerFrame = FrameLength / 16;
    %   FFTLength       = 1024;
    %
    %   % Define stft and istft objects:
    %   win             = hamming(WindowLength,'periodic');
    %   stf             = dsp.STFT(win,WindowLength-HopLength,FFTLength);
    %   istf            = dsp.ISTFT(win,WindowLength-HopLength,1,0);
    %
    %   % Define gain estimation parameters:
    %   dec      = 16;
    %   alpha    = 15;
    %   stftNorm = (sum(win.*win) / dec).^2;
    %
    %   % Perform spectral attenuation
    %   while ~isDone(afr)
    %     cleanAudio =  afr();
    %     noisyAudio = cleanAudio + noiseStd * randn(FrameLength,1);
    %
    %     y = zeros(FrameLength , 1); % y holds the denoised audio frame
    %
    %     % Feed audio to stft one hop-length at a time
    %     for index = 1:numHopsPerFrame
    %
    %         X = stf(noisyAudio((index-1)*HopLength+1:index*HopLength));
    %
    %         % Gain estimator
    %         Z = abs(X).^2 / (noiseStd^2 * alpha) / stftNorm;
    %         Z(Z<=1) = 1;
    %         Z = 1 - 1./Z;
    %         Z = sign(Z) .* sqrt(abs(Z));
    %         X = X .* Z;
    %
    %         % Convert back to time-domain
    %         y((index-1)*HopLength+1:index*HopLength) = istf(X);
    %
    %     end
    %
    %     % Listen to denoised audio:
    %     adw(y);
    %   end
    %
    %   See also dsp.STFT, dsp.FFT, dsp.IFFT
    
    % Copyright 2018-2020 The MathWorks, Inc.
    
    %#codegen
    
    properties
        % Window Synthesis window
        % Specify the synthesis window as a vector of real elements. The
        % default is sqrt(hann(512,'periodic')). This property is tunable.
        Window =  sqrt(hann(512,'periodic'))
        % OverlapLength Overlap length
        % Specify the number of samples by which consecutive windows
        % overlap by as a scalar, positive integer. The default is 256.
        OverlapLength = 256
        % ConjugateSymmetricInput Input is conjugate symmetric
        % Set this property to true if the input is conjugate symmetric to
        % yield real-valued outputs. The FFT of a real valued signal is
        % conjugate symmetric, and setting this property to true optimizes
        % the IFFT computation method. Setting this property to false for
        % conjugate symmetric inputs results in complex output values with
        % small imaginary parts. Setting this property to true for
        % non-conjugate symmetric inputs results in invalid outputs.
        % The default value of this property is true.
        ConjugateSymmetricInput = true
        % WeightedOverlapAdd  Apply weighted overlap-add
        % Set this property to true to apply weighted overlap-add. In
        % weighted overlap-add, the IFFT output is multiplied by the window
        % prior to overlap-add. Set this property to false to skip
        % multiplication by the window. The default of this property is
        % true.
        WeightedOverlapAdd      = true
        %FrequencyRange Frequency range
        % Specify the frequency range as 'onesided' or 'twosided'. If you
        % set the FrequencyRange to 'onesided', the one-sided inverse
        % short-time FFT is computed for a one-sided short-time FFT. If the
        % input frame length is odd, the FFT length used is (frame length -
        % 1) * 2. If the input frame length is even, the FFT length used is
        % (frame length * 2) - 1. If you set the FrequencyRange to
        % 'twosided', the inverse short-time FFT is computed for a
        % two-sided short-time FFT. The FFT length used is equal to the
        % input frame length. The default is 'twosided'.
        FrequencyRange{mustBeMember(FrequencyRange,{'onesided','twosided'})}  = 'twosided'
    end
    
    properties( Access = private)
        % pChunk Buffer used to hold overlap-add state
        pChunk
        % pWindow Private window cast to input datatype
        pWindow =  sqrt(hann(512,'periodic'))
        % pIsInitialized Flag is true if step has not been called yet
        pIsInitialized = false
        % pWindowChanged Flag is true if window needs a refresh
        pWindowChanged = false
        % pFFTLength Cache FFT length
        pFFTLength
        % pIFFTType Symmetric/non-symmetric
        pIFFTType
        % pNorm  Normalization vector
        pNorm
        % pNormWin  Window used in computing normalization
        pNormWin
        % used for one-sided input
        pNumFreqSamples
        % Cache if FFTLength modulus two is true or not
        pIsFFTLengthModTwo
    end
    
    methods
        
        % Constructor
        function obj = ISTFT(varargin)
            
            p = inputParser;
            
            addOptional(p,'Window', sqrt(hann(512,'periodic')), @isnumeric);
            addOptional(p,'OverlapLength', 256, @isnumeric);
            addOptional(p,'ConjugateSymmetricInput', true);
            addOptional(p,'WeightedOverlapAdd', true);
            addParameter(p,'FrequencyRange', 'twosided', @isCharOrString);
            % Parse Inputs
            parse(p, varargin{:});
            results = p.Results;
            
            % Set property values
            obj.Window                  = results.Window;
            obj.OverlapLength           = results.OverlapLength;
            obj.ConjugateSymmetricInput = results.ConjugateSymmetricInput;
            obj.WeightedOverlapAdd      = results.WeightedOverlapAdd;
            obj.FrequencyRange          = results.FrequencyRange;
        end
        
        function set.Window(obj,val)
            validateattributes(val,{'single','double'}, ...
                {'vector','real','nonnan'}, ...
                'set.Window','Window');
            obj.Window = val;
            
            obj.pWindowChanged = true; %#ok
        end
        
        % Set methods
        function set.OverlapLength(obj,val)
            validateattributes(val,{'numeric'}, ...
                {'scalar','integer','nonnegative','real','nonnan'}, ...
                'set.OverlapLength','OverlapLength');
            obj.OverlapLength = val;
        end
        
        function set.ConjugateSymmetricInput(obj,val)
            
            coder.internal.errorIf(obj.pIsInitialized,'MATLAB:system:propertySetWhenLocked'); %#ok
            
            validateattributes(val,{'numeric','logical'}, ...
                {'scalar','real','nonnan'}, ...
                'set.ConjugateSymmetricInput','ConjugateSymmetricInput');
            obj.ConjugateSymmetricInput = val;
        end
        
        function set.WeightedOverlapAdd(obj,val)
            
            coder.internal.errorIf(obj.pIsInitialized,'MATLAB:system:propertySetWhenLocked'); %#ok
            
            validateattributes(val,{'numeric','logical'}, ...
                {'scalar','real','nonnan'}, ...
                'set.WeightedOverlapAdd','WeightedOverlapAdd');
            obj.WeightedOverlapAdd = val;
        end
        
        function set.FrequencyRange(obj,val)
            coder.internal.errorIf(obj.pIsInitialized,'MATLAB:system:propertySetWhenLocked'); %#ok
             % Add String Support
            val = convertStringsToChars(val);
            obj.FrequencyRange = val;
        end
        
    end
    
    methods(Access = protected)
        
        function setupImpl(obj,u)

            obj.pWindow            = repmat(reshape(obj.Window,numel(obj.Window),1),1,size(u,2));
            obj.pFFTLength         = calculateFFTLength(obj,u);
            obj.pNumFreqSamples    = calculateNumFrequencySamples(obj,u);
            obj.pIsFFTLengthModTwo = mod(obj.pFFTLength,2) == 0; 
            L = numel(obj.Window);
            if obj.WeightedOverlapAdd
                obj.pNorm      = cast(obj.pWindow.^2,class(u));
            else
                obj.pNorm      = cast(obj.pWindow,class(u));
            end
            obj.pNormWin   = obj.pNorm;

            if obj.ConjugateSymmetricInput
                obj.pChunk = zeros(L - 1,size(u,2),class(u));
            else
                obj.pChunk = complex(zeros(L - 1,size(u,2),class(u))) ;
            end
            
            if obj.ConjugateSymmetricInput
               obj.pIFFTType = 'symmetric';
            else
               obj.pIFFTType = 'nonsymmetric'; 
            end

            obj.pWindowChanged = false;
            validatePropertiesImpl(obj);
        end
        
        function validatePropertiesImpl(obj)
            coder.internal.errorIf(obj.pFFTLength < numel(obj.Window), ...
                'dsp:system:STFT:FFTLengthTooShort')
            
            coder.internal.errorIf(obj.OverlapLength >= numel(obj.Window), ...
                'dsp:system:STFT:OverlapTooLong')
        end
        
        function validateInputsImpl(obj,u)
            coder.internal.errorIf(calculateFFTLength(obj,u)~= obj.pFFTLength , ...
                'dsp:system:STFT:FFTLengthChanged')
        end
        
        function NFFT = calculateFFTLength(obj, u)
            % Calculate FFT length based on the current input and frequency
            % range
            NFFT = size(u,1);
            if(strcmpi(obj.FrequencyRange,'onesided'))
                if(mod(NFFT,2) == 0)
                    % If number of stft transform points is even
                    NFFT = NFFT * 2 - 1;
                else
                    % If the number of stft transform points is odd
                    NFFT = (NFFT - 1) * 2;
                end
            end
        end
        
        function nSamples = calculateNumFrequencySamples(obj,u)
            nSamples = size(u,1);
            NFFT = obj.pFFTLength;
            if(strcmpi(obj.FrequencyRange,'onesided'))
                if(mod(NFFT,2) == 0)
                    % If the number of NFFT points is odd
                    nSamples = NFFT / 2 + 1;
                else
                    % If number of NFFT points is even
                    nSamples = (NFFT + 1) / 2;
                end
            end
        end
        
        function flag = isOneSided(obj)
           flag = strcmpi(obj.FrequencyRange,'onesided'); 
        end
        
    end
    
    methods
        function z = step(obj,u)
        %     Y = step(OBJ,x) processes the input data, x, to produce the 
        %     output, Y, for object, OBJ.
        
            % Validate inputs to the step method at initialization.
            if ~obj.pIsInitialized
                validateattributes(u,{'double','single'}, {'2d',...
                    'nonsparse'},'','input');
                setupImpl(obj,u);
                obj.pIsInitialized = true;
            end
            
            if obj.pWindowChanged
                win                = cast(reshape(obj.Window,numel(obj.Window),1),class(u));
                obj.pWindow        = repmat(win,1,size(u,2));
                obj.pWindowChanged = false;
                if obj.WeightedOverlapAdd
                    obj.pNormWin      = cast(obj.pWindow.^2,class(u));
                else
                    obj.pNormWin      = cast(obj.pWindow,class(u));
                end
            end
            
            validateInputsImpl(obj,u);
            
            if(strcmpi(obj.FrequencyRange,'onesided'))
                numSamples = obj.pNumFreqSamples;
                uout = zeros(obj.pFFTLength,size(u,2),'like',u);
                uout(1:numSamples,:) = u;
                % Convert the one-sided input transform to two-sided
                if obj.pIsFFTLengthModTwo
                    % Duplicate, conjugate and flip the samples with indices
                    % 2 to pNumFreqSamples - 1
                    uout(end:-1:numSamples+1,:) = conj(u(2:numSamples-1,:));
                else
                    % Duplicate, conjugate and flip the samples with indices
                    % 2 to pNumFreqSamples
                    uout(end:-1:numSamples+1,:) = conj(u(2:numSamples,:));
                end
                z = ifft(uout,obj.pIFFTType);
            else
                z = ifft(u,obj.pIFFTType);
            end
            
            y  = z(1:numel(obj.Window),:);
            if obj.WeightedOverlapAdd
                y  = y .* obj.pWindow;
            end
            
            % Overlap-add
            ovrlap = obj.OverlapLength;
            L      = numel(obj.Window) - ovrlap;
            c      = obj.pChunk(1:ovrlap,:);
            
            y(1:end-L,:) = y(1:end-L,:) + c;
            z            = y(1:L,:);
            c            = y(L+1:end,:);
            
            n            =  obj.pNorm;
            n0           = n;
            n0(n0==0)    = 1; % do not divide by zero
            
            % Normalize
            z = z ./ n0(1:size(z,1),:); 
           
            old                =  n(size(z,1)+1:end,:); 
            n                  =  obj.pNormWin;
            n(1:length(old),:) = n(1:length(old),:) + old;
            obj.pNorm          = n;
            
            % Update state
            obj.pChunk(1:ovrlap,:) = c;
        end
        
        function reset(obj)
            % reset Reset the internal states of the object
            obj.pChunk = zeros(size(obj.pChunk,1),size(obj.pChunk,2),'like',obj.pChunk);
            obj.pNorm  = obj.pNormWin;
        end
        
        function release(obj)
            % release Allow property value and input characteristics
            % changes
            obj.pIsInitialized = false;
        end
        
        function newISTFT = clone(obj)
            % clone Create object with same property values
            %  C = clone(OBJ) creates another instance of the object, OBJ,
            %  with the same property values. If OBJ is locked, the clone
            %  method creates a copy that is also locked and has states
            %  initialized to the same values as the original. If OBJ is not
            %  locked, the clone method creates a new unlocked object with
            %  uninitialized states.
            newISTFT = dsp.ISTFT(obj.Window,obj.OverlapLength,...
                obj.ConjugateSymmetricInput,obj.WeightedOverlapAdd,...
                'FrequencyRange',obj.FrequencyRange);
            newISTFT.pIsInitialized     = obj.pIsInitialized;
            newISTFT.pChunk             = obj.pChunk;
            newISTFT.pNorm              = obj.pNorm;
            newISTFT.pNormWin           = obj.pNormWin;
            newISTFT.pWindow            = obj.pWindow;
            newISTFT.pIsInitialized     = obj.pIsInitialized;
            newISTFT.pWindowChanged     = obj.pWindowChanged;
            newISTFT.pIFFTType          = obj.pIFFTType;
            newISTFT.pIsFFTLengthModTwo = obj.pIsFFTLengthModTwo;
            newISTFT.pFFTLength         = obj.pFFTLength;
            newISTFT.pNumFreqSamples    = obj.pNumFreqSamples;
        end
        
        function l = isLocked(obj)
            % isLocked Locked status for input attributes and non-tunable
            % properties
            l = obj.pIsInitialized;
        end
        
    end
    
    methods (Hidden)
        function n = getNumInputs(~)
            n = 1;
        end
        
        function n = getNumOutputs(~)
            n = 1;
        end
        
        function n = nargin(~)
            n = 1;
        end
        
        function flag = isInactiveProperty(~,~)
            flag = false;
        end
        
        function props = getValueOnlyProps(~)
            props = {'Window','OverlapLength','ConjugateSymmetricInput','WeightedOverlapAdd'};
        end
    end
    
    %----------------------------------------------------------------------
    % Hidden, Sealed methods
    %----------------------------------------------------------------------
    methods  (Hidden=true,Sealed=true)
        function Y = parenReference(obj,u)
            % This is used to enable stepping the object with function
            % notation.
            Y = step(obj,u);
        end
    end
    
    methods (Access = public, Hidden, Static)
        function name = matlabCodegenRedirect(~)
            name = 'dsp.internal.ISTFTCG';
        end
    end
    
end
%--------------------------------------------------------------------------
% Helper methods
%--------------------------------------------------------------------------
function flag = isCharOrString(value)
flag = ischar(value) || isstring(value);
end