classdef (StrictDefaults)ChannelSynthesizer < dsp.internal.PolyphaseFFTBase ...
        & dsp.enhancedsim.UpdateSysObjBuildInfo
%ChannelSynthesizer Polyphase FFT synthesis filter bank.
%   synthesizer = dsp.ChannelSynthesizer returns a polyphase FFT synthesis
%   filter bank System object, synthesizer, which takes multiple narrowband
%   input signals and merges them into a single broadband output signal.
%   This object implements the inverse operation of dsp.Channelizer.
%
%   synthesizer = dsp.ChannelSynthesizer(Name=Value, ...) returns a
%   synthesizer with each specified property name set to the specified
%   value. You can specify additional name-value pair arguments in any
%   order as (Name1=Value1, ...,NameN=ValueN).
%
%   The number of frequency bands (which corresponds to the number of
%   narrowband input signals) is given by the number of columns of the
%   input signal.
%
%   The specification defaults to number of taps per band and stopband
%   attenuation. These values are used to design a prototype lowpass filter
%   that is implemented in polyphase form. The stopband attenuation
%   determines the minimum level of interference (aliasing) from one
%   frequency band to another. The number of taps corresponds to the number
%   of filter coefficients used for each polyphase branch. The number of
%   polyphase branches matches the number of frequency bands. The total
%   number of filter coefficients for the prototype lowpass filter is given
%   by the number of frequency bands times the number of taps per band.
%   For a given stopband attenuation, increasing the number of taps per
%   band will narrow the transition width of the filter resulting in more
%   usable bandwidth for each frequency band at the expense of increased
%   computation.
%
%   Step method syntax:
%
%   y = step(synthesizer,x) merges the narrowband input signals contained
%   in the columns of x into a broadband signal y. The number of columns in
%   x corresponds to the number of frequency bands. If x is three
%   dimensional, each matrix corresponds to a separate channel. If M is the
%   number of frequency bands and x is a LxM matrix, y will have dimensions
%   L*Mx1. If x has more than one channel, i.e. x is LxMxN, y will have
%   dimensions L*MxN.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj,x) and y = obj(x) are
%   equivalent.
%
%   ChannelSynthesizer methods:
%
%   step      - See above description for use of this method
%   release   - Allow property value and input characteristics changes
%   clone     - Create a new object with same property values
%   isLocked  - Locked status (logical)
%   reset     - Reset the internal states to initial conditions
%   coeffs    - Returns a structure containing the prototype lowpass filter
%               coefficients
%   polyphase - Returns the polyphase coefficient matrix
%   tf        - Returns the transfer function of the prototype lowpass
%               filter
%
%   ChannelSynthesizer properties:
%
%   Specification       - Design parameters or Coefficients
%   NumTapsPerBand      - Number of filter coefficients per frequency band
%   StopbandAttenuation - Stopband attenuation for lowpass filter in dB
%   LowpassCoefficients - Coefficients for prototype lowpass filter
%
%   % EXAMPLE: Merge 8 separate narrowband signals, each one containing one
%   % sine wave into one broadband signal with the sine waves modulated to
%   % each band frequency.
%   synthesizer = dsp.ChannelSynthesizer;
%   offsets = [-400,-300,-200,-100,150,250,350,450];
%   sinewave = dsp.SineWave(ComplexOutput=true,Frequency=offsets+...
%       (-375:125:500),SamplesPerFrame=100);
%   scope = spectrumAnalyzer(ShowLegend=true, ...
%               SampleRate=sinewave.SampleRate*8);
%   for i=1:5000
%       x = sinewave();
%       y = synthesizer(x);
%       scope(y);
%   end
%
%   See also dsp.Channelizer, dsp.FIRHalfbandDecimator,
%   dsp.FIRHalfbandInterpolator, dsp.IIRHalfbandInterpolator,
%   dsp.DyadicSynthesisFilterBank, firpr2chfb.

% Copyright 2016-2021 The MathWorks, Inc.

%#codegen
    properties (Access = private)
        fhandle
        actpmatrixHalide
    end
    properties(Access=private,Nontunable)
        halideFlag = true;
    end
    
    methods
        function obj = ChannelSynthesizer(varargin)
        %ChannelSynthesizer Construct the ChannelSynthesizer class.

        % Support name-value pair arguments
            setProperties(obj,nargin,varargin{:});
            obj.halideFlag = coder.const(~strcmp(feval('dsp.internal.feature','dsp_simulations','halide'),'off'));
        end

        function p = polyphase(obj)
        %p = polyphase(obj) Return polyphase matrix
        %   p = polyphase(obj) returns the polyphase matrix used by the
        %   filter bank. Each row in the matrix corresponds to a
        %   polyphase branch. The number of columns of p corresponds to
        %   the number of filter taps per branch.
            if isLocked(obj)
                p = obj.PolyphaseMatrix;
            else
                coder.internal.errorIf(true, ['dsp:system', ...
                                    ':ChannelSynthesizer:notDesigned']);
            end

        end

        function c = coeffs(obj)
        %c = coeffs(obj) Return structure with filter coefficients
        %   c = coeffs(obj) returns the overall prototype lowpass
        %   filter coefficients in a structure.
            if isLocked(obj)
                c.Numerator = poly2coeffs(obj);
            else
                coder.internal.errorIf(true, ['dsp:system', ...
                                    ':ChannelSynthesizer:notDesigned']);
            end
        end

        function [b,a] = tf(obj)
        %[b,a] = tf(obj) Return transfer function
        %   [b,a] = tf(obj) returns the vector of numerator
        %   coefficients b and the vector of denominator coefficients a
        %   for the overall prototype lowpass filter used for the
        %   filter bank.
            if isLocked(obj)
                b = poly2coeffs(obj);
                a = 1;
            else
                coder.internal.errorIf(true, ['dsp:system', ...
                                    ':ChannelSynthesizer:notDesigned']);
            end
        end
    end

    methods (Access=protected)
        function setupImpl(obj, u)
        % Implement any tasks that need to be performed only once, such
        % as computation of constants or creation of child System objects

            setupImpl@dsp.internal.PolyphaseFFTBase(obj);
            
            obj.InputDataType  = class(u);
            M = getNumBands(obj,u);
            coder.internal.errorIf(M < 2, ['dsp:system', ...
                                ':ChannelSynthesizer:numFreqBands']);
            obj.privNumFrequencyBands = uint16(M);
            obj.oldNumFrequencyBands = int16(M);
            if ~strcmpi(obj.Specification,'Coefficients')
                designPrototypeLowpass(obj);
                NTPB = obj.NumTapsPerBand;
            else
                setPolyphaseMatrixFromCustomCoeffs(obj,M);
                NTPB = length(obj.LowpassCoefficients);
            end
            
            N =  getNumChs(obj,u);
            obj.numChannels = int16(N);

            obj.actpmatrix = obj.PolyphaseMatrix;
            obj.actpmatrixHalide = flipud(transpose(obj.PolyphaseMatrix));

            if (coder.const(feval('dsp.enhancedsim.IsSysObjSimInCodeGen',coder.target)) ...
                    || isempty(coder.target)) ...
                    && coder.const(obj.halideFlag)
                [~,Np] = size(obj.PolyphaseMatrix);
                obj.States = complex(zeros(Np-1,M,N,'like',u));
            else
                obj.States = complex(zeros(numel(obj.PolyphaseMatrix), ...
                    N,'like',u));
            end
            if isempty(coder.target)
                if coder.const(obj.halideFlag)
                    obj.fhandle = @dsp.internal.builtins.firPolyphaseFFTSynthesisHalide;

                else
                    obj.fhandle = @dsp.internal.builtins.firPolyphaseFFTSynthesis;
                    obj.actpmatrix = obj.actpmatrix.';
                end
            end
        end

        function nb = getNumBands(~,u)
        % Return the number of bands
            nb = size(u,2);
        end

        function nc = getNumChs(~,u)
        % getNumChs Return the number of input channels
            nc = size(u,3);
        end

        function y = stepImpl(obj, x)
            z = obj.States;
            if isempty(coder.target)
                if coder.const(obj.halideFlag)
                    p = obj.actpmatrixHalide;
                else
                    p = obj.actpmatrix;
                end
                [y,z] = dsp.ChannelSynthesizer.firpolyphase_muxer(p,x,z,obj.fhandle);
            else
                Lx = size(x,1);
                M = size(x,2);
                N = size(x,3);
                v = M.*ifft(x,[],2);
                y = complex(zeros(Lx*M,N,'like',x));
                if coder.const(feval('dsp.enhancedsim.IsSysObjSimInCodeGen',coder.target)) && coder.const(obj.halideFlag)
                    v = complex(M.*ifft(x,[],2));
                    NTPB = size(obj.PolyphaseMatrix, 2);
                    zPadded = zeros((Lx+NTPB)*M,N,'like',v);
                    p = obj.actpmatrixHalide;
                    [y,z] = dsp.ChannelSynthesizer.polyphasefir_cg_halide(...
                        v,y,z,p,uint32(Lx),uint32(M),uint32(N),uint32(NTPB),zPadded);
                else
                    p = obj.actpmatrix;
                    [y,z] = dsp.ChannelSynthesizer.polyphasefir_cg(v,y,z,p,Lx,M);
                end
            end
            obj.States = z;
        end
        
        function processTunedPropertiesImpl(obj)
            processTunedPropertiesImpl@dsp.internal.PolyphaseFFTBase(obj);
            if isempty(coder.target)
                obj.actpmatrix = obj.PolyphaseMatrix.';
            else
                obj.actpmatrix = obj.PolyphaseMatrix;
            end
            obj.actpmatrixHalide = flipud(transpose(obj.PolyphaseMatrix));
        end
        
        function s = saveObjectImpl(obj)
            s = saveObjectImpl@dsp.internal.PolyphaseFFTBase(obj);
            if isLocked(obj)
                s.fhandle = obj.fhandle;
                s.actpmatrixHalide = obj.actpmatrixHalide;
            end
        end
        
        function loadObjectImpl(obj, s, wasLocked)
            if wasLocked
                if isfield(s,'fhandle')
                    obj.fhandle = s.fhandle;
                end
                if isfield(s,'actpmatrixHalide')
                    obj.actpmatrixHalide = s.actpmatrixHalide;
                end
            end
            loadObjectImpl@dsp.internal.PolyphaseFFTBase(obj, s, wasLocked);
            
        end
        
        function validateInputsImpl(obj,u)
            validateattributes(u, {'single', 'double'}, {},'','');

            % Input can be 2D or 3D
            coder.internal.errorIf(ndims(u) > 3, ['dsp:system', ...
                                ':ChannelSynthesizer:numDims']);

            N = obj.numChannels;
            s3 = size(u,3);
            if N == -1 || N ==  0 || s3 == 0
                return;
            end
            coder.internal.errorIf(s3 ~= N, ['dsp:system', ...
                                ':Shared:numChannels']);

            M = obj.oldNumFrequencyBands;
            s2 = size(u,2);
            if M == -1 || M ==  0 || s2 == 0
                return;
            end
            coder.internal.errorIf(s2 < 2, ['dsp:system', ...
                                ':ChannelSynthesizer:numFreqBands']);
            coder.internal.errorIf(s2 ~= M, ['dsp:system', ...
                                ':ChannelSynthesizer:numFreqBandsChanging']);
        end
                
        function flag = isInputSizeMutableImpl(~,~)
            flag = true;
        end

        function flag = isInputComplexityMutableImpl(~,~)
            flag = true;
        end

        function designPrototypeLowpass(obj)
            M = obj.privNumFrequencyBands;
            P = obj.NumTapsPerBand;
            Astop = obj.StopbandAttenuation;

            b = cast(designMultirateFIR(M,1,ceil(P/2),Astop),obj.InputDataType);

            obj.PolyphaseMatrix = reshape(b,M,P);
        end
    end

    methods (Static, Hidden)
        function [y,z] = firpolyphase_muxer(p,x,z,fhand)
        % Inputs:
        %   p - MxNp polyphase matrix
        %   x - L/MxMxN multichannel frame input
        %   z - Np*MxN state vector
        % Outputs:
        %   y - L*N multi-channel frame output
        % Where:
        %   M  - Number of frequency bands
        %   Np - Number of taps per band
        %   L  - Output frame size (must be multiple of M)
        %   N  - Number of independent channels
        %
        % Assumptions:
        %   if p is a double, x, z must also be doubles
        %   if p is a single, x, z must also be singles
        %   z must be complex

            Lx = size(x,1);
            M = size(x,2);
            N = size(x,3);
            y = complex(zeros(Lx*M,N,'like',x));
            v = M.*ifft(x,[],2);
            [y,z] = fhand(complex(v),y,z,p,Lx,M,N);
        end

        function [y,z] = polyphasefir_cg(v,y,z,p,Lx,M)
            for m = 1:Lx
                % Load next input sample
                z(1:M,:) = v(m,1:M,:);

                for k = 1:M
                    val =  p(k,:)*z(k:M:end,:);
                    y(M*(m-1)+k,:) =  val(1: size(z,2));
                    % Update delay line
                    z(M+k:M:end,:) = z(k:M:end-M,:);
                end
                
            end
        end
        % -----------------------------------------------------------------
        function [y,z] = polyphasefir_cg_halide(v,y,z,p,Lx,M,N,Np, zPadded)
            coder.cinclude('iHalideFIRPolyphaseFFTSynthesis.hpp');
            if isa(v,'single')
                if isreal(p)
                    func = 'processHalide_firPolyphaseFFTSynthesis_CRS';
                else
                    func = 'processHalide_firPolyphaseFFTSynthesis_CCS';
                end
            else
                if isreal(p)
                    func = 'processHalide_firPolyphaseFFTSynthesis_CRD';
                else
                    func = 'processHalide_firPolyphaseFFTSynthesis_CCD';
                end
            end
                coder.ceval(func, ...
                    v,p,coder.ref(y),coder.ref(z),zPadded, ...
                    uint32(Lx),uint32(M),uint32(N),uint32(Np));
        end
    end
end
