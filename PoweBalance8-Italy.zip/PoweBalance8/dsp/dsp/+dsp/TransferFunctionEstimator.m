classdef (StrictDefaults)TransferFunctionEstimator < matlab.System                               
%TransferFunctionEstimator Estimate frequency-domain transfer function
%   TFE = dsp.TransferFunctionEstimator returns a System object, TFE, that 
%   computes the transfer function of real or complex input and output 
%   signals via the periodogram method and Welch's averaged, modified 
%   periodogram method.
%
%   TFE = dsp.TransferFunctionEstimator(Name=Value, ...) returns a Transfer
%   Function Estimator System object, TFE, with each specified property
%   name set to the specified value. You can specify additional name-value
%   pair arguments in any order as (Name1=Value1,...,NameN=ValueN).
%
%   Step method syntax:
%
%   Hxy = step(TFE, X, Y) computes the transfer function, Hxy, of the
%   system with input X and output Y using Welch's averaged periodogram
%   method. Hxy is equal to Pyx./Pxx, where Pyx is the cross power spectral
%   density of X and Y, and Pxx is the power spectral density of X. X and Y
%   must be of the same size. The columns of X and Y are treated as
%   independent channels.
%
%   [Hxy,Cxy] = step(TFE, X, Y) also computes the magnitude squared
%   coherence estimate, Cxy, of the system using Welch's averaged
%   periodogram method. Cxy is equal to (abs(Pxy).^2)./(Pxx.*Pyy), where
%   Pxy is the cross power spectral density of Y and X, Pxx is the power
%   spectral density of X, and Pyy is the power spectral density of Y. For
%   coherence to be estimated, OutputCoherence must be set to true.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   TransferFunctionEstimator methods:
%
%   step                 - Compute Transfer Function of inputs (see above)
%   release              - Allow property value and input characteristics 
%                          changes, and release Transfer Function resources
%   clone                - Create Transfer Function object with same 
%                          property values
%   isLocked             - Display locked status (logical)
%   reset                - Reset the states of the Transfer Function
%                          Estimator
%   getRBW               - Get the resolution bandwidth of the spectrum
%   getFrequencyVector   - Get the vector of frequencies at which the
%                          spectrum is estimated
%
%   TransferFunctionEstimator properties:
%
%   
%   FFTLengthSource           - Source of the FFT length value
%   FFTLength                 - FFT length
%   Window                    - Window function
%   SidelobeAttenuation       - Sidelobe attenuation of window
%   FrequencyRange            - Frequency range of the Spectrum estimate
%   AveragingMethod           - Averaging method
%   SpectralAverages          - Number of spectral averages
%   ForgettingFactor          - Forgetting factor
%   OutputCoherence           - Output magnitude squared coherence estimate
%
%   % EXAMPLE: Estimate transfer function of system represented by order-31
%   % FIR filter
%   SINE = dsp.SineWave(Frequency=100, SampleRate=1000,...
%                       SamplesPerFrame=1000);
%   TFE  = dsp.TransferFunctionEstimator(FrequencyRange="centered",...
%                                        OutputCoherence=true);
%   TFEPlotter = dsp.ArrayPlot(PlotType="Line",...
%                              XOffset=-500,...
%                              YLimits=[-120 5],...
%                              YLabel="Frequency Response (dB)",...
%                              XLabel="Frequency (Hz)",...
%                              Title="System Transfer Function");
% 
%   CoherencePlotter = dsp.ArrayPlot(PlotType="Line",...
%                                    XOffset=-500,...
%                                    YLimits=[0 1],...
%                                    YLabel="Coherence",...
%                                    XLabel="Frequency (Hz)",...
%                                    Title="System Coherence");
%     
%   LP = dsp.FIRFilter(Numerator=firceqrip(30,1/4,[0.05 0.03]));
%     
%   tic;
%   while toc < 5
%      % generate input
%      x = SINE() + .1*randn(1000,1);
%      % pass through FIR filter
%      y = LP(x);
%      % estimate transfer function
%      [Txy,Cxy] = TFE(x,y);
%      % plot transfer function
%      TFEPlotter(20*log10(abs(Txy)))
%      CoherencePlotter(Cxy)
%   end
%
%   See also dsp.SpectrumEstimator, dsp.CrossSpectrumEstimator, 
%            spectrumAnalyzer.

%   Copyright 2013-2021 The MathWorks, Inc.
  
%#codegen
%#ok<*EMCLS>

properties (Nontunable, Dependent)
  %FFTLengthSource Source of the FFT length value
  %   Specify the source of the FFT length value as one of 'Auto' |
  %   'Property'. The default is 'Auto'. When you set this property to
  %   'Auto' the Transfer function Estimator sets the FFT length to the 
  %   input frame size. When you set this property to 'Property' then you 
  %   specify the number of FFT points using the FFTLength property.
  FFTLengthSource;
  %FFTLength FFT length
  %   Specify the length of the FFT that the Transfer Function Estimator 
  %   uses to compute spectral estimates as a positive, integer scalar. 
  %   This property applies when you set the FFTLengthSource property to
  %   'Property'. The default is 128.
  FFTLength;
  %Window Window function
  %   Specify a window function for the Transfer Function estimator as one 
  %   of 'Rectangular' | 'Chebyshev' | 'Flat Top' | 'Hamming' | 'Hann' |
  %   'Kaiser'. The default is 'Hann'.
  Window;
  %SidelobeAttenuation Sidelobe attenuation of window (dB)
  %   Specify the sidelobe attenuation of the window as a real, positive
  %   scalar in decibels (dB). This property applies when you set the 
  %   Window property to 'Chebyshev' or 'Kaiser'. The default is 60 dB. 
  SidelobeAttenuation;
  % FrequencyRange Frequency range
  %   Specify the frequency range of the transfer function estimator as one 
  %   of 'twosided' | 'onesided' | 'centered'. 
  %   If you set the FrequencyRange to 'onesided', the transfer function 
  %   estimator computes the one-sided transfer function of real input 
  %   signals X and Y. When the FFT length, NFFT, is even, the transfer
  %   function estimate length is NFFT/2+1 and is computed over the 
  %   interval [0,SampleRate/2]. If NFFT is odd, the length of the transfer 
  %   function estimate is equal to (NFFT+1)/2 and the interval is 
  %   [0,SampleRate/2).
  %   If you set the FrequencyRange to 'twosided', the transfer function 
  %   estimator computes the two-sided transfer function of complex or real 
  %   inputs signals X and Y. The length of the transfer function estimate
  %   is equal to NFFT and is computed over [0, SampleRate). 
  %   If you set the FrequencyRange to 'centered', the transfer function 
  %   estimator computes the centered two-sided transfer function of 
  %   complex or real inputs signals X and Y. The length of the transfer 
  %   function estimate is equal to NFFT and is computed over 
  %   (-SampleRate/2, SampleRate/2] and (-SampleRate/2, SampleRate/2) for 
  %   even and odd length NFFT, respectively. 
  %   The default is 'twosided'
  FrequencyRange;
  % AveragingMethod Averaging method 
  %   Specify the averaging method as 'Running' or 'Exponential'. In the
  %   running averaging method, the object computes an equally weighted
  %   average of specified number of spectrum estimates defined by
  %   'SpectralAverages' property. In the exponential method, the object
  %   computes the average over samples weighted by an exponentially
  %   decaying forgetting factor. The default is 'Running'.
  AveragingMethod;
  %SpectralAverages Number of spectral averages
  %   Specify the number of spectral averages as a positive, integer
  %   scalar. The Transfer Function Estimator computes the current estimate
  %   by averaging the last N estimates, where N is the number of spectral
  %   averages defined in the SpectralAverages property. This property
  %   applies when 'AveragingMethod' is equal to 'Running'. The default
  %   is 8.
  SpectralAverages;
end

properties
  %ForgettingFactor Forgetting factor
  %   Specify the exponential weighting forgetting factor as a scalar value
  %   greater than zero and smaller than or equal to one. This property
  %   applies when 'AveragingMethod' is equal to 'Exponential'. The default
  %   is 0.9. This property is tunable.
  ForgettingFactor
end

properties (Nontunable)
    % Output magnitude squared coherence estimate
    %   Set this property to true to output the magnitude squared coherence
    %   estimate. The default value of this property is false.
    OutputCoherence (1, 1) logical = false;
end

properties (Constant, Hidden)
  % String sets
  FFTLengthSourceSet = matlab.system.StringSet({'Auto','Property'});
  WindowSet = matlab.system.StringSet({...
        'Rectangular', ...
        'Chebyshev', ...
        'Flat Top', ...
        'Hamming', ...
        'Hann', ...
        'Kaiser'});
  FrequencyRangeSet = matlab.system.StringSet({'onesided','twosided','centered'});
  AveragingMethodSet = matlab.system.StringSet({'Running','Exponential'});
end

properties (Access = private)
  % Handle to pxx Spectrum Estimator object
  pSpectrumEstimator;
  % Handle to pyy Spectrum Estimator object (coherence estimate)
  pSpectrumEstimatorY;
  % Handle to Cross-Spectrum Estimator object
  pCrossSpectrumEstimator;
end
    
%--------------------------------------------------------------------------
% Public methods
%--------------------------------------------------------------------------
methods
  % Constructor
  function obj = TransferFunctionEstimator(varargin)
    %TransferFunctionEstimator Construct the TransferFunctionEstimator 
    % class. 
    obj.pSpectrumEstimator = dsp.SpectrumEstimator('SpectrumType',...
                                                   'Power density');
    obj.pCrossSpectrumEstimator = dsp.CrossSpectrumEstimator;
    setProperties(obj, nargin, varargin{:});
  end
  
  % Dependent properties set/get
   
  function set.FFTLengthSource(obj,value)
      setParameter(obj,'FFTLengthSource',value);
  end
  function val = get.FFTLengthSource(obj)
    val = obj.pSpectrumEstimator.FFTLengthSource;
  end
  
  function set.FFTLength(obj,value)
      setParameter(obj,'FFTLength',value);
  end
  function val = get.FFTLength(obj)
    val = obj.pSpectrumEstimator.FFTLength;
  end
  
  function set.Window(obj,value)
     setParameter(obj,'Window',value);
  end
  function val = get.Window(obj)
    val = obj.pSpectrumEstimator.Window;
  end
  
  function set.SidelobeAttenuation(obj,value)
      setParameter(obj,'SidelobeAttenuation',value);
  end
  function val = get.SidelobeAttenuation(obj)
    val = obj.pSpectrumEstimator.SidelobeAttenuation;
  end
  
  function set.FrequencyRange(obj,value)
       setParameter(obj,'FrequencyRange',value);
  end
  function val = get.FrequencyRange(obj)
    val = obj.pSpectrumEstimator.FrequencyRange;
  end
  
  function set.AveragingMethod(obj, val)
     setParameter(obj,'AveragingMethod',val); 
  end
  function val = get.AveragingMethod(obj)
     val = obj.pSpectrumEstimator.AveragingMethod;
  end
  
  function set.SpectralAverages(obj,value)
     setParameter(obj,'SpectralAverages',value);
  end
  function val = get.SpectralAverages(obj)
    val = obj.pSpectrumEstimator.SpectralAverages;
  end
  
  function set.ForgettingFactor(obj,value)
     setParameter(obj,'ForgettingFactor',value);
  end
  function val = get.ForgettingFactor(obj)
    val = obj.pSpectrumEstimator.ForgettingFactor;
  end
end

%--------------------------------------------------------------------------
% Protected methods
%--------------------------------------------------------------------------
methods(Access = protected)

 function num = getNumInputsImpl(~)
    % Two inputs: x (input system data) and y (output system data)
    num = 2;
 end

 function num = getNumOutputsImpl(obj)
     if obj.OutputCoherence
         num = 2;
     else
         num = 1;
     end
 end

 function [H,Cxy] = stepImpl(obj, x,y)
     % Compute the spectrum estimate of x
     pxx = step(obj.pSpectrumEstimator,x);
     % Compute the spectrum estimate of y
     pyx = step(obj.pCrossSpectrumEstimator,y,x);
     % Transfer function estimation
     H = pyx ./ pxx;
     
     if obj.OutputCoherence
         pyy = step(obj.pSpectrumEstimatorY,y);
         Cxy = abs(pyx).^2 ./ (pyy .* pxx);
     end
     
 end
 
 function setupPyyEstimator(obj, y)
     % Setup Pyy estimator for coherence output
     obj.pSpectrumEstimatorY =  dsp.SpectrumEstimator('SpectrumType',...
                                                      'Power density');
     obj.pSpectrumEstimatorY.ReferenceLoad = obj.pSpectrumEstimator.ReferenceLoad;
     obj.pSpectrumEstimatorY.AveragingMethod = obj.pSpectrumEstimator.AveragingMethod;
     if strcmp(obj.pSpectrumEstimatorY.AveragingMethod, 'Running')
        obj.pSpectrumEstimatorY.SpectralAverages = obj.pSpectrumEstimator.SpectralAverages;
     else
        obj.pSpectrumEstimatorY.ForgettingFactor = obj.pSpectrumEstimator.ForgettingFactor;    
     end
     obj.pSpectrumEstimatorY.Window = obj.pSpectrumEstimator.Window;
     obj.pSpectrumEstimatorY.FrequencyRange = obj.pSpectrumEstimator.FrequencyRange;
     obj.pSpectrumEstimatorY.FFTLengthSource = obj.pSpectrumEstimator.FFTLengthSource;
     if strcmp(obj.pSpectrumEstimatorY.FFTLengthSource,'Property')
         obj.pSpectrumEstimatorY.FFTLength = obj.pSpectrumEstimator.FFTLength;
     end
     if strcmp(obj.pSpectrumEstimatorY.Window,'Kaiser') || strcmp(obj.pSpectrumEstimatorY.Window,'Chebyshev')
         obj.pSpectrumEstimatorY.SidelobeAttenuation = obj.pSpectrumEstimator.SidelobeAttenuation;
     end
     setup(obj.pSpectrumEstimatorY,y);
 end
 
 function setupImpl(obj, x , y)
     
    obj.pSpectrumEstimator.ReferenceLoad = cast(1,class(x));
    % Setup the Spectrum and cross-Spectrum objects
    setup(obj.pSpectrumEstimator,x);
    setup(obj.pCrossSpectrumEstimator,y,x);
    if obj.OutputCoherence
        setupPyyEstimator(obj, y);
    end
 end
 
 function  resetImpl(obj)
    % Reset the Spectrum and cross-spectrum objects
    reset(obj.pSpectrumEstimator);
    reset(obj.pCrossSpectrumEstimator);
    if obj.OutputCoherence
        reset(obj.pSpectrumEstimatorY);
    end
 end

 function  releaseImpl(obj)
    % Release the Spectrum and cross-spectrum objects
    release(obj.pSpectrumEstimator);
    release(obj.pCrossSpectrumEstimator);
    if obj.OutputCoherence
       release(obj.pSpectrumEstimatorY);
    end
 end
 
 function validateInputsImpl(obj,x,y)
    validateInputsImpl(obj.pSpectrumEstimator,x);
    validateInputsImpl(obj.pCrossSpectrumEstimator,x,y);
 end

 function flag = isInactivePropertyImpl(obj, prop)
    flag = false;
    switch prop
        case 'SidelobeAttenuation'
            flag = ~strcmp('Chebyshev',obj.Window) && ...
                   ~strcmp('Kaiser',obj.Window);
        case 'FFTLength'
            flag = strcmp(obj.FFTLengthSource,'Auto');
        case 'ForgettingFactor'
            flag = strcmp(obj.AveragingMethod, 'Running');
        case 'SpectralAverages'
            flag = strcmp(obj.AveragingMethod, 'Exponential');
    end
 end

 function s = saveObjectImpl(obj)
    s = saveObjectImpl@matlab.System(obj);
    s.pSpectrumEstimator  = matlab.System.saveObject(obj.pSpectrumEstimator);
    s.pCrossSpectrumEstimator  = matlab.System.saveObject(obj.pCrossSpectrumEstimator);
    if obj.OutputCoherence
        s.pSpectrumEstimatorY  = matlab.System.saveObject(obj.pSpectrumEstimatorY);
    end
 end
  
 function loadObjectImpl(obj, s, ~)
      obj.pSpectrumEstimator = matlab.System.loadObject(s.pSpectrumEstimator);
      obj.pCrossSpectrumEstimator =  matlab.System.loadObject(s.pCrossSpectrumEstimator);
      if isfield(s,'OutputCoherence') && s.OutputCoherence
          obj.pSpectrumEstimatorY  = matlab.System.loadObject(s.pSpectrumEstimatorY);
      end
      loadObjectImpl@matlab.System(obj, s);
 end

 function validateForgettingFactor(~,val)
     validateattributes(val,...
         {'double','single'},...
         {'real','scalar','finite','>',0,'<=',1},...
         '','ForgettingFactor');
 end
end

methods (Access = private)
  function setParameter(obj,ParameterName,value)
    obj.pSpectrumEstimator.(ParameterName) = value;
    obj.pCrossSpectrumEstimator.(ParameterName) = value;
  end
end

methods
  function RBW = getRBW(obj,varargin)
    % getRBW Get the resolution bandwidth of the transfer function 
    %   estimate, in Hz. 
    %
    %   RBW = getRBW(obj,Fs) returns the resolution bandwidth, RBW, of the
    %   transfer function estimate, in Hz. Fs is the input sample rate, in
    %   Hz. The resolution bandwidth is the smallest positive frequency, or
    %   frequency interval, that can be resolved. It is equal to ENBW * Fs/
    %   L, where L is the input length, and ENBW is the two-sided
    %   equivalent noise bandwidth of the window (in Hz). For example, if
    %   Fs = 100, L = 1024, and Window = 'Hann', RBW = enbw(hann(1024)) *
    %   100 / 1024
    %
    %  RBW = getRBW(obj) returns the resolution bandwidth assuming an input
    %  sample rate (Fs) of 1 Hz.

    RBW = obj.pSpectrumEstimator.getRBW(varargin{:});

  end
  
  function w = getFrequencyVector(obj,varargin)
   % getFrequencyVector Get the vector of frequencies at which the 
   % transfer function is estimated, in Hz. 
   %
   %   F = getFrequencyVector(obj,Fs) returns the vector of frequencies, F,
   %   at which the transfer function is estimated, in Hz. Fs is the input
   %   sample rate, in Hz. Fs is the input sample rate, in Hz. If you set
   %   the FrequencyRange to 'onesided' and the FFT length, NFFT, is even,
   %   the frequency vector is of length NFFT/2+1 and it covers the
   %   interval [0,SampleRate/2]. If you set the FrequencyRange to
   %   'onesided' and NFFT is odd, the frequency vector is of length
   %   (NFFT+1)/2 and it covers the interval [0,SampleRate/2). If you set
   %   the FrequencyRange to 'twosided', the frequency vector is of length
   %   NFFT and it covers the interval [0, SampleRate). If you set the
   %   FrequencyRange to 'centered', the frequency vector is of length NFFT
   %   and it covers the range (-SampleRate/2, SampleRate/2] for even
   %   length NFFT, and (-SampleRate/2, SampleRate/2) for odd length NFFT.
   %
   %   F = getFrequencyVector(obj) returns the frequency vector assuming an
   %   input sample rate (Fs) of 1 Hz.

   w = obj.pSpectrumEstimator.getFrequencyVector(varargin{:});
  end
end

methods (Static, Access = protected)
 function group = getPropertyGroupsImpl
    %Get default parameters group for this System object
    parameterString = getString(message('dsp:system:Shared:Parameters'));
    propertyList = {'FFTLengthSource','FFTLength',...
                   'Window','SidelobeAttenuation','FrequencyRange', ...
                   'AveragingMethod','SpectralAverages','ForgettingFactor', ...
                   'OutputCoherence'};
    group = matlab.system.display.Section('Title', parameterString, ...
                   'PropertyList', propertyList,...
                   'DependOnPrivatePropertyList',propertyList);
        
 end
end
end
