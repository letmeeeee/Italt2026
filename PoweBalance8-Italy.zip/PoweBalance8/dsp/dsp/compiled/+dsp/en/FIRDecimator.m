classdef FIRDecimator< dsp.internal.AutoDesignMultirateFIR
%FIRDecimator Filter and downsample input signals
%   FIRDECIM = dsp.FIRDecimator returns an FIR decimation System object,
%   FIRDECIM, which applies an FIR filter to the input signal, then
%   downsamples by an integer value factor. The decimator is implemented 
%   using a polyphase decimation structure.
%
%   The FIR filter used in the FIRDecimator object is typically an
%   anti-aliasing lowpass filter. The FIR coefficients can be specified 
%   by the user through the Numerator property, or be automatically 
%   designed by the object using the designMultirateFIR function.
%
%   FIRDECIM = dsp.FIRDecimator ('PropertyName', PropertyValue, ...)
%   returns an FIR decimator object, FIRDECIM, with each specified
%   property set to the specified value.
%
%   FIRDECIM = dsp.FIRDecimator(DEC,'PropertyName', PropertyValue,
%   ...) returns an FIR decimator, FIRDECIM, with the DecimationFactor
%   property set to DEC. The Numerator property is designed automatically
%   for the specified decimation factor DEC. Other specified properties are 
%   set to the specified values.
%                        
%   FIRDECIM = dsp.FIRDecimator(DEC, NUM, 'PropertyName', PropertyValue,
%   ...) returns an FIR decimator, FIRDECIM, with the DecimationFactor
%   property set to DEC, the Numerator property set to NUM. Other specified 
%   properties are set to the specified values.
%
%   FIRDECIM = dsp.FIRDecimator(DEC, 'Auto', 'PropertyName', PropertyValue,
%   ...) returns an FIR decimator, FIRDECIM, with the DecimationFactor
%   property set to DEC, the NumeratorSource property automatically set to 
%   'Auto'. Other specified properties are set to the specified values.
%
%   Step method syntax:
%
%   Y = step(FIRDECIM, X) outputs the filtered and downsampled values, Y,
%   of the input signal X. A KixN input matrix is treated as N independent
%   channels, and the System object decimates each channel over time and
%   generates a KoxN output matrix. Ko = Ki/M where M is the decimation
%   factor. The object supports real and complex floating-point and
%   fixed-point inputs, except for complex unsigned fixed-point inputs.
%   This configuration is applicable when the NumeratorSource property is
%   'Property'.
%
%   Y = step(FIRDECIM, X, NUM) outputs the filtered and downsampled values,
%   Y, of the input signal X, and filter coefficients NUM. NUM must be a
%   vector. This configuration is applicable when the NumeratorSource
%   property is 'Input port'.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   FIRDecimator methods:
%
%   step        - See above description for use of this method
%   release     - Allow property value and input characteristics changes
%   clone       - Create FIR decimation object with same property values
%   isLocked    - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>       - Reset the internal states to initial conditions
%   generatehdl - Generate HDL code. (Filter Design HDL Coder Required)
%
%   FIRDecimator properties:
%
%   DecimationFactor - Decimation factor
%   NumeratorSource  - FIR filter coefficients source
%   Numerator        - FIR filter coefficients
%   Structure        - Filter structure
%   AllowArbitraryInputLength - Allow arbitrary input length for fixed-size
%                               signals in code generation
%
%   This System object supports several filter analysis methods. For more
%   information, type dsp.FIRDecimator.helpFilterAnalysis.
%
%   This System object supports fixed-point operations. For more
%   information, type dsp.FIRDecimator.helpFixedPoint.
%
%   % EXAMPLE #1: Decimate an input by 2
%   firDecim = dsp.FIRDecimator(2);
%   u = sin(2*pi*(1:50)/50)';
%   y = firDecim(u);
%
%   % Plot output
%   [D,FsOut] = firDecim.outputDelay();
%   ts = timescope(2,[1 FsOut], TimeDisplayOffset=[0 -D],...
%                   ChannelNames={'Original','Downsampled'},...                 
%                   PlotType='stem');
%   ts(u,y);
%
%   % EXAMPLE #2: Half the sampling rate of an audio signal and play it.
%   reader = dsp.AudioFileReader('OutputDataType','single');
%   num = designMultirateFIR(1,2,0.1); % Custom design of FIR 
%   player = audioDeviceWriter(reader.SampleRate/2);
%   firDecim = dsp.FIRDecimator(2,num);
%   while ~isDone(reader)
%       audioIn = reader();
%       audioOut = firDecim(audioIn);
%       player(audioOut);
%   end
%   release(reader);
%   release(player);
%
%   See also dsp.FIRInterpolator, dsp.FIRRateConverter, designMultirateFIR,
%            dsp.FIRDecimator.helpFilterAnalysis,
%            dsp.FIRDecimator.helpFixedPoint.

 
%   Copyright 1995-2022 The MathWorks, Inc.

    methods
        function out=FIRDecimator
        end

        function out=convertToDFILT(~) %#ok<STOUT>
            % Convert the System object to a dfilt object for analysis
        end

        function out=fdhdltool(~) %#ok<STOUT>
            %FDHDLTOOL Launch the GUI to generate HDL
            %   FDHDLTOOL(Hb, nt) launches the Generate HDL dialog that lets you
            %   customize and generate Verilog or VHDL code and test benches for
            %   the quantized System object filter, Hb. You have to call FDHDLTOOL
            %   again if you make changes in the filter, Hb, in the command line.
            %
            %   The main dialog and two subordinate dialogs provide access to many
            %   options for customizing the generated filter and test bench code.
            %
            %   The Generate HDL main dialog categorizes options in two frames:
            %
            %   * HDL Filter - Options you are most likely to customize at least once:
            %   language selection, name and location of generated files, reset
            %   specifications, and optimizations.
            %
            %   * Test bench types - Options for naming and specifying the type of test
            %   bench files to generate, and specific types of stimuli the test benches
            %   are to apply.
            %
            %   EXAMPLE:
            %   firdecim = dsp.FIRDecimator;
            %   T = numerictype(1,16,15);
            %   fdhdltool(firdecim, T)
        end

        function out=generatehdl(~) %#ok<STOUT>
            %   GENERATEHDL(Hb, 'InputDataType', nt) automatically generates VHDL
            %   or Verilog code for the quantized filter, Hb. The default
            %   language is VHDL; to generate Verilog, supply the
            %   property/value pair 'TargetLanguage','Verilog'. The file is written to
            %   the HDL source directory which defaults to 'hdlsrc' under the
            %   current directory. This directory will be created if necessary.
            %
            %   GENERATEHDL(Hb, PARAMETER1, VALUE1, PARAMETER2, VALUE2, ...)
            %   generates the HDL code with parameter/value pairs. Valid properties
            %   and values for GENERATEHDL are listed in the Filter Design HDL
            %   Coder documentation section "Property Reference."
            %
            %   EXAMPLE:
            %   firdecim = dsp.FIRDecimator;
            %   T = numerictype(1,16,15);
            %   generatehdl(firdecim, 'InputDataType', T)
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
            %Get default parameters group for this System object
        end

        function out=helpFixedPoint(~) %#ok<STOUT>
            %helpFixedPoint Display dsp.FIRDecimator System object
            %               fixed-point information
            %   dsp.FIRDecimator.helpFixedPoint displays information about
            %   fixed-point properties and operations of the
            %   dsp.FIRDecimator System object.
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=parseInputArguments(~) %#ok<STOUT>
            % Parse constructor signature
        end

        function out=setPortDataTypeConnections(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            % Cache input data type for filter analysis
        end

    end
    properties
        %AccumulatorDataType Accumulator word- and fraction-length designations
        %   Specify the accumulator fixed-point data type as one of ['Full
        %   precision'} | 'Same as product' | 'Same as input' | 'Custom'].
        %   This property is applicable when the  FullPrecisionOverride
        %   property is false. The default is 'Full precision'.
        AccumulatorDataType;

        %AllowArbitraryInputLength Allow arbitrary input length for fixed-size signals
        %   When this flag is set to 'true', the fixed-size input signal can have
        %   a frame size that is not a multiple of the decimation factor.
        %   This property applies only when the input is a fixed-size signal.
        %   If the size of the input signal varies during simulation 
        %   (varible-size signal), this property does not apply. 
        %   The default value is 'false' and has to be set to 'true' to 
        %   process inputs with arbitrary frame lengths.
        AllowArbitraryInputLength;

        %CoefficientsDataType Coefficients word- and fraction-length designations
        %   Specify the coefficients fixed-point data type as one of ['Same
        %   word length as input'} | 'Custom']. This property is applicable
        %   when the NumeratorSource property is 'Property'. The default is
        %   'Same word length as input'.
        CoefficientsDataType;

        %CustomAccumulatorDataType Accumulator word and fraction lengths
        %   Specify the accumulator fixed-point type as an auto-signed, scaled
        %   numerictype object. This property is applicable when the
        %   FullPrecisionOverride property is false and when the
        %   AccumulatorDataType property is 'Custom'. The default value of this
        %   property is numerictype([],32,30).
        %
        %   See also numerictype.
        CustomAccumulatorDataType;

        %CustomCoefficientsDataType Coefficients word and fraction lengths
        %   Specify the coefficients fixed-point type as an auto-signed
        %   numerictype object. This property is applicable when the
        %   CoefficientsDataType property is 'Custom'. The default value of this
        %   property is numerictype([],16,15). This property is applicable when
        %   the NumeratorSource property is 'Property'.
        %
        %   See also numerictype.
        CustomCoefficientsDataType;

        %CustomOutputDataType Output word and fraction lengths
        %   Specify the output fixed-point type as an auto-signed, scaled
        %   numerictype object. This property is applicable when the
        %   FullPrecisionOverride property is false and when the
        %   OutputDataType property is 'Custom'. The default value of this
        %   property is numerictype([],16,15).
        %
        %   See also numerictype.
        CustomOutputDataType;

        %CustomProductDataType Product word and fraction lengths
        %   Specify the product fixed-point type as an auto-signed, scaled
        %   numerictype object. This property is applicable when the
        %   FullPrecisionOverride property is false and when the
        %   ProductDataType property is 'Custom'. The default value of this
        %   property is numerictype([],32,30).
        %
        %   See also numerictype.
        CustomProductDataType;

        %DecimationFactor Decimation factor
        %   Specify the factor by which to reduce the sampling rate of the
        %   input signal as a positive integer scalar value. The number of rows
        %   should be a multiple of the decimation factor. The default value of
        %   this property is 2.
        DecimationFactor;

        DefaultFdesign;

        DefaultLegacyNumerator;

        % Default values, computed only once - on the first instance creation.
        % Those can be later used with any subsequent instance construction.
        DefaultNumerator;

        %FullPrecisionOverride Full precision override for fixed-point arithmetic
        %   Specify whether to use full precision rules. If you set
        %   FullPrecisionOverride to true the object computes all
        %   internal arithmetic and output data types using full
        %   precision rules. These rules guarantee that no quantization
        %   occurs within the object. Bits are added as needed to ensure
        %   that no round-off or overflow occurs. If you set
        %   FullPrecisionOverride to false, fixed-point data types
        %   are controlled through individual property settings.
        FullPrecisionOverride;

        %Numerator FIR filter coefficients source
        %   Specify the source of the Numerator as one of ['Property' |
        %   'Input port' | 'Auto']. The default is 'Property'.
        NumeratorSource;

        %OutputDataType Output word- and fraction-length designations
        %   Specify the output fixed-point data type as one of ['Same as
        %   accumulator'} | 'Same as product' | 'Same as input' | 'Custom'].
        %   This property is applicable when the FullPrecisionOverride
        %   property is false. The default is 'Same as accumulator'.
        OutputDataType;

        %OverflowAction Overflow action for fixed-point operations
        %   Specify the overflow action as one of ['Wrap'} | 'Saturate']. This
        %   property is applicable when the object is not in a full precision
        %   configuration. The default is 'Wrap'.
        OverflowAction;

        %ProductDataType Product word- and fraction-length designations
        %   Specify the product fixed-point data type as one of ['Full
        %   precision'} | 'Same as input' | 'Custom']. This property is
        %   applicable when the FullPrecisionOverride property is false. The
        %   default is 'Full precision'.
        ProductDataType;

        %RoundingMethod Rounding method for fixed-point operations
        %   Specify the rounding method as one of ['Ceiling' | 'Convergent' |
        %   'Floor'} | 'Nearest' | 'Round' | 'Simplest' | 'Zero']. This
        %   property is applicable when the object is not in a full precision
        %   configuration. The default is 'Floor'.
        RoundingMethod;

        %Structure Filter structure
        %   Specify the implementation of the FIR filter as one of ['Direct
        %   form'} | 'Direct form transposed']. The default is 'Direct form'.
        Structure;

    end
end
