classdef Autocorrelator
%Autocorrelator Autocorrelation of inputs

 
%   Copyright 1995-2022 The MathWorks, Inc.

    methods
        function out=Autocorrelator
        end

    end
end
