classdef FIRRateConverter< dsp.internal.AutoDesignMultirateFIR
%FIRRateConverter Upsample, filter and downsample input signals
%   FIRRC = dsp.FIRRateConverter returns a System object, FIRRC, that
%   resamples an input signal by upsampling by an integer factor L,
%   applying an FIR filter and downsampling by another integer factor M.
%
%   The rate conversion object is implemented using an efficient polyphase
%   structure. The rate change factors L and M must be relatively
%   prime. In most cases, there will be a delay in the filtered output due
%   to causality shift of the FIR.
%
%   The FIR filter used in the FIRRateConverter can be specified by the
%   user through the Numerator property, or be automatically designed by
%   the object according to the method specified in the DesignMethod
%   property. The supported methods are 'ZOH' (hold the input sequence
%   values), 'linear' (linear interpolation), and 'Kaiser' (approximate
%   combined anti-imaging and anti-aliasing lowpass filter, using the
%   designMultirateFIR function).
%
%   FIRRC = dsp.FIRRateConverter('PropertyName', PropertyValue, ...)
%   returns an FIR rate conversion System object, FIRRC, with each
%   specified property set to the specified value.
%
%   FIRRC = dsp.FIRRateConverter(L, M, 'PropertyName', PropertyValue,
%   ...) returns an FIR rate conversion System object, FIRRC, with the
%   InterpolationFactor property set to L, the DecimationFactor property
%   set to M, and the Numerator property is designed automatically. Other
%   specified properties are set to the specified values.
%
%   FIRRC = dsp.FIRRateConverter(L, M, NUM, 'PropertyName', PropertyValue,
%   ...) returns an FIR rate conversion System object, FIRRC, with the
%   InterpolationFactor property set to L, the DecimationFactor property
%   set to M, the Numerator property set to NUM, and the NumeratorSource
%   property to 'Property'. Other specified properties are set to the
%   specified values.
%
%   FIRRC = dsp.FIRRateConverter(L, M, METHOD, 'PropertyName',
%   PropertyValue,...) returns an FIR rate conversion System object, FIRRC,
%   with the InterpolationFactor property set to L, the DecimationFactor property
%   set to M, the DesignMethod set to METHOD, and the NumeratorSource set
%   to 'Auto'. Other specified properties are set to the specified values.
%
%
%   Step method syntax:
%
%   Y = step(FIRRC, X) resamples input X and returns the resampled signal
%   Y. An M-by-N matrix input is treated as N independent channels.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   FIRRateConverter methods:
%
%   step     - See above description for use of this method
%   release  - Allow property value and input characteristics changes
%   clone    - Create FIR rate conversion object with same property values
%   isLocked - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>    - Reset filter states
%   generatehdl - Generate HDL code. (Filter Design HDL Coder Required)
%
%   FIRRateConverter properties:
%
%   InterpolationFactor - Interpolation factor
%   DecimationFactor    - Decimation factor
%   NumeratorSource     - FIR filter coefficients source
%   DesignMethod        - FIR design method
%   Numerator           - FIR filter coefficients
%   AllowArbitraryInputLength - Allow arbitrary input length for fixed-size
%                               signals in code generation
%
%   This System object supports several filter analysis methods. For more
%   information, type dsp.FIRRateConverter.helpFilterAnalysis.
%
%   This System object supports fixed-point operations. For more
%   information, type dsp.FIRRateConverter.helpFixedPoint.
%
%   % EXAMPLE 1: Resample a 100 Hz sine wave signal by a factor of 3:2.
%   % Initialize source
%   FsIn = 5000;
%   sine = dsp.SineWave(1,100,SampleRate=FsIn,SamplesPerFrame=50);
%
%   % To obtain a resampled rate of 3:2, set the interpolation factor to
%   % L=3 and decimation factor to
%   % M=2
%   L = 3;
%   M = 2;
%   src = dsp.FIRRateConverter(L,M); % Create a FIR rate converter
%
%   u = sine();
%   y = src(u);
%
%   % Plot the original and resampled signals.
%   [D,FsOut] = src.outputDelay(FsIn=FsIn); 
%   ts = timescope(2,[FsIn FsOut], TimeDisplayOffset=[0, -D],... 
%                  ChannelNames={'Original','Resampled'},...
%                  PlotType='stem');
%   ts(u,y);
%
%
%   % EXAMPLE 2: Resample and play an audio signal from 48 kHz to 44 kHz
%   % Create an FIRRateConverter System object with interpolation factor of
%   % L=11 and decimation factor of M=12 (the co-prime representation of
%   % the ratio 44k/48k), a reasonable approximation of the standard
%   % 44.1 kHz rate. The FIR is a lowpass filter, designed using
%   % designMultirateFIR for the specified conversion ratio.
%   L = 11;
%   M = 12;
%
%   num = designMultirateFIR(L,M,20); % Custom designed FIR coefficients
%   src = dsp.FIRRateConverter(L,M,num);
%
%   % Initialize source and sink
%   reader = dsp.AudioFileReader('audio48kHz.wav', ...
%         'OutputDataType','single','SamplesPerFrame',4*M);
%
%   player = audioDeviceWriter(44100); % Approximately 44kHz
%
%   while ~isDone(reader)
%       audioIn = reader();          % Read audio from file
%       audioOut = src(audioIn);     % Convert rate
%       player(audioOut);            % Play converted audio
%   end
%   release(reader);
%   release(player);
%
%
%   See also dsp.FIRInterpolator, dsp.FIRDecimator, designMultirateFIR,
%            dsp.SampleRateConverter, dsp.FarrowRateConverter,
%            dsp.FIRRateConverter.helpFilterAnalysis,
%            dsp.FIRRateConverter.helpFixedPoint.

 
%   Copyright 2008-2022 The MathWorks, Inc.

    methods
        function out=FIRRateConverter
        end

        function out=convertToDFILT(~) %#ok<STOUT>
            % Suppress MFILT deprecation warning
        end

        function out=fdhdltool(~) %#ok<STOUT>
            %   FDHDLTOOL(Hb, nt) launches the Generate HDL dialog that lets you
            %   customize and generate Verilog or VHDL code and test benches for
            %   the quantized System object filter, Hb. You have to call FDHDLTOOL
            %   again if you make changes in the filter, Hb, in the command line.
            %
            %   The main dialog and two subordinate dialogs provide access to many
            %   options for customizing the generated filter and test bench code.
            %
            %   The Generate HDL main dialog categorizes options in two frames:
            %
            %   * HDL Filter - Options you are most likely to customize at least once:
            %   language selection, name and location of generated files, reset
            %   specifications, and optimizations.
            %
            %   * Test bench types - Options for naming and specifying the type of test
            %   bench files to generate, and specific types of stimuli the test benches
            %   are to apply.
            %
            %   EXAMPLE:
            %   firrc = dsp.FIRRateConverter;
            %   T = numerictype(1,16,15);
            %   fdhdltool(firrc, T)
        end

        function out=generatehdl(~) %#ok<STOUT>
            %   GENERATEHDL(Hb, 'InputDataType', nt) automatically generates VHDL
            %   or Verilog code for the quantized filter, Hb. The default
            %   language is VHDL; to generate Verilog, supply the
            %   property/value pair 'TargetLanguage','Verilog'. The file is written to
            %   the HDL source directory which defaults to 'hdlsrc' under the
            %   current directory. This directory will be created if necessary.
            %
            %   GENERATEHDL(Hb, PARAMETER1, VALUE1, PARAMETER2, VALUE2, ...)
            %   generates the HDL code with parameter/value pairs. Valid properties
            %   and values for GENERATEHDL are listed in the Filter Design HDL
            %   Coder documentation section "Property Reference."
            %
            %   EXAMPLE:
            %   firrc = dsp.FIRRateConverter;
            %   T = numerictype(1,16,15);
            %   generatehdl(firrc, 'InputDataType', T)
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
            %Get default parameters group for this System object
        end

        function out=helpFixedPoint(~) %#ok<STOUT>
            %helpFixedPoint Display dsp.FIRRateConverter System object
            %               fixed-point information
            %   dsp.FIRRateConverter.helpFixedPoint displays information
            %   about fixed-point properties and operations of the
            %   dsp.FIRRateConverter System object.
        end

        function out=infoImpl(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=parseInputArguments(~) %#ok<STOUT>
            % Parse constructor signature
            % Empty constructor: FIRRateConverter()
        end

        function out=polyphaseMatrix(~) %#ok<STOUT>
            %polyphaseMatrix pad Numerator and reshape to polyphase components
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setPortDataTypeConnections(~) %#ok<STOUT>
        end

        function out=updateGCD(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            % Cache input data type for filter analysis
        end

    end
    properties
        %AccumulatorDataType Accumulator word- and fraction-length designations
        %   Specify the accumulator fixed-point data type as one of ['Full
        %   precision' | 'Same as product' | 'Same as input' | 'Custom'].
        %   This property is applicable when the  FullPrecisionOverride
        %   property is false. The default is 'Full precision'.
        AccumulatorDataType;

        %AllowArbitraryInputLength Arbitrary input length for fixed-size signals
        %   When this flag is set to 'true', the fixed-size input signal can have
        %   a frame size that is not a multiple of the decimation factor.
        %   This property applies only when the input is a fixed-size signal.
        %   If the size of the input signal varies during simulation 
        %   (varible-size signal), this property does not apply. 
        %   The default value is 'false' and has to be set to 'true' to 
        %   process inputs with arbitrary frame lengths.
        AllowArbitraryInputLength;

        %CoefficientsDataType Coefficients word- and fraction-length designations
        %   Specify the coefficients fixed-point data type as one of ['Same
        %   word length as input' | 'Custom']. The default is 'Same word
        %   length as input'.
        CoefficientsDataType;

        %CustomAccumulatorDataType Accumulator word and fraction lengths
        %   Specify the accumulator fixed-point type as an auto-signed, scaled
        %   numerictype object. This property is applicable when the
        %   FullPrecisionOverride property is false and when the
        %   AccumulatorDataType property is 'Custom'. The default value of this
        %   property is numerictype([],32,30).
        %
        %   See also numerictype.
        CustomAccumulatorDataType;

        %CustomCoefficientsDataType Coefficients word and fraction lengths
        %   Specify the coefficients fixed-point type as an auto-signed
        %   numerictype object. This property is applicable when the
        %   CoefficientsDataType property is 'Custom'. The default value of
        %   this property is numerictype([],16,15).
        %
        %   See also numerictype.
        CustomCoefficientsDataType;

        %CustomOutputDataType Output word and fraction lengths
        %   Specify the output fixed-point type as an auto-signed, scaled
        %   numerictype object. This property is applicable when the
        %   FullPrecisionOverride property is false and when the
        %   OutputDataType property is 'Custom'. The default value of this
        %   property is numerictype([],16,15).
        %
        %   See also numerictype.
        CustomOutputDataType;

        %CustomProductDataType Product word and fraction lengths
        %   Specify the product fixed-point type as an auto-signed, scaled
        %   numerictype object. This property is applicable when the
        %   FullPrecisionOverride property is false and when the
        %   ProductDataType property is 'Custom'. The default value of this
        %   property is numerictype([],32,30).
        %
        %   See also numerictype.
        CustomProductDataType;

        %DecimationFactor Decimation factor
        %   Specify the integer factor, by which to downsample the signal after
        %   filtering. The default value of this property is 2.
        DecimationFactor;

        DefaultFdesign;

        DefaultLegacyNumerator;

        % Default values, computed only once - on the first instance creation.
        % Those can be later used with any subsequent instance construction.
        DefaultNumerator;

        %DesignMethod Auto design method
        %   Specify the design method of the FIR filter coefficients as one of
        %   ['ZOH' | 'Linear' | 'Kaiser']. The default value is 'Kaiser'.
        DesignMethod;

        EffectiveDecimationFactor;

        EffectiveInterpolationFactor;

        EffectiveNumerator;

        FactorsGCD;

        %FullPrecisionOverride Full precision override for fixed-point arithmetic
        %   Specify whether to use full precision rules. If you set
        %   FullPrecisionOverride to true the object computes all
        %   internal arithmetic and output data types using full
        %   precision rules. These rules guarantee that no quantization
        %   occurs within the object. Bits are added as needed to ensure
        %   that no round-off or overflow occurs. If you set
        %   FullPrecisionOverride to false, fixed-point data types
        %   are controlled through individual property settings.
        FullPrecisionOverride;

        %InterpolationFactor Interpolation factor
        %   Specify the integer factor, by which to upsample the signal before
        %   filtering. The default value of this property is 3.
        InterpolationFactor;

        %Numerator FIR filter coefficients source
        %   Specify the source of the Numerator as one of ['Property' |
        %   'Auto']. The default is 'Property'.
        NumeratorSource;

        %OutputDataType Output word- and fraction-length designations
        %   Specify the output fixed-point data type as one of ['Same as
        %   accumulator' | 'Same as product' | 'Same as input' | 'Custom'].
        %   This property is applicable when the FullPrecisionOverride
        %   property is false. The default is 'Same as accumulator'.
        OutputDataType;

        %OverflowAction Overflow action for fixed-point operations
        %   Specify the overflow action as one of ['Wrap' | 'Saturate']. This
        %   property is applicable when the object is not in a full precision
        %   configuration. The default is 'Wrap'.
        OverflowAction;

        %ProductDataType Product word- and fraction-length designations
        %   Specify the product fixed-point data type as one of ['Full
        %   precision' | 'Same as input' | 'Custom']. This property is
        %   applicable when the FullPrecisionOverride property is false. The
        %   default is 'Full precision'.
        ProductDataType;

        %RoundingMethod Rounding method for fixed-point operations
        %   Specify the rounding method as one of ['Ceiling' | 'Convergent' |
        %   'Floor' | 'Nearest' | 'Round' | 'Simplest' | 'Zero']. This
        %   property is applicable when the object is not in a full precision
        %   configuration. The default is 'Floor'.
        RoundingMethod;

    end
end
