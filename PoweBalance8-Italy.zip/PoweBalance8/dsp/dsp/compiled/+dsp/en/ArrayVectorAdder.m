classdef ArrayVectorAdder
%ArrayVectorAdder Add vector to array along specified dimension

 
%   Copyright 2008-2022 The MathWorks, Inc.

    methods
        function out=ArrayVectorAdder
        end

    end
end
