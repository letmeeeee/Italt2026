classdef ArrayVectorMultiplier
%ArrayVectorMultiplier Multiply array by vector along specified dimension

 
%   Copyright 2008-2022 The MathWorks, Inc.

    methods
        function out=ArrayVectorMultiplier
        end

    end
end
