classdef CumulativeSum
%CumulativeSum Compute cumulative sum of channel, column, or row elements

 
%   Copyright 1995-2022 The MathWorks, Inc.

    methods
        function out=CumulativeSum
        end

    end
end
