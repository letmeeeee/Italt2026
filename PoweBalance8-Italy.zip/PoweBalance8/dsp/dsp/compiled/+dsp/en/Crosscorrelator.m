classdef Crosscorrelator
%Crosscorrelator Cross-correlation of two inputs

 
%   Copyright 2008-2022 The MathWorks, Inc.

    methods
        function out=Crosscorrelator
        end

    end
end
