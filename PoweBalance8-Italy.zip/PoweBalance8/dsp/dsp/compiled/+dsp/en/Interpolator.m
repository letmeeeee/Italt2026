classdef Interpolator
%Interpolator Interpolate values of real input samples

 
%   Copyright 1995-2022 The MathWorks, Inc.

    methods
        function out=Interpolator
        end

    end
end
