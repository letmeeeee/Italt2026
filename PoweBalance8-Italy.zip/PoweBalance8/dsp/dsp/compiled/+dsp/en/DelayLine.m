classdef DelayLine
%DelayLine Buffer a sequence of inputs with a one-sample shift

 
%   Copyright 2008-2022 The MathWorks, Inc.

    methods
        function out=DelayLine
        end

    end
end
