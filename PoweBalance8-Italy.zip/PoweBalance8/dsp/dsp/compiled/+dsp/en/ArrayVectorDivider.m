classdef ArrayVectorDivider
%ArrayVectorDivider Divide array by vector along specified dimension

 
%   Copyright 2008-2022 The MathWorks, Inc.

    methods
        function out=ArrayVectorDivider
        end

    end
end
