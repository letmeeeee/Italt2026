classdef Convolver
%Convolver Compute convolution of two inputs

 
%   Copyright 2008-2022 The MathWorks, Inc.

    methods
        function out=Convolver
        end

    end
end
