classdef AudioFileReader< matlab.system.SFunSystem & matlab.system.mixin.FiniteSource
%AudioFileReader Read audio samples from audio file
%   AFR = dsp.AudioFileReader returns a System object, AFR, to read an
%   audio file.
%
%   AFR = dsp.AudioFileReader(PropertyName=PropertyValue, ...) returns an
%   audio file reader System object, AFR, with each specified property set
%   to the specified value.
%
%   AFR = dsp.AudioFileReader(FILENAME, PropertyName=PropertyValue, ...)
%   returns an audio file reader System object, AFR, with Filename property
%   set to FILENAME and other specified properties set to the specified
%   values.
%
%   Step method syntax:
%
%   AUDIO = step(AFR) outputs one frame of audio samples, AUDIO. After the
%   file has been played through the number of times specified by
%   PlayCount, AUDIO will contain silence.
%
%   [AUDIO, EOF] = step(AFR) gives the end-of-file indicator in EOF. EOF
%   will be true each time the output contains the last audio sample in the
%   file.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj) and y = obj() are
%   equivalent.
%
%   AudioFileReader methods:
%
%   step     - See above description for use of this method
%   release  - Allow property value and input characteristics changes, and
%              release audio file reader resources
%   clone    - Create audio file reader object with same property values
%   isLocked - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>    - Reset to the beginning of the audio file
%   isDone   - Returns true if object has reached end-of-file PlayCount
%              times
%   <a href="matlab:help matlab.System/info   ">info</a>     - Returns information about the specified audio file
%
%   AudioFileReader properties:
%
%   Filename                    - Name of audio file from which to read
%   PlayCount                   - Number of times to play the file
%   ReadRange                   - Range of samples to read
%   SamplesPerFrame             - Number of samples in audio frame
%   SampleRate                  - Sampling rate of audio file in Hz
%                                 (read-only)
%   NumChannels                 - Number of audio channels in the file
%                                 (read-only)
%   TotalSamples                - Total number of audio samples per channel
%                                 in the file (read-only)
%   Duration                    - Total audio duration in seconds
%                                 (read-only)
%   OutputDataType              - Data type of output
%   FilenameIsTunableInCodegen  - Enable file name tunability in codegen
%   CodegenPrototypeFile        - Prototype audio file name for codegen
%
%   % EXAMPLE: Read in an audio file and play it back using the standard
%   % audio device writer.
%   AFR = dsp.AudioFileReader('speech_dft.mp3');
%   ADW = audioDeviceWriter(AFR.SampleRate);
%   while ~isDone(AFR)
%       audio = AFR();
%       ADW(audio);
%   end
%   release(AFR);  % close the input file
%   release(ADW);  % close the audio output device
%
%   See also dsp.AudioFileWriter.

 
%   Copyright 1995-2023 The MathWorks, Inc.

    methods
        function out=AudioFileReader
        end

        function out=browseButtonCallback(~) %#ok<STOUT>
            % Browse button callback - browse for an audio file via uigetfile
            % dialog.
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
            % Main properties
        end

        function out=infoImpl(~) %#ok<STOUT>
            %info Returns information about the specified audio file
            %   S = info(OBJ) returns a MATLAB structure, S, with information
            %   about the audio file specified in the Filename property. The
            %   possible fields and values for the structure S are described
            %   below:
            %
            %   SampleRate   - Sampling rate of the audio file in Hz.
            %   NumBits      - Number of bits used to encode the audio stream.
            %   TotalSamples - Total number of samples per channel.
            %   Duration     - Total file duration in seconds.
            %   NumChannels  - Number of audio channels.
        end

        function out=isDoneImpl(~) %#ok<STOUT>
            %isDone Returns true if System object has reached end-of-file 
            %PlayCount times. 
            %   STATUS = isDone(OBJ) returns a logical value, STATUS, indicating
            %   if the AudioFileReader System object, OBJ, has reached the end of
            %   the audio file PlayCount times. If the PlayCount property is set 
            %   to Inf, STATUS will be always false.
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=setFileInfoProps(~) %#ok<STOUT>
        end

    end
    properties
        %CodegenPrototypeFile Prototype audio file for codegen
        %   Specify the prototype audio file used in code generation. This
        %   property is applicable when FilenameIsTunableInCodegen is true. The
        %   attributes of the audio file specified in Filename (such as the
        %   audio format, the number of audio channels, the sample rate, and
        %   the bite rate) must match the attributes of the audio file
        %   specified in CodegenPrototypeFile. The default value of this
        %   property is 'speech_dft.mp3'.
        CodegenPrototypeFile;

        %Duration Total duration (read-only)
        %   This read-only property indicates the total duration of the audio
        %   in the file, in seconds.
        Duration;

        %Filename Audio file
        %   Specify the name of the audio file as a string. The full path
        %   for the file needs to be specified only if the file is not on the
        %   MATLAB path. The default value of this property is
        %   'speech_dft.mp3'.
        Filename;

        %FilenameIsTunableInCodegen Enable file name tunability in generated
        %code
        %   Set this property to true to enable tunability of Filename in
        %   generated C/C++ code. The default value of this property is false.
        FilenameIsTunableInCodegen;

        %NumChannels Number of audio channels (read-only)
        %   This read-only property indicates the number of audio channels
        %   in the file.
        NumChannels;

        %OutputDataType Data type of output
        %   Set the data type of the audio data output from the System object.
        %   This property can be set to one of ['double' | 'single' | 'int16'
        %   | 'uint8']. The default value of this property is 'double'.
        OutputDataType;

        %PlayCount Number of times to play the file
        %   Specify a positive integer or inf to represent the number of times
        %   to play the file. The default value of this property is 1.
        PlayCount;

        %ReadRange Range of samples to read
        %   Specify the sample range from which to read, as a vector in the
        %   form of [StartSample EndSample], where StartSample is the sample at
        %   which file reading starts, and EndSample is the sample at which
        %   file reading stops. The default value of this property is [1 inf].
        ReadRange;

        %SampleRate Sampling rate of audio file in Hz (read-only)
        %   This read-only property indicates the sampling rate in Hz of
        %   the specified audio file.
        SampleRate;

        %SamplesPerFrame Number of samples in audio frame
        %   Specify the number of samples in an audio frame as a positive
        %   scalar integer value. The default value of this property is 1024.
        SamplesPerFrame;

        %TotalSamples Total number of samples (read-only)
        %   This read-only property indicates the total number of audio
        %   samples per channel in the file.
        TotalSamples;

    end
end
