classdef Delay< matlab.system.SFunSystem & dsp.internal.FilterAnalysis
%Delay  Delay input by specified number of samples or frames
%   DELAY = dsp.Delay returns a System object, DELAY, to delay the input by
%   a specified number of samples.
%
%   DELAY = dsp.Delay('PropertyName', PropertyValue, ...) returns a delay
%   System object, DELAY, with each specified property set to the specified
%   value.
%
%   DELAY = dsp.Delay(LEN, 'PropertyName', PropertyValue, ...) returns a
%   delay System object, DELAY, with the Length property set to LEN and
%   other specified properties set to the specified values.
%
%   Step method syntax:
%
%   Y = step(DELAY, X) adds delay to input X to return output Y. Each
%   column of X is treated as an independent channel of input.
%
%   Y = step(DELAY, X, R) adds delay to X, and selectively resets the
%   System object's state based on the value of reset input R and the value
%   of the ResetCondition property. This option is available when the
%   ResetInputPort property is true.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   Delay methods:
%
%   step     - See above description for use of this method
%   release  - Allow property value and input characteristics changes
%   clone    - Create delay object with same property values
%   isLocked - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>    - Reset delay states
%
%   Delay properties:
%
%   Length                      - Amount of delay
%   InitialConditionsPerChannel - Enables different initial conditions per
%                                 channel
%   InitialConditionsPerSample  - Enables different initial conditions per
%                                 sample
%   InitialConditions           - Initial output of System object
%   ResetInputPort              - Enables resetting delay states
%   ResetCondition              - Reset trigger setting for delay
%
%   % EXAMPLE: Delay input by five samples
%   delay = dsp.Delay(5);
%   x = (1:10)';
%   y = delay(x);       % Output is [0 0 0 0 0 1 2 3 4 5]'
%
%   See also dsp.VariableIntegerDelay, dsp.VariableFractionalDelay,
%            designFracDelayFIR.

 
%   Copyright 1995-2023 The MathWorks, Inc.

    methods
        function out=Delay
        end

        function out=convertToDFILT(~) %#ok<STOUT>
            % Convert the System object to a dfilt object for analysis
        end

        function out=infoImpl(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setPortDataTypeConnections(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            % Cache input data type for filter analysis
        end

    end
    properties
        %InitialConditions Initial output of System object
        %   Specify the initial output(s) of the System object. This property can
        %   be set to a scalar, vector, matrix or cell array of MATLAB built-in
        %   numeric data type, depending on the values of the
        %   InitialConditionsPerChannel and InitialConditionsPerSample
        %   properties. The default value of this property is 0. 
        %
        %   If the input is an M-by-N matrix, the dimensions of this property
        %   value must be as follows:
        %   * If the InitialConditionsPerChannel and InitialConditionsPerSample
        %   properties are both false, the property value must be a scalar.
        %   * If the InitialConditionsPerChannel property is true and the
        %   InitialConditionsPerSample property is false, the value must be a
        %   vector of length N.
        %   * If the InitialConditionsPerChannel property is false and the
        %   InitialConditionsPerSample property is true, the value must be a
        %   vector of length equal to the Length property value.
        %   * If the InitialConditionsPerChannel and InitialConditionsPerSample
        %   properties are both true, the property value must be a cell array of
        %   size N. Each cell of the cell array represents the delay values for
        %   one channel. Each cell must be a vector of length equal to the Length
        %   property value.
        InitialConditions;

        %InitialConditionsPerChannel Enables different initial conditions per
        %                            channel
        %   Set this property to true to specify different initial conditions per
        %   channel. The default value is false.
        InitialConditionsPerChannel;

        %InitialConditionsPerSample Enables different initial conditions per
        %                           sample
        %   Set this property to true to specify different initial conditions per
        %   sample. The default value is false.
        InitialConditionsPerSample;

        %Length Amount of delay
        %   Specify amount of delay to apply to the input signal. The value of
        %   this property can be one of the following:
        %   * a scalar non-negative integer by which to equally delay all
        %   channels
        %   * a vector of non-negative integers whose length is equal to the
        %   number of input columns (channels). 
        %   The default value of this property is 1.
        Length;

        %ResetCondition Reset trigger setting for delay
        %   Specify the event to reset the delay as one of [ 'Rising edge' |
        %   'Falling edge' | 'Either edge' | 'Non-zero' ]. The System object
        %   resets the delay based on the values of this property and the reset
        %   input to the step method. This property is applicable when the
        %   ResetInputPort property is true. The default is 'Non-zero'.
        ResetCondition;

        %ResetInputPort Enables resetting delay states
        %   Specify when the System object should reset the delay states. By
        %   default, the value of this property is false, and the object does not
        %   reset the delay states. When this property is set to true, a reset
        %   control input is provided to the step method, and the ResetCondition
        %   property becomes applicable. The object resets the delay states based
        %   on the values of the ResetCondition property and the reset input to
        %   the step method.
        ResetInputPort;

    end
end
