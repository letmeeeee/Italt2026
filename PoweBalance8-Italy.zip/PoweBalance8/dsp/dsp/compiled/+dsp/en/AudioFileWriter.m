classdef AudioFileWriter< matlab.system.SFunSystem
%AudioFileWriter Write audio samples to audio file
%   AFW = dsp.AudioFileWriter returns a System object, AFW, that writes
%   audio samples to an audio file (such as a WAV file).
%
%   AFW = dsp.AudioFileWriter(PropertyName=PropertyValue, ...)
%   returns an audio file writer System object, AFW, with each
%   specified property set to the specified value.
%
%   AFW = dsp.AudioFileWriter(FILENAME, PropertyName=PropertyValue, ...)
%   returns an audio file writer System object, AFW, with Filename
%   property set to FILENAME and other specified properties set to the
%   specified values.
%
%   Step method syntax:
%
%   step(AFW, AUDIO) writes one frame of audio samples, AUDIO, to the
%   output file. AUDIO is either a vector or an M-by-N matrix for mono or
%   N-channel audio input, respectively.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, step(obj, x) and obj(x) are equivalent.
%
%   AudioFileWriter methods:
%
%   step     - See above description for use of this method
%   release  - Allow property value and input characteristics changes, and
%              release audio file writer resources
%   clone    - Create audio file writer object with same property values
%   isLocked - Locked status (logical)
%
%   AudioFileWriter properties:
%
%   Filename   - Name of audio file to which to write
%   FileFormat - Format of created file
%   Compressor - Algorithm used to compress audio data (Windows only)
%   SampleRate - Sampling rate of audio data stream
%   DataType   - Data type of the uncompressed audio
%
%   % EXAMPLE: Down-convert an audio signal and write it to disk as a 
%   %          WAV file.
%   AFR = dsp.AudioFileReader(OutputDataType='double');
%   SRC = dsp.SampleRateConverter(InputSampleRate=AFR.SampleRate, ...
%       OutputSampleRate=AFR.SampleRate/2, ...
%       Bandwidth=8000);        % decimate by 2
%   AFW = dsp.AudioFileWriter('speech_dft.wav', ...
%       SampleRate=AFR.SampleRate/2);
%   while ~isDone(AFR)
%       audioIn = AFR();
%       audioOut = SRC(audioIn);
%       AFW(audioOut);
%   end
%   release(AFR);
%   release(AFW);
%
%   See also dsp.AudioFileReader

 
%   Copyright 2008-2023 The MathWorks, Inc.

    methods
        function out=AudioFileWriter
        end

        function out=cloneImpl(~) %#ok<STOUT>
        end

        function out=getPropertyGroupsImpl(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

    end
    properties
        %Compressor Algorithm used to compress audio data (Windows only)
        %   Specify the type of compression algorithm to use to compress the
        %   audio data. This compression reduces the size of the audio file.
        %   Choose 'None (uncompressed)' to save uncompressed audio data to
        %   the file. The other options reflect the available audio compression
        %   algorithms installed on your system.  This property is only available
        %   when writing WAV or AVI files on Windows (R) platforms.
        Compressor;

        %DataType Data type of uncompressed audio
        %   Specify the data type of uncompressed audio which is written to the
        %   file. 
        %   For uncompressed WAV files, the value can be one of :
        %     'inherit'|'uint8'|'int16'|'int24'|'int32'|'single'|'double'.
        %   For FLAC files, the value can be one of :
        %     'inherit'|'uint8'|'int16'|'int24'.
        %   The default is 'int16'. Note that this property is only applicable 
        %   when writing uncompressed WAV and FLAC files.
        DataType;

        %FileFormat Format of created file
        %   Specify the format of the audio file that is created. 
        %   On Windows (R) platforms, this may be one of: 
        %       ['AVI' | 'WAV' | 'FLAC' | 'MP3' | 'OGG' | 'OPUS' | 'WMA' | 'MPEG4'].
        %   On Mac OS X (R) platforms, this may be one of:
        %       ['AVI' | 'WAV' | 'FLAC' | 'MP3' | 'OGG' | 'OPUS' | 'MPEG4'].
        %   On Linux (R) platforms, this may be one of:
        %       ['AVI' | 'WAV' | 'FLAC' | 'MP3' | 'OGG' | 'OPUS']
        %   On Linux (R), the 'OPUS' format requires libsndfile 1.0.29 or higher
        %   and the 'MP3' format requires libsndfile 1.1.0 or higher.
        %   The default format is 'WAV'.
        %   These abbreviations correspond to the following file formats:
        %       WAV:   Microsoft WAVE
        %       MP3:   MPEG-1 Audio Layer 3
        %       FLAC:  Free Lossless Audio Codec
        %       OGG:   Vorbis Compressed Audio
        %       OPUS:  OPUS Compressed Audio
        %       WMA:   Windows Media Audio
        %       AVI:   Audio-Video Interleave
        %       MPEG4: MPEG-4 AAC
        FileFormat;

        %Filename Name of audio file to which to write
        %   Specify the name of the audio file as a string. The default
        %   value of this property is 'output.wav'.
        Filename;

        %SampleRate Sampling rate of audio data stream
        %   Specify the sampling rate of the input audio data as a positive
        %   numeric scalar. The OPUS file format only supports a limited
        %   selection of values (48000, 24000, 16000, 12000, or 8000).
        %   The default value of this property is 44100.
        SampleRate;

    end
end
