classdef ArrayVectorSubtractor
%ArrayVectorSubtractor Subtract vector from array along specified dimension

 
%   Copyright 2008-2022 The MathWorks, Inc.

    methods
        function out=ArrayVectorSubtractor
        end

    end
end
