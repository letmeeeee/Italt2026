classdef FIRInterpolator< dsp.internal.AutoDesignMultirateFIR
%FIRInterpolator Upsample and filter input signals
%   FIRINTERP = dsp.FIRInterpolator returns an FIR interpolation System
%   object, FIRINTERP, which upsamples an input signal by an integer value
%   factor, and then applies an FIR filter. The interpolator is implemented 
%   using a polyphase interpolation structure.
%
%   The FIR filter used in the FIRInterpolator can be specified by the user 
%   through the Numerator property, or be automatically designed by the 
%   object according to the method specified in the DesignMethod property. 
%   The supported methods are 'ZOH' (hold the input sequence values),
%   'linear' (linear interpolation), and 'Kaiser' (approximate anti-imaging 
%   lowpass filter, using the designMultirateFIR function).
%   
%   FIRINTERP = dsp.FIRInterpolator('PropertyName', PropertyValue, ...)
%   returns an FIR interpolation object, FIRINTERP, with each specified
%   property set to the specified value.
%
%   FIRINTERP = dsp.FIRInterpolator(INTERP, 'PropertyName', 
%   PropertyValue, ...) returns an FIR interpolation object, FIRINTERP,
%   with the InterpolationFactor property set to INTERP. The Numerator 
%   property is automatically designed for the specified interpolation 
%   rate. Other specified properties are set to the specified values.
%
%   FIRINTERP = dsp.FIRInterpolator(INTERP, NUM, 'PropertyName',
%   PropertyValue, ...) returns an FIR interpolation object, FIRINTERP,
%   with the InterpolationFactor property set to INTERP, the Numerator
%   property set to NUM, and other specified properties are set to the 
%   specified values.
%
%   FIRINTERP = dsp.FIRInterpolator(INTERP, METHOD, 'PropertyName',
%   PropertyValue, ...) returns an FIR interpolation object, FIRINTERP,
%   with the InterpolationFactor property set to INTERP, the DesignMethod 
%   property is set to METHOD, and the NumeratorSource property is set 
%   to 'Auto'. Other specified properties are set to the specified values.
%
%   Step method syntax:
%
%   Y = step(FIRINTERP, X) outputs the upsampled and filtered values, Y, of
%   the input signal X. A Ki-by-N input matrix is treated as N independent
%   channels, and the System object interpolates each channel over the
%   first dimension and generates a Ko-by-N output matrix, where Ko = Ki*L
%   and L is the interpolation factor. This configuration is applicable
%   when the NumeratorSource property is 'Property'.
%
%   Y = step(FIRINTERP, X, NUM) outputs the upsampled and filtered values,
%   Y, of the input signal X, and filter coefficients NUM. NUM must be a
%   vector. This configuration is applicable when the NumeratorSource
%   property is 'Input port'.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   FIRInterpolator methods:
%
%   step        - See above description for use of this method
%   release     - Allow property value and input characteristics changes
%   clone       - Create FIR interpolation object with same property values
%   isLocked    - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>       - Reset the states
%   generatehdl - Generate HDL code. (Filter Design HDL Coder Required)
%
%   FIRInterpolator properties:
%
%   InterpolationFactor - Interpolation factor
%   NumeratorSource     - FIR filter coefficients source
%   DesignMethod        - FIR filter design method 
%   Numerator           - FIR filter coefficients
%
%   This System object supports several filter analysis methods. For more
%   information, type dsp.FIRInterpolator.helpFilterAnalysis.
%
%   This System object supports fixed-point operations. For more
%   information, type dsp.FIRInterpolator.helpFixedPoint.
% 
%   % EXAMPLE #1: Interpolate an input by 4 using linear interpolation.
%   firInterp = dsp.FIRInterpolator(4,'linear');
%   x = (0:2)'
%   y = firInterp(x)
%
%   % EXAMPLE #2: Interpolate an input by 4 using Kaiser interpolation.
%   firInterp = dsp.FIRInterpolator(4);
%   u = sin((0:30)'*pi/10);
%   y = firInterp(u);
%
%   % Plot the original and resampled signals.
%   [D,FsOut] = firInterp.outputDelay(); 
%   ts = timescope(2,[FsOut 1], TimeDisplayOffset=[-D, 0],... 
%                  ChannelNames={'Upsampled','Original'},...
%                  PlotType='stem');
%   ts(y,u);
%
%   % EXAMPLE #3: Double the sampling rate of an audio signal from 22050 Hz
%   % to 44100 kHz and play it.
%   reader = dsp.AudioFileReader('OutputDataType','single');
%   player = audioDeviceWriter(44100);
%   firInterp = dsp.FIRInterpolator(2);
%   while ~isDone(reader)
%       audioIn = reader();
%       audioOut = firInterp(audioIn);
%       player(audioOut);
%   end
%   release(reader);
%   release(player);
%
%   See also dsp.FIRDecimator, dsp.FIRRateConverter, designMultirateFIR,
%            dsp.FIRInterpolator.helpFilterAnalysis,
%            dsp.FIRInterpolator.helpFixedPoint.

 
%   Copyright 2008-2022 The MathWorks, Inc.

    methods
        function out=FIRInterpolator
        end

        function out=convertToDFILT(~) %#ok<STOUT>
            % Convert the System object to a dfilt object for analysis
        end

        function out=fdhdltool(~) %#ok<STOUT>
            %FDHDLTOOL Launch the GUI to generate HDL
            %   FDHDLTOOL(Hb, nt) launches the Generate HDL dialog that lets you
            %   customize and generate Verilog or VHDL code and test benches for
            %   the quantized System object filter, Hb. You have to call FDHDLTOOL 
            %   again if you make changes in the filter, Hb, in the command line. 
            %
            %   The main dialog and two subordinate dialogs provide access to many
            %   options for customizing the generated filter and test bench code.
            %
            %   The Generate HDL main dialog categorizes options in two frames:
            % 
            %   * HDL Filter - Options you are most likely to customize at least once:
            %   language selection, name and location of generated files, reset
            %   specifications, and optimizations. 
            % 
            %   * Test bench types - Options for naming and specifying the type of test
            %   bench files to generate, and specific types of stimuli the test benches
            %   are to apply.
            %
            %   EXAMPLE:
            %   firinterp = dsp.FIRInterpolator;
            %   T = numerictype(1,16,15);
            %   fdhdltool(firinterp, T)
        end

        function out=generatehdl(~) %#ok<STOUT>
            %   GENERATEHDL(Hb, 'InputDataType', nt) automatically generates VHDL
            %   or Verilog code for the quantized filter, Hb. The default 
            %   language is VHDL; to generate Verilog, supply the 
            %   property/value pair 'TargetLanguage','Verilog'. The file is written to 
            %   the HDL source directory which defaults to 'hdlsrc' under the 
            %   current directory. This directory will be created if necessary.
            %
            %   GENERATEHDL(Hb, PARAMETER1, VALUE1, PARAMETER2, VALUE2, ...)
            %   generates the HDL code with parameter/value pairs. Valid properties
            %   and values for GENERATEHDL are listed in the Filter Design HDL 
            %   Coder documentation section "Property Reference."
            %
            %   EXAMPLE:
            %   firinterp = dsp.FIRInterpolator;
            %   T = numerictype(1,16,15);
            %   generatehdl(firinterp, 'InputDataType', T)
        end

        function out=helpFixedPoint(~) %#ok<STOUT>
            %helpFixedPoint Display dsp.FIRInterpolator System object
            %               fixed-point information
            %   dsp.FIRInterpolator.helpFixedPoint displays information
            %   about fixed-point properties and operations of the
            %   dsp.FIRInterpolator System object.
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=parseInputArguments(~) %#ok<STOUT>
            % Parse constructor signature
        end

        function out=setPortDataTypeConnections(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
            % Cache input data type for filter analysis
        end

    end
    properties
        %AccumulatorDataType Accumulator word- and fraction-length designations
        %   Specify the accumulator fixed-point data type as one of ['Full
        %   precision' | 'Same as product' | 'Same as input' | 'Custom'].
        %   This property is applicable when the  FullPrecisionOverride
        %   property is false. The default is 'Full precision'.
        AccumulatorDataType;

        %CoefficientsDataType Coefficient word- and fraction-length designations
        %   Specify the coefficients fixed-point data type as one of ['Same word
        %   length as input' | 'Custom']. This property is applicable when the
        %  NumeratorSource property is 'Property'. The default is 'Same word
        %  length as input'.
        CoefficientsDataType;

        %CustomAccumulatorDataType Accumulator word and fraction lengths
        %   Specify the accumulator fixed-point type as an auto-signed, scaled
        %   numerictype object. This property is applicable when the
        %   FullPrecisionOverride property is false and when the
        %   AccumulatorDataType property is 'Custom'. The default value of this
        %   property is numerictype([],32,30).
        %
        %   See also numerictype.
        CustomAccumulatorDataType;

        %CustomCoefficientsDataType Coefficient word and fraction lengths
        %   Specify the coefficients fixed-point type as an auto-signed
        %   numerictype object. This property is applicable only when the
        %   CoefficientsDataType property is 'Custom', and the NumeratorSource 
        %   property is 'Property'. The default value of this property is 
        %   numerictype([],16,15). 
        %
        %   See also numerictype.
        CustomCoefficientsDataType;

        %CustomOutputDataType Output word and fraction lengths
        %   Specify the output fixed-point type as an auto-signed, scaled
        %   numerictype object. This property is applicable when the
        %   FullPrecisionOverride property is false and when the
        %   OutputDataType property is 'Custom'. The default value of this
        %   property is numerictype([],16,15).
        %
        %   See also numerictype.
        CustomOutputDataType;

        %CustomProductDataType Product word and fraction lengths
        %   Specify the product fixed-point type as an auto-signed, scaled
        %   numerictype object. This property is applicable when the
        %   FullPrecisionOverride property is false and when the
        %   ProductDataType property is 'Custom'. The default value of this
        %   property is numerictype([],32,30).
        %
        %   See also numerictype.
        CustomProductDataType;

        DefaultFdesign;

        DefaultLegacyNumerator;

        % Default values, computed only once - on the first instance creation.
        % Those can be later used with any subsequent instance construction.
        DefaultNumerator;

        %DesignMethod Auto design method
        %   Specify the design method of the FIR coefficients as one of 
        %   ['ZOH' | 'Linear' | 'Kaiser']. The default value is 'Kaiser'.
        DesignMethod;

        %FullPrecisionOverride Full precision override for fixed-point arithmetic
        %   Specify whether to use full precision rules. If you set
        %   FullPrecisionOverride to true, the object computes all
        %   internal arithmetic and output data types using full
        %   precision rules. These rules guarantee that no quantization
        %   occurs within the object. Bits are added as needed to ensure
        %   that no round-off or overflow occurs. If you set
        %   FullPrecisionOverride to false, fixed-point data types
        %   are controlled through individual property settings.
        FullPrecisionOverride;

        %InterpolationFactor Interpolation factor
        %   Specify the factor by which to increase the sampling rate of the
        %   input signal, as scalar integer value. The default value of this
        %   property is 3.
        InterpolationFactor;

        %Numerator FIR filter coefficients source
        %   Specify the source of the Numerator as one of ['Property' |
        %   'Input port' | 'Auto']. The default is 'Property'.
        NumeratorSource;

        %OutputDataType Output word- and fraction-length designations
        %   Specify the output fixed-point data type as one of ['Same as
        %   accumulator' | 'Same as product' | 'Same as input' | 'Custom'].
        %   This property is applicable only when the FullPrecisionOverride
        %   property is false. The default is 'Same as accumulator'.
        OutputDataType;

        %OverflowAction Overflow action for fixed-point operations
        %   Specify the overflow action as one of ['Wrap' | 'Saturate']. This
        %   property is applicable only when the object is not in a full 
        %   precision configuration. The default is 'Wrap'.
        OverflowAction;

        %ProductDataType Product word- and fraction-length designations
        %   Specify the product fixed-point data type as one of ['Full
        %   precision' | 'Same as input' | 'Custom']. This property is
        %   applicable only when the FullPrecisionOverride property is false. 
        %   The default is 'Full precision'.
        ProductDataType;

        %RoundingMethod Rounding method for fixed-point operations
        %   Specify the rounding method as one of ['Ceiling' | 'Convergent' |
        %   'Floor' | 'Nearest' | 'Round' | 'Simplest' | 'Zero']. This
        %   property is applicable only when the object is not in a full 
        %   precision configuration. The default is 'Floor'.
        RoundingMethod;

    end
end
