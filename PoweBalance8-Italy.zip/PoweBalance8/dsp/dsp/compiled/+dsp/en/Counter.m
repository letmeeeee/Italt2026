classdef Counter
%Counter Count up or down through specified range of numbers

 
%   Copyright 2008-2022 The MathWorks, Inc.

    methods
        function out=Counter
        end

    end
end
