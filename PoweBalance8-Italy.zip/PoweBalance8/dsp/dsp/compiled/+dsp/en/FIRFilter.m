classdef FIRFilter< matlab.system.CoreBlockSystem & dsp.internal.FilterAnalysis & dsp.internal.MultiChannelSim
%FIR Filter Static or time-varying FIR filters
%   FIR = dsp.FIRFilter returns a finite impulse response (FIR) filter
%   System object, FIR, which independently filters each channel of the
%   input over time using a specified FIR filter implementation.
%
%   FIR = dsp.FIRFilter(Name=Value, ...) returns an FIR filter System
%   object, FIR, with each specified property set to the specified value.
%
%   FIR = dsp.FIRFilter(NUMERATOR, Name=Value, ...) returns an FIR filter
%   System object, FIR, with the Numerator property set to NUMERATOR and
%   other specified properties set to the specified values.
%
%   Step method syntax:
%
%   Y = step(FIR, X) filters the real or complex input signal X using the
%   specified filter to produce the output Y. The System object filters
%   each column of the input signal independently over time.
%
%   Y = step(FIR, X, COEFF) uses the time-varying coefficients COEFF, to
%   filter the input signal X and produce the output Y. This option is
%   possible when the NumeratorSource property is 'Input port'.
%
%   System objects may be called directly like a function instead of using
%   the step method. For example, y = step(obj, x) and y = obj(x) are
%   equivalent.
%
%   FIRFilter methods:
%
%   step        - See above description for use of this method
%   release     - Allow property value and input characteristics changes
%   clone       - Create FIR filter object with same property values
%   isLocked    - Locked status (logical)
%   <a href="matlab:help matlab.System/reset   ">reset</a>       - Reset the internal states to initial conditions
%   generatehdl - Generate HDL code. (Filter Design HDL Coder Required)
%
%   FIRFilter properties:
%
%   NumeratorSource              - Source of filter coefficients
%   Numerator                    - Filter coefficients
%   ReflectionCoefficientsSource - Source of Lattice filter coefficients
%   ReflectionCoefficients       - Lattice filter coefficients
%   InitialConditions            - Initial conditions
%   Structure                    - Filter structure
%
%   This System object supports several filter analysis methods. For more
%   information, type dsp.FIRFilter.helpFilterAnalysis.
%
%   This System object supports fixed-point operations. For more
%   information, type dsp.FIRFilter.helpFixedPoint.
%
%   % EXAMPLE 1: Remove high-frequency sinusoid using an FIR filter.
%   % Initialize
%   f1 = 1000; f2 = 3000; Fs = 8000; Fcutoff = 2000;
%   sine = dsp.SineWave(Frequency=[f1,f2],SampleRate=Fs, ...
%       SamplesPerFrame=1024);
%   firlp1 = dsp.FIRFilter(fir1(130,Fcutoff/(Fs/2)));
%   scope = spectrumAnalyzer(SampleRate=Fs,ShowLegend=true, ...
%       PlotAsTwoSidedSpectrum=false,YLimits=[-120 40], ...
%       ChannelNames=["Input Signal","Output Signal"]);
%   % Stream processing loop
%   for k = 1:100
%       input = sum(sine(),2);    % Add the two sinusoids together
%       filteredOutput = firlp1(input);
%       scope([input,filteredOutput]);
%   end
%
%   % EXAMPLE 2: Design an equiripple lowpass FIR filter. Filter white
%   % Gaussian noise with the resulting dsp.FIRFilter and estimate the
%   % transfer function.
%   % Initialize
%   Fs = 96e3; filtSpecs = fdesign.lowpass(20e3,22.05e3,1,80,Fs);
%   firlp2 = design(filtSpecs,"equiripple",SystemObject=true);
%   tfe = dsp.TransferFunctionEstimator(FrequencyRange="onesided", ...
%       SpectralAverages=50);
%   ap = dsp.ArrayPlot(PlotType="Line",YLimits=[-100 5], ...
%       YLabel="Magnitude (dB)",XLabel="Frequency (Hz)", ...
%       SampleIncrement=Fs/1024,ShowLegend=true, ...
%       Title="Magnitude Response",ChannelNames=["Exact","Estimate"]);
%   Htrue = freqz(firlp2,513);  % Compute exact transfer function
%   % Stream processing loop
%   Niter = 1000;
%   for k = 1:Niter
%       x = randn(1024,1);      % Input signal = white Gaussian noise
%       y = firlp2(x);          % Filter noise with FIR filter
%       H = tfe(x,y);           % Compute transfer function estimate
%       ap(20*log10(abs([Htrue,H])));  % Plot estimate
%   end
%
%   See also dsp.BiquadFilter, dsp.FrequencyDomainFIRFIlter,
%            dsp.FIRFilter.helpFixedPoint,
%            dsp.FIRFilter.helpFilterAnalysis.

 
%   Copyright 2011-2023 The MathWorks, Inc.

    methods
        function out=FIRFilter
        end

        function out=convertToDFILT(~) %#ok<STOUT>
            % Convert the System object to a dfilt object for analysis
        end

        function out=fdhdltool(~) %#ok<STOUT>
            %   FDHDLTOOL(Hb, nt) launches the Generate HDL dialog that lets you
            %   customize and generate Verilog or VHDL code and test benches for
            %   the quantized System object filter, Hb. You have to call FDHDLTOOL
            %   again if you make changes in the filter, Hb, in the command line.
            %
            %   The main dialog and two subordinate dialogs provide access to many
            %   options for customizing the generated filter and test bench code.
            %
            %   The Generate HDL main dialog categorizes options in two frames:
            %
            %   * HDL Filter - Options you are most likely to customize at least once:
            %   language selection, name and location of generated files, reset
            %   specifications, and optimizations.
            %
            %   * Test bench types - Options for naming and specifying the type of test
            %   bench files to generate, and specific types of stimuli the test benches
            %   are to apply.
            %
            %   EXAMPLE:
            %   firfilt = dsp.FIRFilter;
            %   T = numerictype(1,16,15);
            %   fdhdltool(firfilt, T)
        end

        function out=generatehdl(~) %#ok<STOUT>
            %   GENERATEHDL(Hb, 'InputDataType', nt) automatically generates VHDL
            %   or Verilog code for the quantized filter, Hb. The default
            %   language is VHDL; to generate Verilog, supply the
            %   property/value pair 'TargetLanguage','Verilog'. The file is written to
            %   the HDL source directory which defaults to 'hdlsrc' under the
            %   current directory. This directory will be created if necessary.
            %
            %   GENERATEHDL(Hb, PARAMETER1, VALUE1, PARAMETER2, VALUE2, ...)
            %   generates the HDL code with parameter/value pairs. Valid properties
            %   and values for GENERATEHDL are listed in the Filter Design HDL
            %   Coder documentation section "Property Reference."
            %
            %   EXAMPLE:
            %   firfilt = dsp.FIRFilter;
            %   T = numerictype(1,16,15);
            %   generatehdl(firfilt, 'InputDataType', T)
        end

        function out=helpFixedPoint(~) %#ok<STOUT>
            %helpFixedPoint Display dsp.FIRFilter System object fixed-point
            %               information
            %   dsp.FIRFilter.helpFixedPoint displays information about
            %   fixed-point properties and operations of the dsp.FIRFilter System
            %   object.
        end

        function out=infoImpl(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

        function out=setPortDataTypeConnections(~) %#ok<STOUT>
        end

        function out=validateInputsImpl(~) %#ok<STOUT>
        end

    end
    properties
        %AccumulatorDataType Accumulator word- and fraction-length designations
        %   Specify the accumulator fixed-point data type as one of [{'Full
        %   precision' | 'Same as product' | 'Same as input' | 'Custom']. This
        %   property is applicable when the  FullPrecisionOverride property is
        %   false. The default is 'Full precision'.
        AccumulatorDataType;

        %CoefficientsDataType Numerator word- and fraction-length designations
        %   Specify the numerator fixed-point data type as one of ['Same
        %   word length as input' | 'Custom']. The default is 'Same word length
        %   as input'.
        CoefficientsDataType;

        %CustomAccumulatorDataType Accumulator word and fraction lengths
        %   Specify the accumulator fixed-point type as a signed or unsigned,
        %   scaled numerictype object. This property is applicable when the
        %   FullPrecisionOverride property is false and when the
        %   AccumulatorDataType property is 'Custom'. The default value of this
        %   property is numerictype(true,32,30).
        %
        %   See also numerictype.
        CustomAccumulatorDataType;

        %CustomCoefficientsDataType Numerator word and fraction lengths
        %   Specify the numerator fixed-point type as a signed or unsigned
        %   numerictype object. This property is applicable when the
        %   CoefficientsDataType property is 'Custom'. The default value of
        %   this property is numerictype(true,16,15).
        %
        %   See also numerictype.
        CustomCoefficientsDataType;

        %CustomOutputDataType Output word and fraction lengths
        %   Specify the output fixed-point type as a signed or unsigned, scaled
        %   numerictype object. This property is applicable when the
        %   FullPrecisionOverride property is false and when the OutputDataType
        %   property is 'Custom'. The default value of this property is
        %   numerictype(true,16,15).
        %
        %   See also numerictype.
        CustomOutputDataType;

        %CustomProductDataType Product word and fraction lengths
        %   Specify the product fixed-point type as a signed or unsigned,
        %   scaled numerictype object. This property is applicable when the
        %   FullPrecisionOverride property is false and when the
        %   ProductDataType property is 'Custom'. The default value of this
        %   property is numerictype(true,32,30).
        %
        %   See also numerictype.
        CustomProductDataType;

        %CustomReflectionCoefficientsDataType Reflection coefficients word and
        %fraction lengths
        %   Specify the numerator fixed-point type as a signed or unsigned
        %   numerictype object. This property is applicable when the
        %   ReflectionCoefficientsDataType property is 'Custom'. The default
        %   value of this property is numerictype(true,16,15).
        %
        %   See also numerictype.
        CustomReflectionCoefficientsDataType;

        %CustomStateDataType State word and fraction lengths
        %   Specify the state fixed-point type as a signed or unsigned, scaled
        %   numerictype object. This property is applicable when the
        %   FullPrecisionOverride property is false and when the OutputDataType
        %   property is 'Custom'. The default value of this property is
        %   numerictype(true,16,15).
        %
        %   See also numerictype.
        CustomStateDataType;

        %FullPrecisionOverride Full precision override for fixed-point arithmetic
        %   Specify whether to use full precision rules. If you set
        %   FullPrecisionOverride to true the object computes all
        %   internal arithmetic and output data types using full
        %   precision rules. These rules guarantee that no quantization
        %   occurs within the object. Bits are added as needed to ensure
        %   that no round-off or overflow occurs. If you set
        %   FullPrecisionOverride to false, fixed-point data types
        %   are controlled through individual property settings.
        FullPrecisionOverride;

        %InitialConditions Initial conditions of the filter states
        %   Specify the initial conditions of the filter states. The default
        %   value of this property is 0. This property is tunable. To learn how
        %   to specify initial conditions, see the help of the
        %   InitialConditions property.
        InitialConditions;

        %Numerator Filter coefficients
        %   Specify the filter coefficients as a real or complex numeric row
        %   vector. This property is applicable when the NumeratorSource
        %   property is 'Property' and the Structure property is set to one of
        %   'Direct form', 'Direct form symmetric', 'Direct form
        %   antisymmetric', or 'Direct form transposed'. This property is
        %   tunable. The default value of this property is [0.5 0.5].
        Numerator;

        %NumeratorSource Source of filter coefficients
        %   Specify the source of the filter coefficients as one of
        %   [{'Property' | 'Input port']. When the filter coefficients are
        %   specified via input port, the System object updates the
        %   time-varying filter once every frame. The default is 'Property'.
        NumeratorSource;

        %OutputDataType Output word- and fraction-length designations
        %   Specify the output fixed-point data type as one of [{'Same as
        %   accumulator' | 'Same as input' | 'Custom']. This property is
        %   applicable when the FullPrecisionOverride property is false. The
        %   default is 'Same as accumulator'.
        OutputDataType;

        %OverflowAction Overflow action for fixed-point operations
        %   Specify the overflow action as one of ['Wrap' | 'Saturate']. The
        %   default is 'Wrap'. The default is 'Wrap'
        OverflowAction;

        %ProductDataType Product word- and fraction-length designations
        %   Specify the product fixed-point data type as one of [{'Full
        %   precision' | 'Same as input' | 'Custom']. This property is
        %   applicable when the FullPrecisionOverride property is false. The
        %   default is 'Full precision'.
        ProductDataType;

        %ReflectionCoefficients Lattice filter coefficients
        %   Specify the lattice filter coefficients as a real or complex
        %   numeric row vector. This property is applicable when the
        %   ReflectionCoefficientsSource property is 'Property' and the
        %   Structure property is set to 'Lattice MA'. This property is
        %   tunable. The default value of this property is [0.5 0.5].
        ReflectionCoefficients;

        %ReflectionCoefficientsDataType Reflection coefficients word- and
        %fraction-length designations
        %   Specify the reflection coefficients fixed-point data type as one of
        %   [{'Same word length as input' | 'Custom']. The default is 'Same
        %   word length as input'.
        ReflectionCoefficientsDataType;

        %ReflectionCoefficientsSource Source of Lattice filter coefficients
        %   Specify the source of the Lattice filter coefficients as one of
        %   [{'Property' | 'Input port']. When the filter coefficients are
        %   specified via input port, the System object updates the
        %   time-varying filter once every frame. The default is 'Property'.
        ReflectionCoefficientsSource;

        %RoundingMethod Rounding method for fixed-point operations
        %   Specify the rounding method as one of ['Ceiling' | 'Convergent' |
        %   'Floor' | 'Nearest' | 'Round' | 'Simplest' | 'Zero']. The default
        %   is 'Floor'.
        RoundingMethod;

        %StateDataType State word- and fraction-length designations
        %   Specify the state fixed-point data type as one of [{'Same as
        %   accumulator' | 'Same as input' | 'Custom']. This property is
        %   applicable when the FullPrecisionOverride property is false. The
        %   default is 'Same as accumulator'.
        StateDataType;

        %Structure Filter structure
        %   Specify the filter structure as one of [{'Direct form' |'Direct
        %   form symmetric' | 'Direct form antisymmetric' | 'Direct form
        %   transposed' | 'Lattice MA']. The default is 'Direct form'.
        Structure;

    end
end
