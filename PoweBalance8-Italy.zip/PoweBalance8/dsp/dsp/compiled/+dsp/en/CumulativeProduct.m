classdef CumulativeProduct
%CumulativeProduct Compute cumulative product of channel, column, or row
%elements

 
%   Copyright 1995-2022 The MathWorks, Inc.

    methods
        function out=CumulativeProduct
        end

    end
end
