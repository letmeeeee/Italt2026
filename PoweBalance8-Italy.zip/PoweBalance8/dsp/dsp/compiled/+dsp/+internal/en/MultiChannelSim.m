classdef MultiChannelSim< matlab.system.SystemAttributes
% Class that has the properties and methods that are used for
% multi-channel parallel simulations

 
    % Copyright 2022 The MathWorks, Inc.

    methods
        function out=MultiChannelSim
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
            % Load MultiChannelParallelism (if exist)
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

    end
end
