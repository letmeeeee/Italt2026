% This function takes a dsp.FilterCascade and converts it to a
% mfilt.cascade.

 
%   Copyright 2015-2021 The MathWorks, Inc.

