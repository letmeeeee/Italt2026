classdef Maximum< dsp.internal.MaximumBase
%Maximum Maximum values in an input or sequence of inputs

 
%   Copyright 2019-2020 The MathWorks, Inc.

    methods
        function out=Maximum
        end

        function out=helpFixedPoint(~) %#ok<STOUT>
            %helpFixedPoint Display dsp.Maximum System object fixed-point
            %               information
            %   dsp.Maximum.helpFixedPoint displays information about
            %   fixed-point properties and operations of the dsp.Maximum
            %   System object.
        end

        function out=isFrameBasedProcessing(~) %#ok<STOUT>
        end

    end
    properties
        %Dimension Dimension to operate along
        %   Specify how the maximum calculation is performed over the data as
        %   one of ['All' | 'Row' | 'Column' | 'Custom']. This property is
        %   applicable when the RunningMaximum property is false. The default
        %   is 'Column'.
        Dimension;

        %IndexBase Numbering base for index of maximum value
        %   Specify the numbering base used when computing the index of the
        %   maximum value as one of ['One' | 'Zero']. This property is
        %   applicable when the IndexOutputPort property is true. The default
        %   is 'One'.
        IndexBase;

    end
end
