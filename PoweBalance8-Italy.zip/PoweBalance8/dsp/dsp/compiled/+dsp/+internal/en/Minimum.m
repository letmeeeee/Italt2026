classdef Minimum< dsp.internal.MinimumBase
%Minimum Minimum values in an input or sequence of inputs

 
%   Copyright 2019-2020 The MathWorks, Inc.

    methods
        function out=Minimum
        end

        function out=helpFixedPoint(~) %#ok<STOUT>
            %helpFixedPoint Display dsp.Minimum System object fixed-point
            %               information
            %   dsp.Minimum.helpFixedPoint displays information about
            %   fixed-point properties and operations of the dsp.Minimum
            %   System object.
        end

        function out=isFrameBasedProcessing(~) %#ok<STOUT>
        end

    end
    properties
        %Dimension Dimension to operate along
        %   Specify how the minimum calculation is performed over the data as
        %   one of ['All' | 'Row' | 'Column' | 'Custom']. This property is
        %   applicable when the RunningMinimum property is false. The default
        %   is 'Column'.
        Dimension;

        %IndexBase Numbering base for index of minimum value
        %   Specify the numbering base used when computing the index of the
        %   minimum value as one of ['One' | 'Zero']. This property is
        %   applicable when the IndexOutputPort property is true. The default
        %   is 'One'.
        IndexBase;

    end
end
