classdef RMS< matlab.system.SFunSystem
%RMS    Root-mean-square of the vector elements

 
%   Copyright 2008-2019 The MathWorks, Inc.

    methods
        function out=RMS
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=setPortDataTypeConnections(~) %#ok<STOUT>
        end

    end
    properties
        %CustomDimension Numerical dimension to operate along
        %   Specify the dimension (one-based scalar integer value) of the input
        %   signal, along which the RMS is computed. The value of this property
        %   cannot exceed the number of dimensions in the input signal. This
        %   property is applicable when Dimension property is 'Custom'. The
        %   default value of this property is 1.
        CustomDimension;

        %Dimension Dimension to operate along    
        %   Specify the dimension along which to calculate the RMS as one of
        %   ['All' | 'Row' | 'Column' | 'Custom']. This property is
        %   applicable when the RunningRMS property is false. The default is
        %   'Column'.
        Dimension;

        %ResetCondition Reset condition for running RMS mode
        %   Specify the event to reset the running RMS as one of ['Rising edge'
        %   | 'Falling edge' | 'Either edge' | 'Non-zero']. This property is
        %   applicable when the ResetInputPort property is true. The default is
        %   'Non-zero'.
        ResetCondition;

        %ResetInputPort Enables resetting in running RMS mode 
        %   Set this property to true to enable resetting the running RMS. When
        %   the property is set to true, a reset input must be specified to the
        %   step method to reset the running RMS. This property is applicable
        %   when the RunningRMS property is true. The default value of this
        %   property is false.
        ResetInputPort;

        %RunningRMS Calculation over successive calls to step method
        %   Set this property to true to enable the calculation of RMS over
        %   successive calls to the step method. The default value of this
        %   property is false.
        RunningRMS;

    end
end
