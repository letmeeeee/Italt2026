classdef IDCT< dsp.internal.DCT
%IDCT   Inverse discrete cosine transform (IDCT)

 
%   Copyright 2020 The MathWorks, Inc.

    methods
        function out=IDCT
        end

    end
end
