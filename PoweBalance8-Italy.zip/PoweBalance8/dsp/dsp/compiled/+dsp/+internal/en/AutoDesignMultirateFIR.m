classdef AutoDesignMultirateFIR< matlab.system.SFunSystem & dsp.internal.FilterAnalysisMultirate & dsp.internal.MultiChannelSim
%AutoDesignMultirateFIR 
%
% This is a shared prototype of automatic design for FIR rate conversion
% classes. It is meant to be inherited - no intances of that class should
% be created.

 
%   Copyright 2021 The MathWorks, Inc.

    methods
        function out=AutoDesignMultirateFIR
        end

        function out=designFIRFilter(~) %#ok<STOUT>
            %designFIRFilter Design an FIR filter based on design requirements
            % (specified in properties e.g rates, DesignMethod and 
            % NumeratorSource defined in the inherited classes
        end

        function out=infoImpl(~) %#ok<STOUT>
        end

        function out=invalidateNumerator(~) %#ok<STOUT>
        end

        function out=isInactivePropertyImpl(~) %#ok<STOUT>
        end

        function out=loadObjectImpl(~) %#ok<STOUT>
        end

        function out=saveObjectImpl(~) %#ok<STOUT>
        end

    end
    properties
        %Numerator FIR filter coefficients
        %   Specify the numerator coefficients of the FIR filter in descending
        %   power of z. This property is applicable when the NumeratorSource 
        %   property is 'Property', or 'Auto' (read only).
        Numerator;

    end
end
