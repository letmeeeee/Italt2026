#!/bin/bash

#日志文件存放路径
file_url=/home/moxa/PingWork/


#-sm 以单位M显示文件大小
#file_size=$(du -sm $file_url | awk '{print $1}')

#删除日志文件的数量
delete_num=1

#容量的阈值，当大于等于此值的时候删除一定量的旧日志
threshold=500
while true
do
    file_size=$(du -sm $file_url | awk '{print $1}')
    if [ $file_size -ge $threshold ]
    then
	echo $file_size
        cd $file_url
        ls -tr $file_url | head -$delete_num | xargs rm -rf
    fi

    sleep 600
done
