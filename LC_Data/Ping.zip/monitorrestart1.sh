hwclock --hctosys
cd /home/moxa/
chmod +x ./tems
sleep 1
setinterface /dev/ttyMI0 0
sleep 1
setinterface /dev/ttyMI1 1
sleep 1
setinterface /dev/ttyMI2 1
sleep 1
setinterface /dev/ttyMI3 1
sleep 1
setinterface /dev/ttyMI4 1
sleep 1
setinterface /dev/ttyMI5 1
sleep 1
setinterface /dev/ttyMI6 1
sleep 1
setinterface /dev/ttyMI7 1
sleep 1
while true; do
{
	NUM1=`ps aux | grep tems | grep -v grep | wc -l`
	if [ "${NUM1}" -lt "1" ];then
	{
		echo "tems Restart!"
		./tems&
	}
	elif [ "${NUM1}" -gt "1" ];then
	{
		echo "tems Killing ......"
		killall -9 tems
	}
	else
	{
		echo "tems Guarding ......"
	}
	fi
	sleep 3
	NUM2=`ps aux | grep Cloud | grep -v grep | wc -l`
	if [ "${NUM2}" -lt "1" ];then
	{
		echo "Cloud Restart!"
		#./Cloud&
	}
	elif [ "${NUM2}" -gt "1" ];then
	{
		echo "Cloud Killing ......"
		killall -9 Cloud
	}
	else
	{
		echo "Cloud Guarding ......"
	}
	fi
	sleep 3
	NUM3=`ps aux | grep check.sh | grep -v grep | wc -l`
	if [ "${NUM3}" -lt "1" ];then
	{
		echo "check.sh Restart!"
		./check.sh&
	}
	elif [ "${NUM3}" -gt "1" ];then
	{
		echo "check.sh Killing ......"
		killall -9 check.sh
	}
	else
	{
		echo "check.sh Guarding ......"
	}
	fi
	sleep 3
	NUM4=`ps aux | grep checkping.sh | grep -v grep | wc -l`
	if [ "${NUM4}" -lt "1" ];then
	{
		echo "checkping.sh Restart!"
		./checkping.sh&
	}
	elif [ "${NUM4}" -gt "1" ];then
	{
		echo "checkping.sh Killing ......"
		killall -9 checkping.sh
	}
	else
	{
		echo "checkping.sh Guarding ......"
	}
	fi
	sleep 3
	NUM5=`ps aux | grep DoPing.sh | grep -v grep | wc -l`
	if [ "${NUM5}" -lt "1" ];then
	{
		echo "DoPing.sh Restart!"
		./DoPing.sh&
	}
	elif [ "${NUM5}" -gt "1" ];then
	{
		echo "DoPing.sh Killing ......"
		killall -9 DoPing.sh
	}
	else
	{
		echo "DoPing.sh Guarding ......"
	}
	fi
	sleep 3
}
done

