#!/bin/bash
M=/home/moxa/PingWork/
filename=/home/moxa/PingWork/`date '+%Y-%m-%d'`
if [ ! -d $M ];then
      mkdir -p $M
        echo -e "\033[32mThe $M Create Successfully!\033[0m"
else
        echo "This $M is exists..."
fi
while true
do
for i in `cat /home/moxa/iplist.txt`
  do
    {
   echo "${i}" 
    ping -c 4 -W 3 ${i}|grep loss|awk '{print $6}'|awk '{print strftime("%H%M%S ",systime()) "'${i}'" "!"  $0; fflush()}' >> "${filename}.txt"
  }& 
   done
  wait
done

